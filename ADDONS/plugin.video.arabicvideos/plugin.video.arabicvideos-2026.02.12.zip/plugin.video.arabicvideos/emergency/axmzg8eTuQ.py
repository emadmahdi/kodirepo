# -*- coding: utf-8 -*-
import sys as JRZhm9oGbiNpcyFnMD3IE2PWXB
EqtyLPNxcWQhK189mi = JRZhm9oGbiNpcyFnMD3IE2PWXB.version_info [0] == 2
q7DLi98wTvyWBtHfJ0mCGjks3 = 2048
ZGMPKfmIijH = 7
def WW5N6bGwvrIjCs8YJ0zA (KkJQHDReAcaP7olqg):
	global OO3XpWPHUaKg
	XPqTdDwz49M1e3VF0 = ord (KkJQHDReAcaP7olqg [-1])
	XXwnHomG1SENP9OZg = KkJQHDReAcaP7olqg [:-1]
	fHJS1ZNgjX = XPqTdDwz49M1e3VF0 % len (XXwnHomG1SENP9OZg)
	hQuJZ1X4k7 = XXwnHomG1SENP9OZg [:fHJS1ZNgjX] + XXwnHomG1SENP9OZg [fHJS1ZNgjX:]
	if EqtyLPNxcWQhK189mi:
		jH7CAy3JonxpzTFS52EO6 = unicode () .join ([unichr (ord (KdhkeYTV0EO) - q7DLi98wTvyWBtHfJ0mCGjks3 - (MC8npQRKxsEv5j7JkqLNtfSI + XPqTdDwz49M1e3VF0) % ZGMPKfmIijH) for MC8npQRKxsEv5j7JkqLNtfSI, KdhkeYTV0EO in enumerate (hQuJZ1X4k7)])
	else:
		jH7CAy3JonxpzTFS52EO6 = str () .join ([chr (ord (KdhkeYTV0EO) - q7DLi98wTvyWBtHfJ0mCGjks3 - (MC8npQRKxsEv5j7JkqLNtfSI + XPqTdDwz49M1e3VF0) % ZGMPKfmIijH) for MC8npQRKxsEv5j7JkqLNtfSI, KdhkeYTV0EO in enumerate (hQuJZ1X4k7)])
	return eval (jH7CAy3JonxpzTFS52EO6)
vl4nJBZQaMposrSwKExOyF,Wg792AJqnwz8moOTZ5,IIYvtpudBF=WW5N6bGwvrIjCs8YJ0zA,WW5N6bGwvrIjCs8YJ0zA,WW5N6bGwvrIjCs8YJ0zA
NTpqJgmvS0a6huZY,t3tIngkbNWG,QFLni0mkUMtHPKy=IIYvtpudBF,Wg792AJqnwz8moOTZ5,vl4nJBZQaMposrSwKExOyF
dYDmO5JoywunX43WNrVSPGE,HGANbdw4xPSyWJCBYzT,PtWvHo63XmwqN472r5QaxTJCSVyDAK=QFLni0mkUMtHPKy,t3tIngkbNWG,NTpqJgmvS0a6huZY
ZaiujwYhQ634qN7SRg,mLS1NZKPri0aM9DYBXyVFwe,zziCKgtI82GP1awehZ6RNSMY3F=PtWvHo63XmwqN472r5QaxTJCSVyDAK,HGANbdw4xPSyWJCBYzT,dYDmO5JoywunX43WNrVSPGE
uKX2cTFCewkW9djva5SR0Qis3,UnqwOyV5tC2,dYqLj0iTxu3Xbp9kRMv=zziCKgtI82GP1awehZ6RNSMY3F,mLS1NZKPri0aM9DYBXyVFwe,ZaiujwYhQ634qN7SRg
Ovd7GgHCDba,WPvoul2AhyacUiJrFwCjMezk,ueWGTXL5PRAoB8t7=dYqLj0iTxu3Xbp9kRMv,UnqwOyV5tC2,uKX2cTFCewkW9djva5SR0Qis3
k4ASEqQL62gwtpoMDvWcn,wJaK1lpHiUF4yWgmROf,nekdqf82zYhWDHwBxjmiKlXSEv4O5=ueWGTXL5PRAoB8t7,WPvoul2AhyacUiJrFwCjMezk,Ovd7GgHCDba
ii5os2hUtM1Rj,pBAbC3eLGcXghFI9KSMo,g1qH4Xu9EhdlTASrnxyD6KVpP=nekdqf82zYhWDHwBxjmiKlXSEv4O5,wJaK1lpHiUF4yWgmROf,k4ASEqQL62gwtpoMDvWcn
P7XtS5p1ElTkWDJZ,djKXw1lcMEgtou0Skma,fh4wNp3Pye6b9LvIjx=g1qH4Xu9EhdlTASrnxyD6KVpP,pBAbC3eLGcXghFI9KSMo,ii5os2hUtM1Rj
PP9pDw1mOqy0GsceaXuh7YkdxL2V,Wkl7xOf63GPnVhdYE2ac0riMF18NDZ,R0GqN43CuTkIsXgdfoeKhxL=fh4wNp3Pye6b9LvIjx,djKXw1lcMEgtou0Skma,P7XtS5p1ElTkWDJZ
cWLX7oZjbzguAsaDKY2HfO,p6GDqY5K0mWwyb,BBHpvyLIWArKzNmT05asfJn=R0GqN43CuTkIsXgdfoeKhxL,Wkl7xOf63GPnVhdYE2ac0riMF18NDZ,PP9pDw1mOqy0GsceaXuh7YkdxL2V
import xbmc as MLG9yjuh7vx,xbmcgui as OOSE0PUYQDHrb2Z9vcqLghkzfAyWC,sys as JRZhm9oGbiNpcyFnMD3IE2PWXB,os as hTuX1lqNoK5vWGmjPrzE8Uc9HQ,requests as l8Yqnzf0PTNusmxi15WR7bD,re as SznexPKUa5CjXtVm29u,xbmcvfs as RRzge3yH1JjEcWw6rnoF9kqKOPfNvm,base64 as YKAo5QuMv2WlwjLOB7Xfz9HqFRk,time as F1k8UmJz5VTj6ptb4
JDWy8bwVMaCTr12deSxuHmvsF3 = NTpqJgmvS0a6huZY(u"ࠫࠬࠀ")
def KWGqDigcLsdF3lvhPrQ7It2HkaTw9o(request):
	ZFXphULWB7V9YoGHlRO1eMQCq = t3tIngkbNWG(u"ࠬࡨࡵࡴࡻࡧ࡭ࡦࡲ࡯ࡨࡰࡲࡧࡦࡴࡣࡦ࡮ࠪࠁ")
	if request==t3tIngkbNWG(u"࠭ࡳࡵࡣࡵࡸࠬࠂ"): MLG9yjuh7vx.executebuiltin(wJaK1lpHiUF4yWgmROf(u"ࠧࡂࡥࡷ࡭ࡻࡧࡴࡦ࡙࡬ࡲࡩࡵࡷࠩࠩࠃ")+ZFXphULWB7V9YoGHlRO1eMQCq+P7XtS5p1ElTkWDJZ(u"ࠨࠫࠪࠄ"))
	elif request==dYqLj0iTxu3Xbp9kRMv(u"ࠩࡶࡸࡴࡶࠧࠅ"): MLG9yjuh7vx.executebuiltin(wJaK1lpHiUF4yWgmROf(u"ࠪࡈ࡮ࡧ࡬ࡰࡩ࠱ࡇࡱࡵࡳࡦࠪࠪࠆ")+ZFXphULWB7V9YoGHlRO1eMQCq+PP9pDw1mOqy0GsceaXuh7YkdxL2V(u"ࠫ࠮࠭ࠇ"))
	return
def oPSeZwkEVFRWrDzNMjJgcB5t(nueDPzsGTN,PQF3ijxABRvK6IzwDkoeyZUSLa,g2jcw9YreUWqZu1F8KB,eeZhq7mPk4YXLIlGtg5cwf9CM,text):
	if not PQF3ijxABRvK6IzwDkoeyZUSLa: PQF3ijxABRvK6IzwDkoeyZUSLa = fh4wNp3Pye6b9LvIjx(u"้ࠬไศࠩࠈ")
	if not g2jcw9YreUWqZu1F8KB: g2jcw9YreUWqZu1F8KB = UnqwOyV5tC2(u"࠭ๆฺ็ࠪࠉ")
	if not eeZhq7mPk4YXLIlGtg5cwf9CM: eeZhq7mPk4YXLIlGtg5cwf9CM = Ovd7GgHCDba(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪࠊ")
	if r9wPbk4AMEu1: ii3bPVFUcgXfY = OOSE0PUYQDHrb2Z9vcqLghkzfAyWC.Dialog().yesno(eeZhq7mPk4YXLIlGtg5cwf9CM,text,JDWy8bwVMaCTr12deSxuHmvsF3,JDWy8bwVMaCTr12deSxuHmvsF3,PQF3ijxABRvK6IzwDkoeyZUSLa,g2jcw9YreUWqZu1F8KB)
	else: ii3bPVFUcgXfY = OOSE0PUYQDHrb2Z9vcqLghkzfAyWC.Dialog().yesno(eeZhq7mPk4YXLIlGtg5cwf9CM,text,PQF3ijxABRvK6IzwDkoeyZUSLa,g2jcw9YreUWqZu1F8KB)
	return ii3bPVFUcgXfY
def zLSmNK08YVFt(nueDPzsGTN,DPwgTAIshcZHOrjayNtY018ln7X,eeZhq7mPk4YXLIlGtg5cwf9CM,text):
	if not eeZhq7mPk4YXLIlGtg5cwf9CM: eeZhq7mPk4YXLIlGtg5cwf9CM = QFLni0mkUMtHPKy(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫࠋ")
	return OOSE0PUYQDHrb2Z9vcqLghkzfAyWC.Dialog().ok(eeZhq7mPk4YXLIlGtg5cwf9CM,text)
def FVklYWOXETibraHG4n(eeZhq7mPk4YXLIlGtg5cwf9CM=ii5os2hUtM1Rj(u"ࠩ็์าฯࠠศๆ่ๅฬะ๊ฮࠩࠌ"),dNhepykOVXxqoFLUlM3ZGjCrfuID=JDWy8bwVMaCTr12deSxuHmvsF3):
	UzJt6LbNkRWQrpIOln4yvTXaAK = OOSE0PUYQDHrb2Z9vcqLghkzfAyWC.Dialog().input(eeZhq7mPk4YXLIlGtg5cwf9CM,dNhepykOVXxqoFLUlM3ZGjCrfuID,type=OOSE0PUYQDHrb2Z9vcqLghkzfAyWC.INPUT_ALPHANUM)
	UzJt6LbNkRWQrpIOln4yvTXaAK = UzJt6LbNkRWQrpIOln4yvTXaAK.strip(cWLX7oZjbzguAsaDKY2HfO(u"ࠪࠤࠬࠍ")).replace(nekdqf82zYhWDHwBxjmiKlXSEv4O5(u"ࠫࠥࠦࠠࠡࠩࠎ"),R0GqN43CuTkIsXgdfoeKhxL(u"ࠬࠦࠧࠏ")).replace(HGANbdw4xPSyWJCBYzT(u"࠭ࠠࠡࠢࠪࠐ"),dYqLj0iTxu3Xbp9kRMv(u"ࠧࠡࠩࠑ")).replace(PP9pDw1mOqy0GsceaXuh7YkdxL2V(u"ࠨࠢࠣࠫࠒ"),vl4nJBZQaMposrSwKExOyF(u"ࠩࠣࠫࠓ"))
	return UzJt6LbNkRWQrpIOln4yvTXaAK
def PPojrN6elakwsfR(W1TRey76KgnP0r3):
	ii3bPVFUcgXfY = oPSeZwkEVFRWrDzNMjJgcB5t(JDWy8bwVMaCTr12deSxuHmvsF3,JDWy8bwVMaCTr12deSxuHmvsF3,JDWy8bwVMaCTr12deSxuHmvsF3,JDWy8bwVMaCTr12deSxuHmvsF3,R0GqN43CuTkIsXgdfoeKhxL(u"ࠪๆอ๊ࠠฦำึห้ࠦำอๆࠣห้ษฮุษฤࠤ๏าศࠡล้ࠤฯฺฺๅࠢหี๋อๅอࠢ฼้ฬี้ࠠฬ้ฮ฽ืࠠฮฬ์ࠤฯ฾็าࠢ็็ࠥอไๆึส็้่ࠦศๆฦา฼อมࠡ࠰࠱ࠤ฾์ฯ่ษࠣื๏่่ๆࠢๆ์ิ๐ࠠษฬึะ๏๊่ࠠา๊ࠤฬ๊ๅีษๆ่ࠥ๎วๅลั฻ฬวࠠโ์ࠣืั๊ࠠศๆฦา฼อมࠡ࠰࠱ࠤํฮูะ้สࠤ็๋ࠠษวิืฬ๊ࠠิฮ็ࠤฬ๊รฯูสล๊ࠥไๆสิ้ัࠦ࠮࠯๊่ࠢࠥะั๋ัࠣห้ศๆࠡวิืฬ๊ࠠิฮ็ࠤฬ๊รฯูสลࠥหไ๊ࠢส่๊ฮัๆฮࠣรࠦ࠭ࠔ"))
	if ii3bPVFUcgXfY!=p6GDqY5K0mWwyb(u"࠱ࢫ"): return
	if not hTuX1lqNoK5vWGmjPrzE8Uc9HQ.path.exists(W1TRey76KgnP0r3):
		zLSmNK08YVFt(JDWy8bwVMaCTr12deSxuHmvsF3,JDWy8bwVMaCTr12deSxuHmvsF3,JDWy8bwVMaCTr12deSxuHmvsF3,vl4nJBZQaMposrSwKExOyF(u"้๊ࠫริใࠣ࠲࠳ࠦำอๆࠣห้ษฮุษฤࠤ฿๐ัࠡ็๋ะํีࠠฤู๊้๊่ࠣฮࠩࠕ"))
		return
	message = FVklYWOXETibraHG4n(UnqwOyV5tC2(u"ࠬษใหสࠣีุอไหๅࠣห้ะ๊ࠡฬิ๎ิࠦลาีส่์อࠠๆ฻ࠣืั๊ࠠศๆฦา฼อมࠨࠖ"))
	TxHfFqrmPeEULbNQh = MLG9yjuh7vx.getInfoLabel(fh4wNp3Pye6b9LvIjx(u"࠭ࡓࡺࡵࡷࡩࡲ࠴ࡁࡥࡦࡲࡲ࡛࡫ࡲࡴ࡫ࡲࡲ࠭࠭ࠗ")+TOV6ItlaNjiADh1Lng2SWwc9PGvKXd+ueWGTXL5PRAoB8t7(u"ࠧࠪࠩ࠘"))
	file = open(W1TRey76KgnP0r3,PP9pDw1mOqy0GsceaXuh7YkdxL2V(u"ࠨࡴࡥࠫ࠙"))
	t9LwDusvmndQOTFh4k8blKYz = hTuX1lqNoK5vWGmjPrzE8Uc9HQ.path.getsize(W1TRey76KgnP0r3)
	if t9LwDusvmndQOTFh4k8blKYz>Wkl7xOf63GPnVhdYE2ac0riMF18NDZ(u"࠴࠲࠴࠴࠵࠶ࢬ"): file.seek(-Wkl7xOf63GPnVhdYE2ac0riMF18NDZ(u"࠴࠲࠴࠴࠵࠶ࢬ"),hTuX1lqNoK5vWGmjPrzE8Uc9HQ.SEEK_END)
	data = file.read()
	file.close()
	data = data.decode(wJaK1lpHiUF4yWgmROf(u"ࠩࡸࡸ࡫࠾ࠧࠚ"))
	bA7QSspGU1fczIjdVaTeu = SznexPKUa5CjXtVm29u.findall(R0GqN43CuTkIsXgdfoeKhxL(u"ࠥࠫࡺࡹࡥࡳࡡ࡬ࡨࠬࡀࠠࠨࠪ࠱࠮ࡄ࠯ࠧࠣࠛ"),data,SznexPKUa5CjXtVm29u.DOTALL)
	if not bA7QSspGU1fczIjdVaTeu: bA7QSspGU1fczIjdVaTeu = SznexPKUa5CjXtVm29u.findall(P7XtS5p1ElTkWDJZ(u"ࠦࠬࡻࡳࡦࡴࠪ࠾ࠥ࠭ࠨ࠯ࠬࡂ࠭ࠬࠨࠜ"),data,SznexPKUa5CjXtVm29u.DOTALL)
	if not bA7QSspGU1fczIjdVaTeu: bA7QSspGU1fczIjdVaTeu = SznexPKUa5CjXtVm29u.findall(wJaK1lpHiUF4yWgmROf(u"ࠬࡢࡤࡼ࠶ࢀ࠱ࡡࡪࡻ࠵ࡿ࠰ࡠࡩࢁ࠴ࡾ࠯࡟ࡨࢀ࠺ࡽ࠮࡞ࡧࡿ࠹ࢃࠧࠝ"),data,SznexPKUa5CjXtVm29u.DOTALL)
	bA7QSspGU1fczIjdVaTeu = bA7QSspGU1fczIjdVaTeu[p6GDqY5K0mWwyb(u"࠲ࢭ")] if bA7QSspGU1fczIjdVaTeu else pBAbC3eLGcXghFI9KSMo(u"࠭࠰࠱࠲࠳ࠫࠞ")
	bA7QSspGU1fczIjdVaTeu = bA7QSspGU1fczIjdVaTeu.split(PP9pDw1mOqy0GsceaXuh7YkdxL2V(u"ࠧ࡝ࡰࠪࠟ"),Wkl7xOf63GPnVhdYE2ac0riMF18NDZ(u"࠴ࢮ"))[dYqLj0iTxu3Xbp9kRMv(u"࠴ࢯ")]
	if r9wPbk4AMEu1: bA7QSspGU1fczIjdVaTeu = bA7QSspGU1fczIjdVaTeu.encode(Wg792AJqnwz8moOTZ5(u"ࠨࡷࡷࡪ࠽࠭ࠠ"))
	hBeibz91IfAoTP4L0s2HWOumE = Wkl7xOf63GPnVhdYE2ac0riMF18NDZ(u"ࠩࡄ࡚࠿ࠦࠧࠡ")+bA7QSspGU1fczIjdVaTeu+ueWGTXL5PRAoB8t7(u"ࠪ࠱ࡊࡳࡥࡳࡩࡨࡲࡨࡿࠧࠢ")
	message += k4ASEqQL62gwtpoMDvWcn(u"ࠫࡡࡴ࡜࡯࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࡞ࡱࡉࡲࡧࡩ࡭ࠢࡖࡩࡳࡪࡥࡳ࠼ࠣࠫࠣ")+bA7QSspGU1fczIjdVaTeu+fh4wNp3Pye6b9LvIjx(u"ࠬࠦ࠺ࠨࠤ")+dYqLj0iTxu3Xbp9kRMv(u"࠭࡜࡯ࠩࠥ")+dYDmO5JoywunX43WNrVSPGE(u"ࠧࡂࡦࡧࡳࡳࠦࡖࡦࡴࡶ࡭ࡴࡴ࠺ࠡࠩࠦ")+TxHfFqrmPeEULbNQh+dYDmO5JoywunX43WNrVSPGE(u"ࠨࠢ࠽ࡠࡳ࠭ࠧ")
	data = data.encode(PtWvHo63XmwqN472r5QaxTJCSVyDAK(u"ࠩࡸࡸ࡫࠾ࠧࠨ"))
	b71qT8F3OoXEUtKjmNlLGvZphsCu = YKAo5QuMv2WlwjLOB7Xfz9HqFRk.b64encode(data)
	VqilRgFQ7xU3Je9Zz5v62ka4tH = {NTpqJgmvS0a6huZY(u"ࠪࡷࡺࡨࡪࡦࡥࡷࠫࠩ"):hBeibz91IfAoTP4L0s2HWOumE,Ovd7GgHCDba(u"ࠫࡲ࡫ࡳࡴࡣࡪࡩࠬࠪ"):message,Wkl7xOf63GPnVhdYE2ac0riMF18NDZ(u"ࠬࡲ࡯ࡨࡨ࡬ࡰࡪ࠭ࠫ"):b71qT8F3OoXEUtKjmNlLGvZphsCu}
	D8T1n2rIpPFHqBx0GdEmOUit64KJCy = UnqwOyV5tC2(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯࡬ࡱࡧ࡭ࡪࡳࡡࡥ࠰ࡹࡩࡷࡩࡥ࡭࠰ࡤࡴࡵ࠵ࡳࡦࡰࡧࡩࡲࡧࡩ࡭ࠩࠬ")
	J25NFvOw6dHKhgskY1 = l8Yqnzf0PTNusmxi15WR7bD.request(pBAbC3eLGcXghFI9KSMo(u"ࠧࡑࡑࡖࡘࠬ࠭"),D8T1n2rIpPFHqBx0GdEmOUit64KJCy,data=VqilRgFQ7xU3Je9Zz5v62ka4tH)
	if J25NFvOw6dHKhgskY1.status_code==Ovd7GgHCDba(u"࠷࠶࠰ࢰ"): zLSmNK08YVFt(JDWy8bwVMaCTr12deSxuHmvsF3,JDWy8bwVMaCTr12deSxuHmvsF3,JDWy8bwVMaCTr12deSxuHmvsF3,nekdqf82zYhWDHwBxjmiKlXSEv4O5(u"ࠨฮํำࠥ࠴࠮่ࠡฯัฯูࠦๆๆํอࠥหัิษ็ࠤุาไࠡษ็วำ฽วยࠩ࠮"))
	else: zLSmNK08YVFt(JDWy8bwVMaCTr12deSxuHmvsF3,JDWy8bwVMaCTr12deSxuHmvsF3,JDWy8bwVMaCTr12deSxuHmvsF3,vl4nJBZQaMposrSwKExOyF(u"ࠩ็่ศูแࠡ࠰࠱ࠤๆฺไหࠢ฼้้๐ษࠡวิืฬ๊ࠠิฮ็ࠤฬ๊รฯูสลࠬ࠯"))
	return
def Ayv5pmD6738l0g():
	ii3bPVFUcgXfY = oPSeZwkEVFRWrDzNMjJgcB5t(JDWy8bwVMaCTr12deSxuHmvsF3,JDWy8bwVMaCTr12deSxuHmvsF3,JDWy8bwVMaCTr12deSxuHmvsF3,JDWy8bwVMaCTr12deSxuHmvsF3,UnqwOyV5tC2(u"้้ࠪ็ࠠฦ฻าหิอสࠡษ็ฬึ์วๆฮࠣ๎าะ่๋ࠢ฼่๎ࠦๅฺๆ๋้ฬะࠠหะุࠤฯำฯ๋อࠣห้ฮั็ษ่ะࠥ๎ส็ฺํ้ࠥ฿ๅๅࠢส่อืๆศ็ฯࠤ࠳࠴ฺ่ࠠาࠤู๊อ้ࠡำหࠥอไๆๆไࠤุ๐โ้็ࠣห้ฮั็ษ่ะࠥฮฮๅไ้้ࠣ็ࠠอัํำࠥ็วา฼ࠣ࠲࠳ࠦ็ๅࠢอี๏ีࠠศๆล๊๋ࠥำฮ่่ࠢๆࠦลฺัสำฬะࠠศๆหี๋อๅอࠢยࠥࠬ࠰"))
	if ii3bPVFUcgXfY!=IIYvtpudBF(u"࠷ࢱ"): return
	haCFWUNxVErAMPnj8b7Smzq42B = EYQdyWbBaOZe4q2gjIolm(fS7rzReEvpxNl6HYXTjuZI4na,PtWvHo63XmwqN472r5QaxTJCSVyDAK(u"ࡌࡡ࡭ࡵࡨࣆ"))
	if haCFWUNxVErAMPnj8b7Smzq42B: zLSmNK08YVFt(JDWy8bwVMaCTr12deSxuHmvsF3,JDWy8bwVMaCTr12deSxuHmvsF3,JDWy8bwVMaCTr12deSxuHmvsF3,QFLni0mkUMtHPKy(u"ࠫั๐ฯࠡ࠰࠱ࠤ๋าอหࠢ฼้้๐ษࠡ็ึั๋ࠥไโࠢศ฽ิอฯศฬࠣฬึ์วๆฮࠣ฽๊อฯࠡๆ็ๅ๏ี๊้้สฮࠥอไฺำห๎ฮ࠭࠱"))
	else: zLSmNK08YVFt(JDWy8bwVMaCTr12deSxuHmvsF3,JDWy8bwVMaCTr12deSxuHmvsF3,JDWy8bwVMaCTr12deSxuHmvsF3,UnqwOyV5tC2(u"๊ࠬไฤีไࠤ࠳࠴ࠠโึ็ฮࠥ฿ๅๅ์ฬࠤู๊อࠡ็็ๅࠥหูะษาหฯࠦศา่ส้ัูࠦๆษาࠤ้๊แ๋ัํ์์อสࠡษ็฽ึฮ๊สࠩ࠲"))
	return
def kmV9eqaE01CMNLzirA5YJxWQ2():
	ii3bPVFUcgXfY = oPSeZwkEVFRWrDzNMjJgcB5t(JDWy8bwVMaCTr12deSxuHmvsF3,JDWy8bwVMaCTr12deSxuHmvsF3,JDWy8bwVMaCTr12deSxuHmvsF3,JDWy8bwVMaCTr12deSxuHmvsF3,cWLX7oZjbzguAsaDKY2HfO(u"࠭ๅอๆาࠤ่อิࠡษ็ฬึ์วๆฮࠣ๎าะ่๋ࠢ฼่๎ࠦๅๅใสฮࠥะฮึࠢอ๊฽๐ๅࠡ฻่่ࠥอไษำ้ห๊าࠠๆอ็ࠤ๊๊แศฬࠣห้๋แืๆฬࠤํ๋ไโษอࠤࡎࡖࡔࡗ๋ࠢࠤࡒ࠹ࡕุ๊ࠡ์ึࠦวๅไ๋หห๋ࠠ࠯࠰ࠣ฽๋ีࠠๆีะࠤ์ึวࠡษ็้ั๊ฯࠡีํๆํ๋ࠠศๆหี๋อๅอࠢหา้่ࠠๆฮ็ำࠥาฯ๋ัࠣๅฬืฺࠡ࠰࠱ࠤ์๊ࠠหำํำࠥอไรุ่้ࠣำࠠๆฮ็ำ้ࠥวีࠢส่อืๆศ็ฯࠤฤࠧࠧ࠳"))
	if ii3bPVFUcgXfY!=HGANbdw4xPSyWJCBYzT(u"࠱ࢲ"): return
	haCFWUNxVErAMPnj8b7Smzq42B = DDV5NjWFlnf4w1d7bLIphaZJ(MxhPqikLGbRjulp,djKXw1lcMEgtou0Skma(u"ࡕࡴࡸࡩࣈ"),djKXw1lcMEgtou0Skma(u"ࡕࡴࡸࡩࣈ"),WPvoul2AhyacUiJrFwCjMezk(u"ࡆࡢ࡮ࡶࡩࣇ"))
	if haCFWUNxVErAMPnj8b7Smzq42B: zLSmNK08YVFt(JDWy8bwVMaCTr12deSxuHmvsF3,JDWy8bwVMaCTr12deSxuHmvsF3,JDWy8bwVMaCTr12deSxuHmvsF3,PtWvHo63XmwqN472r5QaxTJCSVyDAK(u"ࠧอ์าࠤ࠳࠴ࠠ็ฮะฮࠥ฿ๅๅ์ฬࠤู๊อࠡ็ฯ่ิࠦใศึࠣห้ฮั็ษ่ะࠬ࠴"))
	else: zLSmNK08YVFt(JDWy8bwVMaCTr12deSxuHmvsF3,JDWy8bwVMaCTr12deSxuHmvsF3,JDWy8bwVMaCTr12deSxuHmvsF3,R0GqN43CuTkIsXgdfoeKhxL(u"ࠨๆ็วุ็ࠠ࠯࠰ࠣๅู๊สࠡ฻่่๏ฯࠠๆีะࠤ๊าไะࠢๆหูࠦวๅสิ๊ฬ๋ฬࠨ࠵"))
	return
def EYQdyWbBaOZe4q2gjIolm(eetC2KVwYi38QvpTqZbdWcmRG,FUsIjX57Hf3Gcx9i1l0YK):
	haCFWUNxVErAMPnj8b7Smzq42B = Wkl7xOf63GPnVhdYE2ac0riMF18NDZ(u"ࡖࡵࡹࡪࣉ")
	if FUsIjX57Hf3Gcx9i1l0YK:
		ii3bPVFUcgXfY = oPSeZwkEVFRWrDzNMjJgcB5t(JDWy8bwVMaCTr12deSxuHmvsF3,JDWy8bwVMaCTr12deSxuHmvsF3,JDWy8bwVMaCTr12deSxuHmvsF3,JDWy8bwVMaCTr12deSxuHmvsF3,djKXw1lcMEgtou0Skma(u"่่ࠩๆࠦลฺัสำฬะࠠศๆหี๋อๅอࠢํัฯ๎๊ࠡ฻็ํู๋ࠥๅ๊่หฯࠦสฯืࠣฮาี๊ฬࠢส่อืๆศ็ฯࠤํะๆู์่ࠤ฾๋ไࠡษ็ฬึ์วๆฮࠣ࠲࠳ูࠦ็ัุ้ࠣำ่ࠠาสࠤฬ๊ๅๅใࠣื๏่่ๆࠢส่อืๆศ็ฯࠤอิไใ่่ࠢๆࠦฬะ์าࠤๆอั฻ࠢ࠱࠲ࠥํไࠡฬิ๎ิࠦวๅฤ้ࠤู๊อࠡ็็ๅࠥหูะษาหฯࠦวๅสิ๊ฬ๋ฬࠡมࠤࠫ࠶"))
		if ii3bPVFUcgXfY!=cWLX7oZjbzguAsaDKY2HfO(u"࠲ࢳ"): return
	if hTuX1lqNoK5vWGmjPrzE8Uc9HQ.path.exists(eetC2KVwYi38QvpTqZbdWcmRG):
		try: hTuX1lqNoK5vWGmjPrzE8Uc9HQ.remove(eetC2KVwYi38QvpTqZbdWcmRG)
		except Exception as ggP513wLrHI:
			haCFWUNxVErAMPnj8b7Smzq42B = pBAbC3eLGcXghFI9KSMo(u"ࡉࡥࡱࡹࡥ࣊")
			if FUsIjX57Hf3Gcx9i1l0YK: zLSmNK08YVFt(JDWy8bwVMaCTr12deSxuHmvsF3,JDWy8bwVMaCTr12deSxuHmvsF3,JDWy8bwVMaCTr12deSxuHmvsF3,str(ggP513wLrHI))
	if FUsIjX57Hf3Gcx9i1l0YK:
		if haCFWUNxVErAMPnj8b7Smzq42B: zLSmNK08YVFt(JDWy8bwVMaCTr12deSxuHmvsF3,JDWy8bwVMaCTr12deSxuHmvsF3,JDWy8bwVMaCTr12deSxuHmvsF3,p6GDqY5K0mWwyb(u"ࠪะ๏ีࠠ࠯࠰๊ࠣัำสࠡ฻่่๏ฯࠠศๆ่ืา࠭࠷"))
		else: zLSmNK08YVFt(JDWy8bwVMaCTr12deSxuHmvsF3,JDWy8bwVMaCTr12deSxuHmvsF3,JDWy8bwVMaCTr12deSxuHmvsF3,R0GqN43CuTkIsXgdfoeKhxL(u"้๊ࠫริใࠣ࠲࠳ࠦแีๆอࠤ฾๋ไ๋หࠣห้๋ำฮࠩ࠸"))
	return haCFWUNxVErAMPnj8b7Smzq42B
def DDV5NjWFlnf4w1d7bLIphaZJ(wwZdQKGB8IDLRekixW,NEkHsACiyJXVb,raMcHSGJ0VKOIX,FUsIjX57Hf3Gcx9i1l0YK):
	haCFWUNxVErAMPnj8b7Smzq42B = dYqLj0iTxu3Xbp9kRMv(u"ࡘࡷࡻࡥ࣋")
	if FUsIjX57Hf3Gcx9i1l0YK:
		ii3bPVFUcgXfY = oPSeZwkEVFRWrDzNMjJgcB5t(JDWy8bwVMaCTr12deSxuHmvsF3,JDWy8bwVMaCTr12deSxuHmvsF3,JDWy8bwVMaCTr12deSxuHmvsF3,JDWy8bwVMaCTr12deSxuHmvsF3,wwZdQKGB8IDLRekixW+HGANbdw4xPSyWJCBYzT(u"ࠬࡢ࡮࡝ࡰ๊่ࠥะั๋ัุ้ࠣำ่ࠠาสࠤฬ๊ๅอๆาࠤฤࠧࠧ࠹"))
		if ii3bPVFUcgXfY!=QFLni0mkUMtHPKy(u"࠳ࢴ"): return
	if hTuX1lqNoK5vWGmjPrzE8Uc9HQ.path.exists(wwZdQKGB8IDLRekixW):
		for JNIkjTpKUF,RIPODe4MxUd9k3LKjZwuCiWYnNQ,vy7iphT8X2LISYsdGPB54RQ6FH3n in hTuX1lqNoK5vWGmjPrzE8Uc9HQ.walk(wwZdQKGB8IDLRekixW,topdown=Wg792AJqnwz8moOTZ5(u"ࡋࡧ࡬ࡴࡧ࣌")):
			for WoXvm2tIpl in vy7iphT8X2LISYsdGPB54RQ6FH3n:
				BuG9mZEbV1piKg = hTuX1lqNoK5vWGmjPrzE8Uc9HQ.path.join(JNIkjTpKUF,WoXvm2tIpl)
				try: hTuX1lqNoK5vWGmjPrzE8Uc9HQ.remove(BuG9mZEbV1piKg)
				except Exception as ggP513wLrHI:
					haCFWUNxVErAMPnj8b7Smzq42B = wJaK1lpHiUF4yWgmROf(u"ࡌࡡ࡭ࡵࡨ࣍")
					if FUsIjX57Hf3Gcx9i1l0YK: zLSmNK08YVFt(JDWy8bwVMaCTr12deSxuHmvsF3,JDWy8bwVMaCTr12deSxuHmvsF3,JDWy8bwVMaCTr12deSxuHmvsF3,str(ggP513wLrHI))
			if NEkHsACiyJXVb:
				for p9j3WoBFlcnz1I8S2e in RIPODe4MxUd9k3LKjZwuCiWYnNQ:
					FLklRdgcxn72JtGzImM8pHVySuhA = hTuX1lqNoK5vWGmjPrzE8Uc9HQ.path.join(JNIkjTpKUF,p9j3WoBFlcnz1I8S2e)
					try: hTuX1lqNoK5vWGmjPrzE8Uc9HQ.rmdir(FLklRdgcxn72JtGzImM8pHVySuhA)
					except: pass
		if raMcHSGJ0VKOIX:
			try: hTuX1lqNoK5vWGmjPrzE8Uc9HQ.rmdir(JNIkjTpKUF)
			except: pass
	if FUsIjX57Hf3Gcx9i1l0YK:
		if haCFWUNxVErAMPnj8b7Smzq42B: zLSmNK08YVFt(JDWy8bwVMaCTr12deSxuHmvsF3,JDWy8bwVMaCTr12deSxuHmvsF3,JDWy8bwVMaCTr12deSxuHmvsF3,pBAbC3eLGcXghFI9KSMo(u"࠭ฬ๋ัࠣ࠲࠳ࠦๆอฯอࠤ฾๋ไ๋หࠣห้๋ำฮࠩ࠺"))
		else: zLSmNK08YVFt(JDWy8bwVMaCTr12deSxuHmvsF3,JDWy8bwVMaCTr12deSxuHmvsF3,JDWy8bwVMaCTr12deSxuHmvsF3,mLS1NZKPri0aM9DYBXyVFwe(u"ࠧๅๆฦืๆࠦ࠮࠯ࠢไุ้ะฺࠠ็็๎ฮࠦวๅ็ึัࠬ࠻"))
	return haCFWUNxVErAMPnj8b7Smzq42B
def SO1ePbaVRzEl8rk2ocBsXv35IW():
	ii3bPVFUcgXfY = oPSeZwkEVFRWrDzNMjJgcB5t(JDWy8bwVMaCTr12deSxuHmvsF3,JDWy8bwVMaCTr12deSxuHmvsF3,JDWy8bwVMaCTr12deSxuHmvsF3,JDWy8bwVMaCTr12deSxuHmvsF3,WPvoul2AhyacUiJrFwCjMezk(u"ࠨ็ฯ่ิࠦี้ำࠣ็ฯอศสࠢส่็๎วว็ࠣ࠲࠳ࠦ็ัษࠣห้๋ฬๅัࠣๅ๏ํࠠษ฻ูࠤ็๎วว็ࠣห้ฮั็ษ่ะ๋ࠥฮำ่ฬࠤอฺใๅุࠢ์ึࠦศะๆสࠤ๊์ࠠศๆๆฮฬฮษࠡ࠰࠱ࠤ฾์ฯࠡ็ึัࠥอไๆฮ็ำู๊ࠥใ๊่ࠤฬ๊ศา่ส้ัࠦศฯๆๅࠤ๊าไะࠢฯำ๏ี้ࠠ์หำศࠦๅาหࠣวำื้ࠡส่่หํࠠษษ็ูํืฺ่ࠠาࠤๆะอࠡษ็ๆํอฦๆࠢ࠱࠲ࠥํไࠡฬิ๎ิࠦวๅฤ้ࠤู๊อࠡ็ฯ่ิࠦี้ำࠣ็ฯอศสࠢๅ์ฬฬๅࠡษ็ฬึ์วๆฮࠣรࠦ࠭࠼"))
	if ii3bPVFUcgXfY!=HGANbdw4xPSyWJCBYzT(u"࠴ࢵ"): return
	haCFWUNxVErAMPnj8b7Smzq42B = DDV5NjWFlnf4w1d7bLIphaZJ(KfVTg5QmIcxndZvq,P7XtS5p1ElTkWDJZ(u"ࡕࡴࡸࡩ࣏"),Wkl7xOf63GPnVhdYE2ac0riMF18NDZ(u"ࡆࡢ࡮ࡶࡩ࣎"),P7XtS5p1ElTkWDJZ(u"ࡕࡴࡸࡩ࣏"))
	if haCFWUNxVErAMPnj8b7Smzq42B: zLSmNK08YVFt(JDWy8bwVMaCTr12deSxuHmvsF3,JDWy8bwVMaCTr12deSxuHmvsF3,JDWy8bwVMaCTr12deSxuHmvsF3,QFLni0mkUMtHPKy(u"ࠩฯ๎ิࠦ࠮࠯้ࠢะาะฺࠠ็็๎ฮࠦๅิฯ้ࠣั๊ฯࠡื๋ี้ࠥสศสฬࠤฬ๊โ้ษษ้ࠬ࠽"))
	else: zLSmNK08YVFt(JDWy8bwVMaCTr12deSxuHmvsF3,JDWy8bwVMaCTr12deSxuHmvsF3,JDWy8bwVMaCTr12deSxuHmvsF3,nekdqf82zYhWDHwBxjmiKlXSEv4O5(u"่้ࠪษำโࠢ࠱࠲ࠥ็ิๅฬࠣ฽๊๊๊ส่ࠢืาࠦๅอๆาࠤฺ๎ัࠡๅอหอฯࠠศๆๅ์ฬฬๅࠨ࠾"))
	return
def k2hOIXTquzVPB4wGtbf9d3Zvi():
	D8T1n2rIpPFHqBx0GdEmOUit64KJCy = uKX2cTFCewkW9djva5SR0Qis3(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡱ࡯ࡥ࡫ࡨࡱࡦࡪ࠮ࡴࡷࡵ࡫ࡪ࠴ࡳࡩ࠱࡮ࡳࡩ࡯࠯ࡦ࡯ࡤࡨࡤࡧࡲࡢࡤ࡬ࡧࡻ࡯ࡤࡦࡱࡶ࠳ࡴࡲࡤ࠰࡫ࡱࡨࡪࡾ࠮ࡩࡶࡰࡰࠬ࠿")
	J25NFvOw6dHKhgskY1 = l8Yqnzf0PTNusmxi15WR7bD.request(UnqwOyV5tC2(u"ࠬࡍࡅࡕࠩࡀ"),D8T1n2rIpPFHqBx0GdEmOUit64KJCy)
	dFlKAg28UoR4Jf = J25NFvOw6dHKhgskY1.content
	dFlKAg28UoR4Jf = dFlKAg28UoR4Jf.decode(ii5os2hUtM1Rj(u"࠭ࡵࡵࡨ࠻ࠫࡁ"))
	vy7iphT8X2LISYsdGPB54RQ6FH3n = SznexPKUa5CjXtVm29u.findall(zziCKgtI82GP1awehZ6RNSMY3F(u"ࠧࡩࡴࡨࡪࡂࠨࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳࠮࠮ࠫࡁࠬ࠲ࡿ࡯ࡰࠣࠩࡂ"),dFlKAg28UoR4Jf,SznexPKUa5CjXtVm29u.DOTALL)
	vy7iphT8X2LISYsdGPB54RQ6FH3n = sorted(vy7iphT8X2LISYsdGPB54RQ6FH3n,reverse=Wg792AJqnwz8moOTZ5(u"ࡖࡵࡹࡪ࣐"))
	hYl0HoNKE1vA6S283nct7LM45rxR = OOSE0PUYQDHrb2Z9vcqLghkzfAyWC.Dialog().select(NTpqJgmvS0a6huZY(u"ࠨษัฮึࠦวๅวุำฬืࠠศๆำ๎ࠥะั๋ัࠣฮะฮ๊ห้ࠪࡃ"),vy7iphT8X2LISYsdGPB54RQ6FH3n)
	if hYl0HoNKE1vA6S283nct7LM45rxR==-QFLni0mkUMtHPKy(u"࠵ࢶ"): return
	filename = vy7iphT8X2LISYsdGPB54RQ6FH3n[hYl0HoNKE1vA6S283nct7LM45rxR]
	if r9wPbk4AMEu1: filename = filename.encode(PtWvHo63XmwqN472r5QaxTJCSVyDAK(u"ࠩࡸࡸ࡫࠾ࠧࡄ"))
	wnZ2LOBRbSurUhCM0JiozNPGQTEsY6 = D8T1n2rIpPFHqBx0GdEmOUit64KJCy.rsplit(cWLX7oZjbzguAsaDKY2HfO(u"ࠪ࠳ࠬࡅ"),P7XtS5p1ElTkWDJZ(u"࠶ࢷ"))[pBAbC3eLGcXghFI9KSMo(u"࠶ࢸ")]+WPvoul2AhyacUiJrFwCjMezk(u"ࠫ࠴࠭ࡆ")+BBHpvyLIWArKzNmT05asfJn(u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࠬࡇ")+filename+p6GDqY5K0mWwyb(u"࠭࠮ࡻ࡫ࡳࠫࡈ")
	haCFWUNxVErAMPnj8b7Smzq42B = mLS1NZKPri0aM9DYBXyVFwe(u"ࡉࡥࡱࡹࡥ࣑")
	J25NFvOw6dHKhgskY1 = l8Yqnzf0PTNusmxi15WR7bD.request(P7XtS5p1ElTkWDJZ(u"ࠧࡈࡇࡗࠫࡉ"),wnZ2LOBRbSurUhCM0JiozNPGQTEsY6)
	if J25NFvOw6dHKhgskY1.status_code==BBHpvyLIWArKzNmT05asfJn(u"࠲࠱࠲ࢹ"):
		UN0Acil7QM2oKIaJkmv6j9OdLVW3Y = J25NFvOw6dHKhgskY1.content
		import zipfile as FQYSCoIJBajfHrlApbO6kTh7iGDxsc,io as kkCptriXfRydWF
		b9Pys7FTaG = kkCptriXfRydWF.BytesIO(UN0Acil7QM2oKIaJkmv6j9OdLVW3Y)
		DDV5NjWFlnf4w1d7bLIphaZJ(zqcm67DhF2ZIE4WRlK0XuYyOV,IIYvtpudBF(u"࡙ࡸࡵࡦ࣓"),IIYvtpudBF(u"࡙ࡸࡵࡦ࣓"),k4ASEqQL62gwtpoMDvWcn(u"ࡊࡦࡲࡳࡦ࣒"))
		ElUHd56Aspzfiu1IQmNj2awCK3kV = FQYSCoIJBajfHrlApbO6kTh7iGDxsc.ZipFile(b9Pys7FTaG)
		ElUHd56Aspzfiu1IQmNj2awCK3kV.extractall(C8CszeFRxQtrGWaYbJBZcH3AL456mo)
		F1k8UmJz5VTj6ptb4.sleep(g1qH4Xu9EhdlTASrnxyD6KVpP(u"࠲ࢺ"))
		MLG9yjuh7vx.executebuiltin(HGANbdw4xPSyWJCBYzT(u"ࠨࡗࡳࡨࡦࡺࡥࡍࡱࡦࡥࡱࡇࡤࡥࡱࡱࡷࠬࡊ"))
		F1k8UmJz5VTj6ptb4.sleep(uKX2cTFCewkW9djva5SR0Qis3(u"࠳ࢻ"))
		ftFCjXY7nWUsM2P9Z0u6RHeqGvrz5J = MLG9yjuh7vx.executeJSONRPC(HGANbdw4xPSyWJCBYzT(u"ࠩࡾࠦ࡯ࡹ࡯࡯ࡴࡳࡧࠧࡀࠢ࠳࠰࠳ࠦ࠱ࠨ࡭ࡦࡶ࡫ࡳࡩࠨ࠺ࠣࡃࡧࡨࡴࡴࡳ࠯ࡕࡨࡸࡆࡪࡤࡰࡰࡈࡲࡦࡨ࡬ࡦࡦࠥ࠰ࠧ࡯ࡤࠣ࠼࠴࠰ࠧࡶࡡࡳࡣࡰࡷࠧࡀࡻࠣࡣࡧࡨࡴࡴࡩࡥࠤ࠽ࠦࠬࡋ")+TOV6ItlaNjiADh1Lng2SWwc9PGvKXd+ii5os2hUtM1Rj(u"ࠪࠦ࠱ࠨࡥ࡯ࡣࡥࡰࡪࡪࠢ࠻ࡶࡵࡹࡪࢃࡽࠨࡌ"))
		if uKX2cTFCewkW9djva5SR0Qis3(u"ࠫࡔࡑࠧࡍ") in ftFCjXY7nWUsM2P9Z0u6RHeqGvrz5J: haCFWUNxVErAMPnj8b7Smzq42B = mLS1NZKPri0aM9DYBXyVFwe(u"࡚ࡲࡶࡧࣔ")
	if haCFWUNxVErAMPnj8b7Smzq42B:
		zLSmNK08YVFt(JDWy8bwVMaCTr12deSxuHmvsF3,JDWy8bwVMaCTr12deSxuHmvsF3,JDWy8bwVMaCTr12deSxuHmvsF3,dYDmO5JoywunX43WNrVSPGE(u"ࠬา๊ะࠢ࠱࠲ࠥ์ฬฮฬࠣ฽๊๊๊สࠢอฯอ๐สࠡษ็ษฺีวาࠢส่็ี๊ๆࠢ࡟ࡲࡡࡴࠠࠨࡎ")+filename)
		msg = cWLX7oZjbzguAsaDKY2HfO(u"࠭อห๋ࠣ๎อ่้ࠡษ็ษฺีวาࠢส่็ี๊ๆࠢไ๎ࠥา็ศิๆࠤํ๊วࠡ์อ้ࠥะอะ์ฮ๋ࠥษ่ห๊่หฯ๐ใ๋ษࠣ࠲࠳๊ࠦอสࠣว๋ࠦสใ๊่ࠤอห๊ใษไࠤฬ๊สฮัํฯࠥอไฤ๊อ์๊อส๋ๅํࠤ࠳࠴่ࠠๆࠣฮึ๐ฯࠡษ็ฦ๋ࠦล๋ไสๅࠥอไหฯา๎ะࠦวๅล๋ฮํ๋วห์ๆ๎๊ࠥไษำ้ห๊าࠠภࠣࠪࡏ")
		IsOyqpKe2Z43ToBE(msg)
	else: zLSmNK08YVFt(JDWy8bwVMaCTr12deSxuHmvsF3,JDWy8bwVMaCTr12deSxuHmvsF3,JDWy8bwVMaCTr12deSxuHmvsF3,pBAbC3eLGcXghFI9KSMo(u"ࠧๅๆฦืๆࠦ࠮࠯ࠢไุ้ะฺࠠ็็๎ฮࠦสฬสํฮࠥอไฦืาหึࠦวๅไา๎๊ࠦ࡜࡯࡞ࡱࠤࠬࡐ")+filename)
	return
def IsOyqpKe2Z43ToBE(msg=NTpqJgmvS0a6huZY(u"ࠨ้็ࠤฯื๊ะࠢอุ฿๐ไࠡล๋ࠤส๐โศใࠣห้ะอะ์ฮࠤฬ๊ร้ฬ๋้ฬะ๊ไ์่้ࠣฮั็ษ่ะࠥลࠡࠨࡑ")):
	ii3bPVFUcgXfY = oPSeZwkEVFRWrDzNMjJgcB5t(JDWy8bwVMaCTr12deSxuHmvsF3,p6GDqY5K0mWwyb(u"ࠩศ๎็อแࠡษ็ฮาี๊ฬࠩࡒ"),fh4wNp3Pye6b9LvIjx(u"ࠪฮาี๊ฬࠢฦ์ฯ๎ๅศฬํ็๏࠭ࡓ"),JDWy8bwVMaCTr12deSxuHmvsF3,msg)
	if ii3bPVFUcgXfY==-g1qH4Xu9EhdlTASrnxyD6KVpP(u"࠴ࢼ"): return
	Wgjswute3dYXkcNEv79irz = BBHpvyLIWArKzNmT05asfJn(u"ࠫࡪࡴࡡࡣ࡮ࡨࠫࡔ") if ii3bPVFUcgXfY else UnqwOyV5tC2(u"ࠬࡪࡩࡴࡣࡥࡰࡪ࠭ࡕ")
	haCFWUNxVErAMPnj8b7Smzq42B = NTpqJgmvS0a6huZY(u"ࡆࡢ࡮ࡶࡩࣕ")
	BFUKNu0Sn8pbP = ii5os2hUtM1Rj(u"࠭ࡲࡦࡲࡲࡷ࡮ࡺ࡯ࡳࡻ࠱ࡩࡲࡧࡤࠨࡖ")
	e5HcJCDgqLNIB04E6hmvZQAjpy = vl4nJBZQaMposrSwKExOyF(u"ࠧࡣ࡮ࡤࡧࡰࡲࡩࡴࡶࠪࡗ") if r9wPbk4AMEu1 else HGANbdw4xPSyWJCBYzT(u"ࠨࡷࡳࡨࡦࡺࡥࡠࡴࡸࡰࡪࡹࠧࡘ")
	try:
		import sqlite3 as VC2eX6hvBzHGcPlA5tEpfIyNmD9QjF
		OJ2DScP4hKHXC3pZNEQ5 = VC2eX6hvBzHGcPlA5tEpfIyNmD9QjF.connect(OQkwEso9rZ0YB)
		OJ2DScP4hKHXC3pZNEQ5.text_factory = str
		aSrDiNtbRkT6qfGF08gHIWC = OJ2DScP4hKHXC3pZNEQ5.cursor()
		aSrDiNtbRkT6qfGF08gHIWC.execute(fh4wNp3Pye6b9LvIjx(u"ࠩࡖࡉࡑࡋࡃࡕࠢࡲࡶ࡮࡭ࡩ࡯ࠢࡉࡖࡔࡓࠠࡪࡰࡶࡸࡦࡲ࡬ࡦࡦ࡛ࠣࡍࡋࡒࡆࠢࡤࡨࡩࡵ࡮ࡊࡆࠣࡁࠥࠨ࡙ࠧ")+TOV6ItlaNjiADh1Lng2SWwc9PGvKXd+R0GqN43CuTkIsXgdfoeKhxL(u"ࠪࠦࠥࡁ࡚ࠧ"))
		d3uLBDwQGoyPhsj1mZnTIE = aSrDiNtbRkT6qfGF08gHIWC.fetchall()
		if d3uLBDwQGoyPhsj1mZnTIE and BFUKNu0Sn8pbP not in str(d3uLBDwQGoyPhsj1mZnTIE): aSrDiNtbRkT6qfGF08gHIWC.execute(ii5os2hUtM1Rj(u"࡚ࠫࡖࡄࡂࡖࡈࠤ࡮ࡴࡳࡵࡣ࡯ࡰࡪࡪࠠࡔࡇࡗࠤࡴࡸࡩࡨ࡫ࡱࠤࡂࠦࠢࠨ࡛")+BFUKNu0Sn8pbP+g1qH4Xu9EhdlTASrnxyD6KVpP(u"ࠬࠨࠠࡘࡊࡈࡖࡊࠦࡡࡥࡦࡲࡲࡎࡊࠠ࠾ࠢࠥࠫ࡜")+TOV6ItlaNjiADh1Lng2SWwc9PGvKXd+ueWGTXL5PRAoB8t7(u"࠭ࠢࠡ࠽ࠪ࡝"))
		aSrDiNtbRkT6qfGF08gHIWC.execute(g1qH4Xu9EhdlTASrnxyD6KVpP(u"ࠧࡔࡇࡏࡉࡈ࡚ࠠࠫࠢࡉࡖࡔࡓࠠࠨ࡞")+e5HcJCDgqLNIB04E6hmvZQAjpy+Wg792AJqnwz8moOTZ5(u"ࠨ࡚ࠢࡌࡊࡘࡅࠡࡣࡧࡨࡴࡴࡉࡅࠢࡀࠤࠧ࠭࡟")+TOV6ItlaNjiADh1Lng2SWwc9PGvKXd+ZaiujwYhQ634qN7SRg(u"ࠩࠥࠤࡀ࠭ࡠ"))
		d3uLBDwQGoyPhsj1mZnTIE = aSrDiNtbRkT6qfGF08gHIWC.fetchall()
		GbAgKE8MLsypq71WR0XFwztP6rUv2I = zziCKgtI82GP1awehZ6RNSMY3F(u"ࡈࡤࡰࡸ࡫ࣗ") if d3uLBDwQGoyPhsj1mZnTIE else djKXw1lcMEgtou0Skma(u"ࡕࡴࡸࡩࣖ")
		if not GbAgKE8MLsypq71WR0XFwztP6rUv2I and ZaiujwYhQ634qN7SRg(u"ࠪࡩࡳࡧࡢ࡭ࡧࠪࡡ") in Wgjswute3dYXkcNEv79irz: aSrDiNtbRkT6qfGF08gHIWC.execute(WPvoul2AhyacUiJrFwCjMezk(u"ࠫࡉࡋࡌࡆࡖࡈࠤࡋࡘࡏࡎࠢࠪࡢ")+e5HcJCDgqLNIB04E6hmvZQAjpy+Wg792AJqnwz8moOTZ5(u"ࠬࠦࡗࡉࡇࡕࡉࠥࡧࡤࡥࡱࡱࡍࡉࠦ࠽ࠡࠤࠪࡣ")+TOV6ItlaNjiADh1Lng2SWwc9PGvKXd+mLS1NZKPri0aM9DYBXyVFwe(u"࠭ࠢࠡ࠽ࠪࡤ"))
		elif GbAgKE8MLsypq71WR0XFwztP6rUv2I and ZaiujwYhQ634qN7SRg(u"ࠧࡥ࡫ࡶࡥࡧࡲࡥࠨࡥ") in Wgjswute3dYXkcNEv79irz:
			if r9wPbk4AMEu1: aSrDiNtbRkT6qfGF08gHIWC.execute(uKX2cTFCewkW9djva5SR0Qis3(u"ࠨࡋࡑࡗࡊࡘࡔࠡࡋࡑࡘࡔࠦࠧࡦ")+e5HcJCDgqLNIB04E6hmvZQAjpy+wJaK1lpHiUF4yWgmROf(u"ࠩࠣࠬࡦࡪࡤࡰࡰࡌࡈ࠮ࠦࡖࡂࡎࡘࡉࡘࠦࠨࠣࠩࡧ")+TOV6ItlaNjiADh1Lng2SWwc9PGvKXd+vl4nJBZQaMposrSwKExOyF(u"ࠪࠦ࠮ࠦ࠻ࠨࡨ"))
			else: aSrDiNtbRkT6qfGF08gHIWC.execute(uKX2cTFCewkW9djva5SR0Qis3(u"ࠫࡎࡔࡓࡆࡔࡗࠤࡎࡔࡔࡐࠢࠪࡩ")+e5HcJCDgqLNIB04E6hmvZQAjpy+wJaK1lpHiUF4yWgmROf(u"ࠬࠦࠨࡢࡦࡧࡳࡳࡏࡄ࠭ࡷࡳࡨࡦࡺࡥࡓࡷ࡯ࡩ࠮ࠦࡖࡂࡎࡘࡉࡘࠦࠨࠣࠩࡪ")+TOV6ItlaNjiADh1Lng2SWwc9PGvKXd+vl4nJBZQaMposrSwKExOyF(u"࠭ࠢ࠭࠳ࠬࠤࡀ࠭࡫"))
		OJ2DScP4hKHXC3pZNEQ5.commit()
		OJ2DScP4hKHXC3pZNEQ5.close()
		haCFWUNxVErAMPnj8b7Smzq42B = t3tIngkbNWG(u"ࡗࡶࡺ࡫ࣘ")
	except: pass
	if haCFWUNxVErAMPnj8b7Smzq42B:
		F1k8UmJz5VTj6ptb4.sleep(R0GqN43CuTkIsXgdfoeKhxL(u"࠵ࢽ"))
		MLG9yjuh7vx.executebuiltin(HGANbdw4xPSyWJCBYzT(u"ࠧࡖࡲࡧࡥࡹ࡫ࡌࡰࡥࡤࡰࡆࡪࡤࡰࡰࡶࠫ࡬"))
		F1k8UmJz5VTj6ptb4.sleep(BBHpvyLIWArKzNmT05asfJn(u"࠶ࢾ"))
		zLSmNK08YVFt(JDWy8bwVMaCTr12deSxuHmvsF3,JDWy8bwVMaCTr12deSxuHmvsF3,JDWy8bwVMaCTr12deSxuHmvsF3,nekdqf82zYhWDHwBxjmiKlXSEv4O5(u"ࠨฮํำࠥ࠴࠮่ࠡฯัฯࠦวๅ฻่่๏ฯࠧ࡭"))
	else: zLSmNK08YVFt(JDWy8bwVMaCTr12deSxuHmvsF3,JDWy8bwVMaCTr12deSxuHmvsF3,JDWy8bwVMaCTr12deSxuHmvsF3,ZaiujwYhQ634qN7SRg(u"ࠩ็่ศูแࠡ࠰࠱ࠤๆฺไหࠢส่฾๋ไ๋หࠪ࡮"))
	return
def MMBwJRVkxmUDnSa():
	ii3bPVFUcgXfY = oPSeZwkEVFRWrDzNMjJgcB5t(JDWy8bwVMaCTr12deSxuHmvsF3,JDWy8bwVMaCTr12deSxuHmvsF3,JDWy8bwVMaCTr12deSxuHmvsF3,JDWy8bwVMaCTr12deSxuHmvsF3,Wg792AJqnwz8moOTZ5(u"ࠪ฽๊๊๊สࠢอ๊฽๐แࠡๅ๋ำ๏ࠦสห็ࠣฬู๊อࠡษ็้้็วหࠢส่็ี๊ๆหࠣห้๋ฤใฬฬࠤฬ๊ส๋่ࠢฮัู๋สࠢไ๎๋ࠥฬๅัสฮࠥ๎ๅๅใสฮ้่ࠥะ์ࠣ࠲࠳ࠦ็ๅࠢอี๏ีࠠห่฻๎ๆࠦใ้ัํࠤฬ๊ย็ࠢยࠥࠬ࡯"))
	if ii3bPVFUcgXfY!=dYqLj0iTxu3Xbp9kRMv(u"࠷ࢿ"): return
	WWzdrXbQEx6F2OoucS = DDV5NjWFlnf4w1d7bLIphaZJ(pO4eVSUvY5uQfW1w9lD,UnqwOyV5tC2(u"࡙ࡸࡵࡦࣚ"),PtWvHo63XmwqN472r5QaxTJCSVyDAK(u"ࡊࡦࡲࡳࡦࣙ"),PtWvHo63XmwqN472r5QaxTJCSVyDAK(u"ࡊࡦࡲࡳࡦࣙ"))
	aa3IXf6ukEN4iS1lOBzYQxVM0g = DDV5NjWFlnf4w1d7bLIphaZJ(xxighLX9zeH2AB,cWLX7oZjbzguAsaDKY2HfO(u"ࡔࡳࡷࡨࣜ"),P7XtS5p1ElTkWDJZ(u"ࡌࡡ࡭ࡵࡨࣛ"),P7XtS5p1ElTkWDJZ(u"ࡌࡡ࡭ࡵࡨࣛ"))
	RMqihNZ8W5d2GDgBI1Hfj = DDV5NjWFlnf4w1d7bLIphaZJ(PwmkLzrj1CnGl,dYDmO5JoywunX43WNrVSPGE(u"ࡖࡵࡹࡪࣞ"),zziCKgtI82GP1awehZ6RNSMY3F(u"ࡇࡣ࡯ࡷࡪࣝ"),zziCKgtI82GP1awehZ6RNSMY3F(u"ࡇࡣ࡯ࡷࡪࣝ"))
	d7mCEJI163Ng = q2MdNliZk0CJUu(k4ASEqQL62gwtpoMDvWcn(u"ࡗࡶࡺ࡫ࣟ"))
	AB9GD6ayWq0rlXbLjsV = wZOlMzJD2VjsA6LmY4gay3nI1hd()
	haCFWUNxVErAMPnj8b7Smzq42B = all([WWzdrXbQEx6F2OoucS,aa3IXf6ukEN4iS1lOBzYQxVM0g,RMqihNZ8W5d2GDgBI1Hfj,d7mCEJI163Ng,AB9GD6ayWq0rlXbLjsV])
	if haCFWUNxVErAMPnj8b7Smzq42B: zLSmNK08YVFt(JDWy8bwVMaCTr12deSxuHmvsF3,JDWy8bwVMaCTr12deSxuHmvsF3,JDWy8bwVMaCTr12deSxuHmvsF3,t3tIngkbNWG(u"ࠫั๐ฯࠡ࠰࠱ࠤ๋าอหࠢ฼้้๐ษࠡฬ้฼๏็ࠠไ๊า๎ࠬࡰ"))
	else: zLSmNK08YVFt(JDWy8bwVMaCTr12deSxuHmvsF3,JDWy8bwVMaCTr12deSxuHmvsF3,JDWy8bwVMaCTr12deSxuHmvsF3,WPvoul2AhyacUiJrFwCjMezk(u"๊ࠬไฤีไࠤ࠳࠴ࠠโึ็ฮࠥ฿ๅๅ์ฬࠤฯ์ุ๋ใࠣ็ํี๊ࠨࡱ"))
	return
def cRSZCPqrsKjHF78fNQlobyEkD1wtig():
	ii3bPVFUcgXfY = oPSeZwkEVFRWrDzNMjJgcB5t(JDWy8bwVMaCTr12deSxuHmvsF3,JDWy8bwVMaCTr12deSxuHmvsF3,JDWy8bwVMaCTr12deSxuHmvsF3,JDWy8bwVMaCTr12deSxuHmvsF3,g1qH4Xu9EhdlTASrnxyD6KVpP(u"ู࠭ๆๆํอࠥะๆู์ไࠤฬ๊ฬ่ษีࠤฯะๅࠡส่ืาࠦวๅ็็ๅฬะࠠศๆๅำ๏๋ษࠡษ็้ษ่สสࠢส่ฯ๐ࠠๆฬฯ้฾ฯࠠโ์๊ࠣ฽อๅࠡฬื฾๏๊ࠠศๆฯ๋ฬุࠠ࠯࠰๋้ࠣࠦสา์าࠤฯ์ุ๋ใࠣห้า็ศิࠣห้ศๆࠡมࠤࠫࡲ"))
	if ii3bPVFUcgXfY!=ii5os2hUtM1Rj(u"࠱ࣀ"): return
	qqF0QsUb975AdHafuIgkyGLVDZ = wJaK1lpHiUF4yWgmROf(u"ࠧ࠰ࡦࡤࡸࡦ࠵ࡳࡺࡵࡷࡩࡲ࠵ࡵࡴࡣࡪࡩࡸࡺࡡࡵࡵࠪࡳ")
	kNseLWEvSbzOfIM36nqFTm = zziCKgtI82GP1awehZ6RNSMY3F(u"ࠨ࠱ࡧࡥࡹࡧ࠯ࡴࡻࡶࡸࡪࡳ࠯ࡥࡴࡲࡴࡧࡵࡸࠨࡴ")
	yvZ4qaKVpxBX = fh4wNp3Pye6b9LvIjx(u"ࠩ࠲ࡨࡦࡺࡡ࠰ࡶࡲࡱࡧࡹࡴࡰࡰࡨࡷࠬࡵ")
	IZtkifU0drbql9y = HGANbdw4xPSyWJCBYzT(u"ࠪ࠳ࡩࡧࡴࡢ࠱࡯ࡳ࡬࡭ࡥࡳࠩࡶ")
	MteLX4FmQHBRTV8aZr2A = ueWGTXL5PRAoB8t7(u"ࠫ࠴ࡪࡡࡵࡣ࠲ࡰࡴ࡭ࠧࡷ")
	Eqxt3fKMzr1vbHJBghURl9Fe = g1qH4Xu9EhdlTASrnxyD6KVpP(u"ࠬ࠵ࡤࡢࡶࡤ࠳ࡦࡴࡲࠨࡸ")
	WWzdrXbQEx6F2OoucS = DDV5NjWFlnf4w1d7bLIphaZJ(qqF0QsUb975AdHafuIgkyGLVDZ,P7XtS5p1ElTkWDJZ(u"࡙ࡸࡵࡦ࣡"),QFLni0mkUMtHPKy(u"ࡊࡦࡲࡳࡦ࣠"),QFLni0mkUMtHPKy(u"ࡊࡦࡲࡳࡦ࣠"))
	aa3IXf6ukEN4iS1lOBzYQxVM0g = DDV5NjWFlnf4w1d7bLIphaZJ(kNseLWEvSbzOfIM36nqFTm,UnqwOyV5tC2(u"ࡔࡳࡷࡨࣣ"),vl4nJBZQaMposrSwKExOyF(u"ࡌࡡ࡭ࡵࡨ࣢"),vl4nJBZQaMposrSwKExOyF(u"ࡌࡡ࡭ࡵࡨ࣢"))
	RMqihNZ8W5d2GDgBI1Hfj = DDV5NjWFlnf4w1d7bLIphaZJ(yvZ4qaKVpxBX,ii5os2hUtM1Rj(u"ࡖࡵࡹࡪࣥ"),mLS1NZKPri0aM9DYBXyVFwe(u"ࡇࡣ࡯ࡷࡪࣤ"),mLS1NZKPri0aM9DYBXyVFwe(u"ࡇࡣ࡯ࡷࡪࣤ"))
	d7mCEJI163Ng = DDV5NjWFlnf4w1d7bLIphaZJ(IZtkifU0drbql9y,djKXw1lcMEgtou0Skma(u"ࡘࡷࡻࡥࣧ"),Wkl7xOf63GPnVhdYE2ac0riMF18NDZ(u"ࡉࡥࡱࡹࡥࣦ"),Wkl7xOf63GPnVhdYE2ac0riMF18NDZ(u"ࡉࡥࡱࡹࡥࣦ"))
	AB9GD6ayWq0rlXbLjsV = DDV5NjWFlnf4w1d7bLIphaZJ(MteLX4FmQHBRTV8aZr2A,Wg792AJqnwz8moOTZ5(u"࡚ࡲࡶࡧࣩ"),dYqLj0iTxu3Xbp9kRMv(u"ࡋࡧ࡬ࡴࡧࣨ"),dYqLj0iTxu3Xbp9kRMv(u"ࡋࡧ࡬ࡴࡧࣨ"))
	aH278lfrJyULR6WFVngIoMehxw5Bkd = DDV5NjWFlnf4w1d7bLIphaZJ(Eqxt3fKMzr1vbHJBghURl9Fe,t3tIngkbNWG(u"ࡕࡴࡸࡩ࣫"),djKXw1lcMEgtou0Skma(u"ࡆࡢ࡮ࡶࡩ࣪"),djKXw1lcMEgtou0Skma(u"ࡆࡢ࡮ࡶࡩ࣪"))
	haCFWUNxVErAMPnj8b7Smzq42B = all([WWzdrXbQEx6F2OoucS,aa3IXf6ukEN4iS1lOBzYQxVM0g,RMqihNZ8W5d2GDgBI1Hfj,d7mCEJI163Ng,AB9GD6ayWq0rlXbLjsV,aH278lfrJyULR6WFVngIoMehxw5Bkd])
	if haCFWUNxVErAMPnj8b7Smzq42B: zLSmNK08YVFt(JDWy8bwVMaCTr12deSxuHmvsF3,JDWy8bwVMaCTr12deSxuHmvsF3,JDWy8bwVMaCTr12deSxuHmvsF3,k4ASEqQL62gwtpoMDvWcn(u"࠭ฬ๋ัࠣ࠲࠳ࠦๆอฯอࠤ฾๋ไ๋หࠣฮ๋฾๊โࠢส่ัํวำࠩࡹ"))
	else: zLSmNK08YVFt(JDWy8bwVMaCTr12deSxuHmvsF3,JDWy8bwVMaCTr12deSxuHmvsF3,JDWy8bwVMaCTr12deSxuHmvsF3,ueWGTXL5PRAoB8t7(u"ࠧๅๆฦืๆࠦ࠮࠯ࠢไุ้ะฺࠠ็็๎ฮࠦส็ฺํๅࠥอไอ้สึࠬࡺ"))
	return
def q2MdNliZk0CJUu(FUsIjX57Hf3Gcx9i1l0YK):
	haCFWUNxVErAMPnj8b7Smzq42B = zziCKgtI82GP1awehZ6RNSMY3F(u"ࡖࡵࡹࡪ࣬")
	if FUsIjX57Hf3Gcx9i1l0YK:
		ii3bPVFUcgXfY = oPSeZwkEVFRWrDzNMjJgcB5t(JDWy8bwVMaCTr12deSxuHmvsF3,JDWy8bwVMaCTr12deSxuHmvsF3,JDWy8bwVMaCTr12deSxuHmvsF3,JDWy8bwVMaCTr12deSxuHmvsF3,WPvoul2AhyacUiJrFwCjMezk(u"ࠨ้็ࠤฯื๊ะ่ࠢืาࠦๅฮฬ๋๎ฬะࠠๆๆไࠤฺ๎ัࠡษ็ะ้ีࠠภࠣࠤࠫࡻ"))
		if ii3bPVFUcgXfY!=ZaiujwYhQ634qN7SRg(u"࠲ࣁ"): return
	try:
		import sqlite3 as VC2eX6hvBzHGcPlA5tEpfIyNmD9QjF
		KFo2J7nYXRU = VC2eX6hvBzHGcPlA5tEpfIyNmD9QjF.connect(UULOodfycu)
		KFo2J7nYXRU.text_factory = str
		aSrDiNtbRkT6qfGF08gHIWC = KFo2J7nYXRU.cursor()
		aSrDiNtbRkT6qfGF08gHIWC.execute(PP9pDw1mOqy0GsceaXuh7YkdxL2V(u"ࠩࡇࡉࡑࡋࡔࡆࠢࡉࡖࡔࡓࠠࡱࡣࡷ࡬ࡀ࠭ࡼ"))
		aSrDiNtbRkT6qfGF08gHIWC.execute(WPvoul2AhyacUiJrFwCjMezk(u"ࠪࡈࡊࡒࡅࡕࡇࠣࡊࡗࡕࡍࠡࡵ࡬ࡾࡪࡹ࠻ࠨࡽ"))
		aSrDiNtbRkT6qfGF08gHIWC.execute(Ovd7GgHCDba(u"ࠫࡉࡋࡌࡆࡖࡈࠤࡋࡘࡏࡎࠢࡷࡩࡽࡺࡵࡳࡧ࠾ࠫࡾ"))
		KFo2J7nYXRU.commit()
		aSrDiNtbRkT6qfGF08gHIWC.execute(Wg792AJqnwz8moOTZ5(u"ࠬ࡜ࡁࡄࡗࡘࡑࡀ࠭ࡿ"))
		KFo2J7nYXRU.close()
	except: haCFWUNxVErAMPnj8b7Smzq42B = ZaiujwYhQ634qN7SRg(u"ࡉࡥࡱࡹࡥ࣭")
	if FUsIjX57Hf3Gcx9i1l0YK and haCFWUNxVErAMPnj8b7Smzq42B: zLSmNK08YVFt(JDWy8bwVMaCTr12deSxuHmvsF3,JDWy8bwVMaCTr12deSxuHmvsF3,JDWy8bwVMaCTr12deSxuHmvsF3,dYqLj0iTxu3Xbp9kRMv(u"࠭สๆࠢสู่๊อࠡส้ะฬำࠧࢀ"))
	return haCFWUNxVErAMPnj8b7Smzq42B
def wZOlMzJD2VjsA6LmY4gay3nI1hd():
	haCFWUNxVErAMPnj8b7Smzq42B = zziCKgtI82GP1awehZ6RNSMY3F(u"ࡘࡷࡻࡥ࣮")
	for file in hTuX1lqNoK5vWGmjPrzE8Uc9HQ.listdir(Vn4CtpilLuYjs7KxROhEdBfDgSAyPJ):
		if p6GDqY5K0mWwyb(u"ࠧ࡬ࡱࡧ࡭ࡤࡹࡴࡢࡥ࡮ࡸࡷࡧࡣࡦࠩࢁ") not in file or NTpqJgmvS0a6huZY(u"ࠨ࡭ࡲࡨ࡮ࡥࡣࡳࡣࡶ࡬ࡱࡵࡧࠨࢂ") not in file: continue
		BuG9mZEbV1piKg = hTuX1lqNoK5vWGmjPrzE8Uc9HQ.path.join(Vn4CtpilLuYjs7KxROhEdBfDgSAyPJ,file)
		try:
			hTuX1lqNoK5vWGmjPrzE8Uc9HQ.remove(BuG9mZEbV1piKg)
		except Exception as ggP513wLrHI:
			haCFWUNxVErAMPnj8b7Smzq42B = R0GqN43CuTkIsXgdfoeKhxL(u"ࡋࡧ࡬ࡴࡧ࣯")
			if FUsIjX57Hf3Gcx9i1l0YK and haCFWUNxVErAMPnj8b7Smzq42B: zLSmNK08YVFt(JDWy8bwVMaCTr12deSxuHmvsF3,JDWy8bwVMaCTr12deSxuHmvsF3,JDWy8bwVMaCTr12deSxuHmvsF3,str(ggP513wLrHI))
	return haCFWUNxVErAMPnj8b7Smzq42B
KWGqDigcLsdF3lvhPrQ7It2HkaTw9o(R0GqN43CuTkIsXgdfoeKhxL(u"ࠩࡶࡸࡦࡸࡴࠨࢃ"))
e27KDVhaIflR9uA6PqkT = JRZhm9oGbiNpcyFnMD3IE2PWXB.argv[wJaK1lpHiUF4yWgmROf(u"࠳ࣂ")]
TOV6ItlaNjiADh1Lng2SWwc9PGvKXd = PtWvHo63XmwqN472r5QaxTJCSVyDAK(u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡤࡶࡦࡨࡩࡤࡸ࡬ࡨࡪࡵࡳࠨࢄ")
vX3bWRKa0d1DOH8x4scu5 = MLG9yjuh7vx.getInfoLabel(zziCKgtI82GP1awehZ6RNSMY3F(u"ࠦࡘࡿࡳࡵࡧࡰ࠲ࡇࡻࡩ࡭ࡦ࡙ࡩࡷࡹࡩࡰࡰࠥࢅ"))
NF8TUJcrqeAYg4HK5Dmj6C9axWhzI = SznexPKUa5CjXtVm29u.findall(dYqLj0iTxu3Xbp9kRMv(u"ࠬ࠮࡜ࡥ࡞ࡧࡠ࠳ࡢࡤࠪࠩࢆ"),vX3bWRKa0d1DOH8x4scu5,SznexPKUa5CjXtVm29u.DOTALL)
NF8TUJcrqeAYg4HK5Dmj6C9axWhzI = float(NF8TUJcrqeAYg4HK5Dmj6C9axWhzI[zziCKgtI82GP1awehZ6RNSMY3F(u"࠳ࣃ")])
r9wPbk4AMEu1 = NF8TUJcrqeAYg4HK5Dmj6C9axWhzI<PP9pDw1mOqy0GsceaXuh7YkdxL2V(u"࠵࠾ࣄ")
Y5xpHOTvdmy = NF8TUJcrqeAYg4HK5Dmj6C9axWhzI>UnqwOyV5tC2(u"࠶࠾࠮࠺࠻ࣅ")
if Y5xpHOTvdmy:
	Vn4CtpilLuYjs7KxROhEdBfDgSAyPJ = RRzge3yH1JjEcWw6rnoF9kqKOPfNvm.translatePath(ZaiujwYhQ634qN7SRg(u"࠭ࡳࡱࡧࡦ࡭ࡦࡲ࠺࠰࠱࡯ࡳ࡬ࡶࡡࡵࡪࠪࢇ"))
	EerZgywsAHIpkDPiqU5Yf = RRzge3yH1JjEcWw6rnoF9kqKOPfNvm.translatePath(WPvoul2AhyacUiJrFwCjMezk(u"ࠧࡴࡲࡨࡧ࡮ࡧ࡬࠻࠱࠲࡬ࡴࡳࡥࠨ࢈"))
	CzjKrnJ36gEN2G7OA = RRzge3yH1JjEcWw6rnoF9kqKOPfNvm.translatePath(dYDmO5JoywunX43WNrVSPGE(u"ࠨࡵࡳࡩࡨ࡯ࡡ࡭࠼࠲࠳ࡹ࡫࡭ࡱࠩࢉ"))
	OQkwEso9rZ0YB = hTuX1lqNoK5vWGmjPrzE8Uc9HQ.path.join(EerZgywsAHIpkDPiqU5Yf,WPvoul2AhyacUiJrFwCjMezk(u"ࠩࡸࡷࡪࡸࡤࡢࡶࡤࠫࢊ"),R0GqN43CuTkIsXgdfoeKhxL(u"ࠪࡈࡦࡺࡡࡣࡣࡶࡩࠬࢋ"),P7XtS5p1ElTkWDJZ(u"ࠫࡆࡪࡤࡰࡰࡶ࠷࠸࠴ࡤࡣࠩࢌ"))
else:
	Vn4CtpilLuYjs7KxROhEdBfDgSAyPJ = MLG9yjuh7vx.translatePath(vl4nJBZQaMposrSwKExOyF(u"ࠬࡹࡰࡦࡥ࡬ࡥࡱࡀ࠯࠰࡮ࡲ࡫ࡵࡧࡴࡩࠩࢍ"))
	EerZgywsAHIpkDPiqU5Yf = MLG9yjuh7vx.translatePath(P7XtS5p1ElTkWDJZ(u"࠭ࡳࡱࡧࡦ࡭ࡦࡲ࠺࠰࠱࡫ࡳࡲ࡫ࠧࢎ"))
	CzjKrnJ36gEN2G7OA = MLG9yjuh7vx.translatePath(PP9pDw1mOqy0GsceaXuh7YkdxL2V(u"ࠧࡴࡲࡨࡧ࡮ࡧ࡬࠻࠱࠲ࡸࡪࡳࡰࠨ࢏"))
	OQkwEso9rZ0YB = hTuX1lqNoK5vWGmjPrzE8Uc9HQ.path.join(EerZgywsAHIpkDPiqU5Yf,g1qH4Xu9EhdlTASrnxyD6KVpP(u"ࠨࡷࡶࡩࡷࡪࡡࡵࡣࠪ࢐"),wJaK1lpHiUF4yWgmROf(u"ࠩࡇࡥࡹࡧࡢࡢࡵࡨࠫ࢑"),zziCKgtI82GP1awehZ6RNSMY3F(u"ࠪࡅࡩࡪ࡯࡯ࡵ࠵࠻࠳ࡪࡢࠨ࢒"))
l9XnriW0bgzSEZ2yUQjBL = hTuX1lqNoK5vWGmjPrzE8Uc9HQ.path.join(EerZgywsAHIpkDPiqU5Yf,R0GqN43CuTkIsXgdfoeKhxL(u"ࠫࡺࡹࡥࡳࡦࡤࡸࡦ࠭࢓"),dYqLj0iTxu3Xbp9kRMv(u"ࠬࡧࡤࡥࡱࡱࡣࡩࡧࡴࡢࠩ࢔"),TOV6ItlaNjiADh1Lng2SWwc9PGvKXd)
fS7rzReEvpxNl6HYXTjuZI4na = hTuX1lqNoK5vWGmjPrzE8Uc9HQ.path.join(l9XnriW0bgzSEZ2yUQjBL,nekdqf82zYhWDHwBxjmiKlXSEv4O5(u"࠭ࡳࡦࡶࡷ࡭ࡳ࡭ࡳ࠯ࡺࡰࡰࠬ࢕"))
MxhPqikLGbRjulp = hTuX1lqNoK5vWGmjPrzE8Uc9HQ.path.join(CzjKrnJ36gEN2G7OA,TOV6ItlaNjiADh1Lng2SWwc9PGvKXd)
PwmkLzrj1CnGl = hTuX1lqNoK5vWGmjPrzE8Uc9HQ.path.join(EerZgywsAHIpkDPiqU5Yf,BBHpvyLIWArKzNmT05asfJn(u"ࠧࡶࡵࡨࡶࡩࡧࡴࡢࠩ࢖"),WPvoul2AhyacUiJrFwCjMezk(u"ࠨࡖ࡫ࡹࡲࡨ࡮ࡢ࡫࡯ࡷࠬࢗ"))
C8CszeFRxQtrGWaYbJBZcH3AL456mo = hTuX1lqNoK5vWGmjPrzE8Uc9HQ.path.join(EerZgywsAHIpkDPiqU5Yf,g1qH4Xu9EhdlTASrnxyD6KVpP(u"ࠩࡤࡨࡩࡵ࡮ࡴࠩ࢘"))
zqcm67DhF2ZIE4WRlK0XuYyOV = hTuX1lqNoK5vWGmjPrzE8Uc9HQ.path.join(C8CszeFRxQtrGWaYbJBZcH3AL456mo,TOV6ItlaNjiADh1Lng2SWwc9PGvKXd)
pO4eVSUvY5uQfW1w9lD = hTuX1lqNoK5vWGmjPrzE8Uc9HQ.path.join(C8CszeFRxQtrGWaYbJBZcH3AL456mo,wJaK1lpHiUF4yWgmROf(u"ࠪࡸࡪࡳࡰࠨ࢙"))
xxighLX9zeH2AB = hTuX1lqNoK5vWGmjPrzE8Uc9HQ.path.join(C8CszeFRxQtrGWaYbJBZcH3AL456mo,QFLni0mkUMtHPKy(u"ࠫࡵࡧࡣ࡬ࡣࡪࡩࡸ࢚࠭"))
UULOodfycu = hTuX1lqNoK5vWGmjPrzE8Uc9HQ.path.join(EerZgywsAHIpkDPiqU5Yf,k4ASEqQL62gwtpoMDvWcn(u"ࠬࡻࡳࡦࡴࡧࡥࡹࡧ࢛ࠧ"),dYDmO5JoywunX43WNrVSPGE(u"࠭ࡄࡢࡶࡤࡦࡦࡹࡥࠨ࢜"),nekdqf82zYhWDHwBxjmiKlXSEv4O5(u"ࠧࡕࡧࡻࡸࡺࡸࡥࡴ࠳࠶࠲ࡩࡨࠧ࢝"))
KfVTg5QmIcxndZvq = hTuX1lqNoK5vWGmjPrzE8Uc9HQ.path.join(MxhPqikLGbRjulp,IIYvtpudBF(u"ࠨ࡫ࡰࡥ࡬࡫ࡳࠨ࢞"))
S7XyVBWdPCMTwQ6r4s2bvH = hTuX1lqNoK5vWGmjPrzE8Uc9HQ.path.join(Vn4CtpilLuYjs7KxROhEdBfDgSAyPJ,Ovd7GgHCDba(u"ࠩ࡮ࡳࡩ࡯࠮࡭ࡱࡪࠫ࢟"))
bbSVCk02sHfcOAptaFoy954Wdxz8 = hTuX1lqNoK5vWGmjPrzE8Uc9HQ.path.join(Vn4CtpilLuYjs7KxROhEdBfDgSAyPJ,nekdqf82zYhWDHwBxjmiKlXSEv4O5(u"ࠪ࡯ࡴࡪࡩ࠯ࡱ࡯ࡨ࠳ࡲ࡯ࡨࠩࢠ"))
if   e27KDVhaIflR9uA6PqkT==vl4nJBZQaMposrSwKExOyF(u"ࠫࡸ࡫࡮ࡥࡡ࡯ࡳ࡬࡬ࡩ࡭ࡧࠪࢡ")		: PPojrN6elakwsfR(S7XyVBWdPCMTwQ6r4s2bvH)
elif e27KDVhaIflR9uA6PqkT==QFLni0mkUMtHPKy(u"ࠬࡹࡥ࡯ࡦࡢࡳࡱࡪ࡟࡭ࡱࡪࡪ࡮ࡲࡥࠨࢢ")	: PPojrN6elakwsfR(bbSVCk02sHfcOAptaFoy954Wdxz8)
elif e27KDVhaIflR9uA6PqkT==uKX2cTFCewkW9djva5SR0Qis3(u"࠭ࡤࡦ࡮ࡨࡸࡪࡥࡳࡦࡶࡷ࡭ࡳ࡭ࡳࠨࢣ")		: Ayv5pmD6738l0g()
elif e27KDVhaIflR9uA6PqkT==ueWGTXL5PRAoB8t7(u"ࠧࡥࡧ࡯ࡩࡹ࡫࡟ࡤࡣࡦ࡬ࡪ࠭ࢤ")		: kmV9eqaE01CMNLzirA5YJxWQ2()
elif e27KDVhaIflR9uA6PqkT==ueWGTXL5PRAoB8t7(u"ࠨࡥ࡯ࡩࡦࡴ࡟࡬ࡱࡧ࡭ࠬࢥ")			: MMBwJRVkxmUDnSa()
elif e27KDVhaIflR9uA6PqkT==djKXw1lcMEgtou0Skma(u"ࠩࡦࡰࡪࡧ࡮ࡠࡦࡨࡺ࡮ࡩࡥࡠࡱࡶࠫࢦ")		: cRSZCPqrsKjHF78fNQlobyEkD1wtig()
elif e27KDVhaIflR9uA6PqkT==ii5os2hUtM1Rj(u"ࠪ࡭ࡳࡹࡴࡢ࡮࡯ࡣࡴࡲࡤࡠࡸࡨࡶࡸ࡯࡯࡯ࠩࢧ")	: k2hOIXTquzVPB4wGtbf9d3Zvi()
elif e27KDVhaIflR9uA6PqkT==p6GDqY5K0mWwyb(u"ࠫࡲࡵࡤࡪࡨࡼࡣࡦࡻࡴࡰࡷࡳࡨࡦࡺࡥࠨࢨ")	: IsOyqpKe2Z43ToBE()
elif e27KDVhaIflR9uA6PqkT==mLS1NZKPri0aM9DYBXyVFwe(u"ࠬࡪࡥ࡭ࡧࡷࡩࡤࡳࡥ࡯ࡷࡶࡣ࡮ࡳࡡࡨࡧࡶࠫࢩ")	: SO1ePbaVRzEl8rk2ocBsXv35IW()
KWGqDigcLsdF3lvhPrQ7It2HkaTw9o(Ovd7GgHCDba(u"࠭ࡳࡵࡱࡳࠫࢪ"))