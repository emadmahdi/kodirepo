# -*- coding: utf-8 -*-
from pSfaryIjBo import *
Q8Q0IDc6PLZajJAdTntKUmSGXz = 'CIMAFANS'
headers = { 'User-Agent' : qpFY4hAwolV3 }
wwSFijdVJn1QgHW = '_CMF_'
ddBxj51bhNtaK23lDyGMVw = i4bFG3rKE6.SITESURLS[Q8Q0IDc6PLZajJAdTntKUmSGXz][0]
def vTNE2Ck1sGnugJYW8y39aLcSH64U(mode,url,text):
	if   mode==90: MOTjA5H9XFs = nRVAZc4Dp8PSrGU3xBk()
	elif mode==91: MOTjA5H9XFs = c8U1BdtxOZS5FH(url)
	elif mode==92: MOTjA5H9XFs = mzcAeyplZV(url)
	elif mode==94: MOTjA5H9XFs = wwmvODMWlVSc()
	elif mode==95: MOTjA5H9XFs = v1gmfxDcRrWKQ(url)
	elif mode==99: MOTjA5H9XFs = PPqUACSE3VcGLTvw05jHy9JrFNW(text)
	else: MOTjA5H9XFs = False
	return MOTjA5H9XFs
def nRVAZc4Dp8PSrGU3xBk():
	x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+'بحث في الموقع',qpFY4hAwolV3,99,qpFY4hAwolV3,qpFY4hAwolV3,'_REMEMBERRESULTS_')
	x3WSXnKyPhjqfHG2UrtQs('link',xupTj02bvy3O8R+' ===== ===== ===== '+fF4lt9zWYxXLKZVyAco82PgMj,qpFY4hAwolV3,9999)
	x3WSXnKyPhjqfHG2UrtQs('folder',Q8Q0IDc6PLZajJAdTntKUmSGXz+'_SCRIPT_'+wwSFijdVJn1QgHW+'المضاف حديثا',qpFY4hAwolV3,94)
	x3WSXnKyPhjqfHG2UrtQs('folder',Q8Q0IDc6PLZajJAdTntKUmSGXz+'_SCRIPT_'+wwSFijdVJn1QgHW+'الأحدث',ddBxj51bhNtaK23lDyGMVw+'/?type=latest',91)
	x3WSXnKyPhjqfHG2UrtQs('folder',Q8Q0IDc6PLZajJAdTntKUmSGXz+'_SCRIPT_'+wwSFijdVJn1QgHW+'الأعلى تقيماً',ddBxj51bhNtaK23lDyGMVw+'/?type=imdb',91)
	x3WSXnKyPhjqfHG2UrtQs('folder',Q8Q0IDc6PLZajJAdTntKUmSGXz+'_SCRIPT_'+wwSFijdVJn1QgHW+'الأكثر مشاهدة',ddBxj51bhNtaK23lDyGMVw+'/?type=view',91)
	x3WSXnKyPhjqfHG2UrtQs('folder',Q8Q0IDc6PLZajJAdTntKUmSGXz+'_SCRIPT_'+wwSFijdVJn1QgHW+'المثبت',ddBxj51bhNtaK23lDyGMVw+'/?type=pin',91)
	x3WSXnKyPhjqfHG2UrtQs('folder',Q8Q0IDc6PLZajJAdTntKUmSGXz+'_SCRIPT_'+wwSFijdVJn1QgHW+'جديد الأفلام',ddBxj51bhNtaK23lDyGMVw+'/?type=newMovies',91)
	x3WSXnKyPhjqfHG2UrtQs('folder',Q8Q0IDc6PLZajJAdTntKUmSGXz+'_SCRIPT_'+wwSFijdVJn1QgHW+'جديد الحلقات',ddBxj51bhNtaK23lDyGMVw+'/?type=newEpisodes',91)
	x3WSXnKyPhjqfHG2UrtQs('link',xupTj02bvy3O8R+' ===== ===== ===== '+fF4lt9zWYxXLKZVyAco82PgMj,qpFY4hAwolV3,9999)
	cmWl9dOKHPIy41iaXuxrY = GMqfDK9V4F8eTPE1pNOAaiYUbhr(KOyPvpEztYLaZRdMQJWxfTNFHbkg,ddBxj51bhNtaK23lDyGMVw,qpFY4hAwolV3,headers,qpFY4hAwolV3,'CIMAFANS-MENU-1st')
	pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('class="mainmenu(.*?)nav',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	mVYdjvor6i4wZ8 = pfRkcVlLmUxo561g0A8qSbO[0]
	items = ePhmG1jLD6.findall('<li><a href="(.*?)".*?>(.*?)<',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
	YEIA19ehBwpNfPVzK = ['افلام للكبار فقط']
	for MepIvHBYNArkUOdV37shtJ,title in items:
		title = title.strip(mIsDke0oK5x1zSiOWbF9thGcA)
		if not any(value in title for value in YEIA19ehBwpNfPVzK):
			x3WSXnKyPhjqfHG2UrtQs('folder',Q8Q0IDc6PLZajJAdTntKUmSGXz+'_SCRIPT_'+wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,91)
	x3WSXnKyPhjqfHG2UrtQs('link',xupTj02bvy3O8R+' ===== ===== ===== '+fF4lt9zWYxXLKZVyAco82PgMj,qpFY4hAwolV3,9999)
	pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('class="f-cats"(.*?)</ul>',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	mVYdjvor6i4wZ8 = pfRkcVlLmUxo561g0A8qSbO[0]
	items = ePhmG1jLD6.findall('<li><a href="(.*?)".*?>(.*?)<',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
	for MepIvHBYNArkUOdV37shtJ,title in items:
		title = title.strip(mIsDke0oK5x1zSiOWbF9thGcA)
		if not any(value in title for value in YEIA19ehBwpNfPVzK):
			x3WSXnKyPhjqfHG2UrtQs('folder',Q8Q0IDc6PLZajJAdTntKUmSGXz+'_SCRIPT_'+wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,91)
	return cmWl9dOKHPIy41iaXuxrY
def c8U1BdtxOZS5FH(url):
	if '/search.php' in url:
		url,search = url.split('?t=')
		headers = { 'User-Agent' : qpFY4hAwolV3 , 'Content-Type' : 'application/x-www-form-urlencoded' }
		data = { 't' : search }
		IAW0sh6So3NpqM = WWrExJZS3Bj4anOAkpv7(kUz8c7OqsxuPFIGfwg,'POST',url,data,headers,qpFY4hAwolV3,qpFY4hAwolV3,'CIMAFANS-TITLES-1st')
		cmWl9dOKHPIy41iaXuxrY = IAW0sh6So3NpqM.content
	else:
		headers = { 'User-Agent' : qpFY4hAwolV3 }
		cmWl9dOKHPIy41iaXuxrY = GMqfDK9V4F8eTPE1pNOAaiYUbhr(kUz8c7OqsxuPFIGfwg,url,qpFY4hAwolV3,headers,qpFY4hAwolV3,'CIMAFANS-TITLES-2nd')
	pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('"movies-items"(.*?)"clear"',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	if pfRkcVlLmUxo561g0A8qSbO: mVYdjvor6i4wZ8 = pfRkcVlLmUxo561g0A8qSbO[0]
	else: mVYdjvor6i4wZ8 = qpFY4hAwolV3
	items = ePhmG1jLD6.findall('background-image:url\((.*?)\).*?href="(.*?)".*?movie-title">(.*?)<',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
	if not items:
		items = ePhmG1jLD6.findall('"movie-item".*?href="(.*?)".*?src="(.*?)" alt="(.*?)"',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
		CFevtSjzbpn,rS1xqU30RcTwZsVDfuCyzKbLPoaX4,EmejzBHJ28TqtDAZ74NUhF = zip(*items)
		items = zip(rS1xqU30RcTwZsVDfuCyzKbLPoaX4,CFevtSjzbpn,EmejzBHJ28TqtDAZ74NUhF)
	aaCNAJdtsguSRELh2I = []
	for Sj7rMNYRuQPTtkBvpHKeDW3h,MepIvHBYNArkUOdV37shtJ,title in items:
		if 'حلقة' in title and '/c/' not in url and '/cat/' not in url:
			ZDTxRSMbW7PNz = ePhmG1jLD6.findall('(.*?) الحلقة [0-9]+',title,ePhmG1jLD6.DOTALL)
			if ZDTxRSMbW7PNz:
				title = '_MOD_'+ZDTxRSMbW7PNz[0]
				if title not in aaCNAJdtsguSRELh2I:
					x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,95,Sj7rMNYRuQPTtkBvpHKeDW3h)
					aaCNAJdtsguSRELh2I.append(title)
		elif '/video/' in MepIvHBYNArkUOdV37shtJ: x3WSXnKyPhjqfHG2UrtQs('video',wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,92,Sj7rMNYRuQPTtkBvpHKeDW3h)
		else: x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,91,Sj7rMNYRuQPTtkBvpHKeDW3h)
	pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('class="pagination(.*?)div',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	if pfRkcVlLmUxo561g0A8qSbO:
		mVYdjvor6i4wZ8 = pfRkcVlLmUxo561g0A8qSbO[0]
		items = ePhmG1jLD6.findall('<a href="(.*?)".*?>(.*?)<',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
		for MepIvHBYNArkUOdV37shtJ,title in items:
			title = j8PDV0pthfSTidZbsQxNIOmCYKWzH(title)
			title = title.replace('الصفحة ',qpFY4hAwolV3)
			x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+'صفحة '+title,MepIvHBYNArkUOdV37shtJ,91)
	return
def v1gmfxDcRrWKQ(url):
	cmWl9dOKHPIy41iaXuxrY = GMqfDK9V4F8eTPE1pNOAaiYUbhr(kUz8c7OqsxuPFIGfwg,url,qpFY4hAwolV3,headers,qpFY4hAwolV3,'CIMAFANS-EPISODES-1st')
	Sj7rMNYRuQPTtkBvpHKeDW3h = ePhmG1jLD6.findall('img src="(.*?)"',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	Sj7rMNYRuQPTtkBvpHKeDW3h = Sj7rMNYRuQPTtkBvpHKeDW3h[0]
	pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('id="episodes-panel(.*?)div',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	if pfRkcVlLmUxo561g0A8qSbO:
		name = ePhmG1jLD6.findall('itemprop="title">(.*?)<',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
		if name: name = name[1]
		else:
			name = Rqvw05BorCgcye7VE32Sf.getInfoLabel('ListItem.Label')
			if fF4lt9zWYxXLKZVyAco82PgMj in name: name = name.split(fF4lt9zWYxXLKZVyAco82PgMj,1)[1]
		mVYdjvor6i4wZ8 = pfRkcVlLmUxo561g0A8qSbO[0]
		items = ePhmG1jLD6.findall('href="(.*?)".*?name">(.*?)<',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
		for MepIvHBYNArkUOdV37shtJ,title in items:
			x3WSXnKyPhjqfHG2UrtQs('video',wwSFijdVJn1QgHW+name+' - '+title,MepIvHBYNArkUOdV37shtJ,92,Sj7rMNYRuQPTtkBvpHKeDW3h)
	else:
		sgWRIGYQHUhXw5kPzN4OnoZJ1c9 = ePhmG1jLD6.findall('class="movietitle"><a href="(.*?)">(.*?)<',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
		if sgWRIGYQHUhXw5kPzN4OnoZJ1c9: MepIvHBYNArkUOdV37shtJ,title = sgWRIGYQHUhXw5kPzN4OnoZJ1c9[0]
		else: MepIvHBYNArkUOdV37shtJ,title = url,name
		x3WSXnKyPhjqfHG2UrtQs('video',wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,92,Sj7rMNYRuQPTtkBvpHKeDW3h)
	return
def mzcAeyplZV(url):
	U7V0BQZPxXqMbyJnRw6f,xCaQ9ht6SfOY8IKleM2zqR4 = [],[]
	cmWl9dOKHPIy41iaXuxrY = GMqfDK9V4F8eTPE1pNOAaiYUbhr(kUz8c7OqsxuPFIGfwg,url,qpFY4hAwolV3,headers,qpFY4hAwolV3,'CIMAFANS-PLAY-1st')
	GIE2XSj0vVJPZA6dgmOs9TMDy8UkQW = ePhmG1jLD6.findall('text-shadow: none;">(.*?)<',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	if GIE2XSj0vVJPZA6dgmOs9TMDy8UkQW and u0E18eO3HnCzr(Q8Q0IDc6PLZajJAdTntKUmSGXz,url,GIE2XSj0vVJPZA6dgmOs9TMDy8UkQW): return
	pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('id="links-panel(.*?)div',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	if pfRkcVlLmUxo561g0A8qSbO:
		mVYdjvor6i4wZ8 = pfRkcVlLmUxo561g0A8qSbO[0]
		items = ePhmG1jLD6.findall('href="(.*?)"',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
		for MepIvHBYNArkUOdV37shtJ in items:
			MepIvHBYNArkUOdV37shtJ = MepIvHBYNArkUOdV37shtJ+'?__download'
			U7V0BQZPxXqMbyJnRw6f.append(MepIvHBYNArkUOdV37shtJ)
	pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('nav-tabs"(.*?)video-panel-more',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	if pfRkcVlLmUxo561g0A8qSbO:
		mVYdjvor6i4wZ8 = pfRkcVlLmUxo561g0A8qSbO[0]
		items = ePhmG1jLD6.findall('id="(.*?)".*?embed src="(.*?)"',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
		for id,MepIvHBYNArkUOdV37shtJ in items:
			title = 'سيرفر '+id
			MepIvHBYNArkUOdV37shtJ = MepIvHBYNArkUOdV37shtJ+'?named='+title+'__watch'
			U7V0BQZPxXqMbyJnRw6f.append(MepIvHBYNArkUOdV37shtJ)
		items = ePhmG1jLD6.findall('data-server-src="(.*?)"',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
		for MepIvHBYNArkUOdV37shtJ in items:
			if 'http' not in MepIvHBYNArkUOdV37shtJ: MepIvHBYNArkUOdV37shtJ = 'http:'+MepIvHBYNArkUOdV37shtJ
			MepIvHBYNArkUOdV37shtJ = cTt4u6reEMKZqVLplmkNW7(MepIvHBYNArkUOdV37shtJ)
			U7V0BQZPxXqMbyJnRw6f.append(MepIvHBYNArkUOdV37shtJ)
	import inVXFK46ET
	inVXFK46ET.q4qTJvuoQUzM3mZAtegy7IXdnb5wH(U7V0BQZPxXqMbyJnRw6f,Q8Q0IDc6PLZajJAdTntKUmSGXz,'video',url)
	return
def wwmvODMWlVSc():
	cmWl9dOKHPIy41iaXuxrY = GMqfDK9V4F8eTPE1pNOAaiYUbhr(kUz8c7OqsxuPFIGfwg,ddBxj51bhNtaK23lDyGMVw,qpFY4hAwolV3,headers,qpFY4hAwolV3,'CIMAFANS-LATEST-1st')
	pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('id="index-last-movie(.*?)id="index-slider-movie',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	mVYdjvor6i4wZ8 = pfRkcVlLmUxo561g0A8qSbO[0]
	items = ePhmG1jLD6.findall('src="(.*?)".*?href="(.*?)" title="(.*?)"',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
	for Sj7rMNYRuQPTtkBvpHKeDW3h,MepIvHBYNArkUOdV37shtJ,title in items:
		if '/video/' in MepIvHBYNArkUOdV37shtJ: x3WSXnKyPhjqfHG2UrtQs('video',wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,92,Sj7rMNYRuQPTtkBvpHKeDW3h)
		else: x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,91,Sj7rMNYRuQPTtkBvpHKeDW3h)
	return
def PPqUACSE3VcGLTvw05jHy9JrFNW(search):
	search,LBylNhMdH6OV1qGk0tWiXFg3,showDialogs = LLm3sBXHPcnTDxdE5gt6hz0Wkp(search)
	if search==qpFY4hAwolV3: search = jXgARlWMLVFUBnvmZwI2o5()
	if search==qpFY4hAwolV3: return
	search = search.replace(mIsDke0oK5x1zSiOWbF9thGcA,'+')
	url = ddBxj51bhNtaK23lDyGMVw + '/search.php?t='+search
	c8U1BdtxOZS5FH(url)
	return