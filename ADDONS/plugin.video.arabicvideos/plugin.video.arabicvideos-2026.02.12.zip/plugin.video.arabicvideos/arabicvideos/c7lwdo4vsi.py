# -*- coding: utf-8 -*-
from pSfaryIjBo import *
Q8Q0IDc6PLZajJAdTntKUmSGXz = 'LIVETV'
ddBxj51bhNtaK23lDyGMVw = i4bFG3rKE6.SITESURLS['PYTHON'][0]
def vTNE2Ck1sGnugJYW8y39aLcSH64U(mode,url):
	if   mode==100: MOTjA5H9XFs = nRVAZc4Dp8PSrGU3xBk()
	elif mode==101: MOTjA5H9XFs = I19sHuzZ8RryYXSwgV7mQ3Dh('0',True)
	elif mode==102: MOTjA5H9XFs = I19sHuzZ8RryYXSwgV7mQ3Dh('1',True)
	elif mode==103: MOTjA5H9XFs = I19sHuzZ8RryYXSwgV7mQ3Dh('2',True)
	elif mode==104: MOTjA5H9XFs = I19sHuzZ8RryYXSwgV7mQ3Dh('3',True)
	elif mode==105: MOTjA5H9XFs = mzcAeyplZV(url)
	elif mode==106: MOTjA5H9XFs = I19sHuzZ8RryYXSwgV7mQ3Dh('4',True)
	else: MOTjA5H9XFs = False
	return MOTjA5H9XFs
def nRVAZc4Dp8PSrGU3xBk():
	x3WSXnKyPhjqfHG2UrtQs('folder','_M3U_'+'قوائم فيديوهات M3U',qpFY4hAwolV3,762)
	x3WSXnKyPhjqfHG2UrtQs('folder','_IPT_'+'قوائم فيديوهات IPTV',qpFY4hAwolV3,761)
	x3WSXnKyPhjqfHG2UrtQs('folder','_TV0_'+'قنوات من مواقعها الأصلية',qpFY4hAwolV3,101)
	x3WSXnKyPhjqfHG2UrtQs('folder','_TV4_'+'قنوات مختارة من يوتيوب',qpFY4hAwolV3,106)
	x3WSXnKyPhjqfHG2UrtQs('folder','_YUT_'+'قنوات عربية من يوتيوب',qpFY4hAwolV3,147)
	x3WSXnKyPhjqfHG2UrtQs('folder','_YUT_'+'قنوات أجنبية من يوتيوب',qpFY4hAwolV3,148)
	x3WSXnKyPhjqfHG2UrtQs('folder','_IFL_'+'  قناة آي فيلم من موقعهم  ',qpFY4hAwolV3,28)
	x3WSXnKyPhjqfHG2UrtQs('live','_MRF_'+'قناة المعارف من موقعهم',qpFY4hAwolV3,41)
	x3WSXnKyPhjqfHG2UrtQs('link',xupTj02bvy3O8R+' ===== ===== ===== '+fF4lt9zWYxXLKZVyAco82PgMj,qpFY4hAwolV3,9999)
	x3WSXnKyPhjqfHG2UrtQs('folder','_TV1_'+'قنوات تلفزيونية عامة',qpFY4hAwolV3,102)
	x3WSXnKyPhjqfHG2UrtQs('folder','_TV2_'+'قنوات تلفزيونية خاصة',qpFY4hAwolV3,103)
	x3WSXnKyPhjqfHG2UrtQs('folder','_TV3_'+'قنوات تلفزيونية للفحص',qpFY4hAwolV3,104)
	return
def I19sHuzZ8RryYXSwgV7mQ3Dh(HZTvVym7W3M4Nh5CQe,showDialogs=True):
	wwSFijdVJn1QgHW = '_TV'+HZTvVym7W3M4Nh5CQe+'_'
	GI0fwOUzWlVYaicPdBRunFy = {'id':qpFY4hAwolV3,'user':i4bFG3rKE6.AV_CLIENT_IDS,'function':'list','menu':HZTvVym7W3M4Nh5CQe}
	IAW0sh6So3NpqM = WWrExJZS3Bj4anOAkpv7(rGY36xBwT1bLZAngSfcWEIeXdQVNij,'POST',ddBxj51bhNtaK23lDyGMVw,GI0fwOUzWlVYaicPdBRunFy,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,'LIVETV-ITEMS-1st')
	cmWl9dOKHPIy41iaXuxrY = IAW0sh6So3NpqM.content
	items = ePhmG1jLD6.findall('([^;\r\n]+?);;(.*?);;(.*?);;(.*?);;(.*?);;',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	if items:
		for a2jQ83ZCfcM5 in range(len(items)):
			name = items[a2jQ83ZCfcM5][3]
			start = name[0:2]
			start = start.replace('al','Al')
			start = start.replace('El','Al')
			start = start.replace('AL','Al')
			start = start.replace('EL','Al')
			name = start+name[2:]
			start = name[0:3]
			start = start.replace('Al-','Al')
			start = start.replace('Al ','Al')
			name = start+name[3:]
			items[a2jQ83ZCfcM5] = items[a2jQ83ZCfcM5][0],items[a2jQ83ZCfcM5][1],items[a2jQ83ZCfcM5][2],name,items[a2jQ83ZCfcM5][4]
		items = set(items)
		items = sorted(items, reverse=False, key=lambda key: key[0].lower())
		items = sorted(items, reverse=False, key=lambda key: key[3].lower())
		for n38oH7wd6BDyAMJQS,XPNkVcWFUr,KpzHWlsYVwvhfdN0A8Lk2n6M,name,Sj7rMNYRuQPTtkBvpHKeDW3h in items:
			if '#' in n38oH7wd6BDyAMJQS: continue
			if n38oH7wd6BDyAMJQS!='URL': name = name+xupTj02bvy3O8R+bJGaEk9wcz+n38oH7wd6BDyAMJQS+fF4lt9zWYxXLKZVyAco82PgMj
			url = n38oH7wd6BDyAMJQS+';;'+XPNkVcWFUr+';;'+KpzHWlsYVwvhfdN0A8Lk2n6M+';;'+HZTvVym7W3M4Nh5CQe
			x3WSXnKyPhjqfHG2UrtQs('live',wwSFijdVJn1QgHW+qpFY4hAwolV3+name,url,105,Sj7rMNYRuQPTtkBvpHKeDW3h)
	else:
		if showDialogs: x3WSXnKyPhjqfHG2UrtQs('link',wwSFijdVJn1QgHW+'هذه الخدمة مخصصة للمبرمج فقط',qpFY4hAwolV3,9999)
	return
def mzcAeyplZV(id):
	n38oH7wd6BDyAMJQS,XPNkVcWFUr,KpzHWlsYVwvhfdN0A8Lk2n6M,HZTvVym7W3M4Nh5CQe = id.split(';;')
	url = qpFY4hAwolV3
	if n38oH7wd6BDyAMJQS=='URL': url = KpzHWlsYVwvhfdN0A8Lk2n6M
	elif n38oH7wd6BDyAMJQS=='YOUTUBE':
		url = i4bFG3rKE6.SITESURLS['YOUTUBE'][0]+'/watch?v='+KpzHWlsYVwvhfdN0A8Lk2n6M
		import inVXFK46ET
		inVXFK46ET.q4qTJvuoQUzM3mZAtegy7IXdnb5wH([url],Q8Q0IDc6PLZajJAdTntKUmSGXz,'live',url)
		return
	elif n38oH7wd6BDyAMJQS=='GA':
		GI0fwOUzWlVYaicPdBRunFy = { 'id' : qpFY4hAwolV3, 'user' : i4bFG3rKE6.AV_CLIENT_IDS , 'function' : 'playGA1' , 'menu' : qpFY4hAwolV3 }
		IAW0sh6So3NpqM = WWrExJZS3Bj4anOAkpv7(rGY36xBwT1bLZAngSfcWEIeXdQVNij,'GET',ddBxj51bhNtaK23lDyGMVw,GI0fwOUzWlVYaicPdBRunFy,qpFY4hAwolV3,False,qpFY4hAwolV3,'LIVETV-PLAY-1st')
		if not IAW0sh6So3NpqM.succeeded:
			iG7Rz2kmn0x1yLNMV3u8O(qpFY4hAwolV3,qpFY4hAwolV3,GLTtERWbHnFuy4PCp,'هذه الخدمة مخصصة للمبرمج فقط')
			return
		cmWl9dOKHPIy41iaXuxrY = IAW0sh6So3NpqM.content
		cookies = IAW0sh6So3NpqM.cookies
		xQCZuaAWE5H = cookies['ASP.NET_SessionId']
		url = IAW0sh6So3NpqM.headers['Location']
		GI0fwOUzWlVYaicPdBRunFy = { 'id' : KpzHWlsYVwvhfdN0A8Lk2n6M , 'user' : i4bFG3rKE6.AV_CLIENT_IDS , 'function' : 'playGA2' , 'menu' : qpFY4hAwolV3 }
		headers = { 'Cookie' : 'ASP.NET_SessionId='+xQCZuaAWE5H }
		IAW0sh6So3NpqM = WWrExJZS3Bj4anOAkpv7(rGY36xBwT1bLZAngSfcWEIeXdQVNij,'GET',ddBxj51bhNtaK23lDyGMVw,GI0fwOUzWlVYaicPdBRunFy,headers,qpFY4hAwolV3,qpFY4hAwolV3,'LIVETV-PLAY-2nd')
		if not IAW0sh6So3NpqM.succeeded:
			iG7Rz2kmn0x1yLNMV3u8O(qpFY4hAwolV3,qpFY4hAwolV3,GLTtERWbHnFuy4PCp,'هذه الخدمة مخصصة للمبرمج فقط')
			return
		cmWl9dOKHPIy41iaXuxrY = IAW0sh6So3NpqM.content
		url = ePhmG1jLD6.findall('resp":"(http.*?m3u8)(.*?)"',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
		MepIvHBYNArkUOdV37shtJ = url[0][0]
		O2Oj0H3ocNhaSLlsXef7KmBA = url[0][1]
		ozwamuD2NfbC8VKZL7gXYBcxqFjO = 'http://38.'+XPNkVcWFUr+'777/'+KpzHWlsYVwvhfdN0A8Lk2n6M+'_HD.m3u8'+O2Oj0H3ocNhaSLlsXef7KmBA
		GUMziF4hVvqIALetHsNr8OW6mk3f1 = ozwamuD2NfbC8VKZL7gXYBcxqFjO.replace('36:7','40:7').replace('_HD.m3u8','.m3u8')
		xCmlEnHDZtjNFTsY6oPyi = ozwamuD2NfbC8VKZL7gXYBcxqFjO.replace('36:7','42:7').replace('_HD.m3u8','.m3u8')
		QQLqrElamjfneR8GoP9IpuZ = ['HD','SD1','SD2']
		U7V0BQZPxXqMbyJnRw6f = [ozwamuD2NfbC8VKZL7gXYBcxqFjO,GUMziF4hVvqIALetHsNr8OW6mk3f1,xCmlEnHDZtjNFTsY6oPyi]
		ndm6kKswPpgGHNEbtB = 0
		if ndm6kKswPpgGHNEbtB == -1: return
		else: url = U7V0BQZPxXqMbyJnRw6f[ndm6kKswPpgGHNEbtB]
	elif n38oH7wd6BDyAMJQS=='NT':
		headers = { 'Content-Type' : 'application/x-www-form-urlencoded' }
		GI0fwOUzWlVYaicPdBRunFy = { 'id' : KpzHWlsYVwvhfdN0A8Lk2n6M , 'user' : i4bFG3rKE6.AV_CLIENT_IDS , 'function' : 'playNT' , 'menu' : HZTvVym7W3M4Nh5CQe }
		IAW0sh6So3NpqM = WWrExJZS3Bj4anOAkpv7(rGY36xBwT1bLZAngSfcWEIeXdQVNij,'POST', ddBxj51bhNtaK23lDyGMVw, GI0fwOUzWlVYaicPdBRunFy, headers, False,qpFY4hAwolV3,'LIVETV-PLAY-3rd')
		if not IAW0sh6So3NpqM.succeeded:
			iG7Rz2kmn0x1yLNMV3u8O(qpFY4hAwolV3,qpFY4hAwolV3,GLTtERWbHnFuy4PCp,'هذه الخدمة مخصصة للمبرمج فقط')
			return
		cmWl9dOKHPIy41iaXuxrY = IAW0sh6So3NpqM.content
		url = IAW0sh6So3NpqM.headers['Location']
		url = url.replace('%20',mIsDke0oK5x1zSiOWbF9thGcA)
		url = url.replace('%3D','=')
		if 'Learn' in KpzHWlsYVwvhfdN0A8Lk2n6M:
			url = url.replace('NTNNile',qpFY4hAwolV3)
			url = url.replace('learning1','Learning')
	elif n38oH7wd6BDyAMJQS=='PL':
		GI0fwOUzWlVYaicPdBRunFy = { 'id' : KpzHWlsYVwvhfdN0A8Lk2n6M , 'user' : i4bFG3rKE6.AV_CLIENT_IDS , 'function' : 'playPL' , 'menu' : HZTvVym7W3M4Nh5CQe }
		IAW0sh6So3NpqM = WWrExJZS3Bj4anOAkpv7(rGY36xBwT1bLZAngSfcWEIeXdQVNij,'POST', ddBxj51bhNtaK23lDyGMVw, GI0fwOUzWlVYaicPdBRunFy, qpFY4hAwolV3,False,qpFY4hAwolV3,'LIVETV-PLAY-4th')
		if not IAW0sh6So3NpqM.succeeded:
			iG7Rz2kmn0x1yLNMV3u8O(qpFY4hAwolV3,qpFY4hAwolV3,GLTtERWbHnFuy4PCp,'هذه الخدمة مخصصة للمبرمج فقط')
			return
		cmWl9dOKHPIy41iaXuxrY = IAW0sh6So3NpqM.content
		url = IAW0sh6So3NpqM.headers['Location']
		headers = {'Referer':IAW0sh6So3NpqM.headers['Referer']}
		IAW0sh6So3NpqM = WWrExJZS3Bj4anOAkpv7(dzcNuIbsgK3yZ6SXGaEHPfOj5vk,'POST',url, qpFY4hAwolV3,headers , qpFY4hAwolV3,qpFY4hAwolV3,'LIVETV-PLAY-5th')
		if not IAW0sh6So3NpqM.succeeded:
			iG7Rz2kmn0x1yLNMV3u8O(qpFY4hAwolV3,qpFY4hAwolV3,GLTtERWbHnFuy4PCp,'هذه الخدمة مخصصة للمبرمج فقط')
			return
		cmWl9dOKHPIy41iaXuxrY = IAW0sh6So3NpqM.content
		items = ePhmG1jLD6.findall('source src="(.*?)"',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
		url = items[0]
	elif n38oH7wd6BDyAMJQS in ['TA','FM','YU','WS1','WS2','RL1','RL2']:
		if n38oH7wd6BDyAMJQS=='TA': KpzHWlsYVwvhfdN0A8Lk2n6M = id
		headers = { 'Content-Type' : 'application/x-www-form-urlencoded' }
		GI0fwOUzWlVYaicPdBRunFy = { 'id' : KpzHWlsYVwvhfdN0A8Lk2n6M , 'user' : i4bFG3rKE6.AV_CLIENT_IDS , 'function' : 'play'+n38oH7wd6BDyAMJQS , 'menu' : HZTvVym7W3M4Nh5CQe }
		IAW0sh6So3NpqM = WWrExJZS3Bj4anOAkpv7(rGY36xBwT1bLZAngSfcWEIeXdQVNij,'POST',ddBxj51bhNtaK23lDyGMVw,GI0fwOUzWlVYaicPdBRunFy,headers,qpFY4hAwolV3,qpFY4hAwolV3,'LIVETV-PLAY-6th')
		if not IAW0sh6So3NpqM.succeeded:
			iG7Rz2kmn0x1yLNMV3u8O(qpFY4hAwolV3,qpFY4hAwolV3,GLTtERWbHnFuy4PCp,'هذه الخدمة مخصصة للمبرمج فقط')
			return
		cmWl9dOKHPIy41iaXuxrY = IAW0sh6So3NpqM.content
		url = IAW0sh6So3NpqM.headers['Location']
		if n38oH7wd6BDyAMJQS=='FM':
			IAW0sh6So3NpqM = WWrExJZS3Bj4anOAkpv7(dzcNuIbsgK3yZ6SXGaEHPfOj5vk,'GET', url, qpFY4hAwolV3, qpFY4hAwolV3, False,qpFY4hAwolV3,'LIVETV-PLAY-7th')
			url = IAW0sh6So3NpqM.headers['Location']
			url = url.replace('https','http')
	dORtnXbEgi5A8m0CH(url,Q8Q0IDc6PLZajJAdTntKUmSGXz,'live')
	return