# -*- coding: utf-8 -*-
from pSfaryIjBo import *
Q8Q0IDc6PLZajJAdTntKUmSGXz = 'ALARAB'
headers = {'User-Agent':qpFY4hAwolV3}
wwSFijdVJn1QgHW = '_KLA_'
ddBxj51bhNtaK23lDyGMVw = i4bFG3rKE6.SITESURLS[Q8Q0IDc6PLZajJAdTntKUmSGXz][0]
def vTNE2Ck1sGnugJYW8y39aLcSH64U(mode,url,text):
	if   mode==10: MOTjA5H9XFs = nRVAZc4Dp8PSrGU3xBk()
	elif mode==11: MOTjA5H9XFs = c8U1BdtxOZS5FH(url)
	elif mode==12: MOTjA5H9XFs = mzcAeyplZV(url)
	elif mode==13: MOTjA5H9XFs = v1gmfxDcRrWKQ(url)
	elif mode==14: MOTjA5H9XFs = wwmvODMWlVSc()
	elif mode==15: MOTjA5H9XFs = Frsl7tM5gUSNHwjIJ2z1a6hGx93()
	elif mode==16: MOTjA5H9XFs = lBIkOei1Rv9P6pEg()
	elif mode==19: MOTjA5H9XFs = PPqUACSE3VcGLTvw05jHy9JrFNW(text)
	else: MOTjA5H9XFs = False
	return MOTjA5H9XFs
def nRVAZc4Dp8PSrGU3xBk():
	x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+'بحث في الموقع',qpFY4hAwolV3,19,qpFY4hAwolV3,qpFY4hAwolV3,'_REMEMBERRESULTS_')
	x3WSXnKyPhjqfHG2UrtQs('link',xupTj02bvy3O8R+' ===== ===== ===== '+fF4lt9zWYxXLKZVyAco82PgMj,qpFY4hAwolV3,9999)
	x3WSXnKyPhjqfHG2UrtQs('folder',Q8Q0IDc6PLZajJAdTntKUmSGXz+'_SCRIPT_'+wwSFijdVJn1QgHW+'آخر الإضافات',qpFY4hAwolV3,14)
	x3WSXnKyPhjqfHG2UrtQs('folder',Q8Q0IDc6PLZajJAdTntKUmSGXz+'_SCRIPT_'+wwSFijdVJn1QgHW+'مسلسلات رمضان',qpFY4hAwolV3,15)
	cmWl9dOKHPIy41iaXuxrY = GMqfDK9V4F8eTPE1pNOAaiYUbhr(KOyPvpEztYLaZRdMQJWxfTNFHbkg,ddBxj51bhNtaK23lDyGMVw,qpFY4hAwolV3,headers,qpFY4hAwolV3,'ALARAB-MENU-1st')
	pfRkcVlLmUxo561g0A8qSbO=ePhmG1jLD6.findall('id="nav-slider"(.*?)</div>',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	BRveZufhmO2EKP = pfRkcVlLmUxo561g0A8qSbO[0]
	items = ePhmG1jLD6.findall('href="(.*?)".*?>(.*?)<',BRveZufhmO2EKP,ePhmG1jLD6.DOTALL)
	for MepIvHBYNArkUOdV37shtJ,title in items:
		MepIvHBYNArkUOdV37shtJ = ddBxj51bhNtaK23lDyGMVw+MepIvHBYNArkUOdV37shtJ
		title = title.strip(mIsDke0oK5x1zSiOWbF9thGcA)
		x3WSXnKyPhjqfHG2UrtQs('folder',Q8Q0IDc6PLZajJAdTntKUmSGXz+'_SCRIPT_'+wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,11)
	x3WSXnKyPhjqfHG2UrtQs('link',xupTj02bvy3O8R+' ===== ===== ===== '+fF4lt9zWYxXLKZVyAco82PgMj,qpFY4hAwolV3,9999)
	pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('id="navbar"(.*?)</div>',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	WqdHmfQpP0ITnjJOAbDR6u8t7EiU = pfRkcVlLmUxo561g0A8qSbO[0]
	items = ePhmG1jLD6.findall('href="(.*?)".*?>(.*?)<',WqdHmfQpP0ITnjJOAbDR6u8t7EiU,ePhmG1jLD6.DOTALL)
	for MepIvHBYNArkUOdV37shtJ,title in items:
		MepIvHBYNArkUOdV37shtJ = ddBxj51bhNtaK23lDyGMVw+MepIvHBYNArkUOdV37shtJ
		x3WSXnKyPhjqfHG2UrtQs('folder',Q8Q0IDc6PLZajJAdTntKUmSGXz+'_SCRIPT_'+wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,11)
	return cmWl9dOKHPIy41iaXuxrY
def Frsl7tM5gUSNHwjIJ2z1a6hGx93():
	x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+'جميع المسلسلات العربية',ddBxj51bhNtaK23lDyGMVw+'/view-8/مسلسلات-عربية',11)
	x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+'مسلسلات السنة الأخيرة',qpFY4hAwolV3,16)
	x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+'مسلسلات رمضان الأخيرة 1',ddBxj51bhNtaK23lDyGMVw+'/view-8/مسلسلات-رمضان-2022',11)
	x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+'مسلسلات رمضان الأخيرة 2',ddBxj51bhNtaK23lDyGMVw+'/view-8/مسلسلات-رمضان-2023',11)
	x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+'مسلسلات رمضان 2023',ddBxj51bhNtaK23lDyGMVw+'/ramadan2023/مصرية',11)
	x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+'مسلسلات رمضان 2022',ddBxj51bhNtaK23lDyGMVw+'/ramadan2022/مصرية',11)
	x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+'مسلسلات رمضان 2021',ddBxj51bhNtaK23lDyGMVw+'/ramadan2021/مصرية',11)
	x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+'مسلسلات رمضان 2020',ddBxj51bhNtaK23lDyGMVw+'/ramadan2020/مصرية',11)
	x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+'مسلسلات رمضان 2019',ddBxj51bhNtaK23lDyGMVw+'/ramadan2019/مصرية',11)
	x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+'مسلسلات رمضان 2018',ddBxj51bhNtaK23lDyGMVw+'/ramadan2018/مصرية',11)
	x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+'مسلسلات رمضان 2017',ddBxj51bhNtaK23lDyGMVw+'/ramadan2017/مصرية',11)
	x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+'مسلسلات رمضان 2016',ddBxj51bhNtaK23lDyGMVw+'/ramadan2016/مصرية',11)
	return
def wwmvODMWlVSc():
	cmWl9dOKHPIy41iaXuxrY = GMqfDK9V4F8eTPE1pNOAaiYUbhr(kUz8c7OqsxuPFIGfwg,ddBxj51bhNtaK23lDyGMVw,qpFY4hAwolV3,headers,True,'ALARAB-LATEST-1st')
	pfRkcVlLmUxo561g0A8qSbO=ePhmG1jLD6.findall('heading-top(.*?)div class=',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	mVYdjvor6i4wZ8 = pfRkcVlLmUxo561g0A8qSbO[0]+pfRkcVlLmUxo561g0A8qSbO[1]
	items=ePhmG1jLD6.findall('href="(.*?)".*?data-src="(.*?)" alt="(.*?)"',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
	for MepIvHBYNArkUOdV37shtJ,Sj7rMNYRuQPTtkBvpHKeDW3h,title in items:
		url = ddBxj51bhNtaK23lDyGMVw + MepIvHBYNArkUOdV37shtJ
		if 'series' in url: x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+title,url,11,Sj7rMNYRuQPTtkBvpHKeDW3h)
		else: x3WSXnKyPhjqfHG2UrtQs('video',wwSFijdVJn1QgHW+title,url,12,Sj7rMNYRuQPTtkBvpHKeDW3h)
	return
def c8U1BdtxOZS5FH(url):
	IAW0sh6So3NpqM = WWrExJZS3Bj4anOAkpv7(kUz8c7OqsxuPFIGfwg,'GET',url,qpFY4hAwolV3,headers,True,True,'ALARAB-TITLES-1st')
	cmWl9dOKHPIy41iaXuxrY = IAW0sh6So3NpqM.content
	pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('video-category(.*?)right_content',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	if not pfRkcVlLmUxo561g0A8qSbO: return
	mVYdjvor6i4wZ8 = pfRkcVlLmUxo561g0A8qSbO[0]
	u0eDOmMnFCiR = False
	items = ePhmG1jLD6.findall('video-box.*?href="(.*?)".*?src="(http.*?)" alt="(.*?)"',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
	aaCNAJdtsguSRELh2I,OQGDVkNEqh7ogv2I1STC = [],[]
	for MepIvHBYNArkUOdV37shtJ,Sj7rMNYRuQPTtkBvpHKeDW3h,title in items:
		if title==qpFY4hAwolV3: title = MepIvHBYNArkUOdV37shtJ.split(ShynO8pN9idCE3)[-1].replace('-',mIsDke0oK5x1zSiOWbF9thGcA)
		cgwB6jCZf0dy3zvNFuRn5qo = ePhmG1jLD6.findall('(\d+)',title,ePhmG1jLD6.DOTALL)
		if cgwB6jCZf0dy3zvNFuRn5qo: cgwB6jCZf0dy3zvNFuRn5qo = int(cgwB6jCZf0dy3zvNFuRn5qo[0])
		else: cgwB6jCZf0dy3zvNFuRn5qo = 0
		OQGDVkNEqh7ogv2I1STC.append([Sj7rMNYRuQPTtkBvpHKeDW3h,MepIvHBYNArkUOdV37shtJ,title,cgwB6jCZf0dy3zvNFuRn5qo])
	OQGDVkNEqh7ogv2I1STC = sorted(OQGDVkNEqh7ogv2I1STC, reverse=True, key=lambda key: key[3])
	for Sj7rMNYRuQPTtkBvpHKeDW3h,MepIvHBYNArkUOdV37shtJ,title,cgwB6jCZf0dy3zvNFuRn5qo in OQGDVkNEqh7ogv2I1STC:
		MepIvHBYNArkUOdV37shtJ = ddBxj51bhNtaK23lDyGMVw + MepIvHBYNArkUOdV37shtJ
		title = title.replace('مشاهدة مسلسل','مسلسل')
		title = title.replace('مشاهدة المسلسل','المسلسل')
		title = title.replace('مشاهدة فيلم','فيلم')
		title = title.replace('مشاهدة الفيلم','الفيلم')
		title = title.replace('مباشرة كواليتي',qpFY4hAwolV3)
		title = title.replace('عالية على العرب',qpFY4hAwolV3)
		title = title.replace('مشاهدة مباشرة',qpFY4hAwolV3)
		title = title.replace('اون لاين',qpFY4hAwolV3)
		title = title.replace('اونلاين',qpFY4hAwolV3)
		title = title.replace('بجودة عالية',qpFY4hAwolV3)
		title = title.replace('جودة عالية',qpFY4hAwolV3)
		title = title.replace('بدون تحميل',qpFY4hAwolV3)
		title = title.replace('على العرب',qpFY4hAwolV3)
		title = title.replace('مباشرة',qpFY4hAwolV3)
		title = title.strip(mIsDke0oK5x1zSiOWbF9thGcA).replace(r1roOXYi7UQw9FLThzPEdD0ZlvAnRc,mIsDke0oK5x1zSiOWbF9thGcA).replace(r1roOXYi7UQw9FLThzPEdD0ZlvAnRc,mIsDke0oK5x1zSiOWbF9thGcA)
		title = '_MOD_'+title
		UdbGw48M6rCHDRmea5qP91nKI = title
		if '/q/' in url and ('الحلقة' in title or 'الحلقه' in title):
			ZDTxRSMbW7PNz = ePhmG1jLD6.findall('(.*?) الحلقة \d+',title,ePhmG1jLD6.DOTALL)
			if ZDTxRSMbW7PNz: UdbGw48M6rCHDRmea5qP91nKI = ZDTxRSMbW7PNz[0]
		if UdbGw48M6rCHDRmea5qP91nKI not in aaCNAJdtsguSRELh2I:
			aaCNAJdtsguSRELh2I.append(UdbGw48M6rCHDRmea5qP91nKI)
			if '/q/' in url and ('الحلقة' in title or 'الحلقه' in title):
				x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+UdbGw48M6rCHDRmea5qP91nKI,MepIvHBYNArkUOdV37shtJ,13,Sj7rMNYRuQPTtkBvpHKeDW3h)
				u0eDOmMnFCiR = True
			elif 'series' in MepIvHBYNArkUOdV37shtJ:
				x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,11,Sj7rMNYRuQPTtkBvpHKeDW3h)
				u0eDOmMnFCiR = True
			else:
				x3WSXnKyPhjqfHG2UrtQs('video',wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,12,Sj7rMNYRuQPTtkBvpHKeDW3h)
				u0eDOmMnFCiR = True
	if u0eDOmMnFCiR:
		items = ePhmG1jLD6.findall('tsc_3d_button red.*?href="(.*?)" title="(.*?)"',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
		for MepIvHBYNArkUOdV37shtJ,i02wfPp5EM in items:
			url = ddBxj51bhNtaK23lDyGMVw + MepIvHBYNArkUOdV37shtJ
			x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+i02wfPp5EM,url,11)
	return
def v1gmfxDcRrWKQ(url):
	cmWl9dOKHPIy41iaXuxrY = GMqfDK9V4F8eTPE1pNOAaiYUbhr(kUz8c7OqsxuPFIGfwg,url,qpFY4hAwolV3,headers,True,'ALARAB-EPISODES-1st')
	ewzAB1OTpg7mEo65Vq8lZ4tLf = ePhmG1jLD6.findall('href="(/series.*?)"',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	WSQlG8mDhqsNe = ddBxj51bhNtaK23lDyGMVw+ewzAB1OTpg7mEo65Vq8lZ4tLf[0]
	MOTjA5H9XFs = c8U1BdtxOZS5FH(WSQlG8mDhqsNe)
	return
def mzcAeyplZV(url):
	U7V0BQZPxXqMbyJnRw6f = []
	cmWl9dOKHPIy41iaXuxrY = GMqfDK9V4F8eTPE1pNOAaiYUbhr(rGY36xBwT1bLZAngSfcWEIeXdQVNij,url,qpFY4hAwolV3,headers,True,'ALARAB-PLAY-1st')
	WSQlG8mDhqsNe = ePhmG1jLD6.findall('class="resp-iframe" src="(.*?)"',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	if WSQlG8mDhqsNe:
		WSQlG8mDhqsNe = WSQlG8mDhqsNe[0]
		CFevtSjzbpn = ePhmG1jLD6.findall('^(http.*?)(http.*?)$',WSQlG8mDhqsNe,ePhmG1jLD6.DOTALL)
		if CFevtSjzbpn:
			QrAXouklfYpzqd = CFevtSjzbpn[0][0]
			qWgjOLvRpPaKBrHeTs574,PPEOdc8TaAvgQpuI1hSG3 = CFevtSjzbpn[0][1].rsplit(ShynO8pN9idCE3,1)
			hhpztscnBD1GP = qWgjOLvRpPaKBrHeTs574+'?named=__watch'
			U7V0BQZPxXqMbyJnRw6f.append(hhpztscnBD1GP)
			y2SIoiHRUhNMmqPYjrwA3TWg69pxV = QrAXouklfYpzqd+PPEOdc8TaAvgQpuI1hSG3
		else:
			CC8IKXmYeo = GMqfDK9V4F8eTPE1pNOAaiYUbhr(KOyPvpEztYLaZRdMQJWxfTNFHbkg,WSQlG8mDhqsNe,qpFY4hAwolV3,headers,False,'ALARAB-PLAY-2nd')
			WSQlG8mDhqsNe = ePhmG1jLD6.findall('"src": "(.*?)"',CC8IKXmYeo,ePhmG1jLD6.DOTALL)
			if WSQlG8mDhqsNe:
				WSQlG8mDhqsNe = WSQlG8mDhqsNe[0]+'?named=__watch__m3u8'
				U7V0BQZPxXqMbyJnRw6f.append(WSQlG8mDhqsNe)
	pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('searchBox(.*?)<style>',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	if pfRkcVlLmUxo561g0A8qSbO:
		mVYdjvor6i4wZ8 = pfRkcVlLmUxo561g0A8qSbO[0]
		WSQlG8mDhqsNe = ePhmG1jLD6.findall('href="(.*?)"',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
		if WSQlG8mDhqsNe:
			WSQlG8mDhqsNe = WSQlG8mDhqsNe[0]+'?named=__watch'
			U7V0BQZPxXqMbyJnRw6f.append(WSQlG8mDhqsNe)
	import inVXFK46ET
	inVXFK46ET.q4qTJvuoQUzM3mZAtegy7IXdnb5wH(U7V0BQZPxXqMbyJnRw6f,Q8Q0IDc6PLZajJAdTntKUmSGXz,'video',url)
	return
def lBIkOei1Rv9P6pEg():
	cmWl9dOKHPIy41iaXuxrY = GMqfDK9V4F8eTPE1pNOAaiYUbhr(KOyPvpEztYLaZRdMQJWxfTNFHbkg,ddBxj51bhNtaK23lDyGMVw,qpFY4hAwolV3,headers,True,'ALARAB-RAMADAN-1st')
	pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('id="content_sec"(.*?)id="left_content"',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	mVYdjvor6i4wZ8 = pfRkcVlLmUxo561g0A8qSbO[0]
	items = ePhmG1jLD6.findall('href="(.*?)".*?>(.*?)<',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
	G2kdYnBc3arDUwslEx410T6tb87JI = ePhmG1jLD6.findall('/ramadan([0-9]+)/',str(items),ePhmG1jLD6.DOTALL)
	G2kdYnBc3arDUwslEx410T6tb87JI = G2kdYnBc3arDUwslEx410T6tb87JI[0]
	for MepIvHBYNArkUOdV37shtJ,title in items:
		url = ddBxj51bhNtaK23lDyGMVw+MepIvHBYNArkUOdV37shtJ
		title = title.strip(mIsDke0oK5x1zSiOWbF9thGcA)+mIsDke0oK5x1zSiOWbF9thGcA+G2kdYnBc3arDUwslEx410T6tb87JI
		x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+title,url,11)
	return
def PPqUACSE3VcGLTvw05jHy9JrFNW(search):
	search,LBylNhMdH6OV1qGk0tWiXFg3,showDialogs = LLm3sBXHPcnTDxdE5gt6hz0Wkp(search)
	if search==qpFY4hAwolV3: search = jXgARlWMLVFUBnvmZwI2o5()
	if search==qpFY4hAwolV3: return
	K7m9Otk3h1VYIN8rcP6jp2 = search.replace(mIsDke0oK5x1zSiOWbF9thGcA,'+')
	url = ddBxj51bhNtaK23lDyGMVw + "/q/" + K7m9Otk3h1VYIN8rcP6jp2
	MOTjA5H9XFs = c8U1BdtxOZS5FH(url)
	return