# -*- coding: utf-8 -*-
from pSfaryIjBo import *
Q8Q0IDc6PLZajJAdTntKUmSGXz = 'FARESKO'
wwSFijdVJn1QgHW = '_FSK_'
ddBxj51bhNtaK23lDyGMVw = i4bFG3rKE6.SITESURLS[Q8Q0IDc6PLZajJAdTntKUmSGXz][0]
YEIA19ehBwpNfPVzK = ['الرئيسية','يلا شوت']
def vTNE2Ck1sGnugJYW8y39aLcSH64U(mode,url,text):
	if   mode==990: MOTjA5H9XFs = nRVAZc4Dp8PSrGU3xBk()
	elif mode==991: MOTjA5H9XFs = c8U1BdtxOZS5FH(url,text)
	elif mode==992: MOTjA5H9XFs = mzcAeyplZV(url)
	elif mode==993: MOTjA5H9XFs = A8s6orYkjplw(url)
	elif mode==999: MOTjA5H9XFs = PPqUACSE3VcGLTvw05jHy9JrFNW(text)
	else: MOTjA5H9XFs = False
	return MOTjA5H9XFs
def nRVAZc4Dp8PSrGU3xBk():
	IAW0sh6So3NpqM = WWrExJZS3Bj4anOAkpv7(kUz8c7OqsxuPFIGfwg,'GET',ddBxj51bhNtaK23lDyGMVw,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,'FARESKO-MENU-1st')
	cmWl9dOKHPIy41iaXuxrY = IAW0sh6So3NpqM.content
	x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+'بحث في الموقع',qpFY4hAwolV3,999,qpFY4hAwolV3,qpFY4hAwolV3,'_REMEMBERRESULTS_')
	x3WSXnKyPhjqfHG2UrtQs('link',xupTj02bvy3O8R+' ===== ===== ===== '+fF4lt9zWYxXLKZVyAco82PgMj,qpFY4hAwolV3,9999)
	pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('"primary-links"(.*?)</u',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	if pfRkcVlLmUxo561g0A8qSbO:
		mVYdjvor6i4wZ8 = pfRkcVlLmUxo561g0A8qSbO[0]
		items = ePhmG1jLD6.findall('href="(.*?)".*?<span>(.*?)<',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
		for MepIvHBYNArkUOdV37shtJ,title in items:
			if title in YEIA19ehBwpNfPVzK: continue
			x3WSXnKyPhjqfHG2UrtQs('folder',Q8Q0IDc6PLZajJAdTntKUmSGXz+'_SCRIPT_'+wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,991)
	pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('"list-categories"(.*?)</u',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	if pfRkcVlLmUxo561g0A8qSbO:
		mVYdjvor6i4wZ8 = pfRkcVlLmUxo561g0A8qSbO[0]
		items = ePhmG1jLD6.findall('href="(.*?)".*?>(.*?)<',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
		for MepIvHBYNArkUOdV37shtJ,title in items:
			if 'http' not in MepIvHBYNArkUOdV37shtJ: MepIvHBYNArkUOdV37shtJ = ddBxj51bhNtaK23lDyGMVw+ShynO8pN9idCE3+MepIvHBYNArkUOdV37shtJ.lstrip(ShynO8pN9idCE3)
			if title in YEIA19ehBwpNfPVzK: continue
			x3WSXnKyPhjqfHG2UrtQs('folder',Q8Q0IDc6PLZajJAdTntKUmSGXz+'_SCRIPT_'+wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,991)
	return
def c8U1BdtxOZS5FH(url,type=qpFY4hAwolV3):
	IAW0sh6So3NpqM = WWrExJZS3Bj4anOAkpv7(kUz8c7OqsxuPFIGfwg,'GET',url,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,'FARESKO-TITLES-1st')
	cmWl9dOKHPIy41iaXuxrY = IAW0sh6So3NpqM.content
	pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('"home-content"(.*?)"footer"',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	if pfRkcVlLmUxo561g0A8qSbO:
		mVYdjvor6i4wZ8 = pfRkcVlLmUxo561g0A8qSbO[0]
		mVYdjvor6i4wZ8 = mVYdjvor6i4wZ8.replace('"overlay"','"duration"><')
		items = ePhmG1jLD6.findall('"thumb".*?data-src="(.*?)".*?"duration">(.*?)<.*?href="(.*?)">(.*?)<',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
		aaCNAJdtsguSRELh2I = []
		for Sj7rMNYRuQPTtkBvpHKeDW3h,dq0kBrGuKXiP,MepIvHBYNArkUOdV37shtJ,title in items:
			title = title.strip(' ')
			title = j8PDV0pthfSTidZbsQxNIOmCYKWzH(title)
			ZDTxRSMbW7PNz = ePhmG1jLD6.findall('(.*?) (الحلقة|حلقة).\d+',title,ePhmG1jLD6.DOTALL)
			if 'episodes' not in type and ZDTxRSMbW7PNz:
				title = '_MOD_' + ZDTxRSMbW7PNz[0][0]
				title = title.replace('اون لاين',qpFY4hAwolV3)
				if title not in aaCNAJdtsguSRELh2I:
					x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,993,Sj7rMNYRuQPTtkBvpHKeDW3h)
					aaCNAJdtsguSRELh2I.append(title)
			else: x3WSXnKyPhjqfHG2UrtQs('video',wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,992,Sj7rMNYRuQPTtkBvpHKeDW3h,dq0kBrGuKXiP)
	pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('''["']pagination["'](.*?)["']footer["']''',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	if pfRkcVlLmUxo561g0A8qSbO:
		type = 'episodes_pages' if 'episodes' in type else 'pages'
		mVYdjvor6i4wZ8 = pfRkcVlLmUxo561g0A8qSbO[0]
		items = ePhmG1jLD6.findall('href="(.*?)">(.*?)</a>',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
		for MepIvHBYNArkUOdV37shtJ,title in items:
			title = j8PDV0pthfSTidZbsQxNIOmCYKWzH(title)
			x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+'صفحة '+title,MepIvHBYNArkUOdV37shtJ,991,qpFY4hAwolV3,qpFY4hAwolV3,type)
	else:
		MepIvHBYNArkUOdV37shtJ = ePhmG1jLD6.findall('load-next-button" href="(.*?)"',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
		if MepIvHBYNArkUOdV37shtJ: x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+'صفحة جديدة',MepIvHBYNArkUOdV37shtJ[0],991,qpFY4hAwolV3,qpFY4hAwolV3,type)
	return
def A8s6orYkjplw(url):
	IAW0sh6So3NpqM = WWrExJZS3Bj4anOAkpv7(kUz8c7OqsxuPFIGfwg,'GET',url,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,'FARESKO-SERIES-1st')
	cmWl9dOKHPIy41iaXuxrY = IAW0sh6So3NpqM.content
	pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('class="eplist"(.*?)</div>',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	if pfRkcVlLmUxo561g0A8qSbO:
		mVYdjvor6i4wZ8 = pfRkcVlLmUxo561g0A8qSbO[0]
		pzLc3HwImv2dru = ePhmG1jLD6.findall('href="(.*?)" title="(.*?)"',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
		for MepIvHBYNArkUOdV37shtJ,title in pzLc3HwImv2dru:
			title = j8PDV0pthfSTidZbsQxNIOmCYKWzH(title)
			x3WSXnKyPhjqfHG2UrtQs('video',wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,992)
	else:
		MepIvHBYNArkUOdV37shtJ = ePhmG1jLD6.findall('"category".*?href="(.*?)"',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
		if MepIvHBYNArkUOdV37shtJ:
			MepIvHBYNArkUOdV37shtJ = MepIvHBYNArkUOdV37shtJ[0]
			c8U1BdtxOZS5FH(MepIvHBYNArkUOdV37shtJ,'episodes')
	return
def mzcAeyplZV(url):
	tiYp9ZdbFTQMcB4vWkHw6LXIAKrN5m,MB4EzZDuWCJ8FnO9jiGNsroX = [],[]
	IAW0sh6So3NpqM = WWrExJZS3Bj4anOAkpv7(kUz8c7OqsxuPFIGfwg,'GET',url,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,'FARESKO-PLAY-1st')
	cmWl9dOKHPIy41iaXuxrY = IAW0sh6So3NpqM.content
	if 'hash=' in cmWl9dOKHPIy41iaXuxrY:
		Mf3gbyoXh76vBNqES0lIYT = ePhmG1jLD6.findall('hash=(.*?)"',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
		Mf3gbyoXh76vBNqES0lIYT = list(set(Mf3gbyoXh76vBNqES0lIYT))
		for xfBMzb7ZqP2k in Mf3gbyoXh76vBNqES0lIYT:
			IB7VdUhrvGQFYHcClJgP = []
			ooc63dKJAxDM = xfBMzb7ZqP2k.split('__')
			for uRYx1yjMJDr in ooc63dKJAxDM:
				try:
					uRYx1yjMJDr = PP0Gxazjw86.b64decode(uRYx1yjMJDr+'=')
					if DLod2Of8CkRrtzJynev: uRYx1yjMJDr = uRYx1yjMJDr.decode(nV3Tip6XsH1rJw79DPOU)
					IB7VdUhrvGQFYHcClJgP.append(uRYx1yjMJDr)
				except: pass
			CFevtSjzbpn = '>'.join(IB7VdUhrvGQFYHcClJgP)
			CFevtSjzbpn = CFevtSjzbpn.splitlines()
			for MepIvHBYNArkUOdV37shtJ in CFevtSjzbpn:
				if ' => ' in MepIvHBYNArkUOdV37shtJ:
					title,MepIvHBYNArkUOdV37shtJ = MepIvHBYNArkUOdV37shtJ.split(' => ')
					tiYp9ZdbFTQMcB4vWkHw6LXIAKrN5m.append(MepIvHBYNArkUOdV37shtJ+'?named='+title+'__watch')
	elif 'post_id' in cmWl9dOKHPIy41iaXuxrY:
		ed5GKJzygXNsS6il2 = ePhmG1jLD6.findall("post_id = '(.*?)'",cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
		if ed5GKJzygXNsS6il2:
			ed5GKJzygXNsS6il2 = ed5GKJzygXNsS6il2[0]
			headers = {'X-Requested-With':'XMLHttpRequest'}
			SPhHAEby41Wa = ePhmG1jLD6.findall('"video-play-button" href="(.*?)"',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
			if SPhHAEby41Wa: headers.update({'Referer':SPhHAEby41Wa[0]})
			MMd9xVz64U = ddBxj51bhNtaK23lDyGMVw+'/wp-admin/admin-ajax.php?action=video_info&post_id='+ed5GKJzygXNsS6il2
			IAW0sh6So3NpqM = WWrExJZS3Bj4anOAkpv7(kUz8c7OqsxuPFIGfwg,'GET',MMd9xVz64U,qpFY4hAwolV3,headers,qpFY4hAwolV3,qpFY4hAwolV3,'FARESKO-PLAY-2nd')
			kkPMOGloXs5cpZ3d0uJRvmNfLEBQ = IAW0sh6So3NpqM.content
			zQuviwM0CoJTmeZPDW = ePhmG1jLD6.findall('"name":"(.*?)","src":"(.*?)"',kkPMOGloXs5cpZ3d0uJRvmNfLEBQ,ePhmG1jLD6.DOTALL)
			if not zQuviwM0CoJTmeZPDW:
				zQuviwM0CoJTmeZPDW = ePhmG1jLD6.findall('"src":"(.*?)"',kkPMOGloXs5cpZ3d0uJRvmNfLEBQ,ePhmG1jLD6.DOTALL)
				if zQuviwM0CoJTmeZPDW:
					sNRBdIJzmC9l3OAw = ['']*len(zQuviwM0CoJTmeZPDW)
					zQuviwM0CoJTmeZPDW = list(zip(sNRBdIJzmC9l3OAw,zQuviwM0CoJTmeZPDW))
			for name,MepIvHBYNArkUOdV37shtJ in zQuviwM0CoJTmeZPDW:
				MepIvHBYNArkUOdV37shtJ = MepIvHBYNArkUOdV37shtJ.replace('\\/',ShynO8pN9idCE3)
				MepIvHBYNArkUOdV37shtJ = BUKlErdIu7Ggqcz3jYpf09wMePF4V(MepIvHBYNArkUOdV37shtJ)
				if MepIvHBYNArkUOdV37shtJ in MB4EzZDuWCJ8FnO9jiGNsroX: continue
				else: MB4EzZDuWCJ8FnO9jiGNsroX.append(MepIvHBYNArkUOdV37shtJ)
				tiYp9ZdbFTQMcB4vWkHw6LXIAKrN5m.append(MepIvHBYNArkUOdV37shtJ+'?named='+name+'__watch')
			OexQX2mTwfGkuU6AIBLz9vWlHjdF8 = ddBxj51bhNtaK23lDyGMVw+'/wp-admin/admin-ajax.php?action=mwp_generate_video_download_link&post_id='+ed5GKJzygXNsS6il2+'&video_id=null&video_url=null&video_source=custom'
			IAW0sh6So3NpqM = WWrExJZS3Bj4anOAkpv7(kUz8c7OqsxuPFIGfwg,'GET',OexQX2mTwfGkuU6AIBLz9vWlHjdF8,qpFY4hAwolV3,headers,qpFY4hAwolV3,qpFY4hAwolV3,'FARESKO-PLAY-3rd')
			CC8IKXmYeo = IAW0sh6So3NpqM.content
			DWOH2QwVRdhefgNi5BTCn = ePhmG1jLD6.findall('href="(.*?)".*?>(.*?)<',CC8IKXmYeo,ePhmG1jLD6.DOTALL)
			if DWOH2QwVRdhefgNi5BTCn:
				jj7hKRuXHyOinQ6da4z9,x0ToJ6E8tGiulMyN = zip(*DWOH2QwVRdhefgNi5BTCn)
				DWOH2QwVRdhefgNi5BTCn = list(zip(x0ToJ6E8tGiulMyN,jj7hKRuXHyOinQ6da4z9))
			for name,MepIvHBYNArkUOdV37shtJ in DWOH2QwVRdhefgNi5BTCn:
				MepIvHBYNArkUOdV37shtJ = MepIvHBYNArkUOdV37shtJ.replace('\\/',ShynO8pN9idCE3)
				MepIvHBYNArkUOdV37shtJ = BUKlErdIu7Ggqcz3jYpf09wMePF4V(MepIvHBYNArkUOdV37shtJ)
				if MepIvHBYNArkUOdV37shtJ in MB4EzZDuWCJ8FnO9jiGNsroX: continue
				else: MB4EzZDuWCJ8FnO9jiGNsroX.append(MepIvHBYNArkUOdV37shtJ)
				tiYp9ZdbFTQMcB4vWkHw6LXIAKrN5m.append(MepIvHBYNArkUOdV37shtJ+'?named='+name+'__download')
	import inVXFK46ET
	inVXFK46ET.q4qTJvuoQUzM3mZAtegy7IXdnb5wH(tiYp9ZdbFTQMcB4vWkHw6LXIAKrN5m,Q8Q0IDc6PLZajJAdTntKUmSGXz,'video',url)
	return
def PPqUACSE3VcGLTvw05jHy9JrFNW(search):
	search,LBylNhMdH6OV1qGk0tWiXFg3,showDialogs = LLm3sBXHPcnTDxdE5gt6hz0Wkp(search)
	if search==qpFY4hAwolV3: search = jXgARlWMLVFUBnvmZwI2o5()
	if search==qpFY4hAwolV3: return
	search = search.replace(mIsDke0oK5x1zSiOWbF9thGcA,'+')
	url = ddBxj51bhNtaK23lDyGMVw+'/?s='+search
	c8U1BdtxOZS5FH(url,'search')
	return