# -*- coding: utf-8 -*-
from pSfaryIjBo import *
Q8Q0IDc6PLZajJAdTntKUmSGXz = 'BRSTEJ'
wwSFijdVJn1QgHW = '_BRS_'
ddBxj51bhNtaK23lDyGMVw = i4bFG3rKE6.SITESURLS[Q8Q0IDc6PLZajJAdTntKUmSGXz][0]
YEIA19ehBwpNfPVzK = ['Sign in','الاقسام','عرض المزيد','download']
def vTNE2Ck1sGnugJYW8y39aLcSH64U(mode,url,text):
	if   mode==650: MOTjA5H9XFs = nRVAZc4Dp8PSrGU3xBk()
	elif mode==651: MOTjA5H9XFs = c8U1BdtxOZS5FH(url,text)
	elif mode==652: MOTjA5H9XFs = mzcAeyplZV(url)
	elif mode==653: MOTjA5H9XFs = PXEsuKvq5fS438YWFh7gBCdrw(url,text)
	elif mode==654: MOTjA5H9XFs = X2rO3lubqIdCGMLYWcxA6DK5(url)
	elif mode==659: MOTjA5H9XFs = PPqUACSE3VcGLTvw05jHy9JrFNW(text)
	else: MOTjA5H9XFs = False
	return MOTjA5H9XFs
def nRVAZc4Dp8PSrGU3xBk():
	IAW0sh6So3NpqM = WWrExJZS3Bj4anOAkpv7(kUz8c7OqsxuPFIGfwg,'GET',ddBxj51bhNtaK23lDyGMVw,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,'BRSTEJ-MENU-1st')
	cmWl9dOKHPIy41iaXuxrY = IAW0sh6So3NpqM.content
	x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+'بحث في الموقع',qpFY4hAwolV3,659,qpFY4hAwolV3,qpFY4hAwolV3,'_REMEMBERRESULTS_')
	x3WSXnKyPhjqfHG2UrtQs('link',xupTj02bvy3O8R+' ===== ===== ===== '+fF4lt9zWYxXLKZVyAco82PgMj,qpFY4hAwolV3,9999)
	items = ePhmG1jLD6.findall('<h2>(.*?)</h2>',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	for nnZ13Rr6tYXio0DyfLVvSxBec,title in enumerate(items):
		x3WSXnKyPhjqfHG2UrtQs('folder',Q8Q0IDc6PLZajJAdTntKUmSGXz+'_SCRIPT_'+wwSFijdVJn1QgHW+title,ddBxj51bhNtaK23lDyGMVw,651,qpFY4hAwolV3,qpFY4hAwolV3,str(nnZ13Rr6tYXio0DyfLVvSxBec))
	x3WSXnKyPhjqfHG2UrtQs('link',xupTj02bvy3O8R+' ===== ===== ===== '+fF4lt9zWYxXLKZVyAco82PgMj,qpFY4hAwolV3,9999)
	pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('"menu-section-list"(.*?)</ul>',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	mVYdjvor6i4wZ8 = pfRkcVlLmUxo561g0A8qSbO[0]
	items = ePhmG1jLD6.findall('href="(.*?)">(.*?)</',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
	for MepIvHBYNArkUOdV37shtJ,title in items:
		if title in YEIA19ehBwpNfPVzK: continue
		if 'لاحقا' in title or 'مثال' in title: continue
		title = title.replace('<b>',qpFY4hAwolV3).strip(mIsDke0oK5x1zSiOWbF9thGcA)
		x3WSXnKyPhjqfHG2UrtQs('folder',Q8Q0IDc6PLZajJAdTntKUmSGXz+'_SCRIPT_'+wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,651)
	return
def X2rO3lubqIdCGMLYWcxA6DK5(url):
	IAW0sh6So3NpqM = WWrExJZS3Bj4anOAkpv7(kUz8c7OqsxuPFIGfwg,'GET',url,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,'BRSTEJ-SUBMENU-1st')
	cmWl9dOKHPIy41iaXuxrY = IAW0sh6So3NpqM.content
	NDnI9Qrpt5c8MU = ePhmG1jLD6.findall('"caret"(.*?)</ul>',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	if NDnI9Qrpt5c8MU:
		mVYdjvor6i4wZ8 = NDnI9Qrpt5c8MU[0]
		mVYdjvor6i4wZ8 = mVYdjvor6i4wZ8.replace('"presentation"','</ul>')
		pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('"dropdown-header">(.*?)</li>(.*?)</ul>',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
		if not pfRkcVlLmUxo561g0A8qSbO: pfRkcVlLmUxo561g0A8qSbO = [(qpFY4hAwolV3,mVYdjvor6i4wZ8)]
		x3WSXnKyPhjqfHG2UrtQs('link',xupTj02bvy3O8R+' فرز أو فلتر أو ترتيب '+fF4lt9zWYxXLKZVyAco82PgMj,qpFY4hAwolV3,9999)
		for YirSOX5nC0jPyvFTN48sHE1,mVYdjvor6i4wZ8 in pfRkcVlLmUxo561g0A8qSbO:
			items = ePhmG1jLD6.findall('href="(.*?)".*?>(.*?)</a>',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
			if YirSOX5nC0jPyvFTN48sHE1: YirSOX5nC0jPyvFTN48sHE1 = YirSOX5nC0jPyvFTN48sHE1+': '
			for MepIvHBYNArkUOdV37shtJ,title in items:
				title = YirSOX5nC0jPyvFTN48sHE1+title
				x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,651)
	T9TAc28ayKvFgjfd6SD = ePhmG1jLD6.findall('"pm-category-subcats"(.*?)</ul>',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	if T9TAc28ayKvFgjfd6SD:
		mVYdjvor6i4wZ8 = T9TAc28ayKvFgjfd6SD[0]
		items = ePhmG1jLD6.findall('href="(.*?)">(.*?)</a>',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
		if len(items)<30:
			x3WSXnKyPhjqfHG2UrtQs('link',xupTj02bvy3O8R+' ===== ===== ===== '+fF4lt9zWYxXLKZVyAco82PgMj,qpFY4hAwolV3,9999)
			for MepIvHBYNArkUOdV37shtJ,title in items:
				x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,651)
	if not NDnI9Qrpt5c8MU and not T9TAc28ayKvFgjfd6SD: c8U1BdtxOZS5FH(url)
	return
def c8U1BdtxOZS5FH(url,AMbRf4XTpQNvio6J5GELducy0k=qpFY4hAwolV3):
	if AMbRf4XTpQNvio6J5GELducy0k=='ajax-search':
		url,search = url.split('?',1)
		data = 'queryString='+search
		headers = {'Content-Type':'application/x-www-form-urlencoded; charset=UTF-8'}
		IAW0sh6So3NpqM = WWrExJZS3Bj4anOAkpv7(kUz8c7OqsxuPFIGfwg,'POST',url,data,headers,qpFY4hAwolV3,qpFY4hAwolV3,'BRSTEJ-TITLES-1st')
	else:
		IAW0sh6So3NpqM = WWrExJZS3Bj4anOAkpv7(kUz8c7OqsxuPFIGfwg,'GET',url,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,'BRSTEJ-TITLES-2nd')
	cmWl9dOKHPIy41iaXuxrY = IAW0sh6So3NpqM.content
	mVYdjvor6i4wZ8,items = qpFY4hAwolV3,[]
	iipsGz2LKq = AWeJuo2LhZ5xiD8KNSqd9G0rtT74FE(url,'url')
	if AMbRf4XTpQNvio6J5GELducy0k=='ajax-search':
		mVYdjvor6i4wZ8 = cmWl9dOKHPIy41iaXuxrY
		eKEo1iY0x8kAcU76ChWaypzHIwlRMq = ePhmG1jLD6.findall('href="(.*?)">(.*?)</a>',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
		for MepIvHBYNArkUOdV37shtJ,title in eKEo1iY0x8kAcU76ChWaypzHIwlRMq: items.append((qpFY4hAwolV3,MepIvHBYNArkUOdV37shtJ,title))
	elif AMbRf4XTpQNvio6J5GELducy0k=='featured':
		pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('"pm-video-watch-featured"(.*?)</ul>',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
		if pfRkcVlLmUxo561g0A8qSbO: mVYdjvor6i4wZ8 = pfRkcVlLmUxo561g0A8qSbO[0]
	elif AMbRf4XTpQNvio6J5GELducy0k=='new_episodes':
		pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('"row pm-ul-browse-videos(.*?)</ul>',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
		if pfRkcVlLmUxo561g0A8qSbO: mVYdjvor6i4wZ8 = pfRkcVlLmUxo561g0A8qSbO[0]
	elif AMbRf4XTpQNvio6J5GELducy0k=='new_movies':
		pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('"row pm-ul-browse-videos(.*?)</ul>',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
		if len(pfRkcVlLmUxo561g0A8qSbO)>1: mVYdjvor6i4wZ8 = pfRkcVlLmUxo561g0A8qSbO[1]
	elif AMbRf4XTpQNvio6J5GELducy0k=='featured_series':
		pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('"ba mgb table full"(.*?)"clearfix"',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
		if pfRkcVlLmUxo561g0A8qSbO: mVYdjvor6i4wZ8 = pfRkcVlLmUxo561g0A8qSbO[0]
		eKEo1iY0x8kAcU76ChWaypzHIwlRMq = ePhmG1jLD6.findall('href="(.*?)" title="(.*?)"',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
		for MepIvHBYNArkUOdV37shtJ,title in eKEo1iY0x8kAcU76ChWaypzHIwlRMq: items.append((qpFY4hAwolV3,MepIvHBYNArkUOdV37shtJ,title))
	elif AMbRf4XTpQNvio6J5GELducy0k.isdigit():
		pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('<h2>(.*?)</ul>',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
		mVYdjvor6i4wZ8 = pfRkcVlLmUxo561g0A8qSbO[int(AMbRf4XTpQNvio6J5GELducy0k)]
	else:
		pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('"home-container"(.*?)"footer"',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
		if pfRkcVlLmUxo561g0A8qSbO: mVYdjvor6i4wZ8 = pfRkcVlLmUxo561g0A8qSbO[0]
	if mVYdjvor6i4wZ8 and not items: items = ePhmG1jLD6.findall('class="thumb".*?href="(.*?)".*?alt="(.*?)".*?data-src="(.*?)"',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
	if not items: return
	aaCNAJdtsguSRELh2I = []
	WGid3I2kFU = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم','مسرحية']
	for MepIvHBYNArkUOdV37shtJ,title,Sj7rMNYRuQPTtkBvpHKeDW3h in items:
		title = title.strip(mIsDke0oK5x1zSiOWbF9thGcA)
		ZDTxRSMbW7PNz = ePhmG1jLD6.findall('(.*?) (الحلقة|حلقة).\d+',title,ePhmG1jLD6.DOTALL)
		if any(value in title for value in WGid3I2kFU):
			x3WSXnKyPhjqfHG2UrtQs('video',wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,652,Sj7rMNYRuQPTtkBvpHKeDW3h)
		elif AMbRf4XTpQNvio6J5GELducy0k=='new_episodes':
			x3WSXnKyPhjqfHG2UrtQs('video',wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,652,Sj7rMNYRuQPTtkBvpHKeDW3h)
		elif ZDTxRSMbW7PNz:
			title = '_MOD_' + ZDTxRSMbW7PNz[0][0]
			if title not in aaCNAJdtsguSRELh2I:
				x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,653,Sj7rMNYRuQPTtkBvpHKeDW3h)
				aaCNAJdtsguSRELh2I.append(title)
		else: x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,653,Sj7rMNYRuQPTtkBvpHKeDW3h)
	if 1:
		pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall("class='pages'(.*?)</div>",cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
		if pfRkcVlLmUxo561g0A8qSbO:
			mVYdjvor6i4wZ8 = pfRkcVlLmUxo561g0A8qSbO[0]
			items = ePhmG1jLD6.findall('href="(.*?)".*?>(.*?)<',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
			for MepIvHBYNArkUOdV37shtJ,title in items:
				MepIvHBYNArkUOdV37shtJ = MepIvHBYNArkUOdV37shtJ.strip(ShynO8pN9idCE3)
				title = j8PDV0pthfSTidZbsQxNIOmCYKWzH(title)
				x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+'صفحة '+title,MepIvHBYNArkUOdV37shtJ,651)
	return
def PXEsuKvq5fS438YWFh7gBCdrw(url,MaNXbtkeElTRsiK6c1u):
	iipsGz2LKq = AWeJuo2LhZ5xiD8KNSqd9G0rtT74FE(url,'url')
	IAW0sh6So3NpqM = WWrExJZS3Bj4anOAkpv7(kUz8c7OqsxuPFIGfwg,'GET',url,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,'BRSTEJ-EPISODES-1st')
	cmWl9dOKHPIy41iaXuxrY = IAW0sh6So3NpqM.content
	BvbuigUeoJLnTaN2qWxQ415AtYMK9I = ePhmG1jLD6.findall('og:image" content="(.*?)"',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	Sj7rMNYRuQPTtkBvpHKeDW3h = BvbuigUeoJLnTaN2qWxQ415AtYMK9I[0] if BvbuigUeoJLnTaN2qWxQ415AtYMK9I else qpFY4hAwolV3
	pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('"EpisodesList"(.*?)</div>',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	ptoEQ3JduNXrT9AOkCezWmaLB,a3zLRdlm0hBcJe7UC5 = qpFY4hAwolV3,qpFY4hAwolV3
	if len(pfRkcVlLmUxo561g0A8qSbO)==2: ptoEQ3JduNXrT9AOkCezWmaLB,a3zLRdlm0hBcJe7UC5 = pfRkcVlLmUxo561g0A8qSbO
	elif len(pfRkcVlLmUxo561g0A8qSbO)==1: a3zLRdlm0hBcJe7UC5 = pfRkcVlLmUxo561g0A8qSbO[vvXoMLlg513]
	items = []
	BfsF3ItbJ17Mndmy = False
	if ptoEQ3JduNXrT9AOkCezWmaLB and not MaNXbtkeElTRsiK6c1u:
		items = ePhmG1jLD6.findall('href="(.*?)".*?>(.*?)<',ptoEQ3JduNXrT9AOkCezWmaLB,ePhmG1jLD6.DOTALL)
		for MepIvHBYNArkUOdV37shtJ,title in items:
			if len(items)>1: x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,653,Sj7rMNYRuQPTtkBvpHKeDW3h,qpFY4hAwolV3,MaNXbtkeElTRsiK6c1u)
			else: BfsF3ItbJ17Mndmy = True
	else: BfsF3ItbJ17Mndmy = True
	if a3zLRdlm0hBcJe7UC5:
		items = ePhmG1jLD6.findall('href="(.*?)".*?>(.*?)<',a3zLRdlm0hBcJe7UC5,ePhmG1jLD6.DOTALL)
		for MepIvHBYNArkUOdV37shtJ,title in items:
			title = title.strip()
			MepIvHBYNArkUOdV37shtJ = MepIvHBYNArkUOdV37shtJ.strip(ShynO8pN9idCE3)
			x3WSXnKyPhjqfHG2UrtQs('video',wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,652,Sj7rMNYRuQPTtkBvpHKeDW3h)
	return
def mzcAeyplZV(url):
	tiYp9ZdbFTQMcB4vWkHw6LXIAKrN5m = []
	WSQlG8mDhqsNe = url+'/play'
	IAW0sh6So3NpqM = WWrExJZS3Bj4anOAkpv7(kUz8c7OqsxuPFIGfwg,'GET',WSQlG8mDhqsNe,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,'BRSTEJ-PLAY-1st')
	cmWl9dOKHPIy41iaXuxrY = IAW0sh6So3NpqM.content
	pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('<iframe id="main-iframe"(.*?)</iframe>',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	if pfRkcVlLmUxo561g0A8qSbO:
		mVYdjvor6i4wZ8 = pfRkcVlLmUxo561g0A8qSbO[0]
		MepIvHBYNArkUOdV37shtJ = ePhmG1jLD6.findall('src="(.*?)"',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
		if MepIvHBYNArkUOdV37shtJ:
			MepIvHBYNArkUOdV37shtJ = MepIvHBYNArkUOdV37shtJ[0]
			tiYp9ZdbFTQMcB4vWkHw6LXIAKrN5m.append(MepIvHBYNArkUOdV37shtJ+'?named=__embed')
	pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('class="vp-sources(.*?)</div>',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	if pfRkcVlLmUxo561g0A8qSbO:
		mVYdjvor6i4wZ8 = pfRkcVlLmUxo561g0A8qSbO[0]
		CFevtSjzbpn = ePhmG1jLD6.findall('data-url="(.*?)">(.*?)<',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
		for MepIvHBYNArkUOdV37shtJ,title in CFevtSjzbpn:
			if MepIvHBYNArkUOdV37shtJ not in tiYp9ZdbFTQMcB4vWkHw6LXIAKrN5m: tiYp9ZdbFTQMcB4vWkHw6LXIAKrN5m.append(MepIvHBYNArkUOdV37shtJ+'?named='+title.strip()+'__watch')
	c1QSXTU8ntIz6FK4xrE = ePhmG1jLD6.findall('class="Download".*?href="(.*?)"',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	if c1QSXTU8ntIz6FK4xrE:
		WSQlG8mDhqsNe = c1QSXTU8ntIz6FK4xrE[0]
		IAW0sh6So3NpqM = WWrExJZS3Bj4anOAkpv7(kUz8c7OqsxuPFIGfwg,'GET',WSQlG8mDhqsNe,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,'BRSTEJ-PLAY-2nd')
		cmWl9dOKHPIy41iaXuxrY = IAW0sh6So3NpqM.content
		pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('class="download-grid"(.*?)</div>',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
		if pfRkcVlLmUxo561g0A8qSbO:
			mVYdjvor6i4wZ8 = pfRkcVlLmUxo561g0A8qSbO[0]
			CFevtSjzbpn = ePhmG1jLD6.findall('href="(.*?)">(.*?)<',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
			for MepIvHBYNArkUOdV37shtJ,title in CFevtSjzbpn:
				if MepIvHBYNArkUOdV37shtJ not in tiYp9ZdbFTQMcB4vWkHw6LXIAKrN5m: tiYp9ZdbFTQMcB4vWkHw6LXIAKrN5m.append(MepIvHBYNArkUOdV37shtJ+'?named='+title.strip()+'__download')
	import inVXFK46ET
	inVXFK46ET.q4qTJvuoQUzM3mZAtegy7IXdnb5wH(tiYp9ZdbFTQMcB4vWkHw6LXIAKrN5m,Q8Q0IDc6PLZajJAdTntKUmSGXz,'video',url)
	return
def PPqUACSE3VcGLTvw05jHy9JrFNW(search):
	search,LBylNhMdH6OV1qGk0tWiXFg3,showDialogs = LLm3sBXHPcnTDxdE5gt6hz0Wkp(search)
	if search==qpFY4hAwolV3: search = jXgARlWMLVFUBnvmZwI2o5()
	if search==qpFY4hAwolV3: return
	search = search.replace(mIsDke0oK5x1zSiOWbF9thGcA,'+')
	url = ddBxj51bhNtaK23lDyGMVw+'/?s='+search
	c8U1BdtxOZS5FH(url,'search')
	return