﻿# -*- coding: utf-8 -*-
from pSfaryIjBo import *
def vTNE2Ck1sGnugJYW8y39aLcSH64U(ZyiMa3BXVk2xWG0b,DD7oZxRwSW9pQ):
	if DD7oZxRwSW9pQ==qpFY4hAwolV3: return
	if ZyiMa3BXVk2xWG0b==1:
		OkRt1mN0ZhW7EXcMpYaQgSB9x = q5Kah0DftjNzV.getCurrentWindowDialogId()
		oQfLyVaD2zJgOEvX9 = q5Kah0DftjNzV.Window(OkRt1mN0ZhW7EXcMpYaQgSB9x)
		DD7oZxRwSW9pQ = qZ5W2HkliSK9CN(DD7oZxRwSW9pQ)
		oQfLyVaD2zJgOEvX9.getControl(311).setLabel(DD7oZxRwSW9pQ)
	if ZyiMa3BXVk2xWG0b==0:
		kc8s5wJ4Px9zbiWQm='X'
		if DLod2Of8CkRrtzJynev: qu0viGIZJFnK2Y3EcrSPTHNBh9 = isinstance(DD7oZxRwSW9pQ,str)
		else: qu0viGIZJFnK2Y3EcrSPTHNBh9 = isinstance(DD7oZxRwSW9pQ,unicode)
		if qu0viGIZJFnK2Y3EcrSPTHNBh9==True: kc8s5wJ4Px9zbiWQm='U'
		U8U4YGOgki9XIZ=str(type(DD7oZxRwSW9pQ))+mIsDke0oK5x1zSiOWbF9thGcA+DD7oZxRwSW9pQ+mIsDke0oK5x1zSiOWbF9thGcA+kc8s5wJ4Px9zbiWQm+mIsDke0oK5x1zSiOWbF9thGcA
		for a2jQ83ZCfcM5 in range(0,len(DD7oZxRwSW9pQ),1):
			U8U4YGOgki9XIZ += hex(ord(DD7oZxRwSW9pQ[a2jQ83ZCfcM5])).replace('0x',qpFY4hAwolV3)+mIsDke0oK5x1zSiOWbF9thGcA
		DD7oZxRwSW9pQ = qZ5W2HkliSK9CN(DD7oZxRwSW9pQ)
		kc8s5wJ4Px9zbiWQm='X'
		if DLod2Of8CkRrtzJynev: qu0viGIZJFnK2Y3EcrSPTHNBh9 = isinstance(DD7oZxRwSW9pQ, str)
		else: qu0viGIZJFnK2Y3EcrSPTHNBh9 = isinstance(DD7oZxRwSW9pQ, unicode)
		if qu0viGIZJFnK2Y3EcrSPTHNBh9==True: kc8s5wJ4Px9zbiWQm='U'
		rExb1B9DN26Zq=str(type(DD7oZxRwSW9pQ))+mIsDke0oK5x1zSiOWbF9thGcA+DD7oZxRwSW9pQ+mIsDke0oK5x1zSiOWbF9thGcA+kc8s5wJ4Px9zbiWQm+mIsDke0oK5x1zSiOWbF9thGcA
		for a2jQ83ZCfcM5 in range(0,len(DD7oZxRwSW9pQ),1):
			rExb1B9DN26Zq += hex(ord(DD7oZxRwSW9pQ[a2jQ83ZCfcM5])).replace('0x',qpFY4hAwolV3)+mIsDke0oK5x1zSiOWbF9thGcA
	return