# -*- coding: utf-8 -*-
from pSfaryIjBo import *
Q8Q0IDc6PLZajJAdTntKUmSGXz = 'GOOGLESEARCH'
wwSFijdVJn1QgHW = '_GOS_'
def vTNE2Ck1sGnugJYW8y39aLcSH64U(ZyiMa3BXVk2xWG0b,WWowRmHkj1ZAO2SUhtNvdrcKa9E6C,HY7yaJeI89xE56sbTjdBRZPDwQKFX):
	if   ZyiMa3BXVk2xWG0b==1010: MOTjA5H9XFs = nRVAZc4Dp8PSrGU3xBk()
	elif ZyiMa3BXVk2xWG0b==1011: MOTjA5H9XFs = B9vrO71NPxuS5zIe2(HY7yaJeI89xE56sbTjdBRZPDwQKFX)
	elif ZyiMa3BXVk2xWG0b==1012: MOTjA5H9XFs = VpwMYEAgsJb0vzKfuOoa781GW3(WWowRmHkj1ZAO2SUhtNvdrcKa9E6C,HY7yaJeI89xE56sbTjdBRZPDwQKFX)
	elif ZyiMa3BXVk2xWG0b==1013: MOTjA5H9XFs = aInVWv10KNmCO7Tk2ueBUPLqMxDwz()
	elif ZyiMa3BXVk2xWG0b==1014: MOTjA5H9XFs = JlPTuH5FE0L7MXor2v1N(WWowRmHkj1ZAO2SUhtNvdrcKa9E6C,HY7yaJeI89xE56sbTjdBRZPDwQKFX)
	elif ZyiMa3BXVk2xWG0b==1015: MOTjA5H9XFs = ToIEwA30iyDBhO5uxrHFagmzGR(HY7yaJeI89xE56sbTjdBRZPDwQKFX)
	elif ZyiMa3BXVk2xWG0b==1016: MOTjA5H9XFs = Kot3DqVfw7xed8pLA(HY7yaJeI89xE56sbTjdBRZPDwQKFX)
	elif ZyiMa3BXVk2xWG0b==1018: MOTjA5H9XFs = OiN46vymPKbVhEjMxe7pGzSFQLnr(HY7yaJeI89xE56sbTjdBRZPDwQKFX)
	elif ZyiMa3BXVk2xWG0b==1019: MOTjA5H9XFs = PPqUACSE3VcGLTvw05jHy9JrFNW(HY7yaJeI89xE56sbTjdBRZPDwQKFX,False)
	else: MOTjA5H9XFs = False
	return MOTjA5H9XFs
def nRVAZc4Dp8PSrGU3xBk():
	x3WSXnKyPhjqfHG2UrtQs('folder','بحث جوجل جديد',qpFY4hAwolV3,1019)
	x3WSXnKyPhjqfHG2UrtQs('link','كيف يعمل بحث جوجل','',1013)
	x3WSXnKyPhjqfHG2UrtQs('link',xupTj02bvy3O8R+'==== كلمات البحث المخزنة ===='+fF4lt9zWYxXLKZVyAco82PgMj,qpFY4hAwolV3,9999)
	QP6ZgYhxFIiUJ = XXyMBNAVJvKiq7jc20bEw6(WoFsvbmUlDZp7PzRfdGknCV,'dict','GLOBALSEARCH_SPLITTED_GOOGLE')
	if QP6ZgYhxFIiUJ:
		QP6ZgYhxFIiUJ = QP6ZgYhxFIiUJ['__SEQUENCED_COLUMNS__']
		for v9hig4t8jT in reversed(QP6ZgYhxFIiUJ):
			x3WSXnKyPhjqfHG2UrtQs('folder',v9hig4t8jT,qpFY4hAwolV3,1019,qpFY4hAwolV3,qpFY4hAwolV3,v9hig4t8jT)
	return
def OiN46vymPKbVhEjMxe7pGzSFQLnr(search):
	PPqUACSE3VcGLTvw05jHy9JrFNW(search,True)
	E2E18vJ4hLaZpuWSfoMlY9yBzj6b(ag8rjZo1Vz4IPdcOT)
	return
def PPqUACSE3VcGLTvw05jHy9JrFNW(search,P4LyM2OdTQq73hDEwJY5i=False):
	if search==qpFY4hAwolV3: search = jXgARlWMLVFUBnvmZwI2o5()
	if search==qpFY4hAwolV3: return
	BoVz38peOtwnXF9Dry6f15 = search.replace(wwSFijdVJn1QgHW,qpFY4hAwolV3).lower()
	Hpng240dGVM3bflaW8IcvAD,NN7PjtM38za6x5qWLXf4Vdig9Kvlc,pXYVvb37rxHAy2eoNnfWSGwqkz4ZM = [],[],[]
	if not P4LyM2OdTQq73hDEwJY5i:
		Hpng240dGVM3bflaW8IcvAD = XXyMBNAVJvKiq7jc20bEw6(WoFsvbmUlDZp7PzRfdGknCV,'list','GOOGLESEARCH_RESULTS',BoVz38peOtwnXF9Dry6f15)
		if Hpng240dGVM3bflaW8IcvAD: NN7PjtM38za6x5qWLXf4Vdig9Kvlc,pXYVvb37rxHAy2eoNnfWSGwqkz4ZM = Hpng240dGVM3bflaW8IcvAD
	if P4LyM2OdTQq73hDEwJY5i or not Hpng240dGVM3bflaW8IcvAD:
		import JSEBrVPTh9
		JSEBrVPTh9.CCTcPio1Mj0ryqUz6avGYXng8NEf(BoVz38peOtwnXF9Dry6f15,'_GOOGLE',True)
		MhrXE9OeQ5CbcVYFW3 = jELY9mUCTpKfNbyS653(BoVz38peOtwnXF9Dry6f15)
		for lkd2oKvZF03qmgMbIfQ6cD in MhrXE9OeQ5CbcVYFW3:
			name,MepIvHBYNArkUOdV37shtJ,title,text,I5InEFu4fjlBqdgm0tOXchA,j7HgbsXoUDfzcSkmniPu9w6 = lkd2oKvZF03qmgMbIfQ6cD
			if j7HgbsXoUDfzcSkmniPu9w6 in YJtxGoaiQlSndzECbOrRWLjhk: NN7PjtM38za6x5qWLXf4Vdig9Kvlc.append(lkd2oKvZF03qmgMbIfQ6cD)
			else: pXYVvb37rxHAy2eoNnfWSGwqkz4ZM.append(lkd2oKvZF03qmgMbIfQ6cD)
		NN7PjtM38za6x5qWLXf4Vdig9Kvlc = sorted(NN7PjtM38za6x5qWLXf4Vdig9Kvlc,reverse=ag8rjZo1Vz4IPdcOT,key=lambda key: key[vvXoMLlg513])
		pXYVvb37rxHAy2eoNnfWSGwqkz4ZM = sorted(pXYVvb37rxHAy2eoNnfWSGwqkz4ZM,reverse=ag8rjZo1Vz4IPdcOT,key=lambda key: key[vvXoMLlg513])
		zOYMaQ0NgdiRVwDJXh8e(WoFsvbmUlDZp7PzRfdGknCV,'GOOGLESEARCH_RESULTS',BoVz38peOtwnXF9Dry6f15,[NN7PjtM38za6x5qWLXf4Vdig9Kvlc,pXYVvb37rxHAy2eoNnfWSGwqkz4ZM],IZVKS7o3q0)
		mlykPoGXbJIjFnarp9KihxfN(WoFsvbmUlDZp7PzRfdGknCV,'GLOBALSEARCH_DETAILED_GOOGLE',BoVz38peOtwnXF9Dry6f15)
		JSEBrVPTh9.CCTcPio1Mj0ryqUz6avGYXng8NEf(BoVz38peOtwnXF9Dry6f15,'_GOOGLE',False)
		mlykPoGXbJIjFnarp9KihxfN(WoFsvbmUlDZp7PzRfdGknCV,'GLOBALSEARCH_DIVIDED_GOOGLE',"%, '"+BoVz38peOtwnXF9Dry6f15+"')")
		if NN7PjtM38za6x5qWLXf4Vdig9Kvlc: iG7Rz2kmn0x1yLNMV3u8O('','',GLTtERWbHnFuy4PCp,'تم عمل بحث جوجل جديد وتم إيجاد\n\n'+str(len(NN7PjtM38za6x5qWLXf4Vdig9Kvlc))+'  مواقع')
		else: NN7PjtM38za6x5qWLXf4Vdig9Kvlc,pXYVvb37rxHAy2eoNnfWSGwqkz4ZM = uk9QOGysNeoYa4gDdmZxqIlb7(BoVz38peOtwnXF9Dry6f15,ag8rjZo1Vz4IPdcOT)
	x3WSXnKyPhjqfHG2UrtQs('link','بحث جماعي لمواقع جوجل','search_sites_google',1012,qpFY4hAwolV3,qpFY4hAwolV3,BoVz38peOtwnXF9Dry6f15)
	x3WSXnKyPhjqfHG2UrtQs('folder','بحث منفرد لمواقع جوجل',qpFY4hAwolV3,1011,qpFY4hAwolV3,qpFY4hAwolV3,BoVz38peOtwnXF9Dry6f15)
	x3WSXnKyPhjqfHG2UrtQs('link',xupTj02bvy3O8R+'===== ===== ===== '+fF4lt9zWYxXLKZVyAco82PgMj,qpFY4hAwolV3,9999)
	x3WSXnKyPhjqfHG2UrtQs('folder','نتائج البحث مفصلة - '+BoVz38peOtwnXF9Dry6f15,'opened_sites_google',1012,qpFY4hAwolV3,qpFY4hAwolV3,BoVz38peOtwnXF9Dry6f15)
	x3WSXnKyPhjqfHG2UrtQs('folder','نتائج البحث مقسمة - '+BoVz38peOtwnXF9Dry6f15,'listed_sites_google',1012,qpFY4hAwolV3,qpFY4hAwolV3,BoVz38peOtwnXF9Dry6f15)
	x3WSXnKyPhjqfHG2UrtQs('link',xupTj02bvy3O8R+'===== ===== ===== '+fF4lt9zWYxXLKZVyAco82PgMj,qpFY4hAwolV3,9999)
	x3WSXnKyPhjqfHG2UrtQs('folder','مواقع جوجل ('+str(len(NN7PjtM38za6x5qWLXf4Vdig9Kvlc))+') - '+BoVz38peOtwnXF9Dry6f15,'',1016,qpFY4hAwolV3,qpFY4hAwolV3,BoVz38peOtwnXF9Dry6f15)
	x3WSXnKyPhjqfHG2UrtQs('link','إعادة بحث جوجل - '+BoVz38peOtwnXF9Dry6f15,'',1018,qpFY4hAwolV3,qpFY4hAwolV3,search)
	return
def Kot3DqVfw7xed8pLA(BoVz38peOtwnXF9Dry6f15):
	NN7PjtM38za6x5qWLXf4Vdig9Kvlc,pXYVvb37rxHAy2eoNnfWSGwqkz4ZM = uk9QOGysNeoYa4gDdmZxqIlb7(BoVz38peOtwnXF9Dry6f15)
	if not NN7PjtM38za6x5qWLXf4Vdig9Kvlc and not pXYVvb37rxHAy2eoNnfWSGwqkz4ZM: return
	zVeyYmUrwcapWLfK7ndCHqbuISiMlA = {}
	for name,MepIvHBYNArkUOdV37shtJ,title,text,I5InEFu4fjlBqdgm0tOXchA,j7HgbsXoUDfzcSkmniPu9w6 in NN7PjtM38za6x5qWLXf4Vdig9Kvlc: zVeyYmUrwcapWLfK7ndCHqbuISiMlA[j7HgbsXoUDfzcSkmniPu9w6] = name,MepIvHBYNArkUOdV37shtJ,title,text,I5InEFu4fjlBqdgm0tOXchA,j7HgbsXoUDfzcSkmniPu9w6
	jdoGiRX6SpfJzVIPAueb8M5Ys = list(zVeyYmUrwcapWLfK7ndCHqbuISiMlA.keys())
	import JSEBrVPTh9
	q30elgHcyPKrSVpbsiIn5G = JSEBrVPTh9.uArTHUNiXlYWROV9DmgvoGFbL8M(jdoGiRX6SpfJzVIPAueb8M5Ys)
	for j7HgbsXoUDfzcSkmniPu9w6 in q30elgHcyPKrSVpbsiIn5G:
		if isinstance(j7HgbsXoUDfzcSkmniPu9w6,tuple):
			i4bFG3rKE6.menuItemsLIST.append(j7HgbsXoUDfzcSkmniPu9w6)
			continue
		name,MepIvHBYNArkUOdV37shtJ,title,text,I5InEFu4fjlBqdgm0tOXchA,j7HgbsXoUDfzcSkmniPu9w6 = zVeyYmUrwcapWLfK7ndCHqbuISiMlA[j7HgbsXoUDfzcSkmniPu9w6]
		qg4HsMCAcGWP7dZuv,bbieYx6KO2EHAmJj0G,TqMRtYCifVH46FuUgh = pPbuMH5hy6BSXzEaDGn(j7HgbsXoUDfzcSkmniPu9w6)
		x3WSXnKyPhjqfHG2UrtQs('folder',TqMRtYCifVH46FuUgh+name,MepIvHBYNArkUOdV37shtJ,1014,I5InEFu4fjlBqdgm0tOXchA,'',j7HgbsXoUDfzcSkmniPu9w6)
	x3WSXnKyPhjqfHG2UrtQs('link',xupTj02bvy3O8R+'===== ===== ===== '+fF4lt9zWYxXLKZVyAco82PgMj,qpFY4hAwolV3,9999)
	x3WSXnKyPhjqfHG2UrtQs('link',xupTj02bvy3O8R+'مواقع بجوجل غير موجودة بالبرنامج'+fF4lt9zWYxXLKZVyAco82PgMj,qpFY4hAwolV3,1015)
	pXYVvb37rxHAy2eoNnfWSGwqkz4ZM = sorted(pXYVvb37rxHAy2eoNnfWSGwqkz4ZM,reverse=ag8rjZo1Vz4IPdcOT,key=lambda key: key[vvXoMLlg513])
	for name,MepIvHBYNArkUOdV37shtJ,title,text,I5InEFu4fjlBqdgm0tOXchA,j7HgbsXoUDfzcSkmniPu9w6 in pXYVvb37rxHAy2eoNnfWSGwqkz4ZM:
		x3WSXnKyPhjqfHG2UrtQs('link','_GOS_'+name,MepIvHBYNArkUOdV37shtJ,1015,I5InEFu4fjlBqdgm0tOXchA,'',j7HgbsXoUDfzcSkmniPu9w6)
	return
def uk9QOGysNeoYa4gDdmZxqIlb7(BoVz38peOtwnXF9Dry6f15,lZimHx5y6VYIfsznu=gBExoceumj4y8bFW9hY2aNMVSr):
	NN7PjtM38za6x5qWLXf4Vdig9Kvlc,pXYVvb37rxHAy2eoNnfWSGwqkz4ZM = [],[]
	if lZimHx5y6VYIfsznu:
		Hpng240dGVM3bflaW8IcvAD = XXyMBNAVJvKiq7jc20bEw6(WoFsvbmUlDZp7PzRfdGknCV,'list','GOOGLESEARCH_RESULTS',BoVz38peOtwnXF9Dry6f15)
		if Hpng240dGVM3bflaW8IcvAD: NN7PjtM38za6x5qWLXf4Vdig9Kvlc,pXYVvb37rxHAy2eoNnfWSGwqkz4ZM = Hpng240dGVM3bflaW8IcvAD
	if not NN7PjtM38za6x5qWLXf4Vdig9Kvlc and not pXYVvb37rxHAy2eoNnfWSGwqkz4ZM: iG7Rz2kmn0x1yLNMV3u8O('','',GLTtERWbHnFuy4PCp,'للأسف جوجل لم يجد مواقع فيها طلبك')
	return NN7PjtM38za6x5qWLXf4Vdig9Kvlc,pXYVvb37rxHAy2eoNnfWSGwqkz4ZM
def VpwMYEAgsJb0vzKfuOoa781GW3(MtIBq23QjNrgDXvERnwhfa,BoVz38peOtwnXF9Dry6f15):
	NN7PjtM38za6x5qWLXf4Vdig9Kvlc,pXYVvb37rxHAy2eoNnfWSGwqkz4ZM = uk9QOGysNeoYa4gDdmZxqIlb7(BoVz38peOtwnXF9Dry6f15)
	if not NN7PjtM38za6x5qWLXf4Vdig9Kvlc and not pXYVvb37rxHAy2eoNnfWSGwqkz4ZM: return
	qqoUafDXhkw9NQCKHxrZgzmlF2tS7I,zuyK8RwBCImE = [],{}
	for name,MepIvHBYNArkUOdV37shtJ,title,text,I5InEFu4fjlBqdgm0tOXchA,j7HgbsXoUDfzcSkmniPu9w6 in NN7PjtM38za6x5qWLXf4Vdig9Kvlc:
		qqoUafDXhkw9NQCKHxrZgzmlF2tS7I.append(j7HgbsXoUDfzcSkmniPu9w6)
		zuyK8RwBCImE[j7HgbsXoUDfzcSkmniPu9w6] = xwvIefuKN70iXn1Fk(text)
	import JSEBrVPTh9
	JSEBrVPTh9.kiuNMmdRPsAjWntzVc5S1qhUKGb(BoVz38peOtwnXF9Dry6f15,MtIBq23QjNrgDXvERnwhfa,qpFY4hAwolV3,qqoUafDXhkw9NQCKHxrZgzmlF2tS7I,zuyK8RwBCImE)
	return
def B9vrO71NPxuS5zIe2(BoVz38peOtwnXF9Dry6f15):
	NN7PjtM38za6x5qWLXf4Vdig9Kvlc,pXYVvb37rxHAy2eoNnfWSGwqkz4ZM = uk9QOGysNeoYa4gDdmZxqIlb7(BoVz38peOtwnXF9Dry6f15)
	if not NN7PjtM38za6x5qWLXf4Vdig9Kvlc and not pXYVvb37rxHAy2eoNnfWSGwqkz4ZM: return
	zVeyYmUrwcapWLfK7ndCHqbuISiMlA = {}
	for name,MepIvHBYNArkUOdV37shtJ,title,text,I5InEFu4fjlBqdgm0tOXchA,j7HgbsXoUDfzcSkmniPu9w6 in NN7PjtM38za6x5qWLXf4Vdig9Kvlc:
		zVeyYmUrwcapWLfK7ndCHqbuISiMlA[j7HgbsXoUDfzcSkmniPu9w6] = name,MepIvHBYNArkUOdV37shtJ,title,text,I5InEFu4fjlBqdgm0tOXchA,j7HgbsXoUDfzcSkmniPu9w6
	jdoGiRX6SpfJzVIPAueb8M5Ys = list(zVeyYmUrwcapWLfK7ndCHqbuISiMlA.keys())
	import JSEBrVPTh9
	q30elgHcyPKrSVpbsiIn5G = JSEBrVPTh9.uArTHUNiXlYWROV9DmgvoGFbL8M(jdoGiRX6SpfJzVIPAueb8M5Ys)
	for j7HgbsXoUDfzcSkmniPu9w6 in q30elgHcyPKrSVpbsiIn5G:
		if isinstance(j7HgbsXoUDfzcSkmniPu9w6,tuple):
			i4bFG3rKE6.menuItemsLIST.append(j7HgbsXoUDfzcSkmniPu9w6)
			continue
		name,MepIvHBYNArkUOdV37shtJ,title,text,I5InEFu4fjlBqdgm0tOXchA,j7HgbsXoUDfzcSkmniPu9w6 = zVeyYmUrwcapWLfK7ndCHqbuISiMlA[j7HgbsXoUDfzcSkmniPu9w6]
		qg4HsMCAcGWP7dZuv,bbieYx6KO2EHAmJj0G,TqMRtYCifVH46FuUgh = pPbuMH5hy6BSXzEaDGn(j7HgbsXoUDfzcSkmniPu9w6)
		text = xwvIefuKN70iXn1Fk(text)
		name = name+' - '+BoVz38peOtwnXF9Dry6f15
		x3WSXnKyPhjqfHG2UrtQs('folder',TqMRtYCifVH46FuUgh+name,j7HgbsXoUDfzcSkmniPu9w6,548,I5InEFu4fjlBqdgm0tOXchA,'',text)
	return
def xwvIefuKN70iXn1Fk(title):
	ZDTxRSMbW7PNz = ePhmG1jLD6.findall('(.*?) (الحلقة|حلقة)',title,ePhmG1jLD6.DOTALL)
	UdbGw48M6rCHDRmea5qP91nKI = ZDTxRSMbW7PNz[0][0] if ZDTxRSMbW7PNz else title
	UdbGw48M6rCHDRmea5qP91nKI = UdbGw48M6rCHDRmea5qP91nKI.replace('مشاهدة اونلاين، فيديو، الإعلان، صور - السينما.كوم','').replace('- ‎عرب سيد - Arabseed','')
	UdbGw48M6rCHDRmea5qP91nKI = UdbGw48M6rCHDRmea5qP91nKI.replace('- وى سيما wecima ماى سيما mycima - وي سيما','').replace('- فيديو Dailymotion','')
	UdbGw48M6rCHDRmea5qP91nKI = UdbGw48M6rCHDRmea5qP91nKI.replace('الموسم','').replace('الموقع','').replace('- شوف نت','').replace('موسم','').replace('HD','')
	UdbGw48M6rCHDRmea5qP91nKI = UdbGw48M6rCHDRmea5qP91nKI.replace('مشاهدة','').replace('نتائج البحث:','').replace('اونلاين','').replace('- سيما فور بي','')
	UdbGw48M6rCHDRmea5qP91nKI = UdbGw48M6rCHDRmea5qP91nKI.replace('موقع','').replace('| اكوام','').replace('','').replace('','').replace('','').replace('','')
	UdbGw48M6rCHDRmea5qP91nKI = UdbGw48M6rCHDRmea5qP91nKI.strip(' ').replace('    ',' ').replace('   ',' ').replace('  ',' ').replace('  ',' ')
	return UdbGw48M6rCHDRmea5qP91nKI
def jELY9mUCTpKfNbyS653(search):
	search = search.replace(mIsDke0oK5x1zSiOWbF9thGcA,'+')
	headers = {'User-Agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36 Edg/128.0.0.0'}
	url = 'https://www.google.com/search?hl=en&filter=1&imgSize=small&safe=active&q=-youtube+-instagram+-facebook+-tiktok+-elcinema+'+search
	WSQlG8mDhqsNe = url+'&start=0&num=100&tbm=vid&udm=7'
	IAW0sh6So3NpqM = WWrExJZS3Bj4anOAkpv7(dzcNuIbsgK3yZ6SXGaEHPfOj5vk,'GET',WSQlG8mDhqsNe,qpFY4hAwolV3,headers,qpFY4hAwolV3,qpFY4hAwolV3,'GOOGLESEARCH-SEARCH-1st')
	if not IAW0sh6So3NpqM.succeeded: return []
	cmWl9dOKHPIy41iaXuxrY = IAW0sh6So3NpqM.content
	biX9Hvhu0FsDLB8MkdmeJjAQU4 = RPbaxsNFVTwek5Kfv21DiJuzCnjMZp.path.join(MZRS4rVzdoqwH,'googlesearch')
	if not RPbaxsNFVTwek5Kfv21DiJuzCnjMZp.path.exists(biX9Hvhu0FsDLB8MkdmeJjAQU4):
		try: RPbaxsNFVTwek5Kfv21DiJuzCnjMZp.makedirs(biX9Hvhu0FsDLB8MkdmeJjAQU4)
		except: pass
	items = []
	HLVwBWJ6mFa3ApoNlq178nuXgI = ePhmG1jLD6.findall('jsname="UWckNb" href="(.*?)".*?<span.*?>(.*?).*?aria-label="(.*?)".*?src="(.*?)".*?class="cuFRh">(.*?)<',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	if HLVwBWJ6mFa3ApoNlq178nuXgI:
		for mVYdjvor6i4wZ8 in HLVwBWJ6mFa3ApoNlq178nuXgI:
			MepIvHBYNArkUOdV37shtJ,title,text,BvbuigUeoJLnTaN2qWxQ415AtYMK9I,name = mVYdjvor6i4wZ8
			BvbuigUeoJLnTaN2qWxQ415AtYMK9I = ''
			items.append([MepIvHBYNArkUOdV37shtJ,title,text,name,BvbuigUeoJLnTaN2qWxQ415AtYMK9I])
	else:
		WSQlG8mDhqsNe = url+'&start=0&num=200'
		IAW0sh6So3NpqM = WWrExJZS3Bj4anOAkpv7(dzcNuIbsgK3yZ6SXGaEHPfOj5vk,'GET:SCRAPERS',WSQlG8mDhqsNe,qpFY4hAwolV3,headers,qpFY4hAwolV3,qpFY4hAwolV3,'GOOGLESEARCH-SEARCH-2nd')
		if not IAW0sh6So3NpqM.succeeded: return []
		cmWl9dOKHPIy41iaXuxrY = IAW0sh6So3NpqM.content
		HLVwBWJ6mFa3ApoNlq178nuXgI = ePhmG1jLD6.findall('(\[null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,".*?\]\])',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
		if not HLVwBWJ6mFa3ApoNlq178nuXgI: HLVwBWJ6mFa3ApoNlq178nuXgI = ePhmG1jLD6.findall('(\[None,None,None,None,None,None,None,None,None,None,None,None,None,None,None,None,None,".*?\]\])',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
		for mVYdjvor6i4wZ8 in HLVwBWJ6mFa3ApoNlq178nuXgI:
			mVYdjvor6i4wZ8 = wB8NUAidPbqjIr9CFasXvYnxOQpL0g('list',mVYdjvor6i4wZ8)
			if len(mVYdjvor6i4wZ8)>17:
				MepIvHBYNArkUOdV37shtJ = mVYdjvor6i4wZ8[17]
				title,text,name,BvbuigUeoJLnTaN2qWxQ415AtYMK9I = mVYdjvor6i4wZ8[31][0:4]
				items.append([MepIvHBYNArkUOdV37shtJ,title,text,name,BvbuigUeoJLnTaN2qWxQ415AtYMK9I])
	T6n8MOL0qAtgpJDzyH,wGOBvuSfQJn = [],[]
	for lkd2oKvZF03qmgMbIfQ6cD in items:
		MepIvHBYNArkUOdV37shtJ,title,text,name,BvbuigUeoJLnTaN2qWxQ415AtYMK9I = lkd2oKvZF03qmgMbIfQ6cD
		name = name.strip(' ')
		if not name: name = AWeJuo2LhZ5xiD8KNSqd9G0rtT74FE(MepIvHBYNArkUOdV37shtJ,'name')
		name = GmlDbno5psqtUL9XrS(name)
		if 'http://' in BvbuigUeoJLnTaN2qWxQ415AtYMK9I or 'https://' in BvbuigUeoJLnTaN2qWxQ415AtYMK9I: I5InEFu4fjlBqdgm0tOXchA = BvbuigUeoJLnTaN2qWxQ415AtYMK9I
		elif 'data:image/' in BvbuigUeoJLnTaN2qWxQ415AtYMK9I and ';base64,' in BvbuigUeoJLnTaN2qWxQ415AtYMK9I:
			TCgivORFXets6dYmV05B3hM2U = ePhmG1jLD6.findall('data:image/(\w+);base64,',BvbuigUeoJLnTaN2qWxQ415AtYMK9I)
			TCgivORFXets6dYmV05B3hM2U = TCgivORFXets6dYmV05B3hM2U[0]
			I5InEFu4fjlBqdgm0tOXchA = RPbaxsNFVTwek5Kfv21DiJuzCnjMZp.path.join(biX9Hvhu0FsDLB8MkdmeJjAQU4,name+'.'+TCgivORFXets6dYmV05B3hM2U)
			if not RPbaxsNFVTwek5Kfv21DiJuzCnjMZp.path.exists(I5InEFu4fjlBqdgm0tOXchA):
				BvbuigUeoJLnTaN2qWxQ415AtYMK9I = BvbuigUeoJLnTaN2qWxQ415AtYMK9I.replace('\\u003d','=')
				BvbuigUeoJLnTaN2qWxQ415AtYMK9I = BvbuigUeoJLnTaN2qWxQ415AtYMK9I.replace('data:image/'+TCgivORFXets6dYmV05B3hM2U+';base64,','')
				a27L8utEjl9FYoSpHw6s0 = PP0Gxazjw86.b64decode(BvbuigUeoJLnTaN2qWxQ415AtYMK9I)
				open(I5InEFu4fjlBqdgm0tOXchA,'wb').write(a27L8utEjl9FYoSpHw6s0)
		else: I5InEFu4fjlBqdgm0tOXchA = ''
		j7HgbsXoUDfzcSkmniPu9w6 = vxdkqoWN75nRirCIOasgSc3EP6(name,MepIvHBYNArkUOdV37shtJ)
		if j7HgbsXoUDfzcSkmniPu9w6 not in wGOBvuSfQJn:
			wGOBvuSfQJn.append(j7HgbsXoUDfzcSkmniPu9w6)
			name = nqTpa5zm20MfRNsVSIuG7A3biHZ6Fw(j7HgbsXoUDfzcSkmniPu9w6)
			T6n8MOL0qAtgpJDzyH.append([name,MepIvHBYNArkUOdV37shtJ,title,text,I5InEFu4fjlBqdgm0tOXchA,j7HgbsXoUDfzcSkmniPu9w6])
	return T6n8MOL0qAtgpJDzyH
def JlPTuH5FE0L7MXor2v1N(MepIvHBYNArkUOdV37shtJ,j7HgbsXoUDfzcSkmniPu9w6):
	qg4HsMCAcGWP7dZuv,bbieYx6KO2EHAmJj0G,TqMRtYCifVH46FuUgh = pPbuMH5hy6BSXzEaDGn(j7HgbsXoUDfzcSkmniPu9w6)
	if TqMRtYCifVH46FuUgh: qg4HsMCAcGWP7dZuv()
	else: ToIEwA30iyDBhO5uxrHFagmzGR()
	return
def aInVWv10KNmCO7Tk2ueBUPLqMxDwz():
	iG7Rz2kmn0x1yLNMV3u8O('','',GLTtERWbHnFuy4PCp,'هذا البحث يستخدم ذكاء وشمولية وسرعة محرك بحث جوجل .. ونتائج هذا البحث هي أسماء مواقع الإنترنت التي موجودة في هذا البرنامج والتي فيها الفيديوهات المطلوبة\n\nهذا البحث يحتاج كلمات بحث عادية جدا بدون أي مراعاة لدقة الكلمات أو تفاصيل الفيديوهات أو حتى إملاء الكلمات\n\nهذا البحث يستطيع أيضا أن يفحص محتويات المواقع التي وجدها جوجل إذا كانت هذه المواقع موجودة بهذا البرنامج')
	return
def ToIEwA30iyDBhO5uxrHFagmzGR(j7HgbsXoUDfzcSkmniPu9w6=''):
	iG7Rz2kmn0x1yLNMV3u8O('','',j7HgbsXoUDfzcSkmniPu9w6,'هذا الموقع غير موجود في البرنامج .. أو أسم الموقع مختلف وغير مطابق للاسم المستخدم في البرنامج')
	return
def vxdkqoWN75nRirCIOasgSc3EP6(name,MepIvHBYNArkUOdV37shtJ):
	jjpS6wNnR4iVFsI5Lvba3e7TGd = {
	 'فشار فيديو مشاهدة افلام ومسلسلات اون لاين'	:'FUSHARVIDEO'
	,'وى سيما wecima ماى سيما mycima'			:'WECIMA1'
	,'شبكتي تي في - SHABAKATY TV'				:'SHABAKATY'
	,'اكوام  شبكة اكوام AKWAM'					:'AKWAM'
	,'سيما كلوب  CIMACLUB'						:'CIMACLUB'
	,'سيما فري CIMAFREE':'CIMAFREE'
	,'هلا سيما'			:'HALACIMA'
	,'لاروزا'			:'LAROZA'
	,'برستيج'			:'BRSTEJ'
	,'كرمالك TV'		:'KIRMALK'
	,'سيما فور بي'		:'CIMA4P'
	,'اهواك تي في'		:'AHWAK'
	,'CIMA CLUB'		:'CIMACLUB'
	,'اكوام'			:'AKWAM'
	,'وي سيما'			:'WECIMA1'
	,'سيما ناو'			:'CIMANOW'
	,'سيما لايت'			:'CIMALIGHT'
	,'موقع ماي سيما'	:'CIMALIGHT'
	,'عرب سيد'			:'ARABSEED'
	,'فيديو ياقوت'		:'YAQOT'
	,'المصطبة TV'		:'ALMSTBA'
	,'دراما كافيه'		:'DRAMACAFE'
	,'سيما 400'			:'CIMA400'
	,'فيديو تكات'		:'TIKAAT'
	,'السينما.كوم'		:'ELCINEMA'
	,'فوستا'			:'FOSTA'
	,'سيما عبدو'		:'CIMAABDO'
	,'فاصل إعلاني'		:'FASELHD1'
	,'مسلسلات تايم'		:'SERIESTIME'
	,'شوف نت'			:'SHOOFNET'
	}
	YblzdQaeVqgF = name.lower()
	l0bSC83stEymKhqY5WicIvLP67 = ''
	for key in list(jjpS6wNnR4iVFsI5Lvba3e7TGd.keys()):
		if key.lower() in YblzdQaeVqgF: l0bSC83stEymKhqY5WicIvLP67 = jjpS6wNnR4iVFsI5Lvba3e7TGd[key]
	if not l0bSC83stEymKhqY5WicIvLP67:
		OexQX2mTwfGkuU6AIBLz9vWlHjdF8 = AWeJuo2LhZ5xiD8KNSqd9G0rtT74FE(MepIvHBYNArkUOdV37shtJ,'url')
		for j7HgbsXoUDfzcSkmniPu9w6 in list(i4bFG3rKE6.SITESURLS.keys()):
			VGDeqXnNCzwJB4LbUvo = AWeJuo2LhZ5xiD8KNSqd9G0rtT74FE(i4bFG3rKE6.SITESURLS[j7HgbsXoUDfzcSkmniPu9w6][0],'url')
			if OexQX2mTwfGkuU6AIBLz9vWlHjdF8==VGDeqXnNCzwJB4LbUvo: l0bSC83stEymKhqY5WicIvLP67 = j7HgbsXoUDfzcSkmniPu9w6
	if not l0bSC83stEymKhqY5WicIvLP67:
		YblzdQaeVqgF = AWeJuo2LhZ5xiD8KNSqd9G0rtT74FE(MepIvHBYNArkUOdV37shtJ,'name')
		for j7HgbsXoUDfzcSkmniPu9w6 in list(i4bFG3rKE6.SITESURLS.keys()):
			eorpCwV2J6lXLz7DhbjNys5TRt = AWeJuo2LhZ5xiD8KNSqd9G0rtT74FE(i4bFG3rKE6.SITESURLS[j7HgbsXoUDfzcSkmniPu9w6][0],'name')
			if YblzdQaeVqgF==eorpCwV2J6lXLz7DhbjNys5TRt: l0bSC83stEymKhqY5WicIvLP67 = j7HgbsXoUDfzcSkmniPu9w6
	if not l0bSC83stEymKhqY5WicIvLP67: l0bSC83stEymKhqY5WicIvLP67 = name
	l0bSC83stEymKhqY5WicIvLP67 = l0bSC83stEymKhqY5WicIvLP67.upper()
	return l0bSC83stEymKhqY5WicIvLP67