# -*- coding: utf-8 -*-
from pSfaryIjBo import *
Q8Q0IDc6PLZajJAdTntKUmSGXz = 'YOUTUBE'
wwSFijdVJn1QgHW = '_YUT_'
ddBxj51bhNtaK23lDyGMVw = i4bFG3rKE6.SITESURLS[Q8Q0IDc6PLZajJAdTntKUmSGXz][0]
cC2iaBSo1tGuwJLRMr4WvqsV5pj = 0
def vTNE2Ck1sGnugJYW8y39aLcSH64U(mode,url,text,type,i02wfPp5EM,name,BvbuigUeoJLnTaN2qWxQ415AtYMK9I):
	if	 mode==140: MOTjA5H9XFs = nRVAZc4Dp8PSrGU3xBk()
	elif mode==141: MOTjA5H9XFs = BvNZIpTEu2(url,name,BvbuigUeoJLnTaN2qWxQ415AtYMK9I)
	elif mode==143: MOTjA5H9XFs = mzcAeyplZV(url,type)
	elif mode==144: MOTjA5H9XFs = c8U1BdtxOZS5FH(url,i02wfPp5EM,text)
	elif mode==145: MOTjA5H9XFs = O1xHLFnSdMwGtK3kZaNj29QT(url,i02wfPp5EM)
	elif mode==147: MOTjA5H9XFs = MsjP9khYEudmFfxGb6Tg1Bq57DzI()
	elif mode==148: MOTjA5H9XFs = XL4z2fouv1crCBVMU38s7xnid()
	elif mode==149: MOTjA5H9XFs = PPqUACSE3VcGLTvw05jHy9JrFNW(text)
	else: MOTjA5H9XFs = False
	return MOTjA5H9XFs
def nRVAZc4Dp8PSrGU3xBk():
	if 0:
		x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+'قائمة 1',ddBxj51bhNtaK23lDyGMVw+'/playlist?list=PLDJPKWWTSFaaGNjpDcPUsWZJVePmAYk_E&pp=iAQB',144)
		x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+'قائمة 2',ddBxj51bhNtaK23lDyGMVw+'/playlist?list=PLAj5Gs8FH8ZnUbF0RV-7G3BoqIyZA4uSA',144)
		x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+'شخص',ddBxj51bhNtaK23lDyGMVw+'/user/TCNofficial',144)
		x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+'موقع',ddBxj51bhNtaK23lDyGMVw+'/channel/UCq59aGNsq9bbhwVTq1Utvgw',144)
		x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+'حساب',ddBxj51bhNtaK23lDyGMVw+'/@TheSocialCTV',144)
		x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+'العاب',ddBxj51bhNtaK23lDyGMVw+'/gaming',144)
		x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+'افلام',ddBxj51bhNtaK23lDyGMVw+'/feed/storefront',144)
		x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+'مختارات',ddBxj51bhNtaK23lDyGMVw+'/feed/guide_builder',144)
		x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+'قصيرة',ddBxj51bhNtaK23lDyGMVw+'/shorts',144,qpFY4hAwolV3,qpFY4hAwolV3,'_REMEMBERRESULTS_')
		x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+'تصفح',ddBxj51bhNtaK23lDyGMVw+'/youtubei/v1/guide?key=',144)
		x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+'رئيسية',ddBxj51bhNtaK23lDyGMVw+qpFY4hAwolV3,144)
		x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+'رائج',ddBxj51bhNtaK23lDyGMVw+'/feed/trending?bp=',144)
		x3WSXnKyPhjqfHG2UrtQs('link',xupTj02bvy3O8R+' ===== ===== ===== '+fF4lt9zWYxXLKZVyAco82PgMj,qpFY4hAwolV3,9999)
	x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+'بحث في الموقع',qpFY4hAwolV3,149,qpFY4hAwolV3,qpFY4hAwolV3,'_REMEMBERRESULTS_')
	x3WSXnKyPhjqfHG2UrtQs('link',xupTj02bvy3O8R+' ===== ===== ===== '+fF4lt9zWYxXLKZVyAco82PgMj,qpFY4hAwolV3,9999)
	x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+'الرائجة',ddBxj51bhNtaK23lDyGMVw+'/feed/trending',144)
	x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+'التصفح',ddBxj51bhNtaK23lDyGMVw+'/youtubei/v1/guide?key=',144)
	x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+'القصيرة',ddBxj51bhNtaK23lDyGMVw+'/shorts',144,qpFY4hAwolV3,qpFY4hAwolV3,'_REMEMBERRESULTS_')
	x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+'مختارات يوتيوب',ddBxj51bhNtaK23lDyGMVw+'/feed/guide_builder',144)
	x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+'مختارات البرنامج',qpFY4hAwolV3,290)
	x3WSXnKyPhjqfHG2UrtQs('link',xupTj02bvy3O8R+' ===== ===== ===== '+fF4lt9zWYxXLKZVyAco82PgMj,qpFY4hAwolV3,9999)
	x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+'بحث: قنوات عربية',qpFY4hAwolV3,147)
	x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+'بحث: قنوات أجنبية',qpFY4hAwolV3,148)
	x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+'بحث: افلام عربية',ddBxj51bhNtaK23lDyGMVw+'/results?search_query=فيلم',144)
	x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+'بحث: افلام اجنبية',ddBxj51bhNtaK23lDyGMVw+'/results?search_query=movie',144)
	x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+'بحث: مسرحيات عربية',ddBxj51bhNtaK23lDyGMVw+'/results?search_query=مسرحية',144)
	x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+'بحث: مسلسلات عربية',ddBxj51bhNtaK23lDyGMVw+'/results?search_query=مسلسل&sp=EgIQAw==',144)
	x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+'بحث: مسلسلات اجنبية',ddBxj51bhNtaK23lDyGMVw+'/results?search_query=series&sp=EgIQAw==',144)
	x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+'بحث: مسلسلات كارتون',ddBxj51bhNtaK23lDyGMVw+'/results?search_query=كارتون&sp=EgIQAw==',144)
	x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+'بحث: خطبة المرجعية',ddBxj51bhNtaK23lDyGMVw+'/results?search_query=قناة+كربلاء+الفضائية+خطبة+الجمعة&sp=CAISAhAB',144)
	return
def BvNZIpTEu2(url,name,BvbuigUeoJLnTaN2qWxQ415AtYMK9I):
	name = VVGXPpMoc4bar0W(name)
	x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+'CHNL:  '+name,url,144,BvbuigUeoJLnTaN2qWxQ415AtYMK9I)
	return
def MsjP9khYEudmFfxGb6Tg1Bq57DzI():
	c8U1BdtxOZS5FH(ddBxj51bhNtaK23lDyGMVw+'/results?search_query=قناة+بث&sp=EgJAAQ==')
	return
def XL4z2fouv1crCBVMU38s7xnid():
	c8U1BdtxOZS5FH(ddBxj51bhNtaK23lDyGMVw+'/results?search_query=tv&sp=EgJAAQ==')
	return
def mzcAeyplZV(url,type):
	url = url.split('&',1)[0]
	import inVXFK46ET
	inVXFK46ET.q4qTJvuoQUzM3mZAtegy7IXdnb5wH([url],Q8Q0IDc6PLZajJAdTntKUmSGXz,type,url)
	return
def fLGtqBukW8K0T3RwlxVAXbNZUC9iF(kkFQn98geIM3,url,P9gc0wx41l3y26iufIkWtaUGnMZ):
	level,S4rfoRcTAeEIYlBhHF3Q,wTnU7OdYhARf8DS0CBq,SSxInVQWbYrZtjF = P9gc0wx41l3y26iufIkWtaUGnMZ.split('::')
	gQoS7yfB1EN3CWbhm,L9lBUF0pJfOKSqmMiC5j = [],[]
	if '/youtubei/v1/browse' in url: gQoS7yfB1EN3CWbhm.append("yccc['onResponseReceivedActions']")
	if '/youtubei/v1/search' in url: gQoS7yfB1EN3CWbhm.append("yccc['onResponseReceivedCommands']")
	gQoS7yfB1EN3CWbhm.append("yccc['contents']['twoColumnBrowseResultsRenderer']['tabs'][0]['tabRenderer']['content']['sectionListRenderer']['contents'][0]['itemSectionRenderer']['contents'][0]['playlistVideoListRenderer']['contents']")
	if level=='1': gQoS7yfB1EN3CWbhm.append("yccc['contents']['twoColumnBrowseResultsRenderer']['tabs'][0]['tabRenderer']['content']['richGridRenderer']['header']['feedFilterChipBarRenderer']['contents']")
	gQoS7yfB1EN3CWbhm.append("yccc['contents']['twoColumnWatchNextResults']['playlist']['playlist']['contents']")
	gQoS7yfB1EN3CWbhm.append("yccc['contents']['twoColumnSearchResultsRenderer']['primaryContents']['sectionListRenderer']['contents']")
	gQoS7yfB1EN3CWbhm.append("yccc['contents']['twoColumnBrowseResultsRenderer']['tabs']")
	gQoS7yfB1EN3CWbhm.append("yccc['entries']")
	gQoS7yfB1EN3CWbhm.append("yccc['items'][3]['guideSectionRenderer']['items']")
	dB3WynaLlomRX,tWPCqgjkE9eS48om,dIvTHPlhNxYLKy = C7W6YX3Q1Fl(kkFQn98geIM3,qpFY4hAwolV3,gQoS7yfB1EN3CWbhm)
	if level=='1' and dB3WynaLlomRX:
		if len(tWPCqgjkE9eS48om)>1 and 'search_query' not in url:
			for tQZvr8cwngxb in range(len(tWPCqgjkE9eS48om)):
				S4rfoRcTAeEIYlBhHF3Q = str(tQZvr8cwngxb)
				gQoS7yfB1EN3CWbhm = []
				gQoS7yfB1EN3CWbhm.append("yddd["+S4rfoRcTAeEIYlBhHF3Q+"]['reloadContinuationItemsCommand']['continuationItems']")
				gQoS7yfB1EN3CWbhm.append("yddd["+S4rfoRcTAeEIYlBhHF3Q+"]['command']")
				gQoS7yfB1EN3CWbhm.append("yddd["+S4rfoRcTAeEIYlBhHF3Q+"]")
				zlQAfuT2Z7nKhGdXs,lkd2oKvZF03qmgMbIfQ6cD,cgwB6jCZf0dy3zvNFuRn5qo = C7W6YX3Q1Fl(tWPCqgjkE9eS48om,qpFY4hAwolV3,gQoS7yfB1EN3CWbhm)
				if zlQAfuT2Z7nKhGdXs: L9lBUF0pJfOKSqmMiC5j.append([lkd2oKvZF03qmgMbIfQ6cD,url,'2::'+S4rfoRcTAeEIYlBhHF3Q+'::0::0'])
			gQoS7yfB1EN3CWbhm.append("yccc['continuationEndpoint']")
			zlQAfuT2Z7nKhGdXs,lkd2oKvZF03qmgMbIfQ6cD,cgwB6jCZf0dy3zvNFuRn5qo = C7W6YX3Q1Fl(kkFQn98geIM3,qpFY4hAwolV3,gQoS7yfB1EN3CWbhm)
			if zlQAfuT2Z7nKhGdXs and L9lBUF0pJfOKSqmMiC5j and 'continuationCommand' in list(lkd2oKvZF03qmgMbIfQ6cD.keys()):
				MepIvHBYNArkUOdV37shtJ = ddBxj51bhNtaK23lDyGMVw+'/my_main_page_shorts_link'
				L9lBUF0pJfOKSqmMiC5j.append([lkd2oKvZF03qmgMbIfQ6cD,MepIvHBYNArkUOdV37shtJ,'1::0::0::0'])
	return tWPCqgjkE9eS48om,dB3WynaLlomRX,L9lBUF0pJfOKSqmMiC5j,dIvTHPlhNxYLKy
def hT5mliPwgCu(kkFQn98geIM3,tWPCqgjkE9eS48om,url,P9gc0wx41l3y26iufIkWtaUGnMZ):
	level,S4rfoRcTAeEIYlBhHF3Q,wTnU7OdYhARf8DS0CBq,SSxInVQWbYrZtjF = P9gc0wx41l3y26iufIkWtaUGnMZ.split('::')
	gQoS7yfB1EN3CWbhm,sq0Tz98ILW1UgFkAHfcSO4yerRu2i = [],[]
	gQoS7yfB1EN3CWbhm.append("yddd[0]['itemSectionRenderer']['contents']")
	gQoS7yfB1EN3CWbhm.append("yddd["+S4rfoRcTAeEIYlBhHF3Q+"]['reloadContinuationItemsCommand']['continuationItems']")
	gQoS7yfB1EN3CWbhm.append("yddd[1]['reloadContinuationItemsCommand']['continuationItems']")
	if '/youtubei/v1/browse' in url: gQoS7yfB1EN3CWbhm.append("yddd[0]['appendContinuationItemsAction']['continuationItems']")
	elif '/youtubei/v1/search' in url: gQoS7yfB1EN3CWbhm.append("yddd[0]['appendContinuationItemsAction']['continuationItems'][0]['itemSectionRenderer']['contents']")
	gQoS7yfB1EN3CWbhm.append("yddd["+S4rfoRcTAeEIYlBhHF3Q+"]['tabRenderer']['content']['sectionListRenderer']['contents']")
	if '/videos' in url or ('/shorts' in url and '/shorts/' not in url):
		gQoS7yfB1EN3CWbhm.append("yddd["+S4rfoRcTAeEIYlBhHF3Q+"]['tabRenderer']['content']['richGridRenderer']['header']['feedFilterChipBarRenderer']['contents']")
	gQoS7yfB1EN3CWbhm.append("yddd["+S4rfoRcTAeEIYlBhHF3Q+"]['tabRenderer']['content']['richGridRenderer']['contents']")
	gQoS7yfB1EN3CWbhm.append("yddd["+S4rfoRcTAeEIYlBhHF3Q+"]['expandableTabRenderer']['content']['sectionListRenderer']['contents']")
	gQoS7yfB1EN3CWbhm.append("yddd["+S4rfoRcTAeEIYlBhHF3Q+"]['richSectionRenderer']['content']['richShelfRenderer']['contents']")
	gQoS7yfB1EN3CWbhm.append("yddd["+S4rfoRcTAeEIYlBhHF3Q+"]")
	MkDAHUwnlSgVi8LtRFzueyIx7G4,XXgRhQ1qDVSieYl,zziwMKNQhx6EIpWd = C7W6YX3Q1Fl(tWPCqgjkE9eS48om,qpFY4hAwolV3,gQoS7yfB1EN3CWbhm)
	if level=='2' and MkDAHUwnlSgVi8LtRFzueyIx7G4:
		if len(XXgRhQ1qDVSieYl)>1:
			for tQZvr8cwngxb in range(len(XXgRhQ1qDVSieYl)):
				wTnU7OdYhARf8DS0CBq = str(tQZvr8cwngxb)
				gQoS7yfB1EN3CWbhm = []
				gQoS7yfB1EN3CWbhm.append("yeee["+wTnU7OdYhARf8DS0CBq+"]['richSectionRenderer']['content']")
				gQoS7yfB1EN3CWbhm.append("yeee["+wTnU7OdYhARf8DS0CBq+"]['itemSectionRenderer']['contents'][0]['horizontalCardListRenderer']['header']")
				gQoS7yfB1EN3CWbhm.append("yeee["+wTnU7OdYhARf8DS0CBq+"]['itemSectionRenderer']['contents'][0]['horizontalCardListRenderer']['cards']")
				gQoS7yfB1EN3CWbhm.append("yeee["+wTnU7OdYhARf8DS0CBq+"]['itemSectionRenderer']['contents'][0]")
				gQoS7yfB1EN3CWbhm.append("yeee["+wTnU7OdYhARf8DS0CBq+"]['richItemRenderer']['content']")
				gQoS7yfB1EN3CWbhm.append("yeee["+wTnU7OdYhARf8DS0CBq+"]")
				zlQAfuT2Z7nKhGdXs,lkd2oKvZF03qmgMbIfQ6cD,cgwB6jCZf0dy3zvNFuRn5qo = C7W6YX3Q1Fl(XXgRhQ1qDVSieYl,qpFY4hAwolV3,gQoS7yfB1EN3CWbhm)
				if zlQAfuT2Z7nKhGdXs: sq0Tz98ILW1UgFkAHfcSO4yerRu2i.append([lkd2oKvZF03qmgMbIfQ6cD,url,'3::'+S4rfoRcTAeEIYlBhHF3Q+'::'+wTnU7OdYhARf8DS0CBq+'::0'])
			gQoS7yfB1EN3CWbhm.append("yddd[0]['appendContinuationItemsAction']['continuationItems'][1]")
			gQoS7yfB1EN3CWbhm.append("yddd[1]")
			zlQAfuT2Z7nKhGdXs,lkd2oKvZF03qmgMbIfQ6cD,cgwB6jCZf0dy3zvNFuRn5qo = C7W6YX3Q1Fl(tWPCqgjkE9eS48om,qpFY4hAwolV3,gQoS7yfB1EN3CWbhm)
			if zlQAfuT2Z7nKhGdXs and sq0Tz98ILW1UgFkAHfcSO4yerRu2i and 'continuationItemRenderer' in list(lkd2oKvZF03qmgMbIfQ6cD.keys()):
				sq0Tz98ILW1UgFkAHfcSO4yerRu2i.append([lkd2oKvZF03qmgMbIfQ6cD,url,'3::0::0::0'])
	return XXgRhQ1qDVSieYl,MkDAHUwnlSgVi8LtRFzueyIx7G4,sq0Tz98ILW1UgFkAHfcSO4yerRu2i,zziwMKNQhx6EIpWd
def ikWyg1mQL3bD7EZ4KBFNfwVhv(kkFQn98geIM3,XXgRhQ1qDVSieYl,url,P9gc0wx41l3y26iufIkWtaUGnMZ):
	level,S4rfoRcTAeEIYlBhHF3Q,wTnU7OdYhARf8DS0CBq,SSxInVQWbYrZtjF = P9gc0wx41l3y26iufIkWtaUGnMZ.split('::')
	gQoS7yfB1EN3CWbhm,UC6cHAVuZ0x5oGSMJa = [],[]
	gQoS7yfB1EN3CWbhm.append("yeee["+wTnU7OdYhARf8DS0CBq+"]['shelfRenderer']['content']['verticalListRenderer']['items']")
	gQoS7yfB1EN3CWbhm.append("yeee["+wTnU7OdYhARf8DS0CBq+"]['itemSectionRenderer']['contents'][0]['shelfRenderer']['content']['horizontalMovieListRenderer']['items']")
	gQoS7yfB1EN3CWbhm.append("yeee["+wTnU7OdYhARf8DS0CBq+"]['itemSectionRenderer']['contents'][0]['reelShelfRenderer']['items']")
	gQoS7yfB1EN3CWbhm.append("yeee["+wTnU7OdYhARf8DS0CBq+"]['itemSectionRenderer']['contents'][0]['shelfRenderer']['content']['gridRenderer']['items']")
	gQoS7yfB1EN3CWbhm.append("yeee["+wTnU7OdYhARf8DS0CBq+"]['itemSectionRenderer']['contents'][0]['shelfRenderer']['content']['horizontalListRenderer']['items']")
	gQoS7yfB1EN3CWbhm.append("yeee["+wTnU7OdYhARf8DS0CBq+"]['itemSectionRenderer']['contents'][0]['shelfRenderer']['content']['expandedShelfContentsRenderer']['items']")
	gQoS7yfB1EN3CWbhm.append("yeee["+wTnU7OdYhARf8DS0CBq+"]['itemSectionRenderer']['contents'][0]['horizontalCardListRenderer']['cards']")
	gQoS7yfB1EN3CWbhm.append("yeee["+wTnU7OdYhARf8DS0CBq+"]['itemSectionRenderer']['contents'][0]['gridRenderer']['items']")
	gQoS7yfB1EN3CWbhm.append("yeee[0]['itemSectionRenderer']['contents'][0]['shelfRenderer']['content']['gridRenderer']['items']")
	gQoS7yfB1EN3CWbhm.append("yeee[0]['itemSectionRenderer']['contents'][0]['gridRenderer']['items']")
	gQoS7yfB1EN3CWbhm.append("yeee[0]['itemSectionRenderer']['contents'][0]['playlistVideoListRenderer']['contents']")
	gQoS7yfB1EN3CWbhm.append("yeee["+wTnU7OdYhARf8DS0CBq+"]['reelShelfRenderer']['items']")
	gQoS7yfB1EN3CWbhm.append("yeee["+wTnU7OdYhARf8DS0CBq+"]['richSectionRenderer']['content']['richShelfRenderer']['contents']")
	gQoS7yfB1EN3CWbhm.append("yeee")
	Wny7QDYmHoX6I0k8hcpAe,rrRNKkcfmCYvjJ1PeQ2,wgO16H9csdJK0zqyiV2IDr = C7W6YX3Q1Fl(XXgRhQ1qDVSieYl,qpFY4hAwolV3,gQoS7yfB1EN3CWbhm)
	if level=='3' and Wny7QDYmHoX6I0k8hcpAe:
		if len(rrRNKkcfmCYvjJ1PeQ2)>0:
			for tQZvr8cwngxb in range(len(rrRNKkcfmCYvjJ1PeQ2)):
				SSxInVQWbYrZtjF = str(tQZvr8cwngxb)
				gQoS7yfB1EN3CWbhm = []
				gQoS7yfB1EN3CWbhm.append("yfff["+SSxInVQWbYrZtjF+"]['richItemRenderer']['content']")
				gQoS7yfB1EN3CWbhm.append("yfff["+SSxInVQWbYrZtjF+"]['gameCardRenderer']['game']")
				gQoS7yfB1EN3CWbhm.append("yfff["+SSxInVQWbYrZtjF+"]['itemSectionRenderer']['contents'][0]")
				gQoS7yfB1EN3CWbhm.append("yfff["+SSxInVQWbYrZtjF+"]")
				gQoS7yfB1EN3CWbhm.append("yfff")
				zlQAfuT2Z7nKhGdXs,lkd2oKvZF03qmgMbIfQ6cD,cgwB6jCZf0dy3zvNFuRn5qo = C7W6YX3Q1Fl(rrRNKkcfmCYvjJ1PeQ2,qpFY4hAwolV3,gQoS7yfB1EN3CWbhm)
				if zlQAfuT2Z7nKhGdXs: UC6cHAVuZ0x5oGSMJa.append([lkd2oKvZF03qmgMbIfQ6cD,url,'4::'+S4rfoRcTAeEIYlBhHF3Q+'::'+wTnU7OdYhARf8DS0CBq+'::'+SSxInVQWbYrZtjF])
	return rrRNKkcfmCYvjJ1PeQ2,Wny7QDYmHoX6I0k8hcpAe,UC6cHAVuZ0x5oGSMJa,wgO16H9csdJK0zqyiV2IDr
def C7W6YX3Q1Fl(IIlp6evJZOsRD,nrBC7GIPf1QXADqFHitl,MMtA3RJcBf):
	kkFQn98geIM3,nrBC7GIPf1QXADqFHitl = IIlp6evJZOsRD,nrBC7GIPf1QXADqFHitl
	tWPCqgjkE9eS48om,nrBC7GIPf1QXADqFHitl = IIlp6evJZOsRD,nrBC7GIPf1QXADqFHitl
	XXgRhQ1qDVSieYl,nrBC7GIPf1QXADqFHitl = IIlp6evJZOsRD,nrBC7GIPf1QXADqFHitl
	rrRNKkcfmCYvjJ1PeQ2,nrBC7GIPf1QXADqFHitl = IIlp6evJZOsRD,nrBC7GIPf1QXADqFHitl
	lkd2oKvZF03qmgMbIfQ6cD,QQmHn4a8LAC5US76cqrX9WtPVJusxk = IIlp6evJZOsRD,nrBC7GIPf1QXADqFHitl
	count = len(MMtA3RJcBf)
	for nnZ13Rr6tYXio0DyfLVvSxBec in range(count):
		try:
			ikcxrYqSpWeDlwdFbhM7 = eval(MMtA3RJcBf[nnZ13Rr6tYXio0DyfLVvSxBec])
			return True,ikcxrYqSpWeDlwdFbhM7,nnZ13Rr6tYXio0DyfLVvSxBec+1
		except: pass
	return False,qpFY4hAwolV3,0
def c8U1BdtxOZS5FH(url,P9gc0wx41l3y26iufIkWtaUGnMZ=qpFY4hAwolV3,data=qpFY4hAwolV3):
	L9lBUF0pJfOKSqmMiC5j,sq0Tz98ILW1UgFkAHfcSO4yerRu2i,UC6cHAVuZ0x5oGSMJa = [],[],[]
	if '::' not in P9gc0wx41l3y26iufIkWtaUGnMZ: P9gc0wx41l3y26iufIkWtaUGnMZ = '1::0::0::0'
	level,S4rfoRcTAeEIYlBhHF3Q,wTnU7OdYhARf8DS0CBq,SSxInVQWbYrZtjF = P9gc0wx41l3y26iufIkWtaUGnMZ.split('::')
	if level=='4': level,S4rfoRcTAeEIYlBhHF3Q,wTnU7OdYhARf8DS0CBq,SSxInVQWbYrZtjF = '1',S4rfoRcTAeEIYlBhHF3Q,wTnU7OdYhARf8DS0CBq,SSxInVQWbYrZtjF
	data = data.replace('_REMEMBERRESULTS_',qpFY4hAwolV3)
	cmWl9dOKHPIy41iaXuxrY,kkFQn98geIM3,RZ2SwHp6GQvAy = ff26dPE3iqTSL7wcpQGZvM(url,data)
	P9gc0wx41l3y26iufIkWtaUGnMZ = level+'::'+S4rfoRcTAeEIYlBhHF3Q+'::'+wTnU7OdYhARf8DS0CBq+'::'+SSxInVQWbYrZtjF
	if level in ['1','2','3']:
		tWPCqgjkE9eS48om,dB3WynaLlomRX,L9lBUF0pJfOKSqmMiC5j,dIvTHPlhNxYLKy = fLGtqBukW8K0T3RwlxVAXbNZUC9iF(kkFQn98geIM3,url,P9gc0wx41l3y26iufIkWtaUGnMZ)
		if not dB3WynaLlomRX: return
		qOFUGe0lEDu4SKYk68VTCsH = len(L9lBUF0pJfOKSqmMiC5j)
		if qOFUGe0lEDu4SKYk68VTCsH<2:
			if level=='1': level = '2'
			L9lBUF0pJfOKSqmMiC5j = []
	P9gc0wx41l3y26iufIkWtaUGnMZ = level+'::'+S4rfoRcTAeEIYlBhHF3Q+'::'+wTnU7OdYhARf8DS0CBq+'::'+SSxInVQWbYrZtjF
	if level in ['2','3']:
		XXgRhQ1qDVSieYl,MkDAHUwnlSgVi8LtRFzueyIx7G4,sq0Tz98ILW1UgFkAHfcSO4yerRu2i,zziwMKNQhx6EIpWd = hT5mliPwgCu(kkFQn98geIM3,tWPCqgjkE9eS48om,url,P9gc0wx41l3y26iufIkWtaUGnMZ)
		if not MkDAHUwnlSgVi8LtRFzueyIx7G4: return
		zcxrwuK5T0pmdGXtM = len(sq0Tz98ILW1UgFkAHfcSO4yerRu2i)
		if zcxrwuK5T0pmdGXtM<2:
			if level=='2': level = '3'
			sq0Tz98ILW1UgFkAHfcSO4yerRu2i = []
	P9gc0wx41l3y26iufIkWtaUGnMZ = level+'::'+S4rfoRcTAeEIYlBhHF3Q+'::'+wTnU7OdYhARf8DS0CBq+'::'+SSxInVQWbYrZtjF
	if level in ['3']:
		rrRNKkcfmCYvjJ1PeQ2,Wny7QDYmHoX6I0k8hcpAe,UC6cHAVuZ0x5oGSMJa,wgO16H9csdJK0zqyiV2IDr = ikWyg1mQL3bD7EZ4KBFNfwVhv(kkFQn98geIM3,XXgRhQ1qDVSieYl,url,P9gc0wx41l3y26iufIkWtaUGnMZ)
		if not Wny7QDYmHoX6I0k8hcpAe: return
		YrTBZHeO42v = len(UC6cHAVuZ0x5oGSMJa)
	for lkd2oKvZF03qmgMbIfQ6cD,url,P9gc0wx41l3y26iufIkWtaUGnMZ in L9lBUF0pJfOKSqmMiC5j+sq0Tz98ILW1UgFkAHfcSO4yerRu2i+UC6cHAVuZ0x5oGSMJa:
		yybfMXcSVHaGio9xpuEDZwLl4e = x0lDXEatMIcTFqRZzQB4pdjnumy(lkd2oKvZF03qmgMbIfQ6cD,url,P9gc0wx41l3y26iufIkWtaUGnMZ)
	return
def x0lDXEatMIcTFqRZzQB4pdjnumy(lkd2oKvZF03qmgMbIfQ6cD,url=qpFY4hAwolV3,P9gc0wx41l3y26iufIkWtaUGnMZ=qpFY4hAwolV3):
	if '::' in P9gc0wx41l3y26iufIkWtaUGnMZ: level,S4rfoRcTAeEIYlBhHF3Q,wTnU7OdYhARf8DS0CBq,SSxInVQWbYrZtjF = P9gc0wx41l3y26iufIkWtaUGnMZ.split('::')
	else: level,S4rfoRcTAeEIYlBhHF3Q,wTnU7OdYhARf8DS0CBq,SSxInVQWbYrZtjF = '1','0','0','0'
	zlQAfuT2Z7nKhGdXs,title,MepIvHBYNArkUOdV37shtJ,Sj7rMNYRuQPTtkBvpHKeDW3h,count,dq0kBrGuKXiP,TAtO8KpChuNncl0vPVGMUEfZw5S,f04uqzIFPL8RQvWaciTwnH,SmRfnl7kaQEiV = xYtLDq37EARo(lkd2oKvZF03qmgMbIfQ6cD)
	xY63Sf08qUnLFo7 = '/videos?' in MepIvHBYNArkUOdV37shtJ or '/streams?' in MepIvHBYNArkUOdV37shtJ or '/playlists?' in MepIvHBYNArkUOdV37shtJ
	qDcIlBFs6Q18KE75PuxgTChkYS = '/channels?' in MepIvHBYNArkUOdV37shtJ or '/shorts?' in MepIvHBYNArkUOdV37shtJ
	if xY63Sf08qUnLFo7 or qDcIlBFs6Q18KE75PuxgTChkYS: MepIvHBYNArkUOdV37shtJ = url
	xY63Sf08qUnLFo7 = 'watch?v=' not in MepIvHBYNArkUOdV37shtJ and '/playlist?list=' not in MepIvHBYNArkUOdV37shtJ
	qDcIlBFs6Q18KE75PuxgTChkYS = '/gaming' not in MepIvHBYNArkUOdV37shtJ  and '/feed/storefront' not in MepIvHBYNArkUOdV37shtJ
	if P9gc0wx41l3y26iufIkWtaUGnMZ[0:5]=='3::0::' and xY63Sf08qUnLFo7 and qDcIlBFs6Q18KE75PuxgTChkYS: MepIvHBYNArkUOdV37shtJ = url
	if '/youtubei/v1/guide?key=' in url or '/gaming' in MepIvHBYNArkUOdV37shtJ:
		level,S4rfoRcTAeEIYlBhHF3Q,wTnU7OdYhARf8DS0CBq,SSxInVQWbYrZtjF = '1','0','0','0'
		P9gc0wx41l3y26iufIkWtaUGnMZ = qpFY4hAwolV3
	RZ2SwHp6GQvAy = qpFY4hAwolV3
	if '/youtubei/v1/browse' in MepIvHBYNArkUOdV37shtJ or '/youtubei/v1/search' in MepIvHBYNArkUOdV37shtJ or '/my_main_page_shorts_link' in url:
		data = gdPslyFW8ITBcpA302.getSetting('av.youtube.data')
		if data.count(':::')==4:
			SZHKb5vEAcWjBYO61hu2XDGCs,key,rRKzwjFGnaL6DoMsqWEUfeNJ4,S8APDNIJKLkopCdZabhYUWwmt6G1B,hkpnFx0WLU = data.split(':::')
			RZ2SwHp6GQvAy = SZHKb5vEAcWjBYO61hu2XDGCs+':::'+key+':::'+rRKzwjFGnaL6DoMsqWEUfeNJ4+':::'+S8APDNIJKLkopCdZabhYUWwmt6G1B+':::'+SmRfnl7kaQEiV
			if '/my_main_page_shorts_link' in url and not MepIvHBYNArkUOdV37shtJ: MepIvHBYNArkUOdV37shtJ = url
			else: MepIvHBYNArkUOdV37shtJ = MepIvHBYNArkUOdV37shtJ+'?key='+key
	if not title:
		global cC2iaBSo1tGuwJLRMr4WvqsV5pj
		cC2iaBSo1tGuwJLRMr4WvqsV5pj += 1
		title = 'فيديوهات '+str(cC2iaBSo1tGuwJLRMr4WvqsV5pj)
		P9gc0wx41l3y26iufIkWtaUGnMZ = '3'+'::'+S4rfoRcTAeEIYlBhHF3Q+'::'+wTnU7OdYhARf8DS0CBq+'::'+SSxInVQWbYrZtjF
	if not zlQAfuT2Z7nKhGdXs: return False
	elif 'searchPyvRenderer' in str(lkd2oKvZF03qmgMbIfQ6cD): return False
	elif '/about' in MepIvHBYNArkUOdV37shtJ: return False
	elif '/community' in MepIvHBYNArkUOdV37shtJ: return False
	elif 'continuationItemRenderer' in list(lkd2oKvZF03qmgMbIfQ6cD.keys()) or 'continuationCommand' in list(lkd2oKvZF03qmgMbIfQ6cD.keys()):
		if int(level)>1: level = str(int(level)-1)
		P9gc0wx41l3y26iufIkWtaUGnMZ = level+'::'+S4rfoRcTAeEIYlBhHF3Q+'::'+wTnU7OdYhARf8DS0CBq+'::'+SSxInVQWbYrZtjF
		x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+':: '+'صفحة أخرى',MepIvHBYNArkUOdV37shtJ,144,Sj7rMNYRuQPTtkBvpHKeDW3h,P9gc0wx41l3y26iufIkWtaUGnMZ,RZ2SwHp6GQvAy)
	elif '/search' in MepIvHBYNArkUOdV37shtJ:
		title = ':: '+title
		P9gc0wx41l3y26iufIkWtaUGnMZ = '3'+'::'+S4rfoRcTAeEIYlBhHF3Q+'::'+wTnU7OdYhARf8DS0CBq+'::'+SSxInVQWbYrZtjF
		url = url.replace('/search',qpFY4hAwolV3)
		x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+title,url,145,qpFY4hAwolV3,P9gc0wx41l3y26iufIkWtaUGnMZ,'_REMEMBERRESULTS_')
	elif 'search_query' in url and not MepIvHBYNArkUOdV37shtJ:
		P9gc0wx41l3y26iufIkWtaUGnMZ = '3'+'::'+S4rfoRcTAeEIYlBhHF3Q+'::'+wTnU7OdYhARf8DS0CBq+'::'+SSxInVQWbYrZtjF
		title = ':: '+title
		x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+title,url,144,Sj7rMNYRuQPTtkBvpHKeDW3h,P9gc0wx41l3y26iufIkWtaUGnMZ,RZ2SwHp6GQvAy)
	elif '/browse' in MepIvHBYNArkUOdV37shtJ and url==ddBxj51bhNtaK23lDyGMVw:
		title = ':: '+title
		P9gc0wx41l3y26iufIkWtaUGnMZ = '2::0::0::0'
		x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,144,Sj7rMNYRuQPTtkBvpHKeDW3h,P9gc0wx41l3y26iufIkWtaUGnMZ,RZ2SwHp6GQvAy)
	elif not MepIvHBYNArkUOdV37shtJ and 'horizontalMovieListRenderer' in str(lkd2oKvZF03qmgMbIfQ6cD):
		title = ':: '+title
		P9gc0wx41l3y26iufIkWtaUGnMZ = '3::0::0::0'
		x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+title,url,144,Sj7rMNYRuQPTtkBvpHKeDW3h,P9gc0wx41l3y26iufIkWtaUGnMZ)
	elif 'messageRenderer' in str(lkd2oKvZF03qmgMbIfQ6cD):
		x3WSXnKyPhjqfHG2UrtQs('link',wwSFijdVJn1QgHW+title,qpFY4hAwolV3,9999)
	elif TAtO8KpChuNncl0vPVGMUEfZw5S:
		x3WSXnKyPhjqfHG2UrtQs('live',wwSFijdVJn1QgHW+TAtO8KpChuNncl0vPVGMUEfZw5S+title,MepIvHBYNArkUOdV37shtJ,143,Sj7rMNYRuQPTtkBvpHKeDW3h)
	elif '/playlist?list=' in MepIvHBYNArkUOdV37shtJ:
		MepIvHBYNArkUOdV37shtJ = MepIvHBYNArkUOdV37shtJ.replace('&playnext=1',qpFY4hAwolV3)
		x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+'LIST'+count+':  '+title,MepIvHBYNArkUOdV37shtJ,144,Sj7rMNYRuQPTtkBvpHKeDW3h,P9gc0wx41l3y26iufIkWtaUGnMZ)
	elif '/shorts/' in MepIvHBYNArkUOdV37shtJ:
		MepIvHBYNArkUOdV37shtJ = MepIvHBYNArkUOdV37shtJ.split('&list=',1)[0]
		x3WSXnKyPhjqfHG2UrtQs('video',wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,143,Sj7rMNYRuQPTtkBvpHKeDW3h,dq0kBrGuKXiP)
	elif '/watch?v=' in MepIvHBYNArkUOdV37shtJ:
		if '&list=' in MepIvHBYNArkUOdV37shtJ and count:
			z4Zo03IgaGjmtNQbPW = MepIvHBYNArkUOdV37shtJ.split('&list=',1)[1]
			MepIvHBYNArkUOdV37shtJ = ddBxj51bhNtaK23lDyGMVw+'/playlist?list='+z4Zo03IgaGjmtNQbPW
			P9gc0wx41l3y26iufIkWtaUGnMZ = '1::0::0::0'
			x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+'LIST'+count+':  '+title,MepIvHBYNArkUOdV37shtJ,144,Sj7rMNYRuQPTtkBvpHKeDW3h,P9gc0wx41l3y26iufIkWtaUGnMZ)
		else:
			MepIvHBYNArkUOdV37shtJ = MepIvHBYNArkUOdV37shtJ.split('&list=',1)[0]
			x3WSXnKyPhjqfHG2UrtQs('video',wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,143,Sj7rMNYRuQPTtkBvpHKeDW3h,dq0kBrGuKXiP)
	elif '/channel/' in MepIvHBYNArkUOdV37shtJ or '/c/' in MepIvHBYNArkUOdV37shtJ or ('/@' in MepIvHBYNArkUOdV37shtJ and MepIvHBYNArkUOdV37shtJ.count(ShynO8pN9idCE3)==3):
		if NJwViHDTMdmO0xnALqQ9voPalC3Ip:
			title = title.decode(nV3Tip6XsH1rJw79DPOU).encode('raw_unicode_escape')
			title = N8E37XwL6iQbmBY(title)
		x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+'CHNL'+count+':  '+title,MepIvHBYNArkUOdV37shtJ,144,Sj7rMNYRuQPTtkBvpHKeDW3h,P9gc0wx41l3y26iufIkWtaUGnMZ)
	elif '/user/' in MepIvHBYNArkUOdV37shtJ:
		x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+'USER'+count+':  '+title,MepIvHBYNArkUOdV37shtJ,144,Sj7rMNYRuQPTtkBvpHKeDW3h,P9gc0wx41l3y26iufIkWtaUGnMZ)
	else:
		if not MepIvHBYNArkUOdV37shtJ: MepIvHBYNArkUOdV37shtJ = url
		title = ':: '+title
		x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,144,Sj7rMNYRuQPTtkBvpHKeDW3h,P9gc0wx41l3y26iufIkWtaUGnMZ,RZ2SwHp6GQvAy)
	return True
def xYtLDq37EARo(lkd2oKvZF03qmgMbIfQ6cD):
	zlQAfuT2Z7nKhGdXs,title,MepIvHBYNArkUOdV37shtJ,Sj7rMNYRuQPTtkBvpHKeDW3h,count,dq0kBrGuKXiP,TAtO8KpChuNncl0vPVGMUEfZw5S,f04uqzIFPL8RQvWaciTwnH,hkpnFx0WLU = False,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3
	if not isinstance(lkd2oKvZF03qmgMbIfQ6cD,dict): return zlQAfuT2Z7nKhGdXs,title,MepIvHBYNArkUOdV37shtJ,Sj7rMNYRuQPTtkBvpHKeDW3h,count,dq0kBrGuKXiP,TAtO8KpChuNncl0vPVGMUEfZw5S,f04uqzIFPL8RQvWaciTwnH,hkpnFx0WLU
	for UZnt75XA0HdFIqjQ in list(lkd2oKvZF03qmgMbIfQ6cD.keys()):
		QQmHn4a8LAC5US76cqrX9WtPVJusxk = lkd2oKvZF03qmgMbIfQ6cD[UZnt75XA0HdFIqjQ]
		if isinstance(QQmHn4a8LAC5US76cqrX9WtPVJusxk,dict): break
	gQoS7yfB1EN3CWbhm = []
	gQoS7yfB1EN3CWbhm.append("yrender['header']['playlistHeaderRenderer']['title']['simpleText']")
	gQoS7yfB1EN3CWbhm.append("yrender['header']['richListHeaderRenderer']['title']['simpleText']")
	gQoS7yfB1EN3CWbhm.append("yrender['header']['richListHeaderRenderer']['title']")
	gQoS7yfB1EN3CWbhm.append("yrender['headline']['simpleText']")
	gQoS7yfB1EN3CWbhm.append("yrender['unplayableText']['simpleText']")
	gQoS7yfB1EN3CWbhm.append("yrender['formattedTitle']['simpleText']")
	gQoS7yfB1EN3CWbhm.append("yrender['title']['simpleText']")
	gQoS7yfB1EN3CWbhm.append("yrender['title']['runs'][0]['text']")
	gQoS7yfB1EN3CWbhm.append("yrender['text']['simpleText']")
	gQoS7yfB1EN3CWbhm.append("yrender['text']['runs'][0]['text']")
	gQoS7yfB1EN3CWbhm.append("yrender['title']['content']")
	gQoS7yfB1EN3CWbhm.append("yrender['title']")
	gQoS7yfB1EN3CWbhm.append("item['title']")
	gQoS7yfB1EN3CWbhm.append("item['reelWatchEndpoint']['videoId']")
	zlQAfuT2Z7nKhGdXs,title,cgwB6jCZf0dy3zvNFuRn5qo = C7W6YX3Q1Fl(lkd2oKvZF03qmgMbIfQ6cD,QQmHn4a8LAC5US76cqrX9WtPVJusxk,gQoS7yfB1EN3CWbhm)
	gQoS7yfB1EN3CWbhm = []
	gQoS7yfB1EN3CWbhm.append("yrender['title']['runs'][0]['navigationEndpoint']['commandMetadata']['webCommandMetadata']['url']")
	gQoS7yfB1EN3CWbhm.append("yrender['navigationEndpoint']['commandMetadata']['webCommandMetadata']['url']")
	gQoS7yfB1EN3CWbhm.append("yrender['continuationEndpoint']['commandMetadata']['webCommandMetadata']['apiUrl']")
	gQoS7yfB1EN3CWbhm.append("yrender['navigationEndpoint']['commandMetadata']['webCommandMetadata']['apiUrl']")
	gQoS7yfB1EN3CWbhm.append("yrender['endpoint']['commandMetadata']['webCommandMetadata']['url']")
	gQoS7yfB1EN3CWbhm.append("item['endpoint']['commandMetadata']['webCommandMetadata']['url']")
	gQoS7yfB1EN3CWbhm.append("item['commandMetadata']['webCommandMetadata']['url']")
	zlQAfuT2Z7nKhGdXs,MepIvHBYNArkUOdV37shtJ,cgwB6jCZf0dy3zvNFuRn5qo = C7W6YX3Q1Fl(lkd2oKvZF03qmgMbIfQ6cD,QQmHn4a8LAC5US76cqrX9WtPVJusxk,gQoS7yfB1EN3CWbhm)
	gQoS7yfB1EN3CWbhm = []
	gQoS7yfB1EN3CWbhm.append("yrender['thumbnail']['thumbnails'][0]['url']")
	gQoS7yfB1EN3CWbhm.append("yrender['thumbnails'][0]['thumbnails'][0]['url']")
	gQoS7yfB1EN3CWbhm.append("item['reelWatchEndpoint']['thumbnail']['thumbnails'][0]['url']")
	zlQAfuT2Z7nKhGdXs,Sj7rMNYRuQPTtkBvpHKeDW3h,cgwB6jCZf0dy3zvNFuRn5qo = C7W6YX3Q1Fl(lkd2oKvZF03qmgMbIfQ6cD,QQmHn4a8LAC5US76cqrX9WtPVJusxk,gQoS7yfB1EN3CWbhm)
	gQoS7yfB1EN3CWbhm = []
	gQoS7yfB1EN3CWbhm.append("yrender['thumbnailOverlays'][0]['thumbnailOverlayBottomPanelRenderer']['text']['runs'][0]['text']")
	gQoS7yfB1EN3CWbhm.append("yrender['videoCountShortText']['simpleText']")
	gQoS7yfB1EN3CWbhm.append("yrender['videoCountText']['runs'][0]['text']")
	gQoS7yfB1EN3CWbhm.append("yrender['videoCount']")
	zlQAfuT2Z7nKhGdXs,count,cgwB6jCZf0dy3zvNFuRn5qo = C7W6YX3Q1Fl(lkd2oKvZF03qmgMbIfQ6cD,QQmHn4a8LAC5US76cqrX9WtPVJusxk,gQoS7yfB1EN3CWbhm)
	gQoS7yfB1EN3CWbhm = []
	gQoS7yfB1EN3CWbhm.append("yrender['thumbnailOverlays'][0]['thumbnailOverlayTimeStatusRenderer']['text']['runs'][0]['text']")
	gQoS7yfB1EN3CWbhm.append("yrender['thumbnailOverlays'][0]['thumbnailOverlayTimeStatusRenderer']['text']['simpleText']")
	gQoS7yfB1EN3CWbhm.append("yrender['lengthText']['simpleText']")
	gQoS7yfB1EN3CWbhm.append("yrender['thumbnailOverlays'][0]['thumbnailOverlayTimeStatusRenderer']['icon']['iconType']")
	gQoS7yfB1EN3CWbhm.append("yrender['thumbnailOverlays'][0]['thumbnailOverlayTimeStatusRenderer']['style']")
	zlQAfuT2Z7nKhGdXs,dq0kBrGuKXiP,cgwB6jCZf0dy3zvNFuRn5qo = C7W6YX3Q1Fl(lkd2oKvZF03qmgMbIfQ6cD,QQmHn4a8LAC5US76cqrX9WtPVJusxk,gQoS7yfB1EN3CWbhm)
	gQoS7yfB1EN3CWbhm = []
	gQoS7yfB1EN3CWbhm.append("yrender['navigationEndpoint']['continuationCommand']['token']")
	gQoS7yfB1EN3CWbhm.append("yrender['continuationEndpoint']['continuationCommand']['token']")
	zlQAfuT2Z7nKhGdXs,hkpnFx0WLU,cgwB6jCZf0dy3zvNFuRn5qo = C7W6YX3Q1Fl(lkd2oKvZF03qmgMbIfQ6cD,QQmHn4a8LAC5US76cqrX9WtPVJusxk,gQoS7yfB1EN3CWbhm)
	if 'LIVE' in dq0kBrGuKXiP: dq0kBrGuKXiP,TAtO8KpChuNncl0vPVGMUEfZw5S = qpFY4hAwolV3,'LIVE:  '
	if 'مباشر' in dq0kBrGuKXiP: dq0kBrGuKXiP,TAtO8KpChuNncl0vPVGMUEfZw5S = qpFY4hAwolV3,'LIVE:  '
	if 'badges' in list(QQmHn4a8LAC5US76cqrX9WtPVJusxk.keys()):
		pCgqSjYJnc4yPBbDZoAe2hK5FOa = str(QQmHn4a8LAC5US76cqrX9WtPVJusxk['badges'])
		if 'Free with Ads' in pCgqSjYJnc4yPBbDZoAe2hK5FOa: f04uqzIFPL8RQvWaciTwnH = '$:  '
		if 'LIVE' in pCgqSjYJnc4yPBbDZoAe2hK5FOa: TAtO8KpChuNncl0vPVGMUEfZw5S = 'LIVE:  '
		if 'Buy' in pCgqSjYJnc4yPBbDZoAe2hK5FOa or 'Rent' in pCgqSjYJnc4yPBbDZoAe2hK5FOa: f04uqzIFPL8RQvWaciTwnH = '$$:  '
		if AACymb8gWpiZPTSjE5RxheqzHN(u'مباشر') in pCgqSjYJnc4yPBbDZoAe2hK5FOa: TAtO8KpChuNncl0vPVGMUEfZw5S = 'LIVE:  '
		if AACymb8gWpiZPTSjE5RxheqzHN(u'شراء') in pCgqSjYJnc4yPBbDZoAe2hK5FOa: f04uqzIFPL8RQvWaciTwnH = '$$:  '
		if AACymb8gWpiZPTSjE5RxheqzHN(u'استئجار') in pCgqSjYJnc4yPBbDZoAe2hK5FOa: f04uqzIFPL8RQvWaciTwnH = '$$:  '
		if AACymb8gWpiZPTSjE5RxheqzHN(u'إعلانات') in pCgqSjYJnc4yPBbDZoAe2hK5FOa: f04uqzIFPL8RQvWaciTwnH = '$:  '
	MepIvHBYNArkUOdV37shtJ = N8E37XwL6iQbmBY(MepIvHBYNArkUOdV37shtJ)
	if MepIvHBYNArkUOdV37shtJ and 'http' not in MepIvHBYNArkUOdV37shtJ: MepIvHBYNArkUOdV37shtJ = ddBxj51bhNtaK23lDyGMVw+MepIvHBYNArkUOdV37shtJ
	Sj7rMNYRuQPTtkBvpHKeDW3h = Sj7rMNYRuQPTtkBvpHKeDW3h.split('?')[0]
	if  Sj7rMNYRuQPTtkBvpHKeDW3h and 'http' not in Sj7rMNYRuQPTtkBvpHKeDW3h: Sj7rMNYRuQPTtkBvpHKeDW3h = 'https:'+Sj7rMNYRuQPTtkBvpHKeDW3h
	title = N8E37XwL6iQbmBY(title)
	if f04uqzIFPL8RQvWaciTwnH: title = f04uqzIFPL8RQvWaciTwnH+title
	dq0kBrGuKXiP = dq0kBrGuKXiP.replace(',',qpFY4hAwolV3)
	count = count.replace(',',qpFY4hAwolV3)
	count = ePhmG1jLD6.findall('\d+',count)
	if count: count = count[0]
	else: count = qpFY4hAwolV3
	return True,title,MepIvHBYNArkUOdV37shtJ,Sj7rMNYRuQPTtkBvpHKeDW3h,count,dq0kBrGuKXiP,TAtO8KpChuNncl0vPVGMUEfZw5S,f04uqzIFPL8RQvWaciTwnH,hkpnFx0WLU
def ff26dPE3iqTSL7wcpQGZvM(url,data=qpFY4hAwolV3,AMbRf4XTpQNvio6J5GELducy0k=qpFY4hAwolV3):
	if AMbRf4XTpQNvio6J5GELducy0k==qpFY4hAwolV3: AMbRf4XTpQNvio6J5GELducy0k = 'ytInitialData'
	NNWJKEyq13t2kglAZ7d = IyjRtqkmHFBvTCDYwuQNJ0()
	skD7g3FxW4wCa5BR = {'User-Agent':NNWJKEyq13t2kglAZ7d,'Cookie':'PREF=hl=ar'}
	global gdPslyFW8ITBcpA302
	if not data: data = gdPslyFW8ITBcpA302.getSetting('av.youtube.data')
	if data.count(':::')==4: SZHKb5vEAcWjBYO61hu2XDGCs,key,rRKzwjFGnaL6DoMsqWEUfeNJ4,S8APDNIJKLkopCdZabhYUWwmt6G1B,hkpnFx0WLU = data.split(':::')
	else: SZHKb5vEAcWjBYO61hu2XDGCs,key,rRKzwjFGnaL6DoMsqWEUfeNJ4,S8APDNIJKLkopCdZabhYUWwmt6G1B,hkpnFx0WLU = qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3
	RZ2SwHp6GQvAy = {"context":{"client":{"hl":"ar","clientName":"WEB","clientVersion":rRKzwjFGnaL6DoMsqWEUfeNJ4}}}
	if url==ddBxj51bhNtaK23lDyGMVw+'/shorts' or '/my_main_page_shorts_link' in url:
		url = ddBxj51bhNtaK23lDyGMVw+'/youtubei/v1/reel/reel_watch_sequence'+'?key='+key
		RZ2SwHp6GQvAy['sequenceParams'] = SZHKb5vEAcWjBYO61hu2XDGCs
		RZ2SwHp6GQvAy = str(RZ2SwHp6GQvAy)
		IAW0sh6So3NpqM = WWrExJZS3Bj4anOAkpv7(rGY36xBwT1bLZAngSfcWEIeXdQVNij,'POST',url,RZ2SwHp6GQvAy,skD7g3FxW4wCa5BR,True,True,'YOUTUBE-GET_PAGE_DATA-1st')
	elif '/guide?key=' in url:
		url = ddBxj51bhNtaK23lDyGMVw+'/youtubei/v1/guide?key='+key
		RZ2SwHp6GQvAy = str(RZ2SwHp6GQvAy)
		IAW0sh6So3NpqM = WWrExJZS3Bj4anOAkpv7(rGY36xBwT1bLZAngSfcWEIeXdQVNij,'POST',url,RZ2SwHp6GQvAy,skD7g3FxW4wCa5BR,True,True,'YOUTUBE-GET_PAGE_DATA-3rd')
	elif 'key=' in url and SZHKb5vEAcWjBYO61hu2XDGCs:
		RZ2SwHp6GQvAy['continuation'] = hkpnFx0WLU
		RZ2SwHp6GQvAy['context']['client']['visitorData'] = SZHKb5vEAcWjBYO61hu2XDGCs
		RZ2SwHp6GQvAy = str(RZ2SwHp6GQvAy)
		IAW0sh6So3NpqM = WWrExJZS3Bj4anOAkpv7(rGY36xBwT1bLZAngSfcWEIeXdQVNij,'POST',url,RZ2SwHp6GQvAy,skD7g3FxW4wCa5BR,True,True,'YOUTUBE-GET_PAGE_DATA-4th')
	elif 'ctoken=' in url and S8APDNIJKLkopCdZabhYUWwmt6G1B:
		skD7g3FxW4wCa5BR.update({'X-YouTube-Client-Name':'1','X-YouTube-Client-Version':rRKzwjFGnaL6DoMsqWEUfeNJ4})
		skD7g3FxW4wCa5BR.update({'Cookie':'VISITOR_INFO1_LIVE='+S8APDNIJKLkopCdZabhYUWwmt6G1B})
		IAW0sh6So3NpqM = WWrExJZS3Bj4anOAkpv7(rGY36xBwT1bLZAngSfcWEIeXdQVNij,'GET',url,qpFY4hAwolV3,skD7g3FxW4wCa5BR,qpFY4hAwolV3,qpFY4hAwolV3,'YOUTUBE-GET_PAGE_DATA-5th')
	else:
		IAW0sh6So3NpqM = WWrExJZS3Bj4anOAkpv7(rGY36xBwT1bLZAngSfcWEIeXdQVNij,'GET',url,qpFY4hAwolV3,skD7g3FxW4wCa5BR,qpFY4hAwolV3,qpFY4hAwolV3,'YOUTUBE-GET_PAGE_DATA-6th')
	cmWl9dOKHPIy41iaXuxrY = IAW0sh6So3NpqM.content
	sgWRIGYQHUhXw5kPzN4OnoZJ1c9 = ePhmG1jLD6.findall('"innertubeApiKey".*?"(.*?)"',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL|ePhmG1jLD6.I)
	if sgWRIGYQHUhXw5kPzN4OnoZJ1c9: key = sgWRIGYQHUhXw5kPzN4OnoZJ1c9[0]
	sgWRIGYQHUhXw5kPzN4OnoZJ1c9 = ePhmG1jLD6.findall('"cver".*?"value".*?"(.*?)"',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL|ePhmG1jLD6.I)
	if sgWRIGYQHUhXw5kPzN4OnoZJ1c9: rRKzwjFGnaL6DoMsqWEUfeNJ4 = sgWRIGYQHUhXw5kPzN4OnoZJ1c9[0]
	sgWRIGYQHUhXw5kPzN4OnoZJ1c9 = ePhmG1jLD6.findall('"visitorData".*?"(.*?)"',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL|ePhmG1jLD6.I)
	if sgWRIGYQHUhXw5kPzN4OnoZJ1c9: SZHKb5vEAcWjBYO61hu2XDGCs = sgWRIGYQHUhXw5kPzN4OnoZJ1c9[0]
	cookies = IAW0sh6So3NpqM.cookies
	if 'VISITOR_INFO1_LIVE' in list(cookies.keys()): S8APDNIJKLkopCdZabhYUWwmt6G1B = cookies['VISITOR_INFO1_LIVE']
	bZq83DEzAKGxJk4QaUV7w6WuhCj = SZHKb5vEAcWjBYO61hu2XDGCs+':::'+key+':::'+rRKzwjFGnaL6DoMsqWEUfeNJ4+':::'+S8APDNIJKLkopCdZabhYUWwmt6G1B+':::'+hkpnFx0WLU
	if AMbRf4XTpQNvio6J5GELducy0k=='ytInitialData' and 'ytInitialData' in cmWl9dOKHPIy41iaXuxrY:
		D1DdugOv7nps2BEirPeCK9XtFAzJ = ePhmG1jLD6.findall('window\["ytInitialData"\] = ({.*?});',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
		if not D1DdugOv7nps2BEirPeCK9XtFAzJ: D1DdugOv7nps2BEirPeCK9XtFAzJ = ePhmG1jLD6.findall('var ytInitialData = ({.*?});',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
		rv9zqHCpQNi = wB8NUAidPbqjIr9CFasXvYnxOQpL0g('str',D1DdugOv7nps2BEirPeCK9XtFAzJ[0])
	elif AMbRf4XTpQNvio6J5GELducy0k=='ytInitialGuideData' and 'ytInitialGuideData' in cmWl9dOKHPIy41iaXuxrY:
		D1DdugOv7nps2BEirPeCK9XtFAzJ = ePhmG1jLD6.findall('var ytInitialGuideData = ({.*?});',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
		rv9zqHCpQNi = wB8NUAidPbqjIr9CFasXvYnxOQpL0g('str',D1DdugOv7nps2BEirPeCK9XtFAzJ[0])
	elif '</script>' not in cmWl9dOKHPIy41iaXuxrY: rv9zqHCpQNi = wB8NUAidPbqjIr9CFasXvYnxOQpL0g('str',cmWl9dOKHPIy41iaXuxrY)
	else: rv9zqHCpQNi = qpFY4hAwolV3
	if 0:
		kkFQn98geIM3 = str(rv9zqHCpQNi)
		if DLod2Of8CkRrtzJynev: kkFQn98geIM3 = kkFQn98geIM3.encode(nV3Tip6XsH1rJw79DPOU)
		open('S:\\0000emad.dat','wb').write(kkFQn98geIM3)
	gdPslyFW8ITBcpA302.setSetting('av.youtube.data',bZq83DEzAKGxJk4QaUV7w6WuhCj)
	return cmWl9dOKHPIy41iaXuxrY,rv9zqHCpQNi,bZq83DEzAKGxJk4QaUV7w6WuhCj
def O1xHLFnSdMwGtK3kZaNj29QT(url,P9gc0wx41l3y26iufIkWtaUGnMZ):
	search = jXgARlWMLVFUBnvmZwI2o5()
	if not search: return
	search = search.replace(mIsDke0oK5x1zSiOWbF9thGcA,'+')
	WSQlG8mDhqsNe = url+'/search?query='+search
	c8U1BdtxOZS5FH(WSQlG8mDhqsNe,P9gc0wx41l3y26iufIkWtaUGnMZ)
	return
def PPqUACSE3VcGLTvw05jHy9JrFNW(search):
	search,LBylNhMdH6OV1qGk0tWiXFg3,showDialogs = LLm3sBXHPcnTDxdE5gt6hz0Wkp(search)
	if not search:
		search = jXgARlWMLVFUBnvmZwI2o5()
		if not search: return
	search = search.replace(mIsDke0oK5x1zSiOWbF9thGcA,'+')
	WSQlG8mDhqsNe = ddBxj51bhNtaK23lDyGMVw+'/results?search_query='+search
	if not showDialogs:
		if '_YOUTUBE-VIDEOS_' in LBylNhMdH6OV1qGk0tWiXFg3: yR3UtqoQav4cpAur2EVKs = '&sp=EgIQAQ%253D%253D'
		elif '_YOUTUBE-PLAYLISTS_' in LBylNhMdH6OV1qGk0tWiXFg3: yR3UtqoQav4cpAur2EVKs = '&sp=EgIQAw%253D%253D'
		elif '_YOUTUBE-CHANNELS_' in LBylNhMdH6OV1qGk0tWiXFg3: yR3UtqoQav4cpAur2EVKs = '&sp=EgIQAg%253D%253D'
		else: yR3UtqoQav4cpAur2EVKs = qpFY4hAwolV3
		hhpztscnBD1GP = WSQlG8mDhqsNe+yR3UtqoQav4cpAur2EVKs
	else:
		dySeGa5H39lm7g2qLY,cbnaxYA0jhtNz5,UdbGw48M6rCHDRmea5qP91nKI = [],[],qpFY4hAwolV3
		IEq761FzcaA85VD9Z = ['فيديوهات مرتبة بالصلة','فيديوهات مرتبة بالتاريخ','فيديوهات مرتبة بعدد المشاهدات','فيديوهات مرتبة بالتقييم','(جيد للمسلسلات) قوائم تشغيل','قنوات','بث حي']
		wDNAqyQ4SnZ = ['&sp=CAASAhAB','&sp=CAISAhAB','&sp=CAMSAhAB','&sp=CAESAhAB','&sp=EgIQAw==','&sp=EgIQAg==','&sp=EgJAAQ==']
		FKUNojrG79vsdWYqtlPnhDp0kX = xVzqWbrFXJ('اختر البحث المناسب',IEq761FzcaA85VD9Z)
		if FKUNojrG79vsdWYqtlPnhDp0kX == -1: return
		xRLIKcz9XFb3 = wDNAqyQ4SnZ[FKUNojrG79vsdWYqtlPnhDp0kX]
		cmWl9dOKHPIy41iaXuxrY,ttx1HCgfUFWSa,data = ff26dPE3iqTSL7wcpQGZvM(WSQlG8mDhqsNe+xRLIKcz9XFb3)
		if ttx1HCgfUFWSa:
			try:
				ACk6yMhiJQYudeP = ttx1HCgfUFWSa['contents']['twoColumnSearchResultsRenderer']['primaryContents']['sectionListRenderer']['subMenu']['searchSubMenuRenderer']['groups']
				for ZzkY5cQUdIrDJFboBXuvalghE23ns in range(len(ACk6yMhiJQYudeP)):
					group = ACk6yMhiJQYudeP[ZzkY5cQUdIrDJFboBXuvalghE23ns]['searchFilterGroupRenderer']['filters']
					for p7XUcNoGTSHy9vD0WFq in range(len(group)):
						QQmHn4a8LAC5US76cqrX9WtPVJusxk = group[p7XUcNoGTSHy9vD0WFq]['searchFilterRenderer']
						if 'navigationEndpoint' in list(QQmHn4a8LAC5US76cqrX9WtPVJusxk.keys()):
							MepIvHBYNArkUOdV37shtJ = QQmHn4a8LAC5US76cqrX9WtPVJusxk['navigationEndpoint']['commandMetadata']['webCommandMetadata']['url']
							MepIvHBYNArkUOdV37shtJ = MepIvHBYNArkUOdV37shtJ.replace('\u0026','&')
							title = QQmHn4a8LAC5US76cqrX9WtPVJusxk['tooltip']
							title = title.replace('البحث عن ',qpFY4hAwolV3)
							if 'إزالة الفلتر' in title: continue
							if 'قائمة تشغيل' in title:
								title = 'جيد للمسلسلات '+title
								UdbGw48M6rCHDRmea5qP91nKI = title
								OexQX2mTwfGkuU6AIBLz9vWlHjdF8 = MepIvHBYNArkUOdV37shtJ
							if 'ترتيب حسب' in title: continue
							title = title.replace('Search for ',qpFY4hAwolV3)
							if 'Remove' in title: continue
							if 'Playlist' in title:
								title = 'جيد للمسلسلات '+title
								UdbGw48M6rCHDRmea5qP91nKI = title
								OexQX2mTwfGkuU6AIBLz9vWlHjdF8 = MepIvHBYNArkUOdV37shtJ
							if 'Sort by' in title: continue
							dySeGa5H39lm7g2qLY.append(N8E37XwL6iQbmBY(title))
							cbnaxYA0jhtNz5.append(MepIvHBYNArkUOdV37shtJ)
			except: pass
		if not UdbGw48M6rCHDRmea5qP91nKI: ev9JRhqpf2m5nbw4kC61yTQIc3Yr = qpFY4hAwolV3
		else:
			dySeGa5H39lm7g2qLY = ['بدون فلتر',UdbGw48M6rCHDRmea5qP91nKI]+dySeGa5H39lm7g2qLY
			cbnaxYA0jhtNz5 = [qpFY4hAwolV3,OexQX2mTwfGkuU6AIBLz9vWlHjdF8]+cbnaxYA0jhtNz5
			U4n0iH6Ql5mW2dS = xVzqWbrFXJ('موقع يوتيوب - اختر الفلتر',dySeGa5H39lm7g2qLY)
			if U4n0iH6Ql5mW2dS == -1: return
			ev9JRhqpf2m5nbw4kC61yTQIc3Yr = cbnaxYA0jhtNz5[U4n0iH6Ql5mW2dS]
		if ev9JRhqpf2m5nbw4kC61yTQIc3Yr: hhpztscnBD1GP = ddBxj51bhNtaK23lDyGMVw+ev9JRhqpf2m5nbw4kC61yTQIc3Yr
		elif xRLIKcz9XFb3: hhpztscnBD1GP = WSQlG8mDhqsNe+xRLIKcz9XFb3
		else: hhpztscnBD1GP = WSQlG8mDhqsNe
	c8U1BdtxOZS5FH(hhpztscnBD1GP)
	return