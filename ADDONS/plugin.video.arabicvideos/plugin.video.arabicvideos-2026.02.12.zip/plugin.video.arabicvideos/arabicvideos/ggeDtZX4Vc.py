# -*- coding: utf-8 -*-
from pSfaryIjBo import *
Q8Q0IDc6PLZajJAdTntKUmSGXz = 'SHOFHA'
wwSFijdVJn1QgHW = '_SHT_'
ddBxj51bhNtaK23lDyGMVw = i4bFG3rKE6.SITESURLS[Q8Q0IDc6PLZajJAdTntKUmSGXz][0]
YEIA19ehBwpNfPVzK = ['الصفحة الرئيسية','Sign in','أفلام للكبار فقط']
def vTNE2Ck1sGnugJYW8y39aLcSH64U(mode,url,text):
	if   mode==640: MOTjA5H9XFs = nRVAZc4Dp8PSrGU3xBk()
	elif mode==641: MOTjA5H9XFs = c8U1BdtxOZS5FH(url,text)
	elif mode==642: MOTjA5H9XFs = mzcAeyplZV(url)
	elif mode==644: MOTjA5H9XFs = X2rO3lubqIdCGMLYWcxA6DK5(url)
	elif mode==645: MOTjA5H9XFs = v1gmfxDcRrWKQ(url)
	elif mode==649: MOTjA5H9XFs = PPqUACSE3VcGLTvw05jHy9JrFNW(text)
	else: MOTjA5H9XFs = False
	return MOTjA5H9XFs
def nRVAZc4Dp8PSrGU3xBk():
	IAW0sh6So3NpqM = WWrExJZS3Bj4anOAkpv7(kUz8c7OqsxuPFIGfwg,'GET',ddBxj51bhNtaK23lDyGMVw,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,'SHOFHA-MENU-1st')
	cmWl9dOKHPIy41iaXuxrY = IAW0sh6So3NpqM.content
	x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+'بحث في الموقع',qpFY4hAwolV3,649,qpFY4hAwolV3,qpFY4hAwolV3,'_REMEMBERRESULTS_')
	x3WSXnKyPhjqfHG2UrtQs('link',xupTj02bvy3O8R+' ===== ===== ===== '+fF4lt9zWYxXLKZVyAco82PgMj,qpFY4hAwolV3,9999)
	x3WSXnKyPhjqfHG2UrtQs('folder',Q8Q0IDc6PLZajJAdTntKUmSGXz+'_SCRIPT_'+wwSFijdVJn1QgHW+'المميزة',ddBxj51bhNtaK23lDyGMVw,641,qpFY4hAwolV3,qpFY4hAwolV3,'featured')
	pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('"navslide-divider"(.*?)"navslide-divider"',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	mVYdjvor6i4wZ8 = pfRkcVlLmUxo561g0A8qSbO[0]
	items = ePhmG1jLD6.findall('href="(.*?)".*?>(.*?)<',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
	for MepIvHBYNArkUOdV37shtJ,title in items:
		if title in YEIA19ehBwpNfPVzK: continue
		x3WSXnKyPhjqfHG2UrtQs('folder',Q8Q0IDc6PLZajJAdTntKUmSGXz+'_SCRIPT_'+wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,644)
	return
def X2rO3lubqIdCGMLYWcxA6DK5(url):
	G8jrIS0cxzOJlk = []
	IAW0sh6So3NpqM = WWrExJZS3Bj4anOAkpv7(kUz8c7OqsxuPFIGfwg,'GET',url,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,'SHOFHA-SUBMENU-1st')
	cmWl9dOKHPIy41iaXuxrY = IAW0sh6So3NpqM.content
	NDnI9Qrpt5c8MU = ePhmG1jLD6.findall('"caret"(.*?)</ul>',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	if NDnI9Qrpt5c8MU:
		mVYdjvor6i4wZ8 = NDnI9Qrpt5c8MU[0]
		mVYdjvor6i4wZ8 = mVYdjvor6i4wZ8.replace('"presentation"','</ul>')
		pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('"dropdown-header">(.*?)</li>(.*?)</ul>',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
		if not pfRkcVlLmUxo561g0A8qSbO: pfRkcVlLmUxo561g0A8qSbO = [(qpFY4hAwolV3,mVYdjvor6i4wZ8)]
		x3WSXnKyPhjqfHG2UrtQs('link',xupTj02bvy3O8R+' فرز أو فلتر أو ترتيب '+fF4lt9zWYxXLKZVyAco82PgMj,qpFY4hAwolV3,9999)
		for YirSOX5nC0jPyvFTN48sHE1,mVYdjvor6i4wZ8 in pfRkcVlLmUxo561g0A8qSbO:
			G8jrIS0cxzOJlk = ePhmG1jLD6.findall('href="(.*?)".*?>(.*?)</a>',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
			if YirSOX5nC0jPyvFTN48sHE1: YirSOX5nC0jPyvFTN48sHE1 = YirSOX5nC0jPyvFTN48sHE1+': '
			for MepIvHBYNArkUOdV37shtJ,title in G8jrIS0cxzOJlk:
				title = YirSOX5nC0jPyvFTN48sHE1+title
				x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,641)
	T9TAc28ayKvFgjfd6SD = ePhmG1jLD6.findall('"pm-category-subcats"(.*?)</ul>',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	if T9TAc28ayKvFgjfd6SD:
		mVYdjvor6i4wZ8 = T9TAc28ayKvFgjfd6SD[0]
		eKEo1iY0x8kAcU76ChWaypzHIwlRMq = ePhmG1jLD6.findall('href="(.*?)">(.*?)</a>',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
		if len(eKEo1iY0x8kAcU76ChWaypzHIwlRMq)<30:
			if G8jrIS0cxzOJlk: x3WSXnKyPhjqfHG2UrtQs('link',xupTj02bvy3O8R+' ===== ===== ===== '+fF4lt9zWYxXLKZVyAco82PgMj,qpFY4hAwolV3,9999)
			for MepIvHBYNArkUOdV37shtJ,title in eKEo1iY0x8kAcU76ChWaypzHIwlRMq:
				x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,641)
	if not NDnI9Qrpt5c8MU and not T9TAc28ayKvFgjfd6SD: c8U1BdtxOZS5FH(url)
	return
def c8U1BdtxOZS5FH(url,AMbRf4XTpQNvio6J5GELducy0k=qpFY4hAwolV3):
	if AMbRf4XTpQNvio6J5GELducy0k=='ajax-search':
		url,search = url.split('?',1)
		data = 'queryString='+search
		headers = {'Content-Type':'application/x-www-form-urlencoded; charset=UTF-8'}
		IAW0sh6So3NpqM = WWrExJZS3Bj4anOAkpv7(kUz8c7OqsxuPFIGfwg,'POST',url,data,headers,qpFY4hAwolV3,qpFY4hAwolV3,'SHOFHA-TITLES-1st')
	else:
		IAW0sh6So3NpqM = WWrExJZS3Bj4anOAkpv7(kUz8c7OqsxuPFIGfwg,'GET',url,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,'SHOFHA-TITLES-2nd')
	cmWl9dOKHPIy41iaXuxrY = IAW0sh6So3NpqM.content
	mVYdjvor6i4wZ8,items = qpFY4hAwolV3,[]
	iipsGz2LKq = AWeJuo2LhZ5xiD8KNSqd9G0rtT74FE(url,'url')
	if AMbRf4XTpQNvio6J5GELducy0k=='ajax-search':
		mVYdjvor6i4wZ8 = cmWl9dOKHPIy41iaXuxrY
		eKEo1iY0x8kAcU76ChWaypzHIwlRMq = ePhmG1jLD6.findall('href="(.*?)">(.*?)</a>',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
		for MepIvHBYNArkUOdV37shtJ,title in eKEo1iY0x8kAcU76ChWaypzHIwlRMq: items.append((qpFY4hAwolV3,MepIvHBYNArkUOdV37shtJ,title))
	elif AMbRf4XTpQNvio6J5GELducy0k=='featured':
		pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('"mastcontent-wrap"(.*?)"content"',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
		if pfRkcVlLmUxo561g0A8qSbO:
			mVYdjvor6i4wZ8 = pfRkcVlLmUxo561g0A8qSbO[0]
			items = ePhmG1jLD6.findall('href="(.*?)".*?title="(.*?)".*?src="(.*?)"',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
			CFevtSjzbpn,EmejzBHJ28TqtDAZ74NUhF,rS1xqU30RcTwZsVDfuCyzKbLPoaX4 = zip(*items)
			items = zip(rS1xqU30RcTwZsVDfuCyzKbLPoaX4,CFevtSjzbpn,EmejzBHJ28TqtDAZ74NUhF)
	elif AMbRf4XTpQNvio6J5GELducy0k=='new_episodes':
		pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('"row pm-ul-browse-videos(.*?)</ul>',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
		if pfRkcVlLmUxo561g0A8qSbO: mVYdjvor6i4wZ8 = pfRkcVlLmUxo561g0A8qSbO[0]
	elif AMbRf4XTpQNvio6J5GELducy0k=='new_movies':
		pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('"row pm-ul-browse-videos(.*?)</ul>',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
		if len(pfRkcVlLmUxo561g0A8qSbO)>1: mVYdjvor6i4wZ8 = pfRkcVlLmUxo561g0A8qSbO[1]
	elif AMbRf4XTpQNvio6J5GELducy0k=='featured_series':
		pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('"home-series-list"(.*?)</div>[\t|\n]*</div>',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
		if pfRkcVlLmUxo561g0A8qSbO: mVYdjvor6i4wZ8 = pfRkcVlLmUxo561g0A8qSbO[0]
		eKEo1iY0x8kAcU76ChWaypzHIwlRMq = ePhmG1jLD6.findall('href="(.*?)">(.*?)</a>',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
		for MepIvHBYNArkUOdV37shtJ,title in eKEo1iY0x8kAcU76ChWaypzHIwlRMq: items.append((qpFY4hAwolV3,MepIvHBYNArkUOdV37shtJ,title))
	else:
		pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('(data-echo=".*?)</ul>',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
		if pfRkcVlLmUxo561g0A8qSbO: mVYdjvor6i4wZ8 = pfRkcVlLmUxo561g0A8qSbO[0]
	if mVYdjvor6i4wZ8 and not items: items = ePhmG1jLD6.findall('data-echo="(.*?)".*?href="(.*?)">.*?>(.*?)<',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
	if not items: return
	aaCNAJdtsguSRELh2I = []
	WGid3I2kFU = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم','مسرحية']
	for Sj7rMNYRuQPTtkBvpHKeDW3h,MepIvHBYNArkUOdV37shtJ,title in items:
		ZDTxRSMbW7PNz = ePhmG1jLD6.findall('(.*?) (الحلقة|حلقة).\d+',title,ePhmG1jLD6.DOTALL)
		if any(value in title for value in WGid3I2kFU):
			x3WSXnKyPhjqfHG2UrtQs('video',wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,642,Sj7rMNYRuQPTtkBvpHKeDW3h)
		elif AMbRf4XTpQNvio6J5GELducy0k=='new_episodes':
			x3WSXnKyPhjqfHG2UrtQs('video',wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,642,Sj7rMNYRuQPTtkBvpHKeDW3h)
		elif ZDTxRSMbW7PNz:
			title = '_MOD_' + ZDTxRSMbW7PNz[0][0]
			if title not in aaCNAJdtsguSRELh2I:
				x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,645,Sj7rMNYRuQPTtkBvpHKeDW3h)
				aaCNAJdtsguSRELh2I.append(title)
		else: x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,645,Sj7rMNYRuQPTtkBvpHKeDW3h)
	if 1:
		pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('"pagination(.*?)</ul>',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
		if pfRkcVlLmUxo561g0A8qSbO:
			mVYdjvor6i4wZ8 = pfRkcVlLmUxo561g0A8qSbO[0]
			items = ePhmG1jLD6.findall('href="(.*?)".*?>(.*?)</a>',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
			for MepIvHBYNArkUOdV37shtJ,title in items:
				if MepIvHBYNArkUOdV37shtJ=='#': continue
				if 'http' not in MepIvHBYNArkUOdV37shtJ: MepIvHBYNArkUOdV37shtJ = iipsGz2LKq+ShynO8pN9idCE3+MepIvHBYNArkUOdV37shtJ.strip(ShynO8pN9idCE3)
				title = j8PDV0pthfSTidZbsQxNIOmCYKWzH(title)
				x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+'صفحة '+title,MepIvHBYNArkUOdV37shtJ,641)
	return
def v1gmfxDcRrWKQ(url):
	IAW0sh6So3NpqM = WWrExJZS3Bj4anOAkpv7(kUz8c7OqsxuPFIGfwg,'GET',url,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,'SHOFHA-EPISODES-1st')
	cmWl9dOKHPIy41iaXuxrY = IAW0sh6So3NpqM.content
	BvbuigUeoJLnTaN2qWxQ415AtYMK9I = ePhmG1jLD6.findall('"image" content="(.*?)"',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	Sj7rMNYRuQPTtkBvpHKeDW3h = BvbuigUeoJLnTaN2qWxQ415AtYMK9I[0] if BvbuigUeoJLnTaN2qWxQ415AtYMK9I else qpFY4hAwolV3
	pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('"AiredEPS"(.*?)</div>',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	if pfRkcVlLmUxo561g0A8qSbO:
		mVYdjvor6i4wZ8 = pfRkcVlLmUxo561g0A8qSbO[0]
		items = ePhmG1jLD6.findall('href="(.*?)".*?<span>(.*?)</em>',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
		for MepIvHBYNArkUOdV37shtJ,title in items:
			title = title.replace('</span><em>',mIsDke0oK5x1zSiOWbF9thGcA)
			if NJwViHDTMdmO0xnALqQ9voPalC3Ip: MepIvHBYNArkUOdV37shtJ = MepIvHBYNArkUOdV37shtJ.decode(nV3Tip6XsH1rJw79DPOU)
			x3WSXnKyPhjqfHG2UrtQs('video',wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,642,Sj7rMNYRuQPTtkBvpHKeDW3h)
	return
def mzcAeyplZV(url):
	U7V0BQZPxXqMbyJnRw6f,HHXPdv1aOo8WAZYIn0NFQ,tiYp9ZdbFTQMcB4vWkHw6LXIAKrN5m = [],[],[]
	WSQlG8mDhqsNe = url.replace('/watch.php','/play.php')
	IAW0sh6So3NpqM = WWrExJZS3Bj4anOAkpv7(kUz8c7OqsxuPFIGfwg,'GET',WSQlG8mDhqsNe,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,'SHOFHA-PLAY-1st')
	cmWl9dOKHPIy41iaXuxrY = IAW0sh6So3NpqM.content
	if 'embedded-video' in cmWl9dOKHPIy41iaXuxrY:
		pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('"embed_server"(.*?)</div>',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
		if pfRkcVlLmUxo561g0A8qSbO:
			mVYdjvor6i4wZ8 = pfRkcVlLmUxo561g0A8qSbO[0]
			CFevtSjzbpn = ePhmG1jLD6.findall('src="(.*?)"',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
			if CFevtSjzbpn:
				MepIvHBYNArkUOdV37shtJ = CFevtSjzbpn[0]
				if MepIvHBYNArkUOdV37shtJ not in U7V0BQZPxXqMbyJnRw6f:
					HHXPdv1aOo8WAZYIn0NFQ.append('?named=__embed')
					U7V0BQZPxXqMbyJnRw6f.append(MepIvHBYNArkUOdV37shtJ)
	pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('var servers =(.*?);',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	if pfRkcVlLmUxo561g0A8qSbO:
		mVYdjvor6i4wZ8 = pfRkcVlLmUxo561g0A8qSbO[0]
		items = A3AFYmgZLXn4MBab.loads(mVYdjvor6i4wZ8)
		for lkd2oKvZF03qmgMbIfQ6cD in items:
			MepIvHBYNArkUOdV37shtJ = ePhmG1jLD6.findall('src="(.*?)"',lkd2oKvZF03qmgMbIfQ6cD,ePhmG1jLD6.DOTALL)
			if MepIvHBYNArkUOdV37shtJ:
				MepIvHBYNArkUOdV37shtJ = MepIvHBYNArkUOdV37shtJ[0]
				if MepIvHBYNArkUOdV37shtJ not in U7V0BQZPxXqMbyJnRw6f:
					HHXPdv1aOo8WAZYIn0NFQ.append('?named=__watch')
					U7V0BQZPxXqMbyJnRw6f.append(MepIvHBYNArkUOdV37shtJ)
	WSQlG8mDhqsNe = url.replace('/watch.php','/download.php')
	IAW0sh6So3NpqM = WWrExJZS3Bj4anOAkpv7(kUz8c7OqsxuPFIGfwg,'GET',WSQlG8mDhqsNe,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,'SHOFHA-PLAY-2nd')
	cmWl9dOKHPIy41iaXuxrY = IAW0sh6So3NpqM.content
	pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('"player"(.*?)"DownloadServer"',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	if pfRkcVlLmUxo561g0A8qSbO:
		mVYdjvor6i4wZ8 = pfRkcVlLmUxo561g0A8qSbO[0]
		CFevtSjzbpn = ePhmG1jLD6.findall('href="(.*?)".*?</div>(.*?)</a>',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
		iipsGz2LKq = AWeJuo2LhZ5xiD8KNSqd9G0rtT74FE(url,'url')
		for MepIvHBYNArkUOdV37shtJ,title in CFevtSjzbpn:
			title = title.replace('<div class="desc">','').replace('</div>','')
			title = title.strip()
			if 'http' not in MepIvHBYNArkUOdV37shtJ: MepIvHBYNArkUOdV37shtJ = iipsGz2LKq+MepIvHBYNArkUOdV37shtJ
			if MepIvHBYNArkUOdV37shtJ not in U7V0BQZPxXqMbyJnRw6f:
				HHXPdv1aOo8WAZYIn0NFQ.append('?named='+title+'__download')
				U7V0BQZPxXqMbyJnRw6f.append(MepIvHBYNArkUOdV37shtJ)
	G1EWNzkMOm35C = zip(U7V0BQZPxXqMbyJnRw6f,HHXPdv1aOo8WAZYIn0NFQ)
	for MepIvHBYNArkUOdV37shtJ,name in G1EWNzkMOm35C: tiYp9ZdbFTQMcB4vWkHw6LXIAKrN5m.append(MepIvHBYNArkUOdV37shtJ+name)
	import inVXFK46ET
	inVXFK46ET.q4qTJvuoQUzM3mZAtegy7IXdnb5wH(tiYp9ZdbFTQMcB4vWkHw6LXIAKrN5m,Q8Q0IDc6PLZajJAdTntKUmSGXz,'video',url)
	return
def PPqUACSE3VcGLTvw05jHy9JrFNW(search):
	search,LBylNhMdH6OV1qGk0tWiXFg3,showDialogs = LLm3sBXHPcnTDxdE5gt6hz0Wkp(search)
	if search==qpFY4hAwolV3: search = jXgARlWMLVFUBnvmZwI2o5()
	if search==qpFY4hAwolV3: return
	search = search.replace(mIsDke0oK5x1zSiOWbF9thGcA,'+')
	url = ddBxj51bhNtaK23lDyGMVw+'/search.php?keywords='+search
	c8U1BdtxOZS5FH(url,'search')
	return