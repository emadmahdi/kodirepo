# -*- coding: utf-8 -*-
from pSfaryIjBo import *
Q8Q0IDc6PLZajJAdTntKUmSGXz = 'EGYBESTVIP'
wwSFijdVJn1QgHW = '_EGV_'
ddBxj51bhNtaK23lDyGMVw = i4bFG3rKE6.SITESURLS[Q8Q0IDc6PLZajJAdTntKUmSGXz][0]
def vTNE2Ck1sGnugJYW8y39aLcSH64U(mode,url,i02wfPp5EM,text):
	if   mode==220: MOTjA5H9XFs = nRVAZc4Dp8PSrGU3xBk()
	elif mode==221: MOTjA5H9XFs = c8U1BdtxOZS5FH(url,i02wfPp5EM)
	elif mode==222: MOTjA5H9XFs = X2rO3lubqIdCGMLYWcxA6DK5(url)
	elif mode==223: MOTjA5H9XFs = mzcAeyplZV(url)
	elif mode==224: MOTjA5H9XFs = R9pWUgVhBGLd2CQb0z(url)
	elif mode==229: MOTjA5H9XFs = PPqUACSE3VcGLTvw05jHy9JrFNW(text)
	else: MOTjA5H9XFs = False
	return MOTjA5H9XFs
def nRVAZc4Dp8PSrGU3xBk():
	x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+'بحث في الموقع',qpFY4hAwolV3,229,qpFY4hAwolV3,qpFY4hAwolV3,'_REMEMBERRESULTS_')
	x3WSXnKyPhjqfHG2UrtQs('link',xupTj02bvy3O8R+' ===== ===== ===== '+fF4lt9zWYxXLKZVyAco82PgMj,qpFY4hAwolV3,9999)
	IAW0sh6So3NpqM = WWrExJZS3Bj4anOAkpv7(KOyPvpEztYLaZRdMQJWxfTNFHbkg,'GET',ddBxj51bhNtaK23lDyGMVw,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,'EGYBEST-MENU-1st')
	cmWl9dOKHPIy41iaXuxrY = IAW0sh6So3NpqM.content
	pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('class="i i-home"(.*?)</div>',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	if pfRkcVlLmUxo561g0A8qSbO:
		mVYdjvor6i4wZ8 = pfRkcVlLmUxo561g0A8qSbO[0]
		items = ePhmG1jLD6.findall('href="(.*?)"(.*?)</a>',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
		for MepIvHBYNArkUOdV37shtJ,title in items:
			if '</i>' in title: title = title.split('</i>')[1]
			x3WSXnKyPhjqfHG2UrtQs('folder',Q8Q0IDc6PLZajJAdTntKUmSGXz+'_SCRIPT_'+wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,222)
		x3WSXnKyPhjqfHG2UrtQs('link',xupTj02bvy3O8R+' ===== ===== ===== '+fF4lt9zWYxXLKZVyAco82PgMj,qpFY4hAwolV3,9999)
	pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('class="ba(.*?)<script',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	if pfRkcVlLmUxo561g0A8qSbO:
		mVYdjvor6i4wZ8 = pfRkcVlLmUxo561g0A8qSbO[0]
		items = ePhmG1jLD6.findall('pda bdb"><strong>(.*?)<.*?href="(.*?)"',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
		for title,MepIvHBYNArkUOdV37shtJ in items:
			x3WSXnKyPhjqfHG2UrtQs('folder',Q8Q0IDc6PLZajJAdTntKUmSGXz+'_SCRIPT_'+wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,221)
		x3WSXnKyPhjqfHG2UrtQs('link',xupTj02bvy3O8R+' ===== ===== ===== '+fF4lt9zWYxXLKZVyAco82PgMj,qpFY4hAwolV3,9999)
		items = ePhmG1jLD6.findall('href="(.*?)".*?>(.*?)<',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
		for MepIvHBYNArkUOdV37shtJ,title in items:
			if 'html' not in MepIvHBYNArkUOdV37shtJ: continue
			if not MepIvHBYNArkUOdV37shtJ.endswith(ShynO8pN9idCE3): x3WSXnKyPhjqfHG2UrtQs('folder',Q8Q0IDc6PLZajJAdTntKUmSGXz+'_SCRIPT_'+wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,221)
	return cmWl9dOKHPIy41iaXuxrY
def X2rO3lubqIdCGMLYWcxA6DK5(url):
	IAW0sh6So3NpqM = WWrExJZS3Bj4anOAkpv7(KOyPvpEztYLaZRdMQJWxfTNFHbkg,'GET',url,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,'EGYBESTVIP-SUBMENU-1st')
	cmWl9dOKHPIy41iaXuxrY = IAW0sh6So3NpqM.content
	pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('class="rs_scroll"(.*?)</div>',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	mVYdjvor6i4wZ8 = pfRkcVlLmUxo561g0A8qSbO[0]
	items = ePhmG1jLD6.findall('href="(.*?)".*?</i>(.*?)</a>',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
	for MepIvHBYNArkUOdV37shtJ,title in items:
		x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,224)
	return
def R9pWUgVhBGLd2CQb0z(url):
	x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+'الجميع',url,221)
	cmWl9dOKHPIy41iaXuxrY = GMqfDK9V4F8eTPE1pNOAaiYUbhr(KOyPvpEztYLaZRdMQJWxfTNFHbkg,url,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,'EGYBESTVIP-FILTERS_MENU-1st')
	pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('class="sub_nav(.*?)id="movies',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	if pfRkcVlLmUxo561g0A8qSbO:
		mVYdjvor6i4wZ8 = pfRkcVlLmUxo561g0A8qSbO[0]
		items = ePhmG1jLD6.findall('href="(.*?)".+?>(.*?)<',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
		for MepIvHBYNArkUOdV37shtJ,title in items:
			if MepIvHBYNArkUOdV37shtJ=='#': name = title
			else:
				title = title + '  :  ' + 'فلتر ' + name
				x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,221)
	else: c8U1BdtxOZS5FH(url)
	return
def c8U1BdtxOZS5FH(url,i02wfPp5EM='1'):
	if i02wfPp5EM==qpFY4hAwolV3: i02wfPp5EM = '1'
	if '/search' in url or '?' in url: WSQlG8mDhqsNe = url + '&'
	else: WSQlG8mDhqsNe = url + '?'
	WSQlG8mDhqsNe = WSQlG8mDhqsNe + 'page=' + i02wfPp5EM
	cmWl9dOKHPIy41iaXuxrY = GMqfDK9V4F8eTPE1pNOAaiYUbhr(kUz8c7OqsxuPFIGfwg,WSQlG8mDhqsNe,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,'EGYBESTVIP-TITLES-1st')
	if '/season' in url:
		pfRkcVlLmUxo561g0A8qSbO=ePhmG1jLD6.findall('class="pda"(.*?)div',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
		mVYdjvor6i4wZ8 = pfRkcVlLmUxo561g0A8qSbO[-1]
	elif '/series/' in url:
		pfRkcVlLmUxo561g0A8qSbO=ePhmG1jLD6.findall('class="owl-carousel owl-carousel(.*?)div',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
		mVYdjvor6i4wZ8 = pfRkcVlLmUxo561g0A8qSbO[0]
	else:
		pfRkcVlLmUxo561g0A8qSbO=ePhmG1jLD6.findall('id="movies(.*?)</div>',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
		mVYdjvor6i4wZ8 = pfRkcVlLmUxo561g0A8qSbO[-1]
	items = ePhmG1jLD6.findall('<a href="(.*?)".*?src="(.*?)".*?title">(.*?)<',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
	for MepIvHBYNArkUOdV37shtJ,Sj7rMNYRuQPTtkBvpHKeDW3h,title in items:
		title = j8PDV0pthfSTidZbsQxNIOmCYKWzH(title)
		if '/movie/' in MepIvHBYNArkUOdV37shtJ or '/episode' in MepIvHBYNArkUOdV37shtJ:
			x3WSXnKyPhjqfHG2UrtQs('video',wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ.rstrip(ShynO8pN9idCE3),223,Sj7rMNYRuQPTtkBvpHKeDW3h)
		else:
			x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,221,Sj7rMNYRuQPTtkBvpHKeDW3h)
	if len(items)>=16:
		fQnd7lvxm3yAsqNeuojta1r8h = ['/movies','/tv','/search','/trending']
		i02wfPp5EM = int(i02wfPp5EM)
		if any(value in url for value in fQnd7lvxm3yAsqNeuojta1r8h):
			for WbXGhZL104ictIjHlaAkD6mNT5FUw in range(0,1000,100):
				if int(i02wfPp5EM/100)*100==WbXGhZL104ictIjHlaAkD6mNT5FUw:
					for a2jQ83ZCfcM5 in range(WbXGhZL104ictIjHlaAkD6mNT5FUw,WbXGhZL104ictIjHlaAkD6mNT5FUw+100,10):
						if int(i02wfPp5EM/10)*10==a2jQ83ZCfcM5:
							for eoNEQ9AB71YHk8bGaIPy2 in range(a2jQ83ZCfcM5,a2jQ83ZCfcM5+10,1):
								if not i02wfPp5EM==eoNEQ9AB71YHk8bGaIPy2 and eoNEQ9AB71YHk8bGaIPy2!=0:
									x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+'صفحة '+str(eoNEQ9AB71YHk8bGaIPy2),url,221,qpFY4hAwolV3,str(eoNEQ9AB71YHk8bGaIPy2))
						elif a2jQ83ZCfcM5!=0: x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+'صفحة '+str(a2jQ83ZCfcM5),url,221,qpFY4hAwolV3,str(a2jQ83ZCfcM5))
						else: x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+'صفحة '+str(1),url,221,qpFY4hAwolV3,str(1))
				elif WbXGhZL104ictIjHlaAkD6mNT5FUw!=0: x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+'صفحة '+str(WbXGhZL104ictIjHlaAkD6mNT5FUw),url,221,qpFY4hAwolV3,str(WbXGhZL104ictIjHlaAkD6mNT5FUw))
				else: x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+'صفحة '+str(1),url,221)
	return
def mzcAeyplZV(url):
	QQLqrElamjfneR8GoP9IpuZ,U7V0BQZPxXqMbyJnRw6f = [],[]
	cmWl9dOKHPIy41iaXuxrY = GMqfDK9V4F8eTPE1pNOAaiYUbhr(KOyPvpEztYLaZRdMQJWxfTNFHbkg,url,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,'EGYBESTVIP-PLAY-1st')
	GIE2XSj0vVJPZA6dgmOs9TMDy8UkQW = ePhmG1jLD6.findall('<td>التصنيف</td>.*?">(.*?)<',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	if GIE2XSj0vVJPZA6dgmOs9TMDy8UkQW and u0E18eO3HnCzr(Q8Q0IDc6PLZajJAdTntKUmSGXz,url,GIE2XSj0vVJPZA6dgmOs9TMDy8UkQW): return
	nePzHi3G1vc7D,eD0qAk8mas = qpFY4hAwolV3,qpFY4hAwolV3
	iTjJgaPsnYC3IGfc4k7B,YAbsxQmlky9fJOoTDz087KhZCN = cmWl9dOKHPIy41iaXuxrY,cmWl9dOKHPIy41iaXuxrY
	RXh8mEf1stLcT4WBo73w0 = ePhmG1jLD6.findall('show_dl api" href="(.*?)"',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	if RXh8mEf1stLcT4WBo73w0:
		for MepIvHBYNArkUOdV37shtJ in RXh8mEf1stLcT4WBo73w0:
			if '/watch/' in MepIvHBYNArkUOdV37shtJ: nePzHi3G1vc7D = MepIvHBYNArkUOdV37shtJ
			elif '/download/' in MepIvHBYNArkUOdV37shtJ: eD0qAk8mas = MepIvHBYNArkUOdV37shtJ
		if nePzHi3G1vc7D!=qpFY4hAwolV3: iTjJgaPsnYC3IGfc4k7B = GMqfDK9V4F8eTPE1pNOAaiYUbhr(KOyPvpEztYLaZRdMQJWxfTNFHbkg,nePzHi3G1vc7D,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,'EGYBESTVIP-PLAY-2nd')
		if eD0qAk8mas!=qpFY4hAwolV3: YAbsxQmlky9fJOoTDz087KhZCN = GMqfDK9V4F8eTPE1pNOAaiYUbhr(KOyPvpEztYLaZRdMQJWxfTNFHbkg,eD0qAk8mas,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,'EGYBESTVIP-PLAY-3rd')
	UMe0jmlkzYsoV1tqhX2Oy74ZrDB = ePhmG1jLD6.findall('id="video".*?data-src="(.*?)"',iTjJgaPsnYC3IGfc4k7B,ePhmG1jLD6.DOTALL)
	if UMe0jmlkzYsoV1tqhX2Oy74ZrDB:
		WSQlG8mDhqsNe = UMe0jmlkzYsoV1tqhX2Oy74ZrDB[0]
		if WSQlG8mDhqsNe!=qpFY4hAwolV3 and 'uploaded.egybest.download' in WSQlG8mDhqsNe and '/?id=_' not in WSQlG8mDhqsNe:
			CC8IKXmYeo = GMqfDK9V4F8eTPE1pNOAaiYUbhr(KOyPvpEztYLaZRdMQJWxfTNFHbkg,WSQlG8mDhqsNe,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,'EGYBESTVIP-PLAY-4th')
			YBv9bNEWen17Dr4KzuFltdVOpx2Has = ePhmG1jLD6.findall('source src="(.*?)" title="(.*?)"',CC8IKXmYeo,ePhmG1jLD6.DOTALL)
			if YBv9bNEWen17Dr4KzuFltdVOpx2Has:
				for MepIvHBYNArkUOdV37shtJ,Mrp5ZdGHFv9Xi6mkxfac3JDB in YBv9bNEWen17Dr4KzuFltdVOpx2Has:
					U7V0BQZPxXqMbyJnRw6f.append(MepIvHBYNArkUOdV37shtJ+'?named=ed.egybest.do__watch__mp4__'+Mrp5ZdGHFv9Xi6mkxfac3JDB)
			else:
				XPNkVcWFUr = WSQlG8mDhqsNe.split(ShynO8pN9idCE3)[2]
				U7V0BQZPxXqMbyJnRw6f.append(WSQlG8mDhqsNe+'?named='+XPNkVcWFUr+'__watch')
		elif WSQlG8mDhqsNe!=qpFY4hAwolV3:
			XPNkVcWFUr = WSQlG8mDhqsNe.split(ShynO8pN9idCE3)[2]
			U7V0BQZPxXqMbyJnRw6f.append(WSQlG8mDhqsNe+'?named='+XPNkVcWFUr+'__watch')
	j6ThDPHG8VkCeYt9gKJmoLwR3Sr = ePhmG1jLD6.findall('<table class="dls_table(.*?)</table>',YAbsxQmlky9fJOoTDz087KhZCN,ePhmG1jLD6.DOTALL)
	if j6ThDPHG8VkCeYt9gKJmoLwR3Sr:
		j6ThDPHG8VkCeYt9gKJmoLwR3Sr = j6ThDPHG8VkCeYt9gKJmoLwR3Sr[0]
		oDVyQFAbl0dBa = ePhmG1jLD6.findall('<td>.*?<td>(.*?)<.*?href="(.*?)"',j6ThDPHG8VkCeYt9gKJmoLwR3Sr,ePhmG1jLD6.DOTALL)
		if oDVyQFAbl0dBa:
			for Mrp5ZdGHFv9Xi6mkxfac3JDB,MepIvHBYNArkUOdV37shtJ in oDVyQFAbl0dBa:
				if 'myegyvip' not in MepIvHBYNArkUOdV37shtJ: continue
				if MepIvHBYNArkUOdV37shtJ.count(ShynO8pN9idCE3)>=2:
					XPNkVcWFUr = MepIvHBYNArkUOdV37shtJ.split(ShynO8pN9idCE3)[2]
					U7V0BQZPxXqMbyJnRw6f.append(MepIvHBYNArkUOdV37shtJ+'?named='+XPNkVcWFUr+'__download__mp4__'+Mrp5ZdGHFv9Xi6mkxfac3JDB)
	SoixgtW3VRZj = []
	for MepIvHBYNArkUOdV37shtJ in U7V0BQZPxXqMbyJnRw6f:
		SoixgtW3VRZj.append(MepIvHBYNArkUOdV37shtJ)
	import inVXFK46ET
	inVXFK46ET.q4qTJvuoQUzM3mZAtegy7IXdnb5wH(SoixgtW3VRZj,Q8Q0IDc6PLZajJAdTntKUmSGXz,'video',url)
	return
def PPqUACSE3VcGLTvw05jHy9JrFNW(search):
	search,LBylNhMdH6OV1qGk0tWiXFg3,showDialogs = LLm3sBXHPcnTDxdE5gt6hz0Wkp(search)
	if search==qpFY4hAwolV3: search = jXgARlWMLVFUBnvmZwI2o5()
	if search==qpFY4hAwolV3: return
	K7m9Otk3h1VYIN8rcP6jp2 = search.replace(mIsDke0oK5x1zSiOWbF9thGcA,'+')
	cmWl9dOKHPIy41iaXuxrY = GMqfDK9V4F8eTPE1pNOAaiYUbhr(rGY36xBwT1bLZAngSfcWEIeXdQVNij,ddBxj51bhNtaK23lDyGMVw,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,'EGYBESTVIP-SEARCH-1st')
	hkpnFx0WLU = ePhmG1jLD6.findall('name="_token" value="(.*?)"',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	if hkpnFx0WLU:
		url = ddBxj51bhNtaK23lDyGMVw+'/search?_token='+hkpnFx0WLU[0]+'&q='+K7m9Otk3h1VYIN8rcP6jp2
		c8U1BdtxOZS5FH(url)
	return