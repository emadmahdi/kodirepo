# -*- coding: utf-8 -*-
from pSfaryIjBo import *
Q8Q0IDc6PLZajJAdTntKUmSGXz = 'CIMACLUP'
wwSFijdVJn1QgHW = '_CMC_'
ddBxj51bhNtaK23lDyGMVw = i4bFG3rKE6.SITESURLS[Q8Q0IDc6PLZajJAdTntKUmSGXz][0]
YEIA19ehBwpNfPVzK = ['موقع نتفليكس']
def vTNE2Ck1sGnugJYW8y39aLcSH64U(mode,url,text):
	if   mode==490: MOTjA5H9XFs = nRVAZc4Dp8PSrGU3xBk()
	elif mode==491: MOTjA5H9XFs = c8U1BdtxOZS5FH(url,text)
	elif mode==492: MOTjA5H9XFs = mzcAeyplZV(url)
	elif mode==493: MOTjA5H9XFs = v1gmfxDcRrWKQ(url)
	elif mode==494: MOTjA5H9XFs = X2rO3lubqIdCGMLYWcxA6DK5(url)
	elif mode==499: MOTjA5H9XFs = PPqUACSE3VcGLTvw05jHy9JrFNW(text,url)
	else: MOTjA5H9XFs = False
	return MOTjA5H9XFs
def nRVAZc4Dp8PSrGU3xBk():
	IAW0sh6So3NpqM = WWrExJZS3Bj4anOAkpv7(kUz8c7OqsxuPFIGfwg,'GET',ddBxj51bhNtaK23lDyGMVw,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,'CIMACLUP-MENU-1st')
	cmWl9dOKHPIy41iaXuxrY = IAW0sh6So3NpqM.content
	iipsGz2LKq = ePhmG1jLD6.findall('href="(.*?)"',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	iipsGz2LKq = iipsGz2LKq[0].strip(ShynO8pN9idCE3)
	iipsGz2LKq = AWeJuo2LhZ5xiD8KNSqd9G0rtT74FE(iipsGz2LKq,'url')
	T9TAc28ayKvFgjfd6SD = ePhmG1jLD6.findall('"filter AjaxifyFilter"(.*?)</div>',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	if T9TAc28ayKvFgjfd6SD:
		mVYdjvor6i4wZ8 = T9TAc28ayKvFgjfd6SD[0]
		items = ePhmG1jLD6.findall('data-filter="(.*?)".*?>(.*?)</a>',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
		for MepIvHBYNArkUOdV37shtJ,title in items:
			if title in YEIA19ehBwpNfPVzK: continue
			MepIvHBYNArkUOdV37shtJ = iipsGz2LKq+'/wp-content/themes/old/filter/'+MepIvHBYNArkUOdV37shtJ+'.php'
			x3WSXnKyPhjqfHG2UrtQs('folder',Q8Q0IDc6PLZajJAdTntKUmSGXz+'_SCRIPT_'+wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,491)
	x3WSXnKyPhjqfHG2UrtQs('link',xupTj02bvy3O8R+' ===== ===== ===== '+fF4lt9zWYxXLKZVyAco82PgMj,qpFY4hAwolV3,9999)
	x3WSXnKyPhjqfHG2UrtQs('folder',Q8Q0IDc6PLZajJAdTntKUmSGXz+'_SCRIPT_'+wwSFijdVJn1QgHW+'أفلام',iipsGz2LKq+'/category/افلام-movies-filme/foreign-hd-افلام-اجنبى-2',494,qpFY4hAwolV3,qpFY4hAwolV3,'_REMEMBERRESULTS_')
	x3WSXnKyPhjqfHG2UrtQs('folder',Q8Q0IDc6PLZajJAdTntKUmSGXz+'_SCRIPT_'+wwSFijdVJn1QgHW+'مسلسلات',iipsGz2LKq+'/category/مسلسلات/مسلسلات-اجنبى',494,qpFY4hAwolV3,qpFY4hAwolV3,'_REMEMBERRESULTS_')
	x3WSXnKyPhjqfHG2UrtQs('link',xupTj02bvy3O8R+' ===== ===== ===== '+fF4lt9zWYxXLKZVyAco82PgMj,qpFY4hAwolV3,9999)
	pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('class="navigation-menu"(.*?)</ul>',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	mVYdjvor6i4wZ8 = pfRkcVlLmUxo561g0A8qSbO[0]
	items = ePhmG1jLD6.findall('href="(.*?)".*?>(.*?)</a>',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
	for MepIvHBYNArkUOdV37shtJ,title in items:
		if MepIvHBYNArkUOdV37shtJ==ShynO8pN9idCE3: continue
		if 'http' not in MepIvHBYNArkUOdV37shtJ: MepIvHBYNArkUOdV37shtJ = iipsGz2LKq+MepIvHBYNArkUOdV37shtJ
		if title in YEIA19ehBwpNfPVzK: continue
		x3WSXnKyPhjqfHG2UrtQs('folder',Q8Q0IDc6PLZajJAdTntKUmSGXz+'_SCRIPT_'+wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,491)
	return cmWl9dOKHPIy41iaXuxrY
def X2rO3lubqIdCGMLYWcxA6DK5(url):
	IAW0sh6So3NpqM = WWrExJZS3Bj4anOAkpv7(kUz8c7OqsxuPFIGfwg,'GET',url,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,'CIMACLUP-SUBMENU-1st')
	cmWl9dOKHPIy41iaXuxrY = IAW0sh6So3NpqM.content
	NDnI9Qrpt5c8MU = ePhmG1jLD6.findall('"filter"(.*?)</div>',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	if NDnI9Qrpt5c8MU:
		mVYdjvor6i4wZ8 = NDnI9Qrpt5c8MU[0]
		items = ePhmG1jLD6.findall('href="(.*?)".*?>(.*?)</a>',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
		for MepIvHBYNArkUOdV37shtJ,title in items:
			if title in YEIA19ehBwpNfPVzK: continue
			x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,491)
	return
def c8U1BdtxOZS5FH(url,emb0iauxpw6ZAKNyoLHfc1qRnB9UME=qpFY4hAwolV3):
	items = []
	IAW0sh6So3NpqM = WWrExJZS3Bj4anOAkpv7(kUz8c7OqsxuPFIGfwg,'GET',url,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,'CIMACLUP-TITLES-1st')
	cmWl9dOKHPIy41iaXuxrY = IAW0sh6So3NpqM.content
	mVYdjvor6i4wZ8 = qpFY4hAwolV3
	if '.php' in url: mVYdjvor6i4wZ8 = cmWl9dOKHPIy41iaXuxrY
	elif '?s=' in url:
		pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('"blocks(.*?)"manifest"',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
		if pfRkcVlLmUxo561g0A8qSbO:
			mVYdjvor6i4wZ8 = pfRkcVlLmUxo561g0A8qSbO[0]
			items = ePhmG1jLD6.findall('href="(.*?)".*?src="(.*?)".*?alt="(.*?)"',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
	else:
		pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('"Blocks(.*?)"manifest"',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
		if pfRkcVlLmUxo561g0A8qSbO:
			mVYdjvor6i4wZ8 = pfRkcVlLmUxo561g0A8qSbO[0]
	if not mVYdjvor6i4wZ8: return
	aaCNAJdtsguSRELh2I = []
	WGid3I2kFU = ['مشاهدة','فيلم','اغنية','أغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم','مسرحية']
	for MepIvHBYNArkUOdV37shtJ,Sj7rMNYRuQPTtkBvpHKeDW3h,title in items:
		title = j8PDV0pthfSTidZbsQxNIOmCYKWzH(title)
		ZDTxRSMbW7PNz = ePhmG1jLD6.findall('(.*?) حلقة \d+',title,ePhmG1jLD6.DOTALL)
		if not ZDTxRSMbW7PNz: ZDTxRSMbW7PNz = ePhmG1jLD6.findall('(.*?) الحلقة \d+',title,ePhmG1jLD6.DOTALL)
		if not ZDTxRSMbW7PNz or any(value in title for value in WGid3I2kFU):
			x3WSXnKyPhjqfHG2UrtQs('video',wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,492,Sj7rMNYRuQPTtkBvpHKeDW3h)
		elif ZDTxRSMbW7PNz and 'حلقة' in title:
			title = '_MOD_' + ZDTxRSMbW7PNz[0]
			if title not in aaCNAJdtsguSRELh2I:
				x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,493,Sj7rMNYRuQPTtkBvpHKeDW3h)
				aaCNAJdtsguSRELh2I.append(title)
		else: x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,493,Sj7rMNYRuQPTtkBvpHKeDW3h)
	pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('"pagination"(.*?)</ul>',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	if pfRkcVlLmUxo561g0A8qSbO:
		mVYdjvor6i4wZ8 = pfRkcVlLmUxo561g0A8qSbO[0]
		items = ePhmG1jLD6.findall('<li><a href="(.*?)".*?>(.*?)</a>',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
		for MepIvHBYNArkUOdV37shtJ,title in items:
			title = j8PDV0pthfSTidZbsQxNIOmCYKWzH(title)
			title = title.replace('الصفحة ',qpFY4hAwolV3)
			if title!=qpFY4hAwolV3: x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+'صفحة '+title,MepIvHBYNArkUOdV37shtJ,491)
	return
def v1gmfxDcRrWKQ(url):
	IAW0sh6So3NpqM = WWrExJZS3Bj4anOAkpv7(kUz8c7OqsxuPFIGfwg,'GET',url,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,'CIMACLUP-EPISODES-1st')
	cmWl9dOKHPIy41iaXuxrY = IAW0sh6So3NpqM.content
	WSQlG8mDhqsNe = ePhmG1jLD6.findall('"ButtonsBarCo".*?href="(.*?)"',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	if WSQlG8mDhqsNe:
		WSQlG8mDhqsNe = WSQlG8mDhqsNe[0]
		IAW0sh6So3NpqM = WWrExJZS3Bj4anOAkpv7(kUz8c7OqsxuPFIGfwg,'GET',WSQlG8mDhqsNe,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,'CIMACLUP-EPISODES-2nd')
		cmWl9dOKHPIy41iaXuxrY = IAW0sh6So3NpqM.content
	Sj7rMNYRuQPTtkBvpHKeDW3h = ePhmG1jLD6.findall('"img-responsive" src="(.*?)"',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	if Sj7rMNYRuQPTtkBvpHKeDW3h: Sj7rMNYRuQPTtkBvpHKeDW3h = Sj7rMNYRuQPTtkBvpHKeDW3h[0]
	else: Sj7rMNYRuQPTtkBvpHKeDW3h = Rqvw05BorCgcye7VE32Sf.getInfoLabel('ListItem.Thumb')
	NDnI9Qrpt5c8MU = ePhmG1jLD6.findall('"filter"(.*?)</div>',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	T9TAc28ayKvFgjfd6SD = ePhmG1jLD6.findall('"Blocks(.*?)class="pagination"',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	if NDnI9Qrpt5c8MU and '/series/' not in url:
		mVYdjvor6i4wZ8 = NDnI9Qrpt5c8MU[0]
		items = ePhmG1jLD6.findall('href="(.*?)".*?>(.*?)</a>',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
		for MepIvHBYNArkUOdV37shtJ,title in items:
			x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,493,Sj7rMNYRuQPTtkBvpHKeDW3h)
	elif T9TAc28ayKvFgjfd6SD:
		mVYdjvor6i4wZ8 = T9TAc28ayKvFgjfd6SD[0]
		items = ePhmG1jLD6.findall('href="(.*?)".*?image\:url\((.*?)\).*?"boxtitle">(.*?)</div>',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
		if items:
			for MepIvHBYNArkUOdV37shtJ,Sj7rMNYRuQPTtkBvpHKeDW3h,title in items:
				title = title.strip(mIsDke0oK5x1zSiOWbF9thGcA)
				x3WSXnKyPhjqfHG2UrtQs('video',wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,492,Sj7rMNYRuQPTtkBvpHKeDW3h)
		pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('"pagination"(.*?)</div>',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
		if pfRkcVlLmUxo561g0A8qSbO:
			mVYdjvor6i4wZ8 = pfRkcVlLmUxo561g0A8qSbO[0]
			items = ePhmG1jLD6.findall('href="(.*?)".*?>(.*?)</a>',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
			for MepIvHBYNArkUOdV37shtJ,title in items:
				title = j8PDV0pthfSTidZbsQxNIOmCYKWzH(title)
				title = title.replace('الصفحة ',qpFY4hAwolV3)
				if title!=qpFY4hAwolV3: x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+'صفحة '+title,MepIvHBYNArkUOdV37shtJ,491)
	return
def mzcAeyplZV(url):
	WSQlG8mDhqsNe = url.strip(ShynO8pN9idCE3)+'/?view=1'
	IAW0sh6So3NpqM = WWrExJZS3Bj4anOAkpv7(kUz8c7OqsxuPFIGfwg,'GET',WSQlG8mDhqsNe,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,'CIMACLUP-PLAY-1st')
	cmWl9dOKHPIy41iaXuxrY = IAW0sh6So3NpqM.content
	U7V0BQZPxXqMbyJnRw6f = []
	iipsGz2LKq = AWeJuo2LhZ5xiD8KNSqd9G0rtT74FE(url,'url')
	ezh5VObtS4uMRaBx0G9s1ri = ePhmG1jLD6.findall("data: 'q=(.*?)&",cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	ezh5VObtS4uMRaBx0G9s1ri = ezh5VObtS4uMRaBx0G9s1ri[0]
	pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('"serversList"(.*?)</ul>',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	if pfRkcVlLmUxo561g0A8qSbO:
		mVYdjvor6i4wZ8 = pfRkcVlLmUxo561g0A8qSbO[0]
		items = ePhmG1jLD6.findall('data-server="(.*?)">(.*?)</li>',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
		for jPKqLz2wnd7SoJ538lxhg,title in items:
			title = title.strip(mIsDke0oK5x1zSiOWbF9thGcA)
			MepIvHBYNArkUOdV37shtJ = iipsGz2LKq+'/wp-content/themes/old/servers/server.php?q='+ezh5VObtS4uMRaBx0G9s1ri+'&i='+jPKqLz2wnd7SoJ538lxhg+'?named='+title+'__watch'
			U7V0BQZPxXqMbyJnRw6f.append(MepIvHBYNArkUOdV37shtJ)
	MepIvHBYNArkUOdV37shtJ = ePhmG1jLD6.findall('"embedServer".*?SRC="(.*?)"',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	if MepIvHBYNArkUOdV37shtJ:
		title = 'مفضل'
		MepIvHBYNArkUOdV37shtJ = MepIvHBYNArkUOdV37shtJ[0]+'?named=__embed__'+title
		U7V0BQZPxXqMbyJnRw6f.append(MepIvHBYNArkUOdV37shtJ)
	pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('"downloadsList"(.*?)</div>',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	if pfRkcVlLmUxo561g0A8qSbO:
		mVYdjvor6i4wZ8 = pfRkcVlLmUxo561g0A8qSbO[0]
		items = ePhmG1jLD6.findall('<td>(.*?)</td>.*?href="(.*?)"',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
		for title,MepIvHBYNArkUOdV37shtJ in items:
			title = title.strip(mIsDke0oK5x1zSiOWbF9thGcA)
			if 'anavidz' in MepIvHBYNArkUOdV37shtJ: UdbGw48M6rCHDRmea5qP91nKI = '__خاص'
			else: UdbGw48M6rCHDRmea5qP91nKI = qpFY4hAwolV3
			MepIvHBYNArkUOdV37shtJ = MepIvHBYNArkUOdV37shtJ+'?named='+title+'__download'+UdbGw48M6rCHDRmea5qP91nKI
			U7V0BQZPxXqMbyJnRw6f.append(MepIvHBYNArkUOdV37shtJ)
	import inVXFK46ET
	inVXFK46ET.q4qTJvuoQUzM3mZAtegy7IXdnb5wH(U7V0BQZPxXqMbyJnRw6f,Q8Q0IDc6PLZajJAdTntKUmSGXz,'video',url)
	return
def PPqUACSE3VcGLTvw05jHy9JrFNW(search,iipsGz2LKq=qpFY4hAwolV3):
	if not iipsGz2LKq: iipsGz2LKq = ddBxj51bhNtaK23lDyGMVw
	search,LBylNhMdH6OV1qGk0tWiXFg3,showDialogs = LLm3sBXHPcnTDxdE5gt6hz0Wkp(search)
	if not search:
		search = jXgARlWMLVFUBnvmZwI2o5()
		if not search: return
	search = search.replace(mIsDke0oK5x1zSiOWbF9thGcA,'+')
	url = iipsGz2LKq+'/index.php?s='+search
	c8U1BdtxOZS5FH(url)
	return