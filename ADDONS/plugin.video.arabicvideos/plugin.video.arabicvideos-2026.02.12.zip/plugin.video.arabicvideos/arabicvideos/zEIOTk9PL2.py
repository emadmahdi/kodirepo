# -*- coding: utf-8 -*-
from pSfaryIjBo import *
Q8Q0IDc6PLZajJAdTntKUmSGXz = 'CIMA4U'
headers = {'User-Agent':qpFY4hAwolV3}
wwSFijdVJn1QgHW = '_C4U_'
ddBxj51bhNtaK23lDyGMVw = i4bFG3rKE6.SITESURLS[Q8Q0IDc6PLZajJAdTntKUmSGXz][0]
YEIA19ehBwpNfPVzK = ['مصارعة حرة','اخري','اخرى','الرئيسية','بدون إختيار','افلام','مسلسلات']
def vTNE2Ck1sGnugJYW8y39aLcSH64U(mode,url,text):
	if   mode==420: MOTjA5H9XFs = nRVAZc4Dp8PSrGU3xBk()
	elif mode==421: MOTjA5H9XFs = c8U1BdtxOZS5FH(url,text)
	elif mode==422: MOTjA5H9XFs = GMJIVNSa4Ridv5Ou(url)
	elif mode==423: MOTjA5H9XFs = v1gmfxDcRrWKQ(url)
	elif mode==424: MOTjA5H9XFs = R9pWUgVhBGLd2CQb0z(url,'ALL_ITEMS_FILTER___'+text)
	elif mode==425: MOTjA5H9XFs = R9pWUgVhBGLd2CQb0z(url,'SPECIFIED_FILTER___'+text)
	elif mode==426: MOTjA5H9XFs = mzcAeyplZV(url)
	elif mode==427: MOTjA5H9XFs = Gx9TikwZRt8mFvVpnBf4KbPJaDsqy6(url)
	elif mode==429: MOTjA5H9XFs = PPqUACSE3VcGLTvw05jHy9JrFNW(text)
	else: MOTjA5H9XFs = False
	return MOTjA5H9XFs
def nRVAZc4Dp8PSrGU3xBk():
	IAW0sh6So3NpqM = WWrExJZS3Bj4anOAkpv7(kUz8c7OqsxuPFIGfwg,'GET',ddBxj51bhNtaK23lDyGMVw,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,'CIMA4U-MENU-1st')
	cmWl9dOKHPIy41iaXuxrY = IAW0sh6So3NpqM.content
	iipsGz2LKq = ePhmG1jLD6.findall('href="(.*?)"',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	iipsGz2LKq = iipsGz2LKq[0].strip(ShynO8pN9idCE3)
	iipsGz2LKq = AWeJuo2LhZ5xiD8KNSqd9G0rtT74FE(iipsGz2LKq,'url')
	x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+'بحث في الموقع',qpFY4hAwolV3,429,qpFY4hAwolV3,qpFY4hAwolV3,'_REMEMBERRESULTS_')
	x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+'فلتر محدد',iipsGz2LKq,425)
	x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+'فلتر كامل',iipsGz2LKq,424)
	x3WSXnKyPhjqfHG2UrtQs('link',xupTj02bvy3O8R+' ===== ===== ===== '+fF4lt9zWYxXLKZVyAco82PgMj,qpFY4hAwolV3,9999)
	x3WSXnKyPhjqfHG2UrtQs('folder',Q8Q0IDc6PLZajJAdTntKUmSGXz+'_SCRIPT_'+wwSFijdVJn1QgHW+'الرئيسية',iipsGz2LKq,421)
	pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('NavigationMenu(.*?)</div>',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	mVYdjvor6i4wZ8 = pfRkcVlLmUxo561g0A8qSbO[0]
	items = ePhmG1jLD6.findall('href="*(.*?)"*>(.*?)<',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
	for MepIvHBYNArkUOdV37shtJ,title in items:
		if title in YEIA19ehBwpNfPVzK: continue
		if '/actors' in MepIvHBYNArkUOdV37shtJ: title = 'أفلام النجوم'
		elif '/netflix' in MepIvHBYNArkUOdV37shtJ: title = 'أفلام ومسلسلات نيتفلكس'
		x3WSXnKyPhjqfHG2UrtQs('folder',Q8Q0IDc6PLZajJAdTntKUmSGXz+'_SCRIPT_'+wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,421)
	x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+'قائمة تفصيلية',iipsGz2LKq,427)
	return
def Gx9TikwZRt8mFvVpnBf4KbPJaDsqy6(website=qpFY4hAwolV3):
	IAW0sh6So3NpqM = WWrExJZS3Bj4anOAkpv7(kUz8c7OqsxuPFIGfwg,'GET',ddBxj51bhNtaK23lDyGMVw,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,'CIMA4U-MENU-1st')
	cmWl9dOKHPIy41iaXuxrY = IAW0sh6So3NpqM.content
	pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('FilteringTitle(.*?)PageTitle',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	mVYdjvor6i4wZ8 = pfRkcVlLmUxo561g0A8qSbO[0]
	items = ePhmG1jLD6.findall('data-tax="*(.*?)"* data-id="*(.*?)[">]*<a href="*(.*?)[">]+.*?</div>(.*?)<',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
	for n1uwH0oJaGZ5WBd,id,MepIvHBYNArkUOdV37shtJ,title in items:
		if title in YEIA19ehBwpNfPVzK: continue
		if 'netflix-movies' in MepIvHBYNArkUOdV37shtJ: title = 'أفلام نيتفلكس'
		elif 'series-netflix' in MepIvHBYNArkUOdV37shtJ: title = 'مسلسلات نيتفلكس'
		x3WSXnKyPhjqfHG2UrtQs('folder',Q8Q0IDc6PLZajJAdTntKUmSGXz+'_SCRIPT_'+wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,421,qpFY4hAwolV3,qpFY4hAwolV3,n1uwH0oJaGZ5WBd+'|'+id)
	return
def c8U1BdtxOZS5FH(url,emb0iauxpw6ZAKNyoLHfc1qRnB9UME=qpFY4hAwolV3):
	if '/HomepageLoader/' in url: url = url.strip(ShynO8pN9idCE3)+'/mpaa/family/'
	items = []
	iipsGz2LKq = AWeJuo2LhZ5xiD8KNSqd9G0rtT74FE(url,'url')
	IAW0sh6So3NpqM = WWrExJZS3Bj4anOAkpv7(kUz8c7OqsxuPFIGfwg,'GET',url,qpFY4hAwolV3,headers,qpFY4hAwolV3,qpFY4hAwolV3,'CIMA4U-TITLES-1st')
	cmWl9dOKHPIy41iaXuxrY = IAW0sh6So3NpqM.content
	if not emb0iauxpw6ZAKNyoLHfc1qRnB9UME or '|' in emb0iauxpw6ZAKNyoLHfc1qRnB9UME:
		if '|' not in emb0iauxpw6ZAKNyoLHfc1qRnB9UME: ppaOWy1Vm47x5CEuJ = qpFY4hAwolV3
		else: ppaOWy1Vm47x5CEuJ = '/archive/'+emb0iauxpw6ZAKNyoLHfc1qRnB9UME
		aKNztUwJBSXgd = False
		if 'PinSlider' in cmWl9dOKHPIy41iaXuxrY:
			x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+'المميزة',url,421,qpFY4hAwolV3,qpFY4hAwolV3,'featured')
			aKNztUwJBSXgd = True
		pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('PageTitle(.*?)PageContent',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
		if pfRkcVlLmUxo561g0A8qSbO:
			WqdHmfQpP0ITnjJOAbDR6u8t7EiU = pfRkcVlLmUxo561g0A8qSbO[0]
			eKEo1iY0x8kAcU76ChWaypzHIwlRMq = ePhmG1jLD6.findall('data-tab="(.*?)".*?<span>(.*?)<',WqdHmfQpP0ITnjJOAbDR6u8t7EiU,ePhmG1jLD6.DOTALL)
			for PSwOUCDZaI4Et,UdbGw48M6rCHDRmea5qP91nKI in eKEo1iY0x8kAcU76ChWaypzHIwlRMq:
				OexQX2mTwfGkuU6AIBLz9vWlHjdF8 = iipsGz2LKq+'/ajaxcenter/action/HomepageLoader/tab/'+PSwOUCDZaI4Et+ppaOWy1Vm47x5CEuJ+ShynO8pN9idCE3
				x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+UdbGw48M6rCHDRmea5qP91nKI,OexQX2mTwfGkuU6AIBLz9vWlHjdF8,421)
				aKNztUwJBSXgd = True
		if aKNztUwJBSXgd: x3WSXnKyPhjqfHG2UrtQs('link',xupTj02bvy3O8R+' ===== ===== ===== '+fF4lt9zWYxXLKZVyAco82PgMj,qpFY4hAwolV3,9999)
	if emb0iauxpw6ZAKNyoLHfc1qRnB9UME=='featured':
		pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('PinSlider(.*?)MultiFilter',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
		if not pfRkcVlLmUxo561g0A8qSbO: pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('PinSlider(.*?)PageTitle',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
		if pfRkcVlLmUxo561g0A8qSbO: mVYdjvor6i4wZ8 = pfRkcVlLmUxo561g0A8qSbO[0]
		else: mVYdjvor6i4wZ8 = qpFY4hAwolV3
	elif '/HomepageLoader/' in url or '/searchcenter/' in url:
		mVYdjvor6i4wZ8 = cmWl9dOKHPIy41iaXuxrY
	elif '/filter/' in url:
		pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('PageContent(.*?)class="*pagination"*',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
		mVYdjvor6i4wZ8 = pfRkcVlLmUxo561g0A8qSbO[0]
	elif '/actors' in url:
		pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('PageContent(.*?)class="*pagination"*',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
		mVYdjvor6i4wZ8 = pfRkcVlLmUxo561g0A8qSbO[0]
		items = ePhmG1jLD6.findall('href="*(.*?)[">]+.*?image:url\((.*?)\).*?ActorName">(.*?)<',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
	else:
		pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('Cima4uBlocks(.*?)</li></ul>',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
		if pfRkcVlLmUxo561g0A8qSbO: mVYdjvor6i4wZ8 = pfRkcVlLmUxo561g0A8qSbO[0]
		else: mVYdjvor6i4wZ8 = qpFY4hAwolV3
	if not items: items = ePhmG1jLD6.findall('class="*MovieBlock"*.*?href="*(.*?)[">]+.*?image:url\((.*?)\).*?image.*?BoxTitleInfo.*?</div></div>(.*?)<',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
	if not items: items = ePhmG1jLD6.findall('class="MovieBlock".*?href="(.*?)".*?data-image="(.*?)".*?alt="(.*?)"',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
	aaCNAJdtsguSRELh2I = []
	for MepIvHBYNArkUOdV37shtJ,Sj7rMNYRuQPTtkBvpHKeDW3h,title in items:
		if not title: continue
		if '?news=' in MepIvHBYNArkUOdV37shtJ: continue
		title = title.replace('مشاهدة ',qpFY4hAwolV3)
		title = j8PDV0pthfSTidZbsQxNIOmCYKWzH(title)
		ZDTxRSMbW7PNz = ePhmG1jLD6.findall('(.*?) حلقة \d+',title,ePhmG1jLD6.DOTALL)
		if ZDTxRSMbW7PNz and 'حلقة' in title:
			title = '_MOD_' + ZDTxRSMbW7PNz[0]
			if title not in aaCNAJdtsguSRELh2I:
				x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,422,Sj7rMNYRuQPTtkBvpHKeDW3h)
				aaCNAJdtsguSRELh2I.append(title)
		elif '/actor/' in MepIvHBYNArkUOdV37shtJ: x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,421,Sj7rMNYRuQPTtkBvpHKeDW3h)
		else: x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,422,Sj7rMNYRuQPTtkBvpHKeDW3h)
	pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('pagination(.*?)</ul>',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	if pfRkcVlLmUxo561g0A8qSbO and emb0iauxpw6ZAKNyoLHfc1qRnB9UME!='featured':
		mVYdjvor6i4wZ8 = pfRkcVlLmUxo561g0A8qSbO[0]
		items = ePhmG1jLD6.findall('href=[\'\"](.*?)[\'\"]>(.*?)<',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
		for MepIvHBYNArkUOdV37shtJ,title in items:
			title = j8PDV0pthfSTidZbsQxNIOmCYKWzH(title)
			title = title.replace('الصفحة ',qpFY4hAwolV3)
			if title!=qpFY4hAwolV3: x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+'صفحة '+title,MepIvHBYNArkUOdV37shtJ,421)
	aBu8P2i7wnIoDs = ePhmG1jLD6.findall('</li><a href="(.*?)".*?>(.*?)<',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	if aBu8P2i7wnIoDs:
		MepIvHBYNArkUOdV37shtJ,title = aBu8P2i7wnIoDs[0]
		x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,421)
	return
def GMJIVNSa4Ridv5Ou(url):
	IAW0sh6So3NpqM = WWrExJZS3Bj4anOAkpv7(kUz8c7OqsxuPFIGfwg,'GET',url,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,'CIMA4U-SEASONS-1st')
	cmWl9dOKHPIy41iaXuxrY = IAW0sh6So3NpqM.content
	pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('class="WatchNow".*?href="(.*?)"',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	if pfRkcVlLmUxo561g0A8qSbO:
		url = pfRkcVlLmUxo561g0A8qSbO[0]
		IAW0sh6So3NpqM = WWrExJZS3Bj4anOAkpv7(kUz8c7OqsxuPFIGfwg,'GET',url,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,'CIMA4U-SEASONS-2nd')
		cmWl9dOKHPIy41iaXuxrY = IAW0sh6So3NpqM.content
	pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('SeasonsSections(.*?)</div></div></div>',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	if '/tag/' in url or '/actor' in url:
		c8U1BdtxOZS5FH(url)
	elif pfRkcVlLmUxo561g0A8qSbO:
		Sj7rMNYRuQPTtkBvpHKeDW3h = Rqvw05BorCgcye7VE32Sf.getInfoLabel('ListItem.Thumb')
		mVYdjvor6i4wZ8 = pfRkcVlLmUxo561g0A8qSbO[0]
		items = ePhmG1jLD6.findall("href='(.*?)'>(.*?)<",mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
		zxcY1tCfMZwW = ['مسلسل','موسم','برنامج','حلقة']
		for MepIvHBYNArkUOdV37shtJ,title in items:
			if any(value in title for value in zxcY1tCfMZwW):
				x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,423,Sj7rMNYRuQPTtkBvpHKeDW3h)
			else: x3WSXnKyPhjqfHG2UrtQs('video',wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,426,Sj7rMNYRuQPTtkBvpHKeDW3h)
	else: v1gmfxDcRrWKQ(url)
	return
def v1gmfxDcRrWKQ(url):
	IAW0sh6So3NpqM = WWrExJZS3Bj4anOAkpv7(kUz8c7OqsxuPFIGfwg,'GET',url,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,'CIMA4U-EPISODES-1st')
	cmWl9dOKHPIy41iaXuxrY = IAW0sh6So3NpqM.content
	Sj7rMNYRuQPTtkBvpHKeDW3h = ePhmG1jLD6.findall('"background-image:url\((.*?)\)',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	if Sj7rMNYRuQPTtkBvpHKeDW3h: Sj7rMNYRuQPTtkBvpHKeDW3h = Sj7rMNYRuQPTtkBvpHKeDW3h[0]
	else: Sj7rMNYRuQPTtkBvpHKeDW3h = qpFY4hAwolV3
	Tj9nPzghOXy2DGspIZHK = ePhmG1jLD6.findall('EpisodesSection(.*?)</ul>',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	if Tj9nPzghOXy2DGspIZHK:
		mVYdjvor6i4wZ8 = Tj9nPzghOXy2DGspIZHK[0]
		items = ePhmG1jLD6.findall('href="(.*?)"><em>(.*?)<.*?<span>(.*?)<',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
		for MepIvHBYNArkUOdV37shtJ,title,ZDTxRSMbW7PNz in items:
			title = title+mIsDke0oK5x1zSiOWbF9thGcA+ZDTxRSMbW7PNz
			x3WSXnKyPhjqfHG2UrtQs('video',wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,426,Sj7rMNYRuQPTtkBvpHKeDW3h)
	else: x3WSXnKyPhjqfHG2UrtQs('video',wwSFijdVJn1QgHW+'رابط التشغيل',url,426,Sj7rMNYRuQPTtkBvpHKeDW3h)
	return
def mzcAeyplZV(url):
	IAW0sh6So3NpqM = WWrExJZS3Bj4anOAkpv7(kUz8c7OqsxuPFIGfwg,'GET',url,qpFY4hAwolV3,headers,qpFY4hAwolV3,qpFY4hAwolV3,'CIMA4U-PLAY-1st')
	cmWl9dOKHPIy41iaXuxrY = IAW0sh6So3NpqM.content
	oF8Hm1sd4La7N = IAW0sh6So3NpqM.url
	if NJwViHDTMdmO0xnALqQ9voPalC3Ip: oF8Hm1sd4La7N = oF8Hm1sd4La7N.encode(nV3Tip6XsH1rJw79DPOU)
	iipsGz2LKq = AWeJuo2LhZ5xiD8KNSqd9G0rtT74FE(oF8Hm1sd4La7N,'url')
	U7V0BQZPxXqMbyJnRw6f = []
	pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('WatchSection(.*?)</div></div>',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	if pfRkcVlLmUxo561g0A8qSbO:
		mVYdjvor6i4wZ8 = pfRkcVlLmUxo561g0A8qSbO[0]
		items = ePhmG1jLD6.findall('data-link="(.*?)".*? />(.*?)<',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
		for YoxGJTz0QS8dLrAcZq5tBeXVNK1,title in items:
			title = title.strip(mIsDke0oK5x1zSiOWbF9thGcA)
			if 'myvid' in title.lower(): title = 'خاص '+title
			MepIvHBYNArkUOdV37shtJ = iipsGz2LKq+'/structure/server.php?id='+YoxGJTz0QS8dLrAcZq5tBeXVNK1+'?named='+title+'__watch'
			MepIvHBYNArkUOdV37shtJ = MepIvHBYNArkUOdV37shtJ.replace(SGUiazdreo6QRKLOWZj5hMX,qpFY4hAwolV3)
			U7V0BQZPxXqMbyJnRw6f.append(MepIvHBYNArkUOdV37shtJ)
	pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('DownloadServers(.*?)</div></div>',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	if pfRkcVlLmUxo561g0A8qSbO:
		mVYdjvor6i4wZ8 = pfRkcVlLmUxo561g0A8qSbO[0]
		items = ePhmG1jLD6.findall('href="(.*?)".*? />(.*?)<',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
		for MepIvHBYNArkUOdV37shtJ,title in items:
			title = title.strip(mIsDke0oK5x1zSiOWbF9thGcA)
			if 'myvid' in title.lower(): UdbGw48M6rCHDRmea5qP91nKI = '__خاص'
			else: UdbGw48M6rCHDRmea5qP91nKI = qpFY4hAwolV3
			MepIvHBYNArkUOdV37shtJ = MepIvHBYNArkUOdV37shtJ+'?named='+title+'__download'+UdbGw48M6rCHDRmea5qP91nKI
			MepIvHBYNArkUOdV37shtJ = MepIvHBYNArkUOdV37shtJ.replace(SGUiazdreo6QRKLOWZj5hMX,qpFY4hAwolV3)
			U7V0BQZPxXqMbyJnRw6f.append(MepIvHBYNArkUOdV37shtJ)
	import inVXFK46ET
	inVXFK46ET.q4qTJvuoQUzM3mZAtegy7IXdnb5wH(U7V0BQZPxXqMbyJnRw6f,Q8Q0IDc6PLZajJAdTntKUmSGXz,'video',url)
	return
def PPqUACSE3VcGLTvw05jHy9JrFNW(search):
	search,LBylNhMdH6OV1qGk0tWiXFg3,showDialogs = LLm3sBXHPcnTDxdE5gt6hz0Wkp(search)
	if search==qpFY4hAwolV3: search = jXgARlWMLVFUBnvmZwI2o5()
	if search==qpFY4hAwolV3: return
	search = search.replace(mIsDke0oK5x1zSiOWbF9thGcA,'+')
	url = ddBxj51bhNtaK23lDyGMVw+'/Search?q='+search
	c8U1BdtxOZS5FH(url,'search')
	return
def ZcGxoMbewJAYq1sSlV0(url):
	if 'smartemadfilter' not in url: url = AWeJuo2LhZ5xiD8KNSqd9G0rtT74FE(url,'url')
	else: url = url.split('/smartemadfilter?')[0]
	IAW0sh6So3NpqM = WWrExJZS3Bj4anOAkpv7(kUz8c7OqsxuPFIGfwg,'GET',url,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,'CIMA4U-GET_FILTERS_BLOCKS-1st')
	cmWl9dOKHPIy41iaXuxrY = IAW0sh6So3NpqM.content
	pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('MultiFilter(.*?)PageTitle',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	mVYdjvor6i4wZ8 = pfRkcVlLmUxo561g0A8qSbO[0]
	YF4LRjr6TuagQk9o3PiMeIcHx = ePhmG1jLD6.findall('Hoverable.*?<span>(.*?)</span>.*?"all".*?(data-tax="(.*?)".*?)</ul>',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
	return YF4LRjr6TuagQk9o3PiMeIcHx
def iiNGgPHcqX4tCAdRUz(mVYdjvor6i4wZ8):
	items = ePhmG1jLD6.findall('data-id="(.*?)".*?</div>(.*?)</a>',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
	return items
def L0LEtmdaBXk5VTMpnPx7(url):
	CFNSuRJWb5 = url.split('/smartemadfilter?')[0]
	TIr1DgNEH2jsp8547Fx = AWeJuo2LhZ5xiD8KNSqd9G0rtT74FE(url,'url')
	url = url.replace(CFNSuRJWb5,TIr1DgNEH2jsp8547Fx)
	url = url.replace('/smartemadfilter?','/ajaxcenter/action/HomepageLoader/')
	url = url.replace('=',ShynO8pN9idCE3).replace('&',ShynO8pN9idCE3)
	url = url+ShynO8pN9idCE3
	return url
LLAbR2tC6J7OuvqfV4iYg = ['category','types','release-year']
VlsAo2qQ0BbEhZTgNL9u = ['Quality','release-year','types','category']
def R9pWUgVhBGLd2CQb0z(url,filter):
	if '?' in url: url = url.split('/smartemadfilter?')[0]
	type,filter = filter.split('___',1)
	if filter==qpFY4hAwolV3: eAYm1EkvcnOzXWpFB68o9rglSQ0M5,M0jc2ZsJHPb1d3DCoyXIzmgt = qpFY4hAwolV3,qpFY4hAwolV3
	else: eAYm1EkvcnOzXWpFB68o9rglSQ0M5,M0jc2ZsJHPb1d3DCoyXIzmgt = filter.split('___')
	if type=='SPECIFIED_FILTER':
		if '/category/' in url:
			global LLAbR2tC6J7OuvqfV4iYg
			LLAbR2tC6J7OuvqfV4iYg = LLAbR2tC6J7OuvqfV4iYg[1:]
		if LLAbR2tC6J7OuvqfV4iYg[0]+'=' not in eAYm1EkvcnOzXWpFB68o9rglSQ0M5: n1uwH0oJaGZ5WBd = LLAbR2tC6J7OuvqfV4iYg[0]
		for a2jQ83ZCfcM5 in range(len(LLAbR2tC6J7OuvqfV4iYg[0:-1])):
			if LLAbR2tC6J7OuvqfV4iYg[a2jQ83ZCfcM5]+'=' in eAYm1EkvcnOzXWpFB68o9rglSQ0M5: n1uwH0oJaGZ5WBd = LLAbR2tC6J7OuvqfV4iYg[a2jQ83ZCfcM5+1]
		OI4ExuWvaLU = eAYm1EkvcnOzXWpFB68o9rglSQ0M5+'&'+n1uwH0oJaGZ5WBd+'=0'
		vmTWLw30V2PFNC8DrRqI = M0jc2ZsJHPb1d3DCoyXIzmgt+'&'+n1uwH0oJaGZ5WBd+'=0'
		nxGqbf39mXPhwl1NtAsSYK = OI4ExuWvaLU.strip('&')+'___'+vmTWLw30V2PFNC8DrRqI.strip('&')
		ekvC3tHRVnZGM4uDsmE2pBc5x = ZX8DyBJbV4lNAG(M0jc2ZsJHPb1d3DCoyXIzmgt,'modified_filters')
		WSQlG8mDhqsNe = url+'/smartemadfilter?'+ekvC3tHRVnZGM4uDsmE2pBc5x
	elif type=='ALL_ITEMS_FILTER':
		Q7PrOdIzEeXgpT4HL38GK = ZX8DyBJbV4lNAG(eAYm1EkvcnOzXWpFB68o9rglSQ0M5,'modified_values')
		Q7PrOdIzEeXgpT4HL38GK = cTt4u6reEMKZqVLplmkNW7(Q7PrOdIzEeXgpT4HL38GK)
		if M0jc2ZsJHPb1d3DCoyXIzmgt!=qpFY4hAwolV3: M0jc2ZsJHPb1d3DCoyXIzmgt = ZX8DyBJbV4lNAG(M0jc2ZsJHPb1d3DCoyXIzmgt,'modified_filters')
		if M0jc2ZsJHPb1d3DCoyXIzmgt==qpFY4hAwolV3: WSQlG8mDhqsNe = url
		else: WSQlG8mDhqsNe = url+'/smartemadfilter?'+M0jc2ZsJHPb1d3DCoyXIzmgt
		WSQlG8mDhqsNe = L0LEtmdaBXk5VTMpnPx7(WSQlG8mDhqsNe)
		x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+'أظهار قائمة الفيديو التي تم اختيارها ',WSQlG8mDhqsNe,421,qpFY4hAwolV3,qpFY4hAwolV3,'filter')
		x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+' [[   '+Q7PrOdIzEeXgpT4HL38GK+'   ]]',WSQlG8mDhqsNe,421,qpFY4hAwolV3,qpFY4hAwolV3,'filter')
		x3WSXnKyPhjqfHG2UrtQs('link',xupTj02bvy3O8R+' ===== ===== ===== '+fF4lt9zWYxXLKZVyAco82PgMj,qpFY4hAwolV3,9999)
	YF4LRjr6TuagQk9o3PiMeIcHx = ZcGxoMbewJAYq1sSlV0(url)
	dict = {}
	for name,mVYdjvor6i4wZ8,CQlVpYyFN6bzXRBZIMxPWdn in YF4LRjr6TuagQk9o3PiMeIcHx:
		if '/category/' in url and CQlVpYyFN6bzXRBZIMxPWdn=='category': continue
		name = name.replace('--',qpFY4hAwolV3)
		items = iiNGgPHcqX4tCAdRUz(mVYdjvor6i4wZ8)
		if '=' not in WSQlG8mDhqsNe: WSQlG8mDhqsNe = url
		if type=='SPECIFIED_FILTER':
			if n1uwH0oJaGZ5WBd!=CQlVpYyFN6bzXRBZIMxPWdn: continue
			elif len(items)<2:
				if CQlVpYyFN6bzXRBZIMxPWdn==LLAbR2tC6J7OuvqfV4iYg[-1]:
					url = L0LEtmdaBXk5VTMpnPx7(url)
					c8U1BdtxOZS5FH(url)
				else: R9pWUgVhBGLd2CQb0z(WSQlG8mDhqsNe,'SPECIFIED_FILTER___'+nxGqbf39mXPhwl1NtAsSYK)
				return
			else:
				WSQlG8mDhqsNe = L0LEtmdaBXk5VTMpnPx7(WSQlG8mDhqsNe)
				if CQlVpYyFN6bzXRBZIMxPWdn==LLAbR2tC6J7OuvqfV4iYg[-1]: x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+'الجميع',WSQlG8mDhqsNe,421,qpFY4hAwolV3,qpFY4hAwolV3,'filter')
				else: x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+'الجميع',WSQlG8mDhqsNe,425,qpFY4hAwolV3,qpFY4hAwolV3,nxGqbf39mXPhwl1NtAsSYK)
		elif type=='ALL_ITEMS_FILTER':
			OI4ExuWvaLU = eAYm1EkvcnOzXWpFB68o9rglSQ0M5+'&'+CQlVpYyFN6bzXRBZIMxPWdn+'=0'
			vmTWLw30V2PFNC8DrRqI = M0jc2ZsJHPb1d3DCoyXIzmgt+'&'+CQlVpYyFN6bzXRBZIMxPWdn+'=0'
			nxGqbf39mXPhwl1NtAsSYK = OI4ExuWvaLU+'___'+vmTWLw30V2PFNC8DrRqI
			x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+'الجميع :'+name,WSQlG8mDhqsNe,424,qpFY4hAwolV3,qpFY4hAwolV3,nxGqbf39mXPhwl1NtAsSYK)
		dict[CQlVpYyFN6bzXRBZIMxPWdn] = {}
		for value,FLkeT4nCDqrQMmW6ZSlgyU5jIO32 in items:
			if value=='196533': FLkeT4nCDqrQMmW6ZSlgyU5jIO32 = 'أفلام نيتفلكس'
			elif value=='196531': FLkeT4nCDqrQMmW6ZSlgyU5jIO32 = 'مسلسلات نيتفلكس'
			if FLkeT4nCDqrQMmW6ZSlgyU5jIO32 in YEIA19ehBwpNfPVzK: continue
			dict[CQlVpYyFN6bzXRBZIMxPWdn][value] = FLkeT4nCDqrQMmW6ZSlgyU5jIO32
			OI4ExuWvaLU = eAYm1EkvcnOzXWpFB68o9rglSQ0M5+'&'+CQlVpYyFN6bzXRBZIMxPWdn+'='+FLkeT4nCDqrQMmW6ZSlgyU5jIO32
			vmTWLw30V2PFNC8DrRqI = M0jc2ZsJHPb1d3DCoyXIzmgt+'&'+CQlVpYyFN6bzXRBZIMxPWdn+'='+value
			lJWPN5EDIbft92m6iCQqAYLjav4p = OI4ExuWvaLU+'___'+vmTWLw30V2PFNC8DrRqI
			title = FLkeT4nCDqrQMmW6ZSlgyU5jIO32+' :'#+dict[CQlVpYyFN6bzXRBZIMxPWdn]['0']
			title = FLkeT4nCDqrQMmW6ZSlgyU5jIO32+' :'+name
			if type=='ALL_ITEMS_FILTER': x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+title,url,424,qpFY4hAwolV3,qpFY4hAwolV3,lJWPN5EDIbft92m6iCQqAYLjav4p)
			elif type=='SPECIFIED_FILTER' and LLAbR2tC6J7OuvqfV4iYg[-2]+'=' in eAYm1EkvcnOzXWpFB68o9rglSQ0M5:
				ekvC3tHRVnZGM4uDsmE2pBc5x = ZX8DyBJbV4lNAG(vmTWLw30V2PFNC8DrRqI,'modified_filters')
				hhpztscnBD1GP = url+'/smartemadfilter?'+ekvC3tHRVnZGM4uDsmE2pBc5x
				hhpztscnBD1GP = L0LEtmdaBXk5VTMpnPx7(hhpztscnBD1GP)
				x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+title,hhpztscnBD1GP,421,qpFY4hAwolV3,qpFY4hAwolV3,'filter')
			else: x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+title,url,425,qpFY4hAwolV3,qpFY4hAwolV3,lJWPN5EDIbft92m6iCQqAYLjav4p)
	return
def ZX8DyBJbV4lNAG(bbaYxjcVnksy,mode):
	bbaYxjcVnksy = bbaYxjcVnksy.replace('=&','=0&')
	bbaYxjcVnksy = bbaYxjcVnksy.strip('&')
	J9ASCRhfiDyTB = {}
	if '=' in bbaYxjcVnksy:
		items = bbaYxjcVnksy.split('&')
		for lkd2oKvZF03qmgMbIfQ6cD in items:
			JJAsQ4pRYXPhqugN2to9TEzLIS,value = lkd2oKvZF03qmgMbIfQ6cD.split('=')
			J9ASCRhfiDyTB[JJAsQ4pRYXPhqugN2to9TEzLIS] = value
	LxOIqpMU7E1hPKH5fSzj2iW9v = qpFY4hAwolV3
	for key in VlsAo2qQ0BbEhZTgNL9u:
		if key in list(J9ASCRhfiDyTB.keys()): value = J9ASCRhfiDyTB[key]
		else: value = '0'
		if '%' not in value: value = BUKlErdIu7Ggqcz3jYpf09wMePF4V(value)
		if mode=='modified_values' and value!='0': LxOIqpMU7E1hPKH5fSzj2iW9v = LxOIqpMU7E1hPKH5fSzj2iW9v+' + '+value
		elif mode=='modified_filters' and value!='0': LxOIqpMU7E1hPKH5fSzj2iW9v = LxOIqpMU7E1hPKH5fSzj2iW9v+'&'+key+'='+value
		elif mode=='all': LxOIqpMU7E1hPKH5fSzj2iW9v = LxOIqpMU7E1hPKH5fSzj2iW9v+'&'+key+'='+value
	LxOIqpMU7E1hPKH5fSzj2iW9v = LxOIqpMU7E1hPKH5fSzj2iW9v.strip(' + ')
	LxOIqpMU7E1hPKH5fSzj2iW9v = LxOIqpMU7E1hPKH5fSzj2iW9v.strip('&')
	LxOIqpMU7E1hPKH5fSzj2iW9v = LxOIqpMU7E1hPKH5fSzj2iW9v.replace('=0','=')
	return LxOIqpMU7E1hPKH5fSzj2iW9v