# -*- coding: utf-8 -*-
from pSfaryIjBo import *
Q8Q0IDc6PLZajJAdTntKUmSGXz = 'HALACIMA'
wwSFijdVJn1QgHW = '_HLC_'
ddBxj51bhNtaK23lDyGMVw = i4bFG3rKE6.SITESURLS[Q8Q0IDc6PLZajJAdTntKUmSGXz][0]
YEIA19ehBwpNfPVzK = ['مصارعة','احدث البرامج','احدث الالعاب','احدث الاغانى']
def vTNE2Ck1sGnugJYW8y39aLcSH64U(mode,url,text):
	if   mode==80: MOTjA5H9XFs = nRVAZc4Dp8PSrGU3xBk()
	elif mode==81: MOTjA5H9XFs = c8U1BdtxOZS5FH(url,text)
	elif mode==82: MOTjA5H9XFs = mzcAeyplZV(url)
	elif mode==83: MOTjA5H9XFs = v1gmfxDcRrWKQ(url)
	elif mode==89: MOTjA5H9XFs = PPqUACSE3VcGLTvw05jHy9JrFNW(text)
	else: MOTjA5H9XFs = False
	return MOTjA5H9XFs
def nRVAZc4Dp8PSrGU3xBk():
	IAW0sh6So3NpqM = WWrExJZS3Bj4anOAkpv7(kUz8c7OqsxuPFIGfwg,'GET',ddBxj51bhNtaK23lDyGMVw,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,'HALACIMA-MENU-1st')
	cmWl9dOKHPIy41iaXuxrY = IAW0sh6So3NpqM.content
	iipsGz2LKq = AWeJuo2LhZ5xiD8KNSqd9G0rtT74FE(ddBxj51bhNtaK23lDyGMVw,'url')
	x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+'بحث في الموقع',qpFY4hAwolV3,89,qpFY4hAwolV3,qpFY4hAwolV3,'_REMEMBERRESULTS_')
	x3WSXnKyPhjqfHG2UrtQs('link',xupTj02bvy3O8R+' ===== ===== ===== '+fF4lt9zWYxXLKZVyAco82PgMj,qpFY4hAwolV3,9999)
	pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('main-content(.*?)</ul>',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	mVYdjvor6i4wZ8 = pfRkcVlLmUxo561g0A8qSbO[0]
	items = ePhmG1jLD6.findall('data-name="(.*?)".*?</i>(.*?)<',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
	for emb0iauxpw6ZAKNyoLHfc1qRnB9UME,title in items:
		MepIvHBYNArkUOdV37shtJ = iipsGz2LKq+'/ajax/getItem?item='+emb0iauxpw6ZAKNyoLHfc1qRnB9UME+'&Ajax=1'
		x3WSXnKyPhjqfHG2UrtQs('folder',Q8Q0IDc6PLZajJAdTntKUmSGXz+'_SCRIPT_'+wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,81)
	x3WSXnKyPhjqfHG2UrtQs('link',xupTj02bvy3O8R+' ===== ===== ===== '+fF4lt9zWYxXLKZVyAco82PgMj,qpFY4hAwolV3,9999)
	pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('"nav-main"(.*?)</nav>',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	mVYdjvor6i4wZ8 = pfRkcVlLmUxo561g0A8qSbO[0]
	items = ePhmG1jLD6.findall('href="(.*?)">(.*?)<',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
	for MepIvHBYNArkUOdV37shtJ,title in items:
		if MepIvHBYNArkUOdV37shtJ=='#': continue
		if title in YEIA19ehBwpNfPVzK: continue
		x3WSXnKyPhjqfHG2UrtQs('folder',Q8Q0IDc6PLZajJAdTntKUmSGXz+'_SCRIPT_'+wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,81)
	return
def c8U1BdtxOZS5FH(url,emb0iauxpw6ZAKNyoLHfc1qRnB9UME=qpFY4hAwolV3):
	items = []
	if '/ajax/getItem' in url or '/ajax/loadMore' in url:
		WSQlG8mDhqsNe,RZ2SwHp6GQvAy = D02sQSgOGhTJxtKyFEId74Nrv8bYU(url)
		skD7g3FxW4wCa5BR = {'Content-Type':'application/x-www-form-urlencoded; charset=UTF-8'}
		IAW0sh6So3NpqM = WWrExJZS3Bj4anOAkpv7(kUz8c7OqsxuPFIGfwg,'POST',WSQlG8mDhqsNe,RZ2SwHp6GQvAy,skD7g3FxW4wCa5BR,qpFY4hAwolV3,qpFY4hAwolV3,'HALACIMA-TITLES-1st')
		cmWl9dOKHPIy41iaXuxrY = IAW0sh6So3NpqM.content
		pfRkcVlLmUxo561g0A8qSbO = [cmWl9dOKHPIy41iaXuxrY]
	else:
		IAW0sh6So3NpqM = WWrExJZS3Bj4anOAkpv7(kUz8c7OqsxuPFIGfwg,'GET',url,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,'HALACIMA-TITLES-2nd')
		cmWl9dOKHPIy41iaXuxrY = IAW0sh6So3NpqM.content
		if emb0iauxpw6ZAKNyoLHfc1qRnB9UME=='featured':
			pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('"container"(.*?)"container"',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
			mVYdjvor6i4wZ8 = pfRkcVlLmUxo561g0A8qSbO[0]
			items = ePhmG1jLD6.findall('href="(.*?)" title="(.*?)".*?src="(.*?)"',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
		elif '"section-post mb-10"' in cmWl9dOKHPIy41iaXuxrY:
			pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('"section-post mb-10"(.*?)"container"',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
		else:
			pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('<article(.*?)"pagination"',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	if not pfRkcVlLmUxo561g0A8qSbO: return
	mVYdjvor6i4wZ8 = pfRkcVlLmUxo561g0A8qSbO[0]
	if not items:
		items = ePhmG1jLD6.findall('href="(.*?)" title="(.*?)".*?data-original="(.*?)"',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
		if not items: items = ePhmG1jLD6.findall('href="(.*?)" title="(.*?)".*?src="(.*?)"',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
	aaCNAJdtsguSRELh2I = []
	WGid3I2kFU = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم']
	for MepIvHBYNArkUOdV37shtJ,title,Sj7rMNYRuQPTtkBvpHKeDW3h in items:
		MepIvHBYNArkUOdV37shtJ = cTt4u6reEMKZqVLplmkNW7(MepIvHBYNArkUOdV37shtJ).strip(ShynO8pN9idCE3)
		ZDTxRSMbW7PNz = ePhmG1jLD6.findall('(.*?) الحلقة \d+',title,ePhmG1jLD6.DOTALL)
		if '/series/' in MepIvHBYNArkUOdV37shtJ:
			x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,83,Sj7rMNYRuQPTtkBvpHKeDW3h)
		elif 'سلاسل' not in url and any(value in title for value in WGid3I2kFU):
			x3WSXnKyPhjqfHG2UrtQs('video',wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,82,Sj7rMNYRuQPTtkBvpHKeDW3h)
		elif ZDTxRSMbW7PNz and 'الحلقة' in title:
			title = '_MOD_' + ZDTxRSMbW7PNz[0]
			if title not in aaCNAJdtsguSRELh2I:
				x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,83,Sj7rMNYRuQPTtkBvpHKeDW3h)
				aaCNAJdtsguSRELh2I.append(title)
		elif '/movies/' in MepIvHBYNArkUOdV37shtJ:
			x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,81,Sj7rMNYRuQPTtkBvpHKeDW3h)
		else: x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,83,Sj7rMNYRuQPTtkBvpHKeDW3h)
	if emb0iauxpw6ZAKNyoLHfc1qRnB9UME==qpFY4hAwolV3:
		pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('"pagination"(.*?)<footer',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
		if pfRkcVlLmUxo561g0A8qSbO:
			mVYdjvor6i4wZ8 = pfRkcVlLmUxo561g0A8qSbO[0]
			items = ePhmG1jLD6.findall('href="(.*?)".*?>(.*?)<',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
			for MepIvHBYNArkUOdV37shtJ,title in items:
				if MepIvHBYNArkUOdV37shtJ=="": continue
				if title!=qpFY4hAwolV3: x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+'صفحة '+title,MepIvHBYNArkUOdV37shtJ,81)
	if '/ajax/getItem' in url or '/ajax/loadMore' in url:
		if '/ajax/getItem' in url:
			url = url.replace('/ajax/getItem','/ajax/loadMore')+'&offset=20'
		elif '/ajax/loadMore' in url:
			url,offset = url.split('&offset=')
			offset = int(offset)+20
			url = url+'&offset='+str(offset)
		x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+'هناك المزيد',url,81)
	return
def v1gmfxDcRrWKQ(url):
	IAW0sh6So3NpqM = WWrExJZS3Bj4anOAkpv7(kUz8c7OqsxuPFIGfwg,'GET',url,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,'HALACIMA-EPISODES-1st')
	cmWl9dOKHPIy41iaXuxrY = IAW0sh6So3NpqM.content
	NDnI9Qrpt5c8MU = ePhmG1jLD6.findall('"getSeasonsBySeries(.*?)"container"',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	T9TAc28ayKvFgjfd6SD = ePhmG1jLD6.findall('"list-episodes"(.*?)"container"',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	if NDnI9Qrpt5c8MU and '/series/' not in url:
		mVYdjvor6i4wZ8 = NDnI9Qrpt5c8MU[0]
		items = ePhmG1jLD6.findall('href="(.*?)" title="(.*?)".*?src="(.*?)"',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
		for MepIvHBYNArkUOdV37shtJ,title,Sj7rMNYRuQPTtkBvpHKeDW3h in items:
			x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,83,Sj7rMNYRuQPTtkBvpHKeDW3h)
	elif T9TAc28ayKvFgjfd6SD:
		Sj7rMNYRuQPTtkBvpHKeDW3h = ePhmG1jLD6.findall('"image" src="(.*?)"',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
		Sj7rMNYRuQPTtkBvpHKeDW3h = Sj7rMNYRuQPTtkBvpHKeDW3h[0]
		mVYdjvor6i4wZ8 = T9TAc28ayKvFgjfd6SD[0]
		items = ePhmG1jLD6.findall('href="(.*?)" title="(.*?)"',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
		for MepIvHBYNArkUOdV37shtJ,title in items:
			x3WSXnKyPhjqfHG2UrtQs('video',wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,82,Sj7rMNYRuQPTtkBvpHKeDW3h)
	return
def mzcAeyplZV(url):
	WSQlG8mDhqsNe = url.replace('/movies/','/watch_movies/')
	WSQlG8mDhqsNe = WSQlG8mDhqsNe.replace('/episodes/','/watch_episodes/')
	IAW0sh6So3NpqM = WWrExJZS3Bj4anOAkpv7(kUz8c7OqsxuPFIGfwg,'GET',WSQlG8mDhqsNe,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,'HALACIMA-PLAY-1st')
	cmWl9dOKHPIy41iaXuxrY = IAW0sh6So3NpqM.content
	iipsGz2LKq = AWeJuo2LhZ5xiD8KNSqd9G0rtT74FE(WSQlG8mDhqsNe,'url')
	U7V0BQZPxXqMbyJnRw6f = []
	pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('"servers"(.*?)</ul>',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	if pfRkcVlLmUxo561g0A8qSbO:
		mVYdjvor6i4wZ8 = pfRkcVlLmUxo561g0A8qSbO[0]
		ed5GKJzygXNsS6il2 = ePhmG1jLD6.findall('postID = "(.*?)"',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
		ed5GKJzygXNsS6il2 = ed5GKJzygXNsS6il2[0]
		items = ePhmG1jLD6.findall("getPlayer\('(.*?)'.*?</i>(.*?)</a>",mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
		for XPNkVcWFUr,title in items:
			title = title.replace(ZLwoRpfnCWI7FgEHsz6te39lMVh,qpFY4hAwolV3).strip(mIsDke0oK5x1zSiOWbF9thGcA)
			MepIvHBYNArkUOdV37shtJ = iipsGz2LKq+'/ajax/getPlayer?server='+XPNkVcWFUr+'&postID='+ed5GKJzygXNsS6il2+'&Ajax=1'
			MepIvHBYNArkUOdV37shtJ = MepIvHBYNArkUOdV37shtJ+'?named='+title+'__watch'
			U7V0BQZPxXqMbyJnRw6f.append(MepIvHBYNArkUOdV37shtJ)
	pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('"downs"(.*?)</ul>',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	if pfRkcVlLmUxo561g0A8qSbO:
		mVYdjvor6i4wZ8 = pfRkcVlLmUxo561g0A8qSbO[0]
		items = ePhmG1jLD6.findall('href="(.*?)" title="(.*?)"',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
		for MepIvHBYNArkUOdV37shtJ,name in items:
			MepIvHBYNArkUOdV37shtJ = MepIvHBYNArkUOdV37shtJ+'?named='+name+'__download'
			U7V0BQZPxXqMbyJnRw6f.append(MepIvHBYNArkUOdV37shtJ)
	import inVXFK46ET
	inVXFK46ET.q4qTJvuoQUzM3mZAtegy7IXdnb5wH(U7V0BQZPxXqMbyJnRw6f,Q8Q0IDc6PLZajJAdTntKUmSGXz,'video',url)
	return
def PPqUACSE3VcGLTvw05jHy9JrFNW(search):
	search,LBylNhMdH6OV1qGk0tWiXFg3,showDialogs = LLm3sBXHPcnTDxdE5gt6hz0Wkp(search)
	if search==qpFY4hAwolV3: search = jXgARlWMLVFUBnvmZwI2o5()
	if search==qpFY4hAwolV3: return
	search = search.replace(mIsDke0oK5x1zSiOWbF9thGcA,'-')
	url = ddBxj51bhNtaK23lDyGMVw+'/search/'+search+'.html'
	c8U1BdtxOZS5FH(url)
	return