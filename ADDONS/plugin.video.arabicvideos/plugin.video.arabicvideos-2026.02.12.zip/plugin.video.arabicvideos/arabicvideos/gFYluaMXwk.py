# -*- coding: utf-8 -*-
from pSfaryIjBo import *
Q8Q0IDc6PLZajJAdTntKUmSGXz = 'FASELHD2'
headers = {'User-Agent':qpFY4hAwolV3}
wwSFijdVJn1QgHW = '_FH2_'
ddBxj51bhNtaK23lDyGMVw = i4bFG3rKE6.SITESURLS[Q8Q0IDc6PLZajJAdTntKUmSGXz][vvXoMLlg513]
YEIA19ehBwpNfPVzK = ['FaselHD']
def vTNE2Ck1sGnugJYW8y39aLcSH64U(mode,url,text):
	if   mode==590: MOTjA5H9XFs = nRVAZc4Dp8PSrGU3xBk()
	elif mode==591: MOTjA5H9XFs = c8U1BdtxOZS5FH(url,text)
	elif mode==592: MOTjA5H9XFs = mzcAeyplZV(url)
	elif mode==593: MOTjA5H9XFs = eewkhcztmSDWKrPIX(url,text)
	elif mode==599: MOTjA5H9XFs = PPqUACSE3VcGLTvw05jHy9JrFNW(text)
	else: MOTjA5H9XFs = False
	return MOTjA5H9XFs
def nRVAZc4Dp8PSrGU3xBk():
	iipsGz2LKq = ddBxj51bhNtaK23lDyGMVw
	IAW0sh6So3NpqM = WWrExJZS3Bj4anOAkpv7(kUz8c7OqsxuPFIGfwg,'GET',iipsGz2LKq,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,'FASELHD2-MENU-1st')
	cmWl9dOKHPIy41iaXuxrY = IAW0sh6So3NpqM.content
	x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+'بحث في الموقع',iipsGz2LKq,599,qpFY4hAwolV3,qpFY4hAwolV3,'_REMEMBERRESULTS_')
	x3WSXnKyPhjqfHG2UrtQs('link',xupTj02bvy3O8R+' ===== ===== ===== '+fF4lt9zWYxXLKZVyAco82PgMj,qpFY4hAwolV3,9999)
	items = ePhmG1jLD6.findall('<h3>(.*?)<.*?href="(.*?)"',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	P71nY8vWLi4xBOr9tZVNRQzJUbSG6 = vvXoMLlg513
	for title,MepIvHBYNArkUOdV37shtJ in items:
		MepIvHBYNArkUOdV37shtJ = ddBxj51bhNtaK23lDyGMVw
		title = title.strip(mIsDke0oK5x1zSiOWbF9thGcA)
		if any(value in title for value in YEIA19ehBwpNfPVzK): continue
		x3WSXnKyPhjqfHG2UrtQs('folder',Q8Q0IDc6PLZajJAdTntKUmSGXz+'_SCRIPT_'+wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,591,qpFY4hAwolV3,qpFY4hAwolV3,'featured'+str(P71nY8vWLi4xBOr9tZVNRQzJUbSG6))
		P71nY8vWLi4xBOr9tZVNRQzJUbSG6 += mZi0S72jGoHpLO
	x3WSXnKyPhjqfHG2UrtQs('link',xupTj02bvy3O8R+' ===== ===== ===== '+fF4lt9zWYxXLKZVyAco82PgMj,qpFY4hAwolV3,9999)
	pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('"main-menu"(.*?)</nav>',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	if pfRkcVlLmUxo561g0A8qSbO:
		mVYdjvor6i4wZ8 = pfRkcVlLmUxo561g0A8qSbO[vvXoMLlg513]
		ylaZeqO8cxV = ePhmG1jLD6.findall('<li (.*?)</li>',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
		for HZTvVym7W3M4Nh5CQe in ylaZeqO8cxV:
			items = ePhmG1jLD6.findall('href="(.*?)".*?>(.*?)<',HZTvVym7W3M4Nh5CQe,ePhmG1jLD6.DOTALL)
			for MepIvHBYNArkUOdV37shtJ,title in items:
				if 'http' not in MepIvHBYNArkUOdV37shtJ: MepIvHBYNArkUOdV37shtJ = iipsGz2LKq+MepIvHBYNArkUOdV37shtJ
				x3WSXnKyPhjqfHG2UrtQs('folder',Q8Q0IDc6PLZajJAdTntKUmSGXz+'_SCRIPT_'+wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,591)
	return cmWl9dOKHPIy41iaXuxrY
def c8U1BdtxOZS5FH(url,kJ358BIeXtYvzn=qpFY4hAwolV3):
	IAW0sh6So3NpqM = WWrExJZS3Bj4anOAkpv7(kUz8c7OqsxuPFIGfwg,'GET',url,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,'FASELHD2-TITLES-1st')
	cmWl9dOKHPIy41iaXuxrY = IAW0sh6So3NpqM.content
	items = []
	if 'featured' in kJ358BIeXtYvzn:
		P71nY8vWLi4xBOr9tZVNRQzJUbSG6 = kJ358BIeXtYvzn[-mZi0S72jGoHpLO]
		pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('"boxes--holder"(.*?)</ul>',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
		mVYdjvor6i4wZ8 = pfRkcVlLmUxo561g0A8qSbO[int(P71nY8vWLi4xBOr9tZVNRQzJUbSG6)]
	elif kJ358BIeXtYvzn=='filters':
		pfRkcVlLmUxo561g0A8qSbO = [cmWl9dOKHPIy41iaXuxrY.replace('\\/',ShynO8pN9idCE3).replace('\\"','"')]
		mVYdjvor6i4wZ8 = pfRkcVlLmUxo561g0A8qSbO[vvXoMLlg513]
	else:
		pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('"boxes--holder"(.*?)"pagination"',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
		mVYdjvor6i4wZ8 = pfRkcVlLmUxo561g0A8qSbO[vvXoMLlg513]
	if not items: items = ePhmG1jLD6.findall('href="(.*?)".*?data-image="(.*?)".*?alt="(.*?)"',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
	WGid3I2kFU = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم','مسرحية','حلقة']
	aaCNAJdtsguSRELh2I = []
	for MepIvHBYNArkUOdV37shtJ,Sj7rMNYRuQPTtkBvpHKeDW3h,title in items:
		title = title.strip(mIsDke0oK5x1zSiOWbF9thGcA)
		try: title = title.encode(tB51CjmZGyJX09b8cAizhvu4T).decode(nV3Tip6XsH1rJw79DPOU)
		except: pass
		title = j8PDV0pthfSTidZbsQxNIOmCYKWzH(title)
		if any(value in title.lower() for value in YEIA19ehBwpNfPVzK): continue
		ZDTxRSMbW7PNz = ePhmG1jLD6.findall('(.*?) (الحلقة|حلقة).\d+',title,ePhmG1jLD6.DOTALL)
		if '/movseries/' in MepIvHBYNArkUOdV37shtJ: x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,591,Sj7rMNYRuQPTtkBvpHKeDW3h)
		elif ZDTxRSMbW7PNz:
			title = '_MOD_'+ZDTxRSMbW7PNz[0][0]
			if title not in aaCNAJdtsguSRELh2I:
				x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,593,Sj7rMNYRuQPTtkBvpHKeDW3h)
				aaCNAJdtsguSRELh2I.append(title)
		elif any(value in title for value in WGid3I2kFU): x3WSXnKyPhjqfHG2UrtQs('video',wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,592,Sj7rMNYRuQPTtkBvpHKeDW3h)
		else: x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,593,Sj7rMNYRuQPTtkBvpHKeDW3h)
	if kJ358BIeXtYvzn=='filters':
		ppB9zFEedcVZ4GXuwr0 = ePhmG1jLD6.findall('"more_button_page":(.*?),',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
		if ppB9zFEedcVZ4GXuwr0:
			count = ppB9zFEedcVZ4GXuwr0[0]
			MepIvHBYNArkUOdV37shtJ = url+'/offset/'+count
			x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+'صفحة أخرى',MepIvHBYNArkUOdV37shtJ,591,qpFY4hAwolV3,qpFY4hAwolV3,'filters')
	elif 'featured' not in kJ358BIeXtYvzn:
		pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('class="pagination(.*?)</div>',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
		if pfRkcVlLmUxo561g0A8qSbO:
			mVYdjvor6i4wZ8 = pfRkcVlLmUxo561g0A8qSbO[0]
			items = ePhmG1jLD6.findall('href="(.*?)">(.*?)<',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
			for MepIvHBYNArkUOdV37shtJ,title in items:
				title = j8PDV0pthfSTidZbsQxNIOmCYKWzH(title)
				MepIvHBYNArkUOdV37shtJ = j8PDV0pthfSTidZbsQxNIOmCYKWzH(MepIvHBYNArkUOdV37shtJ)
				if 'http' not in MepIvHBYNArkUOdV37shtJ: MepIvHBYNArkUOdV37shtJ = ddBxj51bhNtaK23lDyGMVw+MepIvHBYNArkUOdV37shtJ
				x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+'صفحة '+title,MepIvHBYNArkUOdV37shtJ,591,qpFY4hAwolV3,qpFY4hAwolV3,'details4')
	return
def eewkhcztmSDWKrPIX(url,data=qpFY4hAwolV3):
	if '/Episodes.php' in url:
		headers = {'Content-Type':'application/x-www-form-urlencoded; charset=UTF-8'}
		IAW0sh6So3NpqM = WWrExJZS3Bj4anOAkpv7(kUz8c7OqsxuPFIGfwg,'POST',url,data,headers,qpFY4hAwolV3,qpFY4hAwolV3,'FASELHD2-SEASONS_EPISODES-1st')
		cmWl9dOKHPIy41iaXuxrY = '"EpisodesList"'+IAW0sh6So3NpqM.content+'</div>'
	else:
		IAW0sh6So3NpqM = WWrExJZS3Bj4anOAkpv7(kUz8c7OqsxuPFIGfwg,'GET',url,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,'FASELHD2-SEASONS_EPISODES-2nd')
		cmWl9dOKHPIy41iaXuxrY = IAW0sh6So3NpqM.content
	BvbuigUeoJLnTaN2qWxQ415AtYMK9I = ePhmG1jLD6.findall('"inner--image"><img src="(.*?)"',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	Sj7rMNYRuQPTtkBvpHKeDW3h = BvbuigUeoJLnTaN2qWxQ415AtYMK9I[vvXoMLlg513] if BvbuigUeoJLnTaN2qWxQ415AtYMK9I else qpFY4hAwolV3
	items = []
	if not data:
		pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('"SeasonsList"(.*?)</ul>',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
		if pfRkcVlLmUxo561g0A8qSbO:
			mVYdjvor6i4wZ8 = pfRkcVlLmUxo561g0A8qSbO[vvXoMLlg513]
			items = ePhmG1jLD6.findall('data-id="(.*?)" data-season="(.*?)".*?">(.*?)<',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
			if len(items)>1:
				for ezh5VObtS4uMRaBx0G9s1ri,MaNXbtkeElTRsiK6c1u,title in items:
					MepIvHBYNArkUOdV37shtJ = ddBxj51bhNtaK23lDyGMVw+'/wp-content/themes/AflamPlus/Inc/Ajax/Single/Episodes.php'
					RZ2SwHp6GQvAy = 'season='+MaNXbtkeElTRsiK6c1u+'&post_id='+ezh5VObtS4uMRaBx0G9s1ri
					x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,593,Sj7rMNYRuQPTtkBvpHKeDW3h,qpFY4hAwolV3,RZ2SwHp6GQvAy)
		data = gBExoceumj4y8bFW9hY2aNMVSr
	if data and len(items)<Zwqio2AIWlD5etFa:
		pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('"EpisodesList"(.*?)</div>',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
		if pfRkcVlLmUxo561g0A8qSbO:
			mVYdjvor6i4wZ8 = pfRkcVlLmUxo561g0A8qSbO[vvXoMLlg513]
			items = ePhmG1jLD6.findall('href="(.*?)">(.*?)<em>(.*?)<',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
			for MepIvHBYNArkUOdV37shtJ,rr1mzIljJHqkx,UdbGw48M6rCHDRmea5qP91nKI in items:
				title = rr1mzIljJHqkx+mIsDke0oK5x1zSiOWbF9thGcA+UdbGw48M6rCHDRmea5qP91nKI
				title = title.strip(mIsDke0oK5x1zSiOWbF9thGcA)
				x3WSXnKyPhjqfHG2UrtQs('video',wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,592,Sj7rMNYRuQPTtkBvpHKeDW3h)
	return
def mzcAeyplZV(url):
	url = url.strip(ShynO8pN9idCE3)+'/watch/'
	tiYp9ZdbFTQMcB4vWkHw6LXIAKrN5m,oXZHbnhjTlFK6x9O,rdkXS7oJ6bD = [],[],[]
	IAW0sh6So3NpqM = WWrExJZS3Bj4anOAkpv7(rGY36xBwT1bLZAngSfcWEIeXdQVNij,'GET',url,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,'FASELHD2-PLAY-1st')
	cmWl9dOKHPIy41iaXuxrY = IAW0sh6So3NpqM.content
	N39rcOfDjte7wUmVqsHK8ioB = ePhmG1jLD6.findall('العمر :.*?<strong">(.*?)</strong>',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	if N39rcOfDjte7wUmVqsHK8ioB and u0E18eO3HnCzr(Q8Q0IDc6PLZajJAdTntKUmSGXz,url,N39rcOfDjte7wUmVqsHK8ioB): return
	MepIvHBYNArkUOdV37shtJ = ePhmG1jLD6.findall('<iframe src="(.*?)"',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	if MepIvHBYNArkUOdV37shtJ:
		MepIvHBYNArkUOdV37shtJ = MepIvHBYNArkUOdV37shtJ[0]
		tiYp9ZdbFTQMcB4vWkHw6LXIAKrN5m.append(MepIvHBYNArkUOdV37shtJ+'?named=__embed')
	pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('"main--contents"(.*?)</ul>',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	if pfRkcVlLmUxo561g0A8qSbO:
		mVYdjvor6i4wZ8 = pfRkcVlLmUxo561g0A8qSbO[0]
		items = ePhmG1jLD6.findall('data-i="(.*?)".*?data-id="(.*?)".*?<span>(.*?)<',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
		for jPKqLz2wnd7SoJ538lxhg,ezh5VObtS4uMRaBx0G9s1ri,title in items:
			title = title.strip(mIsDke0oK5x1zSiOWbF9thGcA)
			MepIvHBYNArkUOdV37shtJ = ddBxj51bhNtaK23lDyGMVw+'/wp-content/themes/AflamPlus/Inc/Ajax/Single/Server.php?id='+ezh5VObtS4uMRaBx0G9s1ri+'&i='+jPKqLz2wnd7SoJ538lxhg
			tiYp9ZdbFTQMcB4vWkHw6LXIAKrN5m.append(MepIvHBYNArkUOdV37shtJ+'?named='+title+'__watch')
	pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('"downloads"(.*?)</div>',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	if pfRkcVlLmUxo561g0A8qSbO:
		mVYdjvor6i4wZ8 = pfRkcVlLmUxo561g0A8qSbO[0]
		items = ePhmG1jLD6.findall('href="(.*?)".*?<span>(.*?)<',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
		for MepIvHBYNArkUOdV37shtJ,name in items:
			tiYp9ZdbFTQMcB4vWkHw6LXIAKrN5m.append(MepIvHBYNArkUOdV37shtJ+'?named='+name+'__download')
	for wonOFZLNYPThyXKbz7v2iUCJx6k in tiYp9ZdbFTQMcB4vWkHw6LXIAKrN5m:
		MepIvHBYNArkUOdV37shtJ,name = wonOFZLNYPThyXKbz7v2iUCJx6k.split('?named')
		if MepIvHBYNArkUOdV37shtJ not in oXZHbnhjTlFK6x9O:
			oXZHbnhjTlFK6x9O.append(MepIvHBYNArkUOdV37shtJ)
			rdkXS7oJ6bD.append(wonOFZLNYPThyXKbz7v2iUCJx6k)
	import inVXFK46ET
	inVXFK46ET.q4qTJvuoQUzM3mZAtegy7IXdnb5wH(rdkXS7oJ6bD,Q8Q0IDc6PLZajJAdTntKUmSGXz,'video',url)
	return
def PPqUACSE3VcGLTvw05jHy9JrFNW(search):
	search,LBylNhMdH6OV1qGk0tWiXFg3,showDialogs = LLm3sBXHPcnTDxdE5gt6hz0Wkp(search)
	if search==qpFY4hAwolV3: search = jXgARlWMLVFUBnvmZwI2o5()
	if search==qpFY4hAwolV3: return
	search = search.replace(mIsDke0oK5x1zSiOWbF9thGcA,'+')
	iipsGz2LKq = ddBxj51bhNtaK23lDyGMVw
	url = iipsGz2LKq+'/?s='+search
	c8U1BdtxOZS5FH(url,'details5')
	return