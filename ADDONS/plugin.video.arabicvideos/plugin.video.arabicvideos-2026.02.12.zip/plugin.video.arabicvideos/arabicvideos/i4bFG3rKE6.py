# -*- coding: utf-8 -*-
import sys as TSRUP0dExYGQg
mgNMJhrjcq1xb = TSRUP0dExYGQg.version_info [0] == 2
lQJvf8UXo2de9gjCatY4yH = 2048
YuTB2OjotvlR = 7
def kk0DKyarxq9eS1zwGLMFQTZN35dj (neqP2if8IOJ50aNKcCBLrXdZk):
	global sWerUpk6nQwT7zY43
	vxdNQUujz7ZFV4rtOSK2 = ord (neqP2if8IOJ50aNKcCBLrXdZk [-1])
	yyshZX35KO7JodYjD9qVib6 = neqP2if8IOJ50aNKcCBLrXdZk [:-1]
	fuKReXJ3HPIAU7c = vxdNQUujz7ZFV4rtOSK2 % len (yyshZX35KO7JodYjD9qVib6)
	EEFQdvXog7LPC4Sie0jDkUKxn6M = yyshZX35KO7JodYjD9qVib6 [:fuKReXJ3HPIAU7c] + yyshZX35KO7JodYjD9qVib6 [fuKReXJ3HPIAU7c:]
	if mgNMJhrjcq1xb:
		Clh5YS0XPue68EgT4Uq17GL = unicode () .join ([unichr (ord (AsGVDZFgmuH06jviYrWXTz) - lQJvf8UXo2de9gjCatY4yH - (XvhDIL4ZpzaPs91WkoGnedCEA2rt + vxdNQUujz7ZFV4rtOSK2) % YuTB2OjotvlR) for XvhDIL4ZpzaPs91WkoGnedCEA2rt, AsGVDZFgmuH06jviYrWXTz in enumerate (EEFQdvXog7LPC4Sie0jDkUKxn6M)])
	else:
		Clh5YS0XPue68EgT4Uq17GL = str () .join ([chr (ord (AsGVDZFgmuH06jviYrWXTz) - lQJvf8UXo2de9gjCatY4yH - (XvhDIL4ZpzaPs91WkoGnedCEA2rt + vxdNQUujz7ZFV4rtOSK2) % YuTB2OjotvlR) for XvhDIL4ZpzaPs91WkoGnedCEA2rt, AsGVDZFgmuH06jviYrWXTz in enumerate (EEFQdvXog7LPC4Sie0jDkUKxn6M)])
	return eval (Clh5YS0XPue68EgT4Uq17GL)
qoBMmfAWpFlK70xw8ZRh4naJ,lljaEqwTVtmKsQcOrbXxS5hgNH,aXqWLoTdVgME=kk0DKyarxq9eS1zwGLMFQTZN35dj,kk0DKyarxq9eS1zwGLMFQTZN35dj,kk0DKyarxq9eS1zwGLMFQTZN35dj
UVa3fJw7k6KM,fWoVd0Bmtkx,tQMjXKCA5dN4xq3beVIzaEoWkFLg=aXqWLoTdVgME,lljaEqwTVtmKsQcOrbXxS5hgNH,qoBMmfAWpFlK70xw8ZRh4naJ
viRJWOC5jsYe84,Ie5s2cBtSfdHjzQ4rA9kYlo6D18,sjtU6GZQg5XC2pH4=tQMjXKCA5dN4xq3beVIzaEoWkFLg,fWoVd0Bmtkx,UVa3fJw7k6KM
LZWMikPEB81KSGyxfJtUsCA,rNdBKI74fAklnoCZ6,BRWqdruz2A0=sjtU6GZQg5XC2pH4,Ie5s2cBtSfdHjzQ4rA9kYlo6D18,viRJWOC5jsYe84
CC1eY6yWZUwf2TkRvnp7EJ0AimjHBX,qqzwE6imYG4c2xojI,N3flV6EJsD5CzS=BRWqdruz2A0,rNdBKI74fAklnoCZ6,LZWMikPEB81KSGyxfJtUsCA
UUDAiytEL76RTmMYsuIz5evXB,IaBhDMJc17302LgSvyxd,ddiCzu6yahj5RtTISMJ48sNnZBU=N3flV6EJsD5CzS,qqzwE6imYG4c2xojI,CC1eY6yWZUwf2TkRvnp7EJ0AimjHBX
dJHDqiKf12TXlIzSLkGUuxg4MBs3A,l1DZAt9XNQjqE7YOdrz,l32dnTEOU1skGKqeBtI9hmo=ddiCzu6yahj5RtTISMJ48sNnZBU,IaBhDMJc17302LgSvyxd,UUDAiytEL76RTmMYsuIz5evXB
zYvEaigKWjoq50pXBLDbGJkFc,iNc3KxwErnQ,V3VlkhgjEF4n1erPXHcC0NOsfwyAJ=l32dnTEOU1skGKqeBtI9hmo,l1DZAt9XNQjqE7YOdrz,dJHDqiKf12TXlIzSLkGUuxg4MBs3A
tR1krDGPpO025fghMT3a7UnYj,c2RKu0xG1eC8MiohyE,RlOvin8YIGC2KZXJPk9m0acrMobUex=V3VlkhgjEF4n1erPXHcC0NOsfwyAJ,iNc3KxwErnQ,zYvEaigKWjoq50pXBLDbGJkFc
YY8UDX3MJhb91AHw7fg,ee86G9ladLHVbh5mikzCo,mmV2nucZ5Lpl6FO1JMPEqGoQKW=RlOvin8YIGC2KZXJPk9m0acrMobUex,c2RKu0xG1eC8MiohyE,tR1krDGPpO025fghMT3a7UnYj
DaFZHsThGmd0zv6e,kYDaz79TFlXoR,DiJ8CMuYH1daWyjehfN0L=mmV2nucZ5Lpl6FO1JMPEqGoQKW,ee86G9ladLHVbh5mikzCo,YY8UDX3MJhb91AHw7fg
from yUpZo6itJT import *
SITESURLS = {
			 iNc3KxwErnQ(u"ࠫࡆࡎࡗࡂࡍࠪದ")		:[DaFZHsThGmd0zv6e(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡡࡴ࠰ࡤ࡬ࡼࡧ࡫ࡵࡸ࠱ࡲࡪࡺࠧಧ")]
			,fWoVd0Bmtkx(u"࠭ࡁࡌࡑࡄࡑࠬನ")		:[viRJWOC5jsYe84(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡣ࡮࠲ࡸࡼ࠯ࡰ࡮ࡧࠫ಩")]
			,mmV2nucZ5Lpl6FO1JMPEqGoQKW(u"ࠨࡃࡎ࡛ࡆࡓࠧಪ")		:[lljaEqwTVtmKsQcOrbXxS5hgNH(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡥࡰ࠴ࡳࡷࠩಫ")]
			,V3VlkhgjEF4n1erPXHcC0NOsfwyAJ(u"ࠪࡅࡐ࡝ࡁࡎࡖࡘࡆࡊ࠭ಬ")	:[LZWMikPEB81KSGyxfJtUsCA(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡧࡳ࠯ࡣ࡮ࡻࡦࡳ࠮ࡵࡷࡥࡩࠬಭ")]
			,kYDaz79TFlXoR(u"ࠬࡇࡌࡎࡃࡄࡖࡊࡌࠧಮ")		:[lljaEqwTVtmKsQcOrbXxS5hgNH(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡢ࡮ࡰࡥࡦࡸࡥࡧ࠰ࡦ࡬ࠬಯ")]
			,l1DZAt9XNQjqE7YOdrz(u"ࠧࡂࡎࡐࡗ࡙ࡈࡁࠨರ")		:[IaBhDMJc17302LgSvyxd(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡺࡻࡼ࠴ࡡ࡭࡯ࡶࡸࡧࡧ࠮ࡵࡸࠪಱ")]
			,UUDAiytEL76RTmMYsuIz5evXB(u"ࠩࡄࡒࡎࡓࡅ࡛ࡋࡇࠫಲ")		:[LZWMikPEB81KSGyxfJtUsCA(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡦࡴࡩ࡮ࡧࡽ࡭ࡩ࠴ࡳࡩࡱࡺࠫಳ")]
			,V3VlkhgjEF4n1erPXHcC0NOsfwyAJ(u"ࠫࡆࡘࡁࡃࡋࡆࡘࡔࡕࡎࡔࠩ಴")	:[rNdBKI74fAklnoCZ6(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡽࡷࡸ࠰ࡤࡶࡦࡨࡩࡤ࠯ࡷࡳࡴࡴࡳ࠯ࡥࡲࡱࠬವ")]
			,fWoVd0Bmtkx(u"࠭ࡁࡓࡃࡅࡗࡊࡋࡄࠨಶ")		:[V3VlkhgjEF4n1erPXHcC0NOsfwyAJ(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡣࡵࡥࡧࡹࡥࡦࡦ࠱ࡲࡪࡺࠧಷ")]
			,viRJWOC5jsYe84(u"ࠨࡃ࡜ࡐࡔࡒࠧಸ")		:[fWoVd0Bmtkx(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡻࡪ࠴ࡡࡺ࡮ࡲࡰ࠳ࡴࡥࡵࠩಹ")]
			,LZWMikPEB81KSGyxfJtUsCA(u"ࠪࡆࡔࡑࡒࡂࠩ಺")		:[aXqWLoTdVgME(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡹࡨࡢࡪ࡬ࡨࡱ࡯ࡶࡦ࠰ࡦࡳࠬ಻")]
			,rNdBKI74fAklnoCZ6(u"ࠬࡈࡒࡔࡖࡈࡎ಼ࠬ")		:[sjtU6GZQg5XC2pH4(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡣࡴࡶࡸ࡮ࡰ࠮ࡤࡣࡰࠫಽ")]
			,ddiCzu6yahj5RtTISMJ48sNnZBU(u"ࠧࡄࡋࡐࡅ࠹࠶࠰ࠨಾ")		:[RlOvin8YIGC2KZXJPk9m0acrMobUex(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡦ࡭ࡲࡧ࠴࠱࠲࠱ࡧࡴࡳࠧಿ")]
			,tQMjXKCA5dN4xq3beVIzaEoWkFLg(u"ࠩࡆࡍࡒࡇ࠴ࡑࠩೀ")		:[sjtU6GZQg5XC2pH4(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡼ࠴ࡣࡪ࡯ࡤ࠸ࡵ࠴ࡣࡰ࡯ࠪು")]
			,qqzwE6imYG4c2xojI(u"ࠫࡈࡏࡍࡂ࠶ࡘࠫೂ")		:[zYvEaigKWjoq50pXBLDbGJkFc(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵࠱ࡤ࡫ࡰࡥ࠹ࡻ࠮ࡤࡱࡰࠫೃ")]
			,ee86G9ladLHVbh5mikzCo(u"࠭ࡃࡊࡏࡄࡅࡇࡊࡏࠨೄ")		:[qoBMmfAWpFlK70xw8ZRh4naJ(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡥࡰ࠲ࡨ࡯࡭ࡢ࠵ࡥࡨࡴ࠴ࡣࡰ࡯ࠪ೅")]
			,Ie5s2cBtSfdHjzQ4rA9kYlo6D18(u"ࠨࡅࡌࡑࡆࡉࡌࡖࡄࠪೆ")		:[N3flV6EJsD5CzS(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡧ࡮࡯࡭ࡢࡥ࡯ࡹࡧ࠴ࡣ࡭ࡷࡥࠫೇ")]
			,aXqWLoTdVgME(u"ࠪࡇࡎࡓࡁࡄࡎࡘࡆ࡜ࡕࡒࡌࠩೈ")	:[Ie5s2cBtSfdHjzQ4rA9kYlo6D18(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡺࡶࡷ࠰ࡦ࡭ࡲࡧࡣ࡭ࡷࡥ࠲ࡸ࡮࡯ࡱࠩ೉")]
			,LZWMikPEB81KSGyxfJtUsCA(u"ࠬࡉࡉࡎࡃࡉࡅࡓ࡙ࠧೊ")		:[fWoVd0Bmtkx(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡸࡹࡺ࠲ࡨ࡯࡭ࡢࡨࡤࡲࡸ࠴ࡣࡰࠩೋ")]
			,qqzwE6imYG4c2xojI(u"ࠧࡄࡋࡐࡅࡋࡘࡅࡆࠩೌ")		:[CC1eY6yWZUwf2TkRvnp7EJ0AimjHBX(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡦ࡭ࡲࡧ࡬ࡪࡩ࡫ࡸ࠳ࡵ࡮࡭࡫ࡱࡩ್ࠬ")]
			,ddiCzu6yahj5RtTISMJ48sNnZBU(u"ࠩࡆࡍࡒࡇࡌࡊࡉࡋࡘࠬ೎")	:[qoBMmfAWpFlK70xw8ZRh4naJ(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡲࡿ࠭ࡤ࡫ࡰࡥ࠳ࡴࡥࡵࠩ೏")]
			,IaBhDMJc17302LgSvyxd(u"ࠫࡈࡏࡍࡂࡐࡒ࡛ࠬ೐")		:[c2RKu0xG1eC8MiohyE(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡣࡪ࡯ࡤࡲࡴࡽ࠮ࡤࡥࠪ೑")]
			,DiJ8CMuYH1daWyjehfN0L(u"࠭ࡃࡊࡏࡄ࡛ࡇࡇࡓࠨ೒")		:[qoBMmfAWpFlK70xw8ZRh4naJ(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰࡯ࡼࡧ࡮ࡳࡡ࠯ࡥࡦࠫ೓")]
			,c2RKu0xG1eC8MiohyE(u"ࠨࡆࡄࡍࡑ࡟ࡍࡐࡖࡌࡓࡓ࠭೔")	:[N3flV6EJsD5CzS(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡻࡼࡽ࠮ࡥࡣ࡬ࡰࡾࡳ࡯ࡵ࡫ࡲࡲ࠳ࡩ࡯࡮ࠩೕ"),qqzwE6imYG4c2xojI(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳࡬ࡸࡡࡱࡪࡴࡰ࠳ࡧࡰࡪ࠰ࡧࡥ࡮ࡲࡹ࡮ࡱࡷ࡭ࡴࡴ࠮ࡤࡱࡰࠫೖ"),ee86G9ladLHVbh5mikzCo(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡹࡥࡢࡴࡦ࡬࠳ࡪࡡࡪ࡮ࡼࡱࡴࡺࡩࡰࡰ࠱ࡧࡴࡳࠧ೗")]
			,c2RKu0xG1eC8MiohyE(u"ࠬࡊࡒࡂࡏࡄࡇࡆࡌࡅࠨ೘")	:[CC1eY6yWZUwf2TkRvnp7EJ0AimjHBX(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡸ࠴࠸࠲ࡩࡸࡡ࡮ࡣࡦࡥ࡫࡫࠭ࡵࡸ࠱ࡧࡴࡳࠧ೙")]
			,aXqWLoTdVgME(u"ࠧࡅࡔࡄࡑࡆ࡙࠷ࠨ೚")		:[l32dnTEOU1skGKqeBtI9hmo(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡧࡶࡦࡳࡡࡴ࠹࠱ࡲࡪࡺࠧ೛")]
			,DaFZHsThGmd0zv6e(u"ࠩࡈࡋ࡞ࡈࡅࡔࡖ࠴ࠫ೜")		:[RlOvin8YIGC2KZXJPk9m0acrMobUex(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡪ࡭ࡹࡣࡧࡶࡸ࠳࡬ࡵ࡯ࠩೝ")]
			,IaBhDMJc17302LgSvyxd(u"ࠫࡊࡍ࡙ࡃࡇࡖࡘ࠷࠭ೞ")		:[tQMjXKCA5dN4xq3beVIzaEoWkFLg(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡥࡨࡻࡥࡩࡸࡺ࠮࡯ࡧࡺࡷࠬ೟")]
			,IaBhDMJc17302LgSvyxd(u"࠭ࡅࡈ࡛ࡅࡉࡘ࡚࠳ࠨೠ")		:[BRWqdruz2A0(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰࡫ࡨ࡫ࡾࡨࡥࡴࡶ࠱ࡦ࡮ࡪࠧೡ")]
			,l1DZAt9XNQjqE7YOdrz(u"ࠨࡇࡊ࡝ࡇࡋࡓࡕ࠶ࠪೢ")		:[IaBhDMJc17302LgSvyxd(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡩ࡬ࡿ࠭ࡣࡧࡶࡸ࠳ࡴࡥࡵࠩೣ")]
			,qoBMmfAWpFlK70xw8ZRh4naJ(u"ࠪࡉࡌ࡟ࡄࡆࡃࡇࠫ೤")		:[iNc3KxwErnQ(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴࡫ࡧࡺࡦࡨࡥࡩ࠴࡬ࡪࡸࡨࠫ೥")]
			,Ie5s2cBtSfdHjzQ4rA9kYlo6D18(u"ࠬࡋࡌࡄࡋࡑࡉࡒࡇࠧ೦")		:[ddiCzu6yahj5RtTISMJ48sNnZBU(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡦ࡮ࡦ࡭ࡳ࡫࡭ࡢ࠰ࡦࡳࡲ࠭೧")]
			,dJHDqiKf12TXlIzSLkGUuxg4MBs3A(u"ࠧࡆࡎࡌࡊ࡛ࡏࡄࡆࡑࠪ೨")	:[tQMjXKCA5dN4xq3beVIzaEoWkFLg(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡶ࡬ࡦ࡮ࡩࡥ࠰ࡨࡰ࡮࡬࠮࡯ࡧࡺࡷࠬ೩")]
			,IaBhDMJc17302LgSvyxd(u"ࠩࡉࡅࡇࡘࡁࡌࡃࠪ೪")		:[UVa3fJw7k6KM(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳࡫ࡧࡢࡳ࡭ࡤ࠲ࡨࡵ࡭ࠨ೫")]
			,dJHDqiKf12TXlIzSLkGUuxg4MBs3A(u"ࠫࡋࡇࡊࡆࡔࡖࡌࡔ࡝ࠧ೬")	:[dJHDqiKf12TXlIzSLkGUuxg4MBs3A(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡦࡢ࡬ࡨࡶ࠳ࡹࡨࡰࡹࠪ೭")]
			,DiJ8CMuYH1daWyjehfN0L(u"࠭ࡆࡂࡔࡈࡗࡐࡕࠧ೮")		:[viRJWOC5jsYe84(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡸ࡬ࡴ࠳࡬ࡡࡳࡧࡶ࡯ࡴ࠴࡮ࡦࡶࠪ೯")]
			,RlOvin8YIGC2KZXJPk9m0acrMobUex(u"ࠨࡈࡄࡗࡊࡒࡈࡅ࠴ࠪ೰")		:[mmV2nucZ5Lpl6FO1JMPEqGoQKW(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡥࡸࡲࡡ࠯ࡨࡤࡷࡪࡲࡨࡥ࠰ࡦࡰࡴࡻࡤࠨೱ")]
			,l32dnTEOU1skGKqeBtI9hmo(u"ࠪࡊࡔ࡙ࡔࡂࠩೲ")		:[RlOvin8YIGC2KZXJPk9m0acrMobUex(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴࡬࡯ࡴࡶࡤ࠱ࡹࡼ࠮ࡸࡧࡥࡷ࡮ࡺࡥࠨೳ")]
			,iNc3KxwErnQ(u"ࠬࡌࡕࡏࡑࡑࡘ࡛࠭೴")		:[dJHDqiKf12TXlIzSLkGUuxg4MBs3A(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡨ࠰ࡤࡰࡲ࡫ࡳࡩ࡭ࡤ࡬࠳ࡴࡥࡵࠩ೵")]
			,zYvEaigKWjoq50pXBLDbGJkFc(u"ࠧࡇࡗࡖࡌࡆࡘࡔࡗࠩ೶")		:[V3VlkhgjEF4n1erPXHcC0NOsfwyAJ(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡥ࠲࡫ࡻࡳࡩࡣࡵ࠱ࡹࡼ࠮ࡤࡱࡰࠫ೷")]
			,l32dnTEOU1skGKqeBtI9hmo(u"ࠩࡉ࡙ࡘࡎࡁࡓࡘࡌࡈࡊࡕࠧ೸")	:[sjtU6GZQg5XC2pH4(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡸ࠴ࡦࡶࡵ࡫ࡥࡷ࠴ࡶࡪࡦࡨࡳࠬ೹")]
			,aXqWLoTdVgME(u"ࠫࡍࡇࡌࡂࡅࡌࡑࡆ࠭೺")		:[iNc3KxwErnQ(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡨࡢ࡮ࡤࡧ࡮ࡳࡡ࠯࡯ࡨࡨ࡮ࡧࠧ೻")]
			,ee86G9ladLHVbh5mikzCo(u"࠭ࡉࡇࡋࡏࡑࠬ೼")		:[V3VlkhgjEF4n1erPXHcC0NOsfwyAJ(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡣࡵ࠲࡮࡬ࡩ࡭࡯ࡷࡺ࠳࡯ࡲࠨ೽"),N3flV6EJsD5CzS(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡨࡲ࠳࡯ࡦࡪ࡮ࡰࡸࡻ࠴ࡩࡳࠩ೾"),CC1eY6yWZUwf2TkRvnp7EJ0AimjHBX(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡪࡦ࠴ࡩࡧ࡫࡯ࡱࡹࡼ࠮ࡪࡴࠪ೿"),fWoVd0Bmtkx(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳࡫ࡧ࠲࠯࡫ࡩ࡭ࡱࡳࡴࡷ࠰࡬ࡶࠬഀ"),lljaEqwTVtmKsQcOrbXxS5hgNH(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࠾࠹࠮࠲࠻࠳࠲࠷࠺࠮࠲࠴࠵ࠫഁ")]
			,RlOvin8YIGC2KZXJPk9m0acrMobUex(u"ࠬࡑࡁࡓࡄࡄࡐࡆ࡚ࡖࠨം")	:[ee86G9ladLHVbh5mikzCo(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯࡬ࡣࡵࡦࡦࡲࡡ࠮ࡶࡹ࠲࡮ࡷࠧഃ")]
			,Ie5s2cBtSfdHjzQ4rA9kYlo6D18(u"ࠧࡌࡃࡗࡏࡔ࡚ࡔࡗࠩഄ")		:[sjtU6GZQg5XC2pH4(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱࡮࡭ࡹࡱ࡯ࡵ࠰ࡦࡥࡲ࠭അ")]
			,LZWMikPEB81KSGyxfJtUsCA(u"ࠩࡎࡍࡗࡓࡁࡍࡍࠪആ")		:[lljaEqwTVtmKsQcOrbXxS5hgNH(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡰ࡯ࡲ࡮ࡣ࡯࡯࠳ࡵࡲࡨࠩഇ")]
			,BRWqdruz2A0(u"ࠫࡑࡇࡒࡐ࡜ࡄࠫഈ")		:[viRJWOC5jsYe84(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵࡬ࡢࡴࡲࡾࡦ࠴ࡩ࡯࡭ࠪഉ")]
			,CC1eY6yWZUwf2TkRvnp7EJ0AimjHBX(u"࠭ࡌࡐࡆ࡜ࡒࡊ࡚ࠧഊ")		:[N3flV6EJsD5CzS(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰࡮ࡲࡨࡾࡴࡥࡵ࠰ࡩࡹࡳ࠭ഋ")]
			,Ie5s2cBtSfdHjzQ4rA9kYlo6D18(u"ࠨࡏࡄࡗࡆ࡜ࡉࡅࡇࡒࠫഌ")	:[l32dnTEOU1skGKqeBtI9hmo(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡩࡳ࠴࡭ࡢࡵࡤ࠲ࡳ࡫ࡷࡴࠩ഍")]
			,rNdBKI74fAklnoCZ6(u"ࠪࡔࡆࡔࡅࡕࠩഎ")		:[N3flV6EJsD5CzS(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡼࡽࡷ࠯ࡲࡤࡲࡪࡺ࠮ࡤࡱ࠱࡭ࡱ࠭ഏ")]
			,DaFZHsThGmd0zv6e(u"ࠬࡘࡅࡍࡇࡄࡗࡊ࡙ࠧഐ")		:[UUDAiytEL76RTmMYsuIz5evXB(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯࡬ࡱࡧ࡭ࡪࡳࡡࡥ࠰ࡶࡹࡷ࡭ࡥ࠯ࡵ࡫࠳ࡰࡵࡤࡪ࠱ࡨࡱࡦࡪ࡟ࡢࡴࡤࡦ࡮ࡩࡶࡪࡦࡨࡳࡸ࠵࡯࡭ࡦ࠲࡭ࡳࡪࡥࡹ࠰࡫ࡸࡲࡲࠧ഑")]
			,l32dnTEOU1skGKqeBtI9hmo(u"ࠧࡔࡇࡕࡍࡊ࡙ࡔࡊࡏࡈࠫഒ")	:[kYDaz79TFlXoR(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡥࡥ࠳ࡹࡥࡳ࡫ࡨࡷࡹ࡯࡭ࡦ࠰ࡦࡥࡲ࠭ഓ")]
			,BRWqdruz2A0(u"ࠩࡖࡌࡆࡎࡉࡅ࠶ࡘࠫഔ")		:[DiJ8CMuYH1daWyjehfN0L(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡸ࡮ࡡࡢࡪࡨࡨ࠹ࡻ࠮࡯ࡧࡷࠫക")]
			,iNc3KxwErnQ(u"ࠫࡘࡎࡁࡉࡋࡇ࠸࡚࠸ࠧഖ")	:[iNc3KxwErnQ(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡳࡩࡣ࡫࡭ࡩ࠺ࡵ࠯ࡨࡲࡶࡺࡳࠧഗ")]
			,mmV2nucZ5Lpl6FO1JMPEqGoQKW(u"࠭ࡓࡉࡃࡋࡍࡉࡔࡅࡘࡕࠪഘ")	:[UUDAiytEL76RTmMYsuIz5evXB(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡧ࠱ࡷ࡭࠺ࡵ࠯ࡰࡨࡻࡸ࠭ങ")]
			,ddiCzu6yahj5RtTISMJ48sNnZBU(u"ࠨࡕࡋࡓࡋࡎࡁࠨച")		:[dJHDqiKf12TXlIzSLkGUuxg4MBs3A(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡷ࡭ࡵࡦࡩࡣ࠱ࡸࡻ࠭ഛ")]
			,ddiCzu6yahj5RtTISMJ48sNnZBU(u"ࠪࡗࡍࡕࡏࡇࡏࡄ࡜ࠬജ")		:[DiJ8CMuYH1daWyjehfN0L(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡹࡨࡰࡱࡩࡱࡦࡾ࠮ࡤࡱࡰࠫഝ"),V3VlkhgjEF4n1erPXHcC0NOsfwyAJ(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡳࡵࡣࡷ࡭ࡨ࠴ࡳࡩࡱࡲࡪࡲࡧࡸ࠯ࡥࡲࡱࠬഞ"),N3flV6EJsD5CzS(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡴࡪࡲࡳ࡫ࡳࡡࡹ࠰ࡤࡾࡺࡸࡥࡦࡦࡪࡩ࠳ࡴࡥࡵࠩട")]
			,Ie5s2cBtSfdHjzQ4rA9kYlo6D18(u"ࠧࡔࡊࡒࡓࡋࡔࡅࡕࠩഠ")		:[viRJWOC5jsYe84(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡤࡷ࠳ࡹࡨࡰࡱࡩࡲࡪࡺ࠮ࡰࡰ࡯࡭ࡳ࡫ࠧഡ")]
			,N3flV6EJsD5CzS(u"ࠩࡗࡍࡐࡇࡁࡕࠩഢ")		:[fWoVd0Bmtkx(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡹ࡯࡫ࡢࡣࡷ࠲ࡳ࡫ࡴࠨണ")]
			,rNdBKI74fAklnoCZ6(u"࡙ࠫ࡜ࡆࡖࡐࠪത")		:[l32dnTEOU1skGKqeBtI9hmo(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡳ࠯ࡶࡹࡪࡺࡴ࠮࡮ࡧࠪഥ")]
			,kYDaz79TFlXoR(u"࠭ࡖࡂࡔࡅࡓࡓ࠭ദ")		:[fWoVd0Bmtkx(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰࡯࠱ࡺࡦࡸࡢࡰࡰ࠱ࡧࡦࡳࠧധ")]
			,DiJ8CMuYH1daWyjehfN0L(u"ࠨࡘࡌࡈࡊࡕࡎࡔࡃࡈࡑࠬന")	:[c2RKu0xG1eC8MiohyE(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡺ࡮ࡪࡥࡰ࠰ࡱࡷࡦ࡫࡭࠯ࡰࡨࡸࠬഩ")]
			,fWoVd0Bmtkx(u"࡛ࠪࡊࡉࡉࡎࡃ࠴ࠫപ")		:[aXqWLoTdVgME(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡽࡥࡤ࡫ࡰࡥ࠳ࡪࡩࡳࡧࡦࡸࠬഫ")]
			,c2RKu0xG1eC8MiohyE(u"ࠬ࡝ࡅࡄࡋࡐࡅ࠷࠭ബ")		:[DaFZHsThGmd0zv6e(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡸࡧࡦ࡭ࡲࡧ࠮ࡢࡥࠪഭ")]
			,tR1krDGPpO025fghMT3a7UnYj(u"࡚ࠧࡃࡔࡓ࡙࠭മ")		:[UUDAiytEL76RTmMYsuIz5evXB(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡼ࠲ࡾࡧࡱࡰࡶ࠱ࡸࡻ࠭യ")]
			,YY8UDX3MJhb91AHw7fg(u"ࠩ࡜ࡓ࡚࡚ࡕࡃࡇࠪര")		:[RlOvin8YIGC2KZXJPk9m0acrMobUex(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡼࡽࡷ࠯ࡻࡲࡹࡹࡻࡢࡦ࠰ࡦࡳࡲ࠭റ")]
			,YY8UDX3MJhb91AHw7fg(u"ࠫ࡞࡚ࡂࡠࡅࡋࡅࡓࡔࡅࡍࡕࠪല")	:[c2RKu0xG1eC8MiohyE(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡷࡸࡹ࠱ࡽࡴࡻࡴࡶࡤࡨ࠲ࡨࡵ࡭ࠨള")]
			,UUDAiytEL76RTmMYsuIz5evXB(u"࠭ࡉࡑࡖ࡙ࠫഴ")			:[qpFY4hAwolV3]
			,mmV2nucZ5Lpl6FO1JMPEqGoQKW(u"ࠧࡎ࠵ࡘࠫവ")			:[qpFY4hAwolV3]
			,qoBMmfAWpFlK70xw8ZRh4naJ(u"ࠨࡔࡈࡔࡔ࡙ࠧശ")		:[aXqWLoTdVgME(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲࡯ࡴࡪࡩࡦ࡯ࡤࡨ࠳ࡴࡥࡵ࡮࡬ࡪࡾ࠴ࡡࡱࡲ࠲ࡏࡔࡊࡉࡓࡇࡓࡓ࠴ࡇࡄࡅࡑࡑࡗ࠴ࡧࡤࡥࡱࡱࡷ࠳ࡾ࡭࡭ࠩഷ"),qoBMmfAWpFlK70xw8ZRh4naJ(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡰࡵࡤࡪࡧࡰࡥࡩ࠴࡮ࡦࡶ࡯࡭࡫ࡿ࠮ࡢࡲࡳ࠳ࡐࡕࡄࡊࡔࡈࡔࡔ࠵ࡁࡅࡆࡒࡒࡘ࠷࠸࠰ࡣࡧࡨࡴࡴࡳ࠲࠺࠱ࡼࡲࡲࠧസ"),YY8UDX3MJhb91AHw7fg(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡱ࡯ࡥ࡫ࡨࡱࡦࡪ࠮࡯ࡧࡷࡰ࡮࡬ࡹ࠯ࡣࡳࡴ࠴ࡑࡏࡅࡋࡕࡉࡕࡕ࠯ࡂࡆࡇࡓࡓ࡙࠱࠺࠱ࡤࡨࡩࡵ࡮ࡴ࠳࠼࠲ࡽࡳ࡬ࠨഹ")]
			,ee86G9ladLHVbh5mikzCo(u"ࠬࡘࡅࡑࡑࡖࡣࡇࡑࡐ࠲ࠩഺ")	:[CC1eY6yWZUwf2TkRvnp7EJ0AimjHBX(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡨ࡫ࡷ࡬ࡺࡨ࠮ࡤࡱࡰ࠳ࡪࡳࡡࡥ࡯ࡤ࡬ࡩ࡯࠯ࡌࡑࡇࡍ࠴ࡸࡡࡸ࠱ࡵࡩ࡫ࡹ࠯ࡩࡧࡤࡨࡸ࠵࡭ࡢࡵࡷࡩࡷ࠵ࡁࡅࡆࡒࡒࡘ࠵ࡡࡥࡦࡲࡲࡸ࠴ࡸ࡮࡮഻ࠪ"),CC1eY6yWZUwf2TkRvnp7EJ0AimjHBX(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡩ࡬ࡸ࡭ࡻࡢ࠯ࡥࡲࡱ࠴࡫࡭ࡢࡦࡰࡥ࡭ࡪࡩ࠰ࡍࡒࡈࡎ࠵ࡲࡢࡹ࠲ࡶࡪ࡬ࡳ࠰ࡪࡨࡥࡩࡹ࠯࡮ࡣࡶࡸࡪࡸ࠯ࡂࡆࡇࡓࡓ࡙࠱࠹࠱ࡤࡨࡩࡵ࡮ࡴ࠳࠻࠲ࡽࡳ࡬ࠨ഼"),zYvEaigKWjoq50pXBLDbGJkFc(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡪ࡭ࡹ࡮ࡵࡣ࠰ࡦࡳࡲ࠵ࡥ࡮ࡣࡧࡱࡦ࡮ࡤࡪ࠱ࡎࡓࡉࡏ࠯ࡳࡣࡺ࠳ࡷ࡫ࡦࡴ࠱࡫ࡩࡦࡪࡳ࠰࡯ࡤࡷࡹ࡫ࡲ࠰ࡃࡇࡈࡔࡔࡓ࠲࠻࠲ࡥࡩࡪ࡯࡯ࡵ࠴࠽࠳ࡾ࡭࡭ࠩഽ")]
			,DaFZHsThGmd0zv6e(u"ࠩࡕࡉࡕࡕࡓࡠࡄࡎࡔ࠷࠭ാ")	:[rNdBKI74fAklnoCZ6(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࡯ࡴࡪࡩࡳࡧࡳࡳ࠳ࡻ࡫࠯ࡶࡲ࠳ࡆࡊࡄࡐࡐࡖ࠳ࡦࡪࡤࡰࡰࡶ࠲ࡽࡳ࡬ࠨി"),DiJ8CMuYH1daWyjehfN0L(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡰࡵࡤࡪࡴࡨࡴࡴ࠴ࡵ࡬࠰ࡷࡳ࠴ࡇࡄࡅࡑࡑࡗ࠶࠾࠯ࡢࡦࡧࡳࡳࡹ࠱࠹࠰ࡻࡱࡱ࠭ീ"),DaFZHsThGmd0zv6e(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡱ࡯ࡥ࡫ࡵࡩࡵࡵ࠮ࡶ࡭࠱ࡸࡴ࠵ࡁࡅࡆࡒࡒࡘ࠷࠹࠰ࡣࡧࡨࡴࡴࡳ࠲࠻࠱ࡼࡲࡲࠧു")]
			,mmV2nucZ5Lpl6FO1JMPEqGoQKW(u"࠭ࡒࡆࡒࡒࡗࡤࡈࡋࡑ࠵ࠪൂ")	:[V3VlkhgjEF4n1erPXHcC0NOsfwyAJ(u"ࠧࡩࡶࡷࡴ࠿࠵࠯࡬ࡱࡧ࡭ࡷ࡫ࡰࡰ࠰ࡰࡳࡴࡵ࠮ࡤࡱࡰ࠳ࡆࡊࡄࡐࡐࡖ࠳ࡦࡪࡤࡰࡰࡶ࠲ࡽࡳ࡬ࠨൃ"),mmV2nucZ5Lpl6FO1JMPEqGoQKW(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࡭ࡲࡨ࡮ࡸࡥࡱࡱ࠱ࡱࡴࡵ࡯࠯ࡥࡲࡱ࠴ࡇࡄࡅࡑࡑࡗ࠶࠾࠯ࡢࡦࡧࡳࡳࡹ࠱࠹࠰ࡻࡱࡱ࠭ൄ"),CC1eY6yWZUwf2TkRvnp7EJ0AimjHBX(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࡮ࡳࡩ࡯ࡲࡦࡲࡲ࠲ࡲࡵ࡯ࡰ࠰ࡦࡳࡲ࠵ࡁࡅࡆࡒࡒࡘ࠷࠹࠰ࡣࡧࡨࡴࡴࡳ࠲࠻࠱ࡼࡲࡲࠧ൅")]
			,IaBhDMJc17302LgSvyxd(u"ࠪࡏࡔࡊࡉࡠࡕࡒ࡙ࡗࡉࡅࡔࠩെ")	:[N3flV6EJsD5CzS(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡰࡵࡤࡪࡧࡰࡥࡩ࠴ࡳࡶࡴࡪࡩ࠳ࡹࡨ࠰࡭ࡲࡨ࡮࠭േ"),aXqWLoTdVgME(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡱ࡯ࡥ࡫ࡨࡱࡦࡪ࠮ࡷࡧࡵࡧࡪࡲ࠮ࡢࡲࡳ࠳ࡰࡵࡤࡪࠩൈ"),LZWMikPEB81KSGyxfJtUsCA(u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡥ࡮ࡣࡧࡱࡦ࡮ࡤࡪ࠰ࡳࡽࡹ࡮࡯࡯ࡣࡱࡽࡼ࡮ࡥࡳࡧ࠱ࡧࡴࡳ࠯࡬ࡱࡧ࡭ࠬ൉")]
			,l1DZAt9XNQjqE7YOdrz(u"ࠧࡇࡋࡏࡉࡘࡥࡓࡐࡗࡕࡇࡊ࡙ࠧൊ"):[ee86G9ladLHVbh5mikzCo(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࡭ࡲࡨ࡮࡫࡭ࡢࡦ࠱ࡲࡪࡺ࡬ࡪࡨࡼ࠲ࡦࡶࡰࠨോ")]
			,BRWqdruz2A0(u"ࠩࡎࡓࡉࡏࡅࡎࡃࡇࡣࡆࡖࡐࠨൌ")	:[DiJ8CMuYH1daWyjehfN0L(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡸ࡮ࡴࡹ࠯ࡥࡦ࠳ࡰࡵࡤࡪࡧࡰࡥࡩ്࠭"),sjtU6GZQg5XC2pH4(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡦࡸࡡࡣ࡫ࡦࡺ࡮ࡪࡥࡰࡵ࠵࠴࠶࠾࠮ࡧࡹࡶ࠲ࡸࡺ࡯ࡳࡧࠪൎ")]
			}
if mZi0S72jGoHpLO:
	SITESURLS[CC1eY6yWZUwf2TkRvnp7EJ0AimjHBX(u"ࠬࡖ࡙ࡕࡊࡒࡒࠬ൏")]      = [N3flV6EJsD5CzS(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯࡬ࡱࡧ࡭ࡪࡳࡡࡥ࠰ࡹࡩࡷࡩࡥ࡭࠰ࡤࡴࡵ࠵࡬ࡪࡵࡷࡴࡱࡧࡹࠨ൐"),LZWMikPEB81KSGyxfJtUsCA(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰࡭ࡲࡨ࡮࡫࡭ࡢࡦ࠱ࡺࡪࡸࡣࡦ࡮࠱ࡥࡵࡶ࠯ࡶࡵࡤ࡫ࡪࡸࡥࡱࡱࡵࡸࠬ൑"),YY8UDX3MJhb91AHw7fg(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱࡮ࡳࡩ࡯ࡥ࡮ࡣࡧ࠲ࡻ࡫ࡲࡤࡧ࡯࠲ࡦࡶࡰ࠰ࡵࡨࡲࡩ࡫࡭ࡢ࡫࡯ࠫ൒"),qoBMmfAWpFlK70xw8ZRh4naJ(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲࡯ࡴࡪࡩࡦ࡯ࡤࡨ࠳ࡼࡥࡳࡥࡨࡰ࠳ࡧࡰࡱ࠱ࡪࡩࡹࡳࡥࡴࡵࡤ࡫ࡪࡹࠧ൓"),l1DZAt9XNQjqE7YOdrz(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡰࡵࡤࡪࡧࡰࡥࡩ࠴ࡶࡦࡴࡦࡩࡱ࠴ࡡࡱࡲ࠲࡫ࡪࡺࡩࡴ࡮ࡤࡱ࡮ࡩࠧൔ"),zYvEaigKWjoq50pXBLDbGJkFc(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡱ࡯ࡥ࡫ࡨࡱࡦࡪ࠮ࡷࡧࡵࡧࡪࡲ࠮ࡢࡲࡳ࠳࡬࡫ࡴࡲࡷࡨࡷࡹ࡯࡯࡯ࡵࠪൕ"),l1DZAt9XNQjqE7YOdrz(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵࡫ࡰࡦ࡬ࡩࡲࡧࡤ࠯ࡸࡨࡶࡨ࡫࡬࠯ࡣࡳࡴ࠴࡭ࡥࡵ࡭ࡱࡳࡼࡴࡥࡳࡴࡲࡶࡸ࠭ൖ"),DaFZHsThGmd0zv6e(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯࡬ࡱࡧ࡭ࡪࡳࡡࡥ࠰ࡹࡩࡷࡩࡥ࡭࠰ࡤࡴࡵ࠵ࡣࡢࡲࡷࡧ࡭ࡧࠧൗ"),mmV2nucZ5Lpl6FO1JMPEqGoQKW(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰࡭ࡲࡨ࡮࡫࡭ࡢࡦ࠱ࡺࡪࡸࡣࡦ࡮࠱ࡥࡵࡶ࠯ࡵࡧࡶࡸ࡮ࡴࡧࠨ൘"),RlOvin8YIGC2KZXJPk9m0acrMobUex(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱࡮ࡳࡩ࡯ࡥ࡮ࡣࡧ࠲ࡻ࡫ࡲࡤࡧ࡯࠲ࡦࡶࡰ࠰ࡩࡨࡸࡪࡾࡴࡳࡣࡳࡽࡹ࡮࡯࡯ࡥࡲࡨࡪ࠭൙"),tQMjXKCA5dN4xq3beVIzaEoWkFLg(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲࡯ࡴࡪࡩࡦ࡯ࡤࡨ࠳ࡼࡥࡳࡥࡨࡰ࠳ࡧࡰࡱ࠱ࡨࡼࡪࡩࡵࡵࡧ࡭ࡷࠬ൚"),BRWqdruz2A0(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡰࡵࡤࡪࡧࡰࡥࡩ࠴ࡶࡦࡴࡦࡩࡱ࠴ࡡࡱࡲ࠲ࡻࡪࡨࡣࡢࡥ࡫ࡩࠬ൛")]
	SITESURLS[IaBhDMJc17302LgSvyxd(u"ࠫࡕ࡟ࡔࡉࡑࡑࡣࡇࡑࡐ࠲ࠩ൜")] = [YY8UDX3MJhb91AHw7fg(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡥ࡮ࡣࡧࡱࡦ࡮ࡤࡪ࠰ࡳࡽࡹ࡮࡯࡯ࡣࡱࡽࡼ࡮ࡥࡳࡧ࠱ࡧࡴࡳ࠯࡭࡫ࡶࡸࡵࡲࡡࡺࠩ൝"),iNc3KxwErnQ(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡦ࡯ࡤࡨࡲࡧࡨࡥ࡫࠱ࡴࡾࡺࡨࡰࡰࡤࡲࡾࡽࡨࡦࡴࡨ࠲ࡨࡵ࡭࠰ࡷࡶࡥ࡬࡫ࡲࡦࡲࡲࡶࡹ࠭൞"),UUDAiytEL76RTmMYsuIz5evXB(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡧࡰࡥࡩࡳࡡࡩࡦ࡬࠲ࡵࡿࡴࡩࡱࡱࡥࡳࡿࡷࡩࡧࡵࡩ࠳ࡩ࡯࡮࠱ࡶࡩࡳࡪࡥ࡮ࡣ࡬ࡰࠬൟ"),BRWqdruz2A0(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡨࡱࡦࡪ࡭ࡢࡪࡧ࡭࠳ࡶࡹࡵࡪࡲࡲࡦࡴࡹࡸࡪࡨࡶࡪ࠴ࡣࡰ࡯࠲࡫ࡪࡺ࡭ࡦࡵࡶࡥ࡬࡫ࡳࠨൠ"),tR1krDGPpO025fghMT3a7UnYj(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡩࡲࡧࡤ࡮ࡣ࡫ࡨ࡮࠴ࡰࡺࡶ࡫ࡳࡳࡧ࡮ࡺࡹ࡫ࡩࡷ࡫࠮ࡤࡱࡰ࠳࡬࡫ࡴࡪࡵ࡯ࡥࡲ࡯ࡣࠨൡ"),l32dnTEOU1skGKqeBtI9hmo(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡪࡳࡡࡥ࡯ࡤ࡬ࡩ࡯࠮ࡱࡻࡷ࡬ࡴࡴࡡ࡯ࡻࡺ࡬ࡪࡸࡥ࠯ࡥࡲࡱ࠴࡭ࡥࡵࡳࡸࡩࡸࡺࡩࡰࡰࡶࠫൢ"),tQMjXKCA5dN4xq3beVIzaEoWkFLg(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴࡫࡭ࡢࡦࡰࡥ࡭ࡪࡩ࠯ࡲࡼࡸ࡭ࡵ࡮ࡢࡰࡼࡻ࡭࡫ࡲࡦ࠰ࡦࡳࡲ࠵ࡧࡦࡶ࡮ࡲࡴࡽ࡮ࡦࡴࡵࡳࡷࡹࠧൣ"),zYvEaigKWjoq50pXBLDbGJkFc(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡥ࡮ࡣࡧࡱࡦ࡮ࡤࡪ࠰ࡳࡽࡹ࡮࡯࡯ࡣࡱࡽࡼ࡮ࡥࡳࡧ࠱ࡧࡴࡳ࠯ࡤࡣࡳࡸࡨ࡮ࡡࠨ൤"),zYvEaigKWjoq50pXBLDbGJkFc(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡦ࡯ࡤࡨࡲࡧࡨࡥ࡫࠱ࡴࡾࡺࡨࡰࡰࡤࡲࡾࡽࡨࡦࡴࡨ࠲ࡨࡵ࡭࠰ࡶࡨࡷࡹ࡯࡮ࡨࠩ൥"),LZWMikPEB81KSGyxfJtUsCA(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡧࡰࡥࡩࡳࡡࡩࡦ࡬࠲ࡵࡿࡴࡩࡱࡱࡥࡳࡿࡷࡩࡧࡵࡩ࠳ࡩ࡯࡮࠱ࡪࡩࡹ࡫ࡸࡵࡴࡤࡴࡾࡺࡨࡰࡰࡦࡳࡩ࡫ࠧ൦"),Ie5s2cBtSfdHjzQ4rA9kYlo6D18(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡨࡱࡦࡪ࡭ࡢࡪࡧ࡭࠳ࡶࡹࡵࡪࡲࡲࡦࡴࡹࡸࡪࡨࡶࡪ࠴ࡣࡰ࡯࠲ࡩࡽ࡫ࡣࡶࡶࡨ࡮ࡸ࠭൧"),qqzwE6imYG4c2xojI(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡩࡲࡧࡤ࡮ࡣ࡫ࡨ࡮࠴ࡰࡺࡶ࡫ࡳࡳࡧ࡮ࡺࡹ࡫ࡩࡷ࡫࠮ࡤࡱࡰ࠳ࡼ࡫ࡢࡤࡣࡦ࡬ࡪ࠭൨")]
	SITESURLS[Ie5s2cBtSfdHjzQ4rA9kYlo6D18(u"ࠪࡔ࡞࡚ࡈࡐࡐࡢࡆࡐࡖ࠲ࠨ൩")] = [BRWqdruz2A0(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡹࡥࡳࡸࡨࡶ࠶࠴࡫ࡰࡦ࡬ࡩࡲࡧࡤ࠯ࡨࡵࡩࡪࡪࡤ࡯ࡵ࠱ࡳࡷ࡭࠯࡭࡫ࡶࡸࡵࡲࡡࡺࠩ൪"),rNdBKI74fAklnoCZ6(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡳࡦࡴࡹࡩࡷ࠷࠮࡬ࡱࡧ࡭ࡪࡳࡡࡥ࠰ࡩࡶࡪ࡫ࡤࡥࡰࡶ࠲ࡴࡸࡧ࠰ࡷࡶࡥ࡬࡫ࡲࡦࡲࡲࡶࡹ࠭൫"),Ie5s2cBtSfdHjzQ4rA9kYlo6D18(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡴࡧࡵࡺࡪࡸ࠱࠯࡭ࡲࡨ࡮࡫࡭ࡢࡦ࠱ࡪࡷ࡫ࡥࡥࡦࡱࡷ࠳ࡵࡲࡨ࠱ࡶࡩࡳࡪࡥ࡮ࡣ࡬ࡰࠬ൬"),DiJ8CMuYH1daWyjehfN0L(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡵࡨࡶࡻ࡫ࡲ࠲࠰࡮ࡳࡩ࡯ࡥ࡮ࡣࡧ࠲࡫ࡸࡥࡦࡦࡧࡲࡸ࠴࡯ࡳࡩ࠲࡫ࡪࡺ࡭ࡦࡵࡶࡥ࡬࡫ࡳࠨ൭"),rNdBKI74fAklnoCZ6(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡶࡩࡷࡼࡥࡳ࠳࠱࡯ࡴࡪࡩࡦ࡯ࡤࡨ࠳࡬ࡲࡦࡧࡧࡨࡳࡹ࠮ࡰࡴࡪ࠳࡬࡫ࡴࡪࡵ࡯ࡥࡲ࡯ࡣࠨ൮"),kYDaz79TFlXoR(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡷࡪࡸࡶࡦࡴ࠴࠲ࡰࡵࡤࡪࡧࡰࡥࡩ࠴ࡦࡳࡧࡨࡨࡩࡴࡳ࠯ࡱࡵ࡫࠴࡭ࡥࡵࡳࡸࡩࡸࡺࡩࡰࡰࡶࠫ൯"),Ie5s2cBtSfdHjzQ4rA9kYlo6D18(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡸ࡫ࡲࡷࡧࡵ࠵࠳ࡱ࡯ࡥ࡫ࡨࡱࡦࡪ࠮ࡧࡴࡨࡩࡩࡪ࡮ࡴ࠰ࡲࡶ࡬࠵ࡧࡦࡶ࡮ࡲࡴࡽ࡮ࡦࡴࡵࡳࡷࡹࠧ൰"),DaFZHsThGmd0zv6e(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡹࡥࡳࡸࡨࡶ࠶࠴࡫ࡰࡦ࡬ࡩࡲࡧࡤ࠯ࡨࡵࡩࡪࡪࡤ࡯ࡵ࠱ࡳࡷ࡭࠯ࡤࡣࡳࡸࡨ࡮ࡡࠨ൱"),c2RKu0xG1eC8MiohyE(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡳࡦࡴࡹࡩࡷ࠷࠮࡬ࡱࡧ࡭ࡪࡳࡡࡥ࠰ࡩࡶࡪ࡫ࡤࡥࡰࡶ࠲ࡴࡸࡧ࠰ࡶࡨࡷࡹ࡯࡮ࡨࠩ൲"),CC1eY6yWZUwf2TkRvnp7EJ0AimjHBX(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡴࡧࡵࡺࡪࡸ࠱࠯࡭ࡲࡨ࡮࡫࡭ࡢࡦ࠱ࡪࡷ࡫ࡥࡥࡦࡱࡷ࠳ࡵࡲࡨ࠱ࡪࡩࡹ࡫ࡸࡵࡴࡤࡴࡾࡺࡨࡰࡰࡦࡳࡩ࡫ࠧ൳"),IaBhDMJc17302LgSvyxd(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡵࡨࡶࡻ࡫ࡲ࠲࠰࡮ࡳࡩ࡯ࡥ࡮ࡣࡧ࠲࡫ࡸࡥࡦࡦࡧࡲࡸ࠴࡯ࡳࡩ࠲ࡩࡽ࡫ࡣࡶࡶࡨ࡮ࡸ࠭൴"),RlOvin8YIGC2KZXJPk9m0acrMobUex(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡶࡩࡷࡼࡥࡳ࠳࠱࡯ࡴࡪࡩࡦ࡯ࡤࡨ࠳࡬ࡲࡦࡧࡧࡨࡳࡹ࠮ࡰࡴࡪ࠳ࡼ࡫ࡢࡤࡣࡦ࡬ࡪ࠭൵")]
	SITESURLS[CC1eY6yWZUwf2TkRvnp7EJ0AimjHBX(u"ࠩࡓ࡝࡙ࡎࡏࡏࡡࡅࡏࡕ࠹ࠧ൶")] = [LZWMikPEB81KSGyxfJtUsCA(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࡯ࡴࡪࡩࡦ࡯ࡤࡨ࠳ࡻ࡫࠯ࡶࡲ࠳ࡱ࡯ࡳࡵࡲ࡯ࡥࡾ࠭൷"),V3VlkhgjEF4n1erPXHcC0NOsfwyAJ(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡰࡵࡤࡪࡧࡰࡥࡩ࠴ࡵ࡬࠰ࡷࡳ࠴ࡻࡳࡢࡩࡨࡶࡪࡶ࡯ࡳࡶࠪ൸"),l32dnTEOU1skGKqeBtI9hmo(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡱ࡯ࡥ࡫ࡨࡱࡦࡪ࠮ࡶ࡭࠱ࡸࡴ࠵ࡳࡦࡰࡧࡩࡲࡧࡩ࡭ࠩ൹"),N3flV6EJsD5CzS(u"࠭ࡨࡵࡶࡳ࠾࠴࠵࡫ࡰࡦ࡬ࡩࡲࡧࡤ࠯ࡷ࡮࠲ࡹࡵ࠯ࡨࡧࡷࡱࡪࡹࡳࡢࡩࡨࡷࠬൺ"),kYDaz79TFlXoR(u"ࠧࡩࡶࡷࡴ࠿࠵࠯࡬ࡱࡧ࡭ࡪࡳࡡࡥ࠰ࡸ࡯࠳ࡺ࡯࠰ࡩࡨࡸ࡮ࡹ࡬ࡢ࡯࡬ࡧࠬൻ"),UUDAiytEL76RTmMYsuIz5evXB(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࡭ࡲࡨ࡮࡫࡭ࡢࡦ࠱ࡹࡰ࠴ࡴࡰ࠱ࡪࡩࡹࡷࡵࡦࡵࡷ࡭ࡴࡴࡳࠨർ"),l32dnTEOU1skGKqeBtI9hmo(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࡮ࡳࡩ࡯ࡥ࡮ࡣࡧ࠲ࡺࡱ࠮ࡵࡱ࠲࡫ࡪࡺ࡫࡯ࡱࡺࡲࡪࡸࡲࡰࡴࡶࠫൽ"),rNdBKI74fAklnoCZ6(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࡯ࡴࡪࡩࡦ࡯ࡤࡨ࠳ࡻ࡫࠯ࡶࡲ࠳ࡨࡧࡰࡵࡥ࡫ࡥࠬൾ"),zYvEaigKWjoq50pXBLDbGJkFc(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡰࡵࡤࡪࡧࡰࡥࡩ࠴ࡵ࡬࠰ࡷࡳ࠴ࡺࡥࡴࡶ࡬ࡲ࡬࠭ൿ"),CC1eY6yWZUwf2TkRvnp7EJ0AimjHBX(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡱ࡯ࡥ࡫ࡨࡱࡦࡪ࠮ࡶ࡭࠱ࡸࡴ࠵ࡧࡦࡶࡨࡼࡹࡸࡡࡱࡻࡷ࡬ࡴࡴࡣࡰࡦࡨࠫ඀"),l1DZAt9XNQjqE7YOdrz(u"࠭ࡨࡵࡶࡳ࠾࠴࠵࡫ࡰࡦ࡬ࡩࡲࡧࡤ࠯ࡷ࡮࠲ࡹࡵ࠯ࡦࡺࡨࡧࡺࡺࡥ࡫ࡵࠪඁ"),Ie5s2cBtSfdHjzQ4rA9kYlo6D18(u"ࠧࡩࡶࡷࡴ࠿࠵࠯࡬ࡱࡧ࡭ࡪࡳࡡࡥ࠰ࡸ࡯࠳ࡺ࡯࠰ࡹࡨࡦࡨࡧࡣࡩࡧࠪං")]
else:
	SITESURLS[Ie5s2cBtSfdHjzQ4rA9kYlo6D18(u"ࠨࡒ࡜ࡘࡍࡕࡎࠨඃ")]      = [rNdBKI74fAklnoCZ6(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࠴࠶࠼࠴࠰࠯࠲࠱࠵࠿࠻࠰࠱࠲࠲ࡰ࡮ࡹࡴࡱ࡮ࡤࡽࠬ඄"),c2RKu0xG1eC8MiohyE(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࠵࠷࠽࠮࠱࠰࠳࠲࠶ࡀ࠵࠱࠲࠳࠳ࡺࡹࡡࡨࡧࡵࡩࡵࡵࡲࡵࠩඅ"),zYvEaigKWjoq50pXBLDbGJkFc(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࠶࠸࠷࠯࠲࠱࠴࠳࠷࠺࠶࠲࠳࠴࠴ࡹࡥ࡯ࡦࡨࡱࡦ࡯࡬ࠨආ"),c2RKu0xG1eC8MiohyE(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࠷࠲࠸࠰࠳࠲࠵࠴࠱࠻࠷࠳࠴࠵࠵ࡧࡦࡶࡰࡩࡸࡹࡡࡨࡧࡶࠫඇ"),viRJWOC5jsYe84(u"࠭ࡨࡵࡶࡳ࠾࠴࠵࠱࠳࠹࠱࠴࠳࠶࠮࠲࠼࠸࠴࠵࠶࠯ࡨࡧࡷ࡭ࡸࡲࡡ࡮࡫ࡦࠫඈ"),c2RKu0xG1eC8MiohyE(u"ࠧࡩࡶࡷࡴ࠿࠵࠯࠲࠴࠺࠲࠵࠴࠰࠯࠳࠽࠹࠵࠶࠰࠰ࡩࡨࡸࡶࡻࡥࡴࡶ࡬ࡳࡳࡹࠧඉ"),dJHDqiKf12TXlIzSLkGUuxg4MBs3A(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࠳࠵࠻࠳࠶࠮࠱࠰࠴࠾࠺࠶࠰࠱࠱ࡪࡩࡹࡱ࡮ࡰࡹࡱࡩࡷࡸ࡯ࡳࡵࠪඊ"),qoBMmfAWpFlK70xw8ZRh4naJ(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࠴࠶࠼࠴࠰࠯࠲࠱࠵࠿࠻࠰࠱࠲࠲ࡧࡦࡶࡴࡤࡪࡤࠫඋ"),mmV2nucZ5Lpl6FO1JMPEqGoQKW(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࠵࠷࠽࠮࠱࠰࠳࠲࠶ࡀ࠵࠱࠲࠳࠳ࡹ࡫ࡳࡵ࡫ࡱ࡫ࠬඌ"),l1DZAt9XNQjqE7YOdrz(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࠶࠸࠷࠯࠲࠱࠴࠳࠷࠺࠶࠲࠳࠴࠴࡭ࡥࡵࡧࡻࡸࡷࡧࡰࡺࡶ࡫ࡳࡳࡩ࡯ࡥࡧࠪඍ"),sjtU6GZQg5XC2pH4(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࠷࠲࠸࠰࠳࠲࠵࠴࠱࠻࠷࠳࠴࠵࠵ࡥࡹࡧࡦࡹࡹ࡫ࡪࡴࠩඎ"),V3VlkhgjEF4n1erPXHcC0NOsfwyAJ(u"࠭ࡨࡵࡶࡳ࠾࠴࠵࠱࠳࠹࠱࠴࠳࠶࠮࠲࠼࠸࠴࠵࠶࠯ࡸࡧࡥࡧࡦࡩࡨࡦࠩඏ")]
	SITESURLS[l1DZAt9XNQjqE7YOdrz(u"ࠧࡑ࡛ࡗࡌࡔࡔ࡟ࡃࡍࡓ࠵ࠬඐ")] = [dJHDqiKf12TXlIzSLkGUuxg4MBs3A(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࠳࠵࠻࠳࠶࠮࠱࠰࠴࠾࠺࠶࠰࠱࠱࡯࡭ࡸࡺࡰ࡭ࡣࡼࠫඑ"),RlOvin8YIGC2KZXJPk9m0acrMobUex(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࠴࠶࠼࠴࠰࠯࠲࠱࠵࠿࠻࠰࠱࠲࠲ࡹࡸࡧࡧࡦࡴࡨࡴࡴࡸࡴࠨඒ"),l1DZAt9XNQjqE7YOdrz(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࠵࠷࠽࠮࠱࠰࠳࠲࠶ࡀ࠵࠱࠲࠳࠳ࡸ࡫࡮ࡥࡧࡰࡥ࡮ࡲࠧඓ"),ee86G9ladLHVbh5mikzCo(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࠶࠸࠷࠯࠲࠱࠴࠳࠷࠺࠶࠲࠳࠴࠴࡭ࡥࡵ࡯ࡨࡷࡸࡧࡧࡦࡵࠪඔ"),qoBMmfAWpFlK70xw8ZRh4naJ(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࠷࠲࠸࠰࠳࠲࠵࠴࠱࠻࠷࠳࠴࠵࠵ࡧࡦࡶ࡬ࡷࡱࡧ࡭ࡪࡥࠪඕ"),lljaEqwTVtmKsQcOrbXxS5hgNH(u"࠭ࡨࡵࡶࡳ࠾࠴࠵࠱࠳࠹࠱࠴࠳࠶࠮࠲࠼࠸࠴࠵࠶࠯ࡨࡧࡷࡵࡺ࡫ࡳࡵ࡫ࡲࡲࡸ࠭ඖ"),l32dnTEOU1skGKqeBtI9hmo(u"ࠧࡩࡶࡷࡴ࠿࠵࠯࠲࠴࠺࠲࠵࠴࠰࠯࠳࠽࠹࠵࠶࠰࠰ࡩࡨࡸࡰࡴ࡯ࡸࡰࡨࡶࡷࡵࡲࡴࠩ඗"),LZWMikPEB81KSGyxfJtUsCA(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࠳࠵࠻࠳࠶࠮࠱࠰࠴࠾࠺࠶࠰࠱࠱ࡦࡥࡵࡺࡣࡩࡣࠪ඘"),viRJWOC5jsYe84(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࠴࠶࠼࠴࠰࠯࠲࠱࠵࠿࠻࠰࠱࠲࠲ࡸࡪࡹࡴࡪࡰࡪࠫ඙"),ddiCzu6yahj5RtTISMJ48sNnZBU(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࠵࠷࠽࠮࠱࠰࠳࠲࠶ࡀ࠵࠱࠲࠳࠳࡬࡫ࡴࡦࡺࡷࡶࡦࡶࡹࡵࡪࡲࡲࡨࡵࡤࡦࠩක"),tQMjXKCA5dN4xq3beVIzaEoWkFLg(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࠶࠸࠷࠯࠲࠱࠴࠳࠷࠺࠶࠲࠳࠴࠴࡫ࡸࡦࡥࡸࡸࡪࡰࡳࠨඛ"),lljaEqwTVtmKsQcOrbXxS5hgNH(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࠷࠲࠸࠰࠳࠲࠵࠴࠱࠻࠷࠳࠴࠵࠵ࡷࡦࡤࡦࡥࡨ࡮ࡥࠨග")]
	SITESURLS[CC1eY6yWZUwf2TkRvnp7EJ0AimjHBX(u"࠭ࡐ࡚ࡖࡋࡓࡓࡥࡂࡌࡒ࠵ࠫඝ")] = [l1DZAt9XNQjqE7YOdrz(u"ࠧࡩࡶࡷࡴ࠿࠵࠯࠲࠴࠺࠲࠵࠴࠰࠯࠳࠽࠹࠵࠶࠰࠰࡮࡬ࡷࡹࡶ࡬ࡢࡻࠪඞ"),YY8UDX3MJhb91AHw7fg(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࠳࠵࠻࠳࠶࠮࠱࠰࠴࠾࠺࠶࠰࠱࠱ࡸࡷࡦ࡭ࡥࡳࡧࡳࡳࡷࡺࠧඟ"),YY8UDX3MJhb91AHw7fg(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࠴࠶࠼࠴࠰࠯࠲࠱࠵࠿࠻࠰࠱࠲࠲ࡷࡪࡴࡤࡦ࡯ࡤ࡭ࡱ࠭ච"),V3VlkhgjEF4n1erPXHcC0NOsfwyAJ(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࠵࠷࠽࠮࠱࠰࠳࠲࠶ࡀ࠵࠱࠲࠳࠳࡬࡫ࡴ࡮ࡧࡶࡷࡦ࡭ࡥࡴࠩඡ"),mmV2nucZ5Lpl6FO1JMPEqGoQKW(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࠶࠸࠷࠯࠲࠱࠴࠳࠷࠺࠶࠲࠳࠴࠴࡭ࡥࡵ࡫ࡶࡰࡦࡳࡩࡤࠩජ"),IaBhDMJc17302LgSvyxd(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࠷࠲࠸࠰࠳࠲࠵࠴࠱࠻࠷࠳࠴࠵࠵ࡧࡦࡶࡴࡹࡪࡹࡴࡪࡱࡱࡷࠬඣ"),ee86G9ladLHVbh5mikzCo(u"࠭ࡨࡵࡶࡳ࠾࠴࠵࠱࠳࠹࠱࠴࠳࠶࠮࠲࠼࠸࠴࠵࠶࠯ࡨࡧࡷ࡯ࡳࡵࡷ࡯ࡧࡵࡶࡴࡸࡳࠨඤ"),UVa3fJw7k6KM(u"ࠧࡩࡶࡷࡴ࠿࠵࠯࠲࠴࠺࠲࠵࠴࠰࠯࠳࠽࠹࠵࠶࠰࠰ࡥࡤࡴࡹࡩࡨࡢࠩඥ"),N3flV6EJsD5CzS(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࠳࠵࠻࠳࠶࠮࠱࠰࠴࠾࠺࠶࠰࠱࠱ࡷࡩࡸࡺࡩ࡯ࡩࠪඦ"),qqzwE6imYG4c2xojI(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࠴࠶࠼࠴࠰࠯࠲࠱࠵࠿࠻࠰࠱࠲࠲࡫ࡪࡺࡥࡹࡶࡵࡥࡵࡿࡴࡩࡱࡱࡧࡴࡪࡥࠨට"),IaBhDMJc17302LgSvyxd(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࠵࠷࠽࠮࠱࠰࠳࠲࠶ࡀ࠵࠱࠲࠳࠳ࡪࡾࡥࡤࡷࡷࡩ࡯ࡹࠧඨ"),DaFZHsThGmd0zv6e(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࠶࠸࠷࠯࠲࠱࠴࠳࠷࠺࠶࠲࠳࠴࠴ࡽࡥࡣࡥࡤࡧ࡭࡫ࠧඩ")]
	SITESURLS[rNdBKI74fAklnoCZ6(u"ࠬࡖ࡙ࡕࡊࡒࡒࡤࡈࡋࡑ࠵ࠪඪ")] = [CC1eY6yWZUwf2TkRvnp7EJ0AimjHBX(u"࠭ࡨࡵࡶࡳ࠾࠴࠵࠱࠳࠹࠱࠴࠳࠶࠮࠲࠼࠸࠴࠵࠶࠯࡭࡫ࡶࡸࡵࡲࡡࡺࠩණ"),BRWqdruz2A0(u"ࠧࡩࡶࡷࡴ࠿࠵࠯࠲࠴࠺࠲࠵࠴࠰࠯࠳࠽࠹࠵࠶࠰࠰ࡷࡶࡥ࡬࡫ࡲࡦࡲࡲࡶࡹ࠭ඬ"),dJHDqiKf12TXlIzSLkGUuxg4MBs3A(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࠳࠵࠻࠳࠶࠮࠱࠰࠴࠾࠺࠶࠰࠱࠱ࡶࡩࡳࡪࡥ࡮ࡣ࡬ࡰࠬත"),UUDAiytEL76RTmMYsuIz5evXB(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࠴࠶࠼࠴࠰࠯࠲࠱࠵࠿࠻࠰࠱࠲࠲࡫ࡪࡺ࡭ࡦࡵࡶࡥ࡬࡫ࡳࠨථ"),tQMjXKCA5dN4xq3beVIzaEoWkFLg(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࠵࠷࠽࠮࠱࠰࠳࠲࠶ࡀ࠵࠱࠲࠳࠳࡬࡫ࡴࡪࡵ࡯ࡥࡲ࡯ࡣࠨද"),kYDaz79TFlXoR(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࠶࠸࠷࠯࠲࠱࠴࠳࠷࠺࠶࠲࠳࠴࠴࡭ࡥࡵࡳࡸࡩࡸࡺࡩࡰࡰࡶࠫධ"),aXqWLoTdVgME(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࠷࠲࠸࠰࠳࠲࠵࠴࠱࠻࠷࠳࠴࠵࠵ࡧࡦࡶ࡮ࡲࡴࡽ࡮ࡦࡴࡵࡳࡷࡹࠧන"),kYDaz79TFlXoR(u"࠭ࡨࡵࡶࡳ࠾࠴࠵࠱࠳࠹࠱࠴࠳࠶࠮࠲࠼࠸࠴࠵࠶࠯ࡤࡣࡳࡸࡨ࡮ࡡࠨ඲"),DaFZHsThGmd0zv6e(u"ࠧࡩࡶࡷࡴ࠿࠵࠯࠲࠴࠺࠲࠵࠴࠰࠯࠳࠽࠹࠵࠶࠰࠰ࡶࡨࡷࡹ࡯࡮ࡨࠩඳ"),YY8UDX3MJhb91AHw7fg(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࠳࠵࠻࠳࠶࠮࠱࠰࠴࠾࠺࠶࠰࠱࠱ࡪࡩࡹ࡫ࡸࡵࡴࡤࡴࡾࡺࡨࡰࡰࡦࡳࡩ࡫ࠧප"),fWoVd0Bmtkx(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࠴࠶࠼࠴࠰࠯࠲࠱࠵࠿࠻࠰࠱࠲࠲ࡩࡽ࡫ࡣࡶࡶࡨ࡮ࡸ࠭ඵ"),V3VlkhgjEF4n1erPXHcC0NOsfwyAJ(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࠵࠷࠽࠮࠱࠰࠳࠲࠶ࡀ࠵࠱࠲࠳࠳ࡼ࡫ࡢࡤࡣࡦ࡬ࡪ࠭බ")]
api_python_actions = [ddiCzu6yahj5RtTISMJ48sNnZBU(u"ࠫࡑࡏࡓࡕࡒࡏࡅ࡞࠭භ"),l32dnTEOU1skGKqeBtI9hmo(u"ࠬࡘࡅࡑࡑࡕࡘࡘ࠭ම"),RlOvin8YIGC2KZXJPk9m0acrMobUex(u"࠭ࡅࡎࡃࡌࡐࡘ࠭ඹ"),l32dnTEOU1skGKqeBtI9hmo(u"ࠧࡎࡇࡖࡗࡆࡍࡅࡔࠩය"),c2RKu0xG1eC8MiohyE(u"ࠨࡋࡖࡐࡆࡓࡉࡄࡕࠪර"),IaBhDMJc17302LgSvyxd(u"ࠩࡔ࡙ࡊ࡙ࡔࡊࡑࡑࡗࠬ඼"),LZWMikPEB81KSGyxfJtUsCA(u"ࠪࡏࡓࡕࡗࡏࡇࡕࡖࡔࡘࡓࠨල"),UVa3fJw7k6KM(u"ࠫࡈࡇࡐࡕࡅࡋࡅࠬ඾"),rNdBKI74fAklnoCZ6(u"࡚ࠬࡅࡔࡖࡌࡒࡌ࠭඿"),N3flV6EJsD5CzS(u"࠭ࡅ࡙ࡖࡕࡅࡕ࡟ࡔࡉࡑࡑࡇࡔࡊࡅࠨව"),sjtU6GZQg5XC2pH4(u"ࠧࡆ࡚ࡈࡇ࡚࡚ࡅࡋࡕࠪශ"),ddiCzu6yahj5RtTISMJ48sNnZBU(u"ࠨ࡙ࡈࡆࡈࡇࡃࡉࡇࠪෂ")]
api_repos_actions = [aXqWLoTdVgME(u"ࠩࡄࡈࡉࡕࡎࡔࠩස"),tQMjXKCA5dN4xq3beVIzaEoWkFLg(u"ࠪࡅࡉࡊࡏࡏࡕ࠴࠼ࠬහ"),mmV2nucZ5Lpl6FO1JMPEqGoQKW(u"ࠫࡆࡊࡄࡐࡐࡖ࠵࠾࠭ළ")]
non_videos_actions = [l1DZAt9XNQjqE7YOdrz(u"ࠬࡇࡌࡍࠩෆ"),V3VlkhgjEF4n1erPXHcC0NOsfwyAJ(u"࠭ࡐ࡚ࡖࡋࡓࡓ࠭෇"),UUDAiytEL76RTmMYsuIz5evXB(u"ࠧࡊࡐࡖࡘࡆࡒࡌࠨ෈"),lljaEqwTVtmKsQcOrbXxS5hgNH(u"ࠨࡏࡈࡘࡗࡕࡐࡐࡎࡌࡗࠬ෉"),c2RKu0xG1eC8MiohyE(u"ࠩࡕࡉࡕࡕࡓࠨ්"),iNc3KxwErnQ(u"ࠪࡈࡔࡔࡁࡕࡋࡒࡒࡘ࠭෋"),mmV2nucZ5Lpl6FO1JMPEqGoQKW(u"ࠫࡈࡇࡐࡕࡅࡋࡅࡎࡊࠧ෌"),UUDAiytEL76RTmMYsuIz5evXB(u"ࠬࡉࡁࡑࡖࡆࡌࡆ࡚ࡏࡌࡇࡑࠫ෍"),fWoVd0Bmtkx(u"࠭ࡃࡂࡒࡗࡇࡍࡇࡇࡆࡖࡌࡈࠬ෎"),iNc3KxwErnQ(u"ࠧࡔࡋࡗࡉࡘ࡛ࡒࡍࡕࠪා")]+api_python_actions+api_repos_actions
XXvY7VDsGwhMLy4iaABHQOp = ag8rjZo1Vz4IPdcOT
uj7GLZ5bpqsOCcXxF3w = gBExoceumj4y8bFW9hY2aNMVSr
ogLe6xzIfJyT75HCQa = ag8rjZo1Vz4IPdcOT
ZZFcMiWJ3nfg29XH4L = ag8rjZo1Vz4IPdcOT
avprivsnorestrict = ag8rjZo1Vz4IPdcOT
avprivslongperiod = ag8rjZo1Vz4IPdcOT
resolveonly = ag8rjZo1Vz4IPdcOT
YYhTKn1kR9i = ag8rjZo1Vz4IPdcOT
ALLOW_DNS_FIX = H1k0Fmba4Gfiynp8AML
ALLOW_PROXY_FIX = H1k0Fmba4Gfiynp8AML
ALLOW_SHOWDIALOGS_FIX = H1k0Fmba4Gfiynp8AML
menuItemsLIST = []
SEND_THESE_EVENTS = []
SAVED_FORWARDS = {}
menuItemsDICT = {}
BADSCRAPERS = []
WEBCACHEDATA = {}
BADWEBSITES = [tR1krDGPpO025fghMT3a7UnYj(u"ࠨࡈࡘࡗࡍࡇࡒࡕࡘࠪැ"),kYDaz79TFlXoR(u"ࠩࡇࡖࡆࡓࡁࡄࡃࡉࡉࠬෑ"),viRJWOC5jsYe84(u"ࠪࡇࡎࡓࡁ࠵࠲࠳ࠫි"),viRJWOC5jsYe84(u"ࠫࡊࡍ࡙ࡃࡇࡖࡘ࠹࠭ී"),lljaEqwTVtmKsQcOrbXxS5hgNH(u"ࠬࡒࡁࡓࡑ࡝ࡅࠬු"),BRWqdruz2A0(u"࠭ࡅࡈ࡛ࡅࡉࡘ࡚࠱ࠨ෕"),tQMjXKCA5dN4xq3beVIzaEoWkFLg(u"࡚ࠧࡃࡔࡓ࡙࠭ූ"),mmV2nucZ5Lpl6FO1JMPEqGoQKW(u"ࠨࡘࡄࡖࡇࡕࡎࠨ෗"),N3flV6EJsD5CzS(u"ࠩࡋࡅࡑࡇࡃࡊࡏࡄࠫෘ"),mmV2nucZ5Lpl6FO1JMPEqGoQKW(u"ࠪࡔࡆࡔࡅࡕࠩෙ"),IaBhDMJc17302LgSvyxd(u"ࠫࡘࡎࡁࡃࡃࡎࡅ࡙࡟ࠧේ")]
BADWEBSITES += [YY8UDX3MJhb91AHw7fg(u"ࠬࡌࡁࡃࡔࡄࡏࡆ࠭ෛ"),V3VlkhgjEF4n1erPXHcC0NOsfwyAJ(u"࠭ࡅࡍࡋࡉ࡚ࡎࡊࡅࡐࠩො")]
BADCOMMONIDS = [lljaEqwTVtmKsQcOrbXxS5hgNH(u"ࠧ࠺࠻࠼࠽࠲࠿࠹࠺࠻࠰࠽࠾࠿࠹࠮࠻࠼࠽࠾࠳࠰࠱࠲࠳ࠫෝ"),RlOvin8YIGC2KZXJPk9m0acrMobUex(u"ࠨ࠻࠼࠼࠽࠳࠷࠸࠸࠹࠱࠺࠻࠴࠵࠯࠶࠷࠷࠸࠭࠳࠲࠻࠺ࠬෞ")]
GEOLOCATION_DATA = qpFY4hAwolV3
AV_CLIENT_IDS = qpFY4hAwolV3
DNS_SERVERS = [Ie5s2cBtSfdHjzQ4rA9kYlo6D18(u"ࠩ࠴࠲࠶࠴࠱࠯࠳ࠪෟ"),fWoVd0Bmtkx(u"ࠪ࠼࠳࠾࠮࠹࠰࠻ࠫ෠"),Ie5s2cBtSfdHjzQ4rA9kYlo6D18(u"ࠫ࠶࠴࠰࠯࠲࠱࠵ࠬ෡"),kYDaz79TFlXoR(u"ࠬ࠾࠮࠹࠰࠷࠲࠹࠭෢"),fWoVd0Bmtkx(u"࠭࠲࠱࠺࠱࠺࠼࠴࠲࠳࠴࠱࠶࠷࠸ࠧ෣"),CC1eY6yWZUwf2TkRvnp7EJ0AimjHBX(u"ࠧ࠳࠲࠻࠲࠻࠽࠮࠳࠴࠳࠲࠷࠸࠰ࠨ෤")]
busydialog_active = ag8rjZo1Vz4IPdcOT
dns_succeeded_urls = []
scrapers_succeeded = ag8rjZo1Vz4IPdcOT