# -*- coding: utf-8 -*-
import sys as TSRUP0dExYGQg
mgNMJhrjcq1xb = TSRUP0dExYGQg.version_info [0] == 2
lQJvf8UXo2de9gjCatY4yH = 2048
YuTB2OjotvlR = 7
def kk0DKyarxq9eS1zwGLMFQTZN35dj (neqP2if8IOJ50aNKcCBLrXdZk):
	global sWerUpk6nQwT7zY43
	vxdNQUujz7ZFV4rtOSK2 = ord (neqP2if8IOJ50aNKcCBLrXdZk [-1])
	yyshZX35KO7JodYjD9qVib6 = neqP2if8IOJ50aNKcCBLrXdZk [:-1]
	fuKReXJ3HPIAU7c = vxdNQUujz7ZFV4rtOSK2 % len (yyshZX35KO7JodYjD9qVib6)
	EEFQdvXog7LPC4Sie0jDkUKxn6M = yyshZX35KO7JodYjD9qVib6 [:fuKReXJ3HPIAU7c] + yyshZX35KO7JodYjD9qVib6 [fuKReXJ3HPIAU7c:]
	if mgNMJhrjcq1xb:
		Clh5YS0XPue68EgT4Uq17GL = unicode () .join ([unichr (ord (AsGVDZFgmuH06jviYrWXTz) - lQJvf8UXo2de9gjCatY4yH - (XvhDIL4ZpzaPs91WkoGnedCEA2rt + vxdNQUujz7ZFV4rtOSK2) % YuTB2OjotvlR) for XvhDIL4ZpzaPs91WkoGnedCEA2rt, AsGVDZFgmuH06jviYrWXTz in enumerate (EEFQdvXog7LPC4Sie0jDkUKxn6M)])
	else:
		Clh5YS0XPue68EgT4Uq17GL = str () .join ([chr (ord (AsGVDZFgmuH06jviYrWXTz) - lQJvf8UXo2de9gjCatY4yH - (XvhDIL4ZpzaPs91WkoGnedCEA2rt + vxdNQUujz7ZFV4rtOSK2) % YuTB2OjotvlR) for XvhDIL4ZpzaPs91WkoGnedCEA2rt, AsGVDZFgmuH06jviYrWXTz in enumerate (EEFQdvXog7LPC4Sie0jDkUKxn6M)])
	return eval (Clh5YS0XPue68EgT4Uq17GL)
qoBMmfAWpFlK70xw8ZRh4naJ,lljaEqwTVtmKsQcOrbXxS5hgNH,aXqWLoTdVgME=kk0DKyarxq9eS1zwGLMFQTZN35dj,kk0DKyarxq9eS1zwGLMFQTZN35dj,kk0DKyarxq9eS1zwGLMFQTZN35dj
UVa3fJw7k6KM,fWoVd0Bmtkx,tQMjXKCA5dN4xq3beVIzaEoWkFLg=aXqWLoTdVgME,lljaEqwTVtmKsQcOrbXxS5hgNH,qoBMmfAWpFlK70xw8ZRh4naJ
viRJWOC5jsYe84,Ie5s2cBtSfdHjzQ4rA9kYlo6D18,sjtU6GZQg5XC2pH4=tQMjXKCA5dN4xq3beVIzaEoWkFLg,fWoVd0Bmtkx,UVa3fJw7k6KM
LZWMikPEB81KSGyxfJtUsCA,rNdBKI74fAklnoCZ6,BRWqdruz2A0=sjtU6GZQg5XC2pH4,Ie5s2cBtSfdHjzQ4rA9kYlo6D18,viRJWOC5jsYe84
CC1eY6yWZUwf2TkRvnp7EJ0AimjHBX,qqzwE6imYG4c2xojI,N3flV6EJsD5CzS=BRWqdruz2A0,rNdBKI74fAklnoCZ6,LZWMikPEB81KSGyxfJtUsCA
UUDAiytEL76RTmMYsuIz5evXB,IaBhDMJc17302LgSvyxd,ddiCzu6yahj5RtTISMJ48sNnZBU=N3flV6EJsD5CzS,qqzwE6imYG4c2xojI,CC1eY6yWZUwf2TkRvnp7EJ0AimjHBX
dJHDqiKf12TXlIzSLkGUuxg4MBs3A,l1DZAt9XNQjqE7YOdrz,l32dnTEOU1skGKqeBtI9hmo=ddiCzu6yahj5RtTISMJ48sNnZBU,IaBhDMJc17302LgSvyxd,UUDAiytEL76RTmMYsuIz5evXB
zYvEaigKWjoq50pXBLDbGJkFc,iNc3KxwErnQ,V3VlkhgjEF4n1erPXHcC0NOsfwyAJ=l32dnTEOU1skGKqeBtI9hmo,l1DZAt9XNQjqE7YOdrz,dJHDqiKf12TXlIzSLkGUuxg4MBs3A
tR1krDGPpO025fghMT3a7UnYj,c2RKu0xG1eC8MiohyE,RlOvin8YIGC2KZXJPk9m0acrMobUex=V3VlkhgjEF4n1erPXHcC0NOsfwyAJ,iNc3KxwErnQ,zYvEaigKWjoq50pXBLDbGJkFc
YY8UDX3MJhb91AHw7fg,ee86G9ladLHVbh5mikzCo,mmV2nucZ5Lpl6FO1JMPEqGoQKW=RlOvin8YIGC2KZXJPk9m0acrMobUex,c2RKu0xG1eC8MiohyE,tR1krDGPpO025fghMT3a7UnYj
DaFZHsThGmd0zv6e,kYDaz79TFlXoR,DiJ8CMuYH1daWyjehfN0L=mmV2nucZ5Lpl6FO1JMPEqGoQKW,ee86G9ladLHVbh5mikzCo,YY8UDX3MJhb91AHw7fg
vvXoMLlg513 = l1DZAt9XNQjqE7YOdrz(u"࠳੠")
mZi0S72jGoHpLO = LZWMikPEB81KSGyxfJtUsCA(u"࠵੡")
Zwqio2AIWlD5etFa = mZi0S72jGoHpLO+mZi0S72jGoHpLO
DAE6vkyhXGx1wBdHmcFfTVQpL0l = Zwqio2AIWlD5etFa+mZi0S72jGoHpLO
wn4bG51vUENfaS0Zg = DAE6vkyhXGx1wBdHmcFfTVQpL0l+mZi0S72jGoHpLO
Y719atFWlPpbO6uTULjZf5VGD2o0 = wn4bG51vUENfaS0Zg+mZi0S72jGoHpLO
qpFY4hAwolV3 = sjtU6GZQg5XC2pH4(u"ࠨࠩऎ")
mIsDke0oK5x1zSiOWbF9thGcA = tR1krDGPpO025fghMT3a7UnYj(u"ࠩࠣࠫए")
r1roOXYi7UQw9FLThzPEdD0ZlvAnRc = mIsDke0oK5x1zSiOWbF9thGcA*Zwqio2AIWlD5etFa
bJGaEk9wcz = mIsDke0oK5x1zSiOWbF9thGcA*DAE6vkyhXGx1wBdHmcFfTVQpL0l
M04Bcjvt8SFaeQEK = mIsDke0oK5x1zSiOWbF9thGcA*wn4bG51vUENfaS0Zg
ShynO8pN9idCE3 = fWoVd0Bmtkx(u"ࠪ࠳ࠬऐ")
ttrDbyV5cSO2FjgTzew6qM = DiJ8CMuYH1daWyjehfN0L(u"ࠫ࠴࠵ࠧऑ")
H1k0Fmba4Gfiynp8AML = None
gBExoceumj4y8bFW9hY2aNMVSr = V3VlkhgjEF4n1erPXHcC0NOsfwyAJ(u"ࡔࡳࡷࡨ૰")
ag8rjZo1Vz4IPdcOT = sjtU6GZQg5XC2pH4(u"ࡇࡣ࡯ࡷࡪ૱")
gBS4c5m3A6vTzbpohHjFK1uYfNRk8a = IaBhDMJc17302LgSvyxd(u"ࠬࡺࡲࡶࡧࠪऒ")
pESAKj92MT = ee86G9ladLHVbh5mikzCo(u"࠭ࡦࡢ࡮ࡶࡩࠬओ")
z5wEtWrCxRZiQ = IaBhDMJc17302LgSvyxd(u"ࠧࡪࡩࡱࡳࡷ࡫ࠧऔ")
dND7uS6bknRj82EOIX0iyUxAscl = DiJ8CMuYH1daWyjehfN0L(u"ࠨࡦࡨࡪࡦࡻ࡬ࡵࠩक")
xupTj02bvy3O8R = ee86G9ladLHVbh5mikzCo(u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡋࡌࡂ࠶࠴ࡉࡡࠬख")
IQ2KCmObsTGuiRdEzt931a40jLg = N3flV6EJsD5CzS(u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌࡆࡇࡈ࠳࠴ࡢ࠭ग")
ccTvzSPB8F = sjtU6GZQg5XC2pH4(u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌ࠳࠴ࡇ࠷࠷࠸ࡣࠧघ")
MAlFzqvYasGXKywfVDLP57hNB9mQ1O = RlOvin8YIGC2KZXJPk9m0acrMobUex(u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆ࠲ࡈ࠸࠵ࡋࡌ࡝ࠨङ")
PslJYt2gqcNaKpQ3nRD65yoZGvU8x = zYvEaigKWjoq50pXBLDbGJkFc(u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡈࡉࡊࡋࡌࡆ࡞ࠩच")
fF4lt9zWYxXLKZVyAco82PgMj = lljaEqwTVtmKsQcOrbXxS5hgNH(u"ࠧ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩछ")
nV3Tip6XsH1rJw79DPOU = l1DZAt9XNQjqE7YOdrz(u"ࠨࡷࡷࡪ࠽࠭ज")
tB51CjmZGyJX09b8cAizhvu4T = IaBhDMJc17302LgSvyxd(u"ࠩ࡯ࡥࡹ࡯࡮࠮࠳ࠪझ")
Fufxt0VHDZgPJGAE = BRWqdruz2A0(u"ࠪࡻ࡮ࡴࡤࡰࡹࡶ࠱࠶࠸࠵࠷ࠩञ")
k8kdUSxohLVljnrY = qqzwE6imYG4c2xojI(u"ࠫࡓࡕࡔࡊࡅࡈࠫट")
BYgPHms8JMbdVkrUqKcSoO12Z0Cy = UUDAiytEL76RTmMYsuIz5evXB(u"ࠬࡋࡒࡓࡑࡕࠫठ")
d3MGHW41fvNz6rRFYix2anS = kYDaz79TFlXoR(u"࠭ࡎࡐࡖࡌࡇࡊࡥࡌࡊࡐࡈࡗࠬड")
j8gFJIMYPoBzcCvG9T = ddiCzu6yahj5RtTISMJ48sNnZBU(u"ࠧࡆࡔࡕࡓࡗࡥࡌࡊࡐࡈࡗࠬढ")
ZLwoRpfnCWI7FgEHsz6te39lMVh = LZWMikPEB81KSGyxfJtUsCA(u"ࠨ࡞ࡱࠫण")
SGUiazdreo6QRKLOWZj5hMX = V3VlkhgjEF4n1erPXHcC0NOsfwyAJ(u"ࠩ࡟ࡶࠬत")
GLTtERWbHnFuy4PCp = LZWMikPEB81KSGyxfJtUsCA(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭थ")
ZZNnyCzhaQugG = kYDaz79TFlXoR(u"࠶੢")
fXsOF5ev9LMnDNR3Ua0C6 = DaFZHsThGmd0zv6e(u"࠶࠮࠶੣")
rr7Rv2YkSWmOMDXpjeVTw15zdq3ao = UUDAiytEL76RTmMYsuIz5evXB(u"࠱࠶੤")
pPGV0CcOoWtKmx9sLX1b5eSlNu = BRWqdruz2A0(u"࠴࠲੥")
VmkZc7d9MJjFPHWoRe5Nnzb = N3flV6EJsD5CzS(u"࠳࠳੦")
NLnRHTxVrvWz = mmV2nucZ5Lpl6FO1JMPEqGoQKW(u"࠴࠶࠵੧")
RF2gx9SMq4EGThsHNaZV = [
						 zYvEaigKWjoq50pXBLDbGJkFc(u"ࠫࡑࡏࡂࡓࡃࡕ࡝࠲࡙ࡅࡏࡆࡢࡅࡓࡇࡌ࡚ࡖࡌࡇࡘࡥࡅࡗࡇࡑࡘࡘ࠳࠱ࡴࡶࠪद")
						,BRWqdruz2A0(u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡅ࡙ࡖࡕࡅࡈ࡚࡟ࡎ࠵ࡘ࠼࠲࠷ࡳࡵࠩध")
						,kYDaz79TFlXoR(u"࠭ࡌࡊࡄࡕࡅࡗ࡟࠭ࡓࡃࡑࡈࡔࡓ࡟ࡖࡕࡈࡖࡆࡍࡅࡏࡖ࠰࠵ࡸࡺࠧन")
						,ee86G9ladLHVbh5mikzCo(u"ࠧࡍࡋࡅࡖࡆࡘ࡙࠮ࡉࡈࡘࡤࡖࡒࡐ࡚ࡌࡉࡘࡥࡌࡊࡕࡗ࠱࠶ࡹࡴࠨऩ")
						,tQMjXKCA5dN4xq3beVIzaEoWkFLg(u"ࠨࡋࡓࡘ࡛࠳ࡃࡉࡇࡆࡏࡤࡇࡃࡄࡑࡘࡒ࡙࠳࠱ࡴࡶࠪप")
						,N3flV6EJsD5CzS(u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡋࡊࡕࡌࡐࡅࡄࡘࡎࡕࡎ࠮࠳ࡶࡸࠬफ")
						,V3VlkhgjEF4n1erPXHcC0NOsfwyAJ(u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡌࡕࡏࡈࡎࡈࡣࡓࡋࡗࡠࡊࡒࡗ࡙ࡔࡁࡎࡇ࠰࠵ࡸࡺࠧब")
						,DaFZHsThGmd0zv6e(u"ࠫࡑࡏࡂࡓࡃࡕ࡝࠲ࡍࡏࡐࡉࡏࡉࡤࡔࡅࡘࡡࡋࡓࡘ࡚ࡎࡂࡏࡈ࠱࠸ࡸࡤࠨभ")
						,V3VlkhgjEF4n1erPXHcC0NOsfwyAJ(u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡒࡆࡃࡇࡣࡆࡒࡌࡠࡃࡇࡈࡔࡔࡓࡠ࡚ࡐࡐ࠲࠷ࡳࡵࠩम")
						,aXqWLoTdVgME(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡊࡓࡔࡍࡌࡆࡗࡖࡉࡗࡉࡏࡏࡖࡈࡒ࡙࠳࠱ࡴࡶࠪय")
						,Ie5s2cBtSfdHjzQ4rA9kYlo6D18(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡆ࡞ࡖࡁࡔࡕࡢࡅࡐ࡝ࡁࡎࡡࡆࡅࡕ࡚ࡃࡉࡃ࠰࠷ࡷࡪࠧर")
						,LZWMikPEB81KSGyxfJtUsCA(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡇ࡟ࡐࡂࡕࡖࡣࡆࡑࡗࡂࡏࡢࡇࡆࡖࡔࡄࡊࡄ࠱࠺ࡺࡨࠨऱ")
						,tQMjXKCA5dN4xq3beVIzaEoWkFLg(u"ࠩࡈࡐࡈࡏࡎࡆࡏࡄ࠱ࡘࡋࡁࡓࡅࡋ࠱࠶ࡹࡴࠨल")
						,RlOvin8YIGC2KZXJPk9m0acrMobUex(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡘࡔࡊࡄࡖࡎࡔࡇ࠮࠳ࡶࡸࠬळ")
						,tR1krDGPpO025fghMT3a7UnYj(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࡙࠭ࡕࡋࡅࡗࡏࡎࡈ࠯࠵ࡲࡩ࠭ऴ")
						]
StyMGONai5UZ72p9hemjVv8CDW = RF2gx9SMq4EGThsHNaZV+[
				 iNc3KxwErnQ(u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡐࡓࡑ࡛࡝ࡤ࡚ࡅࡔࡖ࠰࠵ࡸࡺࠧव")
				,Ie5s2cBtSfdHjzQ4rA9kYlo6D18(u"࠭ࡌࡊࡄࡕࡅࡗ࡟࠭ࡐࡒࡈࡒ࡚ࡘࡌࡠࡊࡗࡘࡕ࡙ࡐࡓࡑ࡛ࡍࡊ࡙࠭࠲ࡵࡷࠫश")
				,sjtU6GZQg5XC2pH4(u"ࠧࡍࡋࡅࡖࡆࡘ࡙࠮ࡑࡓࡉࡓ࡛ࡒࡍࡡ࡚ࡉࡇࡖࡒࡐ࡚ࡌࡉࡘ࠳࠱ࡴࡶࠪष")
				,fWoVd0Bmtkx(u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡒࡔࡊࡔࡕࡓࡎࡢ࡛ࡊࡈࡐࡓࡑ࡛ࡍࡊ࡙࠭࠳ࡰࡧࠫस")
				,mmV2nucZ5Lpl6FO1JMPEqGoQKW(u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡓࡕࡋࡎࡖࡔࡏࡣ࡜ࡋࡂࡑࡔࡒ࡜࡞࡚ࡏ࠮࠳ࡶࡸࠬह")
				,sjtU6GZQg5XC2pH4(u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡔࡖࡅࡏࡗࡕࡐࡤ࡝ࡅࡃࡒࡕࡓ࡝࡟ࡔࡐ࠯࠵ࡲࡩ࠭ऺ")
				,qoBMmfAWpFlK70xw8ZRh4naJ(u"ࠫࡑࡏࡂࡓࡃࡕ࡝࠲ࡕࡐࡆࡐࡘࡖࡑࡥࡋࡑࡔࡒ࡜࡞ࡉࡏࡎ࠯࠴ࡷࡹ࠭ऻ")
				,qoBMmfAWpFlK70xw8ZRh4naJ(u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡏࡑࡇࡑ࡙ࡗࡒ࡟ࡌࡒࡕࡓ࡝࡟ࡃࡐࡏ࠰࠶ࡳࡪ़ࠧ")
				,viRJWOC5jsYe84(u"࠭ࡌࡊࡄࡕࡅࡗ࡟࠭ࡐࡒࡈࡒ࡚ࡘࡌࡠࡍࡓࡖࡔ࡞࡙ࡄࡑࡐ࠱࠸ࡸࡤࠨऽ")
				,IaBhDMJc17302LgSvyxd(u"ࠧࡍࡋࡅࡖࡆࡘ࡙࠮ࡅࡋࡉࡈࡑ࡟ࡉࡖࡗࡔࡘࡥࡐࡓࡑ࡛ࡍࡊ࡙࠭࠲ࡵࡷࠫा")
				,kYDaz79TFlXoR(u"ࠨࡕࡈࡖ࡛ࡏࡃࡆࡕ࠰ࡌ࡙࡚ࡐࡔࡡࡗࡉࡘ࡚࠭࠲ࡵࡷࠫि")
				,zYvEaigKWjoq50pXBLDbGJkFc(u"ࠩࡖࡉࡗ࡜ࡉࡄࡇࡖ࠱࡙ࡋࡓࡕࡡࡄࡐࡑࡥࡗࡆࡄࡖࡍ࡙ࡋࡓ࠮࠳ࡶࡸࠬी")
				,LZWMikPEB81KSGyxfJtUsCA(u"ࠪࡗࡊࡘࡖࡊࡅࡈࡗ࠲࡚ࡅࡔࡖࡢࡅࡑࡒ࡟ࡘࡇࡅࡗࡎ࡚ࡅࡔ࠯࠵ࡲࡩ࠭ु")
				,rNdBKI74fAklnoCZ6(u"ࠫࡘࡋࡒࡗࡋࡆࡉࡘ࠳ࡕࡔࡃࡊࡉࡤࡘࡅࡑࡑࡕࡘ࠲࠷ࡳࡵࠩू")
				,viRJWOC5jsYe84(u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡇࡐࡑࡊࡐࡊࡥࡔࡓࡃࡑࡗࡑࡇࡔࡆ࠯࠴ࡷࡹ࠭ृ")
				,V3VlkhgjEF4n1erPXHcC0NOsfwyAJ(u"࠭ࡌࡊࡄࡕࡅࡗ࡟࠭ࡓࡇ࡙ࡉࡗ࡙ࡏࡠࡖࡕࡅࡓ࡙ࡌࡂࡖࡈ࠱࠶ࡹࡴࠨॄ")
				]
GFErxOAcH5 = [
						 aXqWLoTdVgME(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰࡜ࡘࡎࡁࡓࡋࡑࡋ࠲࠷ࡳࡵࠩॅ")
						,N3flV6EJsD5CzS(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱࡝࡙ࡈࡂࡔࡌࡒࡌ࠳࠲࡯ࡦࠪॆ")
						,lljaEqwTVtmKsQcOrbXxS5hgNH(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡓࡕࡍࡖࡌࡣ࡝࡙ࡈࡂࡔࡌࡒࡌ࠳࠱ࡴࡶࠪे")
						]
v2ir6R7FZASfMOl4wqTLKBNupX5E = Y719atFWlPpbO6uTULjZf5VGD2o0
ppn5vq8QdBsEhckl = [DaFZHsThGmd0zv6e(u"ูࠪๆืࠧै"),Ie5s2cBtSfdHjzQ4rA9kYlo6D18(u"ࠫศ๎ไࠨॉ"),fWoVd0Bmtkx(u"ࠬัว็์ࠪॊ"),zYvEaigKWjoq50pXBLDbGJkFc(u"࠭หศๆฮࠫो"),YY8UDX3MJhb91AHw7fg(u"ࠧาษห฽ࠬौ"),Ie5s2cBtSfdHjzQ4rA9kYlo6D18(u"ࠨะส्ุ้࠭"),Ie5s2cBtSfdHjzQ4rA9kYlo6D18(u"ࠩึหิูࠧॎ"),YY8UDX3MJhb91AHw7fg(u"ࠪืฬฮูࠨॏ"),DiJ8CMuYH1daWyjehfN0L(u"ࠫะอๅ็ࠩॐ"),c2RKu0xG1eC8MiohyE(u"ࠬะวิ฻ࠪ॑"),kYDaz79TFlXoR(u"ู࠭ศึิ॒ࠫ")]
niLNz4Iw9uqX6DW15Kh = kYDaz79TFlXoR(u"࠺࠵੨")
Yz7BvqTS1wVGPey0XlojpUh5 = aXqWLoTdVgME(u"࠻࠶੩")*niLNz4Iw9uqX6DW15Kh
nzubSpWFkex4JjGqEYr = l32dnTEOU1skGKqeBtI9hmo(u"࠸࠴੪")*Yz7BvqTS1wVGPey0XlojpUh5
gJmERQiCYqTHWhn3GpaLj9eFt2 = zYvEaigKWjoq50pXBLDbGJkFc(u"࠳࠱੫")*nzubSpWFkex4JjGqEYr
dzcNuIbsgK3yZ6SXGaEHPfOj5vk = vvXoMLlg513
K6imQHZDCI9pewE = LZWMikPEB81KSGyxfJtUsCA(u"࠴࠲੬")*niLNz4Iw9uqX6DW15Kh
rGY36xBwT1bLZAngSfcWEIeXdQVNij = Zwqio2AIWlD5etFa*Yz7BvqTS1wVGPey0XlojpUh5
kUz8c7OqsxuPFIGfwg = rNdBKI74fAklnoCZ6(u"࠳࠹੭")*Yz7BvqTS1wVGPey0XlojpUh5
KOyPvpEztYLaZRdMQJWxfTNFHbkg = DAE6vkyhXGx1wBdHmcFfTVQpL0l*nzubSpWFkex4JjGqEYr
IZVKS7o3q0 = UVa3fJw7k6KM(u"࠶࠴੮")*nzubSpWFkex4JjGqEYr
ivLg9zRnGF83u = qqzwE6imYG4c2xojI(u"࠵࠷੯")*gJmERQiCYqTHWhn3GpaLj9eFt2
FeUDj5b2oEV = Yz7BvqTS1wVGPey0XlojpUh5
q8mKozt9e5LY = [Ie5s2cBtSfdHjzQ4rA9kYlo6D18(u"ࠧࡃࡑࡎࡖࡆ࠭॓"),IaBhDMJc17302LgSvyxd(u"ࠨࡒࡄࡒࡊ࡚ࠧ॔"),ddiCzu6yahj5RtTISMJ48sNnZBU(u"ࠩࡄࡖࡆࡈࡉࡄࡖࡒࡓࡓ࡙ࠧॕ"),qoBMmfAWpFlK70xw8ZRh4naJ(u"ࠪࡏࡆࡘࡂࡂࡎࡄࡘ࡛࠭ॖ"),ddiCzu6yahj5RtTISMJ48sNnZBU(u"ࠫࡎࡌࡉࡍࡏࠪॗ"),UVa3fJw7k6KM(u"ࠬࡏࡆࡊࡎࡐ࠱ࡆࡘࡁࡃࡋࡆࠫक़"),dJHDqiKf12TXlIzSLkGUuxg4MBs3A(u"࠭ࡉࡇࡋࡏࡑ࠲ࡋࡎࡈࡎࡌࡗࡍ࠭ख़")]
q8mKozt9e5LY += [IaBhDMJc17302LgSvyxd(u"࡚ࠧࡖࡅࡣࡈࡎࡁࡏࡐࡈࡐࡘ࠭ग़"),CC1eY6yWZUwf2TkRvnp7EJ0AimjHBX(u"ࠨࡃࡎࡓࡆࡓࠧज़"),dJHDqiKf12TXlIzSLkGUuxg4MBs3A(u"ࠩࡄࡏ࡜ࡇࡍࠨड़"),N3flV6EJsD5CzS(u"ࠪࡅࡑࡓࡁࡂࡔࡈࡊࠬढ़"),qoBMmfAWpFlK70xw8ZRh4naJ(u"ࠫࡘࡎࡏࡐࡈࡐࡅ࡝࠭फ़")]
fDbvpTVAHrwI = [kYDaz79TFlXoR(u"ࠬࡒࡁࡓࡑ࡝ࡅࠬय़"),UUDAiytEL76RTmMYsuIz5evXB(u"࠭ࡆࡂࡌࡈࡖࡘࡎࡏࡘࠩॠ"),qoBMmfAWpFlK70xw8ZRh4naJ(u"ࠧࡕࡘࡉ࡙ࡓ࠭ॡ"),DiJ8CMuYH1daWyjehfN0L(u"ࠨࡎࡒࡈ࡞ࡔࡅࡕࠩॢ"),YY8UDX3MJhb91AHw7fg(u"ࠩࡆࡍࡒࡇࡎࡐ࡙ࠪॣ"),mmV2nucZ5Lpl6FO1JMPEqGoQKW(u"ࠪࡗࡍࡇࡈࡊࡆࡑࡉ࡜࡙ࠧ।"),aXqWLoTdVgME(u"ࠫࡆࡘࡁࡃࡕࡈࡉࡉ࠭॥")]
fDbvpTVAHrwI += [dJHDqiKf12TXlIzSLkGUuxg4MBs3A(u"ࠬࡉࡉࡎࡃࡆࡐ࡚ࡈࠧ०"),qqzwE6imYG4c2xojI(u"࠭ࡓࡉࡃࡋࡍࡉ࠺ࡕࠨ१"),LZWMikPEB81KSGyxfJtUsCA(u"ࠧࡔࡊࡒࡊࡍࡇࠧ२"),ee86G9ladLHVbh5mikzCo(u"ࠨ࡙ࡈࡇࡎࡓࡁ࠲ࠩ३"),lljaEqwTVtmKsQcOrbXxS5hgNH(u"࡚ࠩࡉࡈࡏࡍࡂ࠴ࠪ४")]
dIyDKYvkWTUwNrq64Jz = [zYvEaigKWjoq50pXBLDbGJkFc(u"ࠪࡘࡎࡑࡁࡂࡖࠪ५"),V3VlkhgjEF4n1erPXHcC0NOsfwyAJ(u"ࠫࡆ࡟ࡌࡐࡎࠪ६"),kYDaz79TFlXoR(u"ࠬࡌࡏࡔࡖࡄࠫ७"),V3VlkhgjEF4n1erPXHcC0NOsfwyAJ(u"࠭ࡆࡂࡄࡕࡅࡐࡇࠧ८"),RlOvin8YIGC2KZXJPk9m0acrMobUex(u"࡚ࠧࡃࡔࡓ࡙࠭९"),LZWMikPEB81KSGyxfJtUsCA(u"ࠨࡕࡋࡅࡇࡇࡋࡂࡖ࡜ࠫ॰"),c2RKu0xG1eC8MiohyE(u"࡙ࠩࡅࡗࡈࡏࡏࠩॱ"),V3VlkhgjEF4n1erPXHcC0NOsfwyAJ(u"ࠪࡆࡗ࡙ࡔࡆࡌࠪॲ")]
dIyDKYvkWTUwNrq64Jz += [qqzwE6imYG4c2xojI(u"ࠫࡐࡏࡒࡎࡃࡏࡏࠬॳ"),IaBhDMJc17302LgSvyxd(u"ࠬࡇࡎࡊࡏࡈ࡞ࡎࡊࠧॴ"),viRJWOC5jsYe84(u"࠭ࡆࡂࡔࡈࡗࡐࡕࠧॵ"),qoBMmfAWpFlK70xw8ZRh4naJ(u"ࠧࡉࡃࡏࡅࡈࡏࡍࡂࠩॶ"),c2RKu0xG1eC8MiohyE(u"ࠨࡃࡏࡑࡘ࡚ࡂࡂࠩॷ"),LZWMikPEB81KSGyxfJtUsCA(u"ࠩࡖࡌࡔࡕࡆࡏࡇࡗࠫॸ"),CC1eY6yWZUwf2TkRvnp7EJ0AimjHBX(u"ࠪࡈࡗࡇࡍࡂࡕ࠺ࠫॹ")]
dIyDKYvkWTUwNrq64Jz += [CC1eY6yWZUwf2TkRvnp7EJ0AimjHBX(u"ࠫࡈࡏࡍࡂࡈࡕࡉࡊ࠭ॺ"),LZWMikPEB81KSGyxfJtUsCA(u"ࠬࡉࡉࡎࡃࡉࡅࡓ࡙ࠧॻ"),DiJ8CMuYH1daWyjehfN0L(u"࠭ࡅࡍࡋࡉ࡚ࡎࡊࡅࡐࠩॼ"),DaFZHsThGmd0zv6e(u"ࠧࡇࡗࡑࡓࡓ࡚ࡖࠨॽ"),dJHDqiKf12TXlIzSLkGUuxg4MBs3A(u"ࠨࡅࡌࡑࡆࡒࡉࡈࡊࡗࠫॾ"),N3flV6EJsD5CzS(u"ࠩࡆࡍࡒࡇ࠴࠱࠲ࠪॿ"),DaFZHsThGmd0zv6e(u"ࠪࡇࡎࡓࡁࡂࡄࡇࡓࠬঀ")]
dIyDKYvkWTUwNrq64Jz += [BRWqdruz2A0(u"ࠫࡆࡑࡗࡂࡏࡗ࡙ࡇࡋࠧঁ"),c2RKu0xG1eC8MiohyE(u"ࠬࡓࡁࡔࡃ࡙ࡍࡉࡋࡏࠨং"),mmV2nucZ5Lpl6FO1JMPEqGoQKW(u"࠭ࡄࡓࡃࡐࡅࡈࡇࡆࡆࠩঃ"),DiJ8CMuYH1daWyjehfN0L(u"ࠧࡇࡗࡖࡌࡆࡘࡔࡗࠩ঄"),qqzwE6imYG4c2xojI(u"ࠨࡅࡌࡑࡆ࡝ࡂࡂࡕࠪঅ"),DaFZHsThGmd0zv6e(u"ࠩࡄࡌ࡜ࡇࡋࠨআ"),fWoVd0Bmtkx(u"ࠪࡊࡆ࡙ࡅࡍࡊࡇ࠶ࠬই"),l1DZAt9XNQjqE7YOdrz(u"࡛ࠫࡏࡄࡆࡑࡑࡗࡆࡋࡍࠨঈ")]
dIyDKYvkWTUwNrq64Jz += [BRWqdruz2A0(u"ࠬࡑࡁࡕࡍࡒࡘ࡙࡜ࠧউ"),lljaEqwTVtmKsQcOrbXxS5hgNH(u"࠭ࡓࡆࡔࡌࡉࡘ࡚ࡉࡎࡇࠪঊ"),fWoVd0Bmtkx(u"ࠧࡇࡗࡖࡌࡆࡘࡖࡊࡆࡈࡓࠬঋ"),zYvEaigKWjoq50pXBLDbGJkFc(u"ࠨࡅࡌࡑࡆ࠺ࡐࠨঌ"),dJHDqiKf12TXlIzSLkGUuxg4MBs3A(u"ࠩࡈࡋ࡞ࡈࡅࡔࡖ࠴ࠫ঍"),viRJWOC5jsYe84(u"ࠪࡗࡍࡇࡈࡊࡆ࠷࡙࠷࠭঎"),ee86G9ladLHVbh5mikzCo(u"ࠫࡊࡍ࡙ࡃࡇࡖࡘ࠷࠭এ"),YY8UDX3MJhb91AHw7fg(u"ࠬࡋࡇ࡚ࡄࡈࡗ࡙࠺ࠧঐ")]
UG9KxE31oNn = [BRWqdruz2A0(u"࡙࠭ࡐࡗࡗ࡙ࡇࡋࠧ঑"),zYvEaigKWjoq50pXBLDbGJkFc(u"࡚ࠧࡑࡘࡘ࡚ࡈࡅ࠮ࡘࡌࡈࡊࡕࡓࠨ঒"),DiJ8CMuYH1daWyjehfN0L(u"ࠨ࡛ࡒ࡙࡙࡛ࡂࡆ࠯ࡓࡐࡆ࡟ࡌࡊࡕࡗࡗࠬও"),DaFZHsThGmd0zv6e(u"ࠩ࡜ࡓ࡚࡚ࡕࡃࡇ࠰ࡇࡍࡇࡎࡏࡇࡏࡗࠬঔ")]
UG9KxE31oNn += [sjtU6GZQg5XC2pH4(u"ࠪࡈࡆࡏࡌ࡚ࡏࡒࡘࡎࡕࡎࠨক"),qqzwE6imYG4c2xojI(u"ࠫࡉࡇࡉࡍ࡛ࡐࡓ࡙ࡏࡏࡏ࠯࡙ࡍࡉࡋࡏࡔࠩখ"),tQMjXKCA5dN4xq3beVIzaEoWkFLg(u"ࠬࡊࡁࡊࡎ࡜ࡑࡔ࡚ࡉࡐࡐ࠰ࡔࡑࡇ࡙ࡍࡋࡖࡘࡘ࠭গ"),UUDAiytEL76RTmMYsuIz5evXB(u"࠭ࡄࡂࡋࡏ࡝ࡒࡕࡔࡊࡑࡑ࠱ࡈࡎࡁࡏࡐࡈࡐࡘ࠭ঘ"),dJHDqiKf12TXlIzSLkGUuxg4MBs3A(u"ࠧࡅࡃࡌࡐ࡞ࡓࡏࡕࡋࡒࡒ࠲ࡒࡉࡗࡇࡖࠫঙ"),tQMjXKCA5dN4xq3beVIzaEoWkFLg(u"ࠨࡆࡄࡍࡑ࡟ࡍࡐࡖࡌࡓࡓ࠳ࡈࡂࡕࡋࡘࡆࡍࡓࠨচ")]
YJtxGoaiQlSndzECbOrRWLjhk = [tR1krDGPpO025fghMT3a7UnYj(u"ࠩࡓࡖࡎ࡜ࡁࡕࡇࠪছ")]+q8mKozt9e5LY+[qqzwE6imYG4c2xojI(u"ࠪࡑࡎ࡞ࡅࡅࠩজ")]+fDbvpTVAHrwI+[DaFZHsThGmd0zv6e(u"ࠫࡕ࡛ࡂࡍࡋࡆࠫঝ")]+dIyDKYvkWTUwNrq64Jz+[iNc3KxwErnQ(u"ࠬࡖࡒࡊࡘࡄࡘࡊ࠭ঞ")]+UG9KxE31oNn
dsNPY2j9TZ8aODfqUr = [YY8UDX3MJhb91AHw7fg(u"࡙࠭ࡕࡄࡢࡇࡍࡇࡎࡏࡇࡏࡗࠬট")]
VwEp51MQkbyU03vJKOrD49Ht = [IaBhDMJc17302LgSvyxd(u"ࠧࡑࡔࡌ࡚ࡆ࡚ࡅࠨঠ"),Ie5s2cBtSfdHjzQ4rA9kYlo6D18(u"ࠨࡏࡌ࡜ࡊࡊࠧড"),rNdBKI74fAklnoCZ6(u"ࠩࡓ࡙ࡇࡒࡉࡄࠩঢ")]
zzTfFElKxk = [ee86G9ladLHVbh5mikzCo(u"ࠪࡑ࠸࡛ࠧণ"),ee86G9ladLHVbh5mikzCo(u"ࠫࡎࡖࡔࡗࠩত"),zYvEaigKWjoq50pXBLDbGJkFc(u"ࠬࡊࡁࡊࡎ࡜ࡑࡔ࡚ࡉࡐࡐࠪথ"),dJHDqiKf12TXlIzSLkGUuxg4MBs3A(u"࠭ࡉࡇࡋࡏࡑࠬদ"),l32dnTEOU1skGKqeBtI9hmo(u"࡚ࠧࡑࡘࡘ࡚ࡈࡅࠨধ")]
zzcjaVvxw7QS  = [zYvEaigKWjoq50pXBLDbGJkFc(u"ࠨࡆࡄࡍࡑ࡟ࡍࡐࡖࡌࡓࡓ࠳ࡖࡊࡆࡈࡓࡘ࠭ন"),aXqWLoTdVgME(u"ࠩࡇࡅࡎࡒ࡙ࡎࡑࡗࡍࡔࡔ࠭ࡑࡎࡄ࡝ࡑࡏࡓࡕࡕࠪ঩"),rNdBKI74fAklnoCZ6(u"ࠪࡈࡆࡏࡌ࡚ࡏࡒࡘࡎࡕࡎ࠮ࡅࡋࡅࡓࡔࡅࡍࡕࠪপ"),dJHDqiKf12TXlIzSLkGUuxg4MBs3A(u"ࠫࡉࡇࡉࡍ࡛ࡐࡓ࡙ࡏࡏࡏ࠯ࡏࡍ࡛ࡋࡓࠨফ"),DiJ8CMuYH1daWyjehfN0L(u"ࠬࡊࡁࡊࡎ࡜ࡑࡔ࡚ࡉࡐࡐ࠰ࡌࡆ࡙ࡈࡕࡃࡊࡗࠬব")]
zzcjaVvxw7QS += [BRWqdruz2A0(u"࠭ࡉࡇࡋࡏࡑ࠲ࡇࡒࡂࡄࡌࡇࠬভ"),viRJWOC5jsYe84(u"ࠧࡊࡈࡌࡐࡒ࠳ࡅࡏࡉࡏࡍࡘࡎࠧম")]
zzcjaVvxw7QS += [viRJWOC5jsYe84(u"ࠨ࡛ࡒ࡙࡙࡛ࡂࡆ࠯࡙ࡍࡉࡋࡏࡔࠩয"),V3VlkhgjEF4n1erPXHcC0NOsfwyAJ(u"ࠩ࡜ࡓ࡚࡚ࡕࡃࡇ࠰ࡔࡑࡇ࡙ࡍࡋࡖࡘࡘ࠭র"),sjtU6GZQg5XC2pH4(u"ࠪ࡝ࡔ࡛ࡔࡖࡄࡈ࠱ࡈࡎࡁࡏࡐࡈࡐࡘ࠭঱")]
zzcjaVvxw7QS += [iNc3KxwErnQ(u"ࠫࡎࡖࡔࡗ࠯ࡏࡍ࡛ࡋࠧল"),rNdBKI74fAklnoCZ6(u"ࠬࡏࡐࡕࡘ࠰ࡑࡔ࡜ࡉࡆࡕࠪ঳"),viRJWOC5jsYe84(u"࠭ࡉࡑࡖ࡙࠱ࡘࡋࡒࡊࡇࡖࠫ঴")]
zzcjaVvxw7QS += [CC1eY6yWZUwf2TkRvnp7EJ0AimjHBX(u"ࠧࡎ࠵ࡘ࠱ࡑࡏࡖࡆࠩ঵"),zYvEaigKWjoq50pXBLDbGJkFc(u"ࠨࡏ࠶࡙࠲ࡓࡏࡗࡋࡈࡗࠬশ"),tQMjXKCA5dN4xq3beVIzaEoWkFLg(u"ࠩࡐ࠷࡚࠳ࡓࡆࡔࡌࡉࡘ࠭ষ")]
MEo67e4ikJXTyGb0IaBqsVdpWRgz = list(filter(lambda JcIrh6UxaoESylX92fj: JcIrh6UxaoESylX92fj not in zzcjaVvxw7QS+dsNPY2j9TZ8aODfqUr+VwEp51MQkbyU03vJKOrD49Ht+zzTfFElKxk,YJtxGoaiQlSndzECbOrRWLjhk))
OOaSbLh4fmdBoy95V = MEo67e4ikJXTyGb0IaBqsVdpWRgz+zzTfFElKxk
cmEHgQpO5f1tDrx4CJdz = MEo67e4ikJXTyGb0IaBqsVdpWRgz+zzcjaVvxw7QS
z7mEAQFSD5datXURwNgOkIiG1 = cmEHgQpO5f1tDrx4CJdz+dsNPY2j9TZ8aODfqUr
F19lhKQpNHsdr0ak7TOn = OOaSbLh4fmdBoy95V+dsNPY2j9TZ8aODfqUr
wVue619XFmz5jUdCPK = [l1DZAt9XNQjqE7YOdrz(u"ࠪࡅࡐࡕࡁࡎࠩস"),qqzwE6imYG4c2xojI(u"ࠫࡆࡑࡗࡂࡏࠪহ"),tQMjXKCA5dN4xq3beVIzaEoWkFLg(u"ࠬࡏࡆࡊࡎࡐࠫ঺"),fWoVd0Bmtkx(u"࠭ࡋࡂࡔࡅࡅࡑࡇࡔࡗࠩ঻"),l1DZAt9XNQjqE7YOdrz(u"ࠧࡂࡎࡐࡅࡆࡘࡅࡇ়ࠩ"),c2RKu0xG1eC8MiohyE(u"ࠨࡕࡋࡓࡔࡌࡍࡂ࡚ࠪঽ"),kYDaz79TFlXoR(u"ࠩࡖࡌࡎࡇࡖࡐࡋࡆࡉࠬা"),DaFZHsThGmd0zv6e(u"ࠪ࡝ࡔ࡛ࡔࡖࡄࡈࠫি"),DiJ8CMuYH1daWyjehfN0L(u"ࠫࡉࡇࡉࡍ࡛ࡐࡓ࡙ࡏࡏࡏࠩী"),viRJWOC5jsYe84(u"ࠬࡓ࠳ࡖࠩু"),V3VlkhgjEF4n1erPXHcC0NOsfwyAJ(u"࠭ࡉࡑࡖ࡙ࠫূ"),fWoVd0Bmtkx(u"ࠧࡃࡑࡎࡖࡆ࠭ৃ"),qqzwE6imYG4c2xojI(u"ࠨࡇࡏࡇࡎࡔࡅࡎࡃࠪৄ"),c2RKu0xG1eC8MiohyE(u"ࠩࡄࡖࡆࡈࡉࡄࡖࡒࡓࡓ࡙ࠧ৅")]
NOT_TO_TEST_ALL_SERVERS = [tR1krDGPpO025fghMT3a7UnYj(u"ࠪࡣࡆࡑࡏࡠࠩ৆"),N3flV6EJsD5CzS(u"ࠫࡤࡇࡋࡘࡡࠪে"),qoBMmfAWpFlK70xw8ZRh4naJ(u"ࠬࡥࡉࡇࡎࡢࠫৈ"),Ie5s2cBtSfdHjzQ4rA9kYlo6D18(u"࠭࡟ࡌࡔࡅࡣࠬ৉"),UUDAiytEL76RTmMYsuIz5evXB(u"ࠧࡠࡏࡕࡊࡤ࠭৊"),CC1eY6yWZUwf2TkRvnp7EJ0AimjHBX(u"ࠨࡡࡖࡌࡒࡥࠧো"),DiJ8CMuYH1daWyjehfN0L(u"ࠩࡢࡗࡍ࡜࡟ࠨৌ"),tR1krDGPpO025fghMT3a7UnYj(u"ࠪࡣ࡞࡛ࡔࡠ্ࠩ"),fWoVd0Bmtkx(u"ࠫࡤࡊࡌࡎࡡࠪৎ"),c2RKu0xG1eC8MiohyE(u"ࠬࡥࡍࡖࠩ৏"),sjtU6GZQg5XC2pH4(u"࠭࡟ࡊࡒࠪ৐"),zYvEaigKWjoq50pXBLDbGJkFc(u"ࠧࡠࡄࡎࡖࡤ࠭৑"),DaFZHsThGmd0zv6e(u"ࠨࡡࡈࡐࡈࡥࠧ৒"),viRJWOC5jsYe84(u"ࠩࡢࡅࡗ࡚࡟ࠨ৓")]
VVjT7GrRWSqHOsFkZxlYUNLdJn = [c2RKu0xG1eC8MiohyE(u"ࠪࡑࡊࡔࡕࡠࡔࡈ࡚ࡊࡘࡓࡆࡆࡢࡔࡊࡘࡍࠨ৔"),l32dnTEOU1skGKqeBtI9hmo(u"ࠫࡒࡋࡎࡖࡡࡄࡗࡈࡋࡎࡅࡇࡇࡣࡕࡋࡒࡎࠩ৕"),CC1eY6yWZUwf2TkRvnp7EJ0AimjHBX(u"ࠬࡓࡅࡏࡗࡢࡈࡊ࡙ࡃࡆࡐࡇࡉࡉࡥࡐࡆࡔࡐࠫ৖"),DiJ8CMuYH1daWyjehfN0L(u"࠭ࡍࡆࡐࡘࡣࡗࡇࡎࡅࡑࡐࡍ࡟ࡋࡄࡠࡒࡈࡖࡒ࠭ৗ"),l32dnTEOU1skGKqeBtI9hmo(u"ࠧࡎࡇࡑ࡙ࡤࡘࡅࡗࡇࡕࡗࡊࡊ࡟ࡕࡇࡐࡔࠬ৘"),rNdBKI74fAklnoCZ6(u"ࠨࡏࡈࡒ࡚ࡥࡁࡔࡅࡈࡒࡉࡋࡄࡠࡖࡈࡑࡕ࠭৙"),ddiCzu6yahj5RtTISMJ48sNnZBU(u"ࠩࡐࡉࡓ࡛࡟ࡅࡇࡖࡇࡊࡔࡄࡆࡆࡢࡘࡊࡓࡐࠨ৚"),zYvEaigKWjoq50pXBLDbGJkFc(u"ࠪࡑࡊࡔࡕࡠࡔࡄࡒࡉࡕࡍࡊ࡜ࡈࡈࡤ࡚ࡅࡎࡒࠪ৛")]
DnrCWYzGsj2mB6O = [vvXoMLlg513,BRWqdruz2A0(u"࠶࠻࠰ੰ"),iNc3KxwErnQ(u"࠷࠶࠱੿"),UVa3fJw7k6KM(u"࠳࠺࠴ં"),CC1eY6yWZUwf2TkRvnp7EJ0AimjHBX(u"࠶࠿࠰੷"),zYvEaigKWjoq50pXBLDbGJkFc(u"࠳࠸࠳੺"),c2RKu0xG1eC8MiohyE(u"࠷࠾࠰੾"),viRJWOC5jsYe84(u"࠹࠳࠱੸"),dJHDqiKf12TXlIzSLkGUuxg4MBs3A(u"࠵࠷࠴੻"),qqzwE6imYG4c2xojI(u"࠺࠱࠱ੱ"),c2RKu0xG1eC8MiohyE(u"࠶࠲࠳ઁ"),qoBMmfAWpFlK70xw8ZRh4naJ(u"࠹࠷࠶੶"),iNc3KxwErnQ(u"࠹࠸࠶੽"),iNc3KxwErnQ(u"࠵࠵࠲੹"),UUDAiytEL76RTmMYsuIz5evXB(u"࠷࠷࠲઀"),kYDaz79TFlXoR(u"࠴࠴࠶࠶ੵ"),IaBhDMJc17302LgSvyxd(u"࠻࠼࠽࠵ੴ"),lljaEqwTVtmKsQcOrbXxS5hgNH(u"࠱࠱࠴࠳ੲ"),kYDaz79TFlXoR(u"࠲࠲࠻࠴ੳ"),UUDAiytEL76RTmMYsuIz5evXB(u"࠴࠵࠵࠶੼")]
zX5fB2MikIobqGhF = [mmV2nucZ5Lpl6FO1JMPEqGoQKW(u"ࠫ࠷࠻࠴ࡥࡦ࠶ࡥ࠹࠶࠹ࡥ࠺ࡥ࠺࠽࠷ࡤ࠵ࡧ࠴࠵࠼࡫ࡥ࠸࠺ࡦࡩࡧ࡬࠲࠺ࠩড়"),ee86G9ladLHVbh5mikzCo(u"ࠬ࠷࠵࠱ࡦ࠵࠶࡫࠷࠭ࡤ࠷࠻ࡥ࠲࠺࠰࠳࠳࠰ࡥࡦ࠾࠴࠮ࡧ࠼࠶࠸ࡩࡡࡧ࠺࠸࠼࠸࠺ࠧঢ়"),RlOvin8YIGC2KZXJPk9m0acrMobUex(u"࠭࠳࠺࠻࠴ࡩ࠾ࡩ࠵࠮࠹ࡨࡩ࠸࠳࠴ࡦࡧ࠵࠱࠽࠺ࡣ࠱࠯ࡩࡨ࠼࠿࠲ࡣࡣࡧࡨ࠸ࡪ࠵ࠨ৞"),mmV2nucZ5Lpl6FO1JMPEqGoQKW(u"ࠧ࠸࠸ࡥ࠸࡫ࡩ࠳࠵ࡨࡦࡨ࠶࠿ࡤ࠺ࡥ࠸࠹ࡦ࠷࠵ࡧ࠵࠹࠴࠹ࡩࡤ࠺࠳࠷ࡧࠬয়"),iNc3KxwErnQ(u"ࠨ࠳࡙ࡒࡸࡓࡴࡍ࠳ࡲࡆࡗ࡞࡫ࡔࡐࡆࡦࡈࡓࡊ࠲ࡍ࡛࡝ࡏࡰࡪ࠱ࡦ࡭࡞ࡼ࠭ৠ"),sjtU6GZQg5XC2pH4(u"ࠩࡤ࠸࡫࠽ࡦࡣ࠳࠷࠱࠷ࡪࡥࡧ࠯࠷࠴࠼࠷࠭࠹࠸࠷ࡦ࠲࠸࠲ࡦ࠵࠵࠺࠹ࡪ࠴ࡥࡦࡦࠫৡ"),rNdBKI74fAklnoCZ6(u"ࠪ࠶ࡧ࠹࠴࠱ࡣ࠹࠼࠾࠶ࡡ࠶࠶࠳࠵ࡩࡨࡣ࠴࠹࠵ࡧ࠶࠷࠴࠶ࡦ࠼࠺࠷࡫࠸ࠨৢ"),BRWqdruz2A0(u"ࠫࡨࡩ࠲࠷࠵ࡤࡦ࠶࡫࠵࠱࠶࠷ࡨ࠷ࡩࡡ࠶ࡦ࠸ࡨ࠸࡬࠹ࡦ࠵ࡦ࠷࠽࠼ࡥࡤࡣ࠴࠵࠵࠾࠳࠹࠻ࡤ࠻࠸࠭ৣ"),qqzwE6imYG4c2xojI(u"ࠬ࠷ࡣ࠴ࡦ࠶ࡥࡪ࠷࠸࠶ࡦࡩ࠸ࡧ࡬࠶ࡢࡨ࠸࠷࠸ࡩ࠷࠱࠶࠳ࡦ࠸࠺࠷ࡤ࠻ࡨ࠽࠾ࡨࡥ࠵࠸࠹ࡥࡪ࠿ࠧ৤"),qqzwE6imYG4c2xojI(u"࠭࠴࠵ࡨ࠷࠴࠽ࡪ࠴ࡢ࠴ࡰࡷ࡭࠷ࡢ࠴ࡤࡧ࠸࠾ࡧ࠶࠵࠺࠴࠻࡫࠻ࡰ࠲࠲࠴࠴࠸࡬ࡪࡴࡰ࠷ࡥ࠹࠷࠷ࡧࡥ࠸࠷࠵࠺࠲ࠨ৥"),aXqWLoTdVgME(u"ࠧࡣࡤ࠸࠷࠽࠷࠸࠱࠯࠸ࡨ࠶ࡧ࠭࠵ࡥ࠵࠺࠲ࡧࡢ࠷ࡤ࠰࠵࠻ࡨࡢ࠳࠶ࡥ࠺࠾ࡩ࠸ࡢ࠯࠳࠴࠲࠷ࡶ࠶࠻ࡤ࡬࠷࠻ࡱ࠲ࡣ࠹࠴ࠬ০"),DaFZHsThGmd0zv6e(u"ࠨࡨ࠼ࡪ࠽࠷࠷࠸࠶࠰ࡥࡧ࠿࠸࠮࠶࠴ࡨ࠷࠳࠸࠸࠲ࡧ࠱࠻࠸࠵ࡣ࠺࠷࠺࠺࠸࠵࠴࠳࠰࠴࠵࠳࠱࡮࡫ࡦ࠸ࡩ࡫࡬࡭ࡩࡦࡦࡷ࠭১")]
LbyIPAqK30FY6wJQ9Dosch = [dJHDqiKf12TXlIzSLkGUuxg4MBs3A(u"ࠩࡶࡧࡷࡧࡰࡦࡱࡳࡷࠬ২"),sjtU6GZQg5XC2pH4(u"ࠪࡷࡨࡸࡡࡱࡧࡵࡥࡵ࡯ࠧ৩"),BRWqdruz2A0(u"ࠫࡸࡩࡲࡢࡲ࡬ࡲ࡬ࡧ࡮ࡵࠩ৪"),l1DZAt9XNQjqE7YOdrz(u"ࠬࡹࡣࡳࡣࡳ࡭ࡳ࡭ࡲࡰࡤࡲࡸࠬ৫"),rNdBKI74fAklnoCZ6(u"࠭ࡳࡤࡴࡤࡴࡪࡻࡰࠨ৬"),CC1eY6yWZUwf2TkRvnp7EJ0AimjHBX(u"ࠧࡴࡥࡵࡥࡵ࡫࠮ࡥࡱࠪ৭"),sjtU6GZQg5XC2pH4(u"ࠨࡴࡤࡴ࡮ࡪࡡࡱ࡫࠱ࡧࡴࡳࠧ৮"),N3flV6EJsD5CzS(u"ࠩࡵࡩࡵࡲࡩࡵ࠰ࡧࡩࡻ࠭৯"),LZWMikPEB81KSGyxfJtUsCA(u"ࠪ࠵࠷࠽࠮࠱࠰࠳࠲࠶࠭ৰ"),UVa3fJw7k6KM(u"ࠫࡸ࡫ࡲࡷࡧࡵ࠶࠳ࡱ࡯ࡥ࡫ࡨࡱࡦࡪࠧৱ")]
MsFV8uBxOcW = {
	 iNc3KxwErnQ(u"࡙ࠬࡅࡓࡘࡌࡇࡊ࡙࡟࠱ࠩ৲")	: vvXoMLlg513
	,c2RKu0xG1eC8MiohyE(u"࠭ࡁࡍࡃࡕࡅࡇ࠭৳")		: ddiCzu6yahj5RtTISMJ48sNnZBU(u"࠴࠴ઃ")
	,qoBMmfAWpFlK70xw8ZRh4naJ(u"ࠧࡊࡈࡌࡐࡒ࠭৴")		: mmV2nucZ5Lpl6FO1JMPEqGoQKW(u"࠶࠵઄")
	,tQMjXKCA5dN4xq3beVIzaEoWkFLg(u"ࠨࡒࡄࡒࡊ࡚ࠧ৵")		: qoBMmfAWpFlK70xw8ZRh4naJ(u"࠸࠶અ")
	,Ie5s2cBtSfdHjzQ4rA9kYlo6D18(u"ࠩࡄࡐࡒࡇࡁࡓࡇࡉࠫ৶")		: rNdBKI74fAklnoCZ6(u"࠺࠰આ")
	,DaFZHsThGmd0zv6e(u"ࠪࡗࡍࡕࡏࡇࡏࡄ࡜ࠬ৷")		: tQMjXKCA5dN4xq3beVIzaEoWkFLg(u"࠵࠱ઇ")
	,viRJWOC5jsYe84(u"ࠫࡆࡒࡆࡂࡖࡌࡑࡎ࠭৸")		: Ie5s2cBtSfdHjzQ4rA9kYlo6D18(u"࠷࠲ઈ")
	,mmV2nucZ5Lpl6FO1JMPEqGoQKW(u"ࠬࡇࡋࡐࡃࡐࠫ৹")		: DiJ8CMuYH1daWyjehfN0L(u"࠹࠳ઉ")
	,viRJWOC5jsYe84(u"࠭ࡈࡂࡎࡄࡇࡎࡓࡁࠨ৺")		: viRJWOC5jsYe84(u"࠻࠴ઊ")
	,c2RKu0xG1eC8MiohyE(u"ࠧࡄࡋࡐࡅࡋࡇࡎࡔࠩ৻")		: ee86G9ladLHVbh5mikzCo(u"࠽࠵ઋ")
	,zYvEaigKWjoq50pXBLDbGJkFc(u"ࠨࡎࡌ࡚ࡊ࡚ࡖࠨৼ")		: kYDaz79TFlXoR(u"࠶࠶࠰ઌ")
	,qoBMmfAWpFlK70xw8ZRh4naJ(u"ࠩࡖࡌࡆࡎࡉࡅ࠶ࡘࠫ৽")		: RlOvin8YIGC2KZXJPk9m0acrMobUex(u"࠷࠱࠱ઍ")
	,ee86G9ladLHVbh5mikzCo(u"ࠪࡉࡌ࡟ࡂࡆࡕࡗࠫ৾")		: viRJWOC5jsYe84(u"࠱࠳࠲઎")
	,CC1eY6yWZUwf2TkRvnp7EJ0AimjHBX(u"ࠫࡆࡒࡋࡂ࡙ࡗࡌࡆࡘࠧ৿")	: RlOvin8YIGC2KZXJPk9m0acrMobUex(u"࠲࠵࠳એ")
	,LZWMikPEB81KSGyxfJtUsCA(u"ࠬ࡟ࡏࡖࡖࡘࡆࡊ࠭਀")		: ddiCzu6yahj5RtTISMJ48sNnZBU(u"࠳࠷࠴ઐ")
	,qqzwE6imYG4c2xojI(u"࠭ࡓࡆࡔ࡙ࡍࡈࡋࡓࡠ࠳ࠪਁ")	: V3VlkhgjEF4n1erPXHcC0NOsfwyAJ(u"࠴࠹࠵ઑ")
	,Ie5s2cBtSfdHjzQ4rA9kYlo6D18(u"ࠧࡓࡃࡑࡈࡔࡓࡓࡠ࠲ࠪਂ")	: ddiCzu6yahj5RtTISMJ48sNnZBU(u"࠵࠻࠶઒")
	,BRWqdruz2A0(u"ࠨࡕࡈࡖ࡛ࡏࡃࡆࡕࡢ࠶ࠬਃ")	: LZWMikPEB81KSGyxfJtUsCA(u"࠶࠽࠰ઓ")
	,lljaEqwTVtmKsQcOrbXxS5hgNH(u"ࠩࡐࡓ࡛ࡏ࡚ࡍࡃࡑࡈࠬ਄")	: qoBMmfAWpFlK70xw8ZRh4naJ(u"࠷࠸࠱ઔ")
	,LZWMikPEB81KSGyxfJtUsCA(u"ࠪࡗࡊࡘࡖࡊࡅࡈࡗࡤ࠹ࠧਅ")	: IaBhDMJc17302LgSvyxd(u"࠱࠺࠲ક")
	,fWoVd0Bmtkx(u"ࠫࡆࡘࡂࡍࡋࡒࡒ࡟࠭ਆ")		: qqzwE6imYG4c2xojI(u"࠳࠲࠳ખ")
	,BRWqdruz2A0(u"࡙ࠬࡅࡓࡋࡈࡗ࠹࡝ࡁࡕࡅࡋࠫਇ")	: mmV2nucZ5Lpl6FO1JMPEqGoQKW(u"࠴࠴࠴ગ")
	,mmV2nucZ5Lpl6FO1JMPEqGoQKW(u"࠭ࡅࡈ࡛ࡅࡉࡘ࡚ࡖࡊࡒࠪਈ")	: sjtU6GZQg5XC2pH4(u"࠵࠶࠵ઘ")
	,l32dnTEOU1skGKqeBtI9hmo(u"ࠧࡊࡒࡗ࡚ࡤ࠶ࠧਉ")		: DiJ8CMuYH1daWyjehfN0L(u"࠶࠸࠶ઙ")
	,l1DZAt9XNQjqE7YOdrz(u"ࠨࡃࡎ࡛ࡆࡓࠧਊ")		: l1DZAt9XNQjqE7YOdrz(u"࠷࠺࠰ચ")
	,ee86G9ladLHVbh5mikzCo(u"ࠩࡄࡖࡆࡈࡓࡆࡇࡇࠫ਋")		: kYDaz79TFlXoR(u"࠸࠵࠱છ")
	,CC1eY6yWZUwf2TkRvnp7EJ0AimjHBX(u"ࠪࡑࡊࡔࡕࡔࡡ࠳ࠫ਌")		: c2RKu0xG1eC8MiohyE(u"࠲࠷࠲જ")
	,ddiCzu6yahj5RtTISMJ48sNnZBU(u"ࠫࡋࡇࡖࡐࡔࡌࡘࡊ࡙ࠧ਍")	: ddiCzu6yahj5RtTISMJ48sNnZBU(u"࠳࠹࠳ઝ")
	,DiJ8CMuYH1daWyjehfN0L(u"ࠬࡏࡐࡕࡘࡢ࠵ࠬ਎")		: qoBMmfAWpFlK70xw8ZRh4naJ(u"࠴࠻࠴ઞ")
	,qqzwE6imYG4c2xojI(u"࡙࠭ࡕࡄࡢࡇࡍࡇࡎࡏࡇࡏࡗࠬਏ")	: ee86G9ladLHVbh5mikzCo(u"࠵࠽࠵ટ")
	,RlOvin8YIGC2KZXJPk9m0acrMobUex(u"ࠧࡄࡋࡐࡅࡓࡕࡗࠨਐ")		: mmV2nucZ5Lpl6FO1JMPEqGoQKW(u"࠷࠵࠶ઠ")
	,mmV2nucZ5Lpl6FO1JMPEqGoQKW(u"ࠨࡕࡋࡍࡆ࡜ࡏࡊࡅࡈࠫ਑")	: DiJ8CMuYH1daWyjehfN0L(u"࠸࠷࠰ડ")
	,DiJ8CMuYH1daWyjehfN0L(u"ࠩࡎࡅࡗࡈࡁࡍࡃࡗ࡚ࠬ਒")	: ddiCzu6yahj5RtTISMJ48sNnZBU(u"࠹࠲࠱ઢ")
	,BRWqdruz2A0(u"ࠪࡈࡔ࡝ࡎࡍࡑࡄࡈࠬਓ")		: kYDaz79TFlXoR(u"࠳࠴࠲ણ")
	,dJHDqiKf12TXlIzSLkGUuxg4MBs3A(u"ࠫࡘࡋࡒࡗࡋࡆࡉࡘࡥ࠴ࠨਔ")	: DiJ8CMuYH1daWyjehfN0L(u"࠴࠶࠳ત")
	,ddiCzu6yahj5RtTISMJ48sNnZBU(u"ࠬࡇࡋࡐࡃࡐࡇࡆࡓࠧਕ")		: qoBMmfAWpFlK70xw8ZRh4naJ(u"࠵࠸࠴થ")
	,DiJ8CMuYH1daWyjehfN0L(u"࠭ࡍ࡚ࡅࡌࡑࡆ࠭ਖ")		: c2RKu0xG1eC8MiohyE(u"࠶࠺࠵દ")
	,LZWMikPEB81KSGyxfJtUsCA(u"ࠧࡃࡑࡎࡖࡆ࠭ਗ")		: ee86G9ladLHVbh5mikzCo(u"࠷࠼࠶ધ")
	,CC1eY6yWZUwf2TkRvnp7EJ0AimjHBX(u"ࠨࡏࡒ࡚ࡘ࠺ࡕࠨਘ")		: lljaEqwTVtmKsQcOrbXxS5hgNH(u"࠸࠾࠰ન")
	,iNc3KxwErnQ(u"ࠩࡉࡅࡏࡋࡒࡔࡊࡒ࡛ࠬਙ")	: ee86G9ladLHVbh5mikzCo(u"࠹࠹࠱઩")
	,zYvEaigKWjoq50pXBLDbGJkFc(u"ࠪࡈࡆࡏࡌ࡚ࡏࡒࡘࡎࡕࡎࡠ࠲ࠪਚ"): UUDAiytEL76RTmMYsuIz5evXB(u"࠴࠱࠲પ")
	,IaBhDMJc17302LgSvyxd(u"ࠫࡉࡇࡉࡍ࡛ࡐࡓ࡙ࡏࡏࡏࡡ࠴ࠫਛ"): rNdBKI74fAklnoCZ6(u"࠵࠳࠳ફ")
	,l32dnTEOU1skGKqeBtI9hmo(u"ࠬࡉࡉࡎࡃ࠷࡙ࠬਜ")		: UVa3fJw7k6KM(u"࠶࠵࠴બ")
	,dJHDqiKf12TXlIzSLkGUuxg4MBs3A(u"࠭ࡅࡈ࡛ࡑࡓ࡜࠭ਝ")		: ee86G9ladLHVbh5mikzCo(u"࠷࠷࠵ભ")
	,UVa3fJw7k6KM(u"ࠧࡆࡉ࡜ࡈࡊࡇࡄࠨਞ")		: qoBMmfAWpFlK70xw8ZRh4naJ(u"࠸࠹࠶મ")
	,Ie5s2cBtSfdHjzQ4rA9kYlo6D18(u"ࠨࡎࡒࡈ࡞ࡔࡅࡕࠩਟ")		: tQMjXKCA5dN4xq3beVIzaEoWkFLg(u"࠹࠻࠰ય")
	,IaBhDMJc17302LgSvyxd(u"ࠩࡗ࡚ࡋ࡛ࡎࠨਠ")		: V3VlkhgjEF4n1erPXHcC0NOsfwyAJ(u"࠺࠶࠱ર")
	,IaBhDMJc17302LgSvyxd(u"ࠪࡇࡎࡓࡁࡍࡋࡊࡌ࡙࠭ਡ")	: IaBhDMJc17302LgSvyxd(u"࠴࠸࠲઱")
	,ee86G9ladLHVbh5mikzCo(u"ࠫࡘࡎࡏࡐࡈࡓࡖࡔ࠭ਢ")		: BRWqdruz2A0(u"࠵࠺࠳લ")
	,ddiCzu6yahj5RtTISMJ48sNnZBU(u"ࠬࡉࡉࡎࡃࡆࡐ࡚ࡖࠧਣ")		: aXqWLoTdVgME(u"࠶࠼࠴ળ")
	,fWoVd0Bmtkx(u"࠭ࡓࡆࡔ࡙ࡍࡈࡋࡓࡠ࠷ࠪਤ")	: zYvEaigKWjoq50pXBLDbGJkFc(u"࠸࠴࠵઴")
	,BRWqdruz2A0(u"ࠧࡆࡎࡆࡍࡓࡋࡍࡂࡡ࠳ࠫਥ")	: BRWqdruz2A0(u"࠹࠶࠶વ")
	,c2RKu0xG1eC8MiohyE(u"ࠨࡇࡏࡇࡎࡔࡅࡎࡃࡢ࠵ࠬਦ")	: RlOvin8YIGC2KZXJPk9m0acrMobUex(u"࠺࠸࠰શ")
	,viRJWOC5jsYe84(u"ࠩࡐࡉࡓ࡛ࡓࡠ࠳ࠪਧ")		: viRJWOC5jsYe84(u"࠻࠳࠱ષ")
	,l32dnTEOU1skGKqeBtI9hmo(u"ࠪࡋࡑࡕࡂࡂࡎࡖࡉࡆࡘࡃࡉࠩਨ")	: ddiCzu6yahj5RtTISMJ48sNnZBU(u"࠵࠵࠲સ")
	,l32dnTEOU1skGKqeBtI9hmo(u"ࠫࡈࡏࡍࡂࡃࡅࡈࡔ࠭਩")		: UVa3fJw7k6KM(u"࠶࠷࠳હ")
	,IaBhDMJc17302LgSvyxd(u"ࠬ࡝ࡅࡄࡋࡐࡅ࠶࠭ਪ")		: UUDAiytEL76RTmMYsuIz5evXB(u"࠷࠹࠴઺")
	,YY8UDX3MJhb91AHw7fg(u"࠭ࡆࡂࡕࡈࡐࡍࡊ࠱ࠨਫ")		: l1DZAt9XNQjqE7YOdrz(u"࠸࠻࠵઻")
	,aXqWLoTdVgME(u"ࠧࡔࡊࡄࡌࡎࡊࡎࡆ࡙ࡖࠫਬ")	: UUDAiytEL76RTmMYsuIz5evXB(u"࠹࠽࠶઼")
	,mmV2nucZ5Lpl6FO1JMPEqGoQKW(u"ࠨࡈࡄࡗࡊࡒࡈࡅ࠴ࠪਭ")		: rNdBKI74fAklnoCZ6(u"࠺࠿࠰ઽ")
	,mmV2nucZ5Lpl6FO1JMPEqGoQKW(u"ࠩࡉࡓࡘ࡚ࡁࠨਮ")		: IaBhDMJc17302LgSvyxd(u"࠼࠰࠱ા")
	,N3flV6EJsD5CzS(u"ࠪࡅࡍ࡝ࡁࡌࠩਯ")		: tR1krDGPpO025fghMT3a7UnYj(u"࠶࠲࠲િ")
	,tR1krDGPpO025fghMT3a7UnYj(u"ࠫࡋࡇࡂࡓࡃࡎࡅࠬਰ")		: ddiCzu6yahj5RtTISMJ48sNnZBU(u"࠷࠴࠳ી")
	,CC1eY6yWZUwf2TkRvnp7EJ0AimjHBX(u"ࠬࡉࡉࡎࡃࡆࡐ࡚ࡈࡗࡐࡔࡎࠫ਱")	: DiJ8CMuYH1daWyjehfN0L(u"࠸࠶࠴ુ")
	,kYDaz79TFlXoR(u"࠭ࡓࡉࡑࡉࡌࡆ࠭ਲ")		: DaFZHsThGmd0zv6e(u"࠹࠸࠵ૂ")
	,fWoVd0Bmtkx(u"ࠧࡃࡔࡖࡘࡊࡐࠧਲ਼")		: BRWqdruz2A0(u"࠺࠺࠶ૃ")
	,c2RKu0xG1eC8MiohyE(u"ࠨ࡛ࡄࡕࡔ࡚ࠧ਴")		: mmV2nucZ5Lpl6FO1JMPEqGoQKW(u"࠻࠼࠰ૄ")
	,tQMjXKCA5dN4xq3beVIzaEoWkFLg(u"ࠩࡎࡅ࡙ࡑࡏࡖࡖࡈࠫਵ")		: sjtU6GZQg5XC2pH4(u"࠼࠷࠱ૅ")
	,lljaEqwTVtmKsQcOrbXxS5hgNH(u"ࠪࡈࡗࡇࡍࡂࡕ࠺ࠫਸ਼")		: Ie5s2cBtSfdHjzQ4rA9kYlo6D18(u"࠶࠹࠲૆")
	,YY8UDX3MJhb91AHw7fg(u"ࠫࡈࡏࡍࡂ࠶࠳࠴ࠬ਷")		: ee86G9ladLHVbh5mikzCo(u"࠷࠻࠳ે")
	,sjtU6GZQg5XC2pH4(u"ࠬࡒࡁࡓࡑ࡝ࡅࠬਸ")		: dJHDqiKf12TXlIzSLkGUuxg4MBs3A(u"࠹࠳࠴ૈ")
	,tQMjXKCA5dN4xq3beVIzaEoWkFLg(u"࠭ࡍ࠴ࡗࡢ࠴ࠬਹ")		: lljaEqwTVtmKsQcOrbXxS5hgNH(u"࠺࠵࠵ૉ")
	,DaFZHsThGmd0zv6e(u"ࠧࡎ࠵ࡘࡣ࠶࠭਺")		: DiJ8CMuYH1daWyjehfN0L(u"࠻࠷࠶૊")
	,l1DZAt9XNQjqE7YOdrz(u"ࠨࡃࡕࡅࡇࡏࡃࡕࡑࡒࡒࡘ࠭਻")	: tQMjXKCA5dN4xq3beVIzaEoWkFLg(u"࠼࠹࠰ો")
	,c2RKu0xG1eC8MiohyE(u"ࠩࡆࡐࡊࡇࡎࡆࡔࡢ࠴਼ࠬ")	: fWoVd0Bmtkx(u"࠽࠴࠱ૌ")
	,aXqWLoTdVgME(u"ࠪࡇࡑࡋࡁࡏࡇࡕࡣ࠶࠭਽")	: l32dnTEOU1skGKqeBtI9hmo(u"࠷࠶࠲્")
	,Ie5s2cBtSfdHjzQ4rA9kYlo6D18(u"ࠫࡗࡇࡎࡅࡑࡐࡗࡤ࠷ࠧਾ")	: DaFZHsThGmd0zv6e(u"࠸࠸࠳૎")
	,c2RKu0xG1eC8MiohyE(u"ࠬࡋࡇ࡚ࡄࡈࡗ࡙࠷ࠧਿ")		: kYDaz79TFlXoR(u"࠹࠺࠴૏")
	,CC1eY6yWZUwf2TkRvnp7EJ0AimjHBX(u"࠭ࡅࡈ࡛ࡅࡉࡘ࡚࠲ࠨੀ")		: fWoVd0Bmtkx(u"࠺࠼࠵ૐ")
	,dJHDqiKf12TXlIzSLkGUuxg4MBs3A(u"ࠧࡆࡉ࡜ࡆࡊ࡙ࡔ࠴ࠩੁ")		: LZWMikPEB81KSGyxfJtUsCA(u"࠻࠾࠶૑")
	,rNdBKI74fAklnoCZ6(u"ࠨࡇࡊ࡝ࡇࡋࡓࡕ࠶ࠪੂ")		: lljaEqwTVtmKsQcOrbXxS5hgNH(u"࠽࠶࠰૒")
	,ee86G9ladLHVbh5mikzCo(u"ࠩࡎࡅ࡙ࡑࡏࡕࡖ࡙ࠫ੃")		: aXqWLoTdVgME(u"࠾࠱࠱૓")
	,viRJWOC5jsYe84(u"ࠪࡇࡎࡓࡁࡄࡎࡘࡆࠬ੄")		: kYDaz79TFlXoR(u"࠸࠳࠲૔")
	,YY8UDX3MJhb91AHw7fg(u"ࠫࡈࡏࡍࡂࡈࡕࡉࡊ࠭੅")		: DiJ8CMuYH1daWyjehfN0L(u"࠹࠵࠳૕")
	,BRWqdruz2A0(u"࡙ࠬࡈࡐࡑࡉࡒࡊ࡚ࠧ੆")		: DiJ8CMuYH1daWyjehfN0L(u"࠺࠷࠴૖")
	,kYDaz79TFlXoR(u"࠭ࡁࡌ࡙ࡄࡑ࡙࡛ࡂࡆࠩੇ")	: fWoVd0Bmtkx(u"࠻࠹࠵૗")
	,tQMjXKCA5dN4xq3beVIzaEoWkFLg(u"ࠧࡂࡎࡐࡗ࡙ࡈࡁࠨੈ")		: viRJWOC5jsYe84(u"࠼࠻࠶૘")
	,kYDaz79TFlXoR(u"ࠨࡘࡄࡖࡇࡕࡎࠨ੉")		: LZWMikPEB81KSGyxfJtUsCA(u"࠽࠽࠰૙")
	,lljaEqwTVtmKsQcOrbXxS5hgNH(u"ࠩࡆࡍࡒࡇ࠴ࡑࠩ੊")		: mmV2nucZ5Lpl6FO1JMPEqGoQKW(u"࠾࠸࠱૚")
	,zYvEaigKWjoq50pXBLDbGJkFc(u"ࠪࡗࡊࡘࡉࡆࡕࡗࡍࡒࡋࠧੋ")	: UVa3fJw7k6KM(u"࠸࠺࠲૛")
	,tQMjXKCA5dN4xq3beVIzaEoWkFLg(u"ࠫࡋ࡛ࡓࡉࡃࡕ࡚ࡎࡊࡅࡐࠩੌ")	: fWoVd0Bmtkx(u"࠺࠲࠳૜")
	,l1DZAt9XNQjqE7YOdrz(u"ࠬࡌࡕࡔࡊࡄࡖ࡙࡜੍ࠧ")		: dJHDqiKf12TXlIzSLkGUuxg4MBs3A(u"࠻࠴࠴૝")
	,kYDaz79TFlXoR(u"࠭ࡋࡊࡔࡐࡅࡑࡑࠧ੎")		: N3flV6EJsD5CzS(u"࠼࠶࠵૞")
	,Ie5s2cBtSfdHjzQ4rA9kYlo6D18(u"ࠧࡅࡔࡄࡑࡆࡉࡁࡇࡇࠪ੏")	: lljaEqwTVtmKsQcOrbXxS5hgNH(u"࠽࠸࠶૟")
	,fWoVd0Bmtkx(u"ࠨࡖࡌࡏࡆࡇࡔࠨ੐")		: zYvEaigKWjoq50pXBLDbGJkFc(u"࠾࠺࠰ૠ")
	,N3flV6EJsD5CzS(u"ࠩࡔࡊࡎࡒࡍࠨੑ")		: UUDAiytEL76RTmMYsuIz5evXB(u"࠿࠵࠱ૡ")
	,iNc3KxwErnQ(u"ࠪࡗࡍࡇࡂࡂࡍࡄࡘ࡞࠭੒")	: aXqWLoTdVgME(u"࠹࠷࠲ૢ")
	,UUDAiytEL76RTmMYsuIz5evXB(u"ࠫࡆࡔࡉࡎࡇ࡝ࡍࡉ࠭੓")		: UUDAiytEL76RTmMYsuIz5evXB(u"࠺࠹࠳ૣ")
	,sjtU6GZQg5XC2pH4(u"ࠬࡉࡉࡎࡃ࡚ࡆࡆ࡙ࠧ੔")		: viRJWOC5jsYe84(u"࠻࠻࠴૤")
	,DiJ8CMuYH1daWyjehfN0L(u"࠭ࡆࡂࡔࡈࡗࡐࡕࠧ੕")		: viRJWOC5jsYe84(u"࠼࠽࠵૥")
	,BRWqdruz2A0(u"ࠧࡘࡇࡆࡍࡒࡇ࠲ࠨ੖")		: tR1krDGPpO025fghMT3a7UnYj(u"࠵࠵࠶࠰૦")
	,aXqWLoTdVgME(u"ࠨࡉࡒࡓࡌࡒࡅࡔࡇࡄࡖࡈࡎࠧ੗")	: Ie5s2cBtSfdHjzQ4rA9kYlo6D18(u"࠶࠶࠱࠱૧")
	,BRWqdruz2A0(u"ࠩࡖࡉࡗ࡜ࡉࡄࡇࡖࡣ࠻࠭੘")	: ddiCzu6yahj5RtTISMJ48sNnZBU(u"࠷࠰࠳࠲૨")
	,LZWMikPEB81KSGyxfJtUsCA(u"࡚ࠪࡎࡊࡅࡐࡐࡖࡅࡊࡓࠧਖ਼")	: ddiCzu6yahj5RtTISMJ48sNnZBU(u"࠱࠱࠵࠳૩")
	,V3VlkhgjEF4n1erPXHcC0NOsfwyAJ(u"ࠫࡒࡇࡓࡂࡘࡌࡈࡊࡕࠧਗ਼")	: UUDAiytEL76RTmMYsuIz5evXB(u"࠲࠲࠷࠴૪")
	,DiJ8CMuYH1daWyjehfN0L(u"ࠬࡇ࡙ࡍࡑࡏࠫਜ਼")		: tR1krDGPpO025fghMT3a7UnYj(u"࠳࠳࠹࠵૫")
	,V3VlkhgjEF4n1erPXHcC0NOsfwyAJ(u"࠭ࡅࡍࡋࡉ࡚ࡎࡊࡅࡐࠩੜ")	: UVa3fJw7k6KM(u"࠴࠴࠻࠶૬")
	,ee86G9ladLHVbh5mikzCo(u"ࠧࡇࡗࡑࡓࡓ࡚ࡖࠨ੝")		: LZWMikPEB81KSGyxfJtUsCA(u"࠵࠵࠽࠰૭")
	,V3VlkhgjEF4n1erPXHcC0NOsfwyAJ(u"ࠨࡅࡏࡉࡆࡔࡅࡓࡡ࠵ࠫਫ਼")	: CC1eY6yWZUwf2TkRvnp7EJ0AimjHBX(u"࠶࠶࠸࠱૮")
	,qqzwE6imYG4c2xojI(u"ࠩࡖࡌࡆࡎࡉࡅ࠶ࡘ࠶ࠬ੟")	: sjtU6GZQg5XC2pH4(u"࠷࠰࠺࠲૯")
}