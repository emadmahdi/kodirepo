# -*- coding: utf-8 -*-
import sys as TSRUP0dExYGQg
mgNMJhrjcq1xb = TSRUP0dExYGQg.version_info [0] == 2
lQJvf8UXo2de9gjCatY4yH = 2048
YuTB2OjotvlR = 7
def kk0DKyarxq9eS1zwGLMFQTZN35dj (neqP2if8IOJ50aNKcCBLrXdZk):
	global sWerUpk6nQwT7zY43
	vxdNQUujz7ZFV4rtOSK2 = ord (neqP2if8IOJ50aNKcCBLrXdZk [-1])
	yyshZX35KO7JodYjD9qVib6 = neqP2if8IOJ50aNKcCBLrXdZk [:-1]
	fuKReXJ3HPIAU7c = vxdNQUujz7ZFV4rtOSK2 % len (yyshZX35KO7JodYjD9qVib6)
	EEFQdvXog7LPC4Sie0jDkUKxn6M = yyshZX35KO7JodYjD9qVib6 [:fuKReXJ3HPIAU7c] + yyshZX35KO7JodYjD9qVib6 [fuKReXJ3HPIAU7c:]
	if mgNMJhrjcq1xb:
		Clh5YS0XPue68EgT4Uq17GL = unicode () .join ([unichr (ord (AsGVDZFgmuH06jviYrWXTz) - lQJvf8UXo2de9gjCatY4yH - (XvhDIL4ZpzaPs91WkoGnedCEA2rt + vxdNQUujz7ZFV4rtOSK2) % YuTB2OjotvlR) for XvhDIL4ZpzaPs91WkoGnedCEA2rt, AsGVDZFgmuH06jviYrWXTz in enumerate (EEFQdvXog7LPC4Sie0jDkUKxn6M)])
	else:
		Clh5YS0XPue68EgT4Uq17GL = str () .join ([chr (ord (AsGVDZFgmuH06jviYrWXTz) - lQJvf8UXo2de9gjCatY4yH - (XvhDIL4ZpzaPs91WkoGnedCEA2rt + vxdNQUujz7ZFV4rtOSK2) % YuTB2OjotvlR) for XvhDIL4ZpzaPs91WkoGnedCEA2rt, AsGVDZFgmuH06jviYrWXTz in enumerate (EEFQdvXog7LPC4Sie0jDkUKxn6M)])
	return eval (Clh5YS0XPue68EgT4Uq17GL)
qoBMmfAWpFlK70xw8ZRh4naJ,lljaEqwTVtmKsQcOrbXxS5hgNH,aXqWLoTdVgME=kk0DKyarxq9eS1zwGLMFQTZN35dj,kk0DKyarxq9eS1zwGLMFQTZN35dj,kk0DKyarxq9eS1zwGLMFQTZN35dj
UVa3fJw7k6KM,fWoVd0Bmtkx,tQMjXKCA5dN4xq3beVIzaEoWkFLg=aXqWLoTdVgME,lljaEqwTVtmKsQcOrbXxS5hgNH,qoBMmfAWpFlK70xw8ZRh4naJ
viRJWOC5jsYe84,Ie5s2cBtSfdHjzQ4rA9kYlo6D18,sjtU6GZQg5XC2pH4=tQMjXKCA5dN4xq3beVIzaEoWkFLg,fWoVd0Bmtkx,UVa3fJw7k6KM
LZWMikPEB81KSGyxfJtUsCA,rNdBKI74fAklnoCZ6,BRWqdruz2A0=sjtU6GZQg5XC2pH4,Ie5s2cBtSfdHjzQ4rA9kYlo6D18,viRJWOC5jsYe84
CC1eY6yWZUwf2TkRvnp7EJ0AimjHBX,qqzwE6imYG4c2xojI,N3flV6EJsD5CzS=BRWqdruz2A0,rNdBKI74fAklnoCZ6,LZWMikPEB81KSGyxfJtUsCA
UUDAiytEL76RTmMYsuIz5evXB,IaBhDMJc17302LgSvyxd,ddiCzu6yahj5RtTISMJ48sNnZBU=N3flV6EJsD5CzS,qqzwE6imYG4c2xojI,CC1eY6yWZUwf2TkRvnp7EJ0AimjHBX
dJHDqiKf12TXlIzSLkGUuxg4MBs3A,l1DZAt9XNQjqE7YOdrz,l32dnTEOU1skGKqeBtI9hmo=ddiCzu6yahj5RtTISMJ48sNnZBU,IaBhDMJc17302LgSvyxd,UUDAiytEL76RTmMYsuIz5evXB
zYvEaigKWjoq50pXBLDbGJkFc,iNc3KxwErnQ,V3VlkhgjEF4n1erPXHcC0NOsfwyAJ=l32dnTEOU1skGKqeBtI9hmo,l1DZAt9XNQjqE7YOdrz,dJHDqiKf12TXlIzSLkGUuxg4MBs3A
tR1krDGPpO025fghMT3a7UnYj,c2RKu0xG1eC8MiohyE,RlOvin8YIGC2KZXJPk9m0acrMobUex=V3VlkhgjEF4n1erPXHcC0NOsfwyAJ,iNc3KxwErnQ,zYvEaigKWjoq50pXBLDbGJkFc
YY8UDX3MJhb91AHw7fg,ee86G9ladLHVbh5mikzCo,mmV2nucZ5Lpl6FO1JMPEqGoQKW=RlOvin8YIGC2KZXJPk9m0acrMobUex,c2RKu0xG1eC8MiohyE,tR1krDGPpO025fghMT3a7UnYj
DaFZHsThGmd0zv6e,kYDaz79TFlXoR,DiJ8CMuYH1daWyjehfN0L=mmV2nucZ5Lpl6FO1JMPEqGoQKW,ee86G9ladLHVbh5mikzCo,YY8UDX3MJhb91AHw7fg
from NKn4FXivsk import *
from ww3OrKJBvl import *
import base64 as PP0Gxazjw86
Q8Q0IDc6PLZajJAdTntKUmSGXz = tQMjXKCA5dN4xq3beVIzaEoWkFLg(u"ࠩࡏࡍࡇ࡙ࡔࡘࡑࠪၣ")
if DLod2Of8CkRrtzJynev:
	ssQ5T7em6WrVwIGtXoxNKaBv48zHAM = epqEW3aV5KkuLzCv.translatePath(Ie5s2cBtSfdHjzQ4rA9kYlo6D18(u"ࠪࡷࡵ࡫ࡣࡪࡣ࡯࠾࠴࠵ࡨࡰ࡯ࡨࠫၤ"))
	tn7RmrxkdVJi2PISA1uoG = epqEW3aV5KkuLzCv.translatePath(RlOvin8YIGC2KZXJPk9m0acrMobUex(u"ࠫࡸࡶࡥࡤ࡫ࡤࡰ࠿࠵࠯࡭ࡱࡪࡴࡦࡺࡨࠨၥ"))
	Rb017YwecyPpEVQWAIu6HGhJ9k3tf = RPbaxsNFVTwek5Kfv21DiJuzCnjMZp.path.join(ssQ5T7em6WrVwIGtXoxNKaBv48zHAM,fWoVd0Bmtkx(u"ࠬࡻࡳࡦࡴࡧࡥࡹࡧࠧၦ"),tQMjXKCA5dN4xq3beVIzaEoWkFLg(u"࠭ࡄࡢࡶࡤࡦࡦࡹࡥࠨၧ"),dJHDqiKf12TXlIzSLkGUuxg4MBs3A(u"ࠧࡂࡦࡧࡳࡳࡹ࠳࠴࠰ࡧࡦࠬၨ"))
	Q2lhvMLO4Vp78Cbi6 = RPbaxsNFVTwek5Kfv21DiJuzCnjMZp.path.join(ssQ5T7em6WrVwIGtXoxNKaBv48zHAM,l1DZAt9XNQjqE7YOdrz(u"ࠨࡷࡶࡩࡷࡪࡡࡵࡣࠪၩ"),c2RKu0xG1eC8MiohyE(u"ࠩࡇࡥࡹࡧࡢࡢࡵࡨࠫၪ"),UUDAiytEL76RTmMYsuIz5evXB(u"࡚ࠪ࡮࡫ࡷࡎࡱࡧࡩࡸ࠼࠮ࡥࡤࠪၫ"))
	y9fZ7hgXSTt8 = RPbaxsNFVTwek5Kfv21DiJuzCnjMZp.path.join(ssQ5T7em6WrVwIGtXoxNKaBv48zHAM,IaBhDMJc17302LgSvyxd(u"ࠫࡺࡹࡥࡳࡦࡤࡸࡦ࠭ၬ"),UUDAiytEL76RTmMYsuIz5evXB(u"ࠬࡊࡡࡵࡣࡥࡥࡸ࡫ࠧၭ"),UVa3fJw7k6KM(u"࠭ࡔࡦࡺࡷࡹࡷ࡫ࡳ࠲࠵࠱ࡨࡧ࠭ၮ"))
	from urllib.parse import quote as _8MwxukZ1OqBPNQadU
else:
	ssQ5T7em6WrVwIGtXoxNKaBv48zHAM = Rqvw05BorCgcye7VE32Sf.translatePath(l1DZAt9XNQjqE7YOdrz(u"ࠧࡴࡲࡨࡧ࡮ࡧ࡬࠻࠱࠲࡬ࡴࡳࡥࠨၯ"))
	tn7RmrxkdVJi2PISA1uoG = Rqvw05BorCgcye7VE32Sf.translatePath(CC1eY6yWZUwf2TkRvnp7EJ0AimjHBX(u"ࠨࡵࡳࡩࡨ࡯ࡡ࡭࠼࠲࠳ࡱࡵࡧࡱࡣࡷ࡬ࠬၰ"))
	Rb017YwecyPpEVQWAIu6HGhJ9k3tf = RPbaxsNFVTwek5Kfv21DiJuzCnjMZp.path.join(ssQ5T7em6WrVwIGtXoxNKaBv48zHAM,mmV2nucZ5Lpl6FO1JMPEqGoQKW(u"ࠩࡸࡷࡪࡸࡤࡢࡶࡤࠫၱ"),c2RKu0xG1eC8MiohyE(u"ࠪࡈࡦࡺࡡࡣࡣࡶࡩࠬၲ"),mmV2nucZ5Lpl6FO1JMPEqGoQKW(u"ࠫࡆࡪࡤࡰࡰࡶ࠶࠼࠴ࡤࡣࠩၳ"))
	Q2lhvMLO4Vp78Cbi6 = RPbaxsNFVTwek5Kfv21DiJuzCnjMZp.path.join(ssQ5T7em6WrVwIGtXoxNKaBv48zHAM,kYDaz79TFlXoR(u"ࠬࡻࡳࡦࡴࡧࡥࡹࡧࠧၴ"),l1DZAt9XNQjqE7YOdrz(u"࠭ࡄࡢࡶࡤࡦࡦࡹࡥࠨၵ"),sjtU6GZQg5XC2pH4(u"ࠧࡗ࡫ࡨࡻࡒࡵࡤࡦࡵ࠹࠲ࡩࡨࠧၶ"))
	y9fZ7hgXSTt8 = RPbaxsNFVTwek5Kfv21DiJuzCnjMZp.path.join(ssQ5T7em6WrVwIGtXoxNKaBv48zHAM,tQMjXKCA5dN4xq3beVIzaEoWkFLg(u"ࠨࡷࡶࡩࡷࡪࡡࡵࡣࠪၷ"),UUDAiytEL76RTmMYsuIz5evXB(u"ࠩࡇࡥࡹࡧࡢࡢࡵࡨࠫၸ"),YY8UDX3MJhb91AHw7fg(u"ࠪࡘࡪࡾࡴࡶࡴࡨࡷ࠶࠹࠮ࡥࡤࠪၹ"))
	from urllib import quote as _8MwxukZ1OqBPNQadU
k8AjFZIlXNLg5diJCHMR20TEznOY = RPbaxsNFVTwek5Kfv21DiJuzCnjMZp.path.join(tn7RmrxkdVJi2PISA1uoG,lljaEqwTVtmKsQcOrbXxS5hgNH(u"ࠫࡰࡵࡤࡪ࠰࡯ࡳ࡬࠭ၺ"))
Zxm9QJBbv7GEkYVK6X8fA3DM0 = RPbaxsNFVTwek5Kfv21DiJuzCnjMZp.path.join(tn7RmrxkdVJi2PISA1uoG,qqzwE6imYG4c2xojI(u"ࠬࡱ࡯ࡥ࡫࠱ࡳࡱࡪ࠮࡭ࡱࡪࠫၻ"))
LyvhPRTAX5UcfVj083MGEi = RPbaxsNFVTwek5Kfv21DiJuzCnjMZp.path.join(F8qeAKZjGRMNXimho2gntaV0,N3flV6EJsD5CzS(u"࠭ࡩࡱࡶࡹ࠵ࡩࡧࡴࡢࡡࡢࡣ࠳ࡪࡢࠨၼ"))
FFgPrenTMBYbJKNdOfRHzwSmW = RPbaxsNFVTwek5Kfv21DiJuzCnjMZp.path.join(F8qeAKZjGRMNXimho2gntaV0,DiJ8CMuYH1daWyjehfN0L(u"ࠧࡪࡲࡷࡺ࠷ࡪࡡࡵࡣࡢࡣࡤ࠴ࡤࡣࠩၽ"))
qmnFDxEPc1 = RPbaxsNFVTwek5Kfv21DiJuzCnjMZp.path.join(F8qeAKZjGRMNXimho2gntaV0,tR1krDGPpO025fghMT3a7UnYj(u"ࠨ࡯࠶ࡹࡩࡧࡴࡢࡡࡢࡣ࠳ࡪࡢࠨၾ"))
V2JfszPWt6jq1hCxYKpyM53RL = RPbaxsNFVTwek5Kfv21DiJuzCnjMZp.path.join(F8qeAKZjGRMNXimho2gntaV0,fWoVd0Bmtkx(u"ࠩࡩࡥࡻࡵࡵࡳ࡫ࡷࡩࡸ࠴ࡤࡢࡶࠪၿ"))
nWkOujBZgesV = RPbaxsNFVTwek5Kfv21DiJuzCnjMZp.path.join(F8qeAKZjGRMNXimho2gntaV0,l32dnTEOU1skGKqeBtI9hmo(u"ࠪ࡭ࡵࡺࡶࡧ࡫࡯ࡩࡤࡥ࡟࠯ࡦࡤࡸࠬႀ"))
v3DXdfGq7VeBh9ousFNOw8yrkEM1n = RPbaxsNFVTwek5Kfv21DiJuzCnjMZp.path.join(F8qeAKZjGRMNXimho2gntaV0,l1DZAt9XNQjqE7YOdrz(u"ࠫࡲ࠹ࡵࡧ࡫࡯ࡩࡤࡥ࡟࠯ࡦࡤࡸࠬႁ"))
SmRoq65eLVMIiuz7xjaC = RPbaxsNFVTwek5Kfv21DiJuzCnjMZp.path.join(mFGa34JHCw9LWlB0,sjtU6GZQg5XC2pH4(u"ࠬ࡯ࡣࡰࡰ࠱ࡴࡳ࡭ࠧႂ"))
C10EV9APKpHQmDo = RPbaxsNFVTwek5Kfv21DiJuzCnjMZp.path.join(mFGa34JHCw9LWlB0,CC1eY6yWZUwf2TkRvnp7EJ0AimjHBX(u"࠭ࡴࡩࡷࡰࡦ࠳ࡶ࡮ࡨࠩႃ"))
jzFXuLn8QI6tgk1y54NPmZ2l7J = RPbaxsNFVTwek5Kfv21DiJuzCnjMZp.path.join(mFGa34JHCw9LWlB0,tQMjXKCA5dN4xq3beVIzaEoWkFLg(u"ࠧࡧࡣࡱࡥࡷࡺ࠮ࡱࡰࡪࠫႄ"))
NrxyZcWBfI1w23 = RPbaxsNFVTwek5Kfv21DiJuzCnjMZp.path.join(mFGa34JHCw9LWlB0,viRJWOC5jsYe84(u"ࠨࡤࡤࡲࡳ࡫ࡲ࠯ࡲࡱ࡫ࠬႅ"))
b8GYN0q4tOfWdm = RPbaxsNFVTwek5Kfv21DiJuzCnjMZp.path.join(mFGa34JHCw9LWlB0,ddiCzu6yahj5RtTISMJ48sNnZBU(u"ࠩ࡯ࡥࡳࡪࡳࡤࡣࡳࡩ࠳ࡶ࡮ࡨࠩႆ"))
GeMB3KUQT0NkISq = RPbaxsNFVTwek5Kfv21DiJuzCnjMZp.path.join(mFGa34JHCw9LWlB0,zYvEaigKWjoq50pXBLDbGJkFc(u"ࠪࡴࡴࡹࡴࡦࡴ࠱ࡴࡳ࡭ࠧႇ"))
jYwKaQ8PzLFg7k = RPbaxsNFVTwek5Kfv21DiJuzCnjMZp.path.join(mFGa34JHCw9LWlB0,ee86G9ladLHVbh5mikzCo(u"ࠫࡨࡲࡥࡢࡴ࡯ࡳ࡬ࡵ࠮ࡱࡰࡪࠫႈ"))
Ut5GKqjbkBx6W = RPbaxsNFVTwek5Kfv21DiJuzCnjMZp.path.join(mFGa34JHCw9LWlB0,viRJWOC5jsYe84(u"ࠬࡩ࡬ࡦࡣࡵࡥࡷࡺ࠮ࡱࡰࡪࠫႉ"))
hPapTifLD0Co7g9M2ur = RPbaxsNFVTwek5Kfv21DiJuzCnjMZp.path.join(mFGa34JHCw9LWlB0,dJHDqiKf12TXlIzSLkGUuxg4MBs3A(u"࠭ࡣࡩࡣࡱ࡫ࡪࡲ࡯ࡨ࠰ࡷࡼࡹ࠭ႊ"))
ABbonyRm60ptY7ErO4UD19SXu = RPbaxsNFVTwek5Kfv21DiJuzCnjMZp.path.join(ssQ5T7em6WrVwIGtXoxNKaBv48zHAM,BRWqdruz2A0(u"ࠧࡢࡦࡧࡳࡳࡹࠧႋ"))
NlbovKuET3t9xiZV1Yhc7Aesmg6paz = RPbaxsNFVTwek5Kfv21DiJuzCnjMZp.path.join(ssQ5T7em6WrVwIGtXoxNKaBv48zHAM,qoBMmfAWpFlK70xw8ZRh4naJ(u"ࠨࡷࡶࡩࡷࡪࡡࡵࡣࠪႌ"),YY8UDX3MJhb91AHw7fg(u"ࠩࡤࡨࡩࡵ࡮ࡠࡦࡤࡸࡦႍ࠭"),xqJBEohLpFs)
cIFbpqOmxJWYGVkD = RPbaxsNFVTwek5Kfv21DiJuzCnjMZp.path.join(NlbovKuET3t9xiZV1Yhc7Aesmg6paz,kYDaz79TFlXoR(u"ࠪࡷࡪࡺࡴࡪࡰࡪࡷ࠳ࡾ࡭࡭ࠩႎ"))
SVGrLpvbf3Om2Ej0ZeD8XokNC7QMd = set(i4bFG3rKE6.BADWEBSITES)
z7mEAQFSD5datXURwNgOkIiG1 = [lkd2oKvZF03qmgMbIfQ6cD for lkd2oKvZF03qmgMbIfQ6cD in z7mEAQFSD5datXURwNgOkIiG1 if lkd2oKvZF03qmgMbIfQ6cD not in SVGrLpvbf3Om2Ej0ZeD8XokNC7QMd]
cmEHgQpO5f1tDrx4CJdz = [lkd2oKvZF03qmgMbIfQ6cD for lkd2oKvZF03qmgMbIfQ6cD in cmEHgQpO5f1tDrx4CJdz if lkd2oKvZF03qmgMbIfQ6cD not in SVGrLpvbf3Om2Ej0ZeD8XokNC7QMd]
YJtxGoaiQlSndzECbOrRWLjhk = [lkd2oKvZF03qmgMbIfQ6cD for lkd2oKvZF03qmgMbIfQ6cD in YJtxGoaiQlSndzECbOrRWLjhk if lkd2oKvZF03qmgMbIfQ6cD not in SVGrLpvbf3Om2Ej0ZeD8XokNC7QMd]
OOaSbLh4fmdBoy95V = [lkd2oKvZF03qmgMbIfQ6cD for lkd2oKvZF03qmgMbIfQ6cD in OOaSbLh4fmdBoy95V if lkd2oKvZF03qmgMbIfQ6cD not in SVGrLpvbf3Om2Ej0ZeD8XokNC7QMd]
F19lhKQpNHsdr0ak7TOn = [lkd2oKvZF03qmgMbIfQ6cD for lkd2oKvZF03qmgMbIfQ6cD in F19lhKQpNHsdr0ak7TOn if lkd2oKvZF03qmgMbIfQ6cD not in SVGrLpvbf3Om2Ej0ZeD8XokNC7QMd]
class A9JZujzBXNEck2sKYt75rwQRIL4CT():
	def __init__(LVT1cNq8QJpdKA94bGf53vPStyg,showDialogs=ag8rjZo1Vz4IPdcOT,logErrors=gBExoceumj4y8bFW9hY2aNMVSr):
		LVT1cNq8QJpdKA94bGf53vPStyg.showDialogs = showDialogs
		LVT1cNq8QJpdKA94bGf53vPStyg.logErrors = logErrors
		LVT1cNq8QJpdKA94bGf53vPStyg.finishedLIST,LVT1cNq8QJpdKA94bGf53vPStyg.failedLIST = [],[]
		LVT1cNq8QJpdKA94bGf53vPStyg.statusDICT,LVT1cNq8QJpdKA94bGf53vPStyg.resultsDICT = {},{}
		LVT1cNq8QJpdKA94bGf53vPStyg.processesLIST = []
		LVT1cNq8QJpdKA94bGf53vPStyg.starttimeDICT,LVT1cNq8QJpdKA94bGf53vPStyg.finishtimeDICT,LVT1cNq8QJpdKA94bGf53vPStyg.elpasedtimeDICT = {},{},{}
	def jJaHlms7gkZM06SPiE(LVT1cNq8QJpdKA94bGf53vPStyg,Zu96PkNGaiqRH3d,oAEFIHdP45gND6J2UZChM,*aargs):
		Zu96PkNGaiqRH3d = str(Zu96PkNGaiqRH3d)
		LVT1cNq8QJpdKA94bGf53vPStyg.statusDICT[Zu96PkNGaiqRH3d] = tR1krDGPpO025fghMT3a7UnYj(u"ࠫࡷࡻ࡮࡯࡫ࡱ࡫ࠬႏ")
		if LVT1cNq8QJpdKA94bGf53vPStyg.showDialogs: t8yiLuJp3cBA6d1QE9x7eZ4fa(qpFY4hAwolV3,Zu96PkNGaiqRH3d)
		le9F2xYip3HbnC86AQ7WDZovJEhU = MqWf2atLi7QDnOF0YKuZhrE53gbv1(daemon=gBExoceumj4y8bFW9hY2aNMVSr,target=LVT1cNq8QJpdKA94bGf53vPStyg.LgcuWm4F0XYxZ2IyJlUtqn,args=(Zu96PkNGaiqRH3d,oAEFIHdP45gND6J2UZChM,aargs))
		LVT1cNq8QJpdKA94bGf53vPStyg.processesLIST.append(le9F2xYip3HbnC86AQ7WDZovJEhU)
		return le9F2xYip3HbnC86AQ7WDZovJEhU
	def Tz7dfFGyYuHgE(LVT1cNq8QJpdKA94bGf53vPStyg,Zu96PkNGaiqRH3d,oAEFIHdP45gND6J2UZChM,*aargs):
		le9F2xYip3HbnC86AQ7WDZovJEhU = LVT1cNq8QJpdKA94bGf53vPStyg.jJaHlms7gkZM06SPiE(Zu96PkNGaiqRH3d,oAEFIHdP45gND6J2UZChM,*aargs)
		le9F2xYip3HbnC86AQ7WDZovJEhU.start()
	def LgcuWm4F0XYxZ2IyJlUtqn(LVT1cNq8QJpdKA94bGf53vPStyg,Zu96PkNGaiqRH3d,oAEFIHdP45gND6J2UZChM,aargs):
		Zu96PkNGaiqRH3d = str(Zu96PkNGaiqRH3d)
		LVT1cNq8QJpdKA94bGf53vPStyg.starttimeDICT[Zu96PkNGaiqRH3d] = s7FnXZYOgexlH2MPb8BJck1AKv9.time()
		try:
			LVT1cNq8QJpdKA94bGf53vPStyg.resultsDICT[Zu96PkNGaiqRH3d] = oAEFIHdP45gND6J2UZChM(*aargs)
			if kYDaz79TFlXoR(u"ࠬࡕࡐࡆࡐࡘࡖࡑ࠭႐") in str(oAEFIHdP45gND6J2UZChM) and not LVT1cNq8QJpdKA94bGf53vPStyg.resultsDICT[Zu96PkNGaiqRH3d].succeeded: xtm9pSeMInWo60()
			LVT1cNq8QJpdKA94bGf53vPStyg.finishedLIST.append(Zu96PkNGaiqRH3d)
			LVT1cNq8QJpdKA94bGf53vPStyg.statusDICT[Zu96PkNGaiqRH3d] = ee86G9ladLHVbh5mikzCo(u"࠭ࡦࡪࡰ࡬ࡷ࡭࡫ࡤࠨ႑")
		except Exception as Afgoj31Zzp6XeHU7I:
			if LVT1cNq8QJpdKA94bGf53vPStyg.logErrors:
				ggnX3IOk2LPMd = ralpo6SjWw9FGVfcINEgXB0ZDnT.format_exc()
				if ggnX3IOk2LPMd!=rNdBKI74fAklnoCZ6(u"ࠧࡏࡱࡱࡩ࡙ࡿࡰࡦ࠼ࠣࡒࡴࡴࡥ࡝ࡰࠪ႒"): TSRUP0dExYGQg.stderr.write(ggnX3IOk2LPMd)
			LVT1cNq8QJpdKA94bGf53vPStyg.failedLIST.append(Zu96PkNGaiqRH3d)
			LVT1cNq8QJpdKA94bGf53vPStyg.statusDICT[Zu96PkNGaiqRH3d] = V3VlkhgjEF4n1erPXHcC0NOsfwyAJ(u"ࠨࡨࡤ࡭ࡱ࡫ࡤࠨ႓")
		LVT1cNq8QJpdKA94bGf53vPStyg.finishtimeDICT[Zu96PkNGaiqRH3d] = s7FnXZYOgexlH2MPb8BJck1AKv9.time()
		LVT1cNq8QJpdKA94bGf53vPStyg.elpasedtimeDICT[Zu96PkNGaiqRH3d] = LVT1cNq8QJpdKA94bGf53vPStyg.finishtimeDICT[Zu96PkNGaiqRH3d] - LVT1cNq8QJpdKA94bGf53vPStyg.starttimeDICT[Zu96PkNGaiqRH3d]
	def fBXPGVdRoHN0EpruWg4OCTFQeIKy7(LVT1cNq8QJpdKA94bGf53vPStyg):
		for vvhixN5oI3XVGrfsO1pWnzPqBH0 in LVT1cNq8QJpdKA94bGf53vPStyg.processesLIST:
			vvhixN5oI3XVGrfsO1pWnzPqBH0.start()
	def xAQqijnD9JpfYuoPR4(LVT1cNq8QJpdKA94bGf53vPStyg):
		while Ie5s2cBtSfdHjzQ4rA9kYlo6D18(u"ࠩࡵࡹࡳࡴࡩ࡯ࡩࠪ႔") in list(LVT1cNq8QJpdKA94bGf53vPStyg.statusDICT.values()): s7FnXZYOgexlH2MPb8BJck1AKv9.sleep(LZWMikPEB81KSGyxfJtUsCA(u"࠷ᛍ"))
def d1d0qjI48MeizL7mPDkRt():
	if not sOYTrW4HDRgG: return YY8UDX3MJhb91AHw7fg(u"ࠪࡒࡔࡥࡕࡑࡆࡄࡘࡊ࠭႕")
	HZJeYgfyKuwVci3Nj = V3VlkhgjEF4n1erPXHcC0NOsfwyAJ(u"ࠫࡋ࡛ࡌࡍࡡࡘࡔࡉࡇࡔࡆࠩ႖")
	nlCqPoLyQszuT = [lljaEqwTVtmKsQcOrbXxS5hgNH(u"ࠬ࠾࠮࠶࠰࠳ࠫ႗"),YY8UDX3MJhb91AHw7fg(u"࠭࠲࠱࠴࠴࠲࠶࠶࠮࠲࠻ࠪ႘"),ddiCzu6yahj5RtTISMJ48sNnZBU(u"ࠧ࠳࠲࠵࠵࠳࠷࠱࠯࠴࠷ࡥࠬ႙"),viRJWOC5jsYe84(u"ࠨ࠴࠳࠶࠶࠴࠱࠳࠰࠶࠴ࠬႚ"),N3flV6EJsD5CzS(u"ࠩ࠵࠴࠷࠸࠮࠱࠴࠱࠴࠷࠭ႛ"),LZWMikPEB81KSGyxfJtUsCA(u"ࠪ࠶࠵࠸࠲࠯࠳࠳࠲࠷࠸ࠧႜ"),lljaEqwTVtmKsQcOrbXxS5hgNH(u"ࠫ࠷࠶࠲࠴࠰࠳࠷࠳࠶࠶ࠨႝ"),IaBhDMJc17302LgSvyxd(u"ࠬ࠸࠰࠳࠵࠱࠴࠺࠴࠱࠷ࠩ႞"),zYvEaigKWjoq50pXBLDbGJkFc(u"࠭࠲࠱࠴࠶࠲࠵࠼࠮࠱࠸ࠪ႟"),c2RKu0xG1eC8MiohyE(u"ࠧ࠳࠲࠵࠷࠳࠷࠰࠯࠴࠻ࠫႠ"),kYDaz79TFlXoR(u"ࠨ࠴࠳࠶࠹࠴࠰࠲࠰࠴࠸ࠬႡ"),c2RKu0xG1eC8MiohyE(u"ࠩ࠵࠴࠷࠺࠮࠱࠹࠱࠶࠵࠭Ⴂ"),DiJ8CMuYH1daWyjehfN0L(u"ࠪ࠶࠵࠸࠵࠯࠲࠸࠲࠵࠻ࠧႣ"),UUDAiytEL76RTmMYsuIz5evXB(u"ࠫ࠷࠶࠲࠶࠰࠴࠵࠳࠹࠰ࠨႤ")]
	YYW3M8gGPwXbsmd = nlCqPoLyQszuT[-mZi0S72jGoHpLO]
	tK2IfkW9GdqJTMn15jclZ = BU2EpuS8nvF(YYW3M8gGPwXbsmd)
	sEToNcDhOqlktC92eFxGPSjdIKYw = BU2EpuS8nvF(Q8q1YzIF6icWtSp2L)
	if sEToNcDhOqlktC92eFxGPSjdIKYw>tK2IfkW9GdqJTMn15jclZ:
		HZJeYgfyKuwVci3Nj = fWoVd0Bmtkx(u"࡙ࠬࡉࡎࡒࡏࡉࡤ࡛ࡐࡅࡃࡗࡉࠬႥ")
	return HZJeYgfyKuwVci3Nj
def p4z1rSkcvW3OgjmsFtdLG(FAHCtdm48uIsx):
	b25HOivQdefL0AUruD6yo9nt,j3Gny0vVIepxizbZ8sR5WhQf9H6tmo = qpFY4hAwolV3,ag8rjZo1Vz4IPdcOT
	if FAHCtdm48uIsx: b25HOivQdefL0AUruD6yo9nt = XXyMBNAVJvKiq7jc20bEw6(WoFsvbmUlDZp7PzRfdGknCV,RlOvin8YIGC2KZXJPk9m0acrMobUex(u"࠭ࡳࡵࡴࠪႦ"),tQMjXKCA5dN4xq3beVIzaEoWkFLg(u"ࠧࡎࡋࡖࡇࡤ࡚ࡅࡎࡒࡢ࠵ࠬႧ"),Ie5s2cBtSfdHjzQ4rA9kYlo6D18(u"ࠨࡇ࡛ࡘࡗࡇࡐ࡚ࡖࡋࡓࡓࡉࡏࡅࡇࠪႨ"))
	if not b25HOivQdefL0AUruD6yo9nt:
		Cm4xfTO625jyMtZ8GEpvuKcnbQ1gD = i4bFG3rKE6.SITESURLS[iNc3KxwErnQ(u"ࠩࡓ࡝࡙ࡎࡏࡏࠩႩ")][iNc3KxwErnQ(u"࠹ᛎ")]
		xJyvEDcMaBj0Ph37b8WeIlNiU = {DiJ8CMuYH1daWyjehfN0L(u"ࠪࡹࡸ࡫ࡲࠨႪ"):i4bFG3rKE6.AV_CLIENT_IDS,BRWqdruz2A0(u"ࠫࡻ࡫ࡲࡴ࡫ࡲࡲࠬႫ"):Q8q1YzIF6icWtSp2L}
		b25HOivQdefL0AUruD6yo9nt = SXEgBUeDR78i40AoZupqclMhmxfN(YY8UDX3MJhb91AHw7fg(u"ࠬࡖࡏࡔࡖࠪႬ"),Cm4xfTO625jyMtZ8GEpvuKcnbQ1gD,xJyvEDcMaBj0Ph37b8WeIlNiU,qpFY4hAwolV3,DaFZHsThGmd0zv6e(u"࠭ࡌࡊࡄࡕࡅࡗ࡟࠭ࡆ࡚ࡗࡖࡆࡥࡐ࡚ࡖࡋࡓࡓࡥࡃࡐࡆࡈ࠱࠶ࡹࡴࠨႭ"))
		WRa8n54C9T(i4bFG3rKE6.api_python_actions[dJHDqiKf12TXlIzSLkGUuxg4MBs3A(u"࠺ᛏ")])
		if b25HOivQdefL0AUruD6yo9nt: zOYMaQ0NgdiRVwDJXh8e(WoFsvbmUlDZp7PzRfdGknCV,tQMjXKCA5dN4xq3beVIzaEoWkFLg(u"ࠧࡎࡋࡖࡇࡤ࡚ࡅࡎࡒࡢ࠵ࠬႮ"),zYvEaigKWjoq50pXBLDbGJkFc(u"ࠨࡇ࡛ࡘࡗࡇࡐ࡚ࡖࡋࡓࡓࡉࡏࡅࡇࠪႯ"),b25HOivQdefL0AUruD6yo9nt,ivLg9zRnGF83u)
		j3Gny0vVIepxizbZ8sR5WhQf9H6tmo = gBExoceumj4y8bFW9hY2aNMVSr
	if b25HOivQdefL0AUruD6yo9nt:
		global NEW_SITESURLS,NEW_BADSCRAPERS,NEW_BADWEBSITES,NEW_BADCOMMONIDS,yyHXWxbQARkz0YZctOdSCpg
		NEW_SITESURLS,NEW_BADSCRAPERS,NEW_BADWEBSITES,NEW_BADCOMMONIDS,yyHXWxbQARkz0YZctOdSCpg = {},[],{},[],{}
		exec(b25HOivQdefL0AUruD6yo9nt,globals(),locals())
		i4bFG3rKE6.SITESURLS.update(NEW_SITESURLS)
		i4bFG3rKE6.WEBCACHEDATA.update(yyHXWxbQARkz0YZctOdSCpg)
		i4bFG3rKE6.BADSCRAPERS = list(set(i4bFG3rKE6.BADSCRAPERS+NEW_BADSCRAPERS))
		i4bFG3rKE6.BADCOMMONIDS = list(set(i4bFG3rKE6.BADCOMMONIDS+NEW_BADCOMMONIDS))
		if Q8q1YzIF6icWtSp2L in list(NEW_BADWEBSITES.keys()): i4bFG3rKE6.BADWEBSITES += NEW_BADWEBSITES[Q8q1YzIF6icWtSp2L]
	return j3Gny0vVIepxizbZ8sR5WhQf9H6tmo
def giNkSFytDpdau1KH936r587LAUcql():
	try: RPbaxsNFVTwek5Kfv21DiJuzCnjMZp.makedirs(F8qeAKZjGRMNXimho2gntaV0)
	except: pass
	W3sgDh8SefM = d1d0qjI48MeizL7mPDkRt()
	if W3sgDh8SefM==qqzwE6imYG4c2xojI(u"ࠩࡖࡍࡒࡖࡌࡆࡡࡘࡔࡉࡇࡔࡆࠩႰ"): LLvyStW429DEZKlA(k8kdUSxohLVljnrY,zYvEaigKWjoq50pXBLDbGJkFc(u"ࠪ࠲ࡡࡺࡁࡳࡣࡥ࡭ࡨ࡜ࡩࡥࡧࡲࡷ࡛ࠥࡰࡥࡣࡷࡩ࡚ࠥࡹࡱࡧ࠽ࠤ࡙ࠥࡉࡎࡒࡏࡉ࡛ࠥࡐࡅࡃࡗࡉࠥࠦࠠࡑࡣࡷ࡬࠿࡛ࠦࠡࠩႱ")+Ry9jtldkPEA+UUDAiytEL76RTmMYsuIz5evXB(u"ࠫࠥࡣࠧႲ"))
	else: LLvyStW429DEZKlA(k8kdUSxohLVljnrY,tR1krDGPpO025fghMT3a7UnYj(u"ࠬ࠴࡜ࡵࡃࡵࡥࡧ࡯ࡣࡗ࡫ࡧࡩࡴࡹࠠࡖࡲࡧࡥࡹ࡫ࠠࡕࡻࡳࡩ࠿ࠦࠠࡇࡗࡏࡐ࡛ࠥࡐࡅࡃࡗࡉࠥࠦࠠࡑࡣࡷ࡬࠿࡛ࠦࠡࠩႳ")+Ry9jtldkPEA+kYDaz79TFlXoR(u"࠭ࠠ࡞ࠩႴ"))
	iG7Rz2kmn0x1yLNMV3u8O(qpFY4hAwolV3,qpFY4hAwolV3,GLTtERWbHnFuy4PCp,UVa3fJw7k6KM(u"ࠧห็ࠣฮาี๊ฬࠢส่อืๆศ็ฯࠤๆ๐ࠠอ้สึ่ࡢ࡮ฦๆ์ࠤฬ๊ลึัสีࠥืโๆ࠼࡟ࡲࡡࡴࠧႵ")+Q8q1YzIF6icWtSp2L)
	iG7Rz2kmn0x1yLNMV3u8O(qpFY4hAwolV3,qpFY4hAwolV3,GLTtERWbHnFuy4PCp,c2RKu0xG1eC8MiohyE(u"ࠨฬ่ࠤฯัศ๋ฬࠣวํࠦสฮัํฯࠥอไฦืาหึࠦวๅฮา๎ิࠦไษำ้ห๊าࠠศๆไ๎ิ๐่่ษอࠤฬู๊าสํอࠥ࠴ࠠฤ๊ࠣฮ๊ࠦๅิฯࠣ็ฬฺࠠศๆหี๋อๅอࠢ࡟ࡲࡡࡴࠠิ์ๅ์๊ࠦวๅฤ้ࠤฬ๊ศา่ส้ัࠦศษ฻ูࠤฬ๊แฮุ๊หฯࠦไื็ส๊ࠥ฿ๅๅࠢส่อืๆศ็ฯࠤอ฻่าหูࠣา๐อส๋้ࠢฯ้วๆๆฬࠫႶ"))
	mlykPoGXbJIjFnarp9KihxfN(WoFsvbmUlDZp7PzRfdGknCV,lljaEqwTVtmKsQcOrbXxS5hgNH(u"ࠩࡐࡍࡘࡉ࡟ࡕࡇࡐࡔࡤ࠷ࠧႷ"))
	mlykPoGXbJIjFnarp9KihxfN(WoFsvbmUlDZp7PzRfdGknCV,aXqWLoTdVgME(u"ࠪࡑࡎ࡙ࡃࡠࡖࡈࡑࡕࡥ࠲ࠨႸ"))
	mlykPoGXbJIjFnarp9KihxfN(WoFsvbmUlDZp7PzRfdGknCV,tQMjXKCA5dN4xq3beVIzaEoWkFLg(u"ࠫࡋࡕࡒࡘࡃࡕࡈࡘ࠭Ⴙ"))
	mlykPoGXbJIjFnarp9KihxfN(WoFsvbmUlDZp7PzRfdGknCV,rNdBKI74fAklnoCZ6(u"ࠬࡈࡌࡐࡅࡎࡉࡉࡥࡗࡆࡄࡖࡍ࡙ࡋࡓࠨႺ"))
	mlykPoGXbJIjFnarp9KihxfN(WoFsvbmUlDZp7PzRfdGknCV,dJHDqiKf12TXlIzSLkGUuxg4MBs3A(u"࠭ࡍࡊࡕࡆࡣࡕࡋࡒࡎࠩႻ"),ee86G9ladLHVbh5mikzCo(u"ࠧࡔࡋࡗࡉࡘࡥࡎࡂࡏࡈࡗࠬႼ"))
	mlykPoGXbJIjFnarp9KihxfN(WoFsvbmUlDZp7PzRfdGknCV,BRWqdruz2A0(u"ࠨࡏࡌࡗࡈࡥࡐࡆࡔࡐࠫႽ"),UVa3fJw7k6KM(u"ࠩࡖࡍ࡙ࡋࡓࡠࡅࡋࡉࡈࡑࠧႾ"))
	mlykPoGXbJIjFnarp9KihxfN(WoFsvbmUlDZp7PzRfdGknCV,qoBMmfAWpFlK70xw8ZRh4naJ(u"ࠪࡑࡎ࡙ࡃࡠࡒࡈࡖࡒ࠭Ⴟ"),sjtU6GZQg5XC2pH4(u"ࠫࡘࡏࡔࡆࡕࡢ࡚ࡊࡘࡉࡇ࡛ࠪჀ"))
	gdPslyFW8ITBcpA302.setSetting(tR1krDGPpO025fghMT3a7UnYj(u"ࠬࡧࡶ࠯ࡪࡲࡷࡹ࠴ࡦࡰࡵࡷࡥࠬჁ"),qpFY4hAwolV3)
	gdPslyFW8ITBcpA302.setSetting(l32dnTEOU1skGKqeBtI9hmo(u"࠭ࡡࡷ࠰࡫ࡳࡸࡺ࠮ࡧࡣࡥࡶࡦࡱࡡࠨჂ"),qpFY4hAwolV3)
	gdPslyFW8ITBcpA302.setSetting(viRJWOC5jsYe84(u"ࠧࡢࡸ࠱࡬ࡴࡹࡴ࠯ࡵ࡫ࡥ࡭࡯ࡤ࠵ࡷࠪჃ"),qpFY4hAwolV3)
	gdPslyFW8ITBcpA302.setSetting(ddiCzu6yahj5RtTISMJ48sNnZBU(u"ࠨࡣࡹ࠲࡭ࡵࡳࡵ࠰ࡩࡥࡸ࡫࡬ࡩࡦ࠴ࠫჄ"),qpFY4hAwolV3)
	gdPslyFW8ITBcpA302.setSetting(UVa3fJw7k6KM(u"ࠩࡤࡺ࠳ࡶࡲࡪࡸࡶ࠵ࠬჅ"),qpFY4hAwolV3)
	gdPslyFW8ITBcpA302.setSetting(viRJWOC5jsYe84(u"ࠪࡥࡻ࠴ࡰࡦࡴ࡬ࡳࡩ࠴ࡩ࡯ࡨࡲࡷࠬ჆"),qpFY4hAwolV3)
	gdPslyFW8ITBcpA302.setSetting(dJHDqiKf12TXlIzSLkGUuxg4MBs3A(u"ࠫࡦࡼ࠮࡭ࡣࡶࡸࡨ࡮ࡥࡤ࡭࠱ࡷ࡭ࡵࡲࡵࠩჇ"),qpFY4hAwolV3)
	gdPslyFW8ITBcpA302.setSetting(ddiCzu6yahj5RtTISMJ48sNnZBU(u"ࠬࡧࡶ࠯࡮ࡤࡷࡹࡩࡨࡦࡥ࡮࠲ࡷ࡫ࡧࡶ࡮ࡤࡶࠬ჈"),qpFY4hAwolV3)
	gdPslyFW8ITBcpA302.setSetting(kYDaz79TFlXoR(u"࠭ࡡࡷ࠰࡯ࡥࡸࡺࡣࡩࡧࡦ࡯࠳ࡲ࡯࡯ࡩࠪ჉"),qpFY4hAwolV3)
	gdPslyFW8ITBcpA302.setSetting(YY8UDX3MJhb91AHw7fg(u"ࠧࡢࡸ࠱ࡰࡦࡹࡴࡤࡪࡨࡧࡰ࠴࡭ࡦࡵࡶࡥ࡬࡫ࡳࠨ჊"),qpFY4hAwolV3)
	gdPslyFW8ITBcpA302.setSetting(rNdBKI74fAklnoCZ6(u"ࠨࡣࡹ࠲ࡱࡧࡳࡵࡥ࡫ࡩࡨࡱ࠮ࡲࡷࡨࡷࡹ࡯࡯࡯ࡵࠪ჋"),qpFY4hAwolV3)
	mlykPoGXbJIjFnarp9KihxfN(WoFsvbmUlDZp7PzRfdGknCV,mmV2nucZ5Lpl6FO1JMPEqGoQKW(u"ࠩࡖࡉࡈ࡚ࡉࡐࡐࡖࡣࡘࡏࡔࡆࡕࠪ჌"))
	mlykPoGXbJIjFnarp9KihxfN(WoFsvbmUlDZp7PzRfdGknCV,Ie5s2cBtSfdHjzQ4rA9kYlo6D18(u"ࠪࡗࡊࡉࡔࡊࡑࡑࡗࡤࡏࡐࡕࡘࠪჍ"))
	mlykPoGXbJIjFnarp9KihxfN(WoFsvbmUlDZp7PzRfdGknCV,lljaEqwTVtmKsQcOrbXxS5hgNH(u"ࠫࡘࡋࡃࡕࡋࡒࡒࡘࡥࡍ࠴ࡗࠪ჎"))
	mlykPoGXbJIjFnarp9KihxfN(WoFsvbmUlDZp7PzRfdGknCV,qqzwE6imYG4c2xojI(u"࡙ࠬࡃࡓࡃࡓࡉࡗ࡙ࠧ჏"))
	PAfd3TnXb2oz(ag8rjZo1Vz4IPdcOT)
	UnGr9wJWdq(dzcNuIbsgK3yZ6SXGaEHPfOj5vk)
	import t5tWekJ6XG
	t5tWekJ6XG.qx7AQkCSGFfpTn(aXqWLoTdVgME(u"࠭ࡩ࡯ࡲࡸࡸࡸࡺࡲࡦࡣࡰ࠲ࡦࡪࡡࡱࡶ࡬ࡺࡪ࠭ა"),ag8rjZo1Vz4IPdcOT)
	t5tWekJ6XG.qx7AQkCSGFfpTn(DaFZHsThGmd0zv6e(u"ࠧࡪࡰࡳࡹࡹࡹࡴࡳࡧࡤࡱ࠳ࡸࡴ࡮ࡲࠪბ"),ag8rjZo1Vz4IPdcOT)
	t5tWekJ6XG.qx7AQkCSGFfpTn(mmV2nucZ5Lpl6FO1JMPEqGoQKW(u"ࠨ࡫ࡱࡴࡺࡺࡳࡵࡴࡨࡥࡲ࠴ࡦࡧ࡯ࡳࡩ࡬ࡪࡩࡳࡧࡦࡸࠬგ"),ag8rjZo1Vz4IPdcOT)
	t5tWekJ6XG.Yz4RMHeNEZ9PO7VhxGcQjfs1(gBExoceumj4y8bFW9hY2aNMVSr)
	t5tWekJ6XG.Q4LNO7l9gpTIXVkwjs(ag8rjZo1Vz4IPdcOT)
	if W3sgDh8SefM==dJHDqiKf12TXlIzSLkGUuxg4MBs3A(u"ࠩࡖࡍࡒࡖࡌࡆࡡࡘࡔࡉࡇࡔࡆࠩდ"):
		KXWjTQvV1HGIB2RP3yedZk(gBExoceumj4y8bFW9hY2aNMVSr,[WoFsvbmUlDZp7PzRfdGknCV])
	else:
		KXWjTQvV1HGIB2RP3yedZk(ag8rjZo1Vz4IPdcOT,[])
		t5tWekJ6XG.pNUteOHcV7bf62zAWBS0X9()
		try:
			p2ih6mIbDwBME = RPbaxsNFVTwek5Kfv21DiJuzCnjMZp.path.join(ssQ5T7em6WrVwIGtXoxNKaBv48zHAM,rNdBKI74fAklnoCZ6(u"ࠪࡹࡸ࡫ࡲࡥࡣࡷࡥࠬე"),qqzwE6imYG4c2xojI(u"ࠫࡦࡪࡤࡰࡰࡢࡨࡦࡺࡡࠨვ"),IaBhDMJc17302LgSvyxd(u"ࠬࡹࡣࡳ࡫ࡳࡸ࠳ࡳ࡯ࡥࡷ࡯ࡩ࠳ࡸࡥࡴࡱ࡯ࡺࡪࡻࡲ࡭ࠩზ"),mmV2nucZ5Lpl6FO1JMPEqGoQKW(u"࠭ࡳࡦࡶࡷ࡭ࡳ࡭ࡳ࠯ࡺࡰࡰࠬთ"))
			ShUqA0mLnbD5XHisCBxaNIvP8KljFo = xzFaGrIK6wyE5fBlPvb0.Addon(id=ee86G9ladLHVbh5mikzCo(u"ࠧࡴࡥࡵ࡭ࡵࡺ࠮࡮ࡱࡧࡹࡱ࡫࠮ࡳࡧࡶࡳࡱࡼࡥࡶࡴ࡯ࠫი"))
			ShUqA0mLnbD5XHisCBxaNIvP8KljFo.setSetting(zYvEaigKWjoq50pXBLDbGJkFc(u"ࠨࡣࡹ࠲ࡦࡻࡴࡰࡡࡳ࡭ࡨࡱࠧკ"),lljaEqwTVtmKsQcOrbXxS5hgNH(u"ࠩࡉࡥࡱࡹࡥࠨლ"))
		except: pass
		try:
			p2ih6mIbDwBME = RPbaxsNFVTwek5Kfv21DiJuzCnjMZp.path.join(ssQ5T7em6WrVwIGtXoxNKaBv48zHAM,ddiCzu6yahj5RtTISMJ48sNnZBU(u"ࠪࡹࡸ࡫ࡲࡥࡣࡷࡥࠬმ"),rNdBKI74fAklnoCZ6(u"ࠫࡦࡪࡤࡰࡰࡢࡨࡦࡺࡡࠨნ"),l32dnTEOU1skGKqeBtI9hmo(u"ࠬࡹࡣࡳ࡫ࡳࡸ࠳ࡳ࡯ࡥࡷ࡯ࡩ࠳ࡿࡴ࠮ࡦ࡯ࡴࠬო"),mmV2nucZ5Lpl6FO1JMPEqGoQKW(u"࠭ࡳࡦࡶࡷ࡭ࡳ࡭ࡳ࠯ࡺࡰࡰࠬპ"))
			ShUqA0mLnbD5XHisCBxaNIvP8KljFo = xzFaGrIK6wyE5fBlPvb0.Addon(id=CC1eY6yWZUwf2TkRvnp7EJ0AimjHBX(u"ࠧࡴࡥࡵ࡭ࡵࡺ࠮࡮ࡱࡧࡹࡱ࡫࠮ࡺࡶ࠰ࡨࡱࡶࠧჟ"))
			ShUqA0mLnbD5XHisCBxaNIvP8KljFo.setSetting(mmV2nucZ5Lpl6FO1JMPEqGoQKW(u"ࠨࡣࡹ࠲ࡻ࡯ࡤࡦࡱࡢࡵࡺࡧ࡬ࡪࡶࡼࠫრ"),ee86G9ladLHVbh5mikzCo(u"ࠩ࠶ࠫს"))
		except: pass
		try:
			p2ih6mIbDwBME = RPbaxsNFVTwek5Kfv21DiJuzCnjMZp.path.join(ssQ5T7em6WrVwIGtXoxNKaBv48zHAM,N3flV6EJsD5CzS(u"ࠪࡹࡸ࡫ࡲࡥࡣࡷࡥࠬტ"),fWoVd0Bmtkx(u"ࠫࡦࡪࡤࡰࡰࡢࡨࡦࡺࡡࠨუ"),qqzwE6imYG4c2xojI(u"ࠬ࡯࡮ࡱࡷࡷࡷࡹࡸࡥࡢ࡯࠱ࡥࡩࡧࡰࡵ࡫ࡹࡩࠬფ"),DiJ8CMuYH1daWyjehfN0L(u"࠭ࡳࡦࡶࡷ࡭ࡳ࡭ࡳ࠯ࡺࡰࡰࠬქ"))
			ShUqA0mLnbD5XHisCBxaNIvP8KljFo = xzFaGrIK6wyE5fBlPvb0.Addon(id=aXqWLoTdVgME(u"ࠧࡪࡰࡳࡹࡹࡹࡴࡳࡧࡤࡱ࠳ࡧࡤࡢࡲࡷ࡭ࡻ࡫ࠧღ"))
			ShUqA0mLnbD5XHisCBxaNIvP8KljFo.setSetting(Ie5s2cBtSfdHjzQ4rA9kYlo6D18(u"ࠨࡣࡹ࠲ࡘ࡚ࡒࡆࡃࡐࡗࡊࡒࡅࡄࡖࡌࡓࡓ࠭ყ"),RlOvin8YIGC2KZXJPk9m0acrMobUex(u"ࠩ࠵ࠫშ"))
		except: pass
	dimhv1XTVH8UOrc9EGJZ6 = O8UnIZ9TiHSzXbvxGgs7wlR(RRCjYOQfEdAKub2s)
	dimhv1XTVH8UOrc9EGJZ6 = O8UnIZ9TiHSzXbvxGgs7wlR(V2JfszPWt6jq1hCxYKpyM53RL)
	t5tWekJ6XG.zzV4dDTMsGIoB8hqWp5(ag8rjZo1Vz4IPdcOT)
	gdPslyFW8ITBcpA302.setSetting(rNdBKI74fAklnoCZ6(u"ࠪࡥࡻ࠴ࡶࡦࡴࡶ࡭ࡴࡴࠧჩ"),Q8q1YzIF6icWtSp2L)
	E2E18vJ4hLaZpuWSfoMlY9yBzj6b(ag8rjZo1Vz4IPdcOT)
	return
def hh29YaqZDXR(wc8X04F1e6u):
	j3Gny0vVIepxizbZ8sR5WhQf9H6tmo = p4z1rSkcvW3OgjmsFtdLG(gBExoceumj4y8bFW9hY2aNMVSr)
	if j3Gny0vVIepxizbZ8sR5WhQf9H6tmo:
		return
	zgHxyUv4fP9BI3j = NinEO2UTBHXh(gdPslyFW8ITBcpA302.getSetting(tR1krDGPpO025fghMT3a7UnYj(u"ࠫࡦࡼ࠮࡭ࡣࡶࡸࡨ࡮ࡥࡤ࡭࠱ࡷ࡭ࡵࡲࡵࠩც")))
	zgHxyUv4fP9BI3j = vvXoMLlg513 if not zgHxyUv4fP9BI3j else int(zgHxyUv4fP9BI3j)
	if not zgHxyUv4fP9BI3j or not vvXoMLlg513<=dAeP20gNJ6ltq-zgHxyUv4fP9BI3j<=rGY36xBwT1bLZAngSfcWEIeXdQVNij:
		gdPslyFW8ITBcpA302.setSetting(l32dnTEOU1skGKqeBtI9hmo(u"ࠬࡧࡶ࠯࡮ࡤࡷࡹࡩࡨࡦࡥ࡮࠲ࡸ࡮࡯ࡳࡶࠪძ"),Ikw7JgrXvRT8zteLb5sV6WidBN(dAeP20gNJ6ltq))
		UnGr9wJWdq(dzcNuIbsgK3yZ6SXGaEHPfOj5vk)
		return
	zlMbr1fLXjvSTI3J0iWZqnBQdVN6E = NinEO2UTBHXh(gdPslyFW8ITBcpA302.getSetting(BRWqdruz2A0(u"࠭ࡡࡷ࠰ࡳࡩࡷ࡯࡯ࡥ࠰࡬ࡲ࡫ࡵࡳࠨწ")))
	zlMbr1fLXjvSTI3J0iWZqnBQdVN6E = vvXoMLlg513 if not zlMbr1fLXjvSTI3J0iWZqnBQdVN6E else int(zlMbr1fLXjvSTI3J0iWZqnBQdVN6E)
	UnamzxlLuVW0wHbOeyCKqD4XGSIR1s = NinEO2UTBHXh(gdPslyFW8ITBcpA302.getSetting(UUDAiytEL76RTmMYsuIz5evXB(u"ࠧࡢࡸ࠱ࡰࡦࡹࡴࡤࡪࡨࡧࡰ࠴ࡱࡶࡧࡶࡸ࡮ࡵ࡮ࡴࠩჭ")))
	UnamzxlLuVW0wHbOeyCKqD4XGSIR1s = vvXoMLlg513 if not UnamzxlLuVW0wHbOeyCKqD4XGSIR1s else int(UnamzxlLuVW0wHbOeyCKqD4XGSIR1s)
	if not zlMbr1fLXjvSTI3J0iWZqnBQdVN6E or not UnamzxlLuVW0wHbOeyCKqD4XGSIR1s or not vvXoMLlg513<=dAeP20gNJ6ltq-UnamzxlLuVW0wHbOeyCKqD4XGSIR1s<=zlMbr1fLXjvSTI3J0iWZqnBQdVN6E:
		iC6wSrOx1zuYgqoTk9fHy(gBExoceumj4y8bFW9hY2aNMVSr,zlMbr1fLXjvSTI3J0iWZqnBQdVN6E)
		return
	gc7rOBlFH3pWkCVA4i = NinEO2UTBHXh(gdPslyFW8ITBcpA302.getSetting(YY8UDX3MJhb91AHw7fg(u"ࠨࡣࡹ࠲ࡱࡧࡳࡵࡥ࡫ࡩࡨࡱ࠮ࡳࡧࡪࡹࡱࡧࡲࠨხ")))
	gc7rOBlFH3pWkCVA4i = vvXoMLlg513 if not gc7rOBlFH3pWkCVA4i else int(gc7rOBlFH3pWkCVA4i)
	if not gc7rOBlFH3pWkCVA4i or not vvXoMLlg513<=dAeP20gNJ6ltq-gc7rOBlFH3pWkCVA4i<=kUz8c7OqsxuPFIGfwg:
		gdPslyFW8ITBcpA302.setSetting(fWoVd0Bmtkx(u"ࠩࡤࡺ࠳ࡲࡡࡴࡶࡦ࡬ࡪࡩ࡫࠯ࡴࡨ࡫ࡺࡲࡡࡳࠩჯ"),Ikw7JgrXvRT8zteLb5sV6WidBN(dAeP20gNJ6ltq))
		p4z1rSkcvW3OgjmsFtdLG(ag8rjZo1Vz4IPdcOT)
		return
	if ag8rjZo1Vz4IPdcOT:
		Muci38YNXk01m = NinEO2UTBHXh(gdPslyFW8ITBcpA302.getSetting(UUDAiytEL76RTmMYsuIz5evXB(u"ࠪࡥࡻ࠴࡬ࡢࡵࡷࡧ࡭࡫ࡣ࡬࠰࡯ࡳࡳ࡭ࠧჰ")))
		Muci38YNXk01m = vvXoMLlg513 if not Muci38YNXk01m else int(Muci38YNXk01m)
		if not Muci38YNXk01m or not vvXoMLlg513<=dAeP20gNJ6ltq-Muci38YNXk01m<=KOyPvpEztYLaZRdMQJWxfTNFHbkg:
			gdPslyFW8ITBcpA302.setSetting(CC1eY6yWZUwf2TkRvnp7EJ0AimjHBX(u"ࠫࡦࡼ࠮࡭ࡣࡶࡸࡨ࡮ࡥࡤ࡭࠱ࡰࡴࡴࡧࠨჱ"),Ikw7JgrXvRT8zteLb5sV6WidBN(dAeP20gNJ6ltq))
	return
def iC6wSrOx1zuYgqoTk9fHy(FAHCtdm48uIsx,zlMbr1fLXjvSTI3J0iWZqnBQdVN6E):
	ooVc6UmITkNG7hg0XOzMj3eAZCqR = mZi0S72jGoHpLO
	Cu17wKQrgxJVYXHl2si = ag8rjZo1Vz4IPdcOT if i4bFG3rKE6.XXvY7VDsGwhMLy4iaABHQOp else gBExoceumj4y8bFW9hY2aNMVSr
	if Cu17wKQrgxJVYXHl2si:
		if not zlMbr1fLXjvSTI3J0iWZqnBQdVN6E: FAHCtdm48uIsx = ag8rjZo1Vz4IPdcOT
		weoxDcHJ1PsSiE5pqY7bWMIfX = asFZzCl2vSoiNRU34K(FAHCtdm48uIsx)
		if len(weoxDcHJ1PsSiE5pqY7bWMIfX)>mZi0S72jGoHpLO:
			LLvyStW429DEZKlA(k8kdUSxohLVljnrY,rNdBKI74fAklnoCZ6(u"ࠬ࠴࡜ࡵࡕ࡫ࡳࡼ࡯࡮ࡨࠢࡔࡹࡪࡹࡴࡪࡱࡱࠤࠥࠦࡐࡢࡶ࡫࠾ࠥࡡࠠࠨჲ")+Ry9jtldkPEA+N3flV6EJsD5CzS(u"࠭ࠠ࡞ࠩჳ"))
			Zu96PkNGaiqRH3d,WRbn1LC2xPJMZft,nKb2w7UW0qVN,OkL6wBRsf4,T97ftnWyDr2coKalSe,AGUTOIbFi4tDB1 = weoxDcHJ1PsSiE5pqY7bWMIfX[vvXoMLlg513]
			SYdPURfIsm4j1CT80upw,j8XLTuY5xcO = OkL6wBRsf4.split(rNdBKI74fAklnoCZ6(u"ࠧ࡝ࡰ࠾࠿ࠬჴ"))
			del weoxDcHJ1PsSiE5pqY7bWMIfX[vvXoMLlg513]
			woMdZNyhitPIVqg25acCkLRfmFrDH = P9Kfwdgna8erGcAWyQMOtFbq6Rk.sample(weoxDcHJ1PsSiE5pqY7bWMIfX,mZi0S72jGoHpLO)
			Zu96PkNGaiqRH3d,WRbn1LC2xPJMZft,nKb2w7UW0qVN,OkL6wBRsf4,T97ftnWyDr2coKalSe,AGUTOIbFi4tDB1 = woMdZNyhitPIVqg25acCkLRfmFrDH[vvXoMLlg513]
			nKb2w7UW0qVN = DiJ8CMuYH1daWyjehfN0L(u"ࠨ࡝ࡕࡘࡑࡣࠧჵ")+IQ2KCmObsTGuiRdEzt931a40jLg+viRJWOC5jsYe84(u"ࠩࠣ࠾ࠥ࠭ჶ")+Zu96PkNGaiqRH3d+fF4lt9zWYxXLKZVyAco82PgMj+nKb2w7UW0qVN
			T97ftnWyDr2coKalSe = ddiCzu6yahj5RtTISMJ48sNnZBU(u"ࠪษึูวๅࠢิืฬ๊ษࠡๆ็้อืๅอࠩჷ")
			dmgJWcr8si = BRWqdruz2A0(u"ࠫฬ๊สษำ฼หฯ࠭ჸ")
			button0,button1 = OkL6wBRsf4,T97ftnWyDr2coKalSe
			TOzNltPw3x6BDgvKJaWjGs8bfFkHn4 = [button0,button1,dmgJWcr8si]
			NUiyw0u7blFAadfx1Imq = mZi0S72jGoHpLO if i4bFG3rKE6.ZZFcMiWJ3nfg29XH4L else V3VlkhgjEF4n1erPXHcC0NOsfwyAJ(u"࠳࠳ᛐ")
			muaCBROQ72TixfPh683Y59qH = -l1DZAt9XNQjqE7YOdrz(u"࠼ᛑ")
			while muaCBROQ72TixfPh683Y59qH<vvXoMLlg513:
				fvpNlrX974xzIuJcMaLsnjoY = P9Kfwdgna8erGcAWyQMOtFbq6Rk.sample(TOzNltPw3x6BDgvKJaWjGs8bfFkHn4,DAE6vkyhXGx1wBdHmcFfTVQpL0l)
				muaCBROQ72TixfPh683Y59qH = eVLmAIGFiwpr94UK6MRP5(qpFY4hAwolV3,fvpNlrX974xzIuJcMaLsnjoY[vvXoMLlg513],fvpNlrX974xzIuJcMaLsnjoY[mZi0S72jGoHpLO],fvpNlrX974xzIuJcMaLsnjoY[Zwqio2AIWlD5etFa],SYdPURfIsm4j1CT80upw,nKb2w7UW0qVN,DiJ8CMuYH1daWyjehfN0L(u"ࠬࡩ࡯࡯ࡨ࡬ࡶࡲࡥࡢࡪࡩࡩࡳࡳࡺࠧჹ"),NUiyw0u7blFAadfx1Imq,l1DZAt9XNQjqE7YOdrz(u"࠺࠵ᛒ"))
				if muaCBROQ72TixfPh683Y59qH==ee86G9ladLHVbh5mikzCo(u"࠶࠶ᛓ"): break
				import t5tWekJ6XG
				if muaCBROQ72TixfPh683Y59qH>=vvXoMLlg513 and fvpNlrX974xzIuJcMaLsnjoY[muaCBROQ72TixfPh683Y59qH]==TOzNltPw3x6BDgvKJaWjGs8bfFkHn4[mZi0S72jGoHpLO]:
					t5tWekJ6XG.cSYpMx6W4HlAQK9()
					if muaCBROQ72TixfPh683Y59qH>=vvXoMLlg513: muaCBROQ72TixfPh683Y59qH = -tR1krDGPpO025fghMT3a7UnYj(u"࠿ᛔ")
				elif muaCBROQ72TixfPh683Y59qH>=vvXoMLlg513 and fvpNlrX974xzIuJcMaLsnjoY[muaCBROQ72TixfPh683Y59qH]==TOzNltPw3x6BDgvKJaWjGs8bfFkHn4[Zwqio2AIWlD5etFa]:
					t5tWekJ6XG.PThFb1sQXfUl0RuHBVJStj(ag8rjZo1Vz4IPdcOT)
				if muaCBROQ72TixfPh683Y59qH==-mZi0S72jGoHpLO: iG7Rz2kmn0x1yLNMV3u8O(qpFY4hAwolV3,qpFY4hAwolV3,GLTtERWbHnFuy4PCp,IQ2KCmObsTGuiRdEzt931a40jLg+UUDAiytEL76RTmMYsuIz5evXB(u"࠭ฮา๊ฯࠤำ฽รࠨჺ")+fF4lt9zWYxXLKZVyAco82PgMj+viRJWOC5jsYe84(u"ࠧ࡝ࡰ่้ࠣิั้ฮࠣห้฻อ๋ฯࠣวำะั๊ࠡสัิࠦๅ็ࠢส่ศา่ษหࠣห้๋ส้ใิอࠬ჻"))
			ooVc6UmITkNG7hg0XOzMj3eAZCqR = mZi0S72jGoHpLO
		else: ooVc6UmITkNG7hg0XOzMj3eAZCqR = vvXoMLlg513
	gdPslyFW8ITBcpA302.setSetting(BRWqdruz2A0(u"ࠨࡣࡹ࠲ࡱࡧࡳࡵࡥ࡫ࡩࡨࡱ࠮ࡲࡷࡨࡷࡹ࡯࡯࡯ࡵࠪჼ"),Ikw7JgrXvRT8zteLb5sV6WidBN(dAeP20gNJ6ltq))
	zOYMaQ0NgdiRVwDJXh8e(WoFsvbmUlDZp7PzRfdGknCV,kYDaz79TFlXoR(u"ࠩࡐࡍࡘࡉ࡟ࡑࡇࡕࡑࠬჽ"),ddiCzu6yahj5RtTISMJ48sNnZBU(u"ࠪࡗࡎ࡚ࡅࡔࡡࡑࡅࡒࡋࡓࠨჾ"),ooVc6UmITkNG7hg0XOzMj3eAZCqR,ivLg9zRnGF83u)
	return
def HayCsqfegKTMA6NiG8PpFvJoBkl(kc8s5wJ4Px9zbiWQm,mJjTE9o7ecN8dt,Cm4xfTO625jyMtZ8GEpvuKcnbQ1gD,HNdWR8p36CtO,BvbuigUeoJLnTaN2qWxQ415AtYMK9I,i02wfPp5EM,Z4vQNwLcAiPVufj9sOgCMU6ezEWG,AArDKw6baWehCSOz7,uu5WqOEaRZIibszwTc6t1nmLfAj,wc8X04F1e6u,TILw6pQSxlhMUCJK5qZbv4o,DRbhWYuzweV3IMNCyJv8oZj10Tk):
	if TILw6pQSxlhMUCJK5qZbv4o in [LZWMikPEB81KSGyxfJtUsCA(u"ࠫ࠶࠭ჿ"),viRJWOC5jsYe84(u"ࠬ࠸ࠧᄀ"),iNc3KxwErnQ(u"࠭࠳ࠨᄁ"),lljaEqwTVtmKsQcOrbXxS5hgNH(u"ࠧ࠵ࠩᄂ"),tQMjXKCA5dN4xq3beVIzaEoWkFLg(u"ࠨ࠷ࠪᄃ"),UUDAiytEL76RTmMYsuIz5evXB(u"ࠩ࠴࠵ࠬᄄ"),IaBhDMJc17302LgSvyxd(u"ࠪ࠵࠷࠭ᄅ"),ee86G9ladLHVbh5mikzCo(u"ࠫ࠶࠹ࠧᄆ")] and DRbhWYuzweV3IMNCyJv8oZj10Tk:
		import SAyf06eKY3
		SAyf06eKY3.dmFAy3UQ2eRbJDfiNLBMX6H9tsrv(AArDKw6baWehCSOz7,TILw6pQSxlhMUCJK5qZbv4o,DRbhWYuzweV3IMNCyJv8oZj10Tk)
		E2E18vJ4hLaZpuWSfoMlY9yBzj6b(ag8rjZo1Vz4IPdcOT,Ry9jtldkPEA)
	elif TILw6pQSxlhMUCJK5qZbv4o==dJHDqiKf12TXlIzSLkGUuxg4MBs3A(u"ࠬ࠼ࠧᄇ"):
		import pSfaryIjBo,ww3OrKJBvl
		if DRbhWYuzweV3IMNCyJv8oZj10Tk==RlOvin8YIGC2KZXJPk9m0acrMobUex(u"࠭ࡄࡐ࡙ࡑࡐࡔࡇࡄࠨᄈ"): ww3OrKJBvl.t8yiLuJp3cBA6d1QE9x7eZ4fa(dJHDqiKf12TXlIzSLkGUuxg4MBs3A(u"๋ࠧำฯํࠥอไศ่อ฼ฬืࠧᄉ"),DiJ8CMuYH1daWyjehfN0L(u"ࠨฮสี๏ࠦแฮื้้ࠣ็ࠠศๆอั๊๐ไࠨᄊ"),s7FnXZYOgexlH2MPb8BJck1AKv9=N3flV6EJsD5CzS(u"࠲࠱࠲࠳ᛕ"))
		elif DRbhWYuzweV3IMNCyJv8oZj10Tk==rNdBKI74fAklnoCZ6(u"ࠩࡇࡉࡑࡋࡔࡆࠩᄋ"): woKpIqdvBGa6mgy3P2DnXHCQ(WWowRmHkj1ZAO2SUhtNvdrcKa9E6C,ag8rjZo1Vz4IPdcOT)
		MOTjA5H9XFs = pSfaryIjBo.PLd4s0tr67GpoK(kc8s5wJ4Px9zbiWQm,mJjTE9o7ecN8dt,Cm4xfTO625jyMtZ8GEpvuKcnbQ1gD,wc8X04F1e6u,BvbuigUeoJLnTaN2qWxQ415AtYMK9I,i02wfPp5EM,Z4vQNwLcAiPVufj9sOgCMU6ezEWG,AArDKw6baWehCSOz7,uu5WqOEaRZIibszwTc6t1nmLfAj)
		if DRbhWYuzweV3IMNCyJv8oZj10Tk==tR1krDGPpO025fghMT3a7UnYj(u"ࠪࡈࡔ࡝ࡎࡍࡑࡄࡈࠬᄌ"): xtm9pSeMInWo60()
	elif AArDKw6baWehCSOz7==tR1krDGPpO025fghMT3a7UnYj(u"ࠫ࠼࠭ᄍ"):
		import JSEBrVPTh9
		JSEBrVPTh9.yQsV9qYDJKotx(kYDaz79TFlXoR(u"ࠬࡥࡁࡍࡎࠪᄎ"))
		E2E18vJ4hLaZpuWSfoMlY9yBzj6b(ag8rjZo1Vz4IPdcOT)
	elif AArDKw6baWehCSOz7==c2RKu0xG1eC8MiohyE(u"࠭࠸ࠨᄏ"): Rqvw05BorCgcye7VE32Sf.executebuiltin(tR1krDGPpO025fghMT3a7UnYj(u"ࠧࡄࡱࡱࡸࡦ࡯࡮ࡦࡴ࠱࡙ࡵࡪࡡࡵࡧࠫࡴࡱࡻࡧࡪࡰ࠽࠳࠴࠭ᄐ")+xqJBEohLpFs+LZWMikPEB81KSGyxfJtUsCA(u"ࠨࡁࡰࡳࡩ࡫࠽ࠨᄑ")+str(HNdWR8p36CtO)+CC1eY6yWZUwf2TkRvnp7EJ0AimjHBX(u"ࠩࠩࡸࡾࡶࡥ࠾ࡨࡲࡰࡩ࡫ࡲࠪࠩᄒ"))
	elif AArDKw6baWehCSOz7==UVa3fJw7k6KM(u"ࠪ࠽ࠬᄓ"):
		E2E18vJ4hLaZpuWSfoMlY9yBzj6b(gBExoceumj4y8bFW9hY2aNMVSr)
	elif AArDKw6baWehCSOz7==DiJ8CMuYH1daWyjehfN0L(u"ࠫ࠶࠶ࠧᄔ"):
		import JSEBrVPTh9
		JSEBrVPTh9.yQsV9qYDJKotx(YY8UDX3MJhb91AHw7fg(u"ࠬࡥࡇࡐࡑࡊࡐࡊ࠭ᄕ"))
		E2E18vJ4hLaZpuWSfoMlY9yBzj6b(ag8rjZo1Vz4IPdcOT)
	elif AArDKw6baWehCSOz7==rNdBKI74fAklnoCZ6(u"࠭࠱࠵ࠩᄖ"): E2E18vJ4hLaZpuWSfoMlY9yBzj6b(gBExoceumj4y8bFW9hY2aNMVSr,UUDAiytEL76RTmMYsuIz5evXB(u"ࠧࡎࡇࡑ࡙ࡤࡘࡅࡗࡇࡕࡗࡊࡊ࡟ࡕࡇࡐࡔࠬᄗ"))
	elif AArDKw6baWehCSOz7==YY8UDX3MJhb91AHw7fg(u"ࠨ࠳࠸ࠫᄘ"): E2E18vJ4hLaZpuWSfoMlY9yBzj6b(gBExoceumj4y8bFW9hY2aNMVSr,UUDAiytEL76RTmMYsuIz5evXB(u"ࠩࡐࡉࡓ࡛࡟ࡂࡕࡆࡉࡓࡊࡅࡅࡡࡗࡉࡒࡖࠧᄙ"))
	elif AArDKw6baWehCSOz7==Ie5s2cBtSfdHjzQ4rA9kYlo6D18(u"ࠪ࠵࠻࠭ᄚ"): E2E18vJ4hLaZpuWSfoMlY9yBzj6b(gBExoceumj4y8bFW9hY2aNMVSr,qoBMmfAWpFlK70xw8ZRh4naJ(u"ࠫࡒࡋࡎࡖࡡࡇࡉࡘࡉࡅࡏࡆࡈࡈࡤ࡚ࡅࡎࡒࠪᄛ"))
	elif AArDKw6baWehCSOz7==CC1eY6yWZUwf2TkRvnp7EJ0AimjHBX(u"ࠬ࠷࠷ࠨᄜ"): E2E18vJ4hLaZpuWSfoMlY9yBzj6b(gBExoceumj4y8bFW9hY2aNMVSr,UUDAiytEL76RTmMYsuIz5evXB(u"࠭ࡍࡆࡐࡘࡣࡗࡇࡎࡅࡑࡐࡍ࡟ࡋࡄࡠࡖࡈࡑࡕ࠭ᄝ"))
	elif AArDKw6baWehCSOz7==tQMjXKCA5dN4xq3beVIzaEoWkFLg(u"ࠧ࠲࠺ࠪᄞ"):
		v6yW5DfOsGhBkj4nzUSwEMXReHa = gdPslyFW8ITBcpA302.getSetting(dJHDqiKf12TXlIzSLkGUuxg4MBs3A(u"ࠨࡣࡹ࠲ࡸࡺࡡࡵࡷࡶ࠲ࡧ࡯ࡴࡳࡣࡷࡩࠬᄟ"))
		gdPslyFW8ITBcpA302.setSetting(viRJWOC5jsYe84(u"ࠩࡤࡺ࠳ࡹࡴࡢࡶࡸࡷ࠳ࡨࡩࡵࡴࡤࡸࡪ࠭ᄠ"),DaFZHsThGmd0zv6e(u"ࠪ࠱ࠬᄡ")+v6yW5DfOsGhBkj4nzUSwEMXReHa)
	if AArDKw6baWehCSOz7 in [BRWqdruz2A0(u"ࠫ࠾࠭ᄢ"),DaFZHsThGmd0zv6e(u"ࠬ࠷࠴ࠨᄣ"),iNc3KxwErnQ(u"࠭࠱࠶ࠩᄤ"),RlOvin8YIGC2KZXJPk9m0acrMobUex(u"ࠧ࠲࠸ࠪᄥ"),viRJWOC5jsYe84(u"ࠨ࠳࠺ࠫᄦ")]: xtm9pSeMInWo60(gBExoceumj4y8bFW9hY2aNMVSr)
	return
def pu5OZtyNK1LCqUR0n37wlxP9DTG(kc8s5wJ4Px9zbiWQm,mJjTE9o7ecN8dt,Cm4xfTO625jyMtZ8GEpvuKcnbQ1gD,HNdWR8p36CtO,BvbuigUeoJLnTaN2qWxQ415AtYMK9I,i02wfPp5EM,Z4vQNwLcAiPVufj9sOgCMU6ezEWG,AArDKw6baWehCSOz7,uu5WqOEaRZIibszwTc6t1nmLfAj,wc8X04F1e6u,TILw6pQSxlhMUCJK5qZbv4o,DRbhWYuzweV3IMNCyJv8oZj10Tk,yyV93CAujmWlEMsbf0Iv):
	if sOYTrW4HDRgG: giNkSFytDpdau1KH936r587LAUcql()
	if AArDKw6baWehCSOz7: HayCsqfegKTMA6NiG8PpFvJoBkl(kc8s5wJ4Px9zbiWQm,mJjTE9o7ecN8dt,Cm4xfTO625jyMtZ8GEpvuKcnbQ1gD,HNdWR8p36CtO,BvbuigUeoJLnTaN2qWxQ415AtYMK9I,i02wfPp5EM,Z4vQNwLcAiPVufj9sOgCMU6ezEWG,AArDKw6baWehCSOz7,uu5WqOEaRZIibszwTc6t1nmLfAj,wc8X04F1e6u,TILw6pQSxlhMUCJK5qZbv4o,DRbhWYuzweV3IMNCyJv8oZj10Tk)
	hh29YaqZDXR(wc8X04F1e6u)
	zlQAfuT2Z7nKhGdXs,XXVxgebOpD,v2O0NiyCjDZRW6hAMXuBb1TzoFt = gBExoceumj4y8bFW9hY2aNMVSr,ag8rjZo1Vz4IPdcOT,ag8rjZo1Vz4IPdcOT
	UB1AaCcuj362OJHgFmY0iW = EwtKyHV07cf4BuJ2(kc8s5wJ4Px9zbiWQm,mJjTE9o7ecN8dt,Cm4xfTO625jyMtZ8GEpvuKcnbQ1gD,HNdWR8p36CtO,BvbuigUeoJLnTaN2qWxQ415AtYMK9I,i02wfPp5EM,Z4vQNwLcAiPVufj9sOgCMU6ezEWG,AArDKw6baWehCSOz7,uu5WqOEaRZIibszwTc6t1nmLfAj,wc8X04F1e6u,yyV93CAujmWlEMsbf0Iv,zlQAfuT2Z7nKhGdXs,XXVxgebOpD,v2O0NiyCjDZRW6hAMXuBb1TzoFt)
	ii2toBg7GneHCVP0vdDpUMuNkJhX6r,OXhzNInrpK,lSnaiCROz1KAH0BYycrj6kX,GWALnz3yjFrg2av9BUE,GiO84LcKT6v,DCzj3fTnxYPREU,XDFszW8IixflLHThMYNC2,ZwXAt4V1iRDeQY60cyvadqNHS25 = UB1AaCcuj362OJHgFmY0iW
	if ii2toBg7GneHCVP0vdDpUMuNkJhX6r: return
	if OXhzNInrpK==l1DZAt9XNQjqE7YOdrz(u"ࠩࡕࡉࡋࡘࡅࡔࡊࡢࡇࡆࡉࡈࡆࠩᄧ"): UnGr9wJWdq(dzcNuIbsgK3yZ6SXGaEHPfOj5vk)
	s4PBNzhy8l(ddiCzu6yahj5RtTISMJ48sNnZBU(u"ࠪࡷࡹࡧࡲࡵࠩᄨ"))
	if gdPslyFW8ITBcpA302.getSetting(UVa3fJw7k6KM(u"ࠫࡦࡼ࠮ࡴࡶࡤࡸࡺࡹ࠮ࡤࡣࡦ࡬ࡪ࠭ᄩ")) not in [ddiCzu6yahj5RtTISMJ48sNnZBU(u"ࠬࡇࡕࡕࡑࠪᄪ"),ddiCzu6yahj5RtTISMJ48sNnZBU(u"࠭ࡓࡕࡑࡓࠫᄫ"),BRWqdruz2A0(u"ࠧࡍࡋࡐࡍ࡙ࡋࡄࠨᄬ")]: gdPslyFW8ITBcpA302.setSetting(aXqWLoTdVgME(u"ࠨࡣࡹ࠲ࡸࡺࡡࡵࡷࡶ࠲ࡨࡧࡣࡩࡧࠪᄭ"),YY8UDX3MJhb91AHw7fg(u"ࠩࡄ࡙࡙ࡕࠧᄮ"))
	if gdPslyFW8ITBcpA302.getSetting(DiJ8CMuYH1daWyjehfN0L(u"ࠪࡥࡻ࠴ࡳࡵࡣࡷࡹࡸ࠴ࡡࡶࡶࡲࡷࡨࡸࡡࡱࡧࡵࡷࠬᄯ")) not in [RlOvin8YIGC2KZXJPk9m0acrMobUex(u"ࠫࡆ࡛ࡔࡐࠩᄰ"),kYDaz79TFlXoR(u"࡙ࠬࡔࡐࡒࠪᄱ")]: gdPslyFW8ITBcpA302.setSetting(BRWqdruz2A0(u"࠭ࡡࡷ࠰ࡶࡸࡦࡺࡵࡴ࠰ࡤࡹࡹࡵࡳࡤࡴࡤࡴࡪࡸࡳࠨᄲ"),Ie5s2cBtSfdHjzQ4rA9kYlo6D18(u"ࠧࡂࡗࡗࡓࠬᄳ"))
	if not gdPslyFW8ITBcpA302.getSetting(RlOvin8YIGC2KZXJPk9m0acrMobUex(u"ࠨࡣࡹ࠲ࡸࡺࡡࡵࡷࡶ࠲ࡩࡴࡳࠨᄴ")): gdPslyFW8ITBcpA302.setSetting(BRWqdruz2A0(u"ࠩࡤࡺ࠳ࡹࡴࡢࡶࡸࡷ࠳ࡪ࡮ࡴࠩᄵ"),i4bFG3rKE6.DNS_SERVERS[vvXoMLlg513])
	MOTjA5H9XFs = PLd4s0tr67GpoK(kc8s5wJ4Px9zbiWQm,mJjTE9o7ecN8dt,Cm4xfTO625jyMtZ8GEpvuKcnbQ1gD,HNdWR8p36CtO,BvbuigUeoJLnTaN2qWxQ415AtYMK9I,i02wfPp5EM,Z4vQNwLcAiPVufj9sOgCMU6ezEWG,AArDKw6baWehCSOz7,uu5WqOEaRZIibszwTc6t1nmLfAj)
	if lljaEqwTVtmKsQcOrbXxS5hgNH(u"ࠪࡣࡋࡕࡒࡈࡇࡗࡖࡊ࡙ࡕࡍࡖࡖࡣࠬᄶ") in Z4vQNwLcAiPVufj9sOgCMU6ezEWG: XXVxgebOpD = gBExoceumj4y8bFW9hY2aNMVSr
	if kc8s5wJ4Px9zbiWQm==tR1krDGPpO025fghMT3a7UnYj(u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᄷ"):
		if GWALnz3yjFrg2av9BUE!=fWoVd0Bmtkx(u"ࠬ࠴࠮ࠨᄸ") and GiO84LcKT6v: KvcHEQ9Wh8CIAbomjtVGkdew4lYF()
		if uBifXGhpJlTyzZrWNjIDEg9HULa>-mZi0S72jGoHpLO:
			QKYLBnDyXGAp9iRj13 = [vvXoMLlg513,DiJ8CMuYH1daWyjehfN0L(u"࠳࠸ᛗ"),DiJ8CMuYH1daWyjehfN0L(u"࠴࠻ᛘ"),V3VlkhgjEF4n1erPXHcC0NOsfwyAJ(u"࠵࠾ᛙ"),UUDAiytEL76RTmMYsuIz5evXB(u"࠳࠸ᛖ"),l1DZAt9XNQjqE7YOdrz(u"࠳࠵ᛜ"),DiJ8CMuYH1daWyjehfN0L(u"࠺࠶ᛚ"),N3flV6EJsD5CzS(u"࠻࠳ᛛ"),dJHDqiKf12TXlIzSLkGUuxg4MBs3A(u"࠲࠳࠳ᛝ")]
			if (XXyMBNAVJvKiq7jc20bEw6(WoFsvbmUlDZp7PzRfdGknCV,RlOvin8YIGC2KZXJPk9m0acrMobUex(u"࠭ࡩ࡯ࡶࠪᄹ"),Ie5s2cBtSfdHjzQ4rA9kYlo6D18(u"ࠧࡎࡋࡖࡇࡤࡖࡅࡓࡏࠪᄺ"),UVa3fJw7k6KM(u"ࠨࡕࡌࡘࡊ࡙࡟ࡏࡃࡐࡉࡘ࠭ᄻ")) or wc8X04F1e6u not in QKYLBnDyXGAp9iRj13) and not i4bFG3rKE6.ogLe6xzIfJyT75HCQa:
				from f5akw4Lux3 import GGH7JavK8PfzgubqW0h1XTDnkwS
				IcREVK05Ujwaoi8,PPrqwgn7VQUYIubjO4x38BHF60zpW = f3WFzlwG0u8r5Mcvmg9ba2I(GGH7JavK8PfzgubqW0h1XTDnkwS)
				ii2toBg7GneHCVP0vdDpUMuNkJhX6r = K2YdrI0q5vAO7ZM(lSnaiCROz1KAH0BYycrj6kX,IcREVK05Ujwaoi8,zlQAfuT2Z7nKhGdXs,XXVxgebOpD,v2O0NiyCjDZRW6hAMXuBb1TzoFt)
				if IcREVK05Ujwaoi8 and DCzj3fTnxYPREU:
					if PPrqwgn7VQUYIubjO4x38BHF60zpW: zOYMaQ0NgdiRVwDJXh8e(WoFsvbmUlDZp7PzRfdGknCV,UVa3fJw7k6KM(u"ࠩࡐࡉࡓ࡛ࡓࡠࡅࡄࡇࡍࡋ࡟ࠨᄼ")+XDFszW8IixflLHThMYNC2+LZWMikPEB81KSGyxfJtUsCA(u"ࠪࡣࠬᄽ")+ZwXAt4V1iRDeQY60cyvadqNHS25,lSnaiCROz1KAH0BYycrj6kX,IcREVK05Ujwaoi8,kUz8c7OqsxuPFIGfwg)
					else: mlykPoGXbJIjFnarp9KihxfN(WoFsvbmUlDZp7PzRfdGknCV,Ie5s2cBtSfdHjzQ4rA9kYlo6D18(u"ࠫࡒࡋࡎࡖࡕࡢࡇࡆࡉࡈࡆࡡࠪᄾ")+XDFszW8IixflLHThMYNC2+CC1eY6yWZUwf2TkRvnp7EJ0AimjHBX(u"ࠬࡥࠧᄿ")+ZwXAt4V1iRDeQY60cyvadqNHS25,lSnaiCROz1KAH0BYycrj6kX)
			else:
				hfXHpDn9N2YrC4IMjbOBetadi.addDirectoryItem(uBifXGhpJlTyzZrWNjIDEg9HULa,LZWMikPEB81KSGyxfJtUsCA(u"࠭ࡰ࡭ࡷࡪ࡭ࡳࡀ࠯࠰ࠩᅀ")+xqJBEohLpFs+RlOvin8YIGC2KZXJPk9m0acrMobUex(u"ࠧ࠰ࡁࡷࡽࡵ࡫࠽࡭࡫ࡱ࡯ࠫࡳ࡯ࡥࡧࡀ࠹࠵࠶ࠧᅁ"),q5Kah0DftjNzV.ListItem(iNc3KxwErnQ(u"ࠨๆา๎่ࠦๅีๅ็อ๋ࠥๆࠡฮ๊หื้ࠧᅂ")))
				hfXHpDn9N2YrC4IMjbOBetadi.addDirectoryItem(uBifXGhpJlTyzZrWNjIDEg9HULa,fWoVd0Bmtkx(u"ࠩࡳࡰࡺ࡭ࡩ࡯࠼࠲࠳ࠬᅃ")+xqJBEohLpFs+qoBMmfAWpFlK70xw8ZRh4naJ(u"ࠪ࠳ࡄࡺࡹࡱࡧࡀࡰ࡮ࡴ࡫ࠧ࡯ࡲࡨࡪࡃ࠵࠱࠲ࠪᅄ"),q5Kah0DftjNzV.ListItem(sjtU6GZQg5XC2pH4(u"ࠫศ็สฮࠢ็ฮ็ืรࠡษ็ฮๆอี๋ๆࠪᅅ")))
			hfXHpDn9N2YrC4IMjbOBetadi.endOfDirectory(uBifXGhpJlTyzZrWNjIDEg9HULa,zlQAfuT2Z7nKhGdXs,XXVxgebOpD,v2O0NiyCjDZRW6hAMXuBb1TzoFt)
	return
def UnGr9wJWdq(oK1qDeIAS0lVzT):
	if fWoVd0Bmtkx(u"ࠬࡓࡅࡔࡕࡄࡋࡊ࡙ࠧᅆ") in str(i4bFG3rKE6.SEND_THESE_EVENTS): return
	OOhLgC75PcQaHj = ag8rjZo1Vz4IPdcOT if oK1qDeIAS0lVzT else gBExoceumj4y8bFW9hY2aNMVSr
	if not OOhLgC75PcQaHj:
		XVJMybPCe6s = NinEO2UTBHXh(gdPslyFW8ITBcpA302.getSetting(sjtU6GZQg5XC2pH4(u"࠭ࡡࡷ࠰࡯ࡥࡸࡺࡣࡩࡧࡦ࡯࠳ࡳࡥࡴࡵࡤ࡫ࡪࡹࠧᅇ")))
		XVJMybPCe6s = vvXoMLlg513 if not XVJMybPCe6s else int(XVJMybPCe6s)
		if not XVJMybPCe6s or not vvXoMLlg513<=dAeP20gNJ6ltq-XVJMybPCe6s<=oK1qDeIAS0lVzT: OOhLgC75PcQaHj = gBExoceumj4y8bFW9hY2aNMVSr
	if not OOhLgC75PcQaHj:
		oowgy2mMBi4HjcZSfFQzxsT = gdPslyFW8ITBcpA302.getSetting(IaBhDMJc17302LgSvyxd(u"ࠧࡢࡸ࠱ࡷࡹࡧࡴࡶࡵ࠱ࡱࡪࡹࡳࡢࡩࡨࡷࠬᅈ"))
		if oowgy2mMBi4HjcZSfFQzxsT in [qpFY4hAwolV3,YY8UDX3MJhb91AHw7fg(u"ࠨࡑࡏࡈࡤ࡚ࡏࡠࡇࡕࡖࡔࡘࠧᅉ"),YY8UDX3MJhb91AHw7fg(u"ࠩࡑࡉ࡜ࡥࡔࡐࡡࡈࡖࡗࡕࡒࠨᅊ")]: OOhLgC75PcQaHj = gBExoceumj4y8bFW9hY2aNMVSr
	if not OOhLgC75PcQaHj:
		RzkTF25WYKUxJEOcLHAuQI0h = gdPslyFW8ITBcpA302.getSetting(zYvEaigKWjoq50pXBLDbGJkFc(u"ࠪࡥࡻ࠴ࡰࡳ࡫ࡹࡷ࠶࠭ᅋ"))
		MkQL5RWVxPpz2mi63ADrt,EHQhicPzSdtkG = GGenXr4081Qb9muR(WoFsvbmUlDZp7PzRfdGknCV)
		NBrPCwSFev74butdpqRWiEj25G = oyAV8sgxXrMfnOqFN97eaCWlTIPz(WoFsvbmUlDZp7PzRfdGknCV,MkQL5RWVxPpz2mi63ADrt,EHQhicPzSdtkG,ag8rjZo1Vz4IPdcOT,Ie5s2cBtSfdHjzQ4rA9kYlo6D18(u"ࠫࡕࡘࡁࡈࡏࡄࠤࡦࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯ࡡ࡬ࡨࠥࡁࠧᅌ"))
		NBrPCwSFev74butdpqRWiEj25G = NBrPCwSFev74butdpqRWiEj25G[DaFZHsThGmd0zv6e(u"࠲ᛞ")][DaFZHsThGmd0zv6e(u"࠲ᛞ")]
		MkQL5RWVxPpz2mi63ADrt.close()
		Ljaf25ZGde9BIpVK4 = NAkjg5iJVr7wE4Ta3IfXP0Fo.md5(viRJWOC5jsYe84(u"࠸ᛟ")*RzkTF25WYKUxJEOcLHAuQI0h.encode(nV3Tip6XsH1rJw79DPOU)).hexdigest()
		Ljaf25ZGde9BIpVK4 = NAkjg5iJVr7wE4Ta3IfXP0Fo.md5(YY8UDX3MJhb91AHw7fg(u"࠵࠹ᛠ")*Ljaf25ZGde9BIpVK4.encode(nV3Tip6XsH1rJw79DPOU)).hexdigest()
		Ljaf25ZGde9BIpVK4 = NAkjg5iJVr7wE4Ta3IfXP0Fo.md5(qoBMmfAWpFlK70xw8ZRh4naJ(u"࠶࠿ᛡ")*Ljaf25ZGde9BIpVK4.encode(nV3Tip6XsH1rJw79DPOU)).hexdigest()
		Ljaf25ZGde9BIpVK4 = str(int(Ljaf25ZGde9BIpVK4[UUDAiytEL76RTmMYsuIz5evXB(u"࠳ᛣ"):UUDAiytEL76RTmMYsuIz5evXB(u"࠲࠴ᛤ")],zYvEaigKWjoq50pXBLDbGJkFc(u"࠳࠹ᛥ")))[:IaBhDMJc17302LgSvyxd(u"࠿ᛢ")]
		if Ljaf25ZGde9BIpVK4!=NBrPCwSFev74butdpqRWiEj25G: OOhLgC75PcQaHj = gBExoceumj4y8bFW9hY2aNMVSr
	if OOhLgC75PcQaHj: ZZzULyMTCqYlbS7B9sQtN3DwVFIGWd(ag8rjZo1Vz4IPdcOT)
	return
def O9YCFUXd1von5tKE3rmMWufciwDy(XSRoBuFEbKvZH6meTNCJx7LwQi,AGUTOIbFi4tDB1,n38oH7wd6BDyAMJQS,showDialogs):
	for DIgoXKadb5JRfWHqm in zX5fB2MikIobqGhF:
		if DIgoXKadb5JRfWHqm in AGUTOIbFi4tDB1: AGUTOIbFi4tDB1 = AGUTOIbFi4tDB1.replace(DIgoXKadb5JRfWHqm,qpFY4hAwolV3)
	j7HgbsXoUDfzcSkmniPu9w6 = n38oH7wd6BDyAMJQS.split(UVa3fJw7k6KM(u"ࠬ࠳ࠧᅍ"),mZi0S72jGoHpLO)[vvXoMLlg513] if mmV2nucZ5Lpl6FO1JMPEqGoQKW(u"࠭࠭ࠨᅎ") in n38oH7wd6BDyAMJQS else n38oH7wd6BDyAMJQS
	if not showDialogs or n38oH7wd6BDyAMJQS in RF2gx9SMq4EGThsHNaZV: return ag8rjZo1Vz4IPdcOT
	sk9dYre7h8LK = gdPslyFW8ITBcpA302.getSetting(rNdBKI74fAklnoCZ6(u"ࠧࡢࡸ࠱ࡰࡦࡴࡧࡶࡣࡪࡩ࠳ࡺࡲࡢࡰࡶࡰࡦࡺࡥࠨᅏ"))
	gdPslyFW8ITBcpA302.setSetting(l1DZAt9XNQjqE7YOdrz(u"ࠨࡣࡹ࠲ࡱࡧ࡮ࡨࡷࡤ࡫ࡪ࠴ࡴࡳࡣࡱࡷࡱࡧࡴࡦࠩᅐ"),qpFY4hAwolV3)
	YeKDmohnvXVS = XSRoBuFEbKvZH6meTNCJx7LwQi in [YY8UDX3MJhb91AHw7fg(u"࠽ᛩ"),iNc3KxwErnQ(u"࠵࠶࠶࠰࠲ᛧ"),zYvEaigKWjoq50pXBLDbGJkFc(u"࠴࠵࠵࠶࠲ᛦ"),UVa3fJw7k6KM(u"࠶࠶࠰࠶࠶ᛨ")]
	if YY8UDX3MJhb91AHw7fg(u"ࠩࡂࡹࡸ࡫ࡲ࠾ࠩᅑ") in AGUTOIbFi4tDB1: AGUTOIbFi4tDB1 = AGUTOIbFi4tDB1.split(mmV2nucZ5Lpl6FO1JMPEqGoQKW(u"ࠪࡃࡺࡹࡥࡳ࠿ࠪᅒ"),UUDAiytEL76RTmMYsuIz5evXB(u"࠱ᛪ"))[CC1eY6yWZUwf2TkRvnp7EJ0AimjHBX(u"࠱᛫")]+CC1eY6yWZUwf2TkRvnp7EJ0AimjHBX(u"ࠫ࠮࠭ᅓ")
	mJ2yerHlcApBK38h0f4ZSTNqwd5kX = AGUTOIbFi4tDB1.lower()
	A2AzcoI5TBX4Hp9kWLK7l = XSRoBuFEbKvZH6meTNCJx7LwQi in [vvXoMLlg513,CC1eY6yWZUwf2TkRvnp7EJ0AimjHBX(u"࠵࠵࠺ᛮ"),ddiCzu6yahj5RtTISMJ48sNnZBU(u"࠳࠳࠴࠻࠷᛬"),qoBMmfAWpFlK70xw8ZRh4naJ(u"࠴࠵࠶᛭")]
	f9E3oRJFB01OvdtbQcaxXS = Ie5s2cBtSfdHjzQ4rA9kYlo6D18(u"ࠬࡨ࡬ࡰࡥ࡮ࡩࡩࠦࡢࡺࠢࡦࡰࡴࡻࡤࡧ࡮ࡤࡶࡪ࠭ᅔ") in mJ2yerHlcApBK38h0f4ZSTNqwd5kX
	TaenZlmy7kPBvhKEzGXR1pg = tR1krDGPpO025fghMT3a7UnYj(u"࠭ࡢ࡭ࡱࡦ࡯ࡪࡪࠠࡣࡻࠣ࠹ࠥࡹࡥࡤࡱࡱࡨࡸࠦࡢࡳࡱࡺࡷࡪࡸࠠࡤࡪࡨࡧࡰ࠭ᅕ") in mJ2yerHlcApBK38h0f4ZSTNqwd5kX
	v5r4z6S2X1m90VfUxBZcTA = tQMjXKCA5dN4xq3beVIzaEoWkFLg(u"ࠧࡣ࡮ࡲࡧࡰ࡫ࡤࠡࡤࡼࠤࡷ࡫ࡣࡢࡲࡷࡧ࡭ࡧࠧᅖ") in mJ2yerHlcApBK38h0f4ZSTNqwd5kX
	CKTtBDZwOjdLXypSYez17PU = lljaEqwTVtmKsQcOrbXxS5hgNH(u"ࠨࡤ࡯ࡳࡨࡱࡥࡥࠢࡥࡽࠥࡩ࡬ࡰࡷࡧࡪࡱࡧࡲࡦࠢࡶࡩࡨࡻࡲࡪࡶࡼࠤࡨ࡮ࡥࡤ࡭ࠪᅗ") in mJ2yerHlcApBK38h0f4ZSTNqwd5kX
	RnUtcDh1EkuVeyIT5AMW4OmHv = fWoVd0Bmtkx(u"ࠩࡥࡰࡴࡩ࡫ࡦࡦࠣࡦࡾࠦ࡭ࡪࡵࡶ࡭ࡳ࡭ࠠ࡫ࡣࡹࡥࡸࡩࡲࡪࡲࡷࠤࡨ࡮ࡥࡤ࡭ࠪᅘ") in mJ2yerHlcApBK38h0f4ZSTNqwd5kX
	IPOKvupx0JkES9dyR = UUDAiytEL76RTmMYsuIz5evXB(u"ࠪࡦࡱࡵࡣ࡬ࡧࡧࠤࡧࡿࠠࡺࡱࡸࡶࠥࡴࡥࡵࡹࡲࡶࡰࠦࡤࡦࡸ࡬ࡧࡪࡹࠧᅙ") in mJ2yerHlcApBK38h0f4ZSTNqwd5kX
	tMJcb1hmia6k35QWBy7AfuYCZgKz = gdPslyFW8ITBcpA302.getSetting(ddiCzu6yahj5RtTISMJ48sNnZBU(u"ࠫࡦࡼ࠮ࡴࡶࡤࡸࡺࡹ࠮ࡶࡵࡨࡴࡷࡵࡸࡺࠩᅚ"))
	DL8Eyx0oIsuvmXGOMt = gdPslyFW8ITBcpA302.getSetting(aXqWLoTdVgME(u"ࠬࡧࡶ࠯ࡵࡷࡥࡹࡻࡳ࠯ࡷࡶࡩࡩࡴࡳࠨᅛ"))
	zi7WHgSTK8eGc0tFE36 = l1DZAt9XNQjqE7YOdrz(u"࠭แีๆࠣๅ๏ࠦำฮสࠣห้฻แฮห้๋ࠣࠦวๅว้ฮึ์สࠨᅜ")
	AWcyXkqsOuf = lljaEqwTVtmKsQcOrbXxS5hgNH(u"ࠧࡆࡴࡵࡳࡷࠦࠧᅝ")+str(XSRoBuFEbKvZH6meTNCJx7LwQi)+N3flV6EJsD5CzS(u"ࠨ࠼ࠣࠫᅞ")+AGUTOIbFi4tDB1
	AWcyXkqsOuf = cTt4u6reEMKZqVLplmkNW7(AWcyXkqsOuf)
	if any([A2AzcoI5TBX4Hp9kWLK7l,f9E3oRJFB01OvdtbQcaxXS,TaenZlmy7kPBvhKEzGXR1pg,v5r4z6S2X1m90VfUxBZcTA,CKTtBDZwOjdLXypSYez17PU,RnUtcDh1EkuVeyIT5AMW4OmHv,IPOKvupx0JkES9dyR]): zi7WHgSTK8eGc0tFE36 += sjtU6GZQg5XC2pH4(u"ࠩࠣ࠲ࠥอไๆ๊ๅ฽ࠥ็๊่ࠢะะอࠦึะࠢๆ์ิ๐ࠠๆืาี์ࠦวๅว้ฮึ์สࠡษ็าฬ฻ࠠษๅࠣวํࠦศศๆ่์็฿࡜࡯ࠩᅟ")
	if YeKDmohnvXVS: zi7WHgSTK8eGc0tFE36 += mmV2nucZ5Lpl6FO1JMPEqGoQKW(u"ࠪࠤ࠳ࠦไะ์ๆࠤำ฽รࠡࡆࡑࡗࠥ๎ๅฺ่ส๋ࠥะูัำࠣฮึาๅสࠢสื๊ࠦวๅ็๋ๆ฾ࠦลๅ๋ࠣี็๋็࡝ࡰࠪᅠ")
	AWcyXkqsOuf = ZLwoRpfnCWI7FgEHsz6te39lMVh+xupTj02bvy3O8R+AWcyXkqsOuf+fF4lt9zWYxXLKZVyAco82PgMj
	if tMJcb1hmia6k35QWBy7AfuYCZgKz==UVa3fJw7k6KM(u"ࠫࡆ࡙ࡋࠨᅡ") or DL8Eyx0oIsuvmXGOMt==dJHDqiKf12TXlIzSLkGUuxg4MBs3A(u"ࠬࡇࡓࡌࠩᅢ"):
		zi7WHgSTK8eGc0tFE36 += ZLwoRpfnCWI7FgEHsz6te39lMVh+IQ2KCmObsTGuiRdEzt931a40jLg+kYDaz79TFlXoR(u"࠭็ๅࠢอี๏ีࠠฤ่ࠣ๎าอ่ๅࠢส่อืๆศ็ฯࠤส฻ไศฯࠣห้๋ิไๆฬࠤ࠳࠴ࠠฤ็ࠣฮึ๐ฯࠡวิืฬ๊ࠠาีส่ฮࠦร้ࠢั฻ศࠦลๅ๋ࠣห้๋ศา็ฯࠤฤࠧࠡࠨᅣ")+fF4lt9zWYxXLKZVyAco82PgMj
	tsIMbXH76vWa3rO98zQqPconeD = ag8rjZo1Vz4IPdcOT
	if tMJcb1hmia6k35QWBy7AfuYCZgKz==kYDaz79TFlXoR(u"ࠧࡂࡕࡎࠫᅤ") or DL8Eyx0oIsuvmXGOMt==mmV2nucZ5Lpl6FO1JMPEqGoQKW(u"ࠨࡃࡖࡏࠬᅥ"):
		muaCBROQ72TixfPh683Y59qH = eVLmAIGFiwpr94UK6MRP5(RlOvin8YIGC2KZXJPk9m0acrMobUex(u"ࠩࡦࡩࡳࡺࡥࡳࠩᅦ"),UVa3fJw7k6KM(u"ࠪาึ๎ฬࠨᅧ"),c2RKu0xG1eC8MiohyE(u"ࠫสืำศๆ่้๋ࠣศา็ฯࠫᅨ"),aXqWLoTdVgME(u"ࠬะีๅ์ะࠤฬ๊ๅีๅ็อࠬᅩ"),j7HgbsXoUDfzcSkmniPu9w6+bJGaEk9wcz+nqTpa5zm20MfRNsVSIuG7A3biHZ6Fw(j7HgbsXoUDfzcSkmniPu9w6),zi7WHgSTK8eGc0tFE36+ZLwoRpfnCWI7FgEHsz6te39lMVh+AWcyXkqsOuf)
		if muaCBROQ72TixfPh683Y59qH==mZi0S72jGoHpLO:
			from t5tWekJ6XG import cSYpMx6W4HlAQK9
			cSYpMx6W4HlAQK9()
		elif muaCBROQ72TixfPh683Y59qH==Zwqio2AIWlD5etFa: tsIMbXH76vWa3rO98zQqPconeD = gBExoceumj4y8bFW9hY2aNMVSr
	else: iG7Rz2kmn0x1yLNMV3u8O(qpFY4hAwolV3,qpFY4hAwolV3,j7HgbsXoUDfzcSkmniPu9w6+bJGaEk9wcz+nqTpa5zm20MfRNsVSIuG7A3biHZ6Fw(j7HgbsXoUDfzcSkmniPu9w6),zi7WHgSTK8eGc0tFE36,AWcyXkqsOuf)
	gdPslyFW8ITBcpA302.setSetting(IaBhDMJc17302LgSvyxd(u"࠭ࡡࡷ࠰࡯ࡥࡳ࡭ࡵࡢࡩࡨ࠲ࡹࡸࡡ࡯ࡵ࡯ࡥࡹ࡫ࠧᅪ"),sk9dYre7h8LK)
	return tsIMbXH76vWa3rO98zQqPconeD
def KXWjTQvV1HGIB2RP3yedZk(ddyhARZPeagGHF9smb4c1rB0v8oKi=ag8rjZo1Vz4IPdcOT,VVoeYdHRJkX=[]):
	LLSXr8cvC62MhwDgWIFKBkpl = [RRCjYOQfEdAKub2s,V2JfszPWt6jq1hCxYKpyM53RL]+VVoeYdHRJkX
	for e90IM2s7vtVQTcGkZaUdNA6Y in RPbaxsNFVTwek5Kfv21DiJuzCnjMZp.listdir(F8qeAKZjGRMNXimho2gntaV0):
		if ddyhARZPeagGHF9smb4c1rB0v8oKi and (e90IM2s7vtVQTcGkZaUdNA6Y.startswith(tQMjXKCA5dN4xq3beVIzaEoWkFLg(u"ࠧࡪࡲࡷࡺࠬᅫ")) or e90IM2s7vtVQTcGkZaUdNA6Y.startswith(lljaEqwTVtmKsQcOrbXxS5hgNH(u"ࠨ࡯࠶ࡹࠬᅬ"))): continue
		if e90IM2s7vtVQTcGkZaUdNA6Y.startswith(N3flV6EJsD5CzS(u"ࠩࡩ࡭ࡱ࡫࡟ࠨᅭ")): continue
		xxXKAuM8BcGbD = RPbaxsNFVTwek5Kfv21DiJuzCnjMZp.path.join(F8qeAKZjGRMNXimho2gntaV0,e90IM2s7vtVQTcGkZaUdNA6Y)
		if xxXKAuM8BcGbD in LLSXr8cvC62MhwDgWIFKBkpl: continue
		try: RPbaxsNFVTwek5Kfv21DiJuzCnjMZp.remove(xxXKAuM8BcGbD)
		except: pass
	if MZRS4rVzdoqwH not in LLSXr8cvC62MhwDgWIFKBkpl: EOJmze1pUvdCgVPLRt3(MZRS4rVzdoqwH,gBExoceumj4y8bFW9hY2aNMVSr,ag8rjZo1Vz4IPdcOT)
	s7FnXZYOgexlH2MPb8BJck1AKv9.sleep(BRWqdruz2A0(u"࠶ᛯ"))
	return
def bgLPDpynQC4FoGsu(YtQNlWAxbyH9LuOKP0G8wkIvCcr,z5nOUetfoJHbP6294ghwur,Cm4xfTO625jyMtZ8GEpvuKcnbQ1gD,dimhv1XTVH8UOrc9EGJZ6,ppuvkQrgA1i8WwY3ftNJx7Ba9jH,pYyzPu7Cjal,showDialogs,n38oH7wd6BDyAMJQS,gcGZAoTEvO2qIaufr4RxNyWV8B=gBExoceumj4y8bFW9hY2aNMVSr,yCiSaQP8t2Db=gBExoceumj4y8bFW9hY2aNMVSr):
	Cm4xfTO625jyMtZ8GEpvuKcnbQ1gD = Cm4xfTO625jyMtZ8GEpvuKcnbQ1gD+tQMjXKCA5dN4xq3beVIzaEoWkFLg(u"ࠪࢀࢁࡓࡹࡑࡴࡲࡼࡾ࡛ࡲ࡭࠿ࠪᅮ")+YtQNlWAxbyH9LuOKP0G8wkIvCcr
	lgDZd7ip5Ux = WWrExJZS3Bj4anOAkpv7(KOyPvpEztYLaZRdMQJWxfTNFHbkg,z5nOUetfoJHbP6294ghwur,Cm4xfTO625jyMtZ8GEpvuKcnbQ1gD,dimhv1XTVH8UOrc9EGJZ6,ppuvkQrgA1i8WwY3ftNJx7Ba9jH,pYyzPu7Cjal,showDialogs,n38oH7wd6BDyAMJQS,gcGZAoTEvO2qIaufr4RxNyWV8B,yCiSaQP8t2Db)
	if Cm4xfTO625jyMtZ8GEpvuKcnbQ1gD in lgDZd7ip5Ux.content: lgDZd7ip5Ux.succeeded = ag8rjZo1Vz4IPdcOT
	if not lgDZd7ip5Ux.succeeded:
		xtm9pSeMInWo60()
	return lgDZd7ip5Ux
def ojf5mvgX1CpxPTODiez8(Cm4xfTO625jyMtZ8GEpvuKcnbQ1gD):
	lgDZd7ip5Ux = WWrExJZS3Bj4anOAkpv7(rGY36xBwT1bLZAngSfcWEIeXdQVNij,dJHDqiKf12TXlIzSLkGUuxg4MBs3A(u"ࠫࡌࡋࡔࠨᅯ"),Cm4xfTO625jyMtZ8GEpvuKcnbQ1gD,qpFY4hAwolV3,qpFY4hAwolV3,gBExoceumj4y8bFW9hY2aNMVSr,qpFY4hAwolV3,viRJWOC5jsYe84(u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡇࡆࡖࡢࡔࡗࡕࡘࡊࡇࡖࡣࡑࡏࡓࡕ࠯࠴ࡷࡹ࠭ᅰ"),gBExoceumj4y8bFW9hY2aNMVSr,ag8rjZo1Vz4IPdcOT)
	yyFXCkAHSmaMsGUQo1P4rxRjchZgn = []
	if lgDZd7ip5Ux.succeeded:
		eVEX29oO0qZjxltJKIfbc8aSd = lgDZd7ip5Ux.content
		xxoCrhVQvk = ePhmG1jLD6.findall(fWoVd0Bmtkx(u"࠭ࠠࠩ࠰࠭ࡃ࠮ࠦ࡜ࡥࡽ࠴࠰࠸ࢃ࡭ࡴࠩᅱ"),eVEX29oO0qZjxltJKIfbc8aSd)
		if xxoCrhVQvk: eVEX29oO0qZjxltJKIfbc8aSd = ZLwoRpfnCWI7FgEHsz6te39lMVh.join(xxoCrhVQvk)
		vqb8raUTXynlPwQGVIzkuHM = eVEX29oO0qZjxltJKIfbc8aSd.replace(SGUiazdreo6QRKLOWZj5hMX,qpFY4hAwolV3).strip(ZLwoRpfnCWI7FgEHsz6te39lMVh).split(ZLwoRpfnCWI7FgEHsz6te39lMVh)
		yyFXCkAHSmaMsGUQo1P4rxRjchZgn = []
		for YtQNlWAxbyH9LuOKP0G8wkIvCcr in vqb8raUTXynlPwQGVIzkuHM:
			if YtQNlWAxbyH9LuOKP0G8wkIvCcr.count(Ie5s2cBtSfdHjzQ4rA9kYlo6D18(u"ࠧ࠯ࠩᅲ"))==DAE6vkyhXGx1wBdHmcFfTVQpL0l: yyFXCkAHSmaMsGUQo1P4rxRjchZgn.append(YtQNlWAxbyH9LuOKP0G8wkIvCcr)
	return yyFXCkAHSmaMsGUQo1P4rxRjchZgn
def KKGJOx3ZIbupi2STt8sQoEanUjCRVP(*aargs):
	qSdrXKcE5JvA = CC1eY6yWZUwf2TkRvnp7EJ0AimjHBX(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡤࡴ࡮࠴ࡰࡳࡱࡻࡽࡸࡩࡲࡢࡲࡨ࠲ࡨࡵ࡭࠰ࡸ࠵࠳ࡄࡸࡥࡲࡷࡨࡷࡹࡃࡤࡪࡵࡳࡰࡦࡿࡰࡳࡱࡻ࡭ࡪࡹࠦࡱࡴࡲࡼࡾࡺࡹࡱࡧࡀ࡬ࡹࡺࡰࠧࡶ࡬ࡱࡪࡵࡵࡵ࠿࠴࠴࠵࠶࠰ࠧࡵࡶࡰࡂࡿࡥࡴࠨ࡯࡭ࡲ࡯ࡴ࠾࠳࠳ࠪࡨࡵࡵ࡯ࡶࡵࡽࡂࡔࡌ࠭ࡄࡈ࠰ࡉࡋࠬࡇࡔ࠯ࡋࡇ࠲ࡔࡓࠩᅳ")
	eRFnM7DdZLks3CSOUHWi9f = IaBhDMJc17302LgSvyxd(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡶࡦࡽ࠮ࡨ࡫ࡷ࡬ࡺࡨࡵࡴࡧࡵࡧࡴࡴࡴࡦࡰࡷ࠲ࡨࡵ࡭࠰ࡴࡲࡳࡸࡺࡥࡳ࡭࡬ࡨ࠴ࡵࡰࡦࡰࡳࡶࡴࡾࡹ࡭࡫ࡶࡸ࠴ࡳࡡࡪࡰ࠲ࡌ࡙࡚ࡐࡔ࠰ࡷࡼࡹ࠭ᅴ")
	g1QJyfbkIxoUa3 = ojf5mvgX1CpxPTODiez8(eRFnM7DdZLks3CSOUHWi9f)
	yyFXCkAHSmaMsGUQo1P4rxRjchZgn = ojf5mvgX1CpxPTODiez8(qSdrXKcE5JvA)
	NYXmZpdVFLw = g1QJyfbkIxoUa3+yyFXCkAHSmaMsGUQo1P4rxRjchZgn
	LLvyStW429DEZKlA(d3MGHW41fvNz6rRFYix2anS,lTW9p1v7uPfOxB(Q8Q0IDc6PLZajJAdTntKUmSGXz)+DiJ8CMuYH1daWyjehfN0L(u"ࠪࠤࠥࠦࡇࡰࡶࠣࡴࡷࡵࡸࡪࡧࡶࠤࡱ࡯ࡳࡵࠢࠣࠤ࠶ࡹࡴࠬ࠴ࡱࡨ࠿࡛ࠦࠡࠩᅵ")+str(len(g1QJyfbkIxoUa3))+aXqWLoTdVgME(u"ࠫ࠰࠭ᅶ")+str(len(yyFXCkAHSmaMsGUQo1P4rxRjchZgn))+kYDaz79TFlXoR(u"ࠬࠦ࡝ࠨᅷ"))
	YtQNlWAxbyH9LuOKP0G8wkIvCcr = gdPslyFW8ITBcpA302.getSetting(ee86G9ladLHVbh5mikzCo(u"࠭ࡡࡷ࠰ࡳࡶࡴࡾࡹ࠯࡮ࡤࡷࡹ࠭ᅸ"))
	lgDZd7ip5Ux = qvfZXAI81kwTueoFgnOhWazdBR()
	gdPslyFW8ITBcpA302.setSetting(sjtU6GZQg5XC2pH4(u"ࠧࡢࡸ࠱ࡴࡷࡵࡸࡺ࠰࡯ࡥࡸࡺࠧᅹ"),qpFY4hAwolV3)
	if YtQNlWAxbyH9LuOKP0G8wkIvCcr or NYXmZpdVFLw:
		Zu96PkNGaiqRH3d,cBDoavTz1uIgXpmGQyMOCf3b = vvXoMLlg513,Ie5s2cBtSfdHjzQ4rA9kYlo6D18(u"࠷࠰ᛰ")
		ElofZRm2BDrM = len(NYXmZpdVFLw)
		DB32WKeljta = cBDoavTz1uIgXpmGQyMOCf3b
		if ElofZRm2BDrM>DB32WKeljta: KhJkZrImLesvaBElyAu4t8ioV3 = DB32WKeljta
		else: KhJkZrImLesvaBElyAu4t8ioV3 = ElofZRm2BDrM
		qRNuaxgCfp0J5XM = P9Kfwdgna8erGcAWyQMOtFbq6Rk.sample(NYXmZpdVFLw,KhJkZrImLesvaBElyAu4t8ioV3)
		if YtQNlWAxbyH9LuOKP0G8wkIvCcr: qRNuaxgCfp0J5XM = [YtQNlWAxbyH9LuOKP0G8wkIvCcr]+qRNuaxgCfp0J5XM
		mB1CNRnEQ3whDuLGvK6S = A9JZujzBXNEck2sKYt75rwQRIL4CT(ag8rjZo1Vz4IPdcOT,ag8rjZo1Vz4IPdcOT)
		Z0JRfngy6coNe8FsCIu2O9tip = s7FnXZYOgexlH2MPb8BJck1AKv9.time()
		while s7FnXZYOgexlH2MPb8BJck1AKv9.time()-Z0JRfngy6coNe8FsCIu2O9tip<=cBDoavTz1uIgXpmGQyMOCf3b and not mB1CNRnEQ3whDuLGvK6S.finishedLIST:
			if Zu96PkNGaiqRH3d<KhJkZrImLesvaBElyAu4t8ioV3:
				YtQNlWAxbyH9LuOKP0G8wkIvCcr = qRNuaxgCfp0J5XM[Zu96PkNGaiqRH3d]
				mB1CNRnEQ3whDuLGvK6S.Tz7dfFGyYuHgE(Zu96PkNGaiqRH3d,bgLPDpynQC4FoGsu,YtQNlWAxbyH9LuOKP0G8wkIvCcr,*aargs)
			s7FnXZYOgexlH2MPb8BJck1AKv9.sleep(IaBhDMJc17302LgSvyxd(u"࠰࠯࠹࠸ᛱ"))
			Zu96PkNGaiqRH3d += mZi0S72jGoHpLO
			LLvyStW429DEZKlA(k8kdUSxohLVljnrY,lTW9p1v7uPfOxB(Q8Q0IDc6PLZajJAdTntKUmSGXz)+tR1krDGPpO025fghMT3a7UnYj(u"ࠨࠢࠣࠤ࡙ࡸࡹࡪࡰࡪ࠾ࠥࠦࠠࡑࡴࡲࡼࡾࡀࠠ࡜ࠢࠪᅺ")+YtQNlWAxbyH9LuOKP0G8wkIvCcr+l32dnTEOU1skGKqeBtI9hmo(u"ࠩࠣࡡࠬᅻ"))
		finishedLIST = mB1CNRnEQ3whDuLGvK6S.finishedLIST
		if finishedLIST:
			resultsDICT = mB1CNRnEQ3whDuLGvK6S.resultsDICT
			HNWnCOLmP5BEVTkAy7oDcaqiIXtsZe = finishedLIST[vvXoMLlg513]
			lgDZd7ip5Ux = resultsDICT[HNWnCOLmP5BEVTkAy7oDcaqiIXtsZe]
			YtQNlWAxbyH9LuOKP0G8wkIvCcr = qRNuaxgCfp0J5XM[int(HNWnCOLmP5BEVTkAy7oDcaqiIXtsZe)]
			gdPslyFW8ITBcpA302.setSetting(iNc3KxwErnQ(u"ࠪࡥࡻ࠴ࡰࡳࡱࡻࡽ࠳ࡲࡡࡴࡶࠪᅼ"),YtQNlWAxbyH9LuOKP0G8wkIvCcr)
			if HNWnCOLmP5BEVTkAy7oDcaqiIXtsZe!=vvXoMLlg513: LLvyStW429DEZKlA(d3MGHW41fvNz6rRFYix2anS,lTW9p1v7uPfOxB(Q8Q0IDc6PLZajJAdTntKUmSGXz)+l32dnTEOU1skGKqeBtI9hmo(u"ࠫࠥࠦࠠࡔࡷࡦࡧࡪࡹࡳ࠻ࠢࠣࠤࡕࡸ࡯ࡹࡻ࠽ࠤࡠࠦࠧᅽ")+YtQNlWAxbyH9LuOKP0G8wkIvCcr+c2RKu0xG1eC8MiohyE(u"ࠬࠦ࡝ࠨᅾ"))
			else: LLvyStW429DEZKlA(d3MGHW41fvNz6rRFYix2anS,lTW9p1v7uPfOxB(Q8Q0IDc6PLZajJAdTntKUmSGXz)+l32dnTEOU1skGKqeBtI9hmo(u"࠭ࠠࠡࠢࡖࡹࡨࡩࡥࡴࡵ࠽ࠤࠥࠦࡓࡢࡸࡨࡨࠥࡶࡲࡰࡺࡼ࠾ࠥࡡࠠࠨᅿ")+YtQNlWAxbyH9LuOKP0G8wkIvCcr+UVa3fJw7k6KM(u"ࠧࠡ࡟ࠪᆀ"))
	return lgDZd7ip5Ux
def Hz0CltOwMNv3rA7LfSy56oiuB28R(oo8HOrqn1BS2YaMtue3iTlJv9CVAyI,LBiAQVGuw4fhHDyZTbrYX,kSjtfwsD98Z=gBExoceumj4y8bFW9hY2aNMVSr):
	ZBrzkx5EH8F2eghItonls6MLDv = oo8HOrqn1BS2YaMtue3iTlJv9CVAyI.create_connection
	def yvkS2R5gfxmIK6erFQqb7VP0XGjYlU(kDjzTpV80bEu21F,*aargs,**kkwargs):
		EnkT2XQRiLO,J9v0MeEWnNTDG4lZgsBdI816u = kDjzTpV80bEu21F
		sV5xU7W39QREjpOvGZMT1uKCdF = pbLZ4tTDeY8rVdRwGFQPh2A7c0us(EnkT2XQRiLO,LBiAQVGuw4fhHDyZTbrYX)
		if sV5xU7W39QREjpOvGZMT1uKCdF: EnkT2XQRiLO = sV5xU7W39QREjpOvGZMT1uKCdF[vvXoMLlg513]
		elif kSjtfwsD98Z:
			if LBiAQVGuw4fhHDyZTbrYX in i4bFG3rKE6.DNS_SERVERS: i4bFG3rKE6.DNS_SERVERS.remove(LBiAQVGuw4fhHDyZTbrYX)
			if i4bFG3rKE6.DNS_SERVERS:
				o6htA4ej1TX3knqv9csU2pJGIDQyK8 = i4bFG3rKE6.DNS_SERVERS[vvXoMLlg513]
				sV5xU7W39QREjpOvGZMT1uKCdF = pbLZ4tTDeY8rVdRwGFQPh2A7c0us(EnkT2XQRiLO,o6htA4ej1TX3knqv9csU2pJGIDQyK8)
				if sV5xU7W39QREjpOvGZMT1uKCdF: EnkT2XQRiLO = sV5xU7W39QREjpOvGZMT1uKCdF[vvXoMLlg513]
		if sV5xU7W39QREjpOvGZMT1uKCdF: i4bFG3rKE6.dns_succeeded_urls.append(EnkT2XQRiLO)
		kDjzTpV80bEu21F = (EnkT2XQRiLO,J9v0MeEWnNTDG4lZgsBdI816u)
		return ZBrzkx5EH8F2eghItonls6MLDv(kDjzTpV80bEu21F,*aargs,**kkwargs)
	oo8HOrqn1BS2YaMtue3iTlJv9CVAyI.create_connection = yvkS2R5gfxmIK6erFQqb7VP0XGjYlU
	return ZBrzkx5EH8F2eghItonls6MLDv
def Ra7xXGg0Nnet(Cm4xfTO625jyMtZ8GEpvuKcnbQ1gD):
	gc8IMf1Bel3yqJpm4,MiKNCVAUpnRG = Cm4xfTO625jyMtZ8GEpvuKcnbQ1gD.split(ShynO8pN9idCE3)[Zwqio2AIWlD5etFa],ee86G9ladLHVbh5mikzCo(u"࠹࠲ᛲ")
	if UUDAiytEL76RTmMYsuIz5evXB(u"ࠨ࠼ࠪᆁ") in gc8IMf1Bel3yqJpm4: gc8IMf1Bel3yqJpm4,MiKNCVAUpnRG = gc8IMf1Bel3yqJpm4.split(V3VlkhgjEF4n1erPXHcC0NOsfwyAJ(u"ࠩ࠽ࠫᆂ"))
	h2SnoX9E04bBsNJMyr1gTjVmOpx = ShynO8pN9idCE3+ShynO8pN9idCE3.join(Cm4xfTO625jyMtZ8GEpvuKcnbQ1gD.split(ShynO8pN9idCE3)[BRWqdruz2A0(u"࠵ᛳ"):])
	AMbRf4XTpQNvio6J5GELducy0k = l32dnTEOU1skGKqeBtI9hmo(u"ࠪࡋࡊ࡚ࠠࠨᆃ")+h2SnoX9E04bBsNJMyr1gTjVmOpx+tQMjXKCA5dN4xq3beVIzaEoWkFLg(u"ࠫࠥࡎࡔࡕࡒ࠲࠵࠳࠷࡜ࡳ࡞ࡱࠫᆄ")
	AMbRf4XTpQNvio6J5GELducy0k += ee86G9ladLHVbh5mikzCo(u"ࠬࡎ࡯ࡴࡶ࠽ࠤࠬᆅ")+gc8IMf1Bel3yqJpm4+UVa3fJw7k6KM(u"࠭࡜ࡳ࡞ࡱࠫᆆ")
	AMbRf4XTpQNvio6J5GELducy0k += BRWqdruz2A0(u"ࠧ࡝ࡴ࡟ࡲࠬᆇ")
	from socket import socket as t8jd2DlPfrO9eRCFgG3M1XKHLkST,AF_INET as QICFUT4M827xecVqjXNudy,SOCK_STREAM as ntKANFzB4GqyD
	try:
		FZOHdgvxWV0RBbtL1yP = t8jd2DlPfrO9eRCFgG3M1XKHLkST(QICFUT4M827xecVqjXNudy,ntKANFzB4GqyD)
		FZOHdgvxWV0RBbtL1yP.connect((gc8IMf1Bel3yqJpm4,MiKNCVAUpnRG))
		FZOHdgvxWV0RBbtL1yP.send(AMbRf4XTpQNvio6J5GELducy0k.encode(nV3Tip6XsH1rJw79DPOU))
		vvepFM182VwG9JXBakyPmQ = FZOHdgvxWV0RBbtL1yP.recv(c2RKu0xG1eC8MiohyE(u"࠸࠵࠿࠶ᛵ")*qoBMmfAWpFlK70xw8ZRh4naJ(u"࠴࠴࠷࠺ᛴ"))
		eVEX29oO0qZjxltJKIfbc8aSd = repr(vvepFM182VwG9JXBakyPmQ)
	except: eVEX29oO0qZjxltJKIfbc8aSd = qpFY4hAwolV3
	return eVEX29oO0qZjxltJKIfbc8aSd
def AACymb8gWpiZPTSjE5RxheqzHN(bME1B3yCmlFdvj0p6XLeW):
	mNusid0MD6ByI1RxaZ27JrkSfG = repr(bME1B3yCmlFdvj0p6XLeW.encode(nV3Tip6XsH1rJw79DPOU)).replace(iNc3KxwErnQ(u"ࠣࠩࠥᆈ"),qpFY4hAwolV3)
	return mNusid0MD6ByI1RxaZ27JrkSfG
def qZ5W2HkliSK9CN(nclCOPw5QRY6zG08gk4bXqtU2y):
	PUJ2pw6v39Iex4KNVblhfQ = qpFY4hAwolV3
	if NJwViHDTMdmO0xnALqQ9voPalC3Ip: nclCOPw5QRY6zG08gk4bXqtU2y = nclCOPw5QRY6zG08gk4bXqtU2y.decode(nV3Tip6XsH1rJw79DPOU)
	from unicodedata import decomposition as nR1B7VeXyNTcuopQ
	for n1nBQCVGrPbzaHwSL0DXqg in nclCOPw5QRY6zG08gk4bXqtU2y:
		if   n1nBQCVGrPbzaHwSL0DXqg==zYvEaigKWjoq50pXBLDbGJkFc(u"ࡷࠪฦࠬᆉ"): GGnafHv5pPlIy0BNgihFjbCDmVwocQ = l32dnTEOU1skGKqeBtI9hmo(u"ࠪࡠࡡࡻ࠰࠷࠴࠵ࠫᆊ")
		elif n1nBQCVGrPbzaHwSL0DXqg==iNc3KxwErnQ(u"ࡹࠬษࠧᆋ"): GGnafHv5pPlIy0BNgihFjbCDmVwocQ = ddiCzu6yahj5RtTISMJ48sNnZBU(u"ࠬࡢ࡜ࡶ࠲࠹࠶࠸࠭ᆌ")
		elif n1nBQCVGrPbzaHwSL0DXqg==DaFZHsThGmd0zv6e(u"ࡻࠧลࠩᆍ"): GGnafHv5pPlIy0BNgihFjbCDmVwocQ = IaBhDMJc17302LgSvyxd(u"ࠧ࡝࡞ࡸ࠴࠻࠸࠴ࠨᆎ")
		elif n1nBQCVGrPbzaHwSL0DXqg==qqzwE6imYG4c2xojI(u"ࡶࠩศࠫᆏ"): GGnafHv5pPlIy0BNgihFjbCDmVwocQ = kYDaz79TFlXoR(u"ࠩ࡟ࡠࡺ࠶࠶࠳࠷ࠪᆐ")
		elif n1nBQCVGrPbzaHwSL0DXqg==RlOvin8YIGC2KZXJPk9m0acrMobUex(u"ࡸࠫห࠭ᆑ"): GGnafHv5pPlIy0BNgihFjbCDmVwocQ = BRWqdruz2A0(u"ࠫࡡࡢࡵ࠱࠸࠵࠺ࠬᆒ")
		else:
			BaIUMnEw4u5RqxSbmo60LgNW2QXd7z = nR1B7VeXyNTcuopQ(n1nBQCVGrPbzaHwSL0DXqg)
			if mIsDke0oK5x1zSiOWbF9thGcA in BaIUMnEw4u5RqxSbmo60LgNW2QXd7z: GGnafHv5pPlIy0BNgihFjbCDmVwocQ = viRJWOC5jsYe84(u"ࠬࡢ࡜ࡶࠩᆓ")+BaIUMnEw4u5RqxSbmo60LgNW2QXd7z.split(mIsDke0oK5x1zSiOWbF9thGcA,mZi0S72jGoHpLO)[mZi0S72jGoHpLO]
			else:
				GGnafHv5pPlIy0BNgihFjbCDmVwocQ = qqzwE6imYG4c2xojI(u"࠭࠰࠱࠲࠳ࠫᆔ")+hex(ord(n1nBQCVGrPbzaHwSL0DXqg)).replace(UVa3fJw7k6KM(u"ࠧ࠱ࡺࠪᆕ"),qpFY4hAwolV3)
				GGnafHv5pPlIy0BNgihFjbCDmVwocQ = aXqWLoTdVgME(u"ࠨ࡞࡟ࡹࠬᆖ")+GGnafHv5pPlIy0BNgihFjbCDmVwocQ[-wn4bG51vUENfaS0Zg:]
		PUJ2pw6v39Iex4KNVblhfQ += GGnafHv5pPlIy0BNgihFjbCDmVwocQ
	PUJ2pw6v39Iex4KNVblhfQ = PUJ2pw6v39Iex4KNVblhfQ.replace(l32dnTEOU1skGKqeBtI9hmo(u"ࠩ࡟ࡠࡺ࠶࠶ࡄࡅࠪᆗ"),tQMjXKCA5dN4xq3beVIzaEoWkFLg(u"ࠪࡠࡡࡻ࠰࠷࠶࠼ࠫᆘ"))
	if NJwViHDTMdmO0xnALqQ9voPalC3Ip: PUJ2pw6v39Iex4KNVblhfQ = PUJ2pw6v39Iex4KNVblhfQ.decode(Ie5s2cBtSfdHjzQ4rA9kYlo6D18(u"ࠫࡺࡴࡩࡤࡱࡧࡩࡤ࡫ࡳࡤࡣࡳࡩࠬᆙ")).encode(nV3Tip6XsH1rJw79DPOU)
	else: PUJ2pw6v39Iex4KNVblhfQ = PUJ2pw6v39Iex4KNVblhfQ.encode(nV3Tip6XsH1rJw79DPOU).decode(BRWqdruz2A0(u"ࠬࡻ࡮ࡪࡥࡲࡨࡪࡥࡥࡴࡥࡤࡴࡪ࠭ᆚ"))
	return PUJ2pw6v39Iex4KNVblhfQ
def jXgARlWMLVFUBnvmZwI2o5(header=IaBhDMJc17302LgSvyxd(u"࠭ไ้ฯฬࠤฬ๊ๅโษอ๎า࠭ᆛ"),DYd8SIqKtoNLVye5Q=qpFY4hAwolV3,UdvRN2PMQctuDeIKxmwi=ag8rjZo1Vz4IPdcOT,source=qpFY4hAwolV3):
	Z4vQNwLcAiPVufj9sOgCMU6ezEWG = LhVtyjDJAxpkHXgRmS35nKuT(header,DYd8SIqKtoNLVye5Q,type=q5Kah0DftjNzV.INPUT_ALPHANUM)
	Z4vQNwLcAiPVufj9sOgCMU6ezEWG = Z4vQNwLcAiPVufj9sOgCMU6ezEWG.strip(mIsDke0oK5x1zSiOWbF9thGcA).replace(M04Bcjvt8SFaeQEK,mIsDke0oK5x1zSiOWbF9thGcA).replace(bJGaEk9wcz,mIsDke0oK5x1zSiOWbF9thGcA).replace(r1roOXYi7UQw9FLThzPEdD0ZlvAnRc,mIsDke0oK5x1zSiOWbF9thGcA)
	if not Z4vQNwLcAiPVufj9sOgCMU6ezEWG and not UdvRN2PMQctuDeIKxmwi:
		LLvyStW429DEZKlA(k8kdUSxohLVljnrY,CC1eY6yWZUwf2TkRvnp7EJ0AimjHBX(u"ࠧ࠯࡞ࡷࡏࡪࡿࡢࡰࡣࡵࡨࠥ࡫࡮ࡵࡴࡼࠤࡨࡧ࡮ࡤࡧ࡯ࡩࡩࡀࠠࠡࠢࠥࠫᆜ")+Z4vQNwLcAiPVufj9sOgCMU6ezEWG+YY8UDX3MJhb91AHw7fg(u"ࠨࠤࠪᆝ"))
		iG7Rz2kmn0x1yLNMV3u8O(qpFY4hAwolV3,qpFY4hAwolV3,GLTtERWbHnFuy4PCp,ddiCzu6yahj5RtTISMJ48sNnZBU(u"ࠩอ้ࠥหไ฻ษฤࠤฬ๊ละะส่ࠬᆞ"))
		return qpFY4hAwolV3
	if Z4vQNwLcAiPVufj9sOgCMU6ezEWG not in [qpFY4hAwolV3,mIsDke0oK5x1zSiOWbF9thGcA]:
		Z4vQNwLcAiPVufj9sOgCMU6ezEWG = Z4vQNwLcAiPVufj9sOgCMU6ezEWG.strip(mIsDke0oK5x1zSiOWbF9thGcA)
		Z4vQNwLcAiPVufj9sOgCMU6ezEWG = qZ5W2HkliSK9CN(Z4vQNwLcAiPVufj9sOgCMU6ezEWG)
	if source!=qqzwE6imYG4c2xojI(u"ࠪࡗࡊࡘࡖࡊࡅࡈࡗࠬᆟ") and u0E18eO3HnCzr(RlOvin8YIGC2KZXJPk9m0acrMobUex(u"ࠫࡐࡋ࡙ࡃࡑࡄࡖࡉ࠭ᆠ"),qpFY4hAwolV3,[Z4vQNwLcAiPVufj9sOgCMU6ezEWG],ag8rjZo1Vz4IPdcOT):
		LLvyStW429DEZKlA(k8kdUSxohLVljnrY,viRJWOC5jsYe84(u"ࠬ࠴࡜ࡵࡍࡨࡽࡧࡵࡡࡳࡦࠣࡩࡳࡺࡲࡺࠢࡥࡰࡴࡩ࡫ࡦࡦ࠽ࠤࠥࠦࠢࠨᆡ")+Z4vQNwLcAiPVufj9sOgCMU6ezEWG+mmV2nucZ5Lpl6FO1JMPEqGoQKW(u"࠭ࠢࠨᆢ"))
		iG7Rz2kmn0x1yLNMV3u8O(qpFY4hAwolV3,qpFY4hAwolV3,GLTtERWbHnFuy4PCp,c2RKu0xG1eC8MiohyE(u"ࠧศ่อࠤ่ะศหࠢๆ่๊ฯࠠฤ๊ࠣี็๋ࠠๅ้ࠣ฽้อโสࠢหวๆ๊วๆࠢ็่่ฮวาࠢไๆ฼ࠦ࠮࠯๋๋ࠢีอࠠศๆหี๋อๅอࠢ็หࠥ๐ำๆฯࠣฬฬูสฯัส้ࠥํใัษࠣ็้๋วหࠩᆣ"))
		return qpFY4hAwolV3
	LLvyStW429DEZKlA(k8kdUSxohLVljnrY,DiJ8CMuYH1daWyjehfN0L(u"ࠨ࠰࡟ࡸࡐ࡫ࡹࡣࡱࡤࡶࡩࠦࡥ࡯ࡶࡵࡽࠥࡧ࡬࡭ࡱࡺࡩࡩࡀࠠࠡࠢࠥࠫᆤ")+Z4vQNwLcAiPVufj9sOgCMU6ezEWG+kYDaz79TFlXoR(u"ࠩࠥࠫᆥ"))
	return Z4vQNwLcAiPVufj9sOgCMU6ezEWG
def kkrVFUT4SCmKvAXRfe5gQuYoal(Q8Q0IDc6PLZajJAdTntKUmSGXz,WSQlG8mDhqsNe,skD7g3FxW4wCa5BR={}):
	Cm4xfTO625jyMtZ8GEpvuKcnbQ1gD,oG31XA5x7bFLdqs0aQYTmjfD,BBRZVm4dOeTsJkbL83wMWhFDor2yj,ASdcHmgBEteKzR3PWMqsDjL2YJ9akF = WSQlG8mDhqsNe,{},{},qpFY4hAwolV3
	if YY8UDX3MJhb91AHw7fg(u"ࠪࢀࠬᆦ") in WSQlG8mDhqsNe: Cm4xfTO625jyMtZ8GEpvuKcnbQ1gD,oG31XA5x7bFLdqs0aQYTmjfD = D02sQSgOGhTJxtKyFEId74Nrv8bYU(WSQlG8mDhqsNe,sjtU6GZQg5XC2pH4(u"ࠫࢁ࠭ᆧ"))
	eEXzA4lrGVaHYC9JQUIN3PWTtng = list(set(list(skD7g3FxW4wCa5BR.keys())+list(oG31XA5x7bFLdqs0aQYTmjfD.keys())))
	for ifG5zdxloK8j4RBOq in eEXzA4lrGVaHYC9JQUIN3PWTtng:
		if ifG5zdxloK8j4RBOq in list(oG31XA5x7bFLdqs0aQYTmjfD.keys()): BBRZVm4dOeTsJkbL83wMWhFDor2yj[ifG5zdxloK8j4RBOq] = oG31XA5x7bFLdqs0aQYTmjfD[ifG5zdxloK8j4RBOq]
		else: BBRZVm4dOeTsJkbL83wMWhFDor2yj[ifG5zdxloK8j4RBOq] = skD7g3FxW4wCa5BR[ifG5zdxloK8j4RBOq]
	if ee86G9ladLHVbh5mikzCo(u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩᆨ") not in eEXzA4lrGVaHYC9JQUIN3PWTtng: BBRZVm4dOeTsJkbL83wMWhFDor2yj[kYDaz79TFlXoR(u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪᆩ")] = IyjRtqkmHFBvTCDYwuQNJ0()
	if V3VlkhgjEF4n1erPXHcC0NOsfwyAJ(u"ࠧࡓࡧࡩࡩࡷ࡫ࡲࠨᆪ") not in eEXzA4lrGVaHYC9JQUIN3PWTtng: BBRZVm4dOeTsJkbL83wMWhFDor2yj[mmV2nucZ5Lpl6FO1JMPEqGoQKW(u"ࠨࡔࡨࡪࡪࡸࡥࡳࠩᆫ")] = AWeJuo2LhZ5xiD8KNSqd9G0rtT74FE(Cm4xfTO625jyMtZ8GEpvuKcnbQ1gD,dJHDqiKf12TXlIzSLkGUuxg4MBs3A(u"ࠩࡸࡶࡱ࠭ᆬ"))
	if ddiCzu6yahj5RtTISMJ48sNnZBU(u"ࠪࡅࡨࡩࡥࡱࡶ࠰ࡐࡦࡴࡧࡶࡣࡪࡩࠬᆭ") not in eEXzA4lrGVaHYC9JQUIN3PWTtng: BBRZVm4dOeTsJkbL83wMWhFDor2yj[zYvEaigKWjoq50pXBLDbGJkFc(u"ࠫࡆࡩࡣࡦࡲࡷ࠱ࡑࡧ࡮ࡨࡷࡤ࡫ࡪ࠭ᆮ")] = l32dnTEOU1skGKqeBtI9hmo(u"ࠬ࡫࡮࠭ࡣࡵ࠿ࡶࡃ࠰࠯࠻ࠪᆯ")
	for ifG5zdxloK8j4RBOq in list(BBRZVm4dOeTsJkbL83wMWhFDor2yj.keys()): ASdcHmgBEteKzR3PWMqsDjL2YJ9akF += LZWMikPEB81KSGyxfJtUsCA(u"࠭ࠦࠨᆰ")+ifG5zdxloK8j4RBOq+DiJ8CMuYH1daWyjehfN0L(u"ࠧ࠾ࠩᆱ")+BBRZVm4dOeTsJkbL83wMWhFDor2yj[ifG5zdxloK8j4RBOq]
	if ASdcHmgBEteKzR3PWMqsDjL2YJ9akF: ASdcHmgBEteKzR3PWMqsDjL2YJ9akF = dJHDqiKf12TXlIzSLkGUuxg4MBs3A(u"ࠨࡾࠪᆲ")+ASdcHmgBEteKzR3PWMqsDjL2YJ9akF[mZi0S72jGoHpLO:]
	lgDZd7ip5Ux = WWrExJZS3Bj4anOAkpv7(K6imQHZDCI9pewE,IaBhDMJc17302LgSvyxd(u"ࠩࡊࡉ࡙࠭ᆳ"),Cm4xfTO625jyMtZ8GEpvuKcnbQ1gD,qpFY4hAwolV3,BBRZVm4dOeTsJkbL83wMWhFDor2yj,qpFY4hAwolV3,qpFY4hAwolV3,aXqWLoTdVgME(u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡊ࡞ࡔࡓࡃࡆࡘࡤࡓ࠳ࡖ࠺࠰࠵ࡸࡺࠧᆴ"),ag8rjZo1Vz4IPdcOT,ag8rjZo1Vz4IPdcOT)
	eVEX29oO0qZjxltJKIfbc8aSd = lgDZd7ip5Ux.content
	if mmV2nucZ5Lpl6FO1JMPEqGoQKW(u"ࠫࡘ࡚ࡒࡆࡃࡐ࠱ࡎࡔࡆࠨᆵ") not in eVEX29oO0qZjxltJKIfbc8aSd: return [V3VlkhgjEF4n1erPXHcC0NOsfwyAJ(u"ࠬ࠳࠱ࠨᆶ")],[Cm4xfTO625jyMtZ8GEpvuKcnbQ1gD+ASdcHmgBEteKzR3PWMqsDjL2YJ9akF]
	if iNc3KxwErnQ(u"࠭ࡔ࡚ࡒࡈࡁࡆ࡛ࡄࡊࡑࠪᆷ") in eVEX29oO0qZjxltJKIfbc8aSd: return [dJHDqiKf12TXlIzSLkGUuxg4MBs3A(u"ࠧ࠮࠳ࠪᆸ")],[Cm4xfTO625jyMtZ8GEpvuKcnbQ1gD+ASdcHmgBEteKzR3PWMqsDjL2YJ9akF]
	if RlOvin8YIGC2KZXJPk9m0acrMobUex(u"ࠨࡖ࡜ࡔࡊࡃࡖࡊࡆࡈࡓࠬᆹ") in eVEX29oO0qZjxltJKIfbc8aSd: return [LZWMikPEB81KSGyxfJtUsCA(u"ࠩ࠰࠵ࠬᆺ")],[Cm4xfTO625jyMtZ8GEpvuKcnbQ1gD+ASdcHmgBEteKzR3PWMqsDjL2YJ9akF]
	QQLqrElamjfneR8GoP9IpuZ,U7V0BQZPxXqMbyJnRw6f,QGXpZks6PWFRKJmMhtaUEnjx,GlhEdinvXYatIfkHgy7 = [],[],[],[]
	Mm8BldxpifLUa5s2 = ePhmG1jLD6.findall(rNdBKI74fAklnoCZ6(u"ࠪࠧࡊ࡞ࡔ࠮࡚࠰ࡗ࡙ࡘࡅࡂࡏ࠰ࡍࡓࡌ࠺ࠩ࠰࠭ࡃ࠮ࡡ࡜ࡳ࡞ࡱࡡ࠰࠮࠮ࠫࡁࠬ࡟ࡡࡸ࡜࡯࡟࠮ࠫᆻ"),eVEX29oO0qZjxltJKIfbc8aSd+ZLwoRpfnCWI7FgEHsz6te39lMVh,ePhmG1jLD6.DOTALL)
	if not Mm8BldxpifLUa5s2: return [N3flV6EJsD5CzS(u"ࠫ࠲࠷ࠧᆼ")],[Cm4xfTO625jyMtZ8GEpvuKcnbQ1gD+ASdcHmgBEteKzR3PWMqsDjL2YJ9akF]
	for w2OCG9BuSMs,kl7ToEBRZAs8C6O24Fzad in Mm8BldxpifLUa5s2:
		tOU9gXBwncYEvJjb3oPz8u4rS,v6yW5DfOsGhBkj4nzUSwEMXReHa,Mrp5ZdGHFv9Xi6mkxfac3JDB = {},-ee86G9ladLHVbh5mikzCo(u"࠶ᛶ"),-ee86G9ladLHVbh5mikzCo(u"࠶ᛶ")
		iETYhQsKnLXkNVDIUdobaxO6 = qpFY4hAwolV3
		ccaFGRENLACdnpZevMB25P6 = w2OCG9BuSMs.split(kYDaz79TFlXoR(u"ࠬ࠲ࠧᆽ"))
		for oPd4bh1MqQxN in ccaFGRENLACdnpZevMB25P6:
			if mmV2nucZ5Lpl6FO1JMPEqGoQKW(u"࠭࠽ࠨᆾ") in oPd4bh1MqQxN:
				ifG5zdxloK8j4RBOq,gCzS3XIbaR4dsrWYF9n2TVwAfOk = oPd4bh1MqQxN.split(UUDAiytEL76RTmMYsuIz5evXB(u"ࠧ࠾ࠩᆿ"),mmV2nucZ5Lpl6FO1JMPEqGoQKW(u"࠷ᛷ"))
				tOU9gXBwncYEvJjb3oPz8u4rS[ifG5zdxloK8j4RBOq.lower()] = gCzS3XIbaR4dsrWYF9n2TVwAfOk
		if YY8UDX3MJhb91AHw7fg(u"ࠨࡣࡹࡩࡷࡧࡧࡦ࠯ࡥࡥࡳࡪࡷࡪࡦࡷ࡬ࠬᇀ") in w2OCG9BuSMs.lower():
			v6yW5DfOsGhBkj4nzUSwEMXReHa = int(tOU9gXBwncYEvJjb3oPz8u4rS[IaBhDMJc17302LgSvyxd(u"ࠩࡤࡺࡪࡸࡡࡨࡧ࠰ࡦࡦࡴࡤࡸ࡫ࡧࡸ࡭࠭ᇁ")])//LZWMikPEB81KSGyxfJtUsCA(u"࠱࠱࠴࠷ᛸ")
			iETYhQsKnLXkNVDIUdobaxO6 += str(v6yW5DfOsGhBkj4nzUSwEMXReHa)+rNdBKI74fAklnoCZ6(u"ࠪ࡯ࡧࡶࡳࠡࠢࠪᇂ")
		elif RlOvin8YIGC2KZXJPk9m0acrMobUex(u"ࠫࡧࡧ࡮ࡥࡹ࡬ࡨࡹ࡮ࠧᇃ") in w2OCG9BuSMs.lower():
			v6yW5DfOsGhBkj4nzUSwEMXReHa = int(tOU9gXBwncYEvJjb3oPz8u4rS[kYDaz79TFlXoR(u"ࠬࡨࡡ࡯ࡦࡺ࡭ࡩࡺࡨࠨᇄ")])//qoBMmfAWpFlK70xw8ZRh4naJ(u"࠲࠲࠵࠸᛹")
			iETYhQsKnLXkNVDIUdobaxO6 += str(v6yW5DfOsGhBkj4nzUSwEMXReHa)+UVa3fJw7k6KM(u"࠭࡫ࡣࡲࡶࠤࠥ࠭ᇅ")
		if tQMjXKCA5dN4xq3beVIzaEoWkFLg(u"ࠧࡳࡧࡶࡳࡱࡻࡴࡪࡱࡱࠫᇆ") in w2OCG9BuSMs.lower():
			Mrp5ZdGHFv9Xi6mkxfac3JDB = int(tOU9gXBwncYEvJjb3oPz8u4rS[mmV2nucZ5Lpl6FO1JMPEqGoQKW(u"ࠨࡴࡨࡷࡴࡲࡵࡵ࡫ࡲࡲࠬᇇ")].split(IaBhDMJc17302LgSvyxd(u"ࠩࡻࠫᇈ"))[mZi0S72jGoHpLO])
			iETYhQsKnLXkNVDIUdobaxO6 += str(Mrp5ZdGHFv9Xi6mkxfac3JDB)+r1roOXYi7UQw9FLThzPEdD0ZlvAnRc
		iETYhQsKnLXkNVDIUdobaxO6 = iETYhQsKnLXkNVDIUdobaxO6.strip(r1roOXYi7UQw9FLThzPEdD0ZlvAnRc)
		if not iETYhQsKnLXkNVDIUdobaxO6: iETYhQsKnLXkNVDIUdobaxO6 = mmV2nucZ5Lpl6FO1JMPEqGoQKW(u"࡙ࠪࡳࡱ࡮ࡰࡹࡱࠫᇉ")
		if not kl7ToEBRZAs8C6O24Fzad.startswith(dJHDqiKf12TXlIzSLkGUuxg4MBs3A(u"ࠫ࡭ࡺࡴࡱࠩᇊ")):
			if kl7ToEBRZAs8C6O24Fzad.startswith(ttrDbyV5cSO2FjgTzew6qM): kl7ToEBRZAs8C6O24Fzad = Cm4xfTO625jyMtZ8GEpvuKcnbQ1gD.split(RlOvin8YIGC2KZXJPk9m0acrMobUex(u"ࠬࡀࠧᇋ"),mZi0S72jGoHpLO)[vvXoMLlg513]+ddiCzu6yahj5RtTISMJ48sNnZBU(u"࠭࠺ࠨᇌ")+kl7ToEBRZAs8C6O24Fzad
			elif kl7ToEBRZAs8C6O24Fzad.startswith(ShynO8pN9idCE3): kl7ToEBRZAs8C6O24Fzad = AWeJuo2LhZ5xiD8KNSqd9G0rtT74FE(Cm4xfTO625jyMtZ8GEpvuKcnbQ1gD,DaFZHsThGmd0zv6e(u"ࠧࡶࡴ࡯ࠫᇍ"))+kl7ToEBRZAs8C6O24Fzad
			else: kl7ToEBRZAs8C6O24Fzad = Cm4xfTO625jyMtZ8GEpvuKcnbQ1gD.rsplit(ShynO8pN9idCE3,mZi0S72jGoHpLO)[vvXoMLlg513]+ShynO8pN9idCE3+kl7ToEBRZAs8C6O24Fzad
		if c2RKu0xG1eC8MiohyE(u"ࠨࡲࡵࡳ࡬ࡸࡥࡴࡵ࡬ࡺࡪ࠳ࡵࡳ࡫ࠪᇎ") in list(tOU9gXBwncYEvJjb3oPz8u4rS.keys()):
			OexQX2mTwfGkuU6AIBLz9vWlHjdF8 = tOU9gXBwncYEvJjb3oPz8u4rS[lljaEqwTVtmKsQcOrbXxS5hgNH(u"ࠩࡳࡶࡴ࡭ࡲࡦࡵࡶ࡭ࡻ࡫࠭ࡶࡴ࡬ࠫᇏ")]
			OexQX2mTwfGkuU6AIBLz9vWlHjdF8 = OexQX2mTwfGkuU6AIBLz9vWlHjdF8.replace(fWoVd0Bmtkx(u"ࠪࠦࠬᇐ"),qpFY4hAwolV3).replace(sjtU6GZQg5XC2pH4(u"ࠦࠬࠨᇑ"),qpFY4hAwolV3).split(lljaEqwTVtmKsQcOrbXxS5hgNH(u"ࠬࠩࠧᇒ"),mZi0S72jGoHpLO)[vvXoMLlg513]
			gyEQS6JIZKa = RRwxKI27Mk(OexQX2mTwfGkuU6AIBLz9vWlHjdF8)
			if gyEQS6JIZKa: UdbGw48M6rCHDRmea5qP91nKI = iETYhQsKnLXkNVDIUdobaxO6+r1roOXYi7UQw9FLThzPEdD0ZlvAnRc+gyEQS6JIZKa
			else: UdbGw48M6rCHDRmea5qP91nKI = iETYhQsKnLXkNVDIUdobaxO6
			UdbGw48M6rCHDRmea5qP91nKI = UdbGw48M6rCHDRmea5qP91nKI+kYDaz79TFlXoR(u"࠭ࠠࠡࡒࡵࡳ࡬ࡸࡥࡴࡵ࡬ࡺࡪ࠭ᇓ")
			UdbGw48M6rCHDRmea5qP91nKI = UdbGw48M6rCHDRmea5qP91nKI+r1roOXYi7UQw9FLThzPEdD0ZlvAnRc+AWeJuo2LhZ5xiD8KNSqd9G0rtT74FE(OexQX2mTwfGkuU6AIBLz9vWlHjdF8,dJHDqiKf12TXlIzSLkGUuxg4MBs3A(u"ࠧ࡯ࡣࡰࡩࠬᇔ"))
			QQLqrElamjfneR8GoP9IpuZ.append(UdbGw48M6rCHDRmea5qP91nKI)
			U7V0BQZPxXqMbyJnRw6f.append(OexQX2mTwfGkuU6AIBLz9vWlHjdF8)
			QGXpZks6PWFRKJmMhtaUEnjx.append(Mrp5ZdGHFv9Xi6mkxfac3JDB)
			GlhEdinvXYatIfkHgy7.append(v6yW5DfOsGhBkj4nzUSwEMXReHa)
		kl7ToEBRZAs8C6O24Fzad = kl7ToEBRZAs8C6O24Fzad.split(lljaEqwTVtmKsQcOrbXxS5hgNH(u"ࠨࠥࠪᇕ"),mZi0S72jGoHpLO)[vvXoMLlg513]
		gyEQS6JIZKa = RRwxKI27Mk(kl7ToEBRZAs8C6O24Fzad)
		if gyEQS6JIZKa: iETYhQsKnLXkNVDIUdobaxO6 = iETYhQsKnLXkNVDIUdobaxO6+r1roOXYi7UQw9FLThzPEdD0ZlvAnRc+gyEQS6JIZKa
		iETYhQsKnLXkNVDIUdobaxO6 = iETYhQsKnLXkNVDIUdobaxO6+r1roOXYi7UQw9FLThzPEdD0ZlvAnRc+AWeJuo2LhZ5xiD8KNSqd9G0rtT74FE(kl7ToEBRZAs8C6O24Fzad,V3VlkhgjEF4n1erPXHcC0NOsfwyAJ(u"ࠩࡱࡥࡲ࡫ࠧᇖ"))
		QQLqrElamjfneR8GoP9IpuZ.append(iETYhQsKnLXkNVDIUdobaxO6)
		U7V0BQZPxXqMbyJnRw6f.append(kl7ToEBRZAs8C6O24Fzad)
		QGXpZks6PWFRKJmMhtaUEnjx.append(Mrp5ZdGHFv9Xi6mkxfac3JDB)
		GlhEdinvXYatIfkHgy7.append(v6yW5DfOsGhBkj4nzUSwEMXReHa)
	G1EWNzkMOm35C = list(zip(QQLqrElamjfneR8GoP9IpuZ,U7V0BQZPxXqMbyJnRw6f,QGXpZks6PWFRKJmMhtaUEnjx,GlhEdinvXYatIfkHgy7))
	G1EWNzkMOm35C = sorted(G1EWNzkMOm35C, reverse=gBExoceumj4y8bFW9hY2aNMVSr, key=lambda key: key[DAE6vkyhXGx1wBdHmcFfTVQpL0l])
	QQLqrElamjfneR8GoP9IpuZ,U7V0BQZPxXqMbyJnRw6f,QGXpZks6PWFRKJmMhtaUEnjx,GlhEdinvXYatIfkHgy7 = list(zip(*G1EWNzkMOm35C))
	QQLqrElamjfneR8GoP9IpuZ,U7V0BQZPxXqMbyJnRw6f = list(QQLqrElamjfneR8GoP9IpuZ),list(U7V0BQZPxXqMbyJnRw6f)
	fxYHq8pUSoAPt4RndK7uj6mC = []
	for kl7ToEBRZAs8C6O24Fzad in U7V0BQZPxXqMbyJnRw6f: fxYHq8pUSoAPt4RndK7uj6mC.append(kl7ToEBRZAs8C6O24Fzad+ASdcHmgBEteKzR3PWMqsDjL2YJ9akF)
	j7GQRtObC4IqH803umlkxMsKPvZhY = list(zip(fxYHq8pUSoAPt4RndK7uj6mC,[l32dnTEOU1skGKqeBtI9hmo(u"ࠪࡨࡺࡳ࡭ࡺࠩᇗ")]*len(fxYHq8pUSoAPt4RndK7uj6mC),GlhEdinvXYatIfkHgy7))
	TGK1Mmbg4D8e = U89T5Btp7JjNmDxGzK4M(Q8Q0IDc6PLZajJAdTntKUmSGXz,j7GQRtObC4IqH803umlkxMsKPvZhY)
	if TGK1Mmbg4D8e:
		MepIvHBYNArkUOdV37shtJ,oF67yxKdB8nY3TiH9gAMvlOhaPSws0,v6yW5DfOsGhBkj4nzUSwEMXReHa = TGK1Mmbg4D8e[LZWMikPEB81KSGyxfJtUsCA(u"࠲᛺")]
		index = fxYHq8pUSoAPt4RndK7uj6mC.index(MepIvHBYNArkUOdV37shtJ)
		title = QQLqrElamjfneR8GoP9IpuZ[index]
		QQLqrElamjfneR8GoP9IpuZ,fxYHq8pUSoAPt4RndK7uj6mC = [title],[MepIvHBYNArkUOdV37shtJ]
	return QQLqrElamjfneR8GoP9IpuZ,fxYHq8pUSoAPt4RndK7uj6mC
def pbLZ4tTDeY8rVdRwGFQPh2A7c0us(EnkT2XQRiLO,LBiAQVGuw4fhHDyZTbrYX=qpFY4hAwolV3):
	if not LBiAQVGuw4fhHDyZTbrYX: LBiAQVGuw4fhHDyZTbrYX = i4bFG3rKE6.DNS_SERVERS[vvXoMLlg513]
	if EnkT2XQRiLO.replace(BRWqdruz2A0(u"ࠫ࠳࠭ᇘ"),qpFY4hAwolV3).isdigit(): return [EnkT2XQRiLO]
	from struct import pack as HCT8n915uAKJcfD7kGBE,unpack_from as VfLB9WiI6u5N8kRM
	from socket import socket as t8jd2DlPfrO9eRCFgG3M1XKHLkST,AF_INET as QICFUT4M827xecVqjXNudy,SOCK_DGRAM as s8sycWZv9IKftOAT6
	try:
		kGXCYuzcgBWOUr = HCT8n915uAKJcfD7kGBE(UVa3fJw7k6KM(u"ࠧࡄࡈࠣᇙ"), RlOvin8YIGC2KZXJPk9m0acrMobUex(u"࠴࠶࠵࠺࠹᛻"))
		kGXCYuzcgBWOUr += HCT8n915uAKJcfD7kGBE(BRWqdruz2A0(u"ࠨ࠾ࡉࠤᇚ"), rNdBKI74fAklnoCZ6(u"࠶࠺࠼᛼"))
		kGXCYuzcgBWOUr += HCT8n915uAKJcfD7kGBE(lljaEqwTVtmKsQcOrbXxS5hgNH(u"ࠢ࠿ࡊࠥᇛ"), mZi0S72jGoHpLO)
		kGXCYuzcgBWOUr += HCT8n915uAKJcfD7kGBE(V3VlkhgjEF4n1erPXHcC0NOsfwyAJ(u"ࠣࡀࡋࠦᇜ"), vvXoMLlg513)
		kGXCYuzcgBWOUr += HCT8n915uAKJcfD7kGBE(c2RKu0xG1eC8MiohyE(u"ࠤࡁࡌࠧᇝ"), vvXoMLlg513)
		kGXCYuzcgBWOUr += HCT8n915uAKJcfD7kGBE(fWoVd0Bmtkx(u"ࠥࡂࡍࠨᇞ"), vvXoMLlg513)
		if DLod2Of8CkRrtzJynev: x5WpOeM9NVQiHTr37cvfmhsA = EnkT2XQRiLO.split(l32dnTEOU1skGKqeBtI9hmo(u"ࠫ࠳࠭ᇟ"))
		else: x5WpOeM9NVQiHTr37cvfmhsA = EnkT2XQRiLO.decode(nV3Tip6XsH1rJw79DPOU).split(BRWqdruz2A0(u"ࠬ࠴ࠧᇠ"))
		for D8jZSO4q95ecR in x5WpOeM9NVQiHTr37cvfmhsA:
			oenphG2AxK3HrFTUi4QcOV1MIRWBJE = D8jZSO4q95ecR.encode(nV3Tip6XsH1rJw79DPOU)
			kGXCYuzcgBWOUr += HCT8n915uAKJcfD7kGBE(fWoVd0Bmtkx(u"ࠨࡂࠣᇡ"), len(D8jZSO4q95ecR))
			for TIpZXm7anSyh640zVdc3N1MQxEYg in D8jZSO4q95ecR:
				kGXCYuzcgBWOUr += HCT8n915uAKJcfD7kGBE(l32dnTEOU1skGKqeBtI9hmo(u"ࠢࡤࠤᇢ"), TIpZXm7anSyh640zVdc3N1MQxEYg.encode(nV3Tip6XsH1rJw79DPOU))
		kGXCYuzcgBWOUr += HCT8n915uAKJcfD7kGBE(l1DZAt9XNQjqE7YOdrz(u"ࠣࡄࠥᇣ"), vvXoMLlg513)
		kGXCYuzcgBWOUr += HCT8n915uAKJcfD7kGBE(l1DZAt9XNQjqE7YOdrz(u"ࠤࡁࡌࠧᇤ"), mZi0S72jGoHpLO)
		kGXCYuzcgBWOUr += HCT8n915uAKJcfD7kGBE(lljaEqwTVtmKsQcOrbXxS5hgNH(u"ࠥࡂࡍࠨᇥ"), mZi0S72jGoHpLO)
		FK5yAWRBXJmvNqE79gZT0SYa8 = t8jd2DlPfrO9eRCFgG3M1XKHLkST(QICFUT4M827xecVqjXNudy,s8sycWZv9IKftOAT6)
		FK5yAWRBXJmvNqE79gZT0SYa8.sendto(bytes(kGXCYuzcgBWOUr),(LBiAQVGuw4fhHDyZTbrYX,UVa3fJw7k6KM(u"࠺࠹᛽")))
		FK5yAWRBXJmvNqE79gZT0SYa8.settimeout(fWoVd0Bmtkx(u"࠼᛾"))
		dimhv1XTVH8UOrc9EGJZ6, EEC5GOhJ2NitgS1oKHjFDp = FK5yAWRBXJmvNqE79gZT0SYa8.recvfrom(sjtU6GZQg5XC2pH4(u"࠱࠱࠴࠷᛿"))
		FK5yAWRBXJmvNqE79gZT0SYa8.close()
		huHmqNskO6 = VfLB9WiI6u5N8kRM(tQMjXKCA5dN4xq3beVIzaEoWkFLg(u"ࠦࡃࡎࡈࡉࡊࡋࡌࠧᇦ"), dimhv1XTVH8UOrc9EGJZ6, vvXoMLlg513)
		yZxfNPebp3imB7EMl = huHmqNskO6[DAE6vkyhXGx1wBdHmcFfTVQpL0l]
		JtQaynOX4krsuNwSibhTCz1cl = len(EnkT2XQRiLO)+fWoVd0Bmtkx(u"࠲࠺ᜀ")
		OkL6wBRsf4 = []
		for _nWGKaTN2ejfCvtJR in range(yZxfNPebp3imB7EMl):
			ttK4f0GWYI = JtQaynOX4krsuNwSibhTCz1cl
			YRgZnXWclpxhsfdFkKIyaVqtu = mZi0S72jGoHpLO
			OFnT3Xj7Vhx1cLU8WKk2bRqJMu = ag8rjZo1Vz4IPdcOT
			while gBExoceumj4y8bFW9hY2aNMVSr:
				TIpZXm7anSyh640zVdc3N1MQxEYg = VfLB9WiI6u5N8kRM(CC1eY6yWZUwf2TkRvnp7EJ0AimjHBX(u"ࠧࡄࡂࠣᇧ"), dimhv1XTVH8UOrc9EGJZ6, ttK4f0GWYI)[vvXoMLlg513]
				if TIpZXm7anSyh640zVdc3N1MQxEYg == vvXoMLlg513:
					ttK4f0GWYI += mZi0S72jGoHpLO
					break
				if TIpZXm7anSyh640zVdc3N1MQxEYg >= V3VlkhgjEF4n1erPXHcC0NOsfwyAJ(u"࠳࠼࠶ᜁ"):
					Xi4U5lqbRSPeGArB1Y3tDjdgpvLC = VfLB9WiI6u5N8kRM(DaFZHsThGmd0zv6e(u"ࠨ࠾ࡃࠤᇨ"), dimhv1XTVH8UOrc9EGJZ6, ttK4f0GWYI + mZi0S72jGoHpLO)[vvXoMLlg513]
					ttK4f0GWYI = ((TIpZXm7anSyh640zVdc3N1MQxEYg << V3VlkhgjEF4n1erPXHcC0NOsfwyAJ(u"࠻ᜂ")) + Xi4U5lqbRSPeGArB1Y3tDjdgpvLC - 0xc000) - mZi0S72jGoHpLO
					OFnT3Xj7Vhx1cLU8WKk2bRqJMu = gBExoceumj4y8bFW9hY2aNMVSr
				ttK4f0GWYI += mZi0S72jGoHpLO
				if OFnT3Xj7Vhx1cLU8WKk2bRqJMu == ag8rjZo1Vz4IPdcOT: YRgZnXWclpxhsfdFkKIyaVqtu += mZi0S72jGoHpLO
			if OFnT3Xj7Vhx1cLU8WKk2bRqJMu == gBExoceumj4y8bFW9hY2aNMVSr: YRgZnXWclpxhsfdFkKIyaVqtu += mZi0S72jGoHpLO
			JtQaynOX4krsuNwSibhTCz1cl = JtQaynOX4krsuNwSibhTCz1cl + YRgZnXWclpxhsfdFkKIyaVqtu
			h14jAw5r9XtDQsE = VfLB9WiI6u5N8kRM(fWoVd0Bmtkx(u"ࠢ࠿ࡊࡋࡍࡍࠨᇩ"), dimhv1XTVH8UOrc9EGJZ6, JtQaynOX4krsuNwSibhTCz1cl)
			JtQaynOX4krsuNwSibhTCz1cl = JtQaynOX4krsuNwSibhTCz1cl + lljaEqwTVtmKsQcOrbXxS5hgNH(u"࠵࠵ᜃ")
			fWJgutdUyaBKXh86O = h14jAw5r9XtDQsE[vvXoMLlg513]
			lzYOrsqbKh3 = h14jAw5r9XtDQsE[DAE6vkyhXGx1wBdHmcFfTVQpL0l]
			if fWJgutdUyaBKXh86O == mZi0S72jGoHpLO:
				U9P4AkBlKe0a2jbsEMJZ1LrvFVhDuS = VfLB9WiI6u5N8kRM(RlOvin8YIGC2KZXJPk9m0acrMobUex(u"ࠣࡀࠥᇪ")+zYvEaigKWjoq50pXBLDbGJkFc(u"ࠤࡅࠦᇫ")*lzYOrsqbKh3, dimhv1XTVH8UOrc9EGJZ6, JtQaynOX4krsuNwSibhTCz1cl)
				sV5xU7W39QREjpOvGZMT1uKCdF = qpFY4hAwolV3
				for TIpZXm7anSyh640zVdc3N1MQxEYg in U9P4AkBlKe0a2jbsEMJZ1LrvFVhDuS: sV5xU7W39QREjpOvGZMT1uKCdF += str(TIpZXm7anSyh640zVdc3N1MQxEYg) + l1DZAt9XNQjqE7YOdrz(u"ࠪ࠲ࠬᇬ")
				sV5xU7W39QREjpOvGZMT1uKCdF = sV5xU7W39QREjpOvGZMT1uKCdF[vvXoMLlg513:-mZi0S72jGoHpLO]
				OkL6wBRsf4.append(sV5xU7W39QREjpOvGZMT1uKCdF)
			if fWJgutdUyaBKXh86O in [mZi0S72jGoHpLO,Zwqio2AIWlD5etFa,CC1eY6yWZUwf2TkRvnp7EJ0AimjHBX(u"࠵ᜆ"),l32dnTEOU1skGKqeBtI9hmo(u"࠷ᜇ"),sjtU6GZQg5XC2pH4(u"࠷࠵ᜅ"),UVa3fJw7k6KM(u"࠷࠾ᜄ")]: JtQaynOX4krsuNwSibhTCz1cl = JtQaynOX4krsuNwSibhTCz1cl + lzYOrsqbKh3
	except: OkL6wBRsf4 = []
	if not OkL6wBRsf4: LLvyStW429DEZKlA(j8gFJIMYPoBzcCvG9T,lTW9p1v7uPfOxB(Q8Q0IDc6PLZajJAdTntKUmSGXz)+dJHDqiKf12TXlIzSLkGUuxg4MBs3A(u"ࠫࠥࠦࠠࡅࡐࡖࡣࡗࡋࡓࡐࡎ࡙ࡉࡗࠦࡦࡢ࡫࡯ࡩࡩࠦࠠࠡࡊࡲࡷࡹࡀࠠ࡜ࠢࠪᇭ")+EnkT2XQRiLO+LZWMikPEB81KSGyxfJtUsCA(u"ࠬࠦ࡝ࠨᇮ"))
	return OkL6wBRsf4
def u0E18eO3HnCzr(Q8Q0IDc6PLZajJAdTntKUmSGXz,Cm4xfTO625jyMtZ8GEpvuKcnbQ1gD,GIE2XSj0vVJPZA6dgmOs9TMDy8UkQW,showDialogs=gBExoceumj4y8bFW9hY2aNMVSr):
	if i4bFG3rKE6.avprivsnorestrict or not GIE2XSj0vVJPZA6dgmOs9TMDy8UkQW: return ag8rjZo1Vz4IPdcOT
	UnF2jXAwPoE = [DaFZHsThGmd0zv6e(u"࠭ࡡࡥࡷ࡯ࡸࠬᇯ"),CC1eY6yWZUwf2TkRvnp7EJ0AimjHBX(u"ࠧ࠲࠺࠮ࠫᇰ"),iNc3KxwErnQ(u"ࠨࡺࡻࠫᇱ"),kYDaz79TFlXoR(u"ࠩࡳࡳࡷࡴࠧᇲ"),l1DZAt9XNQjqE7YOdrz(u"ࠪࡷࡪࡾࠧᇳ"),kYDaz79TFlXoR(u"ࠫࡳࡹࡦࡸࠩᇴ"),YY8UDX3MJhb91AHw7fg(u"ࠬࡳࡡࡵࡷࡵࡩࠬᇵ"),lljaEqwTVtmKsQcOrbXxS5hgNH(u"࠭ใษษิࠫᇶ"),lljaEqwTVtmKsQcOrbXxS5hgNH(u"ࠧษษ็฾ࠬᇷ"),DiJ8CMuYH1daWyjehfN0L(u"ࠨษหหา๐ࠧᇸ"),Ie5s2cBtSfdHjzQ4rA9kYlo6D18(u"ࠩฯุ๊࠭ᇹ"),DiJ8CMuYH1daWyjehfN0L(u"้๊ࠪ์ฺ่ࠩᇺ")]
	if Q8Q0IDc6PLZajJAdTntKUmSGXz!=CC1eY6yWZUwf2TkRvnp7EJ0AimjHBX(u"ࠫࡇࡕࡋࡓࡃࠪᇻ"): UnF2jXAwPoE += [YY8UDX3MJhb91AHw7fg(u"ࠬࡸ࠺ࠨᇼ"),N3flV6EJsD5CzS(u"࠭࠺ࡳࠩᇽ"),kYDaz79TFlXoR(u"ࠧࡳ࠯ࠪᇾ"),tQMjXKCA5dN4xq3beVIzaEoWkFLg(u"ࠨ࠯ࡵࠫᇿ"),qoBMmfAWpFlK70xw8ZRh4naJ(u"ࠩ࠰ࡱࡦ࠭ሀ"),BRWqdruz2A0(u"ࠪࡱࡦ࠳ࠧሁ")]
	for kM2XNqgeE1ls47whaRVmTZPd3D5Cn in GIE2XSj0vVJPZA6dgmOs9TMDy8UkQW:
		kM2XNqgeE1ls47whaRVmTZPd3D5Cn = kM2XNqgeE1ls47whaRVmTZPd3D5Cn.lower()
		if iNc3KxwErnQ(u"ࠫ࡬࡫ࡴ࠯ࡲ࡫ࡴࡄ࠭ሂ") in kM2XNqgeE1ls47whaRVmTZPd3D5Cn: continue
		if tQMjXKCA5dN4xq3beVIzaEoWkFLg(u"ࠬࡴ࡯ࡵࠢࡵࡥࡹ࡫ࡤࠨሃ") in kM2XNqgeE1ls47whaRVmTZPd3D5Cn: continue
		if qoBMmfAWpFlK70xw8ZRh4naJ(u"࠭ࡵ࡯ࡴࡤࡸࡪࡪࠧሄ") in kM2XNqgeE1ls47whaRVmTZPd3D5Cn: continue
		if N3flV6EJsD5CzS(u"ࠧฮๆๅอࠬህ") in kM2XNqgeE1ls47whaRVmTZPd3D5Cn: continue
		if l1DZAt9XNQjqE7YOdrz(u"ࠨ฼ํี๋ࠥี็ใࠪሆ") in kM2XNqgeE1ls47whaRVmTZPd3D5Cn: continue
		kM2XNqgeE1ls47whaRVmTZPd3D5Cn = kM2XNqgeE1ls47whaRVmTZPd3D5Cn.replace(V3VlkhgjEF4n1erPXHcC0NOsfwyAJ(u"ࠩฦࠫሇ"),LZWMikPEB81KSGyxfJtUsCA(u"ࠪหࠬለ")).replace(sjtU6GZQg5XC2pH4(u"ࠫส࠭ሉ"),qoBMmfAWpFlK70xw8ZRh4naJ(u"ࠬอࠧሊ")).replace(iNc3KxwErnQ(u"࠭ยࠨላ"),zYvEaigKWjoq50pXBLDbGJkFc(u"ࠧศࠩሌ")).replace(LZWMikPEB81KSGyxfJtUsCA(u"ࠨ๐ࠪል"),qpFY4hAwolV3).replace(l32dnTEOU1skGKqeBtI9hmo(u"ࠩ๎ࠫሎ"),qpFY4hAwolV3)
		kM2XNqgeE1ls47whaRVmTZPd3D5Cn = kM2XNqgeE1ls47whaRVmTZPd3D5Cn.replace(ee86G9ladLHVbh5mikzCo(u"ࠪ๓ࠬሏ"),qpFY4hAwolV3).replace(ddiCzu6yahj5RtTISMJ48sNnZBU(u"ࠫ๕࠭ሐ"),qpFY4hAwolV3).replace(rNdBKI74fAklnoCZ6(u"ࠬ๓ࠧሑ"),qpFY4hAwolV3).replace(ee86G9ladLHVbh5mikzCo(u"࠭๑ࠨሒ"),qpFY4hAwolV3)
		kM2XNqgeE1ls47whaRVmTZPd3D5Cn = kM2XNqgeE1ls47whaRVmTZPd3D5Cn.replace(iNc3KxwErnQ(u"ࠧแࠩሓ"),qpFY4hAwolV3).replace(l32dnTEOU1skGKqeBtI9hmo(u"ࠨ࠼ࠪሔ"),qpFY4hAwolV3)
		if NJwViHDTMdmO0xnALqQ9voPalC3Ip: kM2XNqgeE1ls47whaRVmTZPd3D5Cn = kM2XNqgeE1ls47whaRVmTZPd3D5Cn.decode(nV3Tip6XsH1rJw79DPOU).encode(nV3Tip6XsH1rJw79DPOU)
		wwWfce7ZSpIaz = ePhmG1jLD6.findall(l1DZAt9XNQjqE7YOdrz(u"ࠩࠫ࠵ࡠ࠻࠭࠺࡟࠮ࢀ࠷ࡡ࠰࠮࠵ࡠ࠯࠮࠭ሕ"),kM2XNqgeE1ls47whaRVmTZPd3D5Cn,ePhmG1jLD6.DOTALL)
		yG7StoYNP0qxzeDR8TMCWwhKEu9 = ag8rjZo1Vz4IPdcOT
		for YBpildqxgGyvkJO2rETWf4PQ in wwWfce7ZSpIaz:
			if len(YBpildqxgGyvkJO2rETWf4PQ)==Zwqio2AIWlD5etFa:
				yG7StoYNP0qxzeDR8TMCWwhKEu9 = gBExoceumj4y8bFW9hY2aNMVSr
				break
		if kM2XNqgeE1ls47whaRVmTZPd3D5Cn in [BRWqdruz2A0(u"ࠪࡶࠬሖ")] or yG7StoYNP0qxzeDR8TMCWwhKEu9 or any(value in kM2XNqgeE1ls47whaRVmTZPd3D5Cn for value in UnF2jXAwPoE):
			LLvyStW429DEZKlA(j8gFJIMYPoBzcCvG9T,lTW9p1v7uPfOxB(Q8Q0IDc6PLZajJAdTntKUmSGXz)+qqzwE6imYG4c2xojI(u"ࠫࠥࠦࠠࡃ࡮ࡲࡧࡰ࡫ࡤࠡࡣࡧࡹࡱࡺࡳࠡࡸ࡬ࡨࡪࡵࠠࠡࠢࡘࡖࡑࡀࠠ࡜ࠢ࠱࠲࠳࠴࠮ࠡ࡟ࠪሗ"))
			if showDialogs: t8yiLuJp3cBA6d1QE9x7eZ4fa(GLTtERWbHnFuy4PCp,CC1eY6yWZUwf2TkRvnp7EJ0AimjHBX(u"ࠬอไโ์า๎ํࠦไๅๅหหึࠦแใูࠣ์ศ์วࠡ็้฽ฯํࠧመ"))
			return gBExoceumj4y8bFW9hY2aNMVSr
	return ag8rjZo1Vz4IPdcOT
def IyjRtqkmHFBvTCDYwuQNJ0(Q530ExmlLS2hKzgefA=gBExoceumj4y8bFW9hY2aNMVSr):
	if Q530ExmlLS2hKzgefA:
		NNWJKEyq13t2kglAZ7d = XXyMBNAVJvKiq7jc20bEw6(WoFsvbmUlDZp7PzRfdGknCV,l32dnTEOU1skGKqeBtI9hmo(u"࠭ࡳࡵࡴࠪሙ"),kYDaz79TFlXoR(u"ࠧࡎࡋࡖࡇࡤ࡚ࡅࡎࡒࡢ࠵ࠬሚ"),LZWMikPEB81KSGyxfJtUsCA(u"ࠨࡗࡖࡉࡗࡇࡇࡆࡐࡗࠫማ"))
		if NNWJKEyq13t2kglAZ7d: return NNWJKEyq13t2kglAZ7d
	Z4vQNwLcAiPVufj9sOgCMU6ezEWG = qpFY4hAwolV3
	if vvXoMLlg513 and lgDZd7ip5Ux.succeeded:
		eVEX29oO0qZjxltJKIfbc8aSd = lgDZd7ip5Ux.content
		VC3guEILhR = eVEX29oO0qZjxltJKIfbc8aSd.count(kYDaz79TFlXoR(u"ࠩࡐࡳࡿ࡯࡬࡭ࡣࠪሜ"))
		if VC3guEILhR>viRJWOC5jsYe84(u"࠺࠳ᜈ"):
			Z4vQNwLcAiPVufj9sOgCMU6ezEWG = ePhmG1jLD6.findall(DaFZHsThGmd0zv6e(u"ࠪ࡫ࡪࡺ࠭ࡵࡪࡨ࠱ࡱ࡯ࡳࡵ࠰࠭ࡃࡃ࠮࠮ࠫࡁࠬࡀࠬም"),eVEX29oO0qZjxltJKIfbc8aSd,ePhmG1jLD6.DOTALL)
			Z4vQNwLcAiPVufj9sOgCMU6ezEWG = Z4vQNwLcAiPVufj9sOgCMU6ezEWG[vvXoMLlg513]
	if not Z4vQNwLcAiPVufj9sOgCMU6ezEWG:
		JejTMtIKPq84CGo = RPbaxsNFVTwek5Kfv21DiJuzCnjMZp.path.join(mFGa34JHCw9LWlB0,viRJWOC5jsYe84(u"ࠫࡦࡸࡡࡣ࡫ࡦࡺ࡮ࡪࡥࡰࡵࠪሞ"),aXqWLoTdVgME(u"ࠬࡻࡳࡦࡴࡤ࡫ࡪࡴࡴࡴ࠰ࡷࡼࡹ࠭ሟ"))
		Z4vQNwLcAiPVufj9sOgCMU6ezEWG = open(JejTMtIKPq84CGo,dJHDqiKf12TXlIzSLkGUuxg4MBs3A(u"࠭ࡲࡣࠩሠ")).read()
		if DLod2Of8CkRrtzJynev: Z4vQNwLcAiPVufj9sOgCMU6ezEWG = Z4vQNwLcAiPVufj9sOgCMU6ezEWG.decode(nV3Tip6XsH1rJw79DPOU)
		Z4vQNwLcAiPVufj9sOgCMU6ezEWG = Z4vQNwLcAiPVufj9sOgCMU6ezEWG.replace(SGUiazdreo6QRKLOWZj5hMX,qpFY4hAwolV3)
	Li39MYv6JrxIWw2SQCgoDqPTh = ePhmG1jLD6.findall(ee86G9ladLHVbh5mikzCo(u"ࠧࠩࡏࡲࡾ࡮ࡲ࡬ࡢ࠰࠭ࡃ࠮ࡢ࡮ࠨሡ"),Z4vQNwLcAiPVufj9sOgCMU6ezEWG,ePhmG1jLD6.DOTALL)
	qp9vOC8RhN0ng4MIfGDL3U6HZ = []
	for w2OCG9BuSMs in Li39MYv6JrxIWw2SQCgoDqPTh:
		K0to2Dq4rWgZe59nT = w2OCG9BuSMs.lower()
		if kYDaz79TFlXoR(u"ࠨࡣࡱࡨࡷࡵࡩࡥࠩሢ") in K0to2Dq4rWgZe59nT: continue
		if ee86G9ladLHVbh5mikzCo(u"ࠩࡸࡦࡺࡴࡴࡶࠩሣ") in K0to2Dq4rWgZe59nT: continue
		if qoBMmfAWpFlK70xw8ZRh4naJ(u"ࠪ࡭ࡵ࡮࡯࡯ࡧࠪሤ") in K0to2Dq4rWgZe59nT: continue
		if aXqWLoTdVgME(u"ࠫࡨࡸ࡯ࡴࠩሥ") in K0to2Dq4rWgZe59nT: continue
		qp9vOC8RhN0ng4MIfGDL3U6HZ.append(w2OCG9BuSMs)
	NNWJKEyq13t2kglAZ7d = P9Kfwdgna8erGcAWyQMOtFbq6Rk.sample(qp9vOC8RhN0ng4MIfGDL3U6HZ,mZi0S72jGoHpLO)
	NNWJKEyq13t2kglAZ7d = NNWJKEyq13t2kglAZ7d[vvXoMLlg513]
	zOYMaQ0NgdiRVwDJXh8e(WoFsvbmUlDZp7PzRfdGknCV,IaBhDMJc17302LgSvyxd(u"ࠬࡓࡉࡔࡅࡢࡘࡊࡓࡐࡠ࠳ࠪሦ"),BRWqdruz2A0(u"࠭ࡕࡔࡇࡕࡅࡌࡋࡎࡕࠩሧ"),NNWJKEyq13t2kglAZ7d,kUz8c7OqsxuPFIGfwg)
	return NNWJKEyq13t2kglAZ7d
def XJwGq95IRv1CoWAx(ggnX3IOk2LPMd=qpFY4hAwolV3):
	if i4bFG3rKE6.ALLOW_SHOWDIALOGS_FIX==ag8rjZo1Vz4IPdcOT: return
	if not ggnX3IOk2LPMd: ggnX3IOk2LPMd = ralpo6SjWw9FGVfcINEgXB0ZDnT.format_exc()
	if tQMjXKCA5dN4xq3beVIzaEoWkFLg(u"ࠧࡔࡻࡶࡸࡪࡳࡅࡹ࡫ࡷࠫረ") in ggnX3IOk2LPMd or Ie5s2cBtSfdHjzQ4rA9kYlo6D18(u"ࠨࡡࡢࡣࡋࡕࡒࡄࡇࡢࡉ࡝ࡏࡔࡠࡡࡢࠫሩ") in ggnX3IOk2LPMd: return
	if ggnX3IOk2LPMd!=sjtU6GZQg5XC2pH4(u"ࠩࡑࡳࡳ࡫ࡔࡺࡲࡨ࠾ࠥࡔ࡯࡯ࡧ࡟ࡲࠬሪ"): TSRUP0dExYGQg.stderr.write(ggnX3IOk2LPMd)
	Mm8BldxpifLUa5s2 = ggnX3IOk2LPMd.splitlines()
	pnjEV0aCuY6oZ9M4k8sF1d = Mm8BldxpifLUa5s2[-kYDaz79TFlXoR(u"࠴ᜉ")]
	pphzelv9DIrPbVd8cs2m = open(k8AjFZIlXNLg5diJCHMR20TEznOY,RlOvin8YIGC2KZXJPk9m0acrMobUex(u"ࠪࡶࡧ࠭ራ")).read()
	if DLod2Of8CkRrtzJynev: pphzelv9DIrPbVd8cs2m = pphzelv9DIrPbVd8cs2m.decode(nV3Tip6XsH1rJw79DPOU)
	pphzelv9DIrPbVd8cs2m = pphzelv9DIrPbVd8cs2m[-mmV2nucZ5Lpl6FO1JMPEqGoQKW(u"࠼࠵࠶࠰ᜊ"):]
	aKNztUwJBSXgd = LZWMikPEB81KSGyxfJtUsCA(u"ࠫࡂ࠭ሬ")*tR1krDGPpO025fghMT3a7UnYj(u"࠶࠶࠰ᜋ")
	if aKNztUwJBSXgd in pphzelv9DIrPbVd8cs2m: pphzelv9DIrPbVd8cs2m = pphzelv9DIrPbVd8cs2m.rsplit(aKNztUwJBSXgd,mZi0S72jGoHpLO)[mZi0S72jGoHpLO]
	if pnjEV0aCuY6oZ9M4k8sF1d in pphzelv9DIrPbVd8cs2m: pphzelv9DIrPbVd8cs2m = pphzelv9DIrPbVd8cs2m.rsplit(pnjEV0aCuY6oZ9M4k8sF1d,mZi0S72jGoHpLO)[vvXoMLlg513]
	iqEZgl69yc57UwvhVseCkJnD3pMb = ePhmG1jLD6.findall(DaFZHsThGmd0zv6e(u"ࠬ࠮ࡓࡰࡷࡵࡧࡪࢂࡍࡰࡦࡨ࠭࠿ࠦ࡜࡜ࠢࠫ࠲࠯ࡅࠩࠡ࡞ࡠࠫር"),pphzelv9DIrPbVd8cs2m,ePhmG1jLD6.DOTALL)
	for UUX9LnJPqB,n38oH7wd6BDyAMJQS in reversed(iqEZgl69yc57UwvhVseCkJnD3pMb):
		if n38oH7wd6BDyAMJQS: break
	else: n38oH7wd6BDyAMJQS = Ie5s2cBtSfdHjzQ4rA9kYlo6D18(u"࠭ࡎࡐࡖࠣࡗࡕࡋࡃࡊࡈࡌࡉࡉ࠭ሮ")
	xxaz1IN5QGdc,w2OCG9BuSMs,oAEFIHdP45gND6J2UZChM = qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3
	D1eTz5osJ3LtHg = fWoVd0Bmtkx(u"ࠧ࡜ࡔࡗࡐࡢ࠭ሯ")+IQ2KCmObsTGuiRdEzt931a40jLg+IaBhDMJc17302LgSvyxd(u"ࠨษ็า฼ษ࠺ࠡࠢࠪሰ")+fF4lt9zWYxXLKZVyAco82PgMj+pnjEV0aCuY6oZ9M4k8sF1d
	FiDk4YaTn5OMVjpP = sjtU6GZQg5XC2pH4(u"ࠩ࡞ࡖ࡙ࡒ࡝ࠨሱ")+IQ2KCmObsTGuiRdEzt931a40jLg+LZWMikPEB81KSGyxfJtUsCA(u"ࠪห้๋ีะำ࠽ࠤࠥ࠭ሲ")+fF4lt9zWYxXLKZVyAco82PgMj+n38oH7wd6BDyAMJQS
	for T6AFpSQjxJKZ5LikbRnf3zvXUOBa in reversed(Mm8BldxpifLUa5s2):
		if BRWqdruz2A0(u"ࠫࡋ࡯࡬ࡦࠢࠥࠫሳ") in T6AFpSQjxJKZ5LikbRnf3zvXUOBa and Ie5s2cBtSfdHjzQ4rA9kYlo6D18(u"ࠬࡧࡲࡢࡤ࡬ࡧࡻ࡯ࡤࡦࡱࡶࠫሴ") in T6AFpSQjxJKZ5LikbRnf3zvXUOBa: break
	T6AFpSQjxJKZ5LikbRnf3zvXUOBa = ePhmG1jLD6.findall(aXqWLoTdVgME(u"࠭ࡆࡪ࡮ࡨࠤࠧ࠮࠮ࠫࡁࠬࠦࡡ࠲ࠠ࡭࡫ࡱࡩࠥ࠮࠮ࠫࡁࠬࡠ࠱ࠦࡩ࡯ࠢࠫ࠲࠯ࡅࠩࠥࠩስ"),T6AFpSQjxJKZ5LikbRnf3zvXUOBa,ePhmG1jLD6.DOTALL)
	if T6AFpSQjxJKZ5LikbRnf3zvXUOBa:
		xxaz1IN5QGdc,w2OCG9BuSMs,oAEFIHdP45gND6J2UZChM = T6AFpSQjxJKZ5LikbRnf3zvXUOBa[vvXoMLlg513]
		if ShynO8pN9idCE3 in xxaz1IN5QGdc: xxaz1IN5QGdc = xxaz1IN5QGdc.rsplit(ShynO8pN9idCE3,mZi0S72jGoHpLO)[mZi0S72jGoHpLO]
		else: xxaz1IN5QGdc = xxaz1IN5QGdc.rsplit(YY8UDX3MJhb91AHw7fg(u"ࠧ࡝࡞ࠪሶ"),mZi0S72jGoHpLO)[mZi0S72jGoHpLO]
		Q3jG1mXDwANTOIHkvJsi9rdaK = ddiCzu6yahj5RtTISMJ48sNnZBU(u"ࠨ࡝ࡕࡘࡑࡣࠧሷ")+IQ2KCmObsTGuiRdEzt931a40jLg+qoBMmfAWpFlK70xw8ZRh4naJ(u"ࠩส่๊๊แ࠻ࠢࠣࠫሸ")+fF4lt9zWYxXLKZVyAco82PgMj+xxaz1IN5QGdc
		yyu2iZgGlqYPm1K5 = DaFZHsThGmd0zv6e(u"ࠪ࡟ࡗ࡚ࡌ࡞ࠩሹ")+IQ2KCmObsTGuiRdEzt931a40jLg+dJHDqiKf12TXlIzSLkGUuxg4MBs3A(u"ࠫฬ๊ำุำ࠽ࠤࠥ࠭ሺ")+fF4lt9zWYxXLKZVyAco82PgMj+w2OCG9BuSMs
		vTwNAj97axKdnDMue8SVWqY = DiJ8CMuYH1daWyjehfN0L(u"ࠬࡡࡒࡕࡎࡠࠫሻ")+IQ2KCmObsTGuiRdEzt931a40jLg+N3flV6EJsD5CzS(u"࠭วๅ็ๆห๋ࡀࠠࠡࠩሼ")+fF4lt9zWYxXLKZVyAco82PgMj+oAEFIHdP45gND6J2UZChM
		o1obHQCrjGaV2h = Q3jG1mXDwANTOIHkvJsi9rdaK+ZLwoRpfnCWI7FgEHsz6te39lMVh+yyu2iZgGlqYPm1K5+ZLwoRpfnCWI7FgEHsz6te39lMVh+vTwNAj97axKdnDMue8SVWqY+ZLwoRpfnCWI7FgEHsz6te39lMVh+FiDk4YaTn5OMVjpP+ZLwoRpfnCWI7FgEHsz6te39lMVh+D1eTz5osJ3LtHg
		u0GLYNpnfTICx4l = yyu2iZgGlqYPm1K5+ZLwoRpfnCWI7FgEHsz6te39lMVh+FiDk4YaTn5OMVjpP+ZLwoRpfnCWI7FgEHsz6te39lMVh+D1eTz5osJ3LtHg+ZLwoRpfnCWI7FgEHsz6te39lMVh+Q3jG1mXDwANTOIHkvJsi9rdaK+ZLwoRpfnCWI7FgEHsz6te39lMVh+vTwNAj97axKdnDMue8SVWqY
		BBQhU1jIKHOx = yyu2iZgGlqYPm1K5+ZLwoRpfnCWI7FgEHsz6te39lMVh+D1eTz5osJ3LtHg+ZLwoRpfnCWI7FgEHsz6te39lMVh+Q3jG1mXDwANTOIHkvJsi9rdaK+ZLwoRpfnCWI7FgEHsz6te39lMVh+vTwNAj97axKdnDMue8SVWqY
	else:
		Q3jG1mXDwANTOIHkvJsi9rdaK,yyu2iZgGlqYPm1K5,vTwNAj97axKdnDMue8SVWqY = qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3
		o1obHQCrjGaV2h = FiDk4YaTn5OMVjpP+tQMjXKCA5dN4xq3beVIzaEoWkFLg(u"ࠧ࡝ࡰ࡟ࡲࠬሽ")+D1eTz5osJ3LtHg
		u0GLYNpnfTICx4l = FiDk4YaTn5OMVjpP+qoBMmfAWpFlK70xw8ZRh4naJ(u"ࠨ࡞ࡱࡠࡳ࠭ሾ")+D1eTz5osJ3LtHg
		BBQhU1jIKHOx = D1eTz5osJ3LtHg
	l7AtaNDGIywnErZhpb = viRJWOC5jsYe84(u"ࠩะำะࠦฮุลࠣ฾๏ืࠠๆไุ์ิ࠭ሿ")+ZLwoRpfnCWI7FgEHsz6te39lMVh
	LZOeqjR7iTry9581XKBMfab0 = yrAu3CSUkLp7dN2DYl()
	n8jyswUIi3t9oH = []
	MOTjA5H9XFs = LZOeqjR7iTry9581XKBMfab0[ee86G9ladLHVbh5mikzCo(u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡤࡶࡦࡨࡩࡤࡸ࡬ࡨࡪࡵࡳࠨቀ")]
	sEToNcDhOqlktC92eFxGPSjdIKYw = BU2EpuS8nvF(Q8q1YzIF6icWtSp2L)
	if CC1eY6yWZUwf2TkRvnp7EJ0AimjHBX(u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡥࡷࡧࡢࡪࡥࡹ࡭ࡩ࡫࡯ࡴࠩቁ") in list(LZOeqjR7iTry9581XKBMfab0.keys()):
		for LU1mWQy9VHbFNBd0fl6M3twu,RSvJEKk0srCw1AfUN8yqZTQ6G,IsLXoKHPl4wUtrjCyG3kazDW7mv in MOTjA5H9XFs:
			n8jyswUIi3t9oH = max(n8jyswUIi3t9oH,RSvJEKk0srCw1AfUN8yqZTQ6G)
		if sEToNcDhOqlktC92eFxGPSjdIKYw<n8jyswUIi3t9oH:
			lowSfvhZIUHz = Ie5s2cBtSfdHjzQ4rA9kYlo6D18(u"่ࠬๅࠡสอัิ๐หࠡษ็ฬึ์วๆฮࠣๆอ๊ࠠฦำึห้ࠦวๅลั฻ฬวࠠๅๆ่ฬึ๋ฬࠨቂ")
			muaCBROQ72TixfPh683Y59qH = eVLmAIGFiwpr94UK6MRP5(zYvEaigKWjoq50pXBLDbGJkFc(u"࠭ࡲࡪࡩ࡫ࡸࠬቃ"),aXqWLoTdVgME(u"ࠧฦำึห้ࠦลๅ๋ࠣห้๋ศา็ฯࠫቄ"),mmV2nucZ5Lpl6FO1JMPEqGoQKW(u"ࠨฬะำ๏ัࠧቅ"),qoBMmfAWpFlK70xw8ZRh4naJ(u"ࠩัีําࠧቆ"),l7AtaNDGIywnErZhpb+lowSfvhZIUHz,o1obHQCrjGaV2h)
			if muaCBROQ72TixfPh683Y59qH==mZi0S72jGoHpLO:
				import t5tWekJ6XG
				t5tWekJ6XG.Yz4RMHeNEZ9PO7VhxGcQjfs1(gBExoceumj4y8bFW9hY2aNMVSr)
				xtm9pSeMInWo60()
			elif muaCBROQ72TixfPh683Y59qH==Zwqio2AIWlD5etFa: xtm9pSeMInWo60()
	A10O3JxyQq2vbmStfLngki5 = XXyMBNAVJvKiq7jc20bEw6(WoFsvbmUlDZp7PzRfdGknCV,qqzwE6imYG4c2xojI(u"ࠪࡰ࡮ࡹࡴࠨቇ"),N3flV6EJsD5CzS(u"ࠫࡒࡏࡓࡄࡡࡓࡉࡗࡓࠧቈ"),lljaEqwTVtmKsQcOrbXxS5hgNH(u"ࠬࡇࡌࡍࡡࡖࡉࡓ࡚࡟ࡆࡔࡕࡓࡗ࡙ࠧ቉"))
	if not A10O3JxyQq2vbmStfLngki5: A10O3JxyQq2vbmStfLngki5 = []
	u0GLYNpnfTICx4l = u0GLYNpnfTICx4l.replace(ZLwoRpfnCWI7FgEHsz6te39lMVh,aXqWLoTdVgME(u"࠭࡜࡝ࡰࠪቊ")).replace(l1DZAt9XNQjqE7YOdrz(u"ࠧ࡜ࡔࡗࡐࡢ࠭ቋ"),qpFY4hAwolV3).replace(IQ2KCmObsTGuiRdEzt931a40jLg,qpFY4hAwolV3).replace(fF4lt9zWYxXLKZVyAco82PgMj,qpFY4hAwolV3)
	BBQhU1jIKHOx = BBQhU1jIKHOx.replace(ZLwoRpfnCWI7FgEHsz6te39lMVh,dJHDqiKf12TXlIzSLkGUuxg4MBs3A(u"ࠨ࡞࡟ࡲࠬቌ")).replace(fWoVd0Bmtkx(u"ࠩ࡞ࡖ࡙ࡒ࡝ࠨቍ"),qpFY4hAwolV3).replace(IQ2KCmObsTGuiRdEzt931a40jLg,qpFY4hAwolV3).replace(fF4lt9zWYxXLKZVyAco82PgMj,qpFY4hAwolV3)
	Xr5BPxvtysCf2DJ6imzNZ = Q8q1YzIF6icWtSp2L+rNdBKI74fAklnoCZ6(u"ࠪ࠾࠿࠭቎")+BBQhU1jIKHOx
	if Xr5BPxvtysCf2DJ6imzNZ in A10O3JxyQq2vbmStfLngki5:
		lowSfvhZIUHz = l1DZAt9XNQjqE7YOdrz(u"้่ࠫฯࠡไ่ฮࠥอๆหࠢึหอ่วࠡสศีุอไ้ࠡำหࠥอไฯูฦࠤส๊้ࠡษ็้อืๅอࠩ቏")
		iG7Rz2kmn0x1yLNMV3u8O(ee86G9ladLHVbh5mikzCo(u"ࠬࡸࡩࡨࡪࡷࠫቐ"),qpFY4hAwolV3,l7AtaNDGIywnErZhpb+lowSfvhZIUHz,o1obHQCrjGaV2h)
		return
	HHdLbyOljwcpEUsKguzv = str(oyFvr0T96AwpqEIgxmP).split(mmV2nucZ5Lpl6FO1JMPEqGoQKW(u"࠭࠮ࠨቑ"))[vvXoMLlg513]
	Cm4xfTO625jyMtZ8GEpvuKcnbQ1gD = i4bFG3rKE6.SITESURLS[BRWqdruz2A0(u"ࠧࡑ࡛ࡗࡌࡔࡔࠧቒ")][RlOvin8YIGC2KZXJPk9m0acrMobUex(u"࠼ᜌ")]
	lgDZd7ip5Ux = WWrExJZS3Bj4anOAkpv7(rGY36xBwT1bLZAngSfcWEIeXdQVNij,UVa3fJw7k6KM(u"ࠨࡒࡒࡗ࡙࠭ቓ"),Cm4xfTO625jyMtZ8GEpvuKcnbQ1gD,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,viRJWOC5jsYe84(u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡗࡍࡕࡗࡠࡇ࡛ࡍ࡙ࡥࡅࡓࡔࡒࡖࡘ࠳࠱ࡴࡶࠪቔ"),ag8rjZo1Vz4IPdcOT,ag8rjZo1Vz4IPdcOT)
	eVEX29oO0qZjxltJKIfbc8aSd = lgDZd7ip5Ux.content
	PTCM8ExwsdWHj = ePhmG1jLD6.findall(fWoVd0Bmtkx(u"ࠪࡗ࡙ࡇࡒࡕ࠼࠽ࡗ࡙ࡇࡒࡕ࡝࡟ࡶࡡࡴ࡝ࠬ࠼࠽ࠬ࠳࠰࠿ࠪ࡝࡟ࡶࡡࡴ࡝ࠬ࠼࠽ࠬ࠳࠰࠿ࠪ࡝࡟ࡶࡡࡴ࡝ࠬ࠼࠽ࠬ࠳࠰࠿ࠪ࡝࡟ࡶࡡࡴ࡝ࠬ࠼࠽ࠬ࠳࠰࠿ࠪ࡝࡟ࡶࡡࡴ࡝ࠬࡇࡑࡈ࠿ࡀࡅࡏࡆࠪቕ"),eVEX29oO0qZjxltJKIfbc8aSd,ePhmG1jLD6.DOTALL)
	for cM4lji9wCeYWTkpu5,fgLsZ9jS5WJ0MnRuqCkd8HvA7cbOU,BkWQF3drqwGxbpK,pXhwWM5z3EAKBeFYmGJRZbI in PTCM8ExwsdWHj:
		cM4lji9wCeYWTkpu5 = cM4lji9wCeYWTkpu5.split(ddiCzu6yahj5RtTISMJ48sNnZBU(u"ࠫ࠰࠭ቖ"))
		BkWQF3drqwGxbpK = BkWQF3drqwGxbpK.split(RlOvin8YIGC2KZXJPk9m0acrMobUex(u"ࠬ࠱ࠧ቗"))
		pXhwWM5z3EAKBeFYmGJRZbI = pXhwWM5z3EAKBeFYmGJRZbI.split(qoBMmfAWpFlK70xw8ZRh4naJ(u"࠭ࠫࠨቘ"))
		if w2OCG9BuSMs in cM4lji9wCeYWTkpu5 and pnjEV0aCuY6oZ9M4k8sF1d==fgLsZ9jS5WJ0MnRuqCkd8HvA7cbOU and Q8q1YzIF6icWtSp2L in BkWQF3drqwGxbpK and HHdLbyOljwcpEUsKguzv in pXhwWM5z3EAKBeFYmGJRZbI:
			lowSfvhZIUHz = qqzwE6imYG4c2xojI(u"่ࠧาสࠤฬ๊ฮุล้ࠣ฾ื่โ๋ࠢื๏฿วๅฮࠣฬฬ๊ลึัสีࠥอไใษา้ࠬ቙")
			o4oUxD3u18K59ghHIY = VVpbtSKYUGXrNMwAWFo9IOjZP(dJHDqiKf12TXlIzSLkGUuxg4MBs3A(u"ࠨࡴ࡬࡫࡭ࡺࠧቚ"),DiJ8CMuYH1daWyjehfN0L(u"ࠩัีําࠧቛ"),qoBMmfAWpFlK70xw8ZRh4naJ(u"ࠪษึูวๅࠢศ่๎ࠦวๅ็หี๊าࠧቜ"),l7AtaNDGIywnErZhpb+lowSfvhZIUHz,o1obHQCrjGaV2h)
			if o4oUxD3u18K59ghHIY==mZi0S72jGoHpLO: iG7Rz2kmn0x1yLNMV3u8O(mmV2nucZ5Lpl6FO1JMPEqGoQKW(u"ࠫࡨ࡫࡮ࡵࡧࡵࠫቝ"),qpFY4hAwolV3,qpFY4hAwolV3,lowSfvhZIUHz)
			return
	lowSfvhZIUHz = sjtU6GZQg5XC2pH4(u"ࠬอไาฮสลࠥหัิษ็ࠤ์ึวࠡษ็า฼ษࠠฦๆ์ࠤฬ๊ๅษำ่ะࠬ቞")
	choice = eVLmAIGFiwpr94UK6MRP5(zYvEaigKWjoq50pXBLDbGJkFc(u"࠭ࡲࡪࡩ࡫ࡸࠬ቟"),YY8UDX3MJhb91AHw7fg(u"ࠧฦำึห้ࠦลๅ๋ࠣห้๋ศา็ฯࠫበ"),dJHDqiKf12TXlIzSLkGUuxg4MBs3A(u"ࠨฬะำ๏ัࠠอิษ๎ࠬቡ"),aXqWLoTdVgME(u"ࠩอัิ๐หࠡษ็ฬึ์วๆฮࠪቢ"),l7AtaNDGIywnErZhpb+lowSfvhZIUHz,o1obHQCrjGaV2h)
	if choice==mZi0S72jGoHpLO:
		p4z1rSkcvW3OgjmsFtdLG(ag8rjZo1Vz4IPdcOT)
		t8yiLuJp3cBA6d1QE9x7eZ4fa(mmV2nucZ5Lpl6FO1JMPEqGoQKW(u"๊ࠪัำสࠡ฻่่๏ฯࠠศๆอัิ๐หࠡษ็ะืฬ๊ࠨባ"),lljaEqwTVtmKsQcOrbXxS5hgNH(u"ࠫࡘࡻࡣࡤࡧࡶࡷࠬቤ"),s7FnXZYOgexlH2MPb8BJck1AKv9=iNc3KxwErnQ(u"࠷࠶࠲ᜍ"))
		xtm9pSeMInWo60()
	elif choice==Zwqio2AIWlD5etFa:
		import t5tWekJ6XG
		t5tWekJ6XG.Yz4RMHeNEZ9PO7VhxGcQjfs1(gBExoceumj4y8bFW9hY2aNMVSr)
		xtm9pSeMInWo60()
	o4oUxD3u18K59ghHIY = VVpbtSKYUGXrNMwAWFo9IOjZP(N3flV6EJsD5CzS(u"ࠬࡩࡥ࡯ࡶࡨࡶࠬብ"),qpFY4hAwolV3,qpFY4hAwolV3,GLTtERWbHnFuy4PCp,UUDAiytEL76RTmMYsuIz5evXB(u"࠭ำ้ใࠣ๎ฯ๋ࠠฦำึห้ࠦำอๆࠣห้ษฮุษฤࠤํอไศีอาิอๅࠡว็ํࠥอไๆสิ้ัࠦไไ์ࠣ๎฾ืแࠡษ็้อืๅอࠢฦ๎๋่ࠦๆฬ์ࠤํ้๊โ๋่๊ࠢอะศࠢะู้ะ่ࠠา๊ࠤฬ๊ๅีๅ็อ๊ࠥร็ࠢส่๊ฮัๆฮ่ࠣฬฺ๊ࠦๆ่ࠤฬฺ๊๋สࠣ์้อ๋ࠠีอ฻๏฿ࠠศื็หาࠦๅีๅ็อࠥ๎็้ࠢ็หࠥ๐ูาใࠣ็๏็ู้ࠠิฮࠥ๎ไๆษำหࠥ฾็าฬࠣ์๊ะฺ้๊ࠡีฯࠦ็ั้ࠣห้๋ิไๆฬࠤ࠳ࠦ็ๅࠢอี๏ีࠠฤำึห้ࠦวๅีฯ่ࠥลࠧቦ"))
	if o4oUxD3u18K59ghHIY==mZi0S72jGoHpLO: k2nju1XItgCWLobyG6 = YY8UDX3MJhb91AHw7fg(u"ࠧࡠࡒࡕࡓࡇࡒࡅࡎࡡࠪቧ")
	else:
		iG7Rz2kmn0x1yLNMV3u8O(mmV2nucZ5Lpl6FO1JMPEqGoQKW(u"ࠨࡥࡨࡲࡹ࡫ࡲࠨቨ"),qpFY4hAwolV3,GLTtERWbHnFuy4PCp,IQ2KCmObsTGuiRdEzt931a40jLg+rNdBKI74fAklnoCZ6(u"ࠩอ้ࠥหไ฻ษฤࠤสืำศๆࠣห้ิืฤࠩቩ")+fF4lt9zWYxXLKZVyAco82PgMj+mmV2nucZ5Lpl6FO1JMPEqGoQKW(u"ࠪࡠࡳ๊ร็ࠢส่๊ฮัๆฮ่ࠣฬฺ๊ࠦๆ่ࠤฬฺ๊๋สࠣ์้อ๋ࠠีอ฻๏฿ࠠฦื็หาࠦวๅะฺวࠥฮฯ้่ࠣืั๊ࠠศๆฦา฼อมࠡษ็ิ๏ࠦๅไฬ๋ฬࠥ็๊่ࠢฯ้๏฿ࠠหใสู๏๊่ࠠาสࠤฬ๊ฮุลࠣ์฿๐ั่่๊ࠢࠥอไฤะฺหฦ࠭ቪ"))
		return
	NVFLtBCmp8GAXi5u = u0GLYNpnfTICx4l
	import t5tWekJ6XG
	zlQAfuT2Z7nKhGdXs = t5tWekJ6XG.CCfRqS47rTDe9GyQ5za2JwxpIUV(fWoVd0Bmtkx(u"ࠫࡊࡸࡲࡰࡴࡶࠫቫ"),NVFLtBCmp8GAXi5u,gBExoceumj4y8bFW9hY2aNMVSr,qpFY4hAwolV3,viRJWOC5jsYe84(u"ࠬࡋࡍࡂࡋࡏ࠱ࡋࡘࡏࡎ࠯ࡖࡌࡔ࡝࡟ࡆ࡚ࡌࡘࡤࡋࡒࡓࡑࡕࡗࠬቬ"),k2nju1XItgCWLobyG6)
	if zlQAfuT2Z7nKhGdXs and k2nju1XItgCWLobyG6:
		A10O3JxyQq2vbmStfLngki5.append(Xr5BPxvtysCf2DJ6imzNZ)
		zOYMaQ0NgdiRVwDJXh8e(WoFsvbmUlDZp7PzRfdGknCV,LZWMikPEB81KSGyxfJtUsCA(u"࠭ࡍࡊࡕࡆࡣࡕࡋࡒࡎࠩቭ"),tQMjXKCA5dN4xq3beVIzaEoWkFLg(u"ࠧࡂࡎࡏࡣࡘࡋࡎࡕࡡࡈࡖࡗࡕࡒࡔࠩቮ"),A10O3JxyQq2vbmStfLngki5,ivLg9zRnGF83u)
	return
def uuEImcSejWXyZY6ULzltgR(dimhv1XTVH8UOrc9EGJZ6,filename=H1k0Fmba4Gfiynp8AML):
	s7FnXZYOgexlH2MPb8BJck1AKv9.sleep(N3flV6EJsD5CzS(u"࠱࠰࠳࠶࠺ᜎ"))
	dimhv1XTVH8UOrc9EGJZ6 = dimhv1XTVH8UOrc9EGJZ6.encode(nV3Tip6XsH1rJw79DPOU) if (DLod2Of8CkRrtzJynev and isinstance(dimhv1XTVH8UOrc9EGJZ6, str)) or (not DLod2Of8CkRrtzJynev and isinstance(dimhv1XTVH8UOrc9EGJZ6, unicode)) else str(dimhv1XTVH8UOrc9EGJZ6)
	if not filename: e90IM2s7vtVQTcGkZaUdNA6Y = zYvEaigKWjoq50pXBLDbGJkFc(u"ࠨࡵ࠽ࡠࡡ࠶࠰࠱࠲ࡨࡱࡦࡪ࡟ࠨቯ")+str(s7FnXZYOgexlH2MPb8BJck1AKv9.time())+dJHDqiKf12TXlIzSLkGUuxg4MBs3A(u"ࠩ࠱ࡨࡦࡺࠧተ")
	else: e90IM2s7vtVQTcGkZaUdNA6Y = aXqWLoTdVgME(u"ࠪࡷ࠿ࡢ࡜࠱࠲࠳࠴ࡪࡳࡡࡥࡡࠪቱ")+filename+viRJWOC5jsYe84(u"ࠫ࠳ࡪࡡࡵࠩቲ")
	open(e90IM2s7vtVQTcGkZaUdNA6Y,UUDAiytEL76RTmMYsuIz5evXB(u"ࠬࡽࡢࠨታ")).write(dimhv1XTVH8UOrc9EGJZ6)
	return
def asFZzCl2vSoiNRU34K(FAHCtdm48uIsx):
	if FAHCtdm48uIsx:
		weoxDcHJ1PsSiE5pqY7bWMIfX = XXyMBNAVJvKiq7jc20bEw6(WoFsvbmUlDZp7PzRfdGknCV,CC1eY6yWZUwf2TkRvnp7EJ0AimjHBX(u"࠭࡬ࡪࡵࡷࠫቴ"),CC1eY6yWZUwf2TkRvnp7EJ0AimjHBX(u"ࠧࡎࡋࡖࡇࡤ࡚ࡅࡎࡒࡢ࠵ࠬት"),ee86G9ladLHVbh5mikzCo(u"ࠨࡓࡘࡉࡘ࡚ࡉࡐࡐࡖࠫቶ"))
		if weoxDcHJ1PsSiE5pqY7bWMIfX: return weoxDcHJ1PsSiE5pqY7bWMIfX
	Cm4xfTO625jyMtZ8GEpvuKcnbQ1gD = i4bFG3rKE6.SITESURLS[kYDaz79TFlXoR(u"ࠩࡓ࡝࡙ࡎࡏࡏࠩቷ")][N3flV6EJsD5CzS(u"࠷ᜏ")]
	WRbn1LC2xPJMZft = VfIUXSM1GcvJ6hdr7(ag8rjZo1Vz4IPdcOT) if not FAHCtdm48uIsx else i4bFG3rKE6.AV_CLIENT_IDS
	UZHj1CuOIxPzAoTvcEV05d7NFi2G3m = bfLg2cN8FvsxWMeyj7q()
	F1KMGjNvHegbIJEs3fcOtwq = UZHj1CuOIxPzAoTvcEV05d7NFi2G3m.split(iNc3KxwErnQ(u"ࠪ࠰࠱࠭ቸ"))[Zwqio2AIWlD5etFa]
	lRKcGkOgJYhbqEnfwXr3H6j8y2a = RPbaxsNFVTwek5Kfv21DiJuzCnjMZp.path.join(mFGa34JHCw9LWlB0,IaBhDMJc17302LgSvyxd(u"ࠫࡦࡸࡡࡣ࡫ࡦࡺ࡮ࡪࡥࡰࡵࠪቹ"))
	cxjSLkUZd6VEozw = j06rHnAtPByzqWGuZofg3X2OKkCF7p()
	xJyvEDcMaBj0Ph37b8WeIlNiU = {zYvEaigKWjoq50pXBLDbGJkFc(u"ࠬࡻࡳࡦࡴࠪቺ"):WRbn1LC2xPJMZft,mmV2nucZ5Lpl6FO1JMPEqGoQKW(u"࠭ࡶࡦࡴࡶ࡭ࡴࡴࠧቻ"):Q8q1YzIF6icWtSp2L,DiJ8CMuYH1daWyjehfN0L(u"ࠧࡤࡱࡸࡲࡹࡸࡹࠨቼ"):F1KMGjNvHegbIJEs3fcOtwq,DiJ8CMuYH1daWyjehfN0L(u"ࠨ࡫ࡧࡷࠬች"):Ikw7JgrXvRT8zteLb5sV6WidBN(cxjSLkUZd6VEozw)}
	lgDZd7ip5Ux = WWrExJZS3Bj4anOAkpv7(dzcNuIbsgK3yZ6SXGaEHPfOj5vk,rNdBKI74fAklnoCZ6(u"ࠩࡓࡓࡘ࡚ࠧቾ"),Cm4xfTO625jyMtZ8GEpvuKcnbQ1gD,xJyvEDcMaBj0Ph37b8WeIlNiU,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,tQMjXKCA5dN4xq3beVIzaEoWkFLg(u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡌࡋࡔࡠࡓࡘࡉࡘ࡚ࡉࡐࡐࡖ࠱࠶ࡹࡴࠨቿ"))
	weoxDcHJ1PsSiE5pqY7bWMIfX = []
	if lgDZd7ip5Ux.succeeded:
		eVEX29oO0qZjxltJKIfbc8aSd = lgDZd7ip5Ux.content
		weoxDcHJ1PsSiE5pqY7bWMIfX = eVEX29oO0qZjxltJKIfbc8aSd.replace(kYDaz79TFlXoR(u"ࠫࡡࡢࡲࠨኀ"),ZLwoRpfnCWI7FgEHsz6te39lMVh).replace(l32dnTEOU1skGKqeBtI9hmo(u"ࠬࡢ࡜࡯ࠩኁ"),ZLwoRpfnCWI7FgEHsz6te39lMVh).replace(tR1krDGPpO025fghMT3a7UnYj(u"࠭࡜ࡳ࡞ࡱࠫኂ"),ZLwoRpfnCWI7FgEHsz6te39lMVh).replace(SGUiazdreo6QRKLOWZj5hMX,ZLwoRpfnCWI7FgEHsz6te39lMVh)
		weoxDcHJ1PsSiE5pqY7bWMIfX = ePhmG1jLD6.findall(l32dnTEOU1skGKqeBtI9hmo(u"ࠧࡔࡖࡄࡖ࡙ࡀ࠺ࡔࡖࡄࡖ࡙ࡀ࠺ࠩ࡞ࡧ࠯࠮ࡀ࠺ࠩ࠰࠭ࡃ࠮ࡢ࡮࠻࠼ࠫ࠲࠯ࡅࠩ࡝ࡰ࠽࠾࠭࠴ࠪࡀࠫ࡟ࡲ࠿ࡀࠨ࠯ࠬࡂ࠭ࡡࡴ࠺࠻ࠪ࠱࠮ࡄ࠯࡜࡯ࡇࡑࡈ࠿ࡀࡅࡏࡆࠪኃ"),weoxDcHJ1PsSiE5pqY7bWMIfX,ePhmG1jLD6.DOTALL)
		if weoxDcHJ1PsSiE5pqY7bWMIfX:
			weoxDcHJ1PsSiE5pqY7bWMIfX = sorted(weoxDcHJ1PsSiE5pqY7bWMIfX,reverse=ag8rjZo1Vz4IPdcOT,key=lambda key: int(key[vvXoMLlg513]))
			Zu96PkNGaiqRH3d,WRbn1LC2xPJMZft,nKb2w7UW0qVN,OkL6wBRsf4,T97ftnWyDr2coKalSe,AGUTOIbFi4tDB1 = weoxDcHJ1PsSiE5pqY7bWMIfX[vvXoMLlg513]
			qRw0p7TeAUvjOPibGlF = AGUTOIbFi4tDB1 if i4bFG3rKE6.avprivslongperiod else nKb2w7UW0qVN
			gdPslyFW8ITBcpA302.setSetting(DiJ8CMuYH1daWyjehfN0L(u"ࠨࡣࡹ࠲ࡵ࡫ࡲࡪࡱࡧ࠲࡮ࡴࡦࡰࡵࠪኄ"),qRw0p7TeAUvjOPibGlF)
			zOYMaQ0NgdiRVwDJXh8e(WoFsvbmUlDZp7PzRfdGknCV,YY8UDX3MJhb91AHw7fg(u"ࠩࡐࡍࡘࡉ࡟ࡕࡇࡐࡔࡤ࠷ࠧኅ"),aXqWLoTdVgME(u"ࠪࡕ࡚ࡋࡓࡕࡋࡒࡒࡘ࠭ኆ"),weoxDcHJ1PsSiE5pqY7bWMIfX,kUz8c7OqsxuPFIGfwg)
			gdPslyFW8ITBcpA302.setSetting(lljaEqwTVtmKsQcOrbXxS5hgNH(u"ࠫࡦࡼ࠮࡭ࡣࡶࡸࡨ࡮ࡥࡤ࡭࠱ࡵࡺ࡫ࡳࡵ࡫ࡲࡲࡸ࠭ኇ"),Ikw7JgrXvRT8zteLb5sV6WidBN(dAeP20gNJ6ltq))
	return weoxDcHJ1PsSiE5pqY7bWMIfX
def mG853yUPCJW(ccaFGRENLACdnpZevMB25P6,OS6DIchar1xs0=vvXoMLlg513,P1Ph8mMliTtkOXfYUNJAsRy=vvXoMLlg513):
	if OS6DIchar1xs0 and not P1Ph8mMliTtkOXfYUNJAsRy: P1Ph8mMliTtkOXfYUNJAsRy = len(ccaFGRENLACdnpZevMB25P6)//OS6DIchar1xs0
	HOg1VndBf9sk4NjxucblhZ30,nnZ13Rr6tYXio0DyfLVvSxBec,pvTMfBKPUC1i8nyz2w = [],-mZi0S72jGoHpLO,vvXoMLlg513
	for oPd4bh1MqQxN in ccaFGRENLACdnpZevMB25P6:
		if pvTMfBKPUC1i8nyz2w%P1Ph8mMliTtkOXfYUNJAsRy==vvXoMLlg513:
			nnZ13Rr6tYXio0DyfLVvSxBec += mZi0S72jGoHpLO
			HOg1VndBf9sk4NjxucblhZ30.append([])
		HOg1VndBf9sk4NjxucblhZ30[nnZ13Rr6tYXio0DyfLVvSxBec].append(oPd4bh1MqQxN)
		pvTMfBKPUC1i8nyz2w += mZi0S72jGoHpLO
	return HOg1VndBf9sk4NjxucblhZ30
def cV6PqXALtDQsY2mSp18z(e90IM2s7vtVQTcGkZaUdNA6Y,dimhv1XTVH8UOrc9EGJZ6):
	Pz546fUa8OM2ihjSR1Yl3LW = RPbaxsNFVTwek5Kfv21DiJuzCnjMZp.path.join(F8qeAKZjGRMNXimho2gntaV0,e90IM2s7vtVQTcGkZaUdNA6Y)
	if mZi0S72jGoHpLO or lljaEqwTVtmKsQcOrbXxS5hgNH(u"ࠬࡏࡐࡕࡘࡢࠫኈ") not in e90IM2s7vtVQTcGkZaUdNA6Y or mmV2nucZ5Lpl6FO1JMPEqGoQKW(u"࠭ࡍ࠴ࡗࡢࠫ኉") not in e90IM2s7vtVQTcGkZaUdNA6Y: Z4vQNwLcAiPVufj9sOgCMU6ezEWG = str(dimhv1XTVH8UOrc9EGJZ6)
	else:
		HOg1VndBf9sk4NjxucblhZ30 = mG853yUPCJW(dimhv1XTVH8UOrc9EGJZ6,viRJWOC5jsYe84(u"࠻ᜐ"))
		Z4vQNwLcAiPVufj9sOgCMU6ezEWG = qpFY4hAwolV3
		for dmUGQqRgK3Pk in HOg1VndBf9sk4NjxucblhZ30:
			Z4vQNwLcAiPVufj9sOgCMU6ezEWG += str(dmUGQqRgK3Pk)+c2RKu0xG1eC8MiohyE(u"ࠧ࡝ࡰ࡟ࡲࡂࡃ࠽࠾࡞ࡱࡠࡳ࠭ኊ")
		Z4vQNwLcAiPVufj9sOgCMU6ezEWG = Z4vQNwLcAiPVufj9sOgCMU6ezEWG.strip(qqzwE6imYG4c2xojI(u"ࠨ࡞ࡱࡠࡳࡃ࠽࠾࠿࡟ࡲࡡࡴࠧኋ"))
	ogEX01TKPrHw = ze8aGJsEFdtAWH.compress(Z4vQNwLcAiPVufj9sOgCMU6ezEWG)
	open(Pz546fUa8OM2ihjSR1Yl3LW,RlOvin8YIGC2KZXJPk9m0acrMobUex(u"ࠩࡺࡦࠬኌ")).write(ogEX01TKPrHw)
	return
def qyn5HkIxuWgBeDCo2LOQX(b4SLFUgOtkRAMDaicj0xKwdpq,e90IM2s7vtVQTcGkZaUdNA6Y):
	if b4SLFUgOtkRAMDaicj0xKwdpq==zYvEaigKWjoq50pXBLDbGJkFc(u"ࠪࡨ࡮ࡩࡴࠨኍ"): dimhv1XTVH8UOrc9EGJZ6 = {}
	elif b4SLFUgOtkRAMDaicj0xKwdpq==ddiCzu6yahj5RtTISMJ48sNnZBU(u"ࠫࡱ࡯ࡳࡵࠩ኎"): dimhv1XTVH8UOrc9EGJZ6 = []
	elif b4SLFUgOtkRAMDaicj0xKwdpq==iNc3KxwErnQ(u"ࠬࡹࡴࡳࠩ኏"): dimhv1XTVH8UOrc9EGJZ6 = qpFY4hAwolV3
	elif b4SLFUgOtkRAMDaicj0xKwdpq==UUDAiytEL76RTmMYsuIz5evXB(u"࠭ࡩ࡯ࡶࠪነ"): dimhv1XTVH8UOrc9EGJZ6 = vvXoMLlg513
	else: dimhv1XTVH8UOrc9EGJZ6 = H1k0Fmba4Gfiynp8AML
	Pz546fUa8OM2ihjSR1Yl3LW = RPbaxsNFVTwek5Kfv21DiJuzCnjMZp.path.join(F8qeAKZjGRMNXimho2gntaV0,e90IM2s7vtVQTcGkZaUdNA6Y)
	ogEX01TKPrHw = open(Pz546fUa8OM2ihjSR1Yl3LW,tR1krDGPpO025fghMT3a7UnYj(u"ࠧࡳࡤࠪኑ")).read()
	Z4vQNwLcAiPVufj9sOgCMU6ezEWG = ze8aGJsEFdtAWH.decompress(ogEX01TKPrHw)
	if UUDAiytEL76RTmMYsuIz5evXB(u"ࠨ࡞ࡱࡠࡳࡃ࠽࠾࠿࡟ࡲࡡࡴࠧኒ") not in Z4vQNwLcAiPVufj9sOgCMU6ezEWG: dimhv1XTVH8UOrc9EGJZ6 = eval(Z4vQNwLcAiPVufj9sOgCMU6ezEWG)
	else:
		HOg1VndBf9sk4NjxucblhZ30 = Z4vQNwLcAiPVufj9sOgCMU6ezEWG.split(l32dnTEOU1skGKqeBtI9hmo(u"ࠩ࡟ࡲࡡࡴ࠽࠾࠿ࡀࡠࡳࡢ࡮ࠨና"))
		del Z4vQNwLcAiPVufj9sOgCMU6ezEWG
		dimhv1XTVH8UOrc9EGJZ6 = []
		zxsyB9t2UR1IagCOomuvd0Xp6 = A9JZujzBXNEck2sKYt75rwQRIL4CT()
		Zu96PkNGaiqRH3d = vvXoMLlg513
		for dmUGQqRgK3Pk in HOg1VndBf9sk4NjxucblhZ30:
			zxsyB9t2UR1IagCOomuvd0Xp6.jJaHlms7gkZM06SPiE(str(Zu96PkNGaiqRH3d),eval,dmUGQqRgK3Pk)
			Zu96PkNGaiqRH3d += mZi0S72jGoHpLO
		del HOg1VndBf9sk4NjxucblhZ30
		zxsyB9t2UR1IagCOomuvd0Xp6.fBXPGVdRoHN0EpruWg4OCTFQeIKy7()
		zxsyB9t2UR1IagCOomuvd0Xp6.xAQqijnD9JpfYuoPR4()
		B2wH18VZ9fOp4zYDTIi3t5 = list(zxsyB9t2UR1IagCOomuvd0Xp6.resultsDICT.keys())
		vvYX9Og5Be = sorted(B2wH18VZ9fOp4zYDTIi3t5,reverse=ag8rjZo1Vz4IPdcOT,key=lambda key: int(key))
		for Zu96PkNGaiqRH3d in vvYX9Og5Be:
			dimhv1XTVH8UOrc9EGJZ6 += zxsyB9t2UR1IagCOomuvd0Xp6.resultsDICT[Zu96PkNGaiqRH3d]
	return dimhv1XTVH8UOrc9EGJZ6
def abo14QhCiY9rVELdxGJy0tHwecKzBu(xqJBEohLpFs):
	ygXdSlzf0PNiOCZxu7RAkG = RPbaxsNFVTwek5Kfv21DiJuzCnjMZp.path.join(ssQ5T7em6WrVwIGtXoxNKaBv48zHAM,BRWqdruz2A0(u"ࠪࡥࡩࡪ࡯࡯ࡵࠪኔ"),xqJBEohLpFs,UUDAiytEL76RTmMYsuIz5evXB(u"ࠫࡦࡪࡤࡰࡰ࠱ࡼࡲࡲࠧን"))
	try: YFUro8OAmpN6ZdM1xqQjJ9I2Bbse3 = open(ygXdSlzf0PNiOCZxu7RAkG,lljaEqwTVtmKsQcOrbXxS5hgNH(u"ࠬࡸࡢࠨኖ")).read()
	except:
		iahlsFTLNcvkyPD0wAE5JGgIrme4qo = RPbaxsNFVTwek5Kfv21DiJuzCnjMZp.path.join(U7xCqdacJfvOKrH4wmAZ6sLX83SPIp,UUDAiytEL76RTmMYsuIz5evXB(u"࠭ࡡࡥࡦࡲࡲࡸ࠭ኗ"),xqJBEohLpFs,UUDAiytEL76RTmMYsuIz5evXB(u"ࠧࡢࡦࡧࡳࡳ࠴ࡸ࡮࡮ࠪኘ"))
		try: YFUro8OAmpN6ZdM1xqQjJ9I2Bbse3 = open(iahlsFTLNcvkyPD0wAE5JGgIrme4qo,iNc3KxwErnQ(u"ࠨࡴࡥࠫኙ")).read()
		except: return qpFY4hAwolV3,[]
	if DLod2Of8CkRrtzJynev: YFUro8OAmpN6ZdM1xqQjJ9I2Bbse3 = YFUro8OAmpN6ZdM1xqQjJ9I2Bbse3.decode(nV3Tip6XsH1rJw79DPOU)
	MwXW415FL7myjpSGcDo6NC3sR9erxh = ePhmG1jLD6.findall(sjtU6GZQg5XC2pH4(u"ࠩ࡬ࡨࡂ࠴ࠪࡀࡸࡨࡶࡸ࡯࡯࡯࠿࡞ࡠࠧࡢࠧ࡞ࠪ࠱࠮ࡄ࠯࡛࡝ࠤ࡟ࠫࡢ࠭ኚ"),YFUro8OAmpN6ZdM1xqQjJ9I2Bbse3,ePhmG1jLD6.DOTALL|ePhmG1jLD6.IGNORECASE)
	if not MwXW415FL7myjpSGcDo6NC3sR9erxh: return qpFY4hAwolV3,[]
	f7BjcGO31Y9ndg0oivlry5ZCa42QeK,FFZexcBVTEhmqwU = MwXW415FL7myjpSGcDo6NC3sR9erxh[vvXoMLlg513],BU2EpuS8nvF(MwXW415FL7myjpSGcDo6NC3sR9erxh[vvXoMLlg513])
	return f7BjcGO31Y9ndg0oivlry5ZCa42QeK,FFZexcBVTEhmqwU
def yrAu3CSUkLp7dN2DYl():
	um0KEad67PwTyUOM3Qf = XXyMBNAVJvKiq7jc20bEw6(WoFsvbmUlDZp7PzRfdGknCV,V3VlkhgjEF4n1erPXHcC0NOsfwyAJ(u"ࠪࡨ࡮ࡩࡴࠨኛ"),lljaEqwTVtmKsQcOrbXxS5hgNH(u"ࠫࡒࡏࡓࡄࡡࡗࡉࡒࡖ࡟࠲ࠩኜ"),qqzwE6imYG4c2xojI(u"ࠬࡇࡌࡍࡡࡄࡈࡉࡕࡎࡔࡡ࡛ࡑࡑ࠭ኝ"))
	if um0KEad67PwTyUOM3Qf: return um0KEad67PwTyUOM3Qf
	LZOeqjR7iTry9581XKBMfab0,um0KEad67PwTyUOM3Qf = {},{}
	iqEZgl69yc57UwvhVseCkJnD3pMb = [i4bFG3rKE6.SITESURLS[IaBhDMJc17302LgSvyxd(u"࠭ࡒࡆࡒࡒࡗࠬኞ")][vvXoMLlg513]]
	if oyFvr0T96AwpqEIgxmP>LZWMikPEB81KSGyxfJtUsCA(u"࠵࠼࠴࠹࠺ᜑ"): iqEZgl69yc57UwvhVseCkJnD3pMb.append(i4bFG3rKE6.SITESURLS[qoBMmfAWpFlK70xw8ZRh4naJ(u"ࠧࡓࡇࡓࡓࡘ࠭ኟ")][mZi0S72jGoHpLO])
	if DLod2Of8CkRrtzJynev: iqEZgl69yc57UwvhVseCkJnD3pMb.append(i4bFG3rKE6.SITESURLS[mmV2nucZ5Lpl6FO1JMPEqGoQKW(u"ࠨࡔࡈࡔࡔ࡙ࠧአ")][Zwqio2AIWlD5etFa])
	for tcmel03gS2Bq in iqEZgl69yc57UwvhVseCkJnD3pMb:
		lgDZd7ip5Ux = WWrExJZS3Bj4anOAkpv7(dzcNuIbsgK3yZ6SXGaEHPfOj5vk,aXqWLoTdVgME(u"ࠩࡊࡉ࡙࠭ኡ"),tcmel03gS2Bq,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,UUDAiytEL76RTmMYsuIz5evXB(u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡗࡋࡁࡅࡡࡄࡐࡑࡥࡁࡅࡆࡒࡒࡘࡥࡘࡎࡎ࠰࠵ࡸࡺࠧኢ"))
		if lgDZd7ip5Ux.succeeded:
			eVEX29oO0qZjxltJKIfbc8aSd = lgDZd7ip5Ux.content
			WNG0vaXMsOS6 = tcmel03gS2Bq.rsplit(ShynO8pN9idCE3,LZWMikPEB81KSGyxfJtUsCA(u"࠶ᜒ"))[vvXoMLlg513]
			ipanIyVcumjDfPB70e = ePhmG1jLD6.findall(BRWqdruz2A0(u"ࠫ࡮ࡪ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡺࡪࡸࡳࡪࡱࡱࡁࠧ࠮࠮ࠫࡁࠬࠦࠬኣ"),eVEX29oO0qZjxltJKIfbc8aSd,ePhmG1jLD6.DOTALL|ePhmG1jLD6.IGNORECASE)
			for xqJBEohLpFs,rPEjyAWGKqbde2DF in ipanIyVcumjDfPB70e:
				cr8bsem97N6wyMjq = WNG0vaXMsOS6+ShynO8pN9idCE3+xqJBEohLpFs+ShynO8pN9idCE3+xqJBEohLpFs+ddiCzu6yahj5RtTISMJ48sNnZBU(u"ࠬ࠳ࠧኤ")+rPEjyAWGKqbde2DF+V3VlkhgjEF4n1erPXHcC0NOsfwyAJ(u"࠭࠮ࡻ࡫ࡳࠫእ")
				if xqJBEohLpFs not in list(LZOeqjR7iTry9581XKBMfab0.keys()):
					LZOeqjR7iTry9581XKBMfab0[xqJBEohLpFs] = []
					um0KEad67PwTyUOM3Qf[xqJBEohLpFs] = []
				hckXvV3lPnTFam = BU2EpuS8nvF(rPEjyAWGKqbde2DF)
				LZOeqjR7iTry9581XKBMfab0[xqJBEohLpFs].append((rPEjyAWGKqbde2DF,hckXvV3lPnTFam,cr8bsem97N6wyMjq))
	for xqJBEohLpFs in list(LZOeqjR7iTry9581XKBMfab0.keys()):
		um0KEad67PwTyUOM3Qf[xqJBEohLpFs] = sorted(LZOeqjR7iTry9581XKBMfab0[xqJBEohLpFs],reverse=gBExoceumj4y8bFW9hY2aNMVSr,key=lambda key: key[mZi0S72jGoHpLO])
	zOYMaQ0NgdiRVwDJXh8e(WoFsvbmUlDZp7PzRfdGknCV,DiJ8CMuYH1daWyjehfN0L(u"ࠧࡎࡋࡖࡇࡤ࡚ࡅࡎࡒࡢ࠵ࠬኦ"),zYvEaigKWjoq50pXBLDbGJkFc(u"ࠨࡃࡏࡐࡤࡇࡄࡅࡑࡑࡗࡤ࡞ࡍࡍࠩኧ"),um0KEad67PwTyUOM3Qf,kUz8c7OqsxuPFIGfwg)
	return um0KEad67PwTyUOM3Qf
def BU2EpuS8nvF(rPEjyAWGKqbde2DF):
	hckXvV3lPnTFam = []
	ccHJ5Ri4FBKEn9t6I = rPEjyAWGKqbde2DF.split(zYvEaigKWjoq50pXBLDbGJkFc(u"ࠩ࠱ࠫከ"))
	for wpPIyaVkiGK in ccHJ5Ri4FBKEn9t6I:
		oenphG2AxK3HrFTUi4QcOV1MIRWBJE = ePhmG1jLD6.findall(N3flV6EJsD5CzS(u"ࠪࡠࡩ࠱ࡼ࡜࡞࠮ࡠ࠲ࡧ࠭ࡻࡃ࠰࡞ࡢ࠱ࠧኩ"),wpPIyaVkiGK,ePhmG1jLD6.DOTALL)
		IB7VdUhrvGQFYHcClJgP = []
		for D8jZSO4q95ecR in oenphG2AxK3HrFTUi4QcOV1MIRWBJE:
			if D8jZSO4q95ecR.isdigit(): D8jZSO4q95ecR = int(D8jZSO4q95ecR)
			IB7VdUhrvGQFYHcClJgP.append(D8jZSO4q95ecR)
		hckXvV3lPnTFam.append(IB7VdUhrvGQFYHcClJgP)
	return hckXvV3lPnTFam
def GzK87yQ59q3hbkjlRUI2ntu(hckXvV3lPnTFam):
	rPEjyAWGKqbde2DF = qpFY4hAwolV3
	for wpPIyaVkiGK in hckXvV3lPnTFam:
		for D8jZSO4q95ecR in wpPIyaVkiGK: rPEjyAWGKqbde2DF += str(D8jZSO4q95ecR)
		rPEjyAWGKqbde2DF += ddiCzu6yahj5RtTISMJ48sNnZBU(u"ࠫ࠳࠭ኪ")
	rPEjyAWGKqbde2DF = rPEjyAWGKqbde2DF.strip(c2RKu0xG1eC8MiohyE(u"ࠬ࠴ࠧካ"))
	return rPEjyAWGKqbde2DF
def yJOhc6G7ier1Fj2pzA(RbU35LjaHTM2Gy7YkwA0):
	jNmfig0xKqC3MFIrQt6 = {}
	LZOeqjR7iTry9581XKBMfab0 = yrAu3CSUkLp7dN2DYl()
	w2bZR5AvG4ycgEz1BUfSNLiHxn9 = fitmbL0nNUGKqpgV2(RbU35LjaHTM2Gy7YkwA0)
	for xqJBEohLpFs in RbU35LjaHTM2Gy7YkwA0:
		if xqJBEohLpFs not in list(LZOeqjR7iTry9581XKBMfab0.keys()): continue
		um0KEad67PwTyUOM3Qf = LZOeqjR7iTry9581XKBMfab0[xqJBEohLpFs]
		ddGithIMzBpkfPx67,d7tOFAycUTp,diRE2cprJLWKwY0Bku8xS7CaVh6DI = um0KEad67PwTyUOM3Qf[vvXoMLlg513]
		C4jGlOfiq6w,vjc0VWYzlITUufJ9X = abo14QhCiY9rVELdxGJy0tHwecKzBu(xqJBEohLpFs)
		JsQLOy631x,g978XsaeAohL = w2bZR5AvG4ycgEz1BUfSNLiHxn9[xqJBEohLpFs]
		GEQIKalfkvZAJ5F = d7tOFAycUTp>vjc0VWYzlITUufJ9X and JsQLOy631x
		UQoBYWuIxVM7894F6SsXn1ZfvAjG = gBExoceumj4y8bFW9hY2aNMVSr
		if not JsQLOy631x: SAVY85cF9a3 = BRWqdruz2A0(u"࠭࡭ࡪࡵࡶ࡭ࡳ࡭ࠧኬ")
		elif not g978XsaeAohL: SAVY85cF9a3 = qqzwE6imYG4c2xojI(u"ࠧࡥ࡫ࡶࡥࡧࡲࡥࡥࠩክ")
		elif GEQIKalfkvZAJ5F: SAVY85cF9a3 = lljaEqwTVtmKsQcOrbXxS5hgNH(u"ࠨࡱ࡯ࡨࠬኮ")
		else:
			SAVY85cF9a3 = RlOvin8YIGC2KZXJPk9m0acrMobUex(u"ࠩࡪࡳࡴࡪࠧኯ")
			UQoBYWuIxVM7894F6SsXn1ZfvAjG = ag8rjZo1Vz4IPdcOT
		jNmfig0xKqC3MFIrQt6[xqJBEohLpFs] = UQoBYWuIxVM7894F6SsXn1ZfvAjG,C4jGlOfiq6w,vjc0VWYzlITUufJ9X,ddGithIMzBpkfPx67,d7tOFAycUTp,SAVY85cF9a3,diRE2cprJLWKwY0Bku8xS7CaVh6DI
	return jNmfig0xKqC3MFIrQt6
def fgVlCuI8wy0znKvp1E5oj9xmD(r2reEIBPDyxK5u3RhFq,KGN8SbaxJc4,cPrEAvQVKHGljNfW6gCIpqh=qpFY4hAwolV3,yyu2iZgGlqYPm1K5=qpFY4hAwolV3,cM4lji9wCeYWTkpu5=qpFY4hAwolV3):
	if NJwViHDTMdmO0xnALqQ9voPalC3Ip: r2reEIBPDyxK5u3RhFq.update(KGN8SbaxJc4,cPrEAvQVKHGljNfW6gCIpqh,yyu2iZgGlqYPm1K5,cM4lji9wCeYWTkpu5)
	else: r2reEIBPDyxK5u3RhFq.update(KGN8SbaxJc4,cPrEAvQVKHGljNfW6gCIpqh+ZLwoRpfnCWI7FgEHsz6te39lMVh+yyu2iZgGlqYPm1K5+ZLwoRpfnCWI7FgEHsz6te39lMVh+cM4lji9wCeYWTkpu5)
	return
def LWOs8GxTnm4Q(mmPCYfgaThLQ6ukiWSd4bBAo):
	def oHy5nl2wOchCE(BYwOcSflHkKmxaFrGPuV8CRJ,WH8njriXB9oRIZmVKbvPJx,XMHV6DwGJ3Y5nqQ0OCfdA18gpz=sjtU6GZQg5XC2pH4(u"ࠥ࠴࠶࠸࠳࠵࠷࠹࠻࠽࠿ࡡࡣࡥࡧࡩ࡫࡭ࡨࡪ࡬࡮ࡰࡲࡴ࡯ࡱࡳࡵࡷࡹࡻࡶࡸࡺࡼࡾࡆࡈࡃࡅࡇࡉࡋࡍࡏࡊࡌࡎࡐࡒࡔࡖࡑࡓࡕࡗ࡙࡛࡝ࡘ࡚࡜ࠥኰ")):
		return ((BYwOcSflHkKmxaFrGPuV8CRJ == vvXoMLlg513) and XMHV6DwGJ3Y5nqQ0OCfdA18gpz[vvXoMLlg513]) or (oHy5nl2wOchCE(BYwOcSflHkKmxaFrGPuV8CRJ // WH8njriXB9oRIZmVKbvPJx, WH8njriXB9oRIZmVKbvPJx, XMHV6DwGJ3Y5nqQ0OCfdA18gpz).lstrip(XMHV6DwGJ3Y5nqQ0OCfdA18gpz[vvXoMLlg513]) + XMHV6DwGJ3Y5nqQ0OCfdA18gpz[BYwOcSflHkKmxaFrGPuV8CRJ % WH8njriXB9oRIZmVKbvPJx])
	def BWT8IVFK3ubN(TTyWUDFHiMJd7, U6UELYIMPuNj8xo9pBWS7vQa5Vgdq, ttx1HCgfUFWSa, Vfpa3KcQtx5RLho7, PPSqUiV6axz4AlsKNj=H1k0Fmba4Gfiynp8AML, ACk6yMhiJQYudeP=H1k0Fmba4Gfiynp8AML, iiXq4H1aQ8nwFeIjxN6KR0uCbkpPSM=H1k0Fmba4Gfiynp8AML):
		while (ttx1HCgfUFWSa):
			ttx1HCgfUFWSa-=dJHDqiKf12TXlIzSLkGUuxg4MBs3A(u"࠷ᜓ")
			if (Vfpa3KcQtx5RLho7[ttx1HCgfUFWSa]): TTyWUDFHiMJd7 = ePhmG1jLD6.sub(c2RKu0xG1eC8MiohyE(u"ࠦࡡࡢࡢࠣ኱") + oHy5nl2wOchCE(ttx1HCgfUFWSa, U6UELYIMPuNj8xo9pBWS7vQa5Vgdq) + lljaEqwTVtmKsQcOrbXxS5hgNH(u"ࠧࡢ࡜ࡣࠤኲ"),  Vfpa3KcQtx5RLho7[ttx1HCgfUFWSa], TTyWUDFHiMJd7)
		return TTyWUDFHiMJd7
	mmPCYfgaThLQ6ukiWSd4bBAo = mmPCYfgaThLQ6ukiWSd4bBAo.split(dJHDqiKf12TXlIzSLkGUuxg4MBs3A(u"࠭ࡽࠩࠩኳ"))[mZi0S72jGoHpLO]
	mmPCYfgaThLQ6ukiWSd4bBAo = mmPCYfgaThLQ6ukiWSd4bBAo.rsplit(RlOvin8YIGC2KZXJPk9m0acrMobUex(u"ࠧࡴࡲ࡯࡭ࡹ࠭ኴ"))[vvXoMLlg513]+tQMjXKCA5dN4xq3beVIzaEoWkFLg(u"ࠣࡵࡳࡰ࡮ࡺࠨࠨࡾࠪ࠭࠮ࠨኵ")
	Z7bKFTJzi6X = eval(YY8UDX3MJhb91AHw7fg(u"ࠩࡸࡲࡵࡧࡣ࡬ࠪࠪ኶")+mmPCYfgaThLQ6ukiWSd4bBAo,{RlOvin8YIGC2KZXJPk9m0acrMobUex(u"ࠪࡦࡦࡹࡥࡏࠩ኷"):oHy5nl2wOchCE,YY8UDX3MJhb91AHw7fg(u"ࠫࡺࡴࡰࡢࡥ࡮ࠫኸ"):BWT8IVFK3ubN})
	return Z7bKFTJzi6X
def Qa1IZtDiYvT8Cwl(code):
	_dlqhwuBZbWQ74PHs1Vf=qqzwE6imYG4c2xojI(u"ࠧ࠶࠱࠳࠵࠷࠹࠻࠽࠸࠺ࡣࡥࡧࡩ࡫ࡦࡨࡪ࡬࡮ࡰࡲ࡭࡯ࡱࡳࡵࡷࡹࡴࡶࡸࡺࡼࡾࢀࡁࡃࡅࡇࡉࡋࡍࡈࡊࡌࡎࡐࡒࡔࡏࡑࡓࡕࡗ࡙࡛ࡖࡘ࡚࡜࡞࠰࠵ࠢኹ")
	def aUX6rkTfMBvzge(ACk6yMhiJQYudeP,PPSqUiV6axz4AlsKNj,oD2xzkMHLt1vjuJSU6lTVBc7w):
		Dnt2MFh957 = list(_dlqhwuBZbWQ74PHs1Vf)
		udqnCKFLkmVT2jZzQgeUPfN = Dnt2MFh957[IaBhDMJc17302LgSvyxd(u"࠰᜔"):PPSqUiV6axz4AlsKNj]
		a2jQ83ZCfcM5 = Dnt2MFh957[tR1krDGPpO025fghMT3a7UnYj(u"࠱᜕"):oD2xzkMHLt1vjuJSU6lTVBc7w]
		ACk6yMhiJQYudeP = list(ACk6yMhiJQYudeP)[::-l1DZAt9XNQjqE7YOdrz(u"࠳᜖")]
		eoNEQ9AB71YHk8bGaIPy2 = l32dnTEOU1skGKqeBtI9hmo(u"࠳᜗")
		for ttx1HCgfUFWSa,WH8njriXB9oRIZmVKbvPJx in enumerate(ACk6yMhiJQYudeP):
			if WH8njriXB9oRIZmVKbvPJx in udqnCKFLkmVT2jZzQgeUPfN: eoNEQ9AB71YHk8bGaIPy2 = eoNEQ9AB71YHk8bGaIPy2 + udqnCKFLkmVT2jZzQgeUPfN.index(WH8njriXB9oRIZmVKbvPJx)*PPSqUiV6axz4AlsKNj**ttx1HCgfUFWSa
		Vfpa3KcQtx5RLho7 = l32dnTEOU1skGKqeBtI9hmo(u"ࠨࠢኺ")
		while eoNEQ9AB71YHk8bGaIPy2 > tQMjXKCA5dN4xq3beVIzaEoWkFLg(u"࠴᜘"):
			Vfpa3KcQtx5RLho7 = a2jQ83ZCfcM5[eoNEQ9AB71YHk8bGaIPy2%oD2xzkMHLt1vjuJSU6lTVBc7w] + Vfpa3KcQtx5RLho7
			eoNEQ9AB71YHk8bGaIPy2 = (eoNEQ9AB71YHk8bGaIPy2 - (eoNEQ9AB71YHk8bGaIPy2%oD2xzkMHLt1vjuJSU6lTVBc7w))//oD2xzkMHLt1vjuJSU6lTVBc7w
		return int(Vfpa3KcQtx5RLho7) or CC1eY6yWZUwf2TkRvnp7EJ0AimjHBX(u"࠵᜙")
	def HuatM2LmeUn(udqnCKFLkmVT2jZzQgeUPfN,u,WbXGhZL104ictIjHlaAkD6mNT5FUw,EwBs57aP3ugzLU,PPSqUiV6axz4AlsKNj,iiXq4H1aQ8nwFeIjxN6KR0uCbkpPSM):
		iiXq4H1aQ8nwFeIjxN6KR0uCbkpPSM = RlOvin8YIGC2KZXJPk9m0acrMobUex(u"ࠢࠣኻ");
		a2jQ83ZCfcM5 = tR1krDGPpO025fghMT3a7UnYj(u"࠶᜚")
		while a2jQ83ZCfcM5 < len(udqnCKFLkmVT2jZzQgeUPfN):
			eoNEQ9AB71YHk8bGaIPy2 = rNdBKI74fAklnoCZ6(u"࠰᜛")
			fK4nwmr0M2X5Uy7euZv8RIEFVA = LZWMikPEB81KSGyxfJtUsCA(u"ࠣࠤኼ")
			while udqnCKFLkmVT2jZzQgeUPfN[a2jQ83ZCfcM5] is not WbXGhZL104ictIjHlaAkD6mNT5FUw[PPSqUiV6axz4AlsKNj]:
				fK4nwmr0M2X5Uy7euZv8RIEFVA = qpFY4hAwolV3.join([fK4nwmr0M2X5Uy7euZv8RIEFVA,udqnCKFLkmVT2jZzQgeUPfN[a2jQ83ZCfcM5]])
				a2jQ83ZCfcM5 = a2jQ83ZCfcM5 + lljaEqwTVtmKsQcOrbXxS5hgNH(u"࠲᜜")
			while eoNEQ9AB71YHk8bGaIPy2 < len(WbXGhZL104ictIjHlaAkD6mNT5FUw):
				fK4nwmr0M2X5Uy7euZv8RIEFVA = fK4nwmr0M2X5Uy7euZv8RIEFVA.replace(WbXGhZL104ictIjHlaAkD6mNT5FUw[eoNEQ9AB71YHk8bGaIPy2],str(eoNEQ9AB71YHk8bGaIPy2))
				eoNEQ9AB71YHk8bGaIPy2 = eoNEQ9AB71YHk8bGaIPy2 + Ie5s2cBtSfdHjzQ4rA9kYlo6D18(u"࠳᜝")
			iiXq4H1aQ8nwFeIjxN6KR0uCbkpPSM = qpFY4hAwolV3.join([iiXq4H1aQ8nwFeIjxN6KR0uCbkpPSM,qpFY4hAwolV3.join(map(chr, [aUX6rkTfMBvzge(fK4nwmr0M2X5Uy7euZv8RIEFVA,PPSqUiV6axz4AlsKNj,rNdBKI74fAklnoCZ6(u"࠴࠴᜞")) - EwBs57aP3ugzLU]))])
			a2jQ83ZCfcM5 = a2jQ83ZCfcM5 + RlOvin8YIGC2KZXJPk9m0acrMobUex(u"࠵ᜟ")
		return iiXq4H1aQ8nwFeIjxN6KR0uCbkpPSM
	code = code.replace(fWoVd0Bmtkx(u"ࠩ࡟ࡲࠬኽ"),qpFY4hAwolV3).replace(fWoVd0Bmtkx(u"ࠪࡠࡷ࠭ኾ"),qpFY4hAwolV3)
	T08AQSVwjr9JtNpW = ePhmG1jLD6.findall(RlOvin8YIGC2KZXJPk9m0acrMobUex(u"ࠫࡡࢃ࡜ࠩࠤࠫࡠࡼ࠱ࠩࠣ࠮ࠫࡠࡩ࠱ࠩ࠭ࠤࠫࡠࡼ࠱ࠩࠣ࠮ࠫࡠࡩ࠱ࠩ࠭ࠪ࡟ࡨ࠰࠯ࠬࠩ࡞ࡧ࠯࠮ࡢࠩ࡝ࠫࠪ኿"),code,ePhmG1jLD6.DOTALL)
	if T08AQSVwjr9JtNpW:
		T08AQSVwjr9JtNpW = list(T08AQSVwjr9JtNpW[rNdBKI74fAklnoCZ6(u"࠵ᜠ")])
		for VVQasMJ1fkgtZE4r,code in enumerate(T08AQSVwjr9JtNpW):
			if code.isdigit(): T08AQSVwjr9JtNpW[VVQasMJ1fkgtZE4r] = int(code)
			else: T08AQSVwjr9JtNpW[VVQasMJ1fkgtZE4r] = code.replace(aXqWLoTdVgME(u"ࠬࡢࠢࠨዀ"),qpFY4hAwolV3)
		SI0z4XkqDfBbVYi8HAov1Wgh = HuatM2LmeUn(*T08AQSVwjr9JtNpW)
		return SI0z4XkqDfBbVYi8HAov1Wgh
	return qpFY4hAwolV3
def VfwvMXDtF07A4klEaHgUWhx3dCnO(Cm4xfTO625jyMtZ8GEpvuKcnbQ1gD,Ta4fdYVx5IbPAquJ1zRULit6nwp79=qpFY4hAwolV3):
	if Ta4fdYVx5IbPAquJ1zRULit6nwp79==qoBMmfAWpFlK70xw8ZRh4naJ(u"࠭࡬ࡰࡹࡨࡶࠬ዁"): Cm4xfTO625jyMtZ8GEpvuKcnbQ1gD = ePhmG1jLD6.sub(l32dnTEOU1skGKqeBtI9hmo(u"ࡲࠨࠧ࡞࠴࠲࠿ࡁ࠮࡜ࡠࡿ࠷ࢃࠧዂ"),lambda yvpg3klEoWiTdxBCtmhsGYR4N5M2Df: yvpg3klEoWiTdxBCtmhsGYR4N5M2Df.group(vvXoMLlg513).lower(),Cm4xfTO625jyMtZ8GEpvuKcnbQ1gD)
	elif Ta4fdYVx5IbPAquJ1zRULit6nwp79==LZWMikPEB81KSGyxfJtUsCA(u"ࠨࡷࡳࡴࡪࡸࠧዃ"): Cm4xfTO625jyMtZ8GEpvuKcnbQ1gD = ePhmG1jLD6.sub(tQMjXKCA5dN4xq3beVIzaEoWkFLg(u"ࡴࠪࠩࡠ࠶࠭࠺ࡣ࠰ࡾࡢࢁ࠲ࡾࠩዄ"),lambda yvpg3klEoWiTdxBCtmhsGYR4N5M2Df: yvpg3klEoWiTdxBCtmhsGYR4N5M2Df.group(vvXoMLlg513).upper(),Cm4xfTO625jyMtZ8GEpvuKcnbQ1gD)
	return Cm4xfTO625jyMtZ8GEpvuKcnbQ1gD
def fitmbL0nNUGKqpgV2(RbU35LjaHTM2Gy7YkwA0):
	plVU6JCOFxPLScjrGuAN,VwKqlTPdsG5jHpS16Br = ag8rjZo1Vz4IPdcOT,ag8rjZo1Vz4IPdcOT
	MkQL5RWVxPpz2mi63ADrt = IkS3LDtnyvAh2NaQU5p6P1KHZ.connect(Rb017YwecyPpEVQWAIu6HGhJ9k3tf)
	MkQL5RWVxPpz2mi63ADrt.text_factory = str
	EHQhicPzSdtkG = MkQL5RWVxPpz2mi63ADrt.cursor()
	if len(RbU35LjaHTM2Gy7YkwA0)==mZi0S72jGoHpLO: l8j1KeJzyvT = ddiCzu6yahj5RtTISMJ48sNnZBU(u"ࠪࠬࠧ࠭ዅ")+RbU35LjaHTM2Gy7YkwA0[vvXoMLlg513]+RlOvin8YIGC2KZXJPk9m0acrMobUex(u"ࠫࠧ࠯ࠧ዆")
	else: l8j1KeJzyvT = str(tuple(RbU35LjaHTM2Gy7YkwA0))
	EHQhicPzSdtkG.execute(viRJWOC5jsYe84(u"࡙ࠬࡅࡍࡇࡆࡘࠥࡧࡤࡥࡱࡱࡍࡉ࠲ࡥ࡯ࡣࡥࡰࡪࡪࠠࡇࡔࡒࡑࠥ࡯࡮ࡴࡶࡤࡰࡱ࡫ࡤ࡙ࠡࡋࡉࡗࡋࠠࡢࡦࡧࡳࡳࡏࡄࠡࡋࡑࠤࠬ዇")+l8j1KeJzyvT+Ie5s2cBtSfdHjzQ4rA9kYlo6D18(u"࠭ࠠ࠼ࠩወ"))
	sQviLuhq3tZyGbaJCI9dorR52cmg = EHQhicPzSdtkG.fetchall()
	MkQL5RWVxPpz2mi63ADrt.close()
	w2bZR5AvG4ycgEz1BUfSNLiHxn9 = {}
	for xqJBEohLpFs in RbU35LjaHTM2Gy7YkwA0: w2bZR5AvG4ycgEz1BUfSNLiHxn9[xqJBEohLpFs] = (ag8rjZo1Vz4IPdcOT,ag8rjZo1Vz4IPdcOT)
	for xqJBEohLpFs,VwKqlTPdsG5jHpS16Br in sQviLuhq3tZyGbaJCI9dorR52cmg:
		plVU6JCOFxPLScjrGuAN = gBExoceumj4y8bFW9hY2aNMVSr
		VwKqlTPdsG5jHpS16Br = VwKqlTPdsG5jHpS16Br==mZi0S72jGoHpLO
		w2bZR5AvG4ycgEz1BUfSNLiHxn9[xqJBEohLpFs] = (plVU6JCOFxPLScjrGuAN,VwKqlTPdsG5jHpS16Br)
	return w2bZR5AvG4ycgEz1BUfSNLiHxn9
def O8UnIZ9TiHSzXbvxGgs7wlR(xxaz1IN5QGdc):
	MOTjA5H9XFs = qpFY4hAwolV3
	if RPbaxsNFVTwek5Kfv21DiJuzCnjMZp.path.exists(xxaz1IN5QGdc):
		BdTIyXJb43x1g26YicFWC0sP = open(xxaz1IN5QGdc,qqzwE6imYG4c2xojI(u"ࠧࡳࡤࠪዉ")).read()
		if DLod2Of8CkRrtzJynev: BdTIyXJb43x1g26YicFWC0sP = BdTIyXJb43x1g26YicFWC0sP.decode(nV3Tip6XsH1rJw79DPOU)
		HoA19glnMejxGvpB = wB8NUAidPbqjIr9CFasXvYnxOQpL0g(aXqWLoTdVgME(u"ࠨࡦ࡬ࡧࡹ࠭ዊ"),BdTIyXJb43x1g26YicFWC0sP)
		if HoA19glnMejxGvpB:
			MOTjA5H9XFs = {}
			for ifG5zdxloK8j4RBOq in HoA19glnMejxGvpB.keys():
				MOTjA5H9XFs[ifG5zdxloK8j4RBOq] = []
				for bBvVusRn2O in HoA19glnMejxGvpB[ifG5zdxloK8j4RBOq]:
					kc8s5wJ4Px9zbiWQm,mJjTE9o7ecN8dt,Cm4xfTO625jyMtZ8GEpvuKcnbQ1gD,HNdWR8p36CtO,BvbuigUeoJLnTaN2qWxQ415AtYMK9I,i02wfPp5EM,Z4vQNwLcAiPVufj9sOgCMU6ezEWG,AArDKw6baWehCSOz7,uu5WqOEaRZIibszwTc6t1nmLfAj = qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3
					kc8s5wJ4Px9zbiWQm = bBvVusRn2O[vvXoMLlg513]
					mJjTE9o7ecN8dt = bBvVusRn2O[mZi0S72jGoHpLO]
					mJjTE9o7ecN8dt = VVGXPpMoc4bar0W(mJjTE9o7ecN8dt)
					Cm4xfTO625jyMtZ8GEpvuKcnbQ1gD = bBvVusRn2O[Zwqio2AIWlD5etFa]
					HNdWR8p36CtO = bBvVusRn2O[DAE6vkyhXGx1wBdHmcFfTVQpL0l]
					BvbuigUeoJLnTaN2qWxQ415AtYMK9I = bBvVusRn2O[wn4bG51vUENfaS0Zg]
					i02wfPp5EM = bBvVusRn2O[aXqWLoTdVgME(u"࠻ᜡ")]
					if len(bBvVusRn2O)>V3VlkhgjEF4n1erPXHcC0NOsfwyAJ(u"࠶ᜢ"): Z4vQNwLcAiPVufj9sOgCMU6ezEWG = bBvVusRn2O[V3VlkhgjEF4n1erPXHcC0NOsfwyAJ(u"࠶ᜢ")]
					if len(bBvVusRn2O)>YY8UDX3MJhb91AHw7fg(u"࠸ᜣ"): AArDKw6baWehCSOz7 = bBvVusRn2O[YY8UDX3MJhb91AHw7fg(u"࠸ᜣ")]
					if len(bBvVusRn2O)>YY8UDX3MJhb91AHw7fg(u"࠺ᜤ"): uu5WqOEaRZIibszwTc6t1nmLfAj = bBvVusRn2O[YY8UDX3MJhb91AHw7fg(u"࠺ᜤ")]
					if xxaz1IN5QGdc==V2JfszPWt6jq1hCxYKpyM53RL: JKB3STtiEWv7zMIgpHdxmOen = kc8s5wJ4Px9zbiWQm,mJjTE9o7ecN8dt,Cm4xfTO625jyMtZ8GEpvuKcnbQ1gD,HNdWR8p36CtO,BvbuigUeoJLnTaN2qWxQ415AtYMK9I,i02wfPp5EM,Z4vQNwLcAiPVufj9sOgCMU6ezEWG,qpFY4hAwolV3,uu5WqOEaRZIibszwTc6t1nmLfAj
					else: JKB3STtiEWv7zMIgpHdxmOen = kc8s5wJ4Px9zbiWQm,mJjTE9o7ecN8dt,Cm4xfTO625jyMtZ8GEpvuKcnbQ1gD,HNdWR8p36CtO,BvbuigUeoJLnTaN2qWxQ415AtYMK9I,i02wfPp5EM,Z4vQNwLcAiPVufj9sOgCMU6ezEWG,AArDKw6baWehCSOz7,uu5WqOEaRZIibszwTc6t1nmLfAj
					MOTjA5H9XFs[ifG5zdxloK8j4RBOq].append(JKB3STtiEWv7zMIgpHdxmOen)
		BAm6WyxJ0ahYvlcN4b1sUELPSru5Q = str(MOTjA5H9XFs)
		if DLod2Of8CkRrtzJynev: BAm6WyxJ0ahYvlcN4b1sUELPSru5Q = BAm6WyxJ0ahYvlcN4b1sUELPSru5Q.encode(nV3Tip6XsH1rJw79DPOU)
		open(xxaz1IN5QGdc,qqzwE6imYG4c2xojI(u"ࠩࡺࡦࠬዋ")).write(BAm6WyxJ0ahYvlcN4b1sUELPSru5Q)
	return MOTjA5H9XFs
def pPbuMH5hy6BSXzEaDGn(j7HgbsXoUDfzcSkmniPu9w6):
	S9lZt5DJXuUxhV = j7HgbsXoUDfzcSkmniPu9w6.split(V3VlkhgjEF4n1erPXHcC0NOsfwyAJ(u"ࠪ࠱ࠬዌ"),mZi0S72jGoHpLO)[vvXoMLlg513]
	qg4HsMCAcGWP7dZuv,bbieYx6KO2EHAmJj0G,TqMRtYCifVH46FuUgh = qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3
	if   S9lZt5DJXuUxhV==qoBMmfAWpFlK70xw8ZRh4naJ(u"ࠫࡆࡎࡗࡂࡍࠪው")		:	from OtBYd4KIrk			import nRVAZc4Dp8PSrGU3xBk as qg4HsMCAcGWP7dZuv,PPqUACSE3VcGLTvw05jHy9JrFNW as bbieYx6KO2EHAmJj0G,wwSFijdVJn1QgHW as TqMRtYCifVH46FuUgh
	elif S9lZt5DJXuUxhV==sjtU6GZQg5XC2pH4(u"ࠬࡇࡋࡐࡃࡐࠫዎ")		:	from xxWhjbPwqv			import nRVAZc4Dp8PSrGU3xBk as qg4HsMCAcGWP7dZuv,PPqUACSE3VcGLTvw05jHy9JrFNW as bbieYx6KO2EHAmJj0G,wwSFijdVJn1QgHW as TqMRtYCifVH46FuUgh
	elif S9lZt5DJXuUxhV==N3flV6EJsD5CzS(u"࠭ࡁࡌࡑࡄࡑࡈࡇࡍࠨዏ")	:	from RvtPA4JKkV		import nRVAZc4Dp8PSrGU3xBk as qg4HsMCAcGWP7dZuv,PPqUACSE3VcGLTvw05jHy9JrFNW as bbieYx6KO2EHAmJj0G,wwSFijdVJn1QgHW as TqMRtYCifVH46FuUgh
	elif S9lZt5DJXuUxhV==l1DZAt9XNQjqE7YOdrz(u"ࠧࡂࡍ࡚ࡅࡒ࠭ዐ")		:	from ZYG147KNkS			import nRVAZc4Dp8PSrGU3xBk as qg4HsMCAcGWP7dZuv,PPqUACSE3VcGLTvw05jHy9JrFNW as bbieYx6KO2EHAmJj0G,wwSFijdVJn1QgHW as TqMRtYCifVH46FuUgh
	elif S9lZt5DJXuUxhV==tR1krDGPpO025fghMT3a7UnYj(u"ࠨࡃࡎ࡛ࡆࡓࡔࡖࡄࡈࠫዑ")	:	from AzCpcjiUrZ		import nRVAZc4Dp8PSrGU3xBk as qg4HsMCAcGWP7dZuv,PPqUACSE3VcGLTvw05jHy9JrFNW as bbieYx6KO2EHAmJj0G,wwSFijdVJn1QgHW as TqMRtYCifVH46FuUgh
	elif S9lZt5DJXuUxhV==sjtU6GZQg5XC2pH4(u"ࠩࡄࡐࡆࡘࡁࡃࠩዒ")	:	from IS1UzJArVs			import nRVAZc4Dp8PSrGU3xBk as qg4HsMCAcGWP7dZuv,PPqUACSE3VcGLTvw05jHy9JrFNW as bbieYx6KO2EHAmJj0G,wwSFijdVJn1QgHW as TqMRtYCifVH46FuUgh
	elif S9lZt5DJXuUxhV==ddiCzu6yahj5RtTISMJ48sNnZBU(u"ࠪࡅࡑࡌࡁࡕࡋࡐࡍࠬዓ")	:	from JuNqR4HUjT		import nRVAZc4Dp8PSrGU3xBk as qg4HsMCAcGWP7dZuv,PPqUACSE3VcGLTvw05jHy9JrFNW as bbieYx6KO2EHAmJj0G,wwSFijdVJn1QgHW as TqMRtYCifVH46FuUgh
	elif S9lZt5DJXuUxhV==lljaEqwTVtmKsQcOrbXxS5hgNH(u"ࠫࡆࡒࡋࡂ࡙ࡗࡌࡆࡘࠧዔ")	: 	from z6lT2PChj7		import nRVAZc4Dp8PSrGU3xBk as qg4HsMCAcGWP7dZuv,PPqUACSE3VcGLTvw05jHy9JrFNW as bbieYx6KO2EHAmJj0G,wwSFijdVJn1QgHW as TqMRtYCifVH46FuUgh
	elif S9lZt5DJXuUxhV==DaFZHsThGmd0zv6e(u"ࠬࡇࡌࡎࡃࡄࡖࡊࡌࠧዕ")	:	from V4jcQUkEBs		import nRVAZc4Dp8PSrGU3xBk as qg4HsMCAcGWP7dZuv,PPqUACSE3VcGLTvw05jHy9JrFNW as bbieYx6KO2EHAmJj0G,wwSFijdVJn1QgHW as TqMRtYCifVH46FuUgh
	elif S9lZt5DJXuUxhV==CC1eY6yWZUwf2TkRvnp7EJ0AimjHBX(u"࠭ࡁࡍࡏࡖࡘࡇࡇࠧዖ")	:	from mhxtKgPoyO		import nRVAZc4Dp8PSrGU3xBk as qg4HsMCAcGWP7dZuv,PPqUACSE3VcGLTvw05jHy9JrFNW as bbieYx6KO2EHAmJj0G,wwSFijdVJn1QgHW as TqMRtYCifVH46FuUgh
	elif S9lZt5DJXuUxhV==V3VlkhgjEF4n1erPXHcC0NOsfwyAJ(u"ࠧࡂࡐࡌࡑࡊࡠࡉࡅࠩ዗")	:	from UHzRL6KvuJ		import nRVAZc4Dp8PSrGU3xBk as qg4HsMCAcGWP7dZuv,PPqUACSE3VcGLTvw05jHy9JrFNW as bbieYx6KO2EHAmJj0G,wwSFijdVJn1QgHW as TqMRtYCifVH46FuUgh
	elif S9lZt5DJXuUxhV==iNc3KxwErnQ(u"ࠨࡃࡕࡅࡇࡏࡃࡕࡑࡒࡒࡘ࠭ዘ"):	from GU6eESp45A	import nRVAZc4Dp8PSrGU3xBk as qg4HsMCAcGWP7dZuv,PPqUACSE3VcGLTvw05jHy9JrFNW as bbieYx6KO2EHAmJj0G,wwSFijdVJn1QgHW as TqMRtYCifVH46FuUgh
	elif S9lZt5DJXuUxhV==c2RKu0xG1eC8MiohyE(u"ࠩࡄࡖࡆࡈࡓࡆࡇࡇࠫዙ")	:	from OFCRZH8zGQ		import nRVAZc4Dp8PSrGU3xBk as qg4HsMCAcGWP7dZuv,PPqUACSE3VcGLTvw05jHy9JrFNW as bbieYx6KO2EHAmJj0G,wwSFijdVJn1QgHW as TqMRtYCifVH46FuUgh
	elif S9lZt5DJXuUxhV==DiJ8CMuYH1daWyjehfN0L(u"ࠪࡅ࡞ࡒࡏࡍࠩዚ")		:	from o3bRa1xY2A			import nRVAZc4Dp8PSrGU3xBk as qg4HsMCAcGWP7dZuv,PPqUACSE3VcGLTvw05jHy9JrFNW as bbieYx6KO2EHAmJj0G,wwSFijdVJn1QgHW as TqMRtYCifVH46FuUgh
	elif S9lZt5DJXuUxhV==YY8UDX3MJhb91AHw7fg(u"ࠫࡇࡕࡋࡓࡃࠪዛ")		:	from rU9MCQ2A1w			import nRVAZc4Dp8PSrGU3xBk as qg4HsMCAcGWP7dZuv,PPqUACSE3VcGLTvw05jHy9JrFNW as bbieYx6KO2EHAmJj0G,wwSFijdVJn1QgHW as TqMRtYCifVH46FuUgh
	elif S9lZt5DJXuUxhV==sjtU6GZQg5XC2pH4(u"ࠬࡈࡒࡔࡖࡈࡎࠬዜ")	:	from vZNjABEuf3			import nRVAZc4Dp8PSrGU3xBk as qg4HsMCAcGWP7dZuv,PPqUACSE3VcGLTvw05jHy9JrFNW as bbieYx6KO2EHAmJj0G,wwSFijdVJn1QgHW as TqMRtYCifVH46FuUgh
	elif S9lZt5DJXuUxhV==dJHDqiKf12TXlIzSLkGUuxg4MBs3A(u"࠭ࡃࡊࡏࡄ࠸࠵࠶ࠧዝ")	:	from PPSby7crhn		import nRVAZc4Dp8PSrGU3xBk as qg4HsMCAcGWP7dZuv,PPqUACSE3VcGLTvw05jHy9JrFNW as bbieYx6KO2EHAmJj0G,wwSFijdVJn1QgHW as TqMRtYCifVH46FuUgh
	elif S9lZt5DJXuUxhV==IaBhDMJc17302LgSvyxd(u"ࠧࡄࡋࡐࡅ࠹ࡖࠧዞ")	:	from lloO6s2Jpt			import nRVAZc4Dp8PSrGU3xBk as qg4HsMCAcGWP7dZuv,PPqUACSE3VcGLTvw05jHy9JrFNW as bbieYx6KO2EHAmJj0G,wwSFijdVJn1QgHW as TqMRtYCifVH46FuUgh
	elif S9lZt5DJXuUxhV==kYDaz79TFlXoR(u"ࠨࡅࡌࡑࡆ࠺ࡕࠨዟ")	:	from zEIOTk9PL2			import nRVAZc4Dp8PSrGU3xBk as qg4HsMCAcGWP7dZuv,PPqUACSE3VcGLTvw05jHy9JrFNW as bbieYx6KO2EHAmJj0G,wwSFijdVJn1QgHW as TqMRtYCifVH46FuUgh
	elif S9lZt5DJXuUxhV==Ie5s2cBtSfdHjzQ4rA9kYlo6D18(u"ࠩࡆࡍࡒࡇࡁࡃࡆࡒࠫዠ")	:	from T6epSdDnPH		import nRVAZc4Dp8PSrGU3xBk as qg4HsMCAcGWP7dZuv,PPqUACSE3VcGLTvw05jHy9JrFNW as bbieYx6KO2EHAmJj0G,wwSFijdVJn1QgHW as TqMRtYCifVH46FuUgh
	elif S9lZt5DJXuUxhV==CC1eY6yWZUwf2TkRvnp7EJ0AimjHBX(u"ࠪࡇࡎࡓࡁࡄࡎࡘࡆࠬዡ")	:	from lsGrFaNHxu		import nRVAZc4Dp8PSrGU3xBk as qg4HsMCAcGWP7dZuv,PPqUACSE3VcGLTvw05jHy9JrFNW as bbieYx6KO2EHAmJj0G,wwSFijdVJn1QgHW as TqMRtYCifVH46FuUgh
	elif S9lZt5DJXuUxhV==Ie5s2cBtSfdHjzQ4rA9kYlo6D18(u"ࠫࡈࡏࡍࡂࡅࡏ࡙ࡇ࡝ࡏࡓࡍࠪዢ"):	from hDfQiX2uMt	import nRVAZc4Dp8PSrGU3xBk as qg4HsMCAcGWP7dZuv,PPqUACSE3VcGLTvw05jHy9JrFNW as bbieYx6KO2EHAmJj0G,wwSFijdVJn1QgHW as TqMRtYCifVH46FuUgh
	elif S9lZt5DJXuUxhV==zYvEaigKWjoq50pXBLDbGJkFc(u"ࠬࡉࡉࡎࡃࡆࡐ࡚ࡖࠧዣ")	:	from UuSzT1wl7s		import nRVAZc4Dp8PSrGU3xBk as qg4HsMCAcGWP7dZuv,PPqUACSE3VcGLTvw05jHy9JrFNW as bbieYx6KO2EHAmJj0G,wwSFijdVJn1QgHW as TqMRtYCifVH46FuUgh
	elif S9lZt5DJXuUxhV==LZWMikPEB81KSGyxfJtUsCA(u"࠭ࡃࡊࡏࡄࡊࡆࡔࡓࠨዤ")	:	from W1KDUogqXG		import nRVAZc4Dp8PSrGU3xBk as qg4HsMCAcGWP7dZuv,PPqUACSE3VcGLTvw05jHy9JrFNW as bbieYx6KO2EHAmJj0G,wwSFijdVJn1QgHW as TqMRtYCifVH46FuUgh
	elif S9lZt5DJXuUxhV==CC1eY6yWZUwf2TkRvnp7EJ0AimjHBX(u"ࠧࡄࡋࡐࡅࡋࡘࡅࡆࠩዥ")	:	from DRPFcsXZM0		import nRVAZc4Dp8PSrGU3xBk as qg4HsMCAcGWP7dZuv,PPqUACSE3VcGLTvw05jHy9JrFNW as bbieYx6KO2EHAmJj0G,wwSFijdVJn1QgHW as TqMRtYCifVH46FuUgh
	elif S9lZt5DJXuUxhV==YY8UDX3MJhb91AHw7fg(u"ࠨࡅࡌࡑࡆࡒࡉࡈࡊࡗࠫዦ")	:	from mXsTNUKjiF		import nRVAZc4Dp8PSrGU3xBk as qg4HsMCAcGWP7dZuv,PPqUACSE3VcGLTvw05jHy9JrFNW as bbieYx6KO2EHAmJj0G,wwSFijdVJn1QgHW as TqMRtYCifVH46FuUgh
	elif S9lZt5DJXuUxhV==kYDaz79TFlXoR(u"ࠩࡆࡍࡒࡇࡎࡐ࡙ࠪዧ")	:	from GEcwD5QWl0		import nRVAZc4Dp8PSrGU3xBk as qg4HsMCAcGWP7dZuv,PPqUACSE3VcGLTvw05jHy9JrFNW as bbieYx6KO2EHAmJj0G,wwSFijdVJn1QgHW as TqMRtYCifVH46FuUgh
	elif S9lZt5DJXuUxhV==dJHDqiKf12TXlIzSLkGUuxg4MBs3A(u"ࠪࡇࡎࡓࡁࡘࡄࡄࡗࠬየ")	:	from A5Ew6nShiJ		import nRVAZc4Dp8PSrGU3xBk as qg4HsMCAcGWP7dZuv,PPqUACSE3VcGLTvw05jHy9JrFNW as bbieYx6KO2EHAmJj0G,wwSFijdVJn1QgHW as TqMRtYCifVH46FuUgh
	elif S9lZt5DJXuUxhV==rNdBKI74fAklnoCZ6(u"ࠫࡉࡇࡉࡍ࡛ࡐࡓ࡙ࡏࡏࡏࠩዩ"):	from hRJOTcPq9o	import nRVAZc4Dp8PSrGU3xBk as qg4HsMCAcGWP7dZuv,PPqUACSE3VcGLTvw05jHy9JrFNW as bbieYx6KO2EHAmJj0G,wwSFijdVJn1QgHW as TqMRtYCifVH46FuUgh
	elif S9lZt5DJXuUxhV==c2RKu0xG1eC8MiohyE(u"ࠬࡊࡒࡂࡏࡄࡇࡆࡌࡅࠨዪ")	:	from i0MwjxZb9s		import nRVAZc4Dp8PSrGU3xBk as qg4HsMCAcGWP7dZuv,PPqUACSE3VcGLTvw05jHy9JrFNW as bbieYx6KO2EHAmJj0G,wwSFijdVJn1QgHW as TqMRtYCifVH46FuUgh
	elif S9lZt5DJXuUxhV==DaFZHsThGmd0zv6e(u"࠭ࡄࡓࡃࡐࡅࡘ࠽ࠧያ")	:	from uWUvpiK2lj		import nRVAZc4Dp8PSrGU3xBk as qg4HsMCAcGWP7dZuv,PPqUACSE3VcGLTvw05jHy9JrFNW as bbieYx6KO2EHAmJj0G,wwSFijdVJn1QgHW as TqMRtYCifVH46FuUgh
	elif S9lZt5DJXuUxhV==lljaEqwTVtmKsQcOrbXxS5hgNH(u"ࠧࡆࡉ࡜ࡆࡊ࡙ࡔࠨዬ")	:	from tk48IHLusP		import nRVAZc4Dp8PSrGU3xBk as qg4HsMCAcGWP7dZuv,PPqUACSE3VcGLTvw05jHy9JrFNW as bbieYx6KO2EHAmJj0G,wwSFijdVJn1QgHW as TqMRtYCifVH46FuUgh
	elif S9lZt5DJXuUxhV==N3flV6EJsD5CzS(u"ࠨࡇࡊ࡝ࡇࡋࡓࡕ࠳ࠪይ")	:	from Q4WFjY5NDm		import nRVAZc4Dp8PSrGU3xBk as qg4HsMCAcGWP7dZuv,PPqUACSE3VcGLTvw05jHy9JrFNW as bbieYx6KO2EHAmJj0G,wwSFijdVJn1QgHW as TqMRtYCifVH46FuUgh
	elif S9lZt5DJXuUxhV==DaFZHsThGmd0zv6e(u"ࠩࡈࡋ࡞ࡈࡅࡔࡖ࠵ࠫዮ")	:	from wwl8rsGjdS		import nRVAZc4Dp8PSrGU3xBk as qg4HsMCAcGWP7dZuv,PPqUACSE3VcGLTvw05jHy9JrFNW as bbieYx6KO2EHAmJj0G,wwSFijdVJn1QgHW as TqMRtYCifVH46FuUgh
	elif S9lZt5DJXuUxhV==YY8UDX3MJhb91AHw7fg(u"ࠪࡉࡌ࡟ࡂࡆࡕࡗ࠷ࠬዯ")	:	from lm0RKJ9vHC		import nRVAZc4Dp8PSrGU3xBk as qg4HsMCAcGWP7dZuv,PPqUACSE3VcGLTvw05jHy9JrFNW as bbieYx6KO2EHAmJj0G,wwSFijdVJn1QgHW as TqMRtYCifVH46FuUgh
	elif S9lZt5DJXuUxhV==qqzwE6imYG4c2xojI(u"ࠫࡊࡍ࡙ࡃࡇࡖࡘ࠹࠭ደ")	:	from YC7kPDpyam		import nRVAZc4Dp8PSrGU3xBk as qg4HsMCAcGWP7dZuv,PPqUACSE3VcGLTvw05jHy9JrFNW as bbieYx6KO2EHAmJj0G,wwSFijdVJn1QgHW as TqMRtYCifVH46FuUgh
	elif S9lZt5DJXuUxhV==Ie5s2cBtSfdHjzQ4rA9kYlo6D18(u"ࠬࡋࡇ࡚ࡆࡈࡅࡉ࠭ዱ")	:	from recI4zpnXO		import nRVAZc4Dp8PSrGU3xBk as qg4HsMCAcGWP7dZuv,PPqUACSE3VcGLTvw05jHy9JrFNW as bbieYx6KO2EHAmJj0G,wwSFijdVJn1QgHW as TqMRtYCifVH46FuUgh
	elif S9lZt5DJXuUxhV==iNc3KxwErnQ(u"࠭ࡅࡈ࡛ࡑࡓ࡜࠭ዲ")	:	from mIvLlwT4ND			import nRVAZc4Dp8PSrGU3xBk as qg4HsMCAcGWP7dZuv,PPqUACSE3VcGLTvw05jHy9JrFNW as bbieYx6KO2EHAmJj0G,wwSFijdVJn1QgHW as TqMRtYCifVH46FuUgh
	elif S9lZt5DJXuUxhV==tQMjXKCA5dN4xq3beVIzaEoWkFLg(u"ࠧࡆࡎࡆࡍࡓࡋࡍࡂࠩዳ")	:	from fUGgAOP1cl		import nRVAZc4Dp8PSrGU3xBk as qg4HsMCAcGWP7dZuv,PPqUACSE3VcGLTvw05jHy9JrFNW as bbieYx6KO2EHAmJj0G,wwSFijdVJn1QgHW as TqMRtYCifVH46FuUgh
	elif S9lZt5DJXuUxhV==UVa3fJw7k6KM(u"ࠨࡇࡏࡍࡋ࡜ࡉࡅࡇࡒࠫዴ")	:	from XdmU7WYVIc		import nRVAZc4Dp8PSrGU3xBk as qg4HsMCAcGWP7dZuv,PPqUACSE3VcGLTvw05jHy9JrFNW as bbieYx6KO2EHAmJj0G,wwSFijdVJn1QgHW as TqMRtYCifVH46FuUgh
	elif S9lZt5DJXuUxhV==DaFZHsThGmd0zv6e(u"ࠩࡉࡅࡇࡘࡁࡌࡃࠪድ")	:	from OfAQ8sYkbu		import nRVAZc4Dp8PSrGU3xBk as qg4HsMCAcGWP7dZuv,PPqUACSE3VcGLTvw05jHy9JrFNW as bbieYx6KO2EHAmJj0G,wwSFijdVJn1QgHW as TqMRtYCifVH46FuUgh
	elif S9lZt5DJXuUxhV==dJHDqiKf12TXlIzSLkGUuxg4MBs3A(u"ࠪࡊࡆࡐࡅࡓࡕࡋࡓ࡜࠭ዶ")	:	from mqlgDyjXH5		import nRVAZc4Dp8PSrGU3xBk as qg4HsMCAcGWP7dZuv,PPqUACSE3VcGLTvw05jHy9JrFNW as bbieYx6KO2EHAmJj0G,wwSFijdVJn1QgHW as TqMRtYCifVH46FuUgh
	elif S9lZt5DJXuUxhV==zYvEaigKWjoq50pXBLDbGJkFc(u"ࠫࡋࡇࡒࡆࡕࡎࡓࠬዷ")	:	from K6db70xR5o		import nRVAZc4Dp8PSrGU3xBk as qg4HsMCAcGWP7dZuv,PPqUACSE3VcGLTvw05jHy9JrFNW as bbieYx6KO2EHAmJj0G,wwSFijdVJn1QgHW as TqMRtYCifVH46FuUgh
	elif S9lZt5DJXuUxhV==zYvEaigKWjoq50pXBLDbGJkFc(u"ࠬࡌࡁࡔࡇࡏࡌࡉ࠷ࠧዸ")	:	from KOaIVhJQtA		import nRVAZc4Dp8PSrGU3xBk as qg4HsMCAcGWP7dZuv,PPqUACSE3VcGLTvw05jHy9JrFNW as bbieYx6KO2EHAmJj0G,wwSFijdVJn1QgHW as TqMRtYCifVH46FuUgh
	elif S9lZt5DJXuUxhV==lljaEqwTVtmKsQcOrbXxS5hgNH(u"࠭ࡆࡂࡕࡈࡐࡍࡊ࠲ࠨዹ")	:	from gFYluaMXwk		import nRVAZc4Dp8PSrGU3xBk as qg4HsMCAcGWP7dZuv,PPqUACSE3VcGLTvw05jHy9JrFNW as bbieYx6KO2EHAmJj0G,wwSFijdVJn1QgHW as TqMRtYCifVH46FuUgh
	elif S9lZt5DJXuUxhV==DaFZHsThGmd0zv6e(u"ࠧࡇࡑࡖࡘࡆ࠭ዺ")		:	from rFP29NUYvk			import nRVAZc4Dp8PSrGU3xBk as qg4HsMCAcGWP7dZuv,PPqUACSE3VcGLTvw05jHy9JrFNW as bbieYx6KO2EHAmJj0G,wwSFijdVJn1QgHW as TqMRtYCifVH46FuUgh
	elif S9lZt5DJXuUxhV==l1DZAt9XNQjqE7YOdrz(u"ࠨࡈࡘࡒࡔࡔࡔࡗࠩዻ")	:	from A7ACsnjLFG		import nRVAZc4Dp8PSrGU3xBk as qg4HsMCAcGWP7dZuv,PPqUACSE3VcGLTvw05jHy9JrFNW as bbieYx6KO2EHAmJj0G,wwSFijdVJn1QgHW as TqMRtYCifVH46FuUgh
	elif S9lZt5DJXuUxhV==YY8UDX3MJhb91AHw7fg(u"ࠩࡉ࡙ࡘࡎࡁࡓࡖ࡙ࠫዼ")	:	from bjqifkrsRE		import nRVAZc4Dp8PSrGU3xBk as qg4HsMCAcGWP7dZuv,PPqUACSE3VcGLTvw05jHy9JrFNW as bbieYx6KO2EHAmJj0G,wwSFijdVJn1QgHW as TqMRtYCifVH46FuUgh
	elif S9lZt5DJXuUxhV==fWoVd0Bmtkx(u"ࠪࡊ࡚࡙ࡈࡂࡔ࡙ࡍࡉࡋࡏࠨዽ"):	from a6T9PrhJWH	import nRVAZc4Dp8PSrGU3xBk as qg4HsMCAcGWP7dZuv,PPqUACSE3VcGLTvw05jHy9JrFNW as bbieYx6KO2EHAmJj0G,wwSFijdVJn1QgHW as TqMRtYCifVH46FuUgh
	elif S9lZt5DJXuUxhV==ee86G9ladLHVbh5mikzCo(u"ࠫࡌࡕࡏࡈࡎࡈࡗࡊࡇࡒࡄࡊࠪዾ"):	from shfCoSUzMH	import nRVAZc4Dp8PSrGU3xBk as qg4HsMCAcGWP7dZuv,PPqUACSE3VcGLTvw05jHy9JrFNW as bbieYx6KO2EHAmJj0G,wwSFijdVJn1QgHW as TqMRtYCifVH46FuUgh
	elif S9lZt5DJXuUxhV==kYDaz79TFlXoR(u"ࠬࡎࡁࡍࡃࡆࡍࡒࡇࠧዿ")	:	from QQoAzBtT1w		import nRVAZc4Dp8PSrGU3xBk as qg4HsMCAcGWP7dZuv,PPqUACSE3VcGLTvw05jHy9JrFNW as bbieYx6KO2EHAmJj0G,wwSFijdVJn1QgHW as TqMRtYCifVH46FuUgh
	elif S9lZt5DJXuUxhV==qqzwE6imYG4c2xojI(u"࠭ࡉࡇࡋࡏࡑࠬጀ")		:	from McptVwrj8l			import nRVAZc4Dp8PSrGU3xBk as qg4HsMCAcGWP7dZuv,PPqUACSE3VcGLTvw05jHy9JrFNW as bbieYx6KO2EHAmJj0G,wwSFijdVJn1QgHW as TqMRtYCifVH46FuUgh
	elif S9lZt5DJXuUxhV==c2RKu0xG1eC8MiohyE(u"ࠧࡊࡒࡗ࡚ࠬጁ")		:	from kuHhyElsXe			import XwvsYGlxEn5dSNybeJkBcg9 as qg4HsMCAcGWP7dZuv,DpkVswXMr9iWB0OPAYqFNaK7 as bbieYx6KO2EHAmJj0G,KKxc2jv9sQZOpV as TqMRtYCifVH46FuUgh
	elif S9lZt5DJXuUxhV==DaFZHsThGmd0zv6e(u"ࠨࡍࡄࡖࡇࡇࡌࡂࡖ࡙ࠫጂ")	:	from KIQw2iNgDf		import nRVAZc4Dp8PSrGU3xBk as qg4HsMCAcGWP7dZuv,PPqUACSE3VcGLTvw05jHy9JrFNW as bbieYx6KO2EHAmJj0G,wwSFijdVJn1QgHW as TqMRtYCifVH46FuUgh
	elif S9lZt5DJXuUxhV==kYDaz79TFlXoR(u"ࠩࡎࡅ࡙ࡑࡏࡕࡖ࡙ࠫጃ")	:	from aax8bXLj6c		import nRVAZc4Dp8PSrGU3xBk as qg4HsMCAcGWP7dZuv,PPqUACSE3VcGLTvw05jHy9JrFNW as bbieYx6KO2EHAmJj0G,wwSFijdVJn1QgHW as TqMRtYCifVH46FuUgh
	elif S9lZt5DJXuUxhV==BRWqdruz2A0(u"ࠪࡏࡆ࡚ࡋࡐࡗࡗࡉࠬጄ")	:	from kT0n2StBoY		import nRVAZc4Dp8PSrGU3xBk as qg4HsMCAcGWP7dZuv,PPqUACSE3VcGLTvw05jHy9JrFNW as bbieYx6KO2EHAmJj0G,wwSFijdVJn1QgHW as TqMRtYCifVH46FuUgh
	elif S9lZt5DJXuUxhV==fWoVd0Bmtkx(u"ࠫࡐࡏࡒࡎࡃࡏࡏࠬጅ")	:	from Slc9IyMBe6		import nRVAZc4Dp8PSrGU3xBk as qg4HsMCAcGWP7dZuv,PPqUACSE3VcGLTvw05jHy9JrFNW as bbieYx6KO2EHAmJj0G,wwSFijdVJn1QgHW as TqMRtYCifVH46FuUgh
	elif S9lZt5DJXuUxhV==Ie5s2cBtSfdHjzQ4rA9kYlo6D18(u"ࠬࡒࡁࡓࡑ࡝ࡅࠬጆ")	:	from yyWscmJxY4			import nRVAZc4Dp8PSrGU3xBk as qg4HsMCAcGWP7dZuv,PPqUACSE3VcGLTvw05jHy9JrFNW as bbieYx6KO2EHAmJj0G,wwSFijdVJn1QgHW as TqMRtYCifVH46FuUgh
	elif S9lZt5DJXuUxhV==YY8UDX3MJhb91AHw7fg(u"࠭ࡌࡐࡆ࡜ࡒࡊ࡚ࠧጇ")	:	from uuwrCKXYpz		import nRVAZc4Dp8PSrGU3xBk as qg4HsMCAcGWP7dZuv,PPqUACSE3VcGLTvw05jHy9JrFNW as bbieYx6KO2EHAmJj0G,wwSFijdVJn1QgHW as TqMRtYCifVH46FuUgh
	elif S9lZt5DJXuUxhV==kYDaz79TFlXoR(u"ࠧࡎ࠵ࡘࠫገ")		:	from jV4SY0Trl2			import XwvsYGlxEn5dSNybeJkBcg9 as qg4HsMCAcGWP7dZuv,DpkVswXMr9iWB0OPAYqFNaK7 as bbieYx6KO2EHAmJj0G,KKxc2jv9sQZOpV as TqMRtYCifVH46FuUgh
	elif S9lZt5DJXuUxhV==DaFZHsThGmd0zv6e(u"ࠨࡏࡄࡗࡆ࡜ࡉࡅࡇࡒࠫጉ")	:	from K6FPQdxWgB		import nRVAZc4Dp8PSrGU3xBk as qg4HsMCAcGWP7dZuv,PPqUACSE3VcGLTvw05jHy9JrFNW as bbieYx6KO2EHAmJj0G,wwSFijdVJn1QgHW as TqMRtYCifVH46FuUgh
	elif S9lZt5DJXuUxhV==DiJ8CMuYH1daWyjehfN0L(u"ࠩࡐࡓ࡛࡙࠴ࡖࠩጊ")	:	from cLr9zZs1HC			import nRVAZc4Dp8PSrGU3xBk as qg4HsMCAcGWP7dZuv,PPqUACSE3VcGLTvw05jHy9JrFNW as bbieYx6KO2EHAmJj0G,wwSFijdVJn1QgHW as TqMRtYCifVH46FuUgh
	elif S9lZt5DJXuUxhV==UVa3fJw7k6KM(u"ࠪࡑ࡞ࡉࡉࡎࡃࠪጋ")	:	from axfhdK1XyV			import nRVAZc4Dp8PSrGU3xBk as qg4HsMCAcGWP7dZuv,PPqUACSE3VcGLTvw05jHy9JrFNW as bbieYx6KO2EHAmJj0G,wwSFijdVJn1QgHW as TqMRtYCifVH46FuUgh
	elif S9lZt5DJXuUxhV==l32dnTEOU1skGKqeBtI9hmo(u"ࠫࡕࡇࡎࡆࡖࠪጌ")		:	from UmxgvOQSan			import nRVAZc4Dp8PSrGU3xBk as qg4HsMCAcGWP7dZuv,PPqUACSE3VcGLTvw05jHy9JrFNW as bbieYx6KO2EHAmJj0G,wwSFijdVJn1QgHW as TqMRtYCifVH46FuUgh
	elif S9lZt5DJXuUxhV==YY8UDX3MJhb91AHw7fg(u"ࠬࡗࡆࡊࡎࡐࠫግ")		:	from iijrsYAfto			import nRVAZc4Dp8PSrGU3xBk as qg4HsMCAcGWP7dZuv,PPqUACSE3VcGLTvw05jHy9JrFNW as bbieYx6KO2EHAmJj0G,wwSFijdVJn1QgHW as TqMRtYCifVH46FuUgh
	elif S9lZt5DJXuUxhV==ddiCzu6yahj5RtTISMJ48sNnZBU(u"࠭ࡓࡆࡔࡌࡉࡘ࡚ࡉࡎࡇࠪጎ"):	from iiCM3WajhA		import nRVAZc4Dp8PSrGU3xBk as qg4HsMCAcGWP7dZuv,PPqUACSE3VcGLTvw05jHy9JrFNW as bbieYx6KO2EHAmJj0G,wwSFijdVJn1QgHW as TqMRtYCifVH46FuUgh
	elif S9lZt5DJXuUxhV==N3flV6EJsD5CzS(u"ࠧࡔࡊࡄࡆࡆࡑࡁࡕ࡛ࠪጏ")	:	from ackUbAD3Or		import nRVAZc4Dp8PSrGU3xBk as qg4HsMCAcGWP7dZuv,PPqUACSE3VcGLTvw05jHy9JrFNW as bbieYx6KO2EHAmJj0G,wwSFijdVJn1QgHW as TqMRtYCifVH46FuUgh
	elif S9lZt5DJXuUxhV==zYvEaigKWjoq50pXBLDbGJkFc(u"ࠨࡕࡋࡅࡍࡏࡄ࠵ࡗࠪጐ")	:	from HyqGsIehRp		import nRVAZc4Dp8PSrGU3xBk as qg4HsMCAcGWP7dZuv,PPqUACSE3VcGLTvw05jHy9JrFNW as bbieYx6KO2EHAmJj0G,wwSFijdVJn1QgHW as TqMRtYCifVH46FuUgh
	elif S9lZt5DJXuUxhV==V3VlkhgjEF4n1erPXHcC0NOsfwyAJ(u"ࠩࡖࡌࡆࡎࡉࡅ࠶ࡘ࠶ࠬ጑")	:	from GMTq7pNCtK		import nRVAZc4Dp8PSrGU3xBk as qg4HsMCAcGWP7dZuv,PPqUACSE3VcGLTvw05jHy9JrFNW as bbieYx6KO2EHAmJj0G,wwSFijdVJn1QgHW as TqMRtYCifVH46FuUgh
	elif S9lZt5DJXuUxhV==RlOvin8YIGC2KZXJPk9m0acrMobUex(u"ࠪࡗࡍࡇࡈࡊࡆࡑࡉ࡜࡙ࠧጒ"):	from PbQr4hXEsO		import nRVAZc4Dp8PSrGU3xBk as qg4HsMCAcGWP7dZuv,PPqUACSE3VcGLTvw05jHy9JrFNW as bbieYx6KO2EHAmJj0G,wwSFijdVJn1QgHW as TqMRtYCifVH46FuUgh
	elif S9lZt5DJXuUxhV==rNdBKI74fAklnoCZ6(u"ࠫࡘࡎࡉࡂࡘࡒࡍࡈࡋࠧጓ")	:	from xCeg5ad1vN		import nRVAZc4Dp8PSrGU3xBk as qg4HsMCAcGWP7dZuv,PPqUACSE3VcGLTvw05jHy9JrFNW as bbieYx6KO2EHAmJj0G,wwSFijdVJn1QgHW as TqMRtYCifVH46FuUgh
	elif S9lZt5DJXuUxhV==CC1eY6yWZUwf2TkRvnp7EJ0AimjHBX(u"࡙ࠬࡈࡐࡈࡋࡅࠬጔ")	:	from ggeDtZX4Vc			import nRVAZc4Dp8PSrGU3xBk as qg4HsMCAcGWP7dZuv,PPqUACSE3VcGLTvw05jHy9JrFNW as bbieYx6KO2EHAmJj0G,wwSFijdVJn1QgHW as TqMRtYCifVH46FuUgh
	elif S9lZt5DJXuUxhV==tR1krDGPpO025fghMT3a7UnYj(u"࠭ࡓࡉࡑࡒࡊࡒࡇࡘࠨጕ")	:	from b8TvJxqyHZ		import nRVAZc4Dp8PSrGU3xBk as qg4HsMCAcGWP7dZuv,PPqUACSE3VcGLTvw05jHy9JrFNW as bbieYx6KO2EHAmJj0G,wwSFijdVJn1QgHW as TqMRtYCifVH46FuUgh
	elif S9lZt5DJXuUxhV==YY8UDX3MJhb91AHw7fg(u"ࠧࡔࡊࡒࡓࡋࡔࡅࡕࠩ጖")	:	from VbkR49X8mn		import nRVAZc4Dp8PSrGU3xBk as qg4HsMCAcGWP7dZuv,PPqUACSE3VcGLTvw05jHy9JrFNW as bbieYx6KO2EHAmJj0G,wwSFijdVJn1QgHW as TqMRtYCifVH46FuUgh
	elif S9lZt5DJXuUxhV==mmV2nucZ5Lpl6FO1JMPEqGoQKW(u"ࠨࡕࡋࡓࡔࡌࡐࡓࡑࠪ጗")	:	from xHEoKLjI0e		import nRVAZc4Dp8PSrGU3xBk as qg4HsMCAcGWP7dZuv,PPqUACSE3VcGLTvw05jHy9JrFNW as bbieYx6KO2EHAmJj0G,wwSFijdVJn1QgHW as TqMRtYCifVH46FuUgh
	elif S9lZt5DJXuUxhV==ee86G9ladLHVbh5mikzCo(u"ࠩࡗࡍࡐࡇࡁࡕࠩጘ")	:	from sh4NPyruGZ			import nRVAZc4Dp8PSrGU3xBk as qg4HsMCAcGWP7dZuv,PPqUACSE3VcGLTvw05jHy9JrFNW as bbieYx6KO2EHAmJj0G,wwSFijdVJn1QgHW as TqMRtYCifVH46FuUgh
	elif S9lZt5DJXuUxhV==BRWqdruz2A0(u"ࠪࡘ࡛ࡌࡕࡏࠩጙ")		:	from ffEWLGI5yS			import nRVAZc4Dp8PSrGU3xBk as qg4HsMCAcGWP7dZuv,PPqUACSE3VcGLTvw05jHy9JrFNW as bbieYx6KO2EHAmJj0G,wwSFijdVJn1QgHW as TqMRtYCifVH46FuUgh
	elif S9lZt5DJXuUxhV==IaBhDMJc17302LgSvyxd(u"࡛ࠫࡇࡒࡃࡑࡑࠫጚ")	:	from tFlbeHvpBQ			import nRVAZc4Dp8PSrGU3xBk as qg4HsMCAcGWP7dZuv,PPqUACSE3VcGLTvw05jHy9JrFNW as bbieYx6KO2EHAmJj0G,wwSFijdVJn1QgHW as TqMRtYCifVH46FuUgh
	elif S9lZt5DJXuUxhV==lljaEqwTVtmKsQcOrbXxS5hgNH(u"ࠬ࡜ࡉࡅࡇࡒࡒࡘࡇࡅࡎࠩጛ"):	from PkWl2Edr8z		import nRVAZc4Dp8PSrGU3xBk as qg4HsMCAcGWP7dZuv,PPqUACSE3VcGLTvw05jHy9JrFNW as bbieYx6KO2EHAmJj0G,wwSFijdVJn1QgHW as TqMRtYCifVH46FuUgh
	elif S9lZt5DJXuUxhV==tR1krDGPpO025fghMT3a7UnYj(u"࠭ࡗࡆࡅࡌࡑࡆ࠷ࠧጜ")	:	from cS4xlQm7sC		import nRVAZc4Dp8PSrGU3xBk as qg4HsMCAcGWP7dZuv,PPqUACSE3VcGLTvw05jHy9JrFNW as bbieYx6KO2EHAmJj0G,wwSFijdVJn1QgHW as TqMRtYCifVH46FuUgh
	elif S9lZt5DJXuUxhV==RlOvin8YIGC2KZXJPk9m0acrMobUex(u"ࠧࡘࡇࡆࡍࡒࡇ࠲ࠨጝ")	:	from mLHFrjCxsb		import nRVAZc4Dp8PSrGU3xBk as qg4HsMCAcGWP7dZuv,PPqUACSE3VcGLTvw05jHy9JrFNW as bbieYx6KO2EHAmJj0G,wwSFijdVJn1QgHW as TqMRtYCifVH46FuUgh
	elif S9lZt5DJXuUxhV==rNdBKI74fAklnoCZ6(u"ࠨ࡛ࡄࡕࡔ࡚ࠧጞ")		:	from kWGISBadx1			import nRVAZc4Dp8PSrGU3xBk as qg4HsMCAcGWP7dZuv,PPqUACSE3VcGLTvw05jHy9JrFNW as bbieYx6KO2EHAmJj0G,wwSFijdVJn1QgHW as TqMRtYCifVH46FuUgh
	elif S9lZt5DJXuUxhV==lljaEqwTVtmKsQcOrbXxS5hgNH(u"ࠩ࡜ࡓ࡚࡚ࡕࡃࡇࠪጟ")	:	from jyIEpULGfx		import nRVAZc4Dp8PSrGU3xBk as qg4HsMCAcGWP7dZuv,PPqUACSE3VcGLTvw05jHy9JrFNW as bbieYx6KO2EHAmJj0G,wwSFijdVJn1QgHW as TqMRtYCifVH46FuUgh
	elif S9lZt5DJXuUxhV==sjtU6GZQg5XC2pH4(u"ࠪ࡝࡙ࡈ࡟ࡄࡊࡄࡒࡓࡋࡌࡔࠩጠ"):	from EDYAGbMZnr	import nRVAZc4Dp8PSrGU3xBk as qg4HsMCAcGWP7dZuv,PPqUACSE3VcGLTvw05jHy9JrFNW as bbieYx6KO2EHAmJj0G,wwSFijdVJn1QgHW as TqMRtYCifVH46FuUgh
	return qg4HsMCAcGWP7dZuv,bbieYx6KO2EHAmJj0G,TqMRtYCifVH46FuUgh
def OPCnG7Q8agh4wcdeZ(ECfw2Hev1rN,ppuvkQrgA1i8WwY3ftNJx7Ba9jH,showDialogs):
	LLvyStW429DEZKlA(k8kdUSxohLVljnrY,sjtU6GZQg5XC2pH4(u"ࠫ࠳ࡢࡴࡅࡱࡺࡲࡱࡵࡡࡥ࡫ࡱ࡫࠿࡛ࠦࠡࠩጡ")+DObEAlBf39(ECfw2Hev1rN)+DiJ8CMuYH1daWyjehfN0L(u"ࠬࠦ࡝ࠡࠢࠣࡌࡪࡧࡤࡦࡴࡶ࠾ࠥࡡࠠࠨጢ")+str(ppuvkQrgA1i8WwY3ftNJx7Ba9jH)+N3flV6EJsD5CzS(u"࠭ࠠ࡞ࠩጣ"))
	r2reEIBPDyxK5u3RhFq = W4HCP0bkSsNZlXp()
	r2reEIBPDyxK5u3RhFq.create(GLTtERWbHnFuy4PCp,rNdBKI74fAklnoCZ6(u"๋ࠧฮิ๎ࠥอไร่ࠣๅา฻ࠠศๆ่่ๆࠦวๅ็ฺ่ํฮࠠหฯ่๎้ํ้ࠠส฼ำ์อࠠิ๊ไࠤฯฮฯฤࠢ฼้้๐ษࠡฮ็ฬࠥอไๆๆไࠤ๊์ࠠศๆศ๊ฯืๆหࠩጤ"))
	aHgp7ChWjV32 = RlOvin8YIGC2KZXJPk9m0acrMobUex(u"࠴࠴࠷࠺ᜥ")*RlOvin8YIGC2KZXJPk9m0acrMobUex(u"࠴࠴࠷࠺ᜥ")
	SYfWTXHdL0umFrw = DiJ8CMuYH1daWyjehfN0L(u"࠵ᜦ")*aHgp7ChWjV32
	import requests as lFScPefz0pyYM7QrH41n6woV
	lgDZd7ip5Ux = lFScPefz0pyYM7QrH41n6woV.get(ECfw2Hev1rN,stream=gBExoceumj4y8bFW9hY2aNMVSr,headers=ppuvkQrgA1i8WwY3ftNJx7Ba9jH)
	QNjHuA73Z45lghL = lgDZd7ip5Ux.headers
	lgDZd7ip5Ux.close()
	Td0M9XyNGP2U6Kv87q5oLIZiDE = bytes()
	if not QNjHuA73Z45lghL:
		if showDialogs: iG7Rz2kmn0x1yLNMV3u8O(qpFY4hAwolV3,qpFY4hAwolV3,GLTtERWbHnFuy4PCp,kYDaz79TFlXoR(u"ࠨษ็ฬึ์วๆฮ่๊๊ࠣࠦห็ๆ๊๋ࠥๆࠡฬะ้๏๊ࠠศๆ่่ๆࠦวๅ็ฺ่ํฮ้ࠠษ็ือฮࠠใัࠣ๎่๎ๆࠡ฻้ำ่ࠦๅีๅ็อࠥ็๊ࠡษ็ษ๋ะั็ฬࠣห้ิวึࠢห็ࠥ࠴ࠠอำหࠤฯำๅ๋ๆࠣห้๋ไโ่ࠢีฮࠦรฯำ์ࠫጥ"))
		r2reEIBPDyxK5u3RhFq.close()
	else:
		if tR1krDGPpO025fghMT3a7UnYj(u"ࠩࡆࡳࡳࡺࡥ࡯ࡶ࠰ࡐࡪࡴࡧࡵࡪࠪጦ") not in list(QNjHuA73Z45lghL.keys()): nbdSlFM26tg0Ly9OEwWUcYsQGhNz = vvXoMLlg513
		else: nbdSlFM26tg0Ly9OEwWUcYsQGhNz = int(QNjHuA73Z45lghL[rNdBKI74fAklnoCZ6(u"ࠪࡇࡴࡴࡴࡦࡰࡷ࠱ࡑ࡫࡮ࡨࡶ࡫ࠫጧ")])
		KKahdkrjb61p4zJSytY = str(int(ddiCzu6yahj5RtTISMJ48sNnZBU(u"࠷࠰࠱࠲ᜨ")*nbdSlFM26tg0Ly9OEwWUcYsQGhNz/aHgp7ChWjV32)/RlOvin8YIGC2KZXJPk9m0acrMobUex(u"࠶࠶࠰࠱࠰࠳ᜧ"))
		qqZPRzobWCpDXUVQt6KkFg = int(nbdSlFM26tg0Ly9OEwWUcYsQGhNz/SYfWTXHdL0umFrw)+mZi0S72jGoHpLO
		if V3VlkhgjEF4n1erPXHcC0NOsfwyAJ(u"ࠫࡈࡵ࡮ࡵࡧࡱࡸ࠲ࡘࡡ࡯ࡩࡨࠫጨ") in list(QNjHuA73Z45lghL.keys()) and nbdSlFM26tg0Ly9OEwWUcYsQGhNz>aHgp7ChWjV32:
			k6kvwGyxUCpKzLVdSJMD7Eu = gBExoceumj4y8bFW9hY2aNMVSr
			zBa8lAR5kdmYGOET4QfnxJw36 = []
			jAp4Vsqme2OdNulWIG5atrnoQ = UVa3fJw7k6KM(u"࠱࠱ᜩ")
			zBa8lAR5kdmYGOET4QfnxJw36.append(str(vvXoMLlg513*nbdSlFM26tg0Ly9OEwWUcYsQGhNz//jAp4Vsqme2OdNulWIG5atrnoQ)+N3flV6EJsD5CzS(u"ࠬ࠳ࠧጩ")+str(mZi0S72jGoHpLO*nbdSlFM26tg0Ly9OEwWUcYsQGhNz//jAp4Vsqme2OdNulWIG5atrnoQ-mZi0S72jGoHpLO))
			zBa8lAR5kdmYGOET4QfnxJw36.append(str(mZi0S72jGoHpLO*nbdSlFM26tg0Ly9OEwWUcYsQGhNz//jAp4Vsqme2OdNulWIG5atrnoQ)+qqzwE6imYG4c2xojI(u"࠭࠭ࠨጪ")+str(Zwqio2AIWlD5etFa*nbdSlFM26tg0Ly9OEwWUcYsQGhNz//jAp4Vsqme2OdNulWIG5atrnoQ-mZi0S72jGoHpLO))
			zBa8lAR5kdmYGOET4QfnxJw36.append(str(Zwqio2AIWlD5etFa*nbdSlFM26tg0Ly9OEwWUcYsQGhNz//jAp4Vsqme2OdNulWIG5atrnoQ)+ddiCzu6yahj5RtTISMJ48sNnZBU(u"ࠧ࠮ࠩጫ")+str(DAE6vkyhXGx1wBdHmcFfTVQpL0l*nbdSlFM26tg0Ly9OEwWUcYsQGhNz//jAp4Vsqme2OdNulWIG5atrnoQ-mZi0S72jGoHpLO))
			zBa8lAR5kdmYGOET4QfnxJw36.append(str(DAE6vkyhXGx1wBdHmcFfTVQpL0l*nbdSlFM26tg0Ly9OEwWUcYsQGhNz//jAp4Vsqme2OdNulWIG5atrnoQ)+DiJ8CMuYH1daWyjehfN0L(u"ࠨ࠯ࠪጬ")+str(wn4bG51vUENfaS0Zg*nbdSlFM26tg0Ly9OEwWUcYsQGhNz//jAp4Vsqme2OdNulWIG5atrnoQ-mZi0S72jGoHpLO))
			zBa8lAR5kdmYGOET4QfnxJw36.append(str(wn4bG51vUENfaS0Zg*nbdSlFM26tg0Ly9OEwWUcYsQGhNz//jAp4Vsqme2OdNulWIG5atrnoQ)+YY8UDX3MJhb91AHw7fg(u"ࠩ࠰ࠫጭ")+str(zYvEaigKWjoq50pXBLDbGJkFc(u"࠶ᜪ")*nbdSlFM26tg0Ly9OEwWUcYsQGhNz//jAp4Vsqme2OdNulWIG5atrnoQ-mZi0S72jGoHpLO))
			zBa8lAR5kdmYGOET4QfnxJw36.append(str(iNc3KxwErnQ(u"࠷ᜫ")*nbdSlFM26tg0Ly9OEwWUcYsQGhNz//jAp4Vsqme2OdNulWIG5atrnoQ)+CC1eY6yWZUwf2TkRvnp7EJ0AimjHBX(u"ࠪ࠱ࠬጮ")+str(CC1eY6yWZUwf2TkRvnp7EJ0AimjHBX(u"࠹ᜬ")*nbdSlFM26tg0Ly9OEwWUcYsQGhNz//jAp4Vsqme2OdNulWIG5atrnoQ-mZi0S72jGoHpLO))
			zBa8lAR5kdmYGOET4QfnxJw36.append(str(DiJ8CMuYH1daWyjehfN0L(u"࠻ᜮ")*nbdSlFM26tg0Ly9OEwWUcYsQGhNz//jAp4Vsqme2OdNulWIG5atrnoQ)+Ie5s2cBtSfdHjzQ4rA9kYlo6D18(u"ࠫ࠲࠭ጯ")+str(N3flV6EJsD5CzS(u"࠻ᜭ")*nbdSlFM26tg0Ly9OEwWUcYsQGhNz//jAp4Vsqme2OdNulWIG5atrnoQ-mZi0S72jGoHpLO))
			zBa8lAR5kdmYGOET4QfnxJw36.append(str(N3flV6EJsD5CzS(u"࠷ᜰ")*nbdSlFM26tg0Ly9OEwWUcYsQGhNz//jAp4Vsqme2OdNulWIG5atrnoQ)+YY8UDX3MJhb91AHw7fg(u"ࠬ࠳ࠧጰ")+str(iNc3KxwErnQ(u"࠾ᜯ")*nbdSlFM26tg0Ly9OEwWUcYsQGhNz//jAp4Vsqme2OdNulWIG5atrnoQ-mZi0S72jGoHpLO))
			zBa8lAR5kdmYGOET4QfnxJw36.append(str(ee86G9ladLHVbh5mikzCo(u"࠺ᜲ")*nbdSlFM26tg0Ly9OEwWUcYsQGhNz//jAp4Vsqme2OdNulWIG5atrnoQ)+aXqWLoTdVgME(u"࠭࠭ࠨጱ")+str(BRWqdruz2A0(u"࠺ᜱ")*nbdSlFM26tg0Ly9OEwWUcYsQGhNz//jAp4Vsqme2OdNulWIG5atrnoQ-mZi0S72jGoHpLO))
			zBa8lAR5kdmYGOET4QfnxJw36.append(str(RlOvin8YIGC2KZXJPk9m0acrMobUex(u"࠼ᜳ")*nbdSlFM26tg0Ly9OEwWUcYsQGhNz//jAp4Vsqme2OdNulWIG5atrnoQ)+ddiCzu6yahj5RtTISMJ48sNnZBU(u"ࠧ࠮ࠩጲ"))
			QQK9PY58uLyUolAxTzJfe = float(qqZPRzobWCpDXUVQt6KkFg)/jAp4Vsqme2OdNulWIG5atrnoQ
			S6qBNWZh8L = QQK9PY58uLyUolAxTzJfe/int(mZi0S72jGoHpLO+QQK9PY58uLyUolAxTzJfe)
		else:
			k6kvwGyxUCpKzLVdSJMD7Eu = ag8rjZo1Vz4IPdcOT
			jAp4Vsqme2OdNulWIG5atrnoQ = mZi0S72jGoHpLO
			S6qBNWZh8L = mZi0S72jGoHpLO
		LLvyStW429DEZKlA(k8kdUSxohLVljnrY,UUDAiytEL76RTmMYsuIz5evXB(u"ࠨ࠰࡟ࡸࡉࡵࡷ࡯࡮ࡲࡥࡩࠦࡵࡴ࡫ࡱ࡫ࠥࡸࡡ࡯ࡩࡨࡷ࠿࡛ࠦࠡࠩጳ")+str(k6kvwGyxUCpKzLVdSJMD7Eu)+sjtU6GZQg5XC2pH4(u"ࠩࠣࡡࠥࠦࠠࡅࡱࡺࡲࡱࡵࡡࡥࠢࡶ࡭ࡿ࡫࠺ࠡ࡝ࠣࠫጴ")+str(nbdSlFM26tg0Ly9OEwWUcYsQGhNz)+viRJWOC5jsYe84(u"ࠪࠤࡢ࠭ጵ"))
		nnZ13Rr6tYXio0DyfLVvSxBec,yyUsuwpX84L = vvXoMLlg513,vvXoMLlg513
		for pvTMfBKPUC1i8nyz2w in range(jAp4Vsqme2OdNulWIG5atrnoQ):
			skD7g3FxW4wCa5BR = ppuvkQrgA1i8WwY3ftNJx7Ba9jH.copy()
			if k6kvwGyxUCpKzLVdSJMD7Eu: skD7g3FxW4wCa5BR[ddiCzu6yahj5RtTISMJ48sNnZBU(u"ࠫࡗࡧ࡮ࡨࡧࠪጶ")] = UUDAiytEL76RTmMYsuIz5evXB(u"ࠬࡨࡹࡵࡧࡶࡁࠬጷ")+zBa8lAR5kdmYGOET4QfnxJw36[pvTMfBKPUC1i8nyz2w]
			lgDZd7ip5Ux = lFScPefz0pyYM7QrH41n6woV.get(ECfw2Hev1rN,stream=gBExoceumj4y8bFW9hY2aNMVSr,headers=skD7g3FxW4wCa5BR,timeout=kYDaz79TFlXoR(u"࠷࠵࠶᜴"))
			for fuJUrT92qi0Gs6IlMdZ8EN in lgDZd7ip5Ux.iter_content(chunk_size=SYfWTXHdL0umFrw):
				if r2reEIBPDyxK5u3RhFq.iscanceled():
					LLvyStW429DEZKlA(k8kdUSxohLVljnrY,BRWqdruz2A0(u"࠭࠮࡝ࡶࡇࡳࡼࡴ࡬ࡰࡣࡧࠤࡈࡧ࡮ࡤࡧ࡯ࡩࡩ࠭ጸ"))
					break
				nnZ13Rr6tYXio0DyfLVvSxBec += S6qBNWZh8L
				Td0M9XyNGP2U6Kv87q5oLIZiDE += fuJUrT92qi0Gs6IlMdZ8EN
				if not yyUsuwpX84L: yyUsuwpX84L = len(fuJUrT92qi0Gs6IlMdZ8EN)
				if nbdSlFM26tg0Ly9OEwWUcYsQGhNz: fgVlCuI8wy0znKvp1E5oj9xmD(r2reEIBPDyxK5u3RhFq,iNc3KxwErnQ(u"࠶࠶࠰᜵")*nnZ13Rr6tYXio0DyfLVvSxBec//qqZPRzobWCpDXUVQt6KkFg,DaFZHsThGmd0zv6e(u"ࠧอๆหࠤฬ๊ๅๅใ࠽࠱ࠥอไอิฤࠤึ่ๅࠨጹ"),str(dJHDqiKf12TXlIzSLkGUuxg4MBs3A(u"࠷࠰࠱࠰࠳᜶")*yyUsuwpX84L*nnZ13Rr6tYXio0DyfLVvSxBec//SYfWTXHdL0umFrw//dJHDqiKf12TXlIzSLkGUuxg4MBs3A(u"࠷࠰࠱࠰࠳᜶"))+sjtU6GZQg5XC2pH4(u"ࠨࠢ࠲ࠤࠬጺ")+KKahdkrjb61p4zJSytY+BRWqdruz2A0(u"ࠩࠣࡑࡇ࠭ጻ"))
				else: fgVlCuI8wy0znKvp1E5oj9xmD(r2reEIBPDyxK5u3RhFq,yyUsuwpX84L*nnZ13Rr6tYXio0DyfLVvSxBec//SYfWTXHdL0umFrw,l1DZAt9XNQjqE7YOdrz(u"ࠪะ้ฮࠠศๆ่่ๆࡀ࠭ࠨጼ"),str(rNdBKI74fAklnoCZ6(u"࠱࠱࠲࠱࠴᜷")*yyUsuwpX84L*nnZ13Rr6tYXio0DyfLVvSxBec//SYfWTXHdL0umFrw//rNdBKI74fAklnoCZ6(u"࠱࠱࠲࠱࠴᜷"))+dJHDqiKf12TXlIzSLkGUuxg4MBs3A(u"ࠫࠥࡓࡂࠨጽ"))
			lgDZd7ip5Ux.close()
		r2reEIBPDyxK5u3RhFq.close()
		if len(Td0M9XyNGP2U6Kv87q5oLIZiDE)<nbdSlFM26tg0Ly9OEwWUcYsQGhNz and nbdSlFM26tg0Ly9OEwWUcYsQGhNz>vvXoMLlg513:
			LLvyStW429DEZKlA(k8kdUSxohLVljnrY,CC1eY6yWZUwf2TkRvnp7EJ0AimjHBX(u"ࠬ࠴࡜ࡵࡆࡲࡻࡳࡲ࡯ࡢࡦࠣࡪࡦ࡯࡬ࡦࡦࠣࡳࡷࠦࡣࡢࡰࡦࡩࡱ࡫ࡤࠡࡣࡷ࠾ࠥࡡࠠࠨጾ")+str(len(Td0M9XyNGP2U6Kv87q5oLIZiDE)//aHgp7ChWjV32)+l32dnTEOU1skGKqeBtI9hmo(u"࠭ࠠࡎࡄࠣࡡࠥࠦࠠࡇࡴࡲࡱࠥࡺ࡯ࡵࡣ࡯ࠤࡴ࡬࠺ࠡ࡝ࠣࠫጿ")+KKahdkrjb61p4zJSytY+LZWMikPEB81KSGyxfJtUsCA(u"ࠧࠡࡏࡅࠤࡢ࠭ፀ"))
			muaCBROQ72TixfPh683Y59qH = eVLmAIGFiwpr94UK6MRP5(qpFY4hAwolV3,N3flV6EJsD5CzS(u"ࠨว็฾ฬว้ࠠะิ์ั࠭ፁ"),fWoVd0Bmtkx(u"ࠩสืฯิฯศ็ࠣห้๋ไโࠢส่๋อโึࠩፂ"),YY8UDX3MJhb91AHw7fg(u"ࠪษ฾อฯสࠢฯ่อࠦวๅ็็ๅࠬፃ"),GLTtERWbHnFuy4PCp,c2RKu0xG1eC8MiohyE(u"ࠫๆฺไࠡใํࠤั๊ศࠡษ็้้็ࠠ࡝ࡰ่้ࠣษำโࠢะำะࠦฮุลࠣๅ๏ࠦสฮ็ํ่ࠥอไๆๆไࠤࡡࡴࠠห็ࠣะ้ฮࠠࠨፄ")+str(len(Td0M9XyNGP2U6Kv87q5oLIZiDE)//aHgp7ChWjV32)+l1DZAt9XNQjqE7YOdrz(u"ࠬࠦๅ๋฼สฬฬ๐สࠡ็้ࠤ๊าๅ้฻ࠣࠫፅ")+KKahdkrjb61p4zJSytY+V3VlkhgjEF4n1erPXHcC0NOsfwyAJ(u"࠭ࠠๆ์฽หออ๊หࠢ࡟ࡲࠥาัษࠢฯ่อࠦวๅ็็ๅ๋ࠥัสࠢฦาึ๏ࠠ࡝ࡰ๋้ࠣࠦสา์าࠤฬูสฯัส้ࠥอไๆๆไࠤฬ๊ๆศไุࠤฤࠧࠡࠨፆ"))
			if muaCBROQ72TixfPh683Y59qH==Zwqio2AIWlD5etFa: Td0M9XyNGP2U6Kv87q5oLIZiDE = OPCnG7Q8agh4wcdeZ(ECfw2Hev1rN,ppuvkQrgA1i8WwY3ftNJx7Ba9jH,showDialogs)
			elif muaCBROQ72TixfPh683Y59qH==mZi0S72jGoHpLO: LLvyStW429DEZKlA(k8kdUSxohLVljnrY,dJHDqiKf12TXlIzSLkGUuxg4MBs3A(u"ࠧ࠯࡞ࡷࡒࡴࡺࠠࡤࡱࡰࡴࡱ࡫ࡴࡦࡦࠣࡨࡴࡽ࡮࡭ࡱࡤࡨࡪࡪࠠࡧ࡫࡯ࡩࠥ࡯ࡳࠡࡣࡦࡧࡪࡶࡴࡦࡦࠣࡥࡳࡪࠠࡸ࡫࡯ࡰࠥࡨࡥࠡࡷࡶࡩࡩ࠭ፇ"))
			else: return qpFY4hAwolV3
			if not Td0M9XyNGP2U6Kv87q5oLIZiDE: return qpFY4hAwolV3
		else: LLvyStW429DEZKlA(k8kdUSxohLVljnrY,qqzwE6imYG4c2xojI(u"ࠨ࠰࡟ࡸࡉࡵࡷ࡯࡮ࡲࡥࡩࠦࡓࡶࡥࡦࡩࡪࡪࡥࡥ࠰ࠣࠤࠥࡌࡩ࡭ࡧࠣࡗ࡮ࢀࡥ࠻ࠢ࡞ࠤࠬፈ")+KKahdkrjb61p4zJSytY+DaFZHsThGmd0zv6e(u"ࠩࠣࡑࡇࠦ࡝ࠨፉ"))
	return Td0M9XyNGP2U6Kv87q5oLIZiDE
def RR4j15zMOweAC(Q8Q0IDc6PLZajJAdTntKUmSGXz):
	return lgDZd7ip5Ux
def bfLg2cN8FvsxWMeyj7q(sV5xU7W39QREjpOvGZMT1uKCdF=qpFY4hAwolV3):
	if i4bFG3rKE6.GEOLOCATION_DATA: return i4bFG3rKE6.GEOLOCATION_DATA
	S1XdEOuW7MzwcTKH4Inse8UBrbNx,F1KMGjNvHegbIJEs3fcOtwq,Er5Xg7Qy1AUHufTo0,EoK51V60OdsqchH,ZgAQUaz6nXs,YSw3Ap5hO1vcIF = qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3
	Cm4xfTO625jyMtZ8GEpvuKcnbQ1gD = kYDaz79TFlXoR(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࡭ࡵࡽࡨࡰ࠰࡬ࡷ࠴࠭ፊ")+sV5xU7W39QREjpOvGZMT1uKCdF+l1DZAt9XNQjqE7YOdrz(u"ࠫࡄࡵࡵࡵࡲࡸࡸࡂࡰࡳࡰࡰࠩࡪ࡮࡫࡬ࡥࡵࡀ࡭ࡵ࠲ࡣࡰࡰࡷ࡭ࡳ࡫࡮ࡵ࠮ࡦࡳࡺࡴࡴࡳࡻ࠯ࡧࡴࡻ࡮ࡵࡴࡼࡣࡨࡵࡤࡦ࠮ࡵࡩ࡬࡯࡯࡯࠮ࡦ࡭ࡹࡿࠬࡵ࡫ࡰࡩࡿࡵ࡮ࡦࠩፋ")
	ppuvkQrgA1i8WwY3ftNJx7Ba9jH = {qoBMmfAWpFlK70xw8ZRh4naJ(u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩፌ"):qpFY4hAwolV3}
	lgDZd7ip5Ux = WWrExJZS3Bj4anOAkpv7(rGY36xBwT1bLZAngSfcWEIeXdQVNij,DiJ8CMuYH1daWyjehfN0L(u"࠭ࡇࡆࡖࠪፍ"),Cm4xfTO625jyMtZ8GEpvuKcnbQ1gD,qpFY4hAwolV3,ppuvkQrgA1i8WwY3ftNJx7Ba9jH,qpFY4hAwolV3,qpFY4hAwolV3,DiJ8CMuYH1daWyjehfN0L(u"ࠧࡍࡋࡅࡖࡆࡘ࡙࠮ࡉࡈࡓࡑࡕࡃࡂࡖࡌࡓࡓ࠳࠱ࡴࡶࠪፎ"))
	if not lgDZd7ip5Ux.succeeded:
		Cm4xfTO625jyMtZ8GEpvuKcnbQ1gD = Ie5s2cBtSfdHjzQ4rA9kYlo6D18(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࡫ࡳ࠱ࡦࡶࡩ࠯ࡥࡲࡱ࠴ࡰࡳࡰࡰ࠲ࠫፏ")+sV5xU7W39QREjpOvGZMT1uKCdF+N3flV6EJsD5CzS(u"ࠩࡂࡪ࡮࡫࡬ࡥࡵࡀࡵࡺ࡫ࡲࡺ࠮ࡦࡳࡳࡺࡩ࡯ࡧࡱࡸ࠱ࡩ࡯ࡶࡰࡷࡶࡾ࠲ࡣࡰࡷࡱࡸࡷࡿࡃࡰࡦࡨ࠰ࡷ࡫ࡧࡪࡱࡱࡒࡦࡳࡥ࠭ࡥ࡬ࡸࡾ࠲࡯ࡧࡨࡶࡩࡹ࠭ፐ")
		lgDZd7ip5Ux = WWrExJZS3Bj4anOAkpv7(rGY36xBwT1bLZAngSfcWEIeXdQVNij,CC1eY6yWZUwf2TkRvnp7EJ0AimjHBX(u"ࠪࡋࡊ࡚ࠧፑ"),Cm4xfTO625jyMtZ8GEpvuKcnbQ1gD,qpFY4hAwolV3,ppuvkQrgA1i8WwY3ftNJx7Ba9jH,qpFY4hAwolV3,qpFY4hAwolV3,sjtU6GZQg5XC2pH4(u"ࠫࡑࡏࡂࡓࡃࡕ࡝࠲ࡍࡅࡐࡎࡒࡇࡆ࡚ࡉࡐࡐ࠰࠶ࡳࡪࠧፒ"))
	if lgDZd7ip5Ux.succeeded:
		cmWl9dOKHPIy41iaXuxrY = lgDZd7ip5Ux.content
		try: w3wo1C0XiTPyMDQtEjzGhOS = A3AFYmgZLXn4MBab.loads(cmWl9dOKHPIy41iaXuxrY)
		except: w3wo1C0XiTPyMDQtEjzGhOS = A3AFYmgZLXn4MBab.loads(cmWl9dOKHPIy41iaXuxrY.decode(tQMjXKCA5dN4xq3beVIzaEoWkFLg(u"ࠬࡻࡴࡧ࠯࠻࠱ࡸ࡯ࡧࠨፓ")))
		d76pOBH80GUf5r9 = list(w3wo1C0XiTPyMDQtEjzGhOS.keys())
		if viRJWOC5jsYe84(u"࠭ࡩࡱࠩፔ") in d76pOBH80GUf5r9: sV5xU7W39QREjpOvGZMT1uKCdF = w3wo1C0XiTPyMDQtEjzGhOS[rNdBKI74fAklnoCZ6(u"ࠧࡪࡲࠪፕ")]
		if lljaEqwTVtmKsQcOrbXxS5hgNH(u"ࠨࡥࡲࡲࡹ࡯࡮ࡦࡰࡷࠫፖ") in d76pOBH80GUf5r9: S1XdEOuW7MzwcTKH4Inse8UBrbNx = w3wo1C0XiTPyMDQtEjzGhOS[ddiCzu6yahj5RtTISMJ48sNnZBU(u"ࠩࡦࡳࡳࡺࡩ࡯ࡧࡱࡸࠬፗ")]
		if UVa3fJw7k6KM(u"ࠪࡧࡴࡻ࡮ࡵࡴࡼࠫፘ") in d76pOBH80GUf5r9: F1KMGjNvHegbIJEs3fcOtwq = w3wo1C0XiTPyMDQtEjzGhOS[V3VlkhgjEF4n1erPXHcC0NOsfwyAJ(u"ࠫࡨࡵࡵ࡯ࡶࡵࡽࠬፙ")]
		if BRWqdruz2A0(u"ࠬࡩ࡯ࡶࡰࡷࡶࡾࡥࡣࡰࡦࡨࠫፚ") in d76pOBH80GUf5r9: Er5Xg7Qy1AUHufTo0 = w3wo1C0XiTPyMDQtEjzGhOS[LZWMikPEB81KSGyxfJtUsCA(u"࠭ࡣࡰࡷࡱࡸࡷࡿ࡟ࡤࡱࡧࡩࠬ፛")]
		if RlOvin8YIGC2KZXJPk9m0acrMobUex(u"ࠧࡳࡧࡪ࡭ࡴࡴࠧ፜") in d76pOBH80GUf5r9: EoK51V60OdsqchH = w3wo1C0XiTPyMDQtEjzGhOS[l32dnTEOU1skGKqeBtI9hmo(u"ࠨࡴࡨ࡫࡮ࡵ࡮ࠨ፝")]
		if Ie5s2cBtSfdHjzQ4rA9kYlo6D18(u"ࠩࡦ࡭ࡹࡿࠧ፞") in d76pOBH80GUf5r9: ZgAQUaz6nXs = w3wo1C0XiTPyMDQtEjzGhOS[tQMjXKCA5dN4xq3beVIzaEoWkFLg(u"ࠪࡧ࡮ࡺࡹࠨ፟")]
		if IaBhDMJc17302LgSvyxd(u"ࠫࡶࡻࡥࡳࡻࠪ፠") in d76pOBH80GUf5r9: sV5xU7W39QREjpOvGZMT1uKCdF = w3wo1C0XiTPyMDQtEjzGhOS[UUDAiytEL76RTmMYsuIz5evXB(u"ࠬࡷࡵࡦࡴࡼࠫ፡")]
		if ddiCzu6yahj5RtTISMJ48sNnZBU(u"࠭ࡣࡰࡷࡱࡸࡷࡿࡃࡰࡦࡨࠫ።") in d76pOBH80GUf5r9: Er5Xg7Qy1AUHufTo0 = w3wo1C0XiTPyMDQtEjzGhOS[DaFZHsThGmd0zv6e(u"ࠧࡤࡱࡸࡲࡹࡸࡹࡄࡱࡧࡩࠬ፣")]
		if qoBMmfAWpFlK70xw8ZRh4naJ(u"ࠨࡴࡨ࡫࡮ࡵ࡮ࡏࡣࡰࡩࠬ፤") in d76pOBH80GUf5r9: EoK51V60OdsqchH = w3wo1C0XiTPyMDQtEjzGhOS[BRWqdruz2A0(u"ࠩࡵࡩ࡬࡯࡯࡯ࡐࡤࡱࡪ࠭፥")]
		if V3VlkhgjEF4n1erPXHcC0NOsfwyAJ(u"ࠪࡸ࡮ࡳࡥࡻࡱࡱࡩࠬ፦") in d76pOBH80GUf5r9:
			YSw3Ap5hO1vcIF = w3wo1C0XiTPyMDQtEjzGhOS[UUDAiytEL76RTmMYsuIz5evXB(u"ࠫࡹ࡯࡭ࡦࡼࡲࡲࡪ࠭፧")][BRWqdruz2A0(u"ࠬࡻࡴࡤࠩ፨")]
			if YSw3Ap5hO1vcIF[vvXoMLlg513] not in [YY8UDX3MJhb91AHw7fg(u"࠭࠭ࠨ፩"),viRJWOC5jsYe84(u"ࠧࠬࠩ፪")]: YSw3Ap5hO1vcIF = fWoVd0Bmtkx(u"ࠨ࠭ࠪ፫")+YSw3Ap5hO1vcIF
		if N3flV6EJsD5CzS(u"ࠩࡲࡪ࡫ࡹࡥࡵࠩ፬") in d76pOBH80GUf5r9:
			YSw3Ap5hO1vcIF = w3wo1C0XiTPyMDQtEjzGhOS[CC1eY6yWZUwf2TkRvnp7EJ0AimjHBX(u"ࠪࡳ࡫࡬ࡳࡦࡶࠪ፭")]
			if YSw3Ap5hO1vcIF>=ee86G9ladLHVbh5mikzCo(u"࠱᜸"): YSw3Ap5hO1vcIF = iNc3KxwErnQ(u"ࠫ࠰࠭፮")+s7FnXZYOgexlH2MPb8BJck1AKv9.strftime(DaFZHsThGmd0zv6e(u"ࠧࠫࡈ࠻ࠧࡐࠦ፯"),s7FnXZYOgexlH2MPb8BJck1AKv9.gmtime(YSw3Ap5hO1vcIF))
			else: YSw3Ap5hO1vcIF = YY8UDX3MJhb91AHw7fg(u"࠭࠭ࠨ፰")+s7FnXZYOgexlH2MPb8BJck1AKv9.strftime(sjtU6GZQg5XC2pH4(u"ࠢࠦࡊ࠽ࠩࡒࠨ፱"),s7FnXZYOgexlH2MPb8BJck1AKv9.gmtime(-YSw3Ap5hO1vcIF))
	LxjQvYkwrW6tUgNCoGTz0cup = sV5xU7W39QREjpOvGZMT1uKCdF+mmV2nucZ5Lpl6FO1JMPEqGoQKW(u"ࠨ࠮࠯ࠫ፲")+S1XdEOuW7MzwcTKH4Inse8UBrbNx+l1DZAt9XNQjqE7YOdrz(u"ࠩ࠯࠰ࠬ፳")+F1KMGjNvHegbIJEs3fcOtwq+CC1eY6yWZUwf2TkRvnp7EJ0AimjHBX(u"ࠪ࠰࠱࠭፴")+EoK51V60OdsqchH+kYDaz79TFlXoR(u"ࠫ࠱࠲ࠧ፵")+ZgAQUaz6nXs+iNc3KxwErnQ(u"ࠬ࠲ࠬࠨ፶")+YSw3Ap5hO1vcIF
	LxjQvYkwrW6tUgNCoGTz0cup = LxjQvYkwrW6tUgNCoGTz0cup.encode(nV3Tip6XsH1rJw79DPOU)
	if DLod2Of8CkRrtzJynev: LxjQvYkwrW6tUgNCoGTz0cup = LxjQvYkwrW6tUgNCoGTz0cup.decode(kYDaz79TFlXoR(u"࠭ࡵ࡯࡫ࡦࡳࡩ࡫࡟ࡦࡵࡦࡥࡵ࡫ࠧ፷"))
	i4bFG3rKE6.GEOLOCATION_DATA = N8E37XwL6iQbmBY(LxjQvYkwrW6tUgNCoGTz0cup)
	return i4bFG3rKE6.GEOLOCATION_DATA
def LLm3sBXHPcnTDxdE5gt6hz0Wkp(kINWQUyv5VMmAnwT):
	zS4AgJYX2QtHWZp1IriPRCV6w,showDialogs = qpFY4hAwolV3,gBExoceumj4y8bFW9hY2aNMVSr
	if kINWQUyv5VMmAnwT.count(zYvEaigKWjoq50pXBLDbGJkFc(u"ࠧࡠࠩ፸"))>=Zwqio2AIWlD5etFa:
		kINWQUyv5VMmAnwT,zS4AgJYX2QtHWZp1IriPRCV6w = kINWQUyv5VMmAnwT.split(l1DZAt9XNQjqE7YOdrz(u"ࠨࡡࠪ፹"),mZi0S72jGoHpLO)
		zS4AgJYX2QtHWZp1IriPRCV6w = LZWMikPEB81KSGyxfJtUsCA(u"ࠩࡢࠫ፺")+zS4AgJYX2QtHWZp1IriPRCV6w
		if CC1eY6yWZUwf2TkRvnp7EJ0AimjHBX(u"ࠪࡣࡓࡕࡄࡊࡃࡏࡓࡌ࡙࡟ࠨ፻") in zS4AgJYX2QtHWZp1IriPRCV6w: showDialogs = ag8rjZo1Vz4IPdcOT
		else: showDialogs = gBExoceumj4y8bFW9hY2aNMVSr
	return kINWQUyv5VMmAnwT,zS4AgJYX2QtHWZp1IriPRCV6w,showDialogs
def j06rHnAtPByzqWGuZofg3X2OKkCF7p():
	lRKcGkOgJYhbqEnfwXr3H6j8y2a = RPbaxsNFVTwek5Kfv21DiJuzCnjMZp.path.join(mFGa34JHCw9LWlB0,ee86G9ladLHVbh5mikzCo(u"ࠫࡦࡸࡡࡣ࡫ࡦࡺ࡮ࡪࡥࡰࡵࠪ፼"))
	cxjSLkUZd6VEozw = vvXoMLlg513
	if RPbaxsNFVTwek5Kfv21DiJuzCnjMZp.path.exists(lRKcGkOgJYhbqEnfwXr3H6j8y2a):
		for e90IM2s7vtVQTcGkZaUdNA6Y in RPbaxsNFVTwek5Kfv21DiJuzCnjMZp.listdir(lRKcGkOgJYhbqEnfwXr3H6j8y2a):
			if l32dnTEOU1skGKqeBtI9hmo(u"ࠬ࠴ࡰࡺࡱࠪ፽") in e90IM2s7vtVQTcGkZaUdNA6Y: continue
			if qqzwE6imYG4c2xojI(u"࠭࡟ࡠࡲࡼࡧࡦࡩࡨࡦࡡࡢࠫ፾") in e90IM2s7vtVQTcGkZaUdNA6Y: continue
			wo1ZAyVmBEzYOsQ = RPbaxsNFVTwek5Kfv21DiJuzCnjMZp.path.join(lRKcGkOgJYhbqEnfwXr3H6j8y2a,e90IM2s7vtVQTcGkZaUdNA6Y)
			bbh5fcJDG8NWp6z0,VC3guEILhR = e2YrFAdw9WBl8740uPKUcGCbL(wo1ZAyVmBEzYOsQ)
			cxjSLkUZd6VEozw += bbh5fcJDG8NWp6z0
	return cxjSLkUZd6VEozw
def ZZzULyMTCqYlbS7B9sQtN3DwVFIGWd(showDialogs):
	izMLIZkTyDvrRfoYsGb926 = gdPslyFW8ITBcpA302.getSetting(Ie5s2cBtSfdHjzQ4rA9kYlo6D18(u"ࠧࡢࡸ࠱ࡷࡹࡧࡴࡶࡵ࠱ࡱࡪࡹࡳࡢࡩࡨࡷࠬ፿"))
	AAiqysHNOzdTVp2ZXrgjw = XXyMBNAVJvKiq7jc20bEw6(WoFsvbmUlDZp7PzRfdGknCV,iNc3KxwErnQ(u"ࠨࡵࡷࡶࠬᎀ"),Ie5s2cBtSfdHjzQ4rA9kYlo6D18(u"ࠩࡐࡍࡘࡉ࡟ࡕࡇࡐࡔࡤ࠷ࠧᎁ"),fWoVd0Bmtkx(u"ࠪࡑࡊ࡙ࡓࡂࡉࡈࡗࠬᎂ"))
	NsHd4khI0robtVXBZElfwPFu7pTW,UDJHC6Gk7Q = izMLIZkTyDvrRfoYsGb926,AAiqysHNOzdTVp2ZXrgjw
	FukZtXw1ETIDjQA,j3bCsXWNey915wThr7GlgI4o = qpFY4hAwolV3,qpFY4hAwolV3
	if N3flV6EJsD5CzS(u"ࠫࡒࡋࡓࡔࡃࡊࡉࡘ࠭ᎃ") not in str(i4bFG3rKE6.SEND_THESE_EVENTS):
		Cm4xfTO625jyMtZ8GEpvuKcnbQ1gD = i4bFG3rKE6.SITESURLS[tQMjXKCA5dN4xq3beVIzaEoWkFLg(u"ࠬࡖ࡙ࡕࡊࡒࡒࠬᎄ")][DAE6vkyhXGx1wBdHmcFfTVQpL0l]
		UZHj1CuOIxPzAoTvcEV05d7NFi2G3m = bfLg2cN8FvsxWMeyj7q()
		F1KMGjNvHegbIJEs3fcOtwq = UZHj1CuOIxPzAoTvcEV05d7NFi2G3m.split(ee86G9ladLHVbh5mikzCo(u"࠭ࠬ࠭ࠩᎅ"))[Zwqio2AIWlD5etFa]
		cxjSLkUZd6VEozw = j06rHnAtPByzqWGuZofg3X2OKkCF7p()
		xJyvEDcMaBj0Ph37b8WeIlNiU = {dJHDqiKf12TXlIzSLkGUuxg4MBs3A(u"ࠧࡶࡵࡨࡶࠬᎆ"):i4bFG3rKE6.AV_CLIENT_IDS,rNdBKI74fAklnoCZ6(u"ࠨࡸࡨࡶࡸ࡯࡯࡯ࠩᎇ"):Q8q1YzIF6icWtSp2L,UVa3fJw7k6KM(u"ࠩࡦࡳࡺࡴࡴࡳࡻࠪᎈ"):F1KMGjNvHegbIJEs3fcOtwq,YY8UDX3MJhb91AHw7fg(u"ࠪ࡭ࡩࡹࠧᎉ"):Ikw7JgrXvRT8zteLb5sV6WidBN(cxjSLkUZd6VEozw)}
		lgDZd7ip5Ux = WWrExJZS3Bj4anOAkpv7(dzcNuIbsgK3yZ6SXGaEHPfOj5vk,RlOvin8YIGC2KZXJPk9m0acrMobUex(u"ࠫࡕࡕࡓࡕࠩᎊ"),Cm4xfTO625jyMtZ8GEpvuKcnbQ1gD,xJyvEDcMaBj0Ph37b8WeIlNiU,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,YY8UDX3MJhb91AHw7fg(u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡇࡆࡖࡢࡑࡊ࡙ࡓࡂࡉࡈࡗ࠲࠷ࡳࡵࠩᎋ"))
		if not lgDZd7ip5Ux.succeeded:
			if izMLIZkTyDvrRfoYsGb926 in [qpFY4hAwolV3,dJHDqiKf12TXlIzSLkGUuxg4MBs3A(u"࠭ࡎࡆ࡙ࠪᎌ")]: NsHd4khI0robtVXBZElfwPFu7pTW = RlOvin8YIGC2KZXJPk9m0acrMobUex(u"ࠧࡏࡇ࡚ࡣ࡙ࡕ࡟ࡆࡔࡕࡓࡗ࠭ᎍ")
			elif izMLIZkTyDvrRfoYsGb926==UVa3fJw7k6KM(u"ࠨࡑࡏࡈࠬᎎ"): NsHd4khI0robtVXBZElfwPFu7pTW = Ie5s2cBtSfdHjzQ4rA9kYlo6D18(u"ࠩࡒࡐࡉࡥࡔࡐࡡࡈࡖࡗࡕࡒࠨᎏ")
		else:
			dKTwPDBsSR5frHxXO4uWEyAc = lgDZd7ip5Ux.content
			dKTwPDBsSR5frHxXO4uWEyAc = wB8NUAidPbqjIr9CFasXvYnxOQpL0g(sjtU6GZQg5XC2pH4(u"ࠪࡰ࡮ࡹࡴࠨ᎐"),dKTwPDBsSR5frHxXO4uWEyAc)
			dKTwPDBsSR5frHxXO4uWEyAc = sorted(dKTwPDBsSR5frHxXO4uWEyAc,reverse=gBExoceumj4y8bFW9hY2aNMVSr,key=lambda key: int(key[vvXoMLlg513]))
			j3bCsXWNey915wThr7GlgI4o,UDJHC6Gk7Q = qpFY4hAwolV3,qpFY4hAwolV3
			for k0zE6IHShQa2,IndFPj93TGh6kvutQKCOBW2NqX,NVFLtBCmp8GAXi5u in dKTwPDBsSR5frHxXO4uWEyAc:
				if k0zE6IHShQa2==V3VlkhgjEF4n1erPXHcC0NOsfwyAJ(u"ࠫ࠵࠭᎑"):
					j3bCsXWNey915wThr7GlgI4o += NVFLtBCmp8GAXi5u+kYDaz79TFlXoR(u"ࠬࡀ࠺ࠨ᎒")
					continue
				if UDJHC6Gk7Q: UDJHC6Gk7Q += ZLwoRpfnCWI7FgEHsz6te39lMVh+xupTj02bvy3O8R+kYDaz79TFlXoR(u"࠭ࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࠬ᎓")+fF4lt9zWYxXLKZVyAco82PgMj+UVa3fJw7k6KM(u"ࠧ࡝ࡰ࡟ࡲࠬ᎔")
				ei6o3ZSqrkKJCMDFljIH2WaP = NVFLtBCmp8GAXi5u.split(ZLwoRpfnCWI7FgEHsz6te39lMVh)[vvXoMLlg513]
				qKVrPRkIUi = tR1krDGPpO025fghMT3a7UnYj(u"ࠨำึห้ฯࠠฯษุอ๊ࠥใࠡใๅ฻ࠬ᎕") if IndFPj93TGh6kvutQKCOBW2NqX else qpFY4hAwolV3
				UDJHC6Gk7Q += NVFLtBCmp8GAXi5u.replace(ei6o3ZSqrkKJCMDFljIH2WaP,IQ2KCmObsTGuiRdEzt931a40jLg+ei6o3ZSqrkKJCMDFljIH2WaP+qKVrPRkIUi+fF4lt9zWYxXLKZVyAco82PgMj)+ZLwoRpfnCWI7FgEHsz6te39lMVh
			UDJHC6Gk7Q = ZLwoRpfnCWI7FgEHsz6te39lMVh+UDJHC6Gk7Q+DaFZHsThGmd0zv6e(u"ࠩ࡟ࡲࡡࡴࠧ᎖")
			j3bCsXWNey915wThr7GlgI4o = j3bCsXWNey915wThr7GlgI4o.strip(V3VlkhgjEF4n1erPXHcC0NOsfwyAJ(u"ࠪ࠾࠿࠭᎗"))
			FukZtXw1ETIDjQA = gdPslyFW8ITBcpA302.getSetting(BRWqdruz2A0(u"ࠫࡦࡼ࠮ࡱࡴ࡬ࡺࡸ࠷ࠧ᎘"))
			if UDJHC6Gk7Q==AAiqysHNOzdTVp2ZXrgjw and izMLIZkTyDvrRfoYsGb926 in [kYDaz79TFlXoR(u"ࠬࡕࡌࡅࠩ᎙"),RlOvin8YIGC2KZXJPk9m0acrMobUex(u"࠭ࡏࡍࡆࡢࡘࡔࡥࡅࡓࡔࡒࡖࠬ᎚")]: NsHd4khI0robtVXBZElfwPFu7pTW = Ie5s2cBtSfdHjzQ4rA9kYlo6D18(u"ࠧࡐࡎࡇࠫ᎛")
			else: NsHd4khI0robtVXBZElfwPFu7pTW = aXqWLoTdVgME(u"ࠨࡐࡈ࡛ࠬ᎜")
			zOYMaQ0NgdiRVwDJXh8e(WoFsvbmUlDZp7PzRfdGknCV,BRWqdruz2A0(u"ࠩࡐࡍࡘࡉ࡟ࡕࡇࡐࡔࡤ࠷ࠧ᎝"),IaBhDMJc17302LgSvyxd(u"ࠪࡑࡊ࡙ࡓࡂࡉࡈࡗࠬ᎞"),UDJHC6Gk7Q,ivLg9zRnGF83u)
			gdPslyFW8ITBcpA302.setSetting(kYDaz79TFlXoR(u"ࠫࡦࡼ࠮࡭ࡣࡶࡸࡨ࡮ࡥࡤ࡭࠱ࡱࡪࡹࡳࡢࡩࡨࡷࠬ᎟"),Ikw7JgrXvRT8zteLb5sV6WidBN(dAeP20gNJ6ltq))
			gdPslyFW8ITBcpA302.setSetting(mmV2nucZ5Lpl6FO1JMPEqGoQKW(u"ࠬࡧࡶ࠯ࡲࡵ࡭ࡻࡹ࠱ࠨᎠ"),j3bCsXWNey915wThr7GlgI4o)
			Ljaf25ZGde9BIpVK4 = NAkjg5iJVr7wE4Ta3IfXP0Fo.md5(tR1krDGPpO025fghMT3a7UnYj(u"࠷᜹")*j3bCsXWNey915wThr7GlgI4o.encode(nV3Tip6XsH1rJw79DPOU)).hexdigest()
			Ljaf25ZGde9BIpVK4 = NAkjg5iJVr7wE4Ta3IfXP0Fo.md5(l32dnTEOU1skGKqeBtI9hmo(u"࠴࠸᜺")*Ljaf25ZGde9BIpVK4.encode(nV3Tip6XsH1rJw79DPOU)).hexdigest()
			Ljaf25ZGde9BIpVK4 = NAkjg5iJVr7wE4Ta3IfXP0Fo.md5(DaFZHsThGmd0zv6e(u"࠵࠾᜻")*Ljaf25ZGde9BIpVK4.encode(nV3Tip6XsH1rJw79DPOU)).hexdigest()
			MkQL5RWVxPpz2mi63ADrt,EHQhicPzSdtkG = GGenXr4081Qb9muR(WoFsvbmUlDZp7PzRfdGknCV)
			oyAV8sgxXrMfnOqFN97eaCWlTIPz(WoFsvbmUlDZp7PzRfdGknCV,MkQL5RWVxPpz2mi63ADrt,EHQhicPzSdtkG,ag8rjZo1Vz4IPdcOT,N3flV6EJsD5CzS(u"࠭ࡐࡓࡃࡊࡑࡆࠦࡡࡱࡲ࡯࡭ࡨࡧࡴࡪࡱࡱࡣ࡮ࡪ࠽ࠨᎡ")+str(int(Ljaf25ZGde9BIpVK4[dJHDqiKf12TXlIzSLkGUuxg4MBs3A(u"࠹᜽"):LZWMikPEB81KSGyxfJtUsCA(u"࠱࠳᜾")],LZWMikPEB81KSGyxfJtUsCA(u"࠲࠸᜿")))[:l1DZAt9XNQjqE7YOdrz(u"࠾᜼")]+Ie5s2cBtSfdHjzQ4rA9kYlo6D18(u"ࠧࠡ࠽ࠪᎢ"))
			MkQL5RWVxPpz2mi63ADrt.close()
		MtrAUi7KpukjvVWITnP = gBExoceumj4y8bFW9hY2aNMVSr if j3bCsXWNey915wThr7GlgI4o!=FukZtXw1ETIDjQA else ag8rjZo1Vz4IPdcOT
		if MtrAUi7KpukjvVWITnP:
			Imy27QKG1scZFpL9k = i4bFG3rKE6.ZZFcMiWJ3nfg29XH4L
			i4bFG3rKE6.ogLe6xzIfJyT75HCQa,i4bFG3rKE6.ZZFcMiWJ3nfg29XH4L,i4bFG3rKE6.uj7GLZ5bpqsOCcXxF3w,i4bFG3rKE6.XXvY7VDsGwhMLy4iaABHQOp,i4bFG3rKE6.avprivsnorestrict,i4bFG3rKE6.avprivslongperiod = obE7G0q9ik4dwtAYZpnxrJ([viRJWOC5jsYe84(u"ࠨࡅࡗࡉ࠾ࡊࡓ࠲࠻࡙࡙࠵࡜ࡓ࡙ࠩᎣ"),UUDAiytEL76RTmMYsuIz5evXB(u"࡚ࠩࡗ࡚ࡘࡆࡕ࠳࠼ࡕ࡙ࡋࡆ࡛࡚ࠪᎤ"),UUDAiytEL76RTmMYsuIz5evXB(u"ࠪࡆ࡙ࡋࡸࡑࡘ࠴࠽࡚ࡘࡖࡏࡗࡖ࡙࠺ࡎࡘࠨᎥ"),LZWMikPEB81KSGyxfJtUsCA(u"ࠫࡔ࡚࠱࠺ࡌࡘ࠴ࡽࡈࡔࡖ࡮ࡇ࡜ࠬᎦ"),RlOvin8YIGC2KZXJPk9m0acrMobUex(u"ࠬࡈࡔࡆࡺࡓ࡚࠶࠿ࡓࡓࡘࡑ࡙࡚ࡱ࡬ࡅࡘࡈ࡚ࡊ࡞ࠧᎧ"),ee86G9ladLHVbh5mikzCo(u"࠭ࡍࡕ࠲࠸ࡌ࡝࠶࡬ࡕࡖࡈࡊࡓ࡙ࡕࡏࡨࡘࡉ࡛࡙ࡓࡖ࠻ࡈ࡜ࠬᎨ")])
			NbdOQyIsCA0 = i4bFG3rKE6.ZZFcMiWJ3nfg29XH4L
			if not Imy27QKG1scZFpL9k and NbdOQyIsCA0 and qqzwE6imYG4c2xojI(u"ࠧࡎࡇࡖࡗࡆࡍࡅࡔࡡࡗࡗࠬᎩ") in i4bFG3rKE6.SEND_THESE_EVENTS:
				i4bFG3rKE6.SEND_THESE_EVENTS.remove(N3flV6EJsD5CzS(u"ࠨࡏࡈࡗࡘࡇࡇࡆࡕࡢࡘࡘ࠭Ꭺ"))
				i4bFG3rKE6.SEND_THESE_EVENTS.append(dJHDqiKf12TXlIzSLkGUuxg4MBs3A(u"ࠩࡐࡉࡘ࡙ࡁࡈࡇࡖࠫᎫ"))
			elif Imy27QKG1scZFpL9k and not NbdOQyIsCA0 and fWoVd0Bmtkx(u"ࠪࡑࡊ࡙ࡓࡂࡉࡈࡗࠬᎬ") in i4bFG3rKE6.SEND_THESE_EVENTS:
				i4bFG3rKE6.SEND_THESE_EVENTS.remove(viRJWOC5jsYe84(u"ࠫࡒࡋࡓࡔࡃࡊࡉࡘ࠭Ꭽ"))
				i4bFG3rKE6.SEND_THESE_EVENTS.append(aXqWLoTdVgME(u"ࠬࡓࡅࡔࡕࡄࡋࡊ࡙࡟ࡕࡕࠪᎮ"))
			E2E18vJ4hLaZpuWSfoMlY9yBzj6b(ag8rjZo1Vz4IPdcOT)
	if showDialogs:
		if NsHd4khI0robtVXBZElfwPFu7pTW in [tQMjXKCA5dN4xq3beVIzaEoWkFLg(u"࠭ࡏࡍࡆࡢࡘࡔࡥࡅࡓࡔࡒࡖࠬᎯ"),zYvEaigKWjoq50pXBLDbGJkFc(u"ࠧࡏࡇ࡚ࡣ࡙ࡕ࡟ࡆࡔࡕࡓࡗ࠭Ꮀ")]:
			iG7Rz2kmn0x1yLNMV3u8O(qpFY4hAwolV3,qpFY4hAwolV3,GLTtERWbHnFuy4PCp,YY8UDX3MJhb91AHw7fg(u"ࠨ้้ห่ࠦๅีๅ็อࠥ็๊ࠡฮ๊หื้้้ࠠํࠤ้๐ำห่๊ࠢࠥอไษำ้ห๊าࠠ࠯࠰๋ࠣีํࠠศๆุ่่๊ษࠡไาࠤ๏้่็ࠢึฬอํวࠡษ็ษ๋ะั็ฬࠣห้ิวึࠢห็ࠥษ่ࠡษ็ีฬ๎สาࠢส่ำอีࠡสๆࠤศ๎ࠠๆึๆ่ฮࠦแ๋ࠢส่ศูไศๅࠣ฽๋ีใࠨᎱ"))
		else:
			W2fBJaUN9kZwVeR1n0o4Dc(LZWMikPEB81KSGyxfJtUsCA(u"ࠩࡵ࡭࡬࡮ࡴࠨᎲ"),ddiCzu6yahj5RtTISMJ48sNnZBU(u"ࠪีุอฦๅ่๊ࠢࠥอไๆสิ้ัࠦลๅุ๋้ࠣะฮะ็ํࠤฬ๊ศา่ส้ั࠭Ꮃ"),UDJHC6Gk7Q,BRWqdruz2A0(u"ࠫࡹ࡫ࡸࡵࡸ࡬ࡩࡼࡥࡢࡪࡩࡩࡳࡳࡺ࡟࡭ࡱࡱ࡫ࠬᎴ"))
			NsHd4khI0robtVXBZElfwPFu7pTW = c2RKu0xG1eC8MiohyE(u"ࠬࡕࡌࡅࠩᎵ")
	if NsHd4khI0robtVXBZElfwPFu7pTW!=izMLIZkTyDvrRfoYsGb926:
		gdPslyFW8ITBcpA302.setSetting(ee86G9ladLHVbh5mikzCo(u"࠭ࡡࡷ࠰ࡶࡸࡦࡺࡵࡴ࠰ࡰࡩࡸࡹࡡࡨࡧࡶࠫᎶ"),NsHd4khI0robtVXBZElfwPFu7pTW)
		E2E18vJ4hLaZpuWSfoMlY9yBzj6b(ag8rjZo1Vz4IPdcOT)
	return
def cbWDd2g9hL0ZO8(EnkT2XQRiLO,J9v0MeEWnNTDG4lZgsBdI816u):
	import socket as t8jd2DlPfrO9eRCFgG3M1XKHLkST
	FK5yAWRBXJmvNqE79gZT0SYa8 = t8jd2DlPfrO9eRCFgG3M1XKHLkST.socket(t8jd2DlPfrO9eRCFgG3M1XKHLkST.AF_INET,t8jd2DlPfrO9eRCFgG3M1XKHLkST.SOCK_STREAM)
	FK5yAWRBXJmvNqE79gZT0SYa8.settimeout(DAE6vkyhXGx1wBdHmcFfTVQpL0l)
	try:
		Z0JRfngy6coNe8FsCIu2O9tip = s7FnXZYOgexlH2MPb8BJck1AKv9.time()
		FK5yAWRBXJmvNqE79gZT0SYa8.connect((EnkT2XQRiLO,J9v0MeEWnNTDG4lZgsBdI816u))
		hhsuDxXYlIiQmZqeW = s7FnXZYOgexlH2MPb8BJck1AKv9.time()
		KlvQHZkBxfh8nXeLdR = round((hhsuDxXYlIiQmZqeW-Z0JRfngy6coNe8FsCIu2O9tip)*ddiCzu6yahj5RtTISMJ48sNnZBU(u"࠳࠳࠴࠵ᝀ"))
	except: KlvQHZkBxfh8nXeLdR = -mZi0S72jGoHpLO
	FK5yAWRBXJmvNqE79gZT0SYa8.close()
	return KlvQHZkBxfh8nXeLdR
def PAfd3TnXb2oz(showDialogs):
	if showDialogs:
		o4oUxD3u18K59ghHIY = VVpbtSKYUGXrNMwAWFo9IOjZP(qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,GLTtERWbHnFuy4PCp,fWoVd0Bmtkx(u"ࠧิ๊ไࠤ๏่่ๆࠢส่อืๆศ็ฯࠤฬ๊ย็ࠢหษฺ๊วฮ๋ࠢฮ๋฾๊โࠢฯ้๏฿ࠠใ๊ส฽ิࠦวๅสํห๋อส๊ࠡส่่อิࠡษ็ุ้ะฮะ็ฬࠤๆ๐ࠠศๆหี๋อๅอࠢ࠱࠲ࠥํไࠡฬิ๎ิࠦสี฼ํ่ࠥ฿ๅๅ์ฬࠤฬ๊ส็ฺํๅࠥอไร่ࠣรࠦ࠭Ꮇ"))
	else: o4oUxD3u18K59ghHIY = gBExoceumj4y8bFW9hY2aNMVSr
	if o4oUxD3u18K59ghHIY==mZi0S72jGoHpLO:
		for e90IM2s7vtVQTcGkZaUdNA6Y in RPbaxsNFVTwek5Kfv21DiJuzCnjMZp.listdir(F8qeAKZjGRMNXimho2gntaV0):
			if e90IM2s7vtVQTcGkZaUdNA6Y.endswith(BRWqdruz2A0(u"ࠨ࠰ࡧࡦࠬᎸ")) and aXqWLoTdVgME(u"ࠩࡧࡥࡹࡧࠧᎹ") in e90IM2s7vtVQTcGkZaUdNA6Y:
				FwGREbN3P2ZHr7mdIDVeJ = RPbaxsNFVTwek5Kfv21DiJuzCnjMZp.path.join(F8qeAKZjGRMNXimho2gntaV0,e90IM2s7vtVQTcGkZaUdNA6Y)
				MkQL5RWVxPpz2mi63ADrt,EHQhicPzSdtkG = GGenXr4081Qb9muR(FwGREbN3P2ZHr7mdIDVeJ)
				EHQhicPzSdtkG.execute(iNc3KxwErnQ(u"ࠪࡔࡗࡇࡇࡎࡃࠣࡪࡴࡸࡥࡪࡩࡱࡣࡰ࡫ࡹࡴ࠿ࡱࡳࡀ࠭Ꮊ"))
				EHQhicPzSdtkG.execute(c2RKu0xG1eC8MiohyE(u"ࠫࡕࡘࡁࡈࡏࡄࠤࡹ࡫࡭ࡱࡡࡶࡸࡴࡸࡥ࠾ࡏࡈࡑࡔࡘ࡙࠼ࠩᎻ"))
				EHQhicPzSdtkG.execute(UUDAiytEL76RTmMYsuIz5evXB(u"ࠬࡖࡒࡂࡉࡐࡅࠥ࡯࡮ࡵࡧࡪࡶ࡮ࡺࡹࡠࡥ࡫ࡩࡨࡱ࠻ࠨᎼ"))
				EHQhicPzSdtkG.execute(qqzwE6imYG4c2xojI(u"࠭ࡐࡓࡃࡊࡑࡆࠦ࡯ࡱࡶ࡬ࡱ࡮ࢀࡥ࠼ࠩᎽ"))
				EHQhicPzSdtkG.execute(tR1krDGPpO025fghMT3a7UnYj(u"ࠧࡗࡃࡆ࡙࡚ࡓ࠻ࠨᎾ"))
				MkQL5RWVxPpz2mi63ADrt.commit()
				MkQL5RWVxPpz2mi63ADrt.close()
		if showDialogs: iG7Rz2kmn0x1yLNMV3u8O(qpFY4hAwolV3,qpFY4hAwolV3,GLTtERWbHnFuy4PCp,l1DZAt9XNQjqE7YOdrz(u"ࠨฬ่ฮࠥฮๆอษะࠤ฾๋ไ๋หࠣษฺ๊วฮ๋ࠢฮ๋฾๊โࠢฯ้๏฿ࠠใ๊ส฽ิࠦวๅสํห๋อส๊ࠡส่่อิࠡษ็ุ้ะฮะ็ฬࠤๆ๐ࠠศๆหี๋อๅอࠩᎿ"))
	return
def nGRXot8mU9Qa2Dd(JMB5Ih0KkzpO3,udO3BrRSFCwt,showDialogs):
	if JMB5Ih0KkzpO3!=z5wEtWrCxRZiQ:
		if JMB5Ih0KkzpO3==gBS4c5m3A6vTzbpohHjFK1uYfNRk8a: i4bFG3rKE6.ALLOW_DNS_FIX = gBExoceumj4y8bFW9hY2aNMVSr
		elif JMB5Ih0KkzpO3==pESAKj92MT: i4bFG3rKE6.ALLOW_DNS_FIX = ag8rjZo1Vz4IPdcOT
		elif JMB5Ih0KkzpO3==dND7uS6bknRj82EOIX0iyUxAscl: i4bFG3rKE6.ALLOW_DNS_FIX = gBExoceumj4y8bFW9hY2aNMVSr
	if udO3BrRSFCwt!=z5wEtWrCxRZiQ:
		if udO3BrRSFCwt==gBS4c5m3A6vTzbpohHjFK1uYfNRk8a: i4bFG3rKE6.ALLOW_PROXY_FIX = gBExoceumj4y8bFW9hY2aNMVSr
		elif udO3BrRSFCwt==pESAKj92MT: i4bFG3rKE6.ALLOW_PROXY_FIX = ag8rjZo1Vz4IPdcOT
		elif udO3BrRSFCwt==dND7uS6bknRj82EOIX0iyUxAscl: i4bFG3rKE6.ALLOW_PROXY_FIX = gBExoceumj4y8bFW9hY2aNMVSr
	if showDialogs!=z5wEtWrCxRZiQ:
		if showDialogs==gBS4c5m3A6vTzbpohHjFK1uYfNRk8a: i4bFG3rKE6.ALLOW_SHOWDIALOGS_FIX = gBExoceumj4y8bFW9hY2aNMVSr
		elif showDialogs==pESAKj92MT: i4bFG3rKE6.ALLOW_SHOWDIALOGS_FIX = ag8rjZo1Vz4IPdcOT
		elif showDialogs==dND7uS6bknRj82EOIX0iyUxAscl: i4bFG3rKE6.ALLOW_SHOWDIALOGS_FIX = gBExoceumj4y8bFW9hY2aNMVSr
	return
def VmRkyuTWprQUebn7zPYh2LJ(sqAWIiRPd0TUV75EyCo26JhD38ZN4O,KqJdrnE68y,qgwkQvdFcBJYoyuE7p1CU,args):
	z5nOUetfoJHbP6294ghwur,WSQlG8mDhqsNe,RZ2SwHp6GQvAy,skD7g3FxW4wCa5BR,c0ApgT8hP5FOJ,pDxy6XBiWkz08,n38oH7wd6BDyAMJQS,XSRoBuFEbKvZH6meTNCJx7LwQi,AGUTOIbFi4tDB1 = args
	Z0bQKOAD5c41yg9zER2p = n38oH7wd6BDyAMJQS.split(qoBMmfAWpFlK70xw8ZRh4naJ(u"ࠩ࠰ࠫᏀ"))[vvXoMLlg513]
	is6KpcAFPM8jJNHqtS = viRJWOC5jsYe84(u"ࠪื๏ืแาࠢิๆ๊ࠦࠧᏁ")+str(sqAWIiRPd0TUV75EyCo26JhD38ZN4O)
	jqVJT12oeDhiwf0 = DObEAlBf39(WSQlG8mDhqsNe,n38oH7wd6BDyAMJQS)
	LLvyStW429DEZKlA(d3MGHW41fvNz6rRFYix2anS,lTW9p1v7uPfOxB(Q8Q0IDc6PLZajJAdTntKUmSGXz)+lljaEqwTVtmKsQcOrbXxS5hgNH(u"ࠫࠥࠦࠠࡕࡴࡼ࡭ࡳ࡭ࠠࡣࡻࡳࡥࡸࡹࠠࡣ࡮ࡲࡧࡰ࡯࡮ࡨࠢࠣࠤࡘ࡫ࡲࡷࡧࡵ࠾ࠥࡡࠠࠨᏂ")+str(sqAWIiRPd0TUV75EyCo26JhD38ZN4O)+viRJWOC5jsYe84(u"ࠬࠦ࡝ࠡࠢࠣࡇࡴࡪࡥ࠻ࠢ࡞ࠤࠬᏃ")+str(XSRoBuFEbKvZH6meTNCJx7LwQi)+V3VlkhgjEF4n1erPXHcC0NOsfwyAJ(u"࠭ࠠ࡞ࠢࠣࡖࡪࡧࡳࡰࡰ࠽ࠤࡠࠦࠧᏄ")+AGUTOIbFi4tDB1+fWoVd0Bmtkx(u"ࠧࠡ࡟ࠣࠤ࡙ࠥ࡯ࡶࡴࡦࡩ࠿࡛ࠦࠡࠩᏅ")+n38oH7wd6BDyAMJQS+DiJ8CMuYH1daWyjehfN0L(u"ࠨࠢࡠࠤ࡛ࠥࡒࡍ࠼ࠣ࡟ࠥ࠭Ꮖ")+jqVJT12oeDhiwf0+iNc3KxwErnQ(u"ࠩࠣࡡࠬᏇ"))
	update = gBExoceumj4y8bFW9hY2aNMVSr
	if sqAWIiRPd0TUV75EyCo26JhD38ZN4O==vvXoMLlg513:
		scraperserver = ee86G9ladLHVbh5mikzCo(u"ࠪࡷࡨࡸࡡࡱࡧࡲࡴࡸ࠷ࠧᏈ")
		ZTnaBus8HPRQ5UzFyjwciWAG17KdJ = DiJ8CMuYH1daWyjehfN0L(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡸࡩࡲࡢࡲࡨࡳࡵࡹ࠮࡬ࡧࡨࡴࡤ࡮ࡥࡢࡦࡨࡶࡸࡃࡔࡳࡷࡨ࠲ࡨࡵࡵ࡯ࡶࡵࡽࡂ࡯࡬࠻࠳࠸࠴ࡩ࠸࠲ࡧ࠳࠰ࡧ࠺࠾ࡡ࠮࠶࠳࠶࠶࠳ࡡࡢ࠺࠷࠱ࡪ࠿࠲࠴ࡥࡤࡪ࠽࠻࠸࠴࠶ࡃࡴࡷࡵࡸࡺ࠰ࡶࡧࡷࡧࡰࡦࡱࡳࡷ࠳࡯࡯࠻࠷࠶࠹࠸࠭Ꮙ")
		y2SIoiHRUhNMmqPYjrwA3TWg69pxV = WSQlG8mDhqsNe+kYDaz79TFlXoR(u"ࠬࢂࡼࡎࡻࡓࡶࡴࡾࡹࡖࡴ࡯ࡁࠬᏊ")+ZTnaBus8HPRQ5UzFyjwciWAG17KdJ+l32dnTEOU1skGKqeBtI9hmo(u"࠭ࡼࡽࡐࡲ࡚ࡪࡸࡩࡧࡻࡖࡗࡑ࠭Ꮛ")
		BBn5MeXCPD = kFcsbIlVJDSA1mTOof4(z5nOUetfoJHbP6294ghwur,y2SIoiHRUhNMmqPYjrwA3TWg69pxV,RZ2SwHp6GQvAy,skD7g3FxW4wCa5BR,c0ApgT8hP5FOJ,pDxy6XBiWkz08,n38oH7wd6BDyAMJQS,ag8rjZo1Vz4IPdcOT,ag8rjZo1Vz4IPdcOT)
	elif sqAWIiRPd0TUV75EyCo26JhD38ZN4O==mZi0S72jGoHpLO:
		scraperserver = viRJWOC5jsYe84(u"ࠧࡴࡥࡵࡥࡵ࡫࡯ࡱࡵ࠵ࠫᏌ")
		ZTnaBus8HPRQ5UzFyjwciWAG17KdJ = RlOvin8YIGC2KZXJPk9m0acrMobUex(u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࡵࡦࡶࡦࡶࡥࡰࡲࡶ࠲ࡰ࡫ࡥࡱࡡ࡫ࡩࡦࡪࡥࡳࡵࡀࡘࡷࡻࡥ࠯ࡥࡲࡹࡳࡺࡲࡺ࠿࡬ࡰ࠿࠹࠹࠺࠳ࡨ࠽ࡨ࠻࠭࠸ࡧࡨ࠷࠲࠺ࡥࡦ࠴࠰࠼࠹ࡩ࠰࠮ࡨࡧ࠻࠾࠸ࡢࡢࡦࡧ࠷ࡩ࠻ࡀࡱࡴࡲࡼࡾ࠴ࡳࡤࡴࡤࡴࡪࡵࡰࡴ࠰࡬ࡳ࠿࠻࠳࠶࠵ࠪᏍ")
		y2SIoiHRUhNMmqPYjrwA3TWg69pxV = WSQlG8mDhqsNe+mmV2nucZ5Lpl6FO1JMPEqGoQKW(u"ࠩࡿࢀࡒࡿࡐࡳࡱࡻࡽ࡚ࡸ࡬࠾ࠩᏎ")+ZTnaBus8HPRQ5UzFyjwciWAG17KdJ+UUDAiytEL76RTmMYsuIz5evXB(u"ࠪࢀࢁࡔ࡯ࡗࡧࡵ࡭࡫ࡿࡓࡔࡎࠪᏏ")
		BBn5MeXCPD = kFcsbIlVJDSA1mTOof4(z5nOUetfoJHbP6294ghwur,y2SIoiHRUhNMmqPYjrwA3TWg69pxV,RZ2SwHp6GQvAy,skD7g3FxW4wCa5BR,c0ApgT8hP5FOJ,pDxy6XBiWkz08,n38oH7wd6BDyAMJQS,ag8rjZo1Vz4IPdcOT,ag8rjZo1Vz4IPdcOT)
	elif sqAWIiRPd0TUV75EyCo26JhD38ZN4O==Zwqio2AIWlD5etFa:
		scraperserver = LZWMikPEB81KSGyxfJtUsCA(u"ࠫࡸࡩࡲࡢࡲࡨࡶࡦࡶࡩࠨᏐ")
		ZTnaBus8HPRQ5UzFyjwciWAG17KdJ = c2RKu0xG1eC8MiohyE(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡹࡣࡳࡣࡳࡩࡷࡧࡰࡪ࠰࡮ࡩࡪࡶ࡟ࡩࡧࡤࡨࡪࡸࡳ࠾ࡖࡵࡹࡪ࠴ࡣࡰࡷࡱࡸࡷࡿ࡟ࡤࡱࡧࡩࡂ࡯࡬࠻࠹࠹ࡦ࠹࡬ࡣ࠴࠶ࡩࡧࡩ࠷࠹ࡥ࠻ࡦ࠹࠺ࡧ࠱࠶ࡨ࠶࠺࠵࠺ࡣࡥ࠻࠴࠸ࡨࡆࡰࡳࡱࡻࡽ࠲ࡹࡥࡳࡸࡨࡶ࠳ࡹࡣࡳࡣࡳࡩࡷࡧࡰࡪ࠰ࡦࡳࡲࡀ࠸࠱࠲࠴ࠫᏑ")
		y2SIoiHRUhNMmqPYjrwA3TWg69pxV = WSQlG8mDhqsNe+BRWqdruz2A0(u"࠭ࡼࡽࡏࡼࡔࡷࡵࡸࡺࡗࡵࡰࡂ࠭Ꮢ")+ZTnaBus8HPRQ5UzFyjwciWAG17KdJ+mmV2nucZ5Lpl6FO1JMPEqGoQKW(u"ࠧࡽࡾࡑࡳ࡛࡫ࡲࡪࡨࡼࡗࡘࡒࠧᏓ")
		BBn5MeXCPD = kFcsbIlVJDSA1mTOof4(z5nOUetfoJHbP6294ghwur,y2SIoiHRUhNMmqPYjrwA3TWg69pxV,RZ2SwHp6GQvAy,skD7g3FxW4wCa5BR,c0ApgT8hP5FOJ,pDxy6XBiWkz08,n38oH7wd6BDyAMJQS,ag8rjZo1Vz4IPdcOT,ag8rjZo1Vz4IPdcOT)
	elif sqAWIiRPd0TUV75EyCo26JhD38ZN4O==DAE6vkyhXGx1wBdHmcFfTVQpL0l:
		scraperserver = qoBMmfAWpFlK70xw8ZRh4naJ(u"ࠨࡵࡦࡶࡦࡶࡥࡶࡲࠪᏔ")
		hhpztscnBD1GP = WSQlG8mDhqsNe.replace(IaBhDMJc17302LgSvyxd(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࠫᏕ"),zYvEaigKWjoq50pXBLDbGJkFc(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࠫᏖ"))
		y2SIoiHRUhNMmqPYjrwA3TWg69pxV = sjtU6GZQg5XC2pH4(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡦࡶࡩ࠯ࡵࡦࡶࡦࡶࡥࡶࡲ࠱ࡧࡴࡳ࠯ࡀࡣࡳ࡭ࡤࡱࡥࡺ࠿࠴࡚ࡓࡹࡍࡵࡎ࠴ࡳࡇࡘࡘ࡬ࡕࡑࡇࡧࡉࡍࡋ࠳ࡎ࡜࡞ࡐࡪ࡫࠲ࡧ࡮࡟ࡽࠦ࡬ࡧࡨࡴࡤ࡮ࡥࡢࡦࡨࡶࡸࡃࡆࡢ࡮ࡶࡩࠫࡩ࡯ࡶࡰࡷࡶࡾࡥࡣࡰࡦࡨࡁ࡮ࡲࠦࡶࡴ࡯ࡁࠬᏗ")+BUKlErdIu7Ggqcz3jYpf09wMePF4V(hhpztscnBD1GP)
		BBn5MeXCPD = kFcsbIlVJDSA1mTOof4(V3VlkhgjEF4n1erPXHcC0NOsfwyAJ(u"ࠬࡍࡅࡕࠩᏘ"),y2SIoiHRUhNMmqPYjrwA3TWg69pxV,RZ2SwHp6GQvAy,skD7g3FxW4wCa5BR,c0ApgT8hP5FOJ,pDxy6XBiWkz08,n38oH7wd6BDyAMJQS,ag8rjZo1Vz4IPdcOT,ag8rjZo1Vz4IPdcOT)
	elif sqAWIiRPd0TUV75EyCo26JhD38ZN4O==wn4bG51vUENfaS0Zg:
		scraperserver = ee86G9ladLHVbh5mikzCo(u"࠭ࡳࡤࡴࡤࡴ࡮ࡴࡧࡳࡱࡥࡳࡹ࠭Ꮩ")
		y2SIoiHRUhNMmqPYjrwA3TWg69pxV = UUDAiytEL76RTmMYsuIz5evXB(u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡢࡲ࡬࠲ࡸࡩࡲࡢࡲ࡬ࡲ࡬ࡸ࡯ࡣࡱࡷ࠲ࡨࡵ࡭࠰ࡁࡷࡳࡰ࡫࡮࠾ࡣ࠷ࡪ࠼࡬ࡢ࠲࠶࠰࠶ࡩ࡫ࡦ࠮࠶࠳࠻࠶࠳࠸࠷࠶ࡥ࠱࠷࠸ࡥ࠴࠴࠹࠸ࡩ࠺ࡤࡥࡥࠩࡴࡷࡵࡸࡺࡅࡲࡹࡳࡺࡲࡺ࠿ࡌࡐࠫࡻࡲ࡭࠿ࠪᏚ")+BUKlErdIu7Ggqcz3jYpf09wMePF4V(WSQlG8mDhqsNe)
		BBn5MeXCPD = kFcsbIlVJDSA1mTOof4(l32dnTEOU1skGKqeBtI9hmo(u"ࠨࡉࡈࡘࠬᏛ"),y2SIoiHRUhNMmqPYjrwA3TWg69pxV,RZ2SwHp6GQvAy,skD7g3FxW4wCa5BR,c0ApgT8hP5FOJ,pDxy6XBiWkz08,n38oH7wd6BDyAMJQS,ag8rjZo1Vz4IPdcOT,ag8rjZo1Vz4IPdcOT)
		try:
			qDfPS0MjocvJkUZn = A3AFYmgZLXn4MBab.loads(BBn5MeXCPD.content)
			BBn5MeXCPD.content = qDfPS0MjocvJkUZn.get(zYvEaigKWjoq50pXBLDbGJkFc(u"ࠩࡵࡩࡸࡻ࡬ࡵࠩᏜ"),qpFY4hAwolV3)
			YF1G4LhrWJ9svR8NKOk5x = sum(WckHT2tJPQnh3IC6x8F59 < CC1eY6yWZUwf2TkRvnp7EJ0AimjHBX(u"ࠪࠤࠬᏝ") and WckHT2tJPQnh3IC6x8F59 not in YY8UDX3MJhb91AHw7fg(u"ࠫࡡࡸ࡜࡯࡞ࡷࠫᏞ") for WckHT2tJPQnh3IC6x8F59 in BBn5MeXCPD.content[:qoBMmfAWpFlK70xw8ZRh4naJ(u"࠴࠴࠵࠶ᝁ")])
			if YF1G4LhrWJ9svR8NKOk5x > ddiCzu6yahj5RtTISMJ48sNnZBU(u"࠵࠵ᝂ"):
				BBn5MeXCPD = qvfZXAI81kwTueoFgnOhWazdBR()
				BBn5MeXCPD.succeeded = ag8rjZo1Vz4IPdcOT
				BBn5MeXCPD.content = qpFY4hAwolV3
		except: pass
	elif sqAWIiRPd0TUV75EyCo26JhD38ZN4O==Y719atFWlPpbO6uTULjZf5VGD2o0:
		scraperserver = BRWqdruz2A0(u"ࠬࡹࡣࡳࡣࡳ࡭ࡳ࡭ࡡ࡯ࡶ࠴ࠫᏟ")
		ZTnaBus8HPRQ5UzFyjwciWAG17KdJ = RlOvin8YIGC2KZXJPk9m0acrMobUex(u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡳࡤࡴࡤࡴ࡮ࡴࡧࡢࡰࡷࠪࡵࡸ࡯ࡹࡻࡢࡧࡴࡻ࡮ࡵࡴࡼࡁࡎࡒࠦࡣࡴࡲࡻࡸ࡫ࡲ࠾ࡈࡤࡰࡸ࡫ࠦࡧࡱࡵࡻࡦࡸࡤࡠࡪࡨࡥࡩ࡫ࡲࡴ࠿ࡗࡶࡺ࡫࠺࠳ࡤ࠶࠸࠵ࡧ࠶࠹࠻࠳ࡥ࠺࠺࠰࠲ࡦࡥࡧ࠸࠽࠲ࡤ࠳࠴࠸࠺ࡪ࠹࠷࠴ࡨ࠼ࡅࡶࡲࡰࡺࡼ࠲ࡸࡩࡲࡢࡲ࡬ࡲ࡬ࡧ࡮ࡵ࠰ࡦࡳࡲࡀ࠸࠱࠺࠳ࠫᏠ")
		y2SIoiHRUhNMmqPYjrwA3TWg69pxV = WSQlG8mDhqsNe+IaBhDMJc17302LgSvyxd(u"ࠧࡽࡾࡐࡽࡕࡸ࡯ࡹࡻࡘࡶࡱࡃࠧᏡ")+ZTnaBus8HPRQ5UzFyjwciWAG17KdJ+N3flV6EJsD5CzS(u"ࠨࡾࡿࡒࡴ࡜ࡥࡳ࡫ࡩࡽࡘ࡙ࡌࠨᏢ")
		BBn5MeXCPD = kFcsbIlVJDSA1mTOof4(z5nOUetfoJHbP6294ghwur,y2SIoiHRUhNMmqPYjrwA3TWg69pxV,RZ2SwHp6GQvAy,skD7g3FxW4wCa5BR,c0ApgT8hP5FOJ,pDxy6XBiWkz08,n38oH7wd6BDyAMJQS,ag8rjZo1Vz4IPdcOT,ag8rjZo1Vz4IPdcOT)
	elif sqAWIiRPd0TUV75EyCo26JhD38ZN4O==dJHDqiKf12TXlIzSLkGUuxg4MBs3A(u"࠻ᝃ"):
		scraperserver = ddiCzu6yahj5RtTISMJ48sNnZBU(u"ࠩࡶࡧࡷࡧࡰࡦ࠰ࡧࡳ࠶࠭Ꮳ")
		ZTnaBus8HPRQ5UzFyjwciWAG17KdJ = l1DZAt9XNQjqE7YOdrz(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡧࡨ࠸࠶࠴ࡣࡥ࠵ࡪ࠻࠰࠵࠶ࡧ࠶ࡨࡧ࠵ࡥ࠷ࡧ࠷࡫࠿ࡥ࠴ࡥ࠶࠼࠻࡫ࡣࡢ࠳࠴࠴࠽࠹࠸࠺ࡣ࠺࠷࠿ࡩࡵࡴࡶࡲࡱࡍ࡫ࡡࡥࡧࡵࡷࡂ࡚ࡲࡶࡧࠩ࡫ࡪࡵࡃࡰࡦࡨࡁ࡮ࡲࡀࡱࡴࡲࡼࡾ࠴ࡳࡤࡴࡤࡴࡪ࠴ࡤࡰ࠼࠻࠴࠽࠶ࠧᏤ")
		y2SIoiHRUhNMmqPYjrwA3TWg69pxV = WSQlG8mDhqsNe+LZWMikPEB81KSGyxfJtUsCA(u"ࠫࢁࢂࡍࡺࡒࡵࡳࡽࡿࡕࡳ࡮ࡀࠫᏥ")+ZTnaBus8HPRQ5UzFyjwciWAG17KdJ+N3flV6EJsD5CzS(u"ࠬࢂࡼࡏࡱ࡙ࡩࡷ࡯ࡦࡺࡕࡖࡐࠬᏦ")
		BBn5MeXCPD = kFcsbIlVJDSA1mTOof4(z5nOUetfoJHbP6294ghwur,y2SIoiHRUhNMmqPYjrwA3TWg69pxV,RZ2SwHp6GQvAy,skD7g3FxW4wCa5BR,c0ApgT8hP5FOJ,pDxy6XBiWkz08,n38oH7wd6BDyAMJQS,ag8rjZo1Vz4IPdcOT,ag8rjZo1Vz4IPdcOT)
	elif sqAWIiRPd0TUV75EyCo26JhD38ZN4O==LZWMikPEB81KSGyxfJtUsCA(u"࠽ᝄ"):
		scraperserver = kYDaz79TFlXoR(u"࠭ࡳࡤࡴࡤࡴࡪ࠴ࡤࡰ࠴ࠪᏧ")
		ZTnaBus8HPRQ5UzFyjwciWAG17KdJ = qoBMmfAWpFlK70xw8ZRh4naJ(u"ࠧࡩࡶࡷࡴ࠿࠵࠯࠲ࡥ࠶ࡨ࠸ࡧࡥ࠲࠺࠸ࡨ࡫࠺ࡢࡧ࠸ࡤࡪ࠺࠹࠳ࡤ࠹࠳࠸࠵ࡨ࠳࠵࠹ࡦ࠽ࡪ࠿࠹ࡣࡧ࠷࠺࠻ࡧࡥ࠺࠼ࡦࡹࡸࡺ࡯࡮ࡊࡨࡥࡩ࡫ࡲࡴ࠿ࡗࡶࡺ࡫ࠦࡨࡧࡲࡇࡴࡪࡥ࠾࡫࡯ࡄࡵࡸ࡯ࡹࡻ࠱ࡷࡨࡸࡡࡱࡧ࠱ࡨࡴࡀ࠸࠱࠺࠳ࠫᏨ")
		y2SIoiHRUhNMmqPYjrwA3TWg69pxV = WSQlG8mDhqsNe+BRWqdruz2A0(u"ࠨࡾࡿࡑࡾࡖࡲࡰࡺࡼ࡙ࡷࡲ࠽ࠨᏩ")+ZTnaBus8HPRQ5UzFyjwciWAG17KdJ+qoBMmfAWpFlK70xw8ZRh4naJ(u"ࠩࡿࢀࡓࡵࡖࡦࡴ࡬ࡪࡾ࡙ࡓࡍࠩᏪ")
		BBn5MeXCPD = kFcsbIlVJDSA1mTOof4(z5nOUetfoJHbP6294ghwur,y2SIoiHRUhNMmqPYjrwA3TWg69pxV,RZ2SwHp6GQvAy,skD7g3FxW4wCa5BR,c0ApgT8hP5FOJ,pDxy6XBiWkz08,n38oH7wd6BDyAMJQS,ag8rjZo1Vz4IPdcOT,ag8rjZo1Vz4IPdcOT)
	elif sqAWIiRPd0TUV75EyCo26JhD38ZN4O==LZWMikPEB81KSGyxfJtUsCA(u"࠸ᝅ"):
		scraperserver = c2RKu0xG1eC8MiohyE(u"ࠪࡷࡨࡸࡡࡱࡧࡲࡴࡸ࠹ࠧᏫ")
		y2SIoiHRUhNMmqPYjrwA3TWg69pxV = c2RKu0xG1eC8MiohyE(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡶࡲࡰࡺࡼ࠲ࡸࡩࡲࡢࡲࡨࡳࡵࡹ࠮ࡪࡱ࠲ࡺ࠶࠵࠿ࡢࡲ࡬ࡣࡰ࡫ࡹ࠾࠵࠼࠽࠶࡫࠹ࡤ࠷࠰࠻ࡪ࡫࠳࠮࠶ࡨࡩ࠷࠳࠸࠵ࡥ࠳࠱࡫ࡪ࠷࠺࠴ࡥࡥࡩࡪ࠳ࡥ࠷ࠩࡧࡴࡻ࡮ࡵࡴࡼࡁ࡮ࡲࠦࡶࡴ࡯ࡁࠬᏬ")+BUKlErdIu7Ggqcz3jYpf09wMePF4V(WSQlG8mDhqsNe)
		BBn5MeXCPD = kFcsbIlVJDSA1mTOof4(Ie5s2cBtSfdHjzQ4rA9kYlo6D18(u"ࠬࡍࡅࡕࠩᏭ"),y2SIoiHRUhNMmqPYjrwA3TWg69pxV,RZ2SwHp6GQvAy,skD7g3FxW4wCa5BR,c0ApgT8hP5FOJ,pDxy6XBiWkz08,n38oH7wd6BDyAMJQS,ag8rjZo1Vz4IPdcOT,ag8rjZo1Vz4IPdcOT)
	elif sqAWIiRPd0TUV75EyCo26JhD38ZN4O==aXqWLoTdVgME(u"࠺ᝆ"):
		scraperserver = Ie5s2cBtSfdHjzQ4rA9kYlo6D18(u"࠭ࡳࡤࡴࡤࡴ࡮ࡴࡧࡢࡰࡷ࠶ࠬᏮ")
		ZTnaBus8HPRQ5UzFyjwciWAG17KdJ = rNdBKI74fAklnoCZ6(u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡴࡥࡵࡥࡵ࡯࡮ࡨࡣࡱࡸࠫࡶࡲࡰࡺࡼࡣࡨࡵࡵ࡯ࡶࡵࡽࡂࡇࡅࠧࡴࡨࡸࡺࡸ࡮ࡠࡲࡤ࡫ࡪࡥࡳࡰࡷࡵࡧࡪࡃࡴࡳࡷࡨࠪ࡫ࡵࡲࡸࡣࡵࡨࡤ࡮ࡥࡢࡦࡨࡶࡸࡃࡴࡳࡷࡨ࠾࠷ࡨ࠳࠵࠲ࡤ࠺࠽࠿࠰ࡢ࠷࠷࠴࠶ࡪࡢࡤ࠵࠺࠶ࡨ࠷࠱࠵࠷ࡧ࠽࠻࠸ࡥ࠹ࡂࡳࡶࡴࡾࡹ࠯ࡵࡦࡶࡦࡶࡩ࡯ࡩࡤࡲࡹ࠴ࡣࡰ࡯࠽࠼࠵࠾࠰ࠨᏯ")
		y2SIoiHRUhNMmqPYjrwA3TWg69pxV = WSQlG8mDhqsNe+qqzwE6imYG4c2xojI(u"ࠨࡾࡿࡑࡾࡖࡲࡰࡺࡼ࡙ࡷࡲ࠽ࠨᏰ")+ZTnaBus8HPRQ5UzFyjwciWAG17KdJ+kYDaz79TFlXoR(u"ࠩࡿࢀࡓࡵࡖࡦࡴ࡬ࡪࡾ࡙ࡓࡍࠩᏱ")
		BBn5MeXCPD = kFcsbIlVJDSA1mTOof4(z5nOUetfoJHbP6294ghwur,y2SIoiHRUhNMmqPYjrwA3TWg69pxV,RZ2SwHp6GQvAy,skD7g3FxW4wCa5BR,c0ApgT8hP5FOJ,pDxy6XBiWkz08,n38oH7wd6BDyAMJQS,ag8rjZo1Vz4IPdcOT,ag8rjZo1Vz4IPdcOT)
	elif sqAWIiRPd0TUV75EyCo26JhD38ZN4O==tQMjXKCA5dN4xq3beVIzaEoWkFLg(u"࠳࠳ᝇ"):
		scraperserver = l1DZAt9XNQjqE7YOdrz(u"ࠪࡷࡨࡸࡡࡱࡲࡨࡽࠬᏲ")
		BBRZVm4dOeTsJkbL83wMWhFDor2yj = skD7g3FxW4wCa5BR.copy()
		BBRZVm4dOeTsJkbL83wMWhFDor2yj.update({l32dnTEOU1skGKqeBtI9hmo(u"ࠫ࡝࠳ࡒࡢࡲ࡬ࡨࡦࡶࡩ࠮ࡊࡲࡷࡹ࠭Ᏻ"):dJHDqiKf12TXlIzSLkGUuxg4MBs3A(u"ࠬࡹࡣࡳࡣࡳࡴࡪࡿ࠭ࡤࡱࡰ࠲ࡵ࠴ࡲࡢࡲ࡬ࡨࡦࡶࡩ࠯ࡥࡲࡱࠬᏴ"),CC1eY6yWZUwf2TkRvnp7EJ0AimjHBX(u"࠭ࡘ࠮ࡔࡤࡴ࡮ࡪࡡࡱ࡫࠰ࡏࡪࡿࠧᏵ"):DaFZHsThGmd0zv6e(u"ࠧ࠵࠶ࡩ࠸࠵࠾ࡤ࠵ࡣ࠵ࡱࡸ࡮࠱ࡣ࠵ࡥࡨ࠹࠿ࡡ࠷࠶࠻࠵࠼࡬࠵ࡱ࠳࠳࠵࠵࠹ࡦ࡫ࡵࡱ࠸ࡦ࠺࠱࠸ࡨࡦ࠹࠸࠶࠴࠳ࠩ᏶"),viRJWOC5jsYe84(u"ࠨࡅࡲࡲࡹ࡫࡮ࡵ࠯ࡗࡽࡵ࡫ࠧ᏷"):tQMjXKCA5dN4xq3beVIzaEoWkFLg(u"ࠩࡤࡴࡵࡲࡩࡤࡣࡷ࡭ࡴࡴ࠯࡫ࡵࡲࡲࠬᏸ")})
		bZq83DEzAKGxJk4QaUV7w6WuhCj = RZ2SwHp6GQvAy.copy()
		bZq83DEzAKGxJk4QaUV7w6WuhCj.update({dJHDqiKf12TXlIzSLkGUuxg4MBs3A(u"ࠪࡧࡲࡪࠧᏹ"):qoBMmfAWpFlK70xw8ZRh4naJ(u"ࠫࡷ࡫ࡱࡶࡧࡶࡸ࠳࠭ᏺ")+z5nOUetfoJHbP6294ghwur.lower(),qqzwE6imYG4c2xojI(u"ࠬࡻࡲ࡭ࠩᏻ"):BUKlErdIu7Ggqcz3jYpf09wMePF4V(WSQlG8mDhqsNe)})
		SKG8IuitXC2ELFVdlkWDw = A3AFYmgZLXn4MBab.dumps(bZq83DEzAKGxJk4QaUV7w6WuhCj)
		y2SIoiHRUhNMmqPYjrwA3TWg69pxV = BRWqdruz2A0(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡴࡥࡵࡥࡵࡶࡥࡺ࠯ࡦࡳࡲ࠴ࡰ࠯ࡴࡤࡴ࡮ࡪࡡࡱ࡫࠱ࡧࡴࡳ࠯ࡢࡲ࡬࠳ࡻ࠷ࠧᏼ")
		BBn5MeXCPD = kFcsbIlVJDSA1mTOof4(DaFZHsThGmd0zv6e(u"ࠧࡑࡑࡖࡘࠬᏽ"),y2SIoiHRUhNMmqPYjrwA3TWg69pxV,SKG8IuitXC2ELFVdlkWDw,BBRZVm4dOeTsJkbL83wMWhFDor2yj,c0ApgT8hP5FOJ,pDxy6XBiWkz08,n38oH7wd6BDyAMJQS,ag8rjZo1Vz4IPdcOT,ag8rjZo1Vz4IPdcOT)
		try:
			qDfPS0MjocvJkUZn = A3AFYmgZLXn4MBab.loads(BBn5MeXCPD.content)
			BBn5MeXCPD.content = qDfPS0MjocvJkUZn[BRWqdruz2A0(u"ࠨࡵࡲࡰࡺࡺࡩࡰࡰࠪ᏾")][mmV2nucZ5Lpl6FO1JMPEqGoQKW(u"ࠩࡵࡩࡸࡶ࡯࡯ࡵࡨࠫ᏿")]
		except: pass
	elif sqAWIiRPd0TUV75EyCo26JhD38ZN4O==iNc3KxwErnQ(u"࠴࠵ᝈ"):
		scraperserver = lljaEqwTVtmKsQcOrbXxS5hgNH(u"ࠪࡶࡪࡶ࡬ࡪࡶ࠳࠵ࠬ᐀")
		BBRZVm4dOeTsJkbL83wMWhFDor2yj = skD7g3FxW4wCa5BR.copy()
		BBRZVm4dOeTsJkbL83wMWhFDor2yj.update({viRJWOC5jsYe84(u"ࠫࡆ࡜࠭ࡆࡰࡦࡶࡾࡶࡴࡪࡱࡱࠫᐁ"):IaBhDMJc17302LgSvyxd(u"ࠬ࡜ࡥࡳࡵ࡬ࡳࡳࠦ࠲࠯࠲ࠪᐂ")})
		BBRZVm4dOeTsJkbL83wMWhFDor2yj.update({Ie5s2cBtSfdHjzQ4rA9kYlo6D18(u"࠭ࡃࡰࡰࡷࡩࡳࡺ࠭ࡕࡻࡳࡩࠬᐃ"):sjtU6GZQg5XC2pH4(u"ࠧࡢࡲࡳࡰ࡮ࡩࡡࡵ࡫ࡲࡲ࠴ࡰࡳࡰࡰࠪᐄ")})
		bZq83DEzAKGxJk4QaUV7w6WuhCj = {l32dnTEOU1skGKqeBtI9hmo(u"ࠨࡱࡸࡸࡵࡻࡴࠨᐅ"):zYvEaigKWjoq50pXBLDbGJkFc(u"ࠩ࡫ࡸࡲࡲࠧᐆ"),ee86G9ladLHVbh5mikzCo(u"ࠪࡹࡷࡲࠧᐇ"):WSQlG8mDhqsNe}
		bZq83DEzAKGxJk4QaUV7w6WuhCj = A3AFYmgZLXn4MBab.dumps(bZq83DEzAKGxJk4QaUV7w6WuhCj)
		bZq83DEzAKGxJk4QaUV7w6WuhCj = jVd7bxvBqOp2LZKRlSFY(bZq83DEzAKGxJk4QaUV7w6WuhCj)
		y2SIoiHRUhNMmqPYjrwA3TWg69pxV = LZWMikPEB81KSGyxfJtUsCA(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴࡬࠹ࡧ࠺࠴࠻࠼࠺࠭ࡢࡤ࠼࠼࠲࠺࠱ࡥ࠴࠰࠼࠼࠶ࡤ࠮࠸࠵࠹ࡧ࠾࠴࠷࠷࠵࠹࠸࠷࠭࠱࠲࠰࠵ࡲ࡯ࡣ࠵ࡦࡨࡰࡱ࡭ࡣࡣࡴ࠱࡮ࡦࡴࡥࡸࡣࡼ࠲ࡷ࡫ࡰ࡭࡫ࡷ࠲ࡩ࡫ࡶ࠰ࡨࡨࡸࡨ࡮ࠧᐈ")
		BBn5MeXCPD = kFcsbIlVJDSA1mTOof4(kYDaz79TFlXoR(u"ࠬࡖࡏࡔࡖࠪᐉ"),y2SIoiHRUhNMmqPYjrwA3TWg69pxV,bZq83DEzAKGxJk4QaUV7w6WuhCj,BBRZVm4dOeTsJkbL83wMWhFDor2yj,c0ApgT8hP5FOJ,pDxy6XBiWkz08,n38oH7wd6BDyAMJQS,ag8rjZo1Vz4IPdcOT,ag8rjZo1Vz4IPdcOT)
	elif sqAWIiRPd0TUV75EyCo26JhD38ZN4O==ee86G9ladLHVbh5mikzCo(u"࠵࠷ᝉ"):
		scraperserver = qoBMmfAWpFlK70xw8ZRh4naJ(u"࠭ࡲࡢࡥ࡮ࡲࡪࡸࡤ࠱࠳ࠪᐊ")
		BBRZVm4dOeTsJkbL83wMWhFDor2yj = skD7g3FxW4wCa5BR.copy()
		BBRZVm4dOeTsJkbL83wMWhFDor2yj.update({mmV2nucZ5Lpl6FO1JMPEqGoQKW(u"ࠧࡄࡱࡱࡸࡪࡴࡴ࠮ࡖࡼࡴࡪ࠭ᐋ"):qqzwE6imYG4c2xojI(u"ࠨࡣࡳࡴࡱ࡯ࡣࡢࡶ࡬ࡳࡳ࠵࡯ࡤࡶࡨࡸ࠲ࡹࡴࡳࡧࡤࡱࠬᐌ")})
		BBRZVm4dOeTsJkbL83wMWhFDor2yj.update({V3VlkhgjEF4n1erPXHcC0NOsfwyAJ(u"ࠩࡄࡧࡨ࡫ࡰࡵ࠯ࡈࡲࡨࡵࡤࡪࡰࡪࠫᐍ"):l1DZAt9XNQjqE7YOdrz(u"ࠪ࡫ࡿ࡯ࡰ࠭ࠢࡧࡩ࡫ࡲࡡࡵࡧ࠯ࠤࡧࡸࠧᐎ")})
		BBRZVm4dOeTsJkbL83wMWhFDor2yj.update({viRJWOC5jsYe84(u"ࠫࡆ࡜࠭ࡆࡰࡦࡶࡾࡶࡴࡪࡱࡱࠫᐏ"):UVa3fJw7k6KM(u"ࠬ࡜ࡥࡳࡵ࡬ࡳࡳࠦ࠲࠯࠲ࠪᐐ")})
		bZq83DEzAKGxJk4QaUV7w6WuhCj = {UUDAiytEL76RTmMYsuIz5evXB(u"࠭ࡵࡳ࡮ࠪᐑ"):WSQlG8mDhqsNe,kYDaz79TFlXoR(u"ࠧࡸࡣ࡬ࡸࠬᐒ"):gBExoceumj4y8bFW9hY2aNMVSr,UVa3fJw7k6KM(u"ࠨࡪࡨࡥࡩ࡫ࡲࡴࠩᐓ"):skD7g3FxW4wCa5BR}
		bZq83DEzAKGxJk4QaUV7w6WuhCj = A3AFYmgZLXn4MBab.dumps(bZq83DEzAKGxJk4QaUV7w6WuhCj)
		bZq83DEzAKGxJk4QaUV7w6WuhCj = jVd7bxvBqOp2LZKRlSFY(bZq83DEzAKGxJk4QaUV7w6WuhCj)
		y2SIoiHRUhNMmqPYjrwA3TWg69pxV = CC1eY6yWZUwf2TkRvnp7EJ0AimjHBX(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡶࡩࡷࡼࡥࡳ࠴࠱࡯ࡴࡪࡩࡦ࡯ࡤࡨ࠳࡬ࡲࡦࡧࡧࡨࡳࡹ࠮ࡰࡴࡪ࠾࠶࠾࠱࠶࠱ࡩࡩࡹࡩࡨࠨᐔ")
		BBn5MeXCPD = kFcsbIlVJDSA1mTOof4(aXqWLoTdVgME(u"ࠪࡔࡔ࡙ࡔࠨᐕ"),y2SIoiHRUhNMmqPYjrwA3TWg69pxV,bZq83DEzAKGxJk4QaUV7w6WuhCj,BBRZVm4dOeTsJkbL83wMWhFDor2yj,c0ApgT8hP5FOJ,pDxy6XBiWkz08,n38oH7wd6BDyAMJQS,ag8rjZo1Vz4IPdcOT,ag8rjZo1Vz4IPdcOT)
		update = ag8rjZo1Vz4IPdcOT
	else:
		scraperserver,y2SIoiHRUhNMmqPYjrwA3TWg69pxV = qpFY4hAwolV3,qpFY4hAwolV3
		BBn5MeXCPD = qvfZXAI81kwTueoFgnOhWazdBR()
		BBn5MeXCPD.succeeded = ag8rjZo1Vz4IPdcOT
		update = ag8rjZo1Vz4IPdcOT
	if not BBn5MeXCPD.content or lljaEqwTVtmKsQcOrbXxS5hgNH(u"ࠫࡻ࡫ࡲࡪࡨࡼ࠲࡭ࡺ࡭࡭ࡁࡵࡩࡩ࡯ࡲࡦࡥࡷࡁࠬᐖ") in WSQlG8mDhqsNe: BBn5MeXCPD.succeeded = ag8rjZo1Vz4IPdcOT
	BBn5MeXCPD.scrapernumber = str(sqAWIiRPd0TUV75EyCo26JhD38ZN4O)
	scraperserver = scraperserver+fWoVd0Bmtkx(u"ࠬࠦ࠺ࠡࠩᐗ")+str(sqAWIiRPd0TUV75EyCo26JhD38ZN4O)
	BBn5MeXCPD.scraperserver = scraperserver
	BBn5MeXCPD.scraperurl = y2SIoiHRUhNMmqPYjrwA3TWg69pxV
	if BBn5MeXCPD.succeeded:
		if not i4bFG3rKE6.scrapers_succeeded:
			t8yiLuJp3cBA6d1QE9x7eZ4fa(DaFZHsThGmd0zv6e(u"࠭ๆอฯอࠤ฾๋ไ๋หࠣฮัอ่ำࠢส่าาศࠨᐘ"),is6KpcAFPM8jJNHqtS,s7FnXZYOgexlH2MPb8BJck1AKv9=ee86G9ladLHVbh5mikzCo(u"࠶࠶࠰ᝊ"))
			LLvyStW429DEZKlA(d3MGHW41fvNz6rRFYix2anS,lTW9p1v7uPfOxB(Q8Q0IDc6PLZajJAdTntKUmSGXz)+DaFZHsThGmd0zv6e(u"ࠧࠡࠢࠣࡗࡺࡩࡣࡦࡧࡧࡩࡩࠦࡢࡺࡲࡤࡷࡸࠦࡢ࡭ࡱࡦ࡯࡮ࡴࡧࠡࠢࠣࡗࡪࡸࡶࡦࡴ࠽ࠤࡠࠦࠧᐙ")+scraperserver+DiJ8CMuYH1daWyjehfN0L(u"ࠨࠢࡠࠤࠥࠦࡓࡰࡷࡵࡧࡪࡀࠠ࡜ࠢࠪᐚ")+n38oH7wd6BDyAMJQS+ee86G9ladLHVbh5mikzCo(u"ࠩࠣࡡࠥࠦࠠࡖࡔࡏ࠾ࠥࡡࠠࠨᐛ")+jqVJT12oeDhiwf0+rNdBKI74fAklnoCZ6(u"ࠪࠤࡢ࠭ᐜ"))
	else:
		if not i4bFG3rKE6.scrapers_succeeded:
			t8yiLuJp3cBA6d1QE9x7eZ4fa(CC1eY6yWZUwf2TkRvnp7EJ0AimjHBX(u"ࠫๆฺไหࠢ฼้้๐ษࠡฬฯหํุࠠศๆะะอ࠭ᐝ"),is6KpcAFPM8jJNHqtS,s7FnXZYOgexlH2MPb8BJck1AKv9=YY8UDX3MJhb91AHw7fg(u"࠷࠰࠱ᝋ"))
			LLvyStW429DEZKlA(j8gFJIMYPoBzcCvG9T,lTW9p1v7uPfOxB(Q8Q0IDc6PLZajJAdTntKUmSGXz)+tR1krDGPpO025fghMT3a7UnYj(u"ࠬࠦࠠࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡤࡼࡴࡦࡹࡳࠡࡤ࡯ࡳࡨࡱࡩ࡯ࡩࠣࠤ࡙ࠥࡥࡳࡸࡨࡶ࠿࡛ࠦࠡࠩᐞ")+scraperserver+rNdBKI74fAklnoCZ6(u"࠭ࠠ࡞ࠢࠣࠤࡈࡵࡤࡦ࠼ࠣ࡟ࠥ࠭ᐟ")+str(BBn5MeXCPD.code)+IaBhDMJc17302LgSvyxd(u"ࠧࠡ࡟ࠣࠤࠥࡘࡥࡢࡵࡲࡲ࠿࡛ࠦࠡࠩᐠ")+BBn5MeXCPD.reason+V3VlkhgjEF4n1erPXHcC0NOsfwyAJ(u"ࠨࠢࡠࠤࠥࠦࡓࡰࡷࡵࡧࡪࡀࠠ࡜ࠢࠪᐡ")+n38oH7wd6BDyAMJQS+ddiCzu6yahj5RtTISMJ48sNnZBU(u"ࠩࠣࡡࠥࠦࠠࡖࡔࡏ࠾ࠥࡡࠠࠨᐢ")+jqVJT12oeDhiwf0+ee86G9ladLHVbh5mikzCo(u"ࠪࠤࡢ࠭ᐣ"))
		if update:
			F6IQPG2JndWkujf5M4mgb(KqJdrnE68y,qgwkQvdFcBJYoyuE7p1CU,Z0bQKOAD5c41yg9zER2p,[],sqAWIiRPd0TUV75EyCo26JhD38ZN4O)
	global uVPxDzsb01Ktp9ow,zOhrEeUAIF6dToHJg0Rt
	uVPxDzsb01Ktp9ow[sqAWIiRPd0TUV75EyCo26JhD38ZN4O] = BBn5MeXCPD.succeeded
	zOhrEeUAIF6dToHJg0Rt[sqAWIiRPd0TUV75EyCo26JhD38ZN4O] = BBn5MeXCPD
	return BBn5MeXCPD
def F6IQPG2JndWkujf5M4mgb(KqJdrnE68y,qgwkQvdFcBJYoyuE7p1CU,Z0bQKOAD5c41yg9zER2p,bbSJY3nfcN04K7GVr=[],OrBgQ9HjkzDc1=H1k0Fmba4Gfiynp8AML):
	BYIbCZdRwV820c3 = V3VlkhgjEF4n1erPXHcC0NOsfwyAJ(u"࠵ᝌ")
	KLRQ7TU5DC1HsySNecJ2p6gBq8 = UUDAiytEL76RTmMYsuIz5evXB(u"࠶ᝍ")
	ykHvMXQI2VGAKtL70doSpNmW6 = []
	pwVA7J9dMKva = [vvXoMLlg513]+[vvXoMLlg513]*KqJdrnE68y
	iYqe8B01ZC4SrULWvuGKHEtaT = XXyMBNAVJvKiq7jc20bEw6(WoFsvbmUlDZp7PzRfdGknCV,kYDaz79TFlXoR(u"ࠫࡩ࡯ࡣࡵࠩᐤ"),V3VlkhgjEF4n1erPXHcC0NOsfwyAJ(u"࡙ࠬࡃࡓࡃࡓࡉࡗ࡙ࠧᐥ"))
	for gyX0GYpNwCEZuL5kDe3f6vHtSaPmO in list(iYqe8B01ZC4SrULWvuGKHEtaT.keys()):
		if Z0bQKOAD5c41yg9zER2p not in gyX0GYpNwCEZuL5kDe3f6vHtSaPmO: continue
		j7HgbsXoUDfzcSkmniPu9w6,OLMjUYdHr1FVhksw = gyX0GYpNwCEZuL5kDe3f6vHtSaPmO.split(viRJWOC5jsYe84(u"࠭࡟ࡠࠩᐦ"))
		pwVA7J9dMKva[int(OLMjUYdHr1FVhksw)] = iYqe8B01ZC4SrULWvuGKHEtaT[gyX0GYpNwCEZuL5kDe3f6vHtSaPmO]
	for z1WESm8iYpqd6UD7wx2osC in range(KqJdrnE68y):
		if z1WESm8iYpqd6UD7wx2osC in i4bFG3rKE6.BADSCRAPERS+bbSJY3nfcN04K7GVr: continue
		if z1WESm8iYpqd6UD7wx2osC==OrBgQ9HjkzDc1: pwVA7J9dMKva[z1WESm8iYpqd6UD7wx2osC] = pwVA7J9dMKva[z1WESm8iYpqd6UD7wx2osC]+zYvEaigKWjoq50pXBLDbGJkFc(u"࠳ᝎ")
		if pwVA7J9dMKva[z1WESm8iYpqd6UD7wx2osC]<BYIbCZdRwV820c3: ykHvMXQI2VGAKtL70doSpNmW6 += [z1WESm8iYpqd6UD7wx2osC]*qgwkQvdFcBJYoyuE7p1CU[z1WESm8iYpqd6UD7wx2osC]
	if not ykHvMXQI2VGAKtL70doSpNmW6:
		for z1WESm8iYpqd6UD7wx2osC in range(KqJdrnE68y):
			pwVA7J9dMKva[z1WESm8iYpqd6UD7wx2osC] = vvXoMLlg513
			if z1WESm8iYpqd6UD7wx2osC in i4bFG3rKE6.BADSCRAPERS+bbSJY3nfcN04K7GVr: continue
			ykHvMXQI2VGAKtL70doSpNmW6 += [z1WESm8iYpqd6UD7wx2osC]*qgwkQvdFcBJYoyuE7p1CU[z1WESm8iYpqd6UD7wx2osC]
	for z1WESm8iYpqd6UD7wx2osC in i4bFG3rKE6.BADSCRAPERS:
		if z1WESm8iYpqd6UD7wx2osC<KqJdrnE68y: pwVA7J9dMKva[z1WESm8iYpqd6UD7wx2osC] = qoBMmfAWpFlK70xw8ZRh4naJ(u"࠼࠽࠾࠿ᝏ")
	dJyEmigjCLvZ5tKhc2Yf = []
	for z1WESm8iYpqd6UD7wx2osC in range(KqJdrnE68y): dJyEmigjCLvZ5tKhc2Yf.append(Z0bQKOAD5c41yg9zER2p+zYvEaigKWjoq50pXBLDbGJkFc(u"ࠧࡠࡡࠪᐧ")+str(z1WESm8iYpqd6UD7wx2osC))
	zOYMaQ0NgdiRVwDJXh8e(WoFsvbmUlDZp7PzRfdGknCV,c2RKu0xG1eC8MiohyE(u"ࠨࡕࡆࡖࡆࡖࡅࡓࡕࠪᐨ"),dJyEmigjCLvZ5tKhc2Yf,pwVA7J9dMKva,nzubSpWFkex4JjGqEYr*KLRQ7TU5DC1HsySNecJ2p6gBq8,gBExoceumj4y8bFW9hY2aNMVSr)
	return ykHvMXQI2VGAKtL70doSpNmW6
def VTJoICBmqYhF(s1L4086uUzlXvQeFCZkYiNVRcA3jtJ,z5nOUetfoJHbP6294ghwur,WSQlG8mDhqsNe,RZ2SwHp6GQvAy,skD7g3FxW4wCa5BR,c0ApgT8hP5FOJ,pDxy6XBiWkz08,n38oH7wd6BDyAMJQS,XSRoBuFEbKvZH6meTNCJx7LwQi=qpFY4hAwolV3,AGUTOIbFi4tDB1=qpFY4hAwolV3,bbSJY3nfcN04K7GVr=[]):
	KqJdrnE68y = mmV2nucZ5Lpl6FO1JMPEqGoQKW(u"࠵࠸ᝐ")
	qgwkQvdFcBJYoyuE7p1CU = [l1DZAt9XNQjqE7YOdrz(u"࠶ᝑ"),l1DZAt9XNQjqE7YOdrz(u"࠶ᝑ"),l1DZAt9XNQjqE7YOdrz(u"࠶ᝑ"),rNdBKI74fAklnoCZ6(u"࠷࠰ᝒ"),IaBhDMJc17302LgSvyxd(u"࠵ᝓ"),rNdBKI74fAklnoCZ6(u"࠷࠰ᝒ"),l1DZAt9XNQjqE7YOdrz(u"࠶ᝑ"),l1DZAt9XNQjqE7YOdrz(u"࠶ᝑ"),l1DZAt9XNQjqE7YOdrz(u"࠶ᝑ"),IaBhDMJc17302LgSvyxd(u"࠵ᝓ"),l1DZAt9XNQjqE7YOdrz(u"࠶ᝑ"),ddiCzu6yahj5RtTISMJ48sNnZBU(u"࠲᝕"),l32dnTEOU1skGKqeBtI9hmo(u"࠶࠲᝔")]
	Z0bQKOAD5c41yg9zER2p = n38oH7wd6BDyAMJQS.split(lljaEqwTVtmKsQcOrbXxS5hgNH(u"ࠩ࠰ࠫᐩ"))[vvXoMLlg513]
	T56OU2t4iJEhaVDY = F6IQPG2JndWkujf5M4mgb(KqJdrnE68y,qgwkQvdFcBJYoyuE7p1CU,Z0bQKOAD5c41yg9zER2p)
	args = z5nOUetfoJHbP6294ghwur,WSQlG8mDhqsNe,RZ2SwHp6GQvAy,skD7g3FxW4wCa5BR,c0ApgT8hP5FOJ,pDxy6XBiWkz08,n38oH7wd6BDyAMJQS,XSRoBuFEbKvZH6meTNCJx7LwQi,AGUTOIbFi4tDB1
	global uVPxDzsb01Ktp9ow,zOhrEeUAIF6dToHJg0Rt
	uVPxDzsb01Ktp9ow,zOhrEeUAIF6dToHJg0Rt = [],[]
	for z1WESm8iYpqd6UD7wx2osC in range(KqJdrnE68y):
		uVPxDzsb01Ktp9ow.append(ag8rjZo1Vz4IPdcOT)
		zOhrEeUAIF6dToHJg0Rt.append(qvfZXAI81kwTueoFgnOhWazdBR())
	TuGle5OoE2I3 = gdPslyFW8ITBcpA302.getSetting(fWoVd0Bmtkx(u"ࠪࡥࡻ࠴ࡳࡵࡣࡷࡹࡸ࠴ࡡࡶࡶࡲࡷࡨࡸࡡࡱࡧࡵࡷࠬᐪ"))
	if TuGle5OoE2I3!=rNdBKI74fAklnoCZ6(u"ࠫࡘ࡚ࡏࡑࠩᐫ"):
		oFZTcs6KM1VRI4i = [viRJWOC5jsYe84(u"࠴࠶᝖")]
		CCmGLK4gl93PzSZ1jhWiMDn = [crdvWATbou1QjghIsFlft2 for crdvWATbou1QjghIsFlft2 in oFZTcs6KM1VRI4i if crdvWATbou1QjghIsFlft2 in T56OU2t4iJEhaVDY]
		if CCmGLK4gl93PzSZ1jhWiMDn:
			sqAWIiRPd0TUV75EyCo26JhD38ZN4O = P9Kfwdgna8erGcAWyQMOtFbq6Rk.choice(CCmGLK4gl93PzSZ1jhWiMDn)
			BBn5MeXCPD = VmRkyuTWprQUebn7zPYh2LJ(sqAWIiRPd0TUV75EyCo26JhD38ZN4O,KqJdrnE68y,qgwkQvdFcBJYoyuE7p1CU,args)
			if BBn5MeXCPD.succeeded: return BBn5MeXCPD
			qgwkQvdFcBJYoyuE7p1CU[sqAWIiRPd0TUV75EyCo26JhD38ZN4O] = vvXoMLlg513
	YzK5Mnda6GwuX1LHeI = oqreTDvbVOcSE342g5IfwJx()
	if s1L4086uUzlXvQeFCZkYiNVRcA3jtJ==vvXoMLlg513: o4oUxD3u18K59ghHIY = gBExoceumj4y8bFW9hY2aNMVSr
	elif s1L4086uUzlXvQeFCZkYiNVRcA3jtJ==mZi0S72jGoHpLO:
		YzK5Mnda6GwuX1LHeI.code = -DAE6vkyhXGx1wBdHmcFfTVQpL0l
		tN4JypEOrUVHgz796BKwqGuLQx0 = UUDAiytEL76RTmMYsuIz5evXB(u"ࠬํะ่ࠢสฺ่็อสࠢ็หࠥ๐ๅไ่ࠣะ้ฮ็ศ่๊ࠢࠥอไฦ่อี๋ะࠠศๆัหฺࠦศไࠢ็วู๋ࠦๅ์๊หࠥำฬษࠢํ้๋฿ࠠอ็ํ฽ࠥฮัศ็ฯࠤฬ๊ใ้็ห๎ํะัࠡ็้ࠤั๊ศ๊ࠡไฮา่ࠦศีอาิอๅ้ࠡำ๋ࠥอไึใะหฯࠦ࠮࠯ࠢหี๋อๅอࠢ฼้ฬี๋ࠠีอ฻๏฿ࠠฤ่ࠣ๎ัืศࠡษึฮำีวๆࠢศ๊ฯืๆหࠢฦาึ๏ࠠๅๅ้ࠤ้อ๋๊ࠠฯำࠥ฼ๅศ่ࠣฬฬ๊ๆอษะࡠࡳ࠭ᐬ")+IQ2KCmObsTGuiRdEzt931a40jLg+ddiCzu6yahj5RtTISMJ48sNnZBU(u"࠭ࡅࡳࡴࡲࡶࠥࡉ࡯ࡥࡧ࠽ࠤࠥ࠭ᐭ")+str(YzK5Mnda6GwuX1LHeI.code)+fF4lt9zWYxXLKZVyAco82PgMj+ZLwoRpfnCWI7FgEHsz6te39lMVh+xupTj02bvy3O8R+kYDaz79TFlXoR(u"่ࠧๆࠣฮึ๐ฯࠡ็ะหํ๊ษࠡษึฮำีวๆࠢศ๊ฯืๆหࠢฦาึ๏ࠠๅฬฯหํุࠠศๆะะอࠦฟࠢࠣ࡟ࡲ่࠭ฯࠡฬะฮฬาࠠ࠷࠲ࠣฯฬ์๊สࠫࠪᐮ")+fF4lt9zWYxXLKZVyAco82PgMj
		o4oUxD3u18K59ghHIY = VVpbtSKYUGXrNMwAWFo9IOjZP(qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,GLTtERWbHnFuy4PCp,tN4JypEOrUVHgz796BKwqGuLQx0)
	elif s1L4086uUzlXvQeFCZkYiNVRcA3jtJ==Zwqio2AIWlD5etFa:
		YzK5Mnda6GwuX1LHeI.code = -wn4bG51vUENfaS0Zg
		tN4JypEOrUVHgz796BKwqGuLQx0 = LZWMikPEB81KSGyxfJtUsCA(u"ࠨๆา๎่ࠦๅีๅ็อࠥ็๊ࠡษ็ษ๋ะั็ฬࠣฮ๊์ูࠡใอัࠥฮูืุࠢๅาอสࠡษ็ษ๋ะั็ฬࠣห้฼ั้ำํอࠥ࠴࠮้ࠡำ๋ࠥอไๆึๆ่ฮࠦโะࠢอ็ํ์ࠠๆ่ࠣห้ืว้ฬิࠤ฾์ฯไࠢฦ์๋ࠥๆࠡสิ๊ฬ๋ฬࠡ฻้ำ่ࠦร้่๊ࠢࠥา็ศิࠣ฽๋ีใ๊ࠡ฻๎ๆะ็ࠡษ็ั๊อ๊สูࠢำࠥอไโ์ิ์ุอสࠡล๋ࠤ฻ีࠠศๆอะุูࠠฤฺ๊ࠣิࠦวๅสิห๊าࠠศๆ่ศี๐ษࠡ࠰࠱ࠤ้ำไࠡษ็ู้้ไสࠢํะอࠦล๋ไสๅࠥํะ่ࠢส่า๋ว๋หࠣห้ิวุศฬࡠࡳ࠭ᐯ")+IQ2KCmObsTGuiRdEzt931a40jLg+tR1krDGPpO025fghMT3a7UnYj(u"ࠩࡈࡶࡷࡵࡲࠡࡅࡲࡨࡪࡀࠠࠡࠩᐰ")+str(YzK5Mnda6GwuX1LHeI.code)+fF4lt9zWYxXLKZVyAco82PgMj+ZLwoRpfnCWI7FgEHsz6te39lMVh+xupTj02bvy3O8R+lljaEqwTVtmKsQcOrbXxS5hgNH(u"๋้ࠪࠦสา์าࠤ๊ำว้ๆฬࠤฬูสฯัส้ࠥหๆหำ้ฮࠥษฮา๋่ࠣฯาว้ิࠣห้๋ๆฺࠢยࠥࠦࡢ࡮ࠩไาࠤฯำสศฮࠣ࠺࠵ࠦหศ่ํอ࠮࠭ᐱ")+fF4lt9zWYxXLKZVyAco82PgMj
		o4oUxD3u18K59ghHIY = VVpbtSKYUGXrNMwAWFo9IOjZP(qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,GLTtERWbHnFuy4PCp,tN4JypEOrUVHgz796BKwqGuLQx0)
	if not o4oUxD3u18K59ghHIY:
		YzK5Mnda6GwuX1LHeI.succeeded = ag8rjZo1Vz4IPdcOT
		return YzK5Mnda6GwuX1LHeI
	Kit4z2JHoUdPvDcAfTkFeQsO0b = []
	def I8TWnRe7cAZDO6jBkUgJ():
		if any(uVPxDzsb01Ktp9ow): return gBExoceumj4y8bFW9hY2aNMVSr
		return ag8rjZo1Vz4IPdcOT
	for z1WESm8iYpqd6UD7wx2osC in range(KqJdrnE68y):
		if z1WESm8iYpqd6UD7wx2osC in T56OU2t4iJEhaVDY:
			FFJMOEpGgCIwSaUsrkZ9 = MqWf2atLi7QDnOF0YKuZhrE53gbv1(daemon=gBExoceumj4y8bFW9hY2aNMVSr,target=VmRkyuTWprQUebn7zPYh2LJ,args=(z1WESm8iYpqd6UD7wx2osC,KqJdrnE68y,qgwkQvdFcBJYoyuE7p1CU,args))
			Kit4z2JHoUdPvDcAfTkFeQsO0b.append(FFJMOEpGgCIwSaUsrkZ9)
	qpkEw8cVJd1lTritx7Z(Kit4z2JHoUdPvDcAfTkFeQsO0b,YY8UDX3MJhb91AHw7fg(u"࠺࠵᝗"),mZi0S72jGoHpLO,mZi0S72jGoHpLO,I8TWnRe7cAZDO6jBkUgJ)
	for z1WESm8iYpqd6UD7wx2osC in range(KqJdrnE68y):
		if uVPxDzsb01Ktp9ow[z1WESm8iYpqd6UD7wx2osC]:
			for Y8VNX0sWEbcB29lvZ in Kit4z2JHoUdPvDcAfTkFeQsO0b:
				try: Y8VNX0sWEbcB29lvZ.daemon = ag8rjZo1Vz4IPdcOT
				except: pass
				try: Y8VNX0sWEbcB29lvZ.setDaemon(ag8rjZo1Vz4IPdcOT)
				except: pass
			i4bFG3rKE6.scrapers_succeeded = gBExoceumj4y8bFW9hY2aNMVSr
			return zOhrEeUAIF6dToHJg0Rt[z1WESm8iYpqd6UD7wx2osC]
	return zOhrEeUAIF6dToHJg0Rt[vvXoMLlg513]
def SS6T9J80gPf(Z0bQKOAD5c41yg9zER2p):
	EaWoKlCYhmrS1wzTPb = XXyMBNAVJvKiq7jc20bEw6(WoFsvbmUlDZp7PzRfdGknCV,BRWqdruz2A0(u"ࠫࡱ࡯ࡳࡵࠩᐲ"),sjtU6GZQg5XC2pH4(u"ࠬࡈࡌࡐࡅࡎࡉࡉࡥࡗࡆࡄࡖࡍ࡙ࡋࡓࠨᐳ"))
	if Z0bQKOAD5c41yg9zER2p in EaWoKlCYhmrS1wzTPb: return
	zOYMaQ0NgdiRVwDJXh8e(WoFsvbmUlDZp7PzRfdGknCV,mmV2nucZ5Lpl6FO1JMPEqGoQKW(u"࠭ࡂࡍࡑࡆࡏࡊࡊ࡟ࡘࡇࡅࡗࡎ࡚ࡅࡔࠩᐴ"),Z0bQKOAD5c41yg9zER2p,gBExoceumj4y8bFW9hY2aNMVSr,ivLg9zRnGF83u)
	EaWoKlCYhmrS1wzTPb = EaWoKlCYhmrS1wzTPb+[Z0bQKOAD5c41yg9zER2p]
	UZHj1CuOIxPzAoTvcEV05d7NFi2G3m = bfLg2cN8FvsxWMeyj7q()
	F1KMGjNvHegbIJEs3fcOtwq = UZHj1CuOIxPzAoTvcEV05d7NFi2G3m.split(YY8UDX3MJhb91AHw7fg(u"ࠧ࠭࠮ࠪᐵ"))[Zwqio2AIWlD5etFa]
	xJyvEDcMaBj0Ph37b8WeIlNiU = {viRJWOC5jsYe84(u"ࠨࡷࡶࡩࡷ࠭ᐶ"):sizfDGP6wWXTc3p,CC1eY6yWZUwf2TkRvnp7EJ0AimjHBX(u"ࠩࡹࡩࡷࡹࡩࡰࡰࠪᐷ"):Q8q1YzIF6icWtSp2L,DaFZHsThGmd0zv6e(u"ࠪࡧࡴࡴࡴࡢ࡫ࡱࡩࡷ࠭ᐸ"):qpFY4hAwolV3,IaBhDMJc17302LgSvyxd(u"ࠫ࡮ࡺࡥ࡮ࠩᐹ"):qpFY4hAwolV3,c2RKu0xG1eC8MiohyE(u"ࠬࡼࡡ࡭ࡷࡨࠫᐺ"):qpFY4hAwolV3,l1DZAt9XNQjqE7YOdrz(u"࠭ࡣࡰࡷࡱࡸࡷࡿࠧᐻ"):F1KMGjNvHegbIJEs3fcOtwq,rNdBKI74fAklnoCZ6(u"ࠧࡱࡣࡵࡥࡲࡹ࡟ࡤࡱࡱࡸࡦ࡯࡮ࡦࡴࠪᐼ"):IaBhDMJc17302LgSvyxd(u"ࠨ࠰࠱ࡆࡑࡕࡃࡌࡇࡇࡣ࡚࡙ࡅࡓࡕࠪᐽ"),Ie5s2cBtSfdHjzQ4rA9kYlo6D18(u"ࠩࡳࡥࡷࡧ࡭ࡴࠩᐾ"):EaWoKlCYhmrS1wzTPb}
	aaBerJzFtlYMuoTXUIy = i4bFG3rKE6.SITESURLS[zYvEaigKWjoq50pXBLDbGJkFc(u"ࠪࡔ࡞࡚ࡈࡐࡐࠪᐿ")][lljaEqwTVtmKsQcOrbXxS5hgNH(u"࠶࠷᝘")]
	oF67yxKdB8nY3TiH9gAMvlOhaPSws0 = Tp3qzUdr8iNZYX1(ivLg9zRnGF83u,IaBhDMJc17302LgSvyxd(u"ࠫࡕࡕࡓࡕࠩᑀ"),aaBerJzFtlYMuoTXUIy,xJyvEDcMaBj0Ph37b8WeIlNiU,qpFY4hAwolV3,Ie5s2cBtSfdHjzQ4rA9kYlo6D18(u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡓࡆࡐࡇࡣࡇࡒࡏࡄࡍࡈࡈࡤ࡝ࡅࡃࡕࡌࡘࡊ࡙࡟ࡍࡋࡖࡘࡤ࡚ࡏࡠ࡙ࡈࡆࡈࡇࡃࡉࡇ࠰࠵ࡸࡺࠧᑁ"))
	return
def GMqfDK9V4F8eTPE1pNOAaiYUbhr(BigAz2Owj3arMN5J6RGFk8PTq,Cm4xfTO625jyMtZ8GEpvuKcnbQ1gD,dimhv1XTVH8UOrc9EGJZ6,ppuvkQrgA1i8WwY3ftNJx7Ba9jH,showDialogs,n38oH7wd6BDyAMJQS):
	if not dimhv1XTVH8UOrc9EGJZ6 or isinstance(dimhv1XTVH8UOrc9EGJZ6,dict): z5nOUetfoJHbP6294ghwur = CC1eY6yWZUwf2TkRvnp7EJ0AimjHBX(u"࠭ࡇࡆࡖࠪᑂ")
	else:
		z5nOUetfoJHbP6294ghwur = tR1krDGPpO025fghMT3a7UnYj(u"ࠧࡑࡑࡖࡘࠬᑃ")
		dimhv1XTVH8UOrc9EGJZ6 = cTt4u6reEMKZqVLplmkNW7(dimhv1XTVH8UOrc9EGJZ6)
		gr0v47sfpG,dimhv1XTVH8UOrc9EGJZ6 = D02sQSgOGhTJxtKyFEId74Nrv8bYU(dimhv1XTVH8UOrc9EGJZ6)
	lgDZd7ip5Ux = WWrExJZS3Bj4anOAkpv7(BigAz2Owj3arMN5J6RGFk8PTq,z5nOUetfoJHbP6294ghwur,Cm4xfTO625jyMtZ8GEpvuKcnbQ1gD,dimhv1XTVH8UOrc9EGJZ6,ppuvkQrgA1i8WwY3ftNJx7Ba9jH,gBExoceumj4y8bFW9hY2aNMVSr,showDialogs,n38oH7wd6BDyAMJQS)
	eVEX29oO0qZjxltJKIfbc8aSd = lgDZd7ip5Ux.content
	eVEX29oO0qZjxltJKIfbc8aSd = str(eVEX29oO0qZjxltJKIfbc8aSd)
	return eVEX29oO0qZjxltJKIfbc8aSd
def HSQlpuY1RZfmob4iqMP9kjeV5rch(Cm4xfTO625jyMtZ8GEpvuKcnbQ1gD):
	tAeR0rp7K61QEBlJg2HW4dSI9U = Cm4xfTO625jyMtZ8GEpvuKcnbQ1gD.split(ddiCzu6yahj5RtTISMJ48sNnZBU(u"ࠨࡾࡿࠫᑄ"))
	WSQlG8mDhqsNe,Hitbcw146SAGnegpqP5zrJUxTW8vBO,vLNaxndFy5jGkTiQhYX,KKf8YWi2FyGABj = tAeR0rp7K61QEBlJg2HW4dSI9U[vvXoMLlg513],H1k0Fmba4Gfiynp8AML,H1k0Fmba4Gfiynp8AML,gBExoceumj4y8bFW9hY2aNMVSr
	for oPd4bh1MqQxN in tAeR0rp7K61QEBlJg2HW4dSI9U:
		if kYDaz79TFlXoR(u"ࠩࡐࡽࡕࡸ࡯ࡹࡻࡘࡶࡱࡃࠧᑅ") in oPd4bh1MqQxN: Hitbcw146SAGnegpqP5zrJUxTW8vBO = oPd4bh1MqQxN[RlOvin8YIGC2KZXJPk9m0acrMobUex(u"࠷࠱᝙"):]
		elif qoBMmfAWpFlK70xw8ZRh4naJ(u"ࠪࡑࡾࡊࡎࡔࡗࡵࡰࡂ࠭ᑆ") in oPd4bh1MqQxN: vLNaxndFy5jGkTiQhYX = oPd4bh1MqQxN[tQMjXKCA5dN4xq3beVIzaEoWkFLg(u"࠹᝚"):]
		elif tR1krDGPpO025fghMT3a7UnYj(u"ࠫࡓࡵࡖࡦࡴ࡬ࡪࡾ࡙ࡓࡍࠩᑇ") in oPd4bh1MqQxN: KKf8YWi2FyGABj = ag8rjZo1Vz4IPdcOT
	return WSQlG8mDhqsNe,Hitbcw146SAGnegpqP5zrJUxTW8vBO,vLNaxndFy5jGkTiQhYX,KKf8YWi2FyGABj
def YBNhACRib2dlgwp7869GJ(BigAz2Owj3arMN5J6RGFk8PTq,z5nOUetfoJHbP6294ghwur,Cm4xfTO625jyMtZ8GEpvuKcnbQ1gD,BAvuHpoh4tUiTZk0,UzSRKABHGypmT,dca7y6zwhOQK,ppuvkQrgA1i8WwY3ftNJx7Ba9jH=qpFY4hAwolV3):
	NkU4hAKiIe = AWeJuo2LhZ5xiD8KNSqd9G0rtT74FE(Cm4xfTO625jyMtZ8GEpvuKcnbQ1gD,IaBhDMJc17302LgSvyxd(u"ࠬࡻࡲ࡭ࠩᑈ"))
	FbPVyxAuaIiYj2wlJgsRm3G = gdPslyFW8ITBcpA302.getSetting(tQMjXKCA5dN4xq3beVIzaEoWkFLg(u"࠭ࡡࡷ࠰࡫ࡳࡸࡺ࠮ࠨᑉ")+BAvuHpoh4tUiTZk0)
	if NkU4hAKiIe==FbPVyxAuaIiYj2wlJgsRm3G: gdPslyFW8ITBcpA302.setSetting(ee86G9ladLHVbh5mikzCo(u"ࠧࡢࡸ࠱࡬ࡴࡹࡴ࠯ࠩᑊ")+BAvuHpoh4tUiTZk0,qpFY4hAwolV3)
	if FbPVyxAuaIiYj2wlJgsRm3G: hhpztscnBD1GP = Cm4xfTO625jyMtZ8GEpvuKcnbQ1gD.replace(NkU4hAKiIe,FbPVyxAuaIiYj2wlJgsRm3G)
	else:
		hhpztscnBD1GP = Cm4xfTO625jyMtZ8GEpvuKcnbQ1gD
		FbPVyxAuaIiYj2wlJgsRm3G = NkU4hAKiIe
	YYAG0TXBO4hCgSRmkPZdvV = WWrExJZS3Bj4anOAkpv7(BigAz2Owj3arMN5J6RGFk8PTq,z5nOUetfoJHbP6294ghwur,hhpztscnBD1GP,qpFY4hAwolV3,ppuvkQrgA1i8WwY3ftNJx7Ba9jH,qpFY4hAwolV3,qpFY4hAwolV3,qoBMmfAWpFlK70xw8ZRh4naJ(u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡊࡓࡔࡍࡌࡆࡡࡑࡉ࡜ࡥࡈࡐࡕࡗࡒࡆࡓࡅ࠮࠳ࡶࡸࠬᑋ"))
	eVEX29oO0qZjxltJKIfbc8aSd = YYAG0TXBO4hCgSRmkPZdvV.content
	if DLod2Of8CkRrtzJynev:
		try: eVEX29oO0qZjxltJKIfbc8aSd = eVEX29oO0qZjxltJKIfbc8aSd.decode(nV3Tip6XsH1rJw79DPOU,DaFZHsThGmd0zv6e(u"ࠩ࡬࡫ࡳࡵࡲࡦࠩᑌ"))
		except: pass
	if not YYAG0TXBO4hCgSRmkPZdvV.succeeded or dca7y6zwhOQK not in eVEX29oO0qZjxltJKIfbc8aSd:
		UzSRKABHGypmT = UzSRKABHGypmT.replace(mIsDke0oK5x1zSiOWbF9thGcA,IaBhDMJc17302LgSvyxd(u"ࠪ࠯ࠬᑍ"))
		WSQlG8mDhqsNe = DaFZHsThGmd0zv6e(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡽࡷࡸ࠰ࡪࡳࡴ࡭࡬ࡦ࠰ࡦࡳࡲ࠵ࡳࡦࡣࡵࡧ࡭ࡅࡱ࠾ࠩᑎ")+UzSRKABHGypmT
		skD7g3FxW4wCa5BR = {aXqWLoTdVgME(u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩᑏ"):qpFY4hAwolV3}
		YzK5Mnda6GwuX1LHeI = WWrExJZS3Bj4anOAkpv7(BigAz2Owj3arMN5J6RGFk8PTq,z5nOUetfoJHbP6294ghwur,WSQlG8mDhqsNe,qpFY4hAwolV3,skD7g3FxW4wCa5BR,qpFY4hAwolV3,qpFY4hAwolV3,tR1krDGPpO025fghMT3a7UnYj(u"࠭ࡌࡊࡄࡕࡅࡗ࡟࠭ࡈࡑࡒࡋࡑࡋ࡟ࡏࡇ࡚ࡣࡍࡕࡓࡕࡐࡄࡑࡊ࠳࠲࡯ࡦࠪᑐ"))
		if YzK5Mnda6GwuX1LHeI.succeeded:
			eVEX29oO0qZjxltJKIfbc8aSd = YzK5Mnda6GwuX1LHeI.content
			if DLod2Of8CkRrtzJynev:
				try: eVEX29oO0qZjxltJKIfbc8aSd = eVEX29oO0qZjxltJKIfbc8aSd.decode(nV3Tip6XsH1rJw79DPOU,mmV2nucZ5Lpl6FO1JMPEqGoQKW(u"ࠧࡪࡩࡱࡳࡷ࡫ࠧᑑ"))
				except: pass
			CFevtSjzbpn = ePhmG1jLD6.findall(dJHDqiKf12TXlIzSLkGUuxg4MBs3A(u"ࠨ࠾ࡤࠤ࡭ࡸࡥࡧ࠿ࠥ࠳ࡡࡽࠪ࡝ࡁ࠱࠮ࡄ࠮ࡨࡵࡶࡳ࠲࠯ࡅࠩࠣࠩᑒ"),eVEX29oO0qZjxltJKIfbc8aSd,ePhmG1jLD6.DOTALL)
			uuUw2Xln9VfoQGpLdJ0zhyjbC = [FbPVyxAuaIiYj2wlJgsRm3G]
			Vv2e3LFJRzUHWh5SdQD = [RlOvin8YIGC2KZXJPk9m0acrMobUex(u"ࠩࡤࡴࡰ࠭ᑓ"),l32dnTEOU1skGKqeBtI9hmo(u"ࠪ࡫ࡴࡵࡧ࡭ࡧࠪᑔ"),tR1krDGPpO025fghMT3a7UnYj(u"ࠫࡹࡽࡩࡵࡶࡨࡶࠬᑕ"),zYvEaigKWjoq50pXBLDbGJkFc(u"ࠬࡿ࡯ࡶࡶࡸࡦࡪ࠭ᑖ"),tR1krDGPpO025fghMT3a7UnYj(u"࠭ࡦࡢࡥࡨࡦࡴࡵ࡫ࠨᑗ"),zYvEaigKWjoq50pXBLDbGJkFc(u"ࠧࡱࡪࡳࠫᑘ"),viRJWOC5jsYe84(u"ࠨࡣࡷࡰࡦࡷࠧᑙ"),UVa3fJw7k6KM(u"ࠩࡶ࡭ࡹ࡫ࡩ࡯ࡦ࡬ࡧࡪࡹࠧᑚ"),UVa3fJw7k6KM(u"ࠪࡷࡺࡸ࠮࡭ࡻࠪᑛ"),qoBMmfAWpFlK70xw8ZRh4naJ(u"ࠫࡧࡲ࡯ࡨࡵࡳࡳࡹ࠭ᑜ"),Ie5s2cBtSfdHjzQ4rA9kYlo6D18(u"ࠬ࡯࡮ࡧࡱࡵࡱࡪࡸࠧᑝ"),c2RKu0xG1eC8MiohyE(u"࠭ࡳࡪࡶࡨࡰ࡮ࡱࡥࠨᑞ"),qqzwE6imYG4c2xojI(u"ࠧࡪࡰࡶࡸࡦ࡭ࡲࡢ࡯ࠪᑟ"),zYvEaigKWjoq50pXBLDbGJkFc(u"ࠨࡵࡱࡥࡵࡩࡨࡢࡶࠪᑠ"),DiJ8CMuYH1daWyjehfN0L(u"ࠩ࡫ࡸࡹࡶ࠭ࡦࡳࡸ࡭ࡻ࠭ᑡ"),Ie5s2cBtSfdHjzQ4rA9kYlo6D18(u"ࠪࡪࡦࡹࡥ࡭ࡲ࡯ࡹࡸ࠭ᑢ")]
			for kl7ToEBRZAs8C6O24Fzad in CFevtSjzbpn:
				if any(value in kl7ToEBRZAs8C6O24Fzad for value in Vv2e3LFJRzUHWh5SdQD): continue
				FbPVyxAuaIiYj2wlJgsRm3G = AWeJuo2LhZ5xiD8KNSqd9G0rtT74FE(kl7ToEBRZAs8C6O24Fzad,LZWMikPEB81KSGyxfJtUsCA(u"ࠫࡺࡸ࡬ࠨᑣ"))
				if FbPVyxAuaIiYj2wlJgsRm3G in uuUw2Xln9VfoQGpLdJ0zhyjbC: continue
				if len(uuUw2Xln9VfoQGpLdJ0zhyjbC)==rNdBKI74fAklnoCZ6(u"࠺᝛"):
					LLvyStW429DEZKlA(j8gFJIMYPoBzcCvG9T,lTW9p1v7uPfOxB(Q8Q0IDc6PLZajJAdTntKUmSGXz)+l1DZAt9XNQjqE7YOdrz(u"ࠬࠦࠠࠡࡉࡲࡳ࡬ࡲࡥࠡࡦ࡬ࡨࠥࡴ࡯ࡵࠢࡩ࡭ࡳࡪࠠࡢࠢࡱࡩࡼࠦࡨࡰࡵࡷࡲࡦࡳࡥࠡࠢࠣࡗ࡮ࡺࡥ࠻ࠢ࡞ࠤࠬᑤ")+BAvuHpoh4tUiTZk0+RlOvin8YIGC2KZXJPk9m0acrMobUex(u"࠭ࠠ࡞ࠢࠣࡓࡱࡪ࠺ࠡ࡝ࠣࠫᑥ")+NkU4hAKiIe+ee86G9ladLHVbh5mikzCo(u"ࠧࠡ࡟ࠪᑦ"))
					gdPslyFW8ITBcpA302.setSetting(ddiCzu6yahj5RtTISMJ48sNnZBU(u"ࠨࡣࡹ࠲࡭ࡵࡳࡵ࠰ࠪᑧ")+BAvuHpoh4tUiTZk0,qpFY4hAwolV3)
					break
				uuUw2Xln9VfoQGpLdJ0zhyjbC.append(FbPVyxAuaIiYj2wlJgsRm3G)
				hhpztscnBD1GP = Cm4xfTO625jyMtZ8GEpvuKcnbQ1gD.replace(NkU4hAKiIe,FbPVyxAuaIiYj2wlJgsRm3G)
				YYAG0TXBO4hCgSRmkPZdvV = WWrExJZS3Bj4anOAkpv7(BigAz2Owj3arMN5J6RGFk8PTq,z5nOUetfoJHbP6294ghwur,hhpztscnBD1GP,qpFY4hAwolV3,ppuvkQrgA1i8WwY3ftNJx7Ba9jH,qpFY4hAwolV3,qpFY4hAwolV3,iNc3KxwErnQ(u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡋࡔࡕࡇࡍࡇࡢࡒࡊ࡝࡟ࡉࡑࡖࡘࡓࡇࡍࡆ࠯࠶ࡶࡩ࠭ᑨ"))
				eVEX29oO0qZjxltJKIfbc8aSd = YYAG0TXBO4hCgSRmkPZdvV.content
				if YYAG0TXBO4hCgSRmkPZdvV.succeeded and dca7y6zwhOQK in eVEX29oO0qZjxltJKIfbc8aSd:
					LLvyStW429DEZKlA(d3MGHW41fvNz6rRFYix2anS,lTW9p1v7uPfOxB(Q8Q0IDc6PLZajJAdTntKUmSGXz)+BRWqdruz2A0(u"ࠪࠤࠥࠦࡇࡰࡱࡪࡰࡪࠦࡦࡰࡷࡱࡨࠥࡧࠠ࡯ࡧࡺࠤ࡭ࡵࡳࡵࡰࡤࡱࡪࠦࠠࠡࡕ࡬ࡸࡪࡀࠠ࡜ࠢࠪᑩ")+BAvuHpoh4tUiTZk0+l1DZAt9XNQjqE7YOdrz(u"ࠫࠥࡣࠠࠡࠢࡑࡩࡼࡀࠠ࡜ࠢࠪᑪ")+FbPVyxAuaIiYj2wlJgsRm3G+DiJ8CMuYH1daWyjehfN0L(u"ࠬࠦ࡝ࠡࠢࡒࡰࡩࡀࠠ࡜ࠢࠪᑫ")+NkU4hAKiIe+lljaEqwTVtmKsQcOrbXxS5hgNH(u"࠭ࠠ࡞ࠩᑬ"))
					gdPslyFW8ITBcpA302.setSetting(kYDaz79TFlXoR(u"ࠧࡢࡸ࠱࡬ࡴࡹࡴ࠯ࠩᑭ")+BAvuHpoh4tUiTZk0,FbPVyxAuaIiYj2wlJgsRm3G)
					break
	return FbPVyxAuaIiYj2wlJgsRm3G,hhpztscnBD1GP,YYAG0TXBO4hCgSRmkPZdvV
def nqTpa5zm20MfRNsVSIuG7A3biHZ6Fw(Z4vQNwLcAiPVufj9sOgCMU6ezEWG):
	rPpqkjNAamSGRin4gD5HYEhM86w2 = {
	 CC1eY6yWZUwf2TkRvnp7EJ0AimjHBX(u"ࠨࡣ࡫ࡻࡦࡱࠧᑮ")				:IaBhDMJc17302LgSvyxd(u"่ࠩ์็฿ࠠฤ้๋ห่ࠦส๋ใํࠫᑯ")
	,RlOvin8YIGC2KZXJPk9m0acrMobUex(u"ࠪࡥࡰࡵࡡ࡮ࠩᑰ")				:kYDaz79TFlXoR(u"๊ࠫ๎โฺࠢฦ็ํอๅࠡษ็ๆิ๐ๅࠨᑱ")
	,Ie5s2cBtSfdHjzQ4rA9kYlo6D18(u"ࠬࡧ࡫ࡰࡣࡰࡧࡦࡳࠧᑲ")				:c2RKu0xG1eC8MiohyE(u"࠭ๅ้ไ฼ࠤศ้่ศ็ࠣ็ฬ๋ࠧᑳ")
	,CC1eY6yWZUwf2TkRvnp7EJ0AimjHBX(u"ࠧࡢ࡭ࡺࡥࡲ࠭ᑴ")				:UVa3fJw7k6KM(u"ࠨ็๋ๆ฾ࠦรไ๊ส้ࠥอไอัํำࠬᑵ")
	,ddiCzu6yahj5RtTISMJ48sNnZBU(u"ࠩࡤ࡯ࡼࡧ࡭ࡵࡷࡥࡩࠬᑶ")			:LZWMikPEB81KSGyxfJtUsCA(u"้ࠪํู่ࠡษๆ์ฬ๋ࠠห์๋ฬࠬᑷ")
	,aXqWLoTdVgME(u"ࠫࡦࡲࡡࡳࡣࡥࠫᑸ")				:ddiCzu6yahj5RtTISMJ48sNnZBU(u"๋่ࠬใ฻ࠣ็้ࠦวๅ฻ิฬࠬᑹ")
	,IaBhDMJc17302LgSvyxd(u"࠭ࡡ࡭ࡨࡤࡸ࡮ࡳࡩࠨᑺ")				:qqzwE6imYG4c2xojI(u"ࠧๆ๊ๅ฽ࠥอไๆ่หีࠥอไโษฺ้๏࠭ᑻ")
	,c2RKu0xG1eC8MiohyE(u"ࠨࡣ࡯࡯ࡦࡽࡴࡩࡣࡵࠫᑼ")			:UVa3fJw7k6KM(u"่ࠩ์็฿ࠠใ่สอࠥอไไ๊ฮีࠬᑽ")
	,LZWMikPEB81KSGyxfJtUsCA(u"ࠪࡥࡱࡳࡡࡢࡴࡨࡪࠬᑾ")				:iNc3KxwErnQ(u"๊ࠫ๎โฺࠢๅ๊ฬฯࠠศๆ่฽ฬืแࠨᑿ")
	,aXqWLoTdVgME(u"ࠬࡧ࡬࡮ࡵࡷࡦࡦ࠭ᒀ")				:Ie5s2cBtSfdHjzQ4rA9kYlo6D18(u"࠭ๅ้ไ฼ࠤฬ๊ๅึูหอࠬᒁ")
	,l1DZAt9XNQjqE7YOdrz(u"ࠧࡢࡰ࡬ࡱࡪࢀࡩࡥࠩᒂ")				:zYvEaigKWjoq50pXBLDbGJkFc(u"ࠨ็๋ๆ฾ࠦว็็ํࠤืีࠧᒃ")
	,aXqWLoTdVgME(u"ࠩࡤࡶࡦࡨࡩࡤࡶࡲࡳࡳࡹࠧᒄ")			:qoBMmfAWpFlK70xw8ZRh4naJ(u"้ࠪํู่ࠡฬ๋๊ืูࠦาสํอࠬᒅ")
	,DiJ8CMuYH1daWyjehfN0L(u"ࠫࡦࡸࡡࡣࡵࡨࡩࡩ࠭ᒆ")				:N3flV6EJsD5CzS(u"๋่ࠬใ฻ࠣ฽ึฮࠠิ์ํำࠬᒇ")
	,DiJ8CMuYH1daWyjehfN0L(u"࠭ࡡࡳࡤ࡯࡭ࡴࡴࡺࠨᒈ")				:UVa3fJw7k6KM(u"ࠧๆ๊ๅ฽ࠥ฿ัษࠢ็๎ํ์าࠨᒉ")
	,UUDAiytEL76RTmMYsuIz5evXB(u"ࠨࡣࡼࡰࡴࡲࠧᒊ")				:Ie5s2cBtSfdHjzQ4rA9kYlo6D18(u"่ࠩ์็฿ࠠฤ์็์้࠭ᒋ")
	,UUDAiytEL76RTmMYsuIz5evXB(u"ࠪࡦࡴࡱࡲࡢࠩᒌ")				:kYDaz79TFlXoR(u"๊ࠫ๎โฺࠢห็ึอࠧᒍ")
	,mmV2nucZ5Lpl6FO1JMPEqGoQKW(u"ࠬࡨࡲࡴࡶࡨ࡮ࠬᒎ")				:DiJ8CMuYH1daWyjehfN0L(u"࠭ๅ้ไ฼ࠤอืำห์ฯࠫᒏ")
	,UVa3fJw7k6KM(u"ࠧࡤ࡫ࡰࡥ࠹࠶࠰ࠨᒐ")				:kYDaz79TFlXoR(u"ࠨ็๋ๆ฾ࠦำ๋็สࠤ࠹࠶࠰ࠨᒑ")
	,LZWMikPEB81KSGyxfJtUsCA(u"ࠩࡦ࡭ࡲࡧ࠴ࡱࠩᒒ")				:c2RKu0xG1eC8MiohyE(u"้ࠪํู่ࠡีํ้ฬࠦแ้ำࠣฬ๏࠭ᒓ")
	,lljaEqwTVtmKsQcOrbXxS5hgNH(u"ࠫࡨ࡯࡭ࡢ࠶ࡸࠫᒔ")				:qqzwE6imYG4c2xojI(u"๋่ࠬใ฻ࠣื๏๋วࠡใ๋ี๏๎ࠧᒕ")
	,YY8UDX3MJhb91AHw7fg(u"࠭ࡣࡪ࡯ࡤࡥࡧࡪ࡯ࠨᒖ")				:viRJWOC5jsYe84(u"ࠧๆ๊ๅ฽ู๊ࠥๆษࠣ฽อี่ࠨᒗ")
	,tQMjXKCA5dN4xq3beVIzaEoWkFLg(u"ࠨࡥ࡬ࡱࡦࡩ࡬ࡶࡤࠪᒘ")				:aXqWLoTdVgME(u"่ࠩ์็฿ࠠิ์่ห้ࠥไ้สࠪᒙ")
	,zYvEaigKWjoq50pXBLDbGJkFc(u"ࠪࡧ࡮ࡳࡡࡤ࡮ࡸࡦࡼࡵࡲ࡬ࠩᒚ")			:BRWqdruz2A0(u"๊ࠫ๎โฺࠢึ๎๊อࠠไๆ๋ฬࠥ฿ๅๅࠩᒛ")
	,lljaEqwTVtmKsQcOrbXxS5hgNH(u"ࠬࡩࡩ࡮ࡣࡦࡰࡺࡶࠧᒜ")				:qoBMmfAWpFlK70xw8ZRh4naJ(u"࠭ๅ้ไ฼ࠤุ๐ๅศࠢๆ่ํฮࠧᒝ")
	,IaBhDMJc17302LgSvyxd(u"ࠧࡤ࡫ࡰࡥ࡫ࡧ࡮ࡴࠩᒞ")				:c2RKu0xG1eC8MiohyE(u"ࠨ็๋ๆ฾ࠦำ๋็สࠤๆอๆำࠩᒟ")
	,V3VlkhgjEF4n1erPXHcC0NOsfwyAJ(u"ࠩࡦ࡭ࡲࡧࡦࡳࡧࡨࠫᒠ")				:aXqWLoTdVgME(u"้ࠪํู่ࠡีํ้ฬࠦแา์ࠪᒡ")
	,dJHDqiKf12TXlIzSLkGUuxg4MBs3A(u"ࠫࡨ࡯࡭ࡢ࡮࡬࡫࡭ࡺࠧᒢ")			:kYDaz79TFlXoR(u"๋่ࠬใ฻ࠣื๏๋วࠡๆส๎ฯ࠭ᒣ")
	,tR1krDGPpO025fghMT3a7UnYj(u"࠭ࡣࡪ࡯ࡤࡲࡴࡽࠧᒤ")				:dJHDqiKf12TXlIzSLkGUuxg4MBs3A(u"ࠧๆ๊ๅ฽ู๊ࠥๆษ๊ࠣฬ๎ࠧᒥ")
	,DiJ8CMuYH1daWyjehfN0L(u"ࠨࡥ࡬ࡱࡦࡽࡢࡢࡵࠪᒦ")				:tQMjXKCA5dN4xq3beVIzaEoWkFLg(u"่ࠩ์็฿ࠠิ์่หࠥ๎ศิࠩᒧ")
	,qqzwE6imYG4c2xojI(u"ࠪࡨࡦ࡯࡬ࡺ࡯ࡲࡸ࡮ࡵ࡮ࠨᒨ")			:tR1krDGPpO025fghMT3a7UnYj(u"๊ࠫ๎โฺࠢาห๏๊๊ࠡ็ุ๋๋࠭ᒩ")
	,c2RKu0xG1eC8MiohyE(u"ࠬࡪࡡࡪ࡮ࡼࡱࡴࡺࡩࡰࡰ࠰ࡧ࡭ࡧ࡮࡯ࡧ࡯ࡷࠬᒪ")	:viRJWOC5jsYe84(u"࠭ๅ้ไ฼ࠤิอ๊ๅ์้ࠣํฺๆࠡ็ึฮำีๅ๋่ࠪᒫ")
	,qoBMmfAWpFlK70xw8ZRh4naJ(u"ࠧࡥࡣ࡬ࡰࡾࡳ࡯ࡵ࡫ࡲࡲ࠲࡮ࡡࡴࡪࡷࡥ࡬ࡹࠧᒬ")	:kYDaz79TFlXoR(u"ࠨ็๋ๆ฾ࠦฯศ์็๎๋่ࠥี่๋ࠣฬฺสศๅࠪᒭ")
	,RlOvin8YIGC2KZXJPk9m0acrMobUex(u"ࠩࡧࡥ࡮ࡲࡹ࡮ࡱࡷ࡭ࡴࡴ࠭࡭࡫ࡹࡩࡸ࠭ᒮ")	:viRJWOC5jsYe84(u"้ࠪํู่ࠡัส๎้๐ࠠๆ๊ื๊๋ࠥศศึิࠫᒯ")
	,iNc3KxwErnQ(u"ࠫࡩࡧࡩ࡭ࡻࡰࡳࡹ࡯࡯࡯࠯ࡳࡰࡦࡿ࡬ࡪࡵࡷࡷࠬᒰ"):qoBMmfAWpFlK70xw8ZRh4naJ(u"๋่ࠬใ฻ࠣำฬ๐ไ๋่ࠢ์ู์ࠠใ๊สส๊࠭ᒱ")
	,dJHDqiKf12TXlIzSLkGUuxg4MBs3A(u"࠭ࡤࡢ࡫࡯ࡽࡲࡵࡴࡪࡱࡱ࠱ࡹࡵࡰࡪࡥࡶࠫᒲ")	:N3flV6EJsD5CzS(u"ࠧๆ๊ๅ฽ࠥีว๋ๆํࠤ๊๎ิ็่ࠢ์ฬ฼ฺ๊ࠩᒳ")
	,dJHDqiKf12TXlIzSLkGUuxg4MBs3A(u"ࠨࡦࡤ࡭ࡱࡿ࡭ࡰࡶ࡬ࡳࡳ࠳ࡶࡪࡦࡨࡳࡸ࠭ᒴ")	:ee86G9ladLHVbh5mikzCo(u"่ࠩ์็฿ࠠะษํ่๏ࠦๅ้ึ้ࠤๆ๐ฯ๋๊๊หฯ࠭ᒵ")
	,dJHDqiKf12TXlIzSLkGUuxg4MBs3A(u"ࠪࡨ࡮ࡹࡡࡣ࡮ࡨࡨࠬᒶ")				:sjtU6GZQg5XC2pH4(u"๊ࠫะ่ใใࠪᒷ")
	,c2RKu0xG1eC8MiohyE(u"ࠬࡪࡲࡢ࡯ࡤࡧࡦ࡬ࡥࠨᒸ")			:zYvEaigKWjoq50pXBLDbGJkFc(u"࠭ๅ้ไ฼ࠤิืวๆษࠣ็ฬ็๊่ࠩᒹ")
	,l1DZAt9XNQjqE7YOdrz(u"ࠧࡥࡴࡤࡱࡦࡹ࠷ࠨᒺ")				:tQMjXKCA5dN4xq3beVIzaEoWkFLg(u"ࠨ็๋ๆ฾ࠦฯาษ่หࠥ฻อࠨᒻ")
	,mmV2nucZ5Lpl6FO1JMPEqGoQKW(u"ࠩࡨ࡫ࡾࡨࡥࡴࡶࠪᒼ")				:ddiCzu6yahj5RtTISMJ48sNnZBU(u"้ࠪํู่ࠡษํะ๏ࠦศ๋ีอࠫᒽ")
	,sjtU6GZQg5XC2pH4(u"ࠫࡪ࡭ࡹࡣࡧࡶࡸ࠶࠭ᒾ")				:lljaEqwTVtmKsQcOrbXxS5hgNH(u"๋่ࠬใ฻ࠣห๏า๊ࠡสํืฯࠦ࠱ࠨᒿ")
	,sjtU6GZQg5XC2pH4(u"࠭ࡥࡨࡻࡥࡩࡸࡺ࠲ࠨᓀ")				:tQMjXKCA5dN4xq3beVIzaEoWkFLg(u"ࠧๆ๊ๅ฽ࠥอ๊อ์ࠣฬ๏ูสࠡ࠴ࠪᓁ")
	,rNdBKI74fAklnoCZ6(u"ࠨࡧࡪࡽࡧ࡫ࡳࡵ࠵ࠪᓂ")				:tR1krDGPpO025fghMT3a7UnYj(u"่ࠩ์็฿ࠠศ์ฯ๎ࠥฮ๊ิฬࠣ࠷ࠬᓃ")
	,aXqWLoTdVgME(u"ࠪࡩ࡬ࡿࡢࡦࡵࡷ࠸ࠬᓄ")				:IaBhDMJc17302LgSvyxd(u"๊ࠫ๎โฺࠢส๎ั๐ࠠษ์ึฮࠥ࠺ࠧᓅ")
	,V3VlkhgjEF4n1erPXHcC0NOsfwyAJ(u"ࠬ࡫ࡧࡺࡤࡨࡷࡹࡼࡩࡱࠩᓆ")			:CC1eY6yWZUwf2TkRvnp7EJ0AimjHBX(u"࠭ๅ้ไ฼ࠤฬ๐ฬ๋ࠢห๎ุะࠠࡷ࡫ࡳࠫᓇ")
	,aXqWLoTdVgME(u"ࠧࡦࡩࡼࡨࡪࡧࡤࠨᓈ")				:V3VlkhgjEF4n1erPXHcC0NOsfwyAJ(u"ࠨ็๋ๆ฾ࠦล๋ฮํࠤิ๐ฯࠨᓉ")
	,IaBhDMJc17302LgSvyxd(u"ࠩࡨ࡫ࡾࡴ࡯ࡸࠩᓊ")				:tQMjXKCA5dN4xq3beVIzaEoWkFLg(u"้ࠪํู่ࠡวํะ๏ࠦๆศ๊ࠪᓋ")
	,RlOvin8YIGC2KZXJPk9m0acrMobUex(u"ࠫࡪࡲࡣࡪࡰࡨࡱࡦ࠭ᓌ")				:mmV2nucZ5Lpl6FO1JMPEqGoQKW(u"๋่ࠬใ฻้ࠣํฺู่หࠣหู้๊็็สࠫᓍ")
	,tR1krDGPpO025fghMT3a7UnYj(u"࠭ࡥ࡭࡫ࡩࡺ࡮ࡪࡥࡰࠩᓎ")			:qqzwE6imYG4c2xojI(u"ࠧๆ๊ๅ฽ࠥษไ๋ใࠣๅ๏ี๊้ࠩᓏ")
	,zYvEaigKWjoq50pXBLDbGJkFc(u"ࠨࡨࡤࡦࡷࡧ࡫ࡢࠩᓐ")				:rNdBKI74fAklnoCZ6(u"่ࠩ์็฿ࠠโสิ็ฮ࠭ᓑ")
	,V3VlkhgjEF4n1erPXHcC0NOsfwyAJ(u"ࠪࡪࡦ࡯࡬ࡦࡦࠪᓒ")				:tQMjXKCA5dN4xq3beVIzaEoWkFLg(u"ࠫๆฺไࠨᓓ")
	,rNdBKI74fAklnoCZ6(u"ࠬ࡬ࡡ࡫ࡧࡵࡷ࡭ࡵࡷࠨᓔ")			:iNc3KxwErnQ(u"࠭ๅ้ไ฼ࠤๆาัࠡึ๋ࠫᓕ")
	,UVa3fJw7k6KM(u"ࠧࡧࡣࡵࡩࡸࡱ࡯ࠨᓖ")				:aXqWLoTdVgME(u"ࠨ็๋ๆ฾ࠦแศำึ็ํ࠭ᓗ")
	,fWoVd0Bmtkx(u"ࠩࡩࡥࡸ࡫࡬ࡩࡦ࠴ࠫᓘ")				:kYDaz79TFlXoR(u"้ࠪํู่ࠡใสู้ࠦวๅล๋่ࠬᓙ")
	,qqzwE6imYG4c2xojI(u"ࠫ࡫ࡧࡳࡦ࡮࡫ࡨ࠷࠭ᓚ")				:zYvEaigKWjoq50pXBLDbGJkFc(u"๋่ࠬใ฻ࠣๅฬ฻ไࠡษ็ฯฬ์๊ࠨᓛ")
	,zYvEaigKWjoq50pXBLDbGJkFc(u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ᓜ")				:YY8UDX3MJhb91AHw7fg(u"ࠧๆฮ็ำࠬᓝ")
	,l1DZAt9XNQjqE7YOdrz(u"ࠨࡨࡲࡷࡹࡧࠧᓞ")				:rNdBKI74fAklnoCZ6(u"่ࠩ์็฿ࠠโ๊ึฮฬ࠭ᓟ")
	,N3flV6EJsD5CzS(u"ࠪࡪࡺࡴ࡯࡯ࡶࡹࠫᓠ")				:IaBhDMJc17302LgSvyxd(u"๊ࠫ๎โฺࠢไ๊ํ์ࠠห์ไ๎ࠬᓡ")
	,CC1eY6yWZUwf2TkRvnp7EJ0AimjHBX(u"ࠬ࡬ࡵࡴࡪࡤࡶࡹࡼࠧᓢ")				:UUDAiytEL76RTmMYsuIz5evXB(u"࠭ๅ้ไ฼ࠤๆ๎ิศำࠣฮ๏็๊ࠨᓣ")
	,iNc3KxwErnQ(u"ࠧࡧࡷࡶ࡬ࡦࡸࡶࡪࡦࡨࡳࠬᓤ")			:aXqWLoTdVgME(u"ࠨ็๋ๆ฾ࠦแ้ึสีࠥ็๊ะ์๋ࠫᓥ")
	,UVa3fJw7k6KM(u"ࠩࡪࡳࡴࡪࠧᓦ")					:N3flV6EJsD5CzS(u"ࠪะ๏ีࠧᓧ")
	,IaBhDMJc17302LgSvyxd(u"ࠫ࡭ࡧ࡬ࡢࡥ࡬ࡱࡦ࠭ᓨ")				:V3VlkhgjEF4n1erPXHcC0NOsfwyAJ(u"๋่ࠬใ฻๋้ࠣอࠠิ์่หࠬᓩ")
	,IaBhDMJc17302LgSvyxd(u"࠭ࡨࡦ࡮ࡤࡰࠬᓪ")				:Ie5s2cBtSfdHjzQ4rA9kYlo6D18(u"ࠧๆ๊ๅ฽ࠥํไศๆࠣ๎ํะ๊้สࠪᓫ")
	,kYDaz79TFlXoR(u"ࠨ࡫ࡩ࡭ࡱࡳࠧᓬ")				:ddiCzu6yahj5RtTISMJ48sNnZBU(u"่ࠩ์็฿ࠠใ่สอࠥศ๊ࠡใํ่๊࠭ᓭ")
	,qoBMmfAWpFlK70xw8ZRh4naJ(u"ࠪ࡭࡫࡯࡬࡮࠯ࡤࡶࡦࡨࡩࡤࠩᓮ")			:mmV2nucZ5Lpl6FO1JMPEqGoQKW(u"๊ࠫ๎โฺࠢๅ๊ฬฯࠠร์ࠣๅ๏๊ๅࠡ฻ิฬ๏࠭ᓯ")
	,ee86G9ladLHVbh5mikzCo(u"ࠬ࡯ࡦࡪ࡮ࡰ࠱ࡪࡴࡧ࡭࡫ࡶ࡬ࠬᓰ")		:dJHDqiKf12TXlIzSLkGUuxg4MBs3A(u"࠭ๅ้ไ฼ࠤ็์วสࠢล๎ࠥ็๊ๅ็ࠣห๋าไ๋ิํࠫᓱ")
	,DaFZHsThGmd0zv6e(u"ࠧࡪࡲࡷࡺࠬᓲ")					:mmV2nucZ5Lpl6FO1JMPEqGoQKW(u"ࠨࡋࡓࡘ࡛࠭ᓳ")
	,YY8UDX3MJhb91AHw7fg(u"ࠩ࡬ࡴࡹࡼ࠭࡭࡫ࡹࡩࠬᓴ")			:DiJ8CMuYH1daWyjehfN0L(u"ࠪࡍࡕ࡚ࡖࠡไ้์ฬะࠧᓵ")
	,l1DZAt9XNQjqE7YOdrz(u"ࠫ࡮ࡶࡴࡷ࠯ࡰࡳࡻ࡯ࡥࡴࠩᓶ")			:iNc3KxwErnQ(u"ࠬࡏࡐࡕࡘࠣวๆ๊วๆࠩᓷ")
	,DaFZHsThGmd0zv6e(u"࠭ࡩࡱࡶࡹ࠱ࡸ࡫ࡲࡪࡧࡶࠫᓸ")			:zYvEaigKWjoq50pXBLDbGJkFc(u"ࠧࡊࡒࡗ๋࡚ࠥำๅี็หฯ࠭ᓹ")
	,ddiCzu6yahj5RtTISMJ48sNnZBU(u"ࠨ࡭ࡤࡶࡧࡧ࡬ࡢࡶࡹࠫᓺ")			:Ie5s2cBtSfdHjzQ4rA9kYlo6D18(u"่ࠩ์็฿ࠠใ่สอ้ࠥัษๆสลࠬᓻ")
	,viRJWOC5jsYe84(u"ࠪ࡯ࡦࡺ࡫ࡰࡶࡷࡺࠬᓼ")				:UVa3fJw7k6KM(u"๊ࠫ๎โฺࠢๆฮ่๎สࠡฬํๅ๏࠭ᓽ")
	,ddiCzu6yahj5RtTISMJ48sNnZBU(u"ࠬࡱࡡࡵ࡭ࡲࡹࡹ࡫ࠧᓾ")				:tQMjXKCA5dN4xq3beVIzaEoWkFLg(u"࠭ๅ้ไ฼ࠤ่ะใ้ฬࠪᓿ")
	,DiJ8CMuYH1daWyjehfN0L(u"ࠧ࡬࡫ࡵࡱࡦࡲ࡫ࠨᔀ")				:ddiCzu6yahj5RtTISMJ48sNnZBU(u"ࠨ็๋ๆ฾ࠦใา็ส่่࠭ᔁ")
	,aXqWLoTdVgME(u"ࠩ࡯ࡥࡷࡵࡺࡢࠩᔂ")				:BRWqdruz2A0(u"้ࠪํู่ࠡๆสีํุวࠨᔃ")
	,c2RKu0xG1eC8MiohyE(u"ࠫࡱ࡯ࡢࡳࡣࡵࡽࠬᔄ")				:V3VlkhgjEF4n1erPXHcC0NOsfwyAJ(u"๋ࠬไโࠩᔅ")
	,LZWMikPEB81KSGyxfJtUsCA(u"࠭࡬ࡪࡸࡨࠫᔆ")					:ddiCzu6yahj5RtTISMJ48sNnZBU(u"ࠧใ่สอࠬᔇ")
	,CC1eY6yWZUwf2TkRvnp7EJ0AimjHBX(u"ࠨ࡮࡬ࡺࡪࡺࡶࠨᔈ")				:kYDaz79TFlXoR(u"่่ࠩๆ࠭ᔉ")
	,lljaEqwTVtmKsQcOrbXxS5hgNH(u"ࠪࡰࡴࡪࡹ࡯ࡧࡷࠫᔊ")				:N3flV6EJsD5CzS(u"๊ࠫ๎โฺࠢ็์ิ๐ࠠ็ฬࠪᔋ")
	,sjtU6GZQg5XC2pH4(u"ࠬࡳ࠳ࡶࠩᔌ")					:RlOvin8YIGC2KZXJPk9m0acrMobUex(u"࠭ࡍ࠴ࡗࠪᔍ")
	,LZWMikPEB81KSGyxfJtUsCA(u"ࠧ࡮࠵ࡸ࠱ࡱ࡯ࡶࡦࠩᔎ")				:sjtU6GZQg5XC2pH4(u"ࠨࡏ࠶่࡙ࠥๆ้ษอࠫᔏ")
	,sjtU6GZQg5XC2pH4(u"ࠩࡰ࠷ࡺ࠳࡭ࡰࡸ࡬ࡩࡸ࠭ᔐ")			:V3VlkhgjEF4n1erPXHcC0NOsfwyAJ(u"ࠪࡑ࠸࡛ࠠฤใ็ห๊࠭ᔑ")
	,viRJWOC5jsYe84(u"ࠫࡲ࠹ࡵ࠮ࡵࡨࡶ࡮࡫ࡳࠨᔒ")			:kYDaz79TFlXoR(u"ࠬࡓ࠳ࡖ่ࠢืู้ไศฬࠪᔓ")
	,qoBMmfAWpFlK70xw8ZRh4naJ(u"࠭࡭ࡢࡵࡤࡺ࡮ࡪࡥࡰࠩᔔ")			:viRJWOC5jsYe84(u"ࠧๆ๊ๅ฽๋ࠥวิษࠣๅ๏ี๊้ࠩᔕ")
	,sjtU6GZQg5XC2pH4(u"ࠨ࡯࡬ࡷࡸ࡯࡮ࡨࠩᔖ")				:BRWqdruz2A0(u"่ࠩๅ็๎ฯࠨᔗ")
	,ddiCzu6yahj5RtTISMJ48sNnZBU(u"ࠪࡱࡴࡼࡳ࠵ࡷࠪᔘ")				:viRJWOC5jsYe84(u"๊ࠫ๎โฺ่ࠢ์ๆุࠠโ๊ิ๎ํ࠭ᔙ")
	,V3VlkhgjEF4n1erPXHcC0NOsfwyAJ(u"ࠬࡳࡹࡤ࡫ࡰࡥࠬᔚ")				:UUDAiytEL76RTmMYsuIz5evXB(u"࠭ๅ้ไ฼ࠤ๊อ๊ࠡีํ้ฬ࠭ᔛ")
	,sjtU6GZQg5XC2pH4(u"ࠧࡰ࡮ࡧࠫᔜ")					:kYDaz79TFlXoR(u"ࠨไา๎๊࠭ᔝ")
	,c2RKu0xG1eC8MiohyE(u"ࠩࡳࡥࡳ࡫ࡴࠨᔞ")				:aXqWLoTdVgME(u"้ࠪํู่ࠡสส๊๏ะࠧᔟ")
	,ee86G9ladLHVbh5mikzCo(u"ࠫࡵࡧ࡮ࡦࡶ࠰ࡱࡴࡼࡩࡦࡵࠪᔠ")			:l1DZAt9XNQjqE7YOdrz(u"๋่ࠬใ฻ࠣฬฬ์๊หࠢสๅ้อๅࠨᔡ")
	,aXqWLoTdVgME(u"࠭ࡰࡢࡰࡨࡸ࠲ࡹࡥࡳ࡫ࡨࡷࠬᔢ")			:aXqWLoTdVgME(u"ࠧๆ๊ๅ฽ࠥฮว็์อࠤู๊ไิๆสฮࠬᔣ")
	,ddiCzu6yahj5RtTISMJ48sNnZBU(u"ࠨࡳࡩ࡭ࡱࡳࠧᔤ")				:YY8UDX3MJhb91AHw7fg(u"่ࠩ์็฿ࠠไ์๋ࠤๆ๐ไๆࠩᔥ")
	,iNc3KxwErnQ(u"ࠪࡷࡪࡸࡩࡦࡵࡷ࡭ࡲ࡫ࠧᔦ")			:kYDaz79TFlXoR(u"๊ࠫ๎โฺࠢึ๎ึ๐ำࠡฬส๎๊࠭ᔧ")
	,kYDaz79TFlXoR(u"ࠬࡹࡨࡢࡤࡤ࡯ࡦࡺࡹࠨᔨ")			:sjtU6GZQg5XC2pH4(u"࠭ๅ้ไ฼ࠤูฮให์ࠪᔩ")
	,zYvEaigKWjoq50pXBLDbGJkFc(u"ࠧࡴࡪࡤ࡬࡮ࡪ࠴ࡶࠩᔪ")				:iNc3KxwErnQ(u"ࠨ็๋ๆ฾ࠦิศ้าࠤๆ๎ั๋๊ࠪᔫ")
	,viRJWOC5jsYe84(u"ࠩࡶ࡬ࡦ࡮ࡩࡥ࠶ࡸ࠶ࠬᔬ")			:mmV2nucZ5Lpl6FO1JMPEqGoQKW(u"้ࠪํู่ࠡึส๋ิࠦแ้ำํ์ࠥ࠸ࠧᔭ")
	,c2RKu0xG1eC8MiohyE(u"ࠫࡸ࡮ࡡࡩ࡫ࡧࡲࡪࡽࡳࠨᔮ")			:tQMjXKCA5dN4xq3beVIzaEoWkFLg(u"๋่ࠬใ฻ุࠣฬํฯ่ࠡํ์ื࠭ᔯ")
	,rNdBKI74fAklnoCZ6(u"࠭ࡳࡩ࡫ࡤࡺࡴ࡯ࡣࡦࠩᔰ")			:tR1krDGPpO025fghMT3a7UnYj(u"ࠧๆ๊ๅ฽ࠥ฻่หࠢสู่๐ูสࠩᔱ")
	,rNdBKI74fAklnoCZ6(u"ࠨࡵ࡫࡭ࡦࡼ࡯ࡪࡥࡨ࠱ࡦࡲࡢࡶ࡯ࡶࠫᔲ")		:dJHDqiKf12TXlIzSLkGUuxg4MBs3A(u"่ࠩ์็฿ࠠึ๊อࠤฬ๊ิ๋฻ฬࠤฬ๊ศ้็ࠪᔳ")
	,CC1eY6yWZUwf2TkRvnp7EJ0AimjHBX(u"ࠪࡷ࡭࡯ࡡࡷࡱ࡬ࡧࡪ࠳ࡡࡶࡦ࡬ࡳࡸ࠭ᔴ")		:l32dnTEOU1skGKqeBtI9hmo(u"๊ࠫ๎โฺุࠢ์ฯࠦวๅึํ฽ฮࠦี้ฬํหฯ࠭ᔵ")
	,qqzwE6imYG4c2xojI(u"ࠬࡹࡨࡪࡣࡹࡳ࡮ࡩࡥ࠮ࡲࡨࡶࡸࡵ࡮ࡴࠩᔶ")	:UUDAiytEL76RTmMYsuIz5evXB(u"࠭ๅ้ไ฼ࠤฺ๎สࠡษ็ุ๏฿ษࠡไสีห࠭ᔷ")
	,RlOvin8YIGC2KZXJPk9m0acrMobUex(u"ࠧࡴࡪࡲࡪ࡭ࡧࠧᔸ")				:UUDAiytEL76RTmMYsuIz5evXB(u"ࠨ็๋ๆ฾ࠦิ้ใ๊หࠥะ๊โ์ࠪᔹ")
	,qoBMmfAWpFlK70xw8ZRh4naJ(u"ࠩࡶ࡬ࡴࡵࡦ࡮ࡣࡻࠫᔺ")				:tQMjXKCA5dN4xq3beVIzaEoWkFLg(u"้ࠪํู่ࠡึ๋ๅ๋ࠥวไีࠪᔻ")
	,ee86G9ladLHVbh5mikzCo(u"ࠫࡸ࡮࡯ࡰࡨࡱࡩࡹ࠭ᔼ")				:mmV2nucZ5Lpl6FO1JMPEqGoQKW(u"๋่ࠬใ฻ุࠣํ็ࠠ็ฬࠪᔽ")
	,tR1krDGPpO025fghMT3a7UnYj(u"࠭ࡳࡩࡱࡲࡪࡵࡸ࡯ࠨᔾ")				:ddiCzu6yahj5RtTISMJ48sNnZBU(u"ࠧๆ๊ๅ฽ฺ่ࠥโࠢหีํ࠭ᔿ")
	,N3flV6EJsD5CzS(u"ࠨࡶ࡬࡯ࡦࡧࡴࠨᕀ")				:tR1krDGPpO025fghMT3a7UnYj(u"่ࠩ์็฿ࠠหๅสฮࠬᕁ")
	,ee86G9ladLHVbh5mikzCo(u"ࠪࡸࡻ࡬ࡵ࡯ࠩᕂ")				:dJHDqiKf12TXlIzSLkGUuxg4MBs3A(u"๊ࠫ๎โฺࠢอ๎ๆ๐ࠠโษ้ࠫᕃ")
	,qqzwE6imYG4c2xojI(u"ࠬࡼࡡࡳࡤࡲࡲࠬᕄ")				:LZWMikPEB81KSGyxfJtUsCA(u"࠭ๅ้ไ฼ࠤๆอัษ๊้ࠫᕅ")
	,zYvEaigKWjoq50pXBLDbGJkFc(u"ࠧࡷ࡫ࡧࡩࡴ࠭ᕆ")				:rNdBKI74fAklnoCZ6(u"ࠨใํำ๏๎ࠧᕇ")
	,tR1krDGPpO025fghMT3a7UnYj(u"ࠩࡹ࡭ࡩ࡫࡯࡯ࡵࡤࡩࡲ࠭ᕈ")			:V3VlkhgjEF4n1erPXHcC0NOsfwyAJ(u"้ࠪํู่ࠡใํำ๏๎ࠠ็ีสส๊࠭ᕉ")
	,CC1eY6yWZUwf2TkRvnp7EJ0AimjHBX(u"ࠫࡼ࡫ࡣࡪ࡯ࡤ࠵ࠬᕊ")				:UUDAiytEL76RTmMYsuIz5evXB(u"๋่ࠬใ฻ࠣ์๏ࠦำ๋็สࠤ࠶࠭ᕋ")
	,UVa3fJw7k6KM(u"࠭ࡷࡦࡥ࡬ࡱࡦ࠸ࠧᕌ")				:RlOvin8YIGC2KZXJPk9m0acrMobUex(u"ࠧๆ๊ๅ฽ࠥ๎๊ࠡีํ้ฬࠦ࠲ࠨᕍ")
	,sjtU6GZQg5XC2pH4(u"ࠨࡻࡤࡵࡴࡺࠧᕎ")				:tR1krDGPpO025fghMT3a7UnYj(u"่ࠩ์็฿๋ࠠษๅ์ฯ࠭ᕏ")
	,qqzwE6imYG4c2xojI(u"ࠪࡽࡴࡻࡴࡶࡤࡨࠫᕐ")				:sjtU6GZQg5XC2pH4(u"๊ࠫ๎โฺࠢํ์ฯ๐่ษࠩᕑ")
	,qoBMmfAWpFlK70xw8ZRh4naJ(u"ࠬࡿ࡯ࡶࡶࡸࡦࡪ࠳ࡣࡩࡣࡱࡲࡪࡲࡳࠨᕒ")		:RlOvin8YIGC2KZXJPk9m0acrMobUex(u"࠭ๅ้ไ฼ࠤ๏๎ส๋๊หࠤ็์่ศฬࠪᕓ")
	,rNdBKI74fAklnoCZ6(u"ࠧࡺࡱࡸࡸࡺࡨࡥ࠮ࡲ࡯ࡥࡾࡲࡩࡴࡶࡶࠫᕔ")	:UUDAiytEL76RTmMYsuIz5evXB(u"ࠨ็๋ๆ฾๊้ࠦฬํ์อࠦโ้ษษ้ࠬᕕ")
	,UUDAiytEL76RTmMYsuIz5evXB(u"ࠩࡼࡳࡺࡺࡵࡣࡧ࠰ࡺ࡮ࡪࡥࡰࡵࠪᕖ")		:qoBMmfAWpFlK70xw8ZRh4naJ(u"้ࠪํู่ࠡ์๋ฮ๏๎ศࠡใํำ๏๎็ศฬࠪᕗ")
	,mmV2nucZ5Lpl6FO1JMPEqGoQKW(u"ࠫࡾࡺࡢࡠࡥ࡫ࡥࡳࡴࡥ࡭ࡵࠪᕘ")			:BRWqdruz2A0(u"๋่ࠬศไ฼ࠤ๊์๋๊ࠠอ๎ํฮࠧᕙ")
	}
	aqA4E3bXkTNwLFyt = Z4vQNwLcAiPVufj9sOgCMU6ezEWG.lower()
	for key in list(rPpqkjNAamSGRin4gD5HYEhM86w2.keys()):
		bNS3pZDBiHelAVJXIkWTo2CyYw = key.lower()
		if aqA4E3bXkTNwLFyt==bNS3pZDBiHelAVJXIkWTo2CyYw:
			Z4vQNwLcAiPVufj9sOgCMU6ezEWG = rPpqkjNAamSGRin4gD5HYEhM86w2[key]
			break
	return Z4vQNwLcAiPVufj9sOgCMU6ezEWG
def E2E18vJ4hLaZpuWSfoMlY9yBzj6b(Z4rlgivT09OD2jG8,b9IgujrqQNZipGy=qpFY4hAwolV3):
	i4bFG3rKE6.YYhTKn1kR9i = gBExoceumj4y8bFW9hY2aNMVSr
	if not b9IgujrqQNZipGy and Z4rlgivT09OD2jG8: b9IgujrqQNZipGy = fWoVd0Bmtkx(u"࠭ࡒࡆࡓࡘࡉࡘ࡚࡟ࡓࡇࡉࡖࡊ࡙ࡈࡠࡅࡄࡇࡍࡋࠧᕚ")
	gdPslyFW8ITBcpA302.setSetting(V3VlkhgjEF4n1erPXHcC0NOsfwyAJ(u"ࠧࡢࡸ࠱ࡷࡹࡧࡴࡶࡵ࠱ࡶࡪ࡬ࡲࡦࡵ࡫ࠫᕛ"),b9IgujrqQNZipGy)
	return
def BUKlErdIu7Ggqcz3jYpf09wMePF4V(Cm4xfTO625jyMtZ8GEpvuKcnbQ1gD,dmSqhrzlYeU9pb3EPgyanjWDC=qoBMmfAWpFlK70xw8ZRh4naJ(u"ࠨ࠼࠲ࠫᕜ")):
	return _8MwxukZ1OqBPNQadU(Cm4xfTO625jyMtZ8GEpvuKcnbQ1gD,dmSqhrzlYeU9pb3EPgyanjWDC)
def LL8HwasKb3c7MgGdPVviIUW(f1fZjXNbtBiO743h):
	if f1fZjXNbtBiO743h in [qpFY4hAwolV3,fWoVd0Bmtkx(u"ࠩ࠳ࠫᕝ"),vvXoMLlg513]: return qpFY4hAwolV3
	f1fZjXNbtBiO743h = int(f1fZjXNbtBiO743h)
	FeBIOfy9wLAjJMPS1kmnUzYv = f1fZjXNbtBiO743h^KOyPvpEztYLaZRdMQJWxfTNFHbkg
	aKRePEy5FNz1SV7G32q0JhWDCT9wX = f1fZjXNbtBiO743h^kUz8c7OqsxuPFIGfwg
	PPEOdc8TaAvgQpuI1hSG3 = f1fZjXNbtBiO743h^rGY36xBwT1bLZAngSfcWEIeXdQVNij
	GGmfcn2jy9M6lBtpgA3v = str(FeBIOfy9wLAjJMPS1kmnUzYv)+str(aKRePEy5FNz1SV7G32q0JhWDCT9wX)+str(PPEOdc8TaAvgQpuI1hSG3)
	return GGmfcn2jy9M6lBtpgA3v
def mFnPSez3bN0UXqOdsB75fTJHR(f1fZjXNbtBiO743h):
	if f1fZjXNbtBiO743h in [qpFY4hAwolV3,V3VlkhgjEF4n1erPXHcC0NOsfwyAJ(u"ࠪ࠴ࠬᕞ"),vvXoMLlg513]: return qpFY4hAwolV3
	f1fZjXNbtBiO743h = str(f1fZjXNbtBiO743h)
	GGmfcn2jy9M6lBtpgA3v = qpFY4hAwolV3
	if len(f1fZjXNbtBiO743h)==LZWMikPEB81KSGyxfJtUsCA(u"࠳࠸᝜"):
		FeBIOfy9wLAjJMPS1kmnUzYv,aKRePEy5FNz1SV7G32q0JhWDCT9wX,PPEOdc8TaAvgQpuI1hSG3 = f1fZjXNbtBiO743h[vvXoMLlg513:wn4bG51vUENfaS0Zg],f1fZjXNbtBiO743h[wn4bG51vUENfaS0Zg:aXqWLoTdVgME(u"࠼᝝")],f1fZjXNbtBiO743h[aXqWLoTdVgME(u"࠼᝝"):]
		FeBIOfy9wLAjJMPS1kmnUzYv = int(FeBIOfy9wLAjJMPS1kmnUzYv)^rGY36xBwT1bLZAngSfcWEIeXdQVNij
		aKRePEy5FNz1SV7G32q0JhWDCT9wX = int(aKRePEy5FNz1SV7G32q0JhWDCT9wX)^kUz8c7OqsxuPFIGfwg
		PPEOdc8TaAvgQpuI1hSG3 = int(PPEOdc8TaAvgQpuI1hSG3)^KOyPvpEztYLaZRdMQJWxfTNFHbkg
		if FeBIOfy9wLAjJMPS1kmnUzYv==aKRePEy5FNz1SV7G32q0JhWDCT9wX==PPEOdc8TaAvgQpuI1hSG3: GGmfcn2jy9M6lBtpgA3v = str(FeBIOfy9wLAjJMPS1kmnUzYv*BRWqdruz2A0(u"࠺࠵᝞"))
	return GGmfcn2jy9M6lBtpgA3v
def Ikw7JgrXvRT8zteLb5sV6WidBN(f1fZjXNbtBiO743h,wfFS5pjdAMqEDa=rNdBKI74fAklnoCZ6(u"ࠫ࠻࠹࠸࠵࠳࠻࠶࠸࠭ᕟ")):
	if f1fZjXNbtBiO743h==qpFY4hAwolV3: return qpFY4hAwolV3
	f1fZjXNbtBiO743h = int(f1fZjXNbtBiO743h)+int(wfFS5pjdAMqEDa)
	FeBIOfy9wLAjJMPS1kmnUzYv = f1fZjXNbtBiO743h^KOyPvpEztYLaZRdMQJWxfTNFHbkg
	aKRePEy5FNz1SV7G32q0JhWDCT9wX = f1fZjXNbtBiO743h^kUz8c7OqsxuPFIGfwg
	PPEOdc8TaAvgQpuI1hSG3 = f1fZjXNbtBiO743h^rGY36xBwT1bLZAngSfcWEIeXdQVNij
	GGmfcn2jy9M6lBtpgA3v = str(FeBIOfy9wLAjJMPS1kmnUzYv)+str(aKRePEy5FNz1SV7G32q0JhWDCT9wX)+str(PPEOdc8TaAvgQpuI1hSG3)
	return GGmfcn2jy9M6lBtpgA3v
def NinEO2UTBHXh(f1fZjXNbtBiO743h,wfFS5pjdAMqEDa=iNc3KxwErnQ(u"ࠬ࠼࠳࠹࠶࠴࠼࠷࠹ࠧᕠ")):
	if f1fZjXNbtBiO743h==qpFY4hAwolV3: return qpFY4hAwolV3
	f1fZjXNbtBiO743h = str(f1fZjXNbtBiO743h)
	TPmOZ5fE7qCcw = int(len(f1fZjXNbtBiO743h)/DAE6vkyhXGx1wBdHmcFfTVQpL0l)
	FeBIOfy9wLAjJMPS1kmnUzYv = int(f1fZjXNbtBiO743h[vvXoMLlg513:TPmOZ5fE7qCcw])^KOyPvpEztYLaZRdMQJWxfTNFHbkg
	aKRePEy5FNz1SV7G32q0JhWDCT9wX = int(f1fZjXNbtBiO743h[TPmOZ5fE7qCcw:Zwqio2AIWlD5etFa*TPmOZ5fE7qCcw])^kUz8c7OqsxuPFIGfwg
	PPEOdc8TaAvgQpuI1hSG3 = int(f1fZjXNbtBiO743h[Zwqio2AIWlD5etFa*TPmOZ5fE7qCcw:DAE6vkyhXGx1wBdHmcFfTVQpL0l*TPmOZ5fE7qCcw])^rGY36xBwT1bLZAngSfcWEIeXdQVNij
	GGmfcn2jy9M6lBtpgA3v = qpFY4hAwolV3
	if FeBIOfy9wLAjJMPS1kmnUzYv==aKRePEy5FNz1SV7G32q0JhWDCT9wX==PPEOdc8TaAvgQpuI1hSG3: GGmfcn2jy9M6lBtpgA3v = str(int(FeBIOfy9wLAjJMPS1kmnUzYv)-int(wfFS5pjdAMqEDa))
	return GGmfcn2jy9M6lBtpgA3v
def nQfs1hgqHNaAXRKVIyLSvE5U(Jbc92fgvQqeRL0):
	IIuXldCPGFHOp = i4bFG3rKE6.SITESURLS[ddiCzu6yahj5RtTISMJ48sNnZBU(u"࠭ࡐ࡚ࡖࡋࡓࡓ࠭ᕡ")][ee86G9ladLHVbh5mikzCo(u"࠽᝟")]
	jIxo6UkZmf = RPbaxsNFVTwek5Kfv21DiJuzCnjMZp.path.join(mFGa34JHCw9LWlB0,l32dnTEOU1skGKqeBtI9hmo(u"ࠧࡳࡧࡶࡳࡺࡸࡣࡦࡵࠪᕢ"),tQMjXKCA5dN4xq3beVIzaEoWkFLg(u"ࠨࡵ࡮࡭ࡳࡹࠧᕣ"),c2RKu0xG1eC8MiohyE(u"ࠩࡇࡩ࡫ࡧࡵ࡭ࡶࠪᕤ"),Ie5s2cBtSfdHjzQ4rA9kYlo6D18(u"ࠪ࠻࠷࠶ࡰࠨᕥ"),IaBhDMJc17302LgSvyxd(u"ࠫࡉ࡯ࡡ࡭ࡱࡪࡇࡴࡴࡦࡪࡴࡰࡘ࡭ࡸࡥࡦࡄࡸࡸࡹࡵ࡮ࡴ࠰ࡻࡱࡱ࠭ᕦ"))
	IuHBvEA23Vi9dlUmKophCrn1,MszCVub2p5Ddw = e2YrFAdw9WBl8740uPKUcGCbL(jIxo6UkZmf)
	IuHBvEA23Vi9dlUmKophCrn1 = Ikw7JgrXvRT8zteLb5sV6WidBN(IuHBvEA23Vi9dlUmKophCrn1,viRJWOC5jsYe84(u"ࠬ࠷࠲࠲࠺࠶࠵࠽࠻࠳ࠨᕧ"))
	rpPU0hMTE6fQx = {mmV2nucZ5Lpl6FO1JMPEqGoQKW(u"࠭ࡩࡥࡵࠪᕨ"):N3flV6EJsD5CzS(u"ࠧࡅࡋࡄࡐࡔࡍࠧᕩ"),LZWMikPEB81KSGyxfJtUsCA(u"ࠨࡷࡶࡶࠬᕪ"):i4bFG3rKE6.AV_CLIENT_IDS,IaBhDMJc17302LgSvyxd(u"ࠩࡹࡩࡷ࠭ᕫ"):Q8q1YzIF6icWtSp2L,YY8UDX3MJhb91AHw7fg(u"ࠪࡷࡨࡸࠧᕬ"):Jbc92fgvQqeRL0,LZWMikPEB81KSGyxfJtUsCA(u"ࠫࡸ࡯ࡺࠨᕭ"):IuHBvEA23Vi9dlUmKophCrn1}
	PMHf9mpNv6jLUz = {qqzwE6imYG4c2xojI(u"ࠬࡉ࡯࡯ࡶࡨࡲࡹ࠳ࡔࡺࡲࡨࠫᕮ"):mmV2nucZ5Lpl6FO1JMPEqGoQKW(u"࠭ࡡࡱࡲ࡯࡭ࡨࡧࡴࡪࡱࡱ࠳ࡽ࠳ࡷࡸࡹ࠰ࡪࡴࡸ࡭࠮ࡷࡵࡰࡪࡴࡣࡰࡦࡨࡨࠬᕯ")}
	WjpGS1BQ4KfD = WWrExJZS3Bj4anOAkpv7(kUz8c7OqsxuPFIGfwg,tR1krDGPpO025fghMT3a7UnYj(u"ࠧࡑࡑࡖࡘࠬᕰ"),IIuXldCPGFHOp,rpPU0hMTE6fQx,PMHf9mpNv6jLUz,qpFY4hAwolV3,qpFY4hAwolV3,fWoVd0Bmtkx(u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡖࡌࡔ࡝࡟ࡑࡎࡄ࡝ࡤࡊࡉࡂࡎࡒࡋ࠲࠷ࡳࡵࠩᕱ"))
	DDhuOF6ay0kdoW = WjpGS1BQ4KfD.content
	try:
		if not DDhuOF6ay0kdoW: u0ibzAH5ECYewVL
		OsLR3laitQr01fUNKb9TZIuozP = wB8NUAidPbqjIr9CFasXvYnxOQpL0g(rNdBKI74fAklnoCZ6(u"ࠩࡧ࡭ࡨࡺࠧᕲ"),DDhuOF6ay0kdoW)
		hrRABN5cWymJdtxG = OsLR3laitQr01fUNKb9TZIuozP[fWoVd0Bmtkx(u"ࠪࡱࡸ࡭ࠧᕳ")]
		D0vsemjUP8R = OsLR3laitQr01fUNKb9TZIuozP[qqzwE6imYG4c2xojI(u"ࠫࡸ࡫ࡣࠨᕴ")]
		UTNAqvbxfEIS1 = OsLR3laitQr01fUNKb9TZIuozP[UVa3fJw7k6KM(u"ࠬࡹࡴࡱࠩᕵ")]
		D0vsemjUP8R = int(NinEO2UTBHXh(D0vsemjUP8R,c2RKu0xG1eC8MiohyE(u"࠭࠱࠳࠳࠻࠷࠶࠾࠵࠴ࠩᕶ")))
		UTNAqvbxfEIS1 = int(NinEO2UTBHXh(UTNAqvbxfEIS1,RlOvin8YIGC2KZXJPk9m0acrMobUex(u"ࠧ࠲࠴࠴࠼࠸࠷࠸࠶࠵ࠪᕷ")))
		for W3Cp6XfoUP0RLebD7 in range(D0vsemjUP8R,vvXoMLlg513,-UTNAqvbxfEIS1):
			if not eval(Ie5s2cBtSfdHjzQ4rA9kYlo6D18(u"ࠨࡺࡥࡱࡨ࠴ࡐ࡭ࡣࡼࡩࡷ࠮ࠩ࠯࡫ࡶࡔࡱࡧࡹࡪࡰࡪࠬ࠮࠭ᕸ"),{IaBhDMJc17302LgSvyxd(u"ࠩࡻࡦࡲࡩࠧᕹ"):Rqvw05BorCgcye7VE32Sf}): u0ibzAH5ECYewVL
			t8yiLuJp3cBA6d1QE9x7eZ4fa(lljaEqwTVtmKsQcOrbXxS5hgNH(u"ࠪฬฬ่๊ࠡๆ็ฮัืศส๋ࠢห้็อึࠩᕺ"),str(W3Cp6XfoUP0RLebD7)+IaBhDMJc17302LgSvyxd(u"ࠫࠥࠦหศ่ํอࠬᕻ"),s7FnXZYOgexlH2MPb8BJck1AKv9=UVa3fJw7k6KM(u"࠷࠰࠱ᝠ")*UTNAqvbxfEIS1)
			Rqvw05BorCgcye7VE32Sf.sleep(IaBhDMJc17302LgSvyxd(u"࠱࠱࠲࠳ᝡ")*UTNAqvbxfEIS1)
		if eval(YY8UDX3MJhb91AHw7fg(u"ࠬࡾࡢ࡮ࡥ࠱ࡔࡱࡧࡹࡦࡴࠫ࠭࠳࡯ࡳࡑ࡮ࡤࡽ࡮ࡴࡧࠩࠫࠪᕼ"),{V3VlkhgjEF4n1erPXHcC0NOsfwyAJ(u"࠭ࡸࡣ࡯ࡦࠫᕽ"):Rqvw05BorCgcye7VE32Sf}):
			hrRABN5cWymJdtxG = hrRABN5cWymJdtxG.replace(ZLwoRpfnCWI7FgEHsz6te39lMVh,rNdBKI74fAklnoCZ6(u"ࠧ࡝࡞ࡱࠫᕾ")).replace(SGUiazdreo6QRKLOWZj5hMX,BRWqdruz2A0(u"ࠨ࡞࡟ࡶࠬᕿ"))
			iG7Rz2kmn0x1yLNMV3u8O(qpFY4hAwolV3,YY8UDX3MJhb91AHw7fg(u"ࠩัีําࠧᖀ"),GLTtERWbHnFuy4PCp,hrRABN5cWymJdtxG)
		u0ibzAH5ECYewVL
	except: exec(ddiCzu6yahj5RtTISMJ48sNnZBU(u"ࠪࡼࡧࡳࡣ࠯ࡒ࡯ࡥࡾ࡫ࡲࠩࠫ࠱ࡷࡹࡵࡰࠩࠫࠪᖁ"),{tQMjXKCA5dN4xq3beVIzaEoWkFLg(u"ࠫࡽࡨ࡭ࡤࠩᖂ"):Rqvw05BorCgcye7VE32Sf})
	return
def UCqxwyZsFuJj8AXrO7D3KpIPvT6():
	exec(l1DZAt9XNQjqE7YOdrz(u"ࠬ࠭ࠧࠎࠌࡷࡶࡾࡀࠍࠋࠋࡺ࡭ࡳࡪ࡯ࡸ࠳࠵࠷ࠥࡃࠠࡹࡤࡰࡧ࡬ࡻࡩ࠯࡙࡬ࡲࡩࡵࡷࠩ࠳࠳࠴࠷࠻ࠩࠎࠌࠌࡻ࡭࡯࡬ࡦࠢࡗࡶࡺ࡫࠺ࠎࠌࠌࠍࡽࡨ࡭ࡤ࠰ࡶࡰࡪ࡫ࡰࠩ࠳࠳࠴࠵࠯ࠍࠋࠋࠌࡸࡷࡿ࠺ࠡࡹ࡬ࡲࡩࡵࡷ࠲࠴࠶࠲࡬࡫ࡴࡇࡱࡦࡹࡸ࠮࠱࠱࠲࠵࠹࠮ࠓࠊࠊࠋࡨࡼࡨ࡫ࡰࡵ࠼ࠣࡦࡷ࡫ࡡ࡬ࠏࠍࠍࡿࡩࡲࡦࡣࡷࡩࡤ࡫ࡲࡰࡴࡵࠑࠏ࡫ࡸࡤࡧࡳࡸ࠿ࠦࡸࡣ࡯ࡦ࠲ࡕࡲࡡࡺࡧࡵࠬ࠮࠴ࡳࡵࡱࡳࠬ࠮ࠓࠊࠨࠩࠪᖃ"),{CC1eY6yWZUwf2TkRvnp7EJ0AimjHBX(u"࠭ࡸࡣ࡯ࡦ࡫ࡺ࡯ࠧᖄ"):q5Kah0DftjNzV,YY8UDX3MJhb91AHw7fg(u"ࠧࡹࡤࡰࡧࠬᖅ"):Rqvw05BorCgcye7VE32Sf})
	return
def e2YrFAdw9WBl8740uPKUcGCbL(xxaz1IN5QGdc):
	bbh5fcJDG8NWp6z0,VC3guEILhR = vvXoMLlg513,vvXoMLlg513
	if RPbaxsNFVTwek5Kfv21DiJuzCnjMZp.path.exists(xxaz1IN5QGdc):
		try: bbh5fcJDG8NWp6z0 = RPbaxsNFVTwek5Kfv21DiJuzCnjMZp.path.getsize(xxaz1IN5QGdc)
		except: pass
		if not bbh5fcJDG8NWp6z0:
			try: bbh5fcJDG8NWp6z0 = RPbaxsNFVTwek5Kfv21DiJuzCnjMZp.stat(xxaz1IN5QGdc).st_size
			except: pass
		if not bbh5fcJDG8NWp6z0:
			try:
				from pathlib import Path as WIgCd9rbzyh7ov
				bbh5fcJDG8NWp6z0 = WIgCd9rbzyh7ov(xxaz1IN5QGdc).stat().st_size
			except: pass
		if bbh5fcJDG8NWp6z0: VC3guEILhR = mZi0S72jGoHpLO
	return bbh5fcJDG8NWp6z0,VC3guEILhR
def woKpIqdvBGa6mgy3P2DnXHCQ(kpJsvnqfj2DO17zB96Ta5Y,showDialogs):
	if showDialogs:
		o4oUxD3u18K59ghHIY = VVpbtSKYUGXrNMwAWFo9IOjZP(qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,GLTtERWbHnFuy4PCp,kpJsvnqfj2DO17zB96Ta5Y+YY8UDX3MJhb91AHw7fg(u"ࠨ࡞ࡱࡠࡳ࠭ᖆ")+xupTj02bvy3O8R+iNc3KxwErnQ(u"๊่ࠩࠥะั๋ัุ้ࠣำ่ࠠาสࠤฬ๊ๅๅใࠣรࠦ࠭ᖇ")+fF4lt9zWYxXLKZVyAco82PgMj)
		if o4oUxD3u18K59ghHIY!=qqzwE6imYG4c2xojI(u"࠲ᝢ"): return ag8rjZo1Vz4IPdcOT
	succeeded = gBExoceumj4y8bFW9hY2aNMVSr
	if RPbaxsNFVTwek5Kfv21DiJuzCnjMZp.path.exists(kpJsvnqfj2DO17zB96Ta5Y):
		try: RPbaxsNFVTwek5Kfv21DiJuzCnjMZp.remove(kpJsvnqfj2DO17zB96Ta5Y.decode(nV3Tip6XsH1rJw79DPOU))
		except:
			try: RPbaxsNFVTwek5Kfv21DiJuzCnjMZp.remove(omXFcvMCRVp)
			except Exception as Afgoj31Zzp6XeHU7I:
				succeeded = ag8rjZo1Vz4IPdcOT
				if showDialogs: iG7Rz2kmn0x1yLNMV3u8O(qpFY4hAwolV3,qpFY4hAwolV3,GLTtERWbHnFuy4PCp,str(Afgoj31Zzp6XeHU7I))
	if showDialogs:
		if succeeded: iG7Rz2kmn0x1yLNMV3u8O(qpFY4hAwolV3,qpFY4hAwolV3,GLTtERWbHnFuy4PCp,V3VlkhgjEF4n1erPXHcC0NOsfwyAJ(u"ࠪๅู๊สࠡ฻่่๏ฯࠠๆีะࠤฬ๊ๅๅใࠪᖈ"))
		else: iG7Rz2kmn0x1yLNMV3u8O(qpFY4hAwolV3,qpFY4hAwolV3,GLTtERWbHnFuy4PCp,mmV2nucZ5Lpl6FO1JMPEqGoQKW(u"ࠫฯ๋ࠠศๆ่ืาࠦศ็ฮสัࠬᖉ"))
	return succeeded
def EOJmze1pUvdCgVPLRt3(LtXQ5jUcTveIgZD0W,ccPH6gXQZwYKnVvGSEO,showDialogs):
	if showDialogs:
		o4oUxD3u18K59ghHIY = VVpbtSKYUGXrNMwAWFo9IOjZP(qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,GLTtERWbHnFuy4PCp,LtXQ5jUcTveIgZD0W+ddiCzu6yahj5RtTISMJ48sNnZBU(u"ࠬࡢ࡮࡝ࡰࠪᖊ")+xupTj02bvy3O8R+mmV2nucZ5Lpl6FO1JMPEqGoQKW(u"࠭็ๅࠢอี๏ีࠠๆีะࠤ์ึวࠡษ็้ั๊ฯࠡมࠤࠫᖋ")+fF4lt9zWYxXLKZVyAco82PgMj)
		if o4oUxD3u18K59ghHIY!=mZi0S72jGoHpLO: return ag8rjZo1Vz4IPdcOT
	succeeded = gBExoceumj4y8bFW9hY2aNMVSr
	if RPbaxsNFVTwek5Kfv21DiJuzCnjMZp.path.exists(LtXQ5jUcTveIgZD0W):
		for f9wTYGXyuPAbWQRB6o5MNzZgJ1nO,VrN3pmC0XdMoF5UGYJkbuengS,vN0gZI3nVwehLcsEjxm6 in RPbaxsNFVTwek5Kfv21DiJuzCnjMZp.walk(LtXQ5jUcTveIgZD0W,topdown=ag8rjZo1Vz4IPdcOT):
			for xxaz1IN5QGdc in vN0gZI3nVwehLcsEjxm6:
				Pz546fUa8OM2ihjSR1Yl3LW = RPbaxsNFVTwek5Kfv21DiJuzCnjMZp.path.join(f9wTYGXyuPAbWQRB6o5MNzZgJ1nO,xxaz1IN5QGdc)
				try: RPbaxsNFVTwek5Kfv21DiJuzCnjMZp.remove(Pz546fUa8OM2ihjSR1Yl3LW)
				except Exception as Afgoj31Zzp6XeHU7I:
					succeeded = ag8rjZo1Vz4IPdcOT
					if showDialogs: iG7Rz2kmn0x1yLNMV3u8O(qpFY4hAwolV3,qpFY4hAwolV3,GLTtERWbHnFuy4PCp,str(Afgoj31Zzp6XeHU7I))
			if ccPH6gXQZwYKnVvGSEO:
				for dir in VrN3pmC0XdMoF5UGYJkbuengS:
					pG6lJ8Y3aARDyq9QwoKBNFEhIc = RPbaxsNFVTwek5Kfv21DiJuzCnjMZp.path.join(f9wTYGXyuPAbWQRB6o5MNzZgJ1nO,dir)
					try: RPbaxsNFVTwek5Kfv21DiJuzCnjMZp.rmdir(pG6lJ8Y3aARDyq9QwoKBNFEhIc)
					except: pass
		if ccPH6gXQZwYKnVvGSEO:
			try: RPbaxsNFVTwek5Kfv21DiJuzCnjMZp.rmdir(f9wTYGXyuPAbWQRB6o5MNzZgJ1nO)
			except: pass
	if showDialogs:
		if succeeded: iG7Rz2kmn0x1yLNMV3u8O(qpFY4hAwolV3,qpFY4hAwolV3,GLTtERWbHnFuy4PCp,iNc3KxwErnQ(u"ࠧห็ࠣห้๋ำฮࠢห๊ัออࠨᖌ"))
		else: iG7Rz2kmn0x1yLNMV3u8O(qpFY4hAwolV3,qpFY4hAwolV3,GLTtERWbHnFuy4PCp,IaBhDMJc17302LgSvyxd(u"ࠨๆ็วุ็ࠠโึ็ฮࠥ฿ๅๅ์ฬࠤฬ๊ๅิฯࠪᖍ"))
	return succeeded
def Tp3qzUdr8iNZYX1(BigAz2Owj3arMN5J6RGFk8PTq,z5nOUetfoJHbP6294ghwur,Cm4xfTO625jyMtZ8GEpvuKcnbQ1gD,dimhv1XTVH8UOrc9EGJZ6,ppuvkQrgA1i8WwY3ftNJx7Ba9jH,n38oH7wd6BDyAMJQS):
	WSQlG8mDhqsNe,Hitbcw146SAGnegpqP5zrJUxTW8vBO,vLNaxndFy5jGkTiQhYX,KKf8YWi2FyGABj = HSQlpuY1RZfmob4iqMP9kjeV5rch(Cm4xfTO625jyMtZ8GEpvuKcnbQ1gD)
	ZaxVkzo39s8Hjd7RMW1fC = z5nOUetfoJHbP6294ghwur,WSQlG8mDhqsNe,dimhv1XTVH8UOrc9EGJZ6,ppuvkQrgA1i8WwY3ftNJx7Ba9jH
	if N3flV6EJsD5CzS(u"ࠩࡐࡅࡎࡔ࡟ࡅࡋࡖࡔࡆ࡚ࡃࡉࡇࡕࡣࡈࡇࡃࡉࡇࡇࠫᖎ") in n38oH7wd6BDyAMJQS:
		gCzS3XIbaR4dsrWYF9n2TVwAfOk = dimhv1XTVH8UOrc9EGJZ6.get(DiJ8CMuYH1daWyjehfN0L(u"ࠪࡺࡦࡲࡵࡦࠩᖏ"))
		if gCzS3XIbaR4dsrWYF9n2TVwAfOk:
			JvCQhctHKErfp15XBZ = gCzS3XIbaR4dsrWYF9n2TVwAfOk.split(aXqWLoTdVgME(u"ࠫࡤࡥࡓࡆࡒࡢࡣࠬᖐ"),zYvEaigKWjoq50pXBLDbGJkFc(u"࠳ᝣ"))[zYvEaigKWjoq50pXBLDbGJkFc(u"࠳ᝣ")]
			XXE7IoFQWNkPgyBv34ftiTLD1HC = dimhv1XTVH8UOrc9EGJZ6.copy()
			XXE7IoFQWNkPgyBv34ftiTLD1HC[aXqWLoTdVgME(u"ࠬࡼࡡ࡭ࡷࡨࠫᖑ")] = JvCQhctHKErfp15XBZ
			ZaxVkzo39s8Hjd7RMW1fC = z5nOUetfoJHbP6294ghwur,WSQlG8mDhqsNe,XXE7IoFQWNkPgyBv34ftiTLD1HC,ppuvkQrgA1i8WwY3ftNJx7Ba9jH
	if BigAz2Owj3arMN5J6RGFk8PTq<l1DZAt9XNQjqE7YOdrz(u"࠳ᝤ"):
		mlykPoGXbJIjFnarp9KihxfN(WoFsvbmUlDZp7PzRfdGknCV,aXqWLoTdVgME(u"࠭ࡏࡑࡇࡑ࡙ࡗࡒ࡟ࡖࡔࡏࡐࡎࡈࠧᖒ"),ZaxVkzo39s8Hjd7RMW1fC)
		BigAz2Owj3arMN5J6RGFk8PTq = -BigAz2Owj3arMN5J6RGFk8PTq
	if BigAz2Owj3arMN5J6RGFk8PTq>qoBMmfAWpFlK70xw8ZRh4naJ(u"࠴ᝥ"):
		eVEX29oO0qZjxltJKIfbc8aSd = XXyMBNAVJvKiq7jc20bEw6(WoFsvbmUlDZp7PzRfdGknCV,YY8UDX3MJhb91AHw7fg(u"ࠧࡴࡶࡵࠫᖓ"),rNdBKI74fAklnoCZ6(u"ࠨࡑࡓࡉࡓ࡛ࡒࡍࡡࡘࡖࡑࡒࡉࡃࠩᖔ"),ZaxVkzo39s8Hjd7RMW1fC)
		if eVEX29oO0qZjxltJKIfbc8aSd:
			h9hOUpTxk0(RlOvin8YIGC2KZXJPk9m0acrMobUex(u"ࠩࡘࡖࡑࡒࡉࡃࠢࠣࡖࡊࡇࡄࡠࡅࡄࡇࡍࡋࠧᖕ"),Cm4xfTO625jyMtZ8GEpvuKcnbQ1gD,dimhv1XTVH8UOrc9EGJZ6,ppuvkQrgA1i8WwY3ftNJx7Ba9jH,n38oH7wd6BDyAMJQS,z5nOUetfoJHbP6294ghwur)
			return eVEX29oO0qZjxltJKIfbc8aSd[wn4bG51vUENfaS0Zg:]
	eVEX29oO0qZjxltJKIfbc8aSd = SXEgBUeDR78i40AoZupqclMhmxfN(z5nOUetfoJHbP6294ghwur,Cm4xfTO625jyMtZ8GEpvuKcnbQ1gD,dimhv1XTVH8UOrc9EGJZ6,ppuvkQrgA1i8WwY3ftNJx7Ba9jH,n38oH7wd6BDyAMJQS)
	eVEX29oO0qZjxltJKIfbc8aSd = M04Bcjvt8SFaeQEK+eVEX29oO0qZjxltJKIfbc8aSd
	if BigAz2Owj3arMN5J6RGFk8PTq: zOYMaQ0NgdiRVwDJXh8e(WoFsvbmUlDZp7PzRfdGknCV,DiJ8CMuYH1daWyjehfN0L(u"ࠪࡓࡕࡋࡎࡖࡔࡏࡣ࡚ࡘࡌࡍࡋࡅࠫᖖ"),ZaxVkzo39s8Hjd7RMW1fC,eVEX29oO0qZjxltJKIfbc8aSd,BigAz2Owj3arMN5J6RGFk8PTq)
	return eVEX29oO0qZjxltJKIfbc8aSd[wn4bG51vUENfaS0Zg:]
def U89T5Btp7JjNmDxGzK4M(Q8Q0IDc6PLZajJAdTntKUmSGXz,gxaeEfCylRiH4T9t12zb7PqYSrsv,b9McgtL5WvIGf3jKYm1Q0H=vvXoMLlg513):
	gXv0HlqtLKTaJZWnC = gdPslyFW8ITBcpA302.getSetting(Ie5s2cBtSfdHjzQ4rA9kYlo6D18(u"ࠫࡦࡼ࠮ࡴࡶࡤࡸࡺࡹ࠮ࡣ࡫ࡷࡶࡦࡺࡥࠨᖗ"))
	if gXv0HlqtLKTaJZWnC and iNc3KxwErnQ(u"ࠬ࠳ࠧᖘ") not in gXv0HlqtLKTaJZWnC: SRumox0JwQpaA8MidjtKLPe,cQLiPwWuCZ4I9hjEOfBG = int(gXv0HlqtLKTaJZWnC),gBExoceumj4y8bFW9hY2aNMVSr
	elif b9McgtL5WvIGf3jKYm1Q0H: SRumox0JwQpaA8MidjtKLPe,cQLiPwWuCZ4I9hjEOfBG = b9McgtL5WvIGf3jKYm1Q0H,ag8rjZo1Vz4IPdcOT
	else: return []
	GsC7KiUokxFlbYtJEjROpNv5zD3a,iEWJ1FdbmIa3ZvCfyjtzXpQ = [],qpFY4hAwolV3
	W2b4CmHY9kp,Zoqz21G7RiL5gfp,PnJN2Ooks5,WevZpbYuhiw4VRHU5a = qpFY4hAwolV3,qpFY4hAwolV3,vvXoMLlg513,vvXoMLlg513
	gxaeEfCylRiH4T9t12zb7PqYSrsv = sorted(gxaeEfCylRiH4T9t12zb7PqYSrsv,reverse=gBExoceumj4y8bFW9hY2aNMVSr,key=lambda key: (key[mZi0S72jGoHpLO],key[Zwqio2AIWlD5etFa]))
	for stream,PeWih1lgsZEUt8TQHnfRqdob5Xa,v6yW5DfOsGhBkj4nzUSwEMXReHa in gxaeEfCylRiH4T9t12zb7PqYSrsv+[[qpFY4hAwolV3,qpFY4hAwolV3,vvXoMLlg513]]:
		if PeWih1lgsZEUt8TQHnfRqdob5Xa==iEWJ1FdbmIa3ZvCfyjtzXpQ:
			if v6yW5DfOsGhBkj4nzUSwEMXReHa>SRumox0JwQpaA8MidjtKLPe: Zoqz21G7RiL5gfp,WevZpbYuhiw4VRHU5a = stream,v6yW5DfOsGhBkj4nzUSwEMXReHa
			elif not W2b4CmHY9kp: W2b4CmHY9kp,PnJN2Ooks5 = stream,v6yW5DfOsGhBkj4nzUSwEMXReHa
		else:
			if Zoqz21G7RiL5gfp or W2b4CmHY9kp:
				if W2b4CmHY9kp: GsC7KiUokxFlbYtJEjROpNv5zD3a.append([W2b4CmHY9kp,iEWJ1FdbmIa3ZvCfyjtzXpQ,PnJN2Ooks5])
				elif Zoqz21G7RiL5gfp: GsC7KiUokxFlbYtJEjROpNv5zD3a.append([Zoqz21G7RiL5gfp,iEWJ1FdbmIa3ZvCfyjtzXpQ,WevZpbYuhiw4VRHU5a])
			if v6yW5DfOsGhBkj4nzUSwEMXReHa>SRumox0JwQpaA8MidjtKLPe:
				Zoqz21G7RiL5gfp,WevZpbYuhiw4VRHU5a = stream,v6yW5DfOsGhBkj4nzUSwEMXReHa
				W2b4CmHY9kp,PnJN2Ooks5 = qpFY4hAwolV3,vvXoMLlg513
			else:
				Zoqz21G7RiL5gfp,WevZpbYuhiw4VRHU5a = qpFY4hAwolV3,vvXoMLlg513
				W2b4CmHY9kp,PnJN2Ooks5 = stream,v6yW5DfOsGhBkj4nzUSwEMXReHa
		iEWJ1FdbmIa3ZvCfyjtzXpQ = PeWih1lgsZEUt8TQHnfRqdob5Xa
	if cQLiPwWuCZ4I9hjEOfBG:
		l5lTKsEuZgHdcLr,ew5PcmQDZk9LKHXt3GivE2sjb4,yBNX7dtIGrpe5OabPR0vUxY = zip(*GsC7KiUokxFlbYtJEjROpNv5zD3a)
		xLUcinRHV79a2J5fKYEh8G1FZlDW4 = [l32dnTEOU1skGKqeBtI9hmo(u"࠭࡭ࡱ࠶ࠪᖙ"),qoBMmfAWpFlK70xw8ZRh4naJ(u"ࠧ࡮ࡲࡧࠫᖚ"),sjtU6GZQg5XC2pH4(u"ࠨࡶࡶࠫᖛ"),c2RKu0xG1eC8MiohyE(u"ࠩࡰ࠷ࡺ࠭ᖜ")]
		for PeWih1lgsZEUt8TQHnfRqdob5Xa in xLUcinRHV79a2J5fKYEh8G1FZlDW4:
			if PeWih1lgsZEUt8TQHnfRqdob5Xa in ew5PcmQDZk9LKHXt3GivE2sjb4:
				index = ew5PcmQDZk9LKHXt3GivE2sjb4.index(PeWih1lgsZEUt8TQHnfRqdob5Xa)
				GsC7KiUokxFlbYtJEjROpNv5zD3a = [[l5lTKsEuZgHdcLr[index],ew5PcmQDZk9LKHXt3GivE2sjb4[index],yBNX7dtIGrpe5OabPR0vUxY[index]]]
				break
	return GsC7KiUokxFlbYtJEjROpNv5zD3a
def uArTHUNiXlYWROV9DmgvoGFbL8M(jdoGiRX6SpfJzVIPAueb8M5Ys):
	q30elgHcyPKrSVpbsiIn5G,lLGMSJOP5TI = [],H1k0Fmba4Gfiynp8AML
	for j7HgbsXoUDfzcSkmniPu9w6 in YJtxGoaiQlSndzECbOrRWLjhk:
		if j7HgbsXoUDfzcSkmniPu9w6==rNdBKI74fAklnoCZ6(u"ࠪࡔࡗࡏࡖࡂࡖࡈࠫᖝ"): lLGMSJOP5TI = (ddiCzu6yahj5RtTISMJ48sNnZBU(u"ࠫࡱ࡯࡮࡬ࠩᖞ"),xupTj02bvy3O8R+CC1eY6yWZUwf2TkRvnp7EJ0AimjHBX(u"๋่ࠬศไ฼ࠤุ๐ัโำสฮࠥิวึหࠣ࠱่ࠥไ๋ๆฬࠤฬ๊ๅีษๆ่ࠬᖟ")+fF4lt9zWYxXLKZVyAco82PgMj,qpFY4hAwolV3,tR1krDGPpO025fghMT3a7UnYj(u"࠶࠻࠷ᝦ"),qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3)
		elif j7HgbsXoUDfzcSkmniPu9w6==c2RKu0xG1eC8MiohyE(u"࠭ࡍࡊ࡚ࡈࡈࠬᖠ"): lLGMSJOP5TI = (YY8UDX3MJhb91AHw7fg(u"ࠧ࡭࡫ࡱ࡯ࠬᖡ"),xupTj02bvy3O8R+UVa3fJw7k6KM(u"ࠨ็๋ห็฿ࠠิ์ิๅึอสࠡะสูฮฺ่ࠦษ่อࠥ࠳ࠠไอํีฮࠦวๅ็ืห่๊ࠧᖢ")+fF4lt9zWYxXLKZVyAco82PgMj,qpFY4hAwolV3,BRWqdruz2A0(u"࠷࠵࠸ᝧ"),qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3)
		elif j7HgbsXoUDfzcSkmniPu9w6==c2RKu0xG1eC8MiohyE(u"ࠩࡓ࡙ࡇࡒࡉࡄࠩᖣ"): lLGMSJOP5TI = (aXqWLoTdVgME(u"ࠪࡰ࡮ࡴ࡫ࠨᖤ"),xupTj02bvy3O8R+zYvEaigKWjoq50pXBLDbGJkFc(u"๊ࠫ๎วใ฻ࠣื๏ืแาษอࠤ฾อๅสࠢ࠰ࠤ่ั๊าหࠣห้๋ิศๅ็ࠫᖥ")+fF4lt9zWYxXLKZVyAco82PgMj,qpFY4hAwolV3,ddiCzu6yahj5RtTISMJ48sNnZBU(u"࠱࠶࠹ᝨ"),qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3)
		if j7HgbsXoUDfzcSkmniPu9w6 not in jdoGiRX6SpfJzVIPAueb8M5Ys: continue
		if lLGMSJOP5TI:
			q30elgHcyPKrSVpbsiIn5G.append(lLGMSJOP5TI)
			lLGMSJOP5TI = H1k0Fmba4Gfiynp8AML
		if j7HgbsXoUDfzcSkmniPu9w6 not in [l1DZAt9XNQjqE7YOdrz(u"ࠬࡖࡒࡊࡘࡄࡘࡊ࠭ᖦ"),Ie5s2cBtSfdHjzQ4rA9kYlo6D18(u"࠭ࡍࡊ࡚ࡈࡈࠬᖧ"),sjtU6GZQg5XC2pH4(u"ࠧࡑࡗࡅࡐࡎࡉࠧᖨ")]: q30elgHcyPKrSVpbsiIn5G.append(j7HgbsXoUDfzcSkmniPu9w6)
	return q30elgHcyPKrSVpbsiIn5G
def nnZ5PlMzYBosCO1(xfTUWaiKPtYjy03LpJz7Dw,args=[]):
	PMHf9mpNv6jLUz = {V3VlkhgjEF4n1erPXHcC0NOsfwyAJ(u"ࠨࡅࡲࡲࡹ࡫࡮ࡵ࠯ࡗࡽࡵ࡫ࠧᖩ"):mmV2nucZ5Lpl6FO1JMPEqGoQKW(u"ࠩࡤࡴࡵࡲࡩࡤࡣࡷ࡭ࡴࡴ࠯࡫ࡵࡲࡲࠬᖪ")}
	n0Ub5zmJcjrsohieQ1B2R9,d27iagnXSIb148xEYKo9rBtMqvNL3F,rrvPbVlUc5j3gsAut = V3VlkhgjEF4n1erPXHcC0NOsfwyAJ(u"ࠪࡺࡨࡨࡣ࠷࠷࠶࠸࠻࡭ࡦࡩࡤࡱࡽࡲࡻࡪ࡬ࠩᖫ"),zYvEaigKWjoq50pXBLDbGJkFc(u"ࠫ࠹࠹ࡶࡤࡸ࠶ࡨ࡫࡭ࡪ࡬ࡱ࠺࠼ࡸࡾࡺࡥ࠴ࠪᖬ"),int(s7FnXZYOgexlH2MPb8BJck1AKv9.time())
	aujcyh14SRZOw8AP = n0Ub5zmJcjrsohieQ1B2R9+sizfDGP6wWXTc3p+str(rrvPbVlUc5j3gsAut)+Q8q1YzIF6icWtSp2L+d27iagnXSIb148xEYKo9rBtMqvNL3F
	Ljaf25ZGde9BIpVK4 = NAkjg5iJVr7wE4Ta3IfXP0Fo.md5(aujcyh14SRZOw8AP.encode(dJHDqiKf12TXlIzSLkGUuxg4MBs3A(u"ࠬࡻࡴࡧ࠺ࠪᖭ"))).hexdigest()[:UUDAiytEL76RTmMYsuIz5evXB(u"࠴࠴ᝩ")]
	rpPU0hMTE6fQx = {BRWqdruz2A0(u"࠭ࡪࡴࡥࡲࡨࡪ࠭ᖮ"):xfTUWaiKPtYjy03LpJz7Dw,RlOvin8YIGC2KZXJPk9m0acrMobUex(u"ࠧࡢࡴࡪࡷࠬᖯ"):args,mmV2nucZ5Lpl6FO1JMPEqGoQKW(u"ࠨࡷࡶࡩࡷ࠭ᖰ"):sizfDGP6wWXTc3p,kYDaz79TFlXoR(u"ࠩࡹࡩࡷࡹࡩࡰࡰࠪᖱ"):Q8q1YzIF6icWtSp2L,sjtU6GZQg5XC2pH4(u"ࠪ࡭ࡩࡹࠧᖲ"):Ljaf25ZGde9BIpVK4}
	MMrNbXsdf1zESPGRF7Cj0Jvn = i4bFG3rKE6.SITESURLS[V3VlkhgjEF4n1erPXHcC0NOsfwyAJ(u"ࠫࡕ࡟ࡔࡉࡑࡑࠫᖳ")][l1DZAt9XNQjqE7YOdrz(u"࠳࠳ᝪ")]
	WjpGS1BQ4KfD = WWrExJZS3Bj4anOAkpv7(kUz8c7OqsxuPFIGfwg,dJHDqiKf12TXlIzSLkGUuxg4MBs3A(u"ࠬࡖࡏࡔࡖࠪᖴ"),MMrNbXsdf1zESPGRF7Cj0Jvn,rpPU0hMTE6fQx,PMHf9mpNv6jLUz,qpFY4hAwolV3,qpFY4hAwolV3,aXqWLoTdVgME(u"࠭ࡌࡊࡄࡕࡅࡗ࡟࠭ࡆ࡚ࡈࡇ࡚࡚ࡅࡠࡌࡖ࠱࠶ࡹࡴࠨᖵ"))
	DDhuOF6ay0kdoW = WjpGS1BQ4KfD.content
	return DDhuOF6ay0kdoW
def qpkEw8cVJd1lTritx7Z(cbiRHIApnoCL3w70MysPr1EQWNKq,CCdfLkBJnhbwzjDgNFWyY9v,PvhmLtAbUY7cxf5O4n81WiaBDulwE,NRJoTUnar72,FIS15OTGJHDjesaoL):
	VLnafQMgjO9dCe5mvbW = ag8rjZo1Vz4IPdcOT
	uukL4jDEWOdNyfKlw = CCdfLkBJnhbwzjDgNFWyY9v
	for RSOK5UCfJsY7vZHgD in cbiRHIApnoCL3w70MysPr1EQWNKq:
		RSOK5UCfJsY7vZHgD.start()
		s7FnXZYOgexlH2MPb8BJck1AKv9.sleep(PvhmLtAbUY7cxf5O4n81WiaBDulwE)
		uukL4jDEWOdNyfKlw -= PvhmLtAbUY7cxf5O4n81WiaBDulwE
		VLnafQMgjO9dCe5mvbW = FIS15OTGJHDjesaoL()
		if VLnafQMgjO9dCe5mvbW: break
	while not VLnafQMgjO9dCe5mvbW and uukL4jDEWOdNyfKlw>vvXoMLlg513:
		s7FnXZYOgexlH2MPb8BJck1AKv9.sleep(NRJoTUnar72)
		uukL4jDEWOdNyfKlw -= NRJoTUnar72
		VLnafQMgjO9dCe5mvbW = FIS15OTGJHDjesaoL()
	return VLnafQMgjO9dCe5mvbW
def O8YxFVZUhBXd6wDcb(ttYhLZvrsTQz6H2deA5SJ1FCXBg9P=rpQoXd70jFJO4Cfb8MqU5iT):
	uk03EAZeGaNSR9xrJ64ovhsUlO = aXqWLoTdVgME(u"࠴࠴࠷࠺ᝫ")
	jYv8XRG9wz = vvXoMLlg513
	if not jYv8XRG9wz:
		try:
			import shutil as n6A4DoReWl3Tx
			jYv8XRG9wz = n6A4DoReWl3Tx.disk_usage(ttYhLZvrsTQz6H2deA5SJ1FCXBg9P).free
		except: pass
	if not jYv8XRG9wz and hasattr(RPbaxsNFVTwek5Kfv21DiJuzCnjMZp,qqzwE6imYG4c2xojI(u"ࠧࡴࡶࡤࡸࡻ࡬ࡳࠨᖶ")):
		try:
			IID7qbgwVRpk = RPbaxsNFVTwek5Kfv21DiJuzCnjMZp.statvfs(ttYhLZvrsTQz6H2deA5SJ1FCXBg9P)
			jYv8XRG9wz = IID7qbgwVRpk.f_frsize * IID7qbgwVRpk.f_bavail
		except: pass
	if not jYv8XRG9wz and hasattr(RPbaxsNFVTwek5Kfv21DiJuzCnjMZp,IaBhDMJc17302LgSvyxd(u"ࠨࡨࡶࡸࡦࡺࡶࡧࡵࠪᖷ")):
		try:
			IID7qbgwVRpk = RPbaxsNFVTwek5Kfv21DiJuzCnjMZp.fstatvfs(ttYhLZvrsTQz6H2deA5SJ1FCXBg9P)
			jYv8XRG9wz = IID7qbgwVRpk.f_frsize * IID7qbgwVRpk.f_bavail
		except: pass
	if not jYv8XRG9wz and TSRUP0dExYGQg.platform == DiJ8CMuYH1daWyjehfN0L(u"ࠩࡺ࡭ࡳ࠹࠲ࠨᖸ"):
		try:
			import ctypes as pZ6jOyf9SwAc
			lWO4TpwNj9t8APydUQZMCa = pZ6jOyf9SwAc.c_ulonglong(vvXoMLlg513)
			pZ6jOyf9SwAc.windll.kernel32.GetDiskFreeSpaceExW(pZ6jOyf9SwAc.c_wchar_p(ttYhLZvrsTQz6H2deA5SJ1FCXBg9P),None,None,pZ6jOyf9SwAc.pointer(lWO4TpwNj9t8APydUQZMCa))
			jYv8XRG9wz = lWO4TpwNj9t8APydUQZMCa.value
		except: pass
	if not jYv8XRG9wz:
		try:
			mmuVeqR3Mrt6fJDIL = Rqvw05BorCgcye7VE32Sf.getInfoLabel(tR1krDGPpO025fghMT3a7UnYj(u"ࠪࡗࡾࡹࡴࡦ࡯࠱ࡊࡷ࡫ࡥࡔࡲࡤࡧࡪ࠭ᖹ"))
			P5d4wytLYgWIuAmrFjbZvSQh9V = ePhmG1jLD6.findall(tR1krDGPpO025fghMT3a7UnYj(u"ࠫࡡࡪࠫࠩࡁ࠽ࡠ࠳ࡢࡤࠬࠫࡂࠫᖺ"),mmuVeqR3Mrt6fJDIL,ePhmG1jLD6.DOTALL)
			if P5d4wytLYgWIuAmrFjbZvSQh9V:
				P5d4wytLYgWIuAmrFjbZvSQh9V = float(P5d4wytLYgWIuAmrFjbZvSQh9V[tR1krDGPpO025fghMT3a7UnYj(u"࠴ᝬ")])
				if   BRWqdruz2A0(u"࡚ࠬࠧᖻ") in mmuVeqR3Mrt6fJDIL: jYv8XRG9wz = P5d4wytLYgWIuAmrFjbZvSQh9V*uk03EAZeGaNSR9xrJ64ovhsUlO**wn4bG51vUENfaS0Zg
				elif ee86G9ladLHVbh5mikzCo(u"࠭ࡇࠨᖼ") in mmuVeqR3Mrt6fJDIL: jYv8XRG9wz = P5d4wytLYgWIuAmrFjbZvSQh9V*uk03EAZeGaNSR9xrJ64ovhsUlO**DAE6vkyhXGx1wBdHmcFfTVQpL0l
				elif DiJ8CMuYH1daWyjehfN0L(u"ࠧࡎࠩᖽ") in mmuVeqR3Mrt6fJDIL: jYv8XRG9wz = P5d4wytLYgWIuAmrFjbZvSQh9V*uk03EAZeGaNSR9xrJ64ovhsUlO**Zwqio2AIWlD5etFa
				elif qqzwE6imYG4c2xojI(u"ࠨࡍࠪᖾ") in mmuVeqR3Mrt6fJDIL: jYv8XRG9wz = P5d4wytLYgWIuAmrFjbZvSQh9V*uk03EAZeGaNSR9xrJ64ovhsUlO
				else: jYv8XRG9wz = P5d4wytLYgWIuAmrFjbZvSQh9V
		except: pass
	if not jYv8XRG9wz: jYv8XRG9wz = DiJ8CMuYH1daWyjehfN0L(u"࠾࠿࠹࠺࠻࠼࠽࠾࠿࠹࠺࠻࠼࠽࠾᝭")
	return int(jYv8XRG9wz)
def AAEc2whI4s1G9PqxHaWVRSLCTztfD3(FAHCtdm48uIsx):
	if FAHCtdm48uIsx:
		hSBi0yNm1OADvxX47k8lnGwVo = XXyMBNAVJvKiq7jc20bEw6(WoFsvbmUlDZp7PzRfdGknCV,ddiCzu6yahj5RtTISMJ48sNnZBU(u"ࠩ࡯࡭ࡸࡺࠧᖿ"),l32dnTEOU1skGKqeBtI9hmo(u"ࠪࡑࡎ࡙ࡃࡠࡖࡈࡑࡕࡥ࠱ࠨᗀ"),zYvEaigKWjoq50pXBLDbGJkFc(u"ࠫࡘࡏࡔࡆࡕࡢ࡙ࡘࡇࡇࡆࠩᗁ"))
		if hSBi0yNm1OADvxX47k8lnGwVo: return hSBi0yNm1OADvxX47k8lnGwVo
	GI0fwOUzWlVYaicPdBRunFy = {LZWMikPEB81KSGyxfJtUsCA(u"ࠬࡧࠧᗂ"):lljaEqwTVtmKsQcOrbXxS5hgNH(u"࠭ࡡࠨᗃ")}
	url = i4bFG3rKE6.SITESURLS[ddiCzu6yahj5RtTISMJ48sNnZBU(u"ࠧࡑ࡛ࡗࡌࡔࡔࠧᗄ")][mZi0S72jGoHpLO]
	IAW0sh6So3NpqM = WWrExJZS3Bj4anOAkpv7(dzcNuIbsgK3yZ6SXGaEHPfOj5vk,viRJWOC5jsYe84(u"ࠨࡒࡒࡗ࡙࠭ᗅ"),url,GI0fwOUzWlVYaicPdBRunFy,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,BRWqdruz2A0(u"ࠩࡖࡉࡗ࡜ࡉࡄࡇࡖ࠱ࡌࡋࡔࡠࡕࡌࡘࡊ࡙࡟ࡖࡕࡄࡋࡊ࠳࠱ࡴࡶࠪᗆ"))
	cmWl9dOKHPIy41iaXuxrY = IAW0sh6So3NpqM.content
	cmWl9dOKHPIy41iaXuxrY = cmWl9dOKHPIy41iaXuxrY.replace(l1DZAt9XNQjqE7YOdrz(u"࡙ࠪࡳ࡯ࡴࡦࡦࠣࡗࡹࡧࡴࡦࡵࠪᗇ"),LZWMikPEB81KSGyxfJtUsCA(u"࡚࡙ࠫࡁࠨᗈ"))
	cmWl9dOKHPIy41iaXuxrY = cmWl9dOKHPIy41iaXuxrY.replace(LZWMikPEB81KSGyxfJtUsCA(u"࡛ࠬ࡮ࡪࡶࡨࡨࠥࡑࡩ࡯ࡩࡧࡳࡲ࠭ᗉ"),V3VlkhgjEF4n1erPXHcC0NOsfwyAJ(u"࠭ࡕࡌࠩᗊ"))
	cmWl9dOKHPIy41iaXuxrY = cmWl9dOKHPIy41iaXuxrY.replace(sjtU6GZQg5XC2pH4(u"ࠧࡖࡰ࡬ࡸࡪࡪࠠࡂࡴࡤࡦࠥࡋ࡭ࡪࡴࡤࡸࡪࡹࠧᗋ"),LZWMikPEB81KSGyxfJtUsCA(u"ࠨࡗࡄࡉࠬᗌ"))
	cmWl9dOKHPIy41iaXuxrY = cmWl9dOKHPIy41iaXuxrY.replace(V3VlkhgjEF4n1erPXHcC0NOsfwyAJ(u"ࠩࡖࡥࡺࡪࡩࠡࡃࡵࡥࡧ࡯ࡡࠨᗍ"),DaFZHsThGmd0zv6e(u"ࠪࡏࡘࡇࠧᗎ"))
	cmWl9dOKHPIy41iaXuxrY = cmWl9dOKHPIy41iaXuxrY.replace(UVa3fJw7k6KM(u"ࠫࡓࡵࡲࡵࡪࠣࡑࡦࡩࡥࡥࡱࡱ࡭ࡦ࠭ᗏ"),BRWqdruz2A0(u"ࠬࡔ࠮ࡎࡣࡦࡩࡩࡵ࡮ࡪࡣࠪᗐ"))
	cmWl9dOKHPIy41iaXuxrY = cmWl9dOKHPIy41iaXuxrY.replace(YY8UDX3MJhb91AHw7fg(u"࠭ࡗࡦࡵࡷࡩࡷࡴࠠࡔࡣ࡫ࡥࡷࡧࠧᗑ"),zYvEaigKWjoq50pXBLDbGJkFc(u"ࠧࡘ࠰ࡖࡥ࡭ࡧࡲࡢࠩᗒ"))
	cmWl9dOKHPIy41iaXuxrY = cmWl9dOKHPIy41iaXuxrY.replace(rNdBKI74fAklnoCZ6(u"ࠨࡡࡢࡣࠬᗓ"),r1roOXYi7UQw9FLThzPEdD0ZlvAnRc)
	try: VkelYOQJDq7I6 = wB8NUAidPbqjIr9CFasXvYnxOQpL0g(UVa3fJw7k6KM(u"ࠩ࡯࡭ࡸࡺࠧᗔ"),cmWl9dOKHPIy41iaXuxrY)
	except:
		iG7Rz2kmn0x1yLNMV3u8O(qpFY4hAwolV3,qpFY4hAwolV3,GLTtERWbHnFuy4PCp,viRJWOC5jsYe84(u"ࠪๅู๊ࠠโ์ࠣะ้ฮࠠๆฯอ์๏อสࠡฬๅี๏ืࠠศๆสืฯิฯศ็ࠪᗕ"))
		return
	bx3jTse48lZ0Lyo1,QSw4EotG8i6uhWVzOgYk2BZDqmUrpc,P7aKopEAw5tjyVULJbIc = VkelYOQJDq7I6
	RSs8DOKPaxVFdAeI4w1,GP8aR7oKEXWij1 = [],[]
	for j7HgbsXoUDfzcSkmniPu9w6,SEmBRMGhrOAykanY,Dd6CzsItHvW5 in QSw4EotG8i6uhWVzOgYk2BZDqmUrpc:
		if SEmBRMGhrOAykanY.isdigit(): SEmBRMGhrOAykanY = DaFZHsThGmd0zv6e(u"ࠫ࡭࡯ࡧࡩࡷࡶࡥ࡬࡫ࠧᗖ") if int(SEmBRMGhrOAykanY)>tR1krDGPpO025fghMT3a7UnYj(u"࠻࠰ᝮ") else viRJWOC5jsYe84(u"ࠬࡲ࡯ࡸࡷࡶࡥ࡬࡫ࠧᗗ")
		if j7HgbsXoUDfzcSkmniPu9w6 not in i4bFG3rKE6.non_videos_actions:
			if   SEmBRMGhrOAykanY==c2RKu0xG1eC8MiohyE(u"࠭ࡨࡪࡩ࡫ࡹࡸࡧࡧࡦࠩᗘ"): RSs8DOKPaxVFdAeI4w1.append(j7HgbsXoUDfzcSkmniPu9w6)
			elif SEmBRMGhrOAykanY==ee86G9ladLHVbh5mikzCo(u"ࠧ࡭ࡱࡺࡹࡸࡧࡧࡦࠩᗙ"): GP8aR7oKEXWij1.append(j7HgbsXoUDfzcSkmniPu9w6)
	zOYMaQ0NgdiRVwDJXh8e(WoFsvbmUlDZp7PzRfdGknCV,l1DZAt9XNQjqE7YOdrz(u"ࠨࡏࡌࡗࡈࡥࡔࡆࡏࡓࡣ࠶࠭ᗚ"),tR1krDGPpO025fghMT3a7UnYj(u"ࠩࡖࡍ࡙ࡋࡓࡠࡗࡖࡅࡌࡋࠧᗛ"),[VkelYOQJDq7I6,RSs8DOKPaxVFdAeI4w1,GP8aR7oKEXWij1],kUz8c7OqsxuPFIGfwg)
	return VkelYOQJDq7I6,RSs8DOKPaxVFdAeI4w1,GP8aR7oKEXWij1
def WWrExJZS3Bj4anOAkpv7(BigAz2Owj3arMN5J6RGFk8PTq,z5nOUetfoJHbP6294ghwur,Cm4xfTO625jyMtZ8GEpvuKcnbQ1gD,dimhv1XTVH8UOrc9EGJZ6,ppuvkQrgA1i8WwY3ftNJx7Ba9jH,pYyzPu7Cjal,showDialogs,n38oH7wd6BDyAMJQS,gcGZAoTEvO2qIaufr4RxNyWV8B=qpFY4hAwolV3,yCiSaQP8t2Db=qpFY4hAwolV3):
	if LZWMikPEB81KSGyxfJtUsCA(u"ࠪ࠾ࠬᗜ") in z5nOUetfoJHbP6294ghwur: z5nOUetfoJHbP6294ghwur,kc8s5wJ4Px9zbiWQm = z5nOUetfoJHbP6294ghwur.split(tQMjXKCA5dN4xq3beVIzaEoWkFLg(u"ࠫ࠿࠭ᗝ"))
	else: z5nOUetfoJHbP6294ghwur,kc8s5wJ4Px9zbiWQm = z5nOUetfoJHbP6294ghwur,tQMjXKCA5dN4xq3beVIzaEoWkFLg(u"ࠬ࠭ᗞ")
	WSQlG8mDhqsNe,Hitbcw146SAGnegpqP5zrJUxTW8vBO,vLNaxndFy5jGkTiQhYX,KKf8YWi2FyGABj = HSQlpuY1RZfmob4iqMP9kjeV5rch(Cm4xfTO625jyMtZ8GEpvuKcnbQ1gD)
	GG3xkz2tbIwfXl = ppuvkQrgA1i8WwY3ftNJx7Ba9jH.copy() if isinstance(ppuvkQrgA1i8WwY3ftNJx7Ba9jH,dict) else ppuvkQrgA1i8WwY3ftNJx7Ba9jH
	oPd4bh1MqQxN = z5nOUetfoJHbP6294ghwur,WSQlG8mDhqsNe,dimhv1XTVH8UOrc9EGJZ6,GG3xkz2tbIwfXl,pYyzPu7Cjal
	if BigAz2Owj3arMN5J6RGFk8PTq<vvXoMLlg513:
		mlykPoGXbJIjFnarp9KihxfN(WoFsvbmUlDZp7PzRfdGknCV,lljaEqwTVtmKsQcOrbXxS5hgNH(u"࠭ࡏࡑࡇࡑ࡙ࡗࡒ࡟ࡓࡇࡔ࡙ࡊ࡙ࡔࡔࠩᗟ"),oPd4bh1MqQxN)
		BigAz2Owj3arMN5J6RGFk8PTq = -BigAz2Owj3arMN5J6RGFk8PTq
	if BigAz2Owj3arMN5J6RGFk8PTq>vvXoMLlg513:
		lgDZd7ip5Ux = XXyMBNAVJvKiq7jc20bEw6(WoFsvbmUlDZp7PzRfdGknCV,fWoVd0Bmtkx(u"ࠧࡳࡧࡶࡴࡴࡴࡳࡦࠩᗠ"),ee86G9ladLHVbh5mikzCo(u"ࠨࡑࡓࡉࡓ࡛ࡒࡍࡡࡕࡉࡖ࡛ࡅࡔࡖࡖࠫᗡ"),oPd4bh1MqQxN)
		if lgDZd7ip5Ux.succeeded:
			h9hOUpTxk0(ddiCzu6yahj5RtTISMJ48sNnZBU(u"ࠩࡕࡉࡖ࡛ࡅࡔࡖࡖࠤࠥࡘࡅࡂࡆࡢࡇࡆࡉࡈࡆࠩᗢ"),WSQlG8mDhqsNe,dimhv1XTVH8UOrc9EGJZ6,ppuvkQrgA1i8WwY3ftNJx7Ba9jH,n38oH7wd6BDyAMJQS,z5nOUetfoJHbP6294ghwur)
			return lgDZd7ip5Ux
	if kc8s5wJ4Px9zbiWQm==qoBMmfAWpFlK70xw8ZRh4naJ(u"ࠪࡗࡈࡘࡁࡑࡇࡕࡗࠬᗣ"): lgDZd7ip5Ux = VTJoICBmqYhF(vvXoMLlg513,z5nOUetfoJHbP6294ghwur,Cm4xfTO625jyMtZ8GEpvuKcnbQ1gD,dimhv1XTVH8UOrc9EGJZ6,ppuvkQrgA1i8WwY3ftNJx7Ba9jH,pYyzPu7Cjal,showDialogs,n38oH7wd6BDyAMJQS)
	else: lgDZd7ip5Ux = kFcsbIlVJDSA1mTOof4(z5nOUetfoJHbP6294ghwur,Cm4xfTO625jyMtZ8GEpvuKcnbQ1gD,dimhv1XTVH8UOrc9EGJZ6,ppuvkQrgA1i8WwY3ftNJx7Ba9jH,pYyzPu7Cjal,showDialogs,n38oH7wd6BDyAMJQS,gcGZAoTEvO2qIaufr4RxNyWV8B,yCiSaQP8t2Db)
	if lgDZd7ip5Ux.succeeded:
		if aXqWLoTdVgME(u"ࠫࡈࡏࡍࡂࡐࡒ࡛ࠬᗤ") in n38oH7wd6BDyAMJQS: lgDZd7ip5Ux.content = KT2JmP8oGz5eZkv6lasH(lgDZd7ip5Ux.content,l32dnTEOU1skGKqeBtI9hmo(u"ࠬࡩࡩ࡮ࡣࡱࡳࡼࡥࡈࡕࡏࡏࡣࡪࡴࡣࡰࡦࡨࡶࠬᗥ"))
		if lgDZd7ip5Ux.scrape: BigAz2Owj3arMN5J6RGFk8PTq = KOyPvpEztYLaZRdMQJWxfTNFHbkg
		if BigAz2Owj3arMN5J6RGFk8PTq and lgDZd7ip5Ux.content: zOYMaQ0NgdiRVwDJXh8e(WoFsvbmUlDZp7PzRfdGknCV,zYvEaigKWjoq50pXBLDbGJkFc(u"࠭ࡏࡑࡇࡑ࡙ࡗࡒ࡟ࡓࡇࡔ࡙ࡊ࡙ࡔࡔࠩᗦ"),oPd4bh1MqQxN,lgDZd7ip5Ux,BigAz2Owj3arMN5J6RGFk8PTq)
	return lgDZd7ip5Ux
def SSIJ7maKr2efs41vTxcwYyFXkng5Bh(z5nOUetfoJHbP6294ghwur,Cm4xfTO625jyMtZ8GEpvuKcnbQ1gD,data,headers,allow_redirects,showDialogs,n38oH7wd6BDyAMJQS,gcGZAoTEvO2qIaufr4RxNyWV8B,yCiSaQP8t2Db):
	if data==qpFY4hAwolV3: data = {}
	if headers==qpFY4hAwolV3: headers = {}
	c0ApgT8hP5FOJ = gBExoceumj4y8bFW9hY2aNMVSr if allow_redirects in [qpFY4hAwolV3,gBExoceumj4y8bFW9hY2aNMVSr] else ag8rjZo1Vz4IPdcOT
	pDxy6XBiWkz08 = gBExoceumj4y8bFW9hY2aNMVSr if showDialogs in [qpFY4hAwolV3,gBExoceumj4y8bFW9hY2aNMVSr] else ag8rjZo1Vz4IPdcOT
	saSK1Iw7unP3hBMtlpz = gBExoceumj4y8bFW9hY2aNMVSr if gcGZAoTEvO2qIaufr4RxNyWV8B in [qpFY4hAwolV3,gBExoceumj4y8bFW9hY2aNMVSr] else ag8rjZo1Vz4IPdcOT
	ZhgUpDlstBPOxFn9 = gBExoceumj4y8bFW9hY2aNMVSr if yCiSaQP8t2Db in [qpFY4hAwolV3,gBExoceumj4y8bFW9hY2aNMVSr] else ag8rjZo1Vz4IPdcOT
	RZ2SwHp6GQvAy = data
	skD7g3FxW4wCa5BR = headers
	pDxy6XBiWkz08 = pDxy6XBiWkz08 if i4bFG3rKE6.ALLOW_SHOWDIALOGS_FIX==H1k0Fmba4Gfiynp8AML else i4bFG3rKE6.ALLOW_SHOWDIALOGS_FIX
	saSK1Iw7unP3hBMtlpz = saSK1Iw7unP3hBMtlpz if i4bFG3rKE6.ALLOW_DNS_FIX==H1k0Fmba4Gfiynp8AML else i4bFG3rKE6.ALLOW_DNS_FIX
	ZhgUpDlstBPOxFn9 = ZhgUpDlstBPOxFn9 if i4bFG3rKE6.ALLOW_PROXY_FIX==H1k0Fmba4Gfiynp8AML else i4bFG3rKE6.ALLOW_PROXY_FIX
	if n38oH7wd6BDyAMJQS==tQMjXKCA5dN4xq3beVIzaEoWkFLg(u"ࠧࡔࡇࡕ࡚ࡎࡉࡅࡔ࠯ࡌࡒࡘ࡚ࡁࡍࡎࡢࡓࡑࡊ࡟ࡓࡇࡏࡉࡆ࡙ࡅ࠮࠳ࡶࡸࠬᗧ"): skD7g3FxW4wCa5BR = {}
	else:
		o3GAywTavpCVJg8dhDZln1 = list(skD7g3FxW4wCa5BR.keys())
		if RlOvin8YIGC2KZXJPk9m0acrMobUex(u"ࠨࡔࡨࡪࡪࡸࡥࡳࠩᗨ") not in o3GAywTavpCVJg8dhDZln1: skD7g3FxW4wCa5BR[DiJ8CMuYH1daWyjehfN0L(u"ࠩࡕࡩ࡫࡫ࡲࡦࡴࠪᗩ")] = Ie5s2cBtSfdHjzQ4rA9kYlo6D18(u"ࠪ࡬ࡹࡺࡰࠨᗪ")
		if kYDaz79TFlXoR(u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨᗫ") not in o3GAywTavpCVJg8dhDZln1: skD7g3FxW4wCa5BR[UVa3fJw7k6KM(u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩᗬ")] = IyjRtqkmHFBvTCDYwuQNJ0(gBExoceumj4y8bFW9hY2aNMVSr)
	return z5nOUetfoJHbP6294ghwur,Cm4xfTO625jyMtZ8GEpvuKcnbQ1gD,RZ2SwHp6GQvAy,skD7g3FxW4wCa5BR,c0ApgT8hP5FOJ,pDxy6XBiWkz08,n38oH7wd6BDyAMJQS,saSK1Iw7unP3hBMtlpz,ZhgUpDlstBPOxFn9
def kFcsbIlVJDSA1mTOof4(z5nOUetfoJHbP6294ghwur,Cm4xfTO625jyMtZ8GEpvuKcnbQ1gD,dimhv1XTVH8UOrc9EGJZ6,ppuvkQrgA1i8WwY3ftNJx7Ba9jH,pYyzPu7Cjal,showDialogs,n38oH7wd6BDyAMJQS,gcGZAoTEvO2qIaufr4RxNyWV8B=qpFY4hAwolV3,yCiSaQP8t2Db=qpFY4hAwolV3):
	O2Oj0H3ocNhaSLlsXef7KmBA = SSIJ7maKr2efs41vTxcwYyFXkng5Bh(z5nOUetfoJHbP6294ghwur,Cm4xfTO625jyMtZ8GEpvuKcnbQ1gD,dimhv1XTVH8UOrc9EGJZ6,ppuvkQrgA1i8WwY3ftNJx7Ba9jH,pYyzPu7Cjal,showDialogs,n38oH7wd6BDyAMJQS,gcGZAoTEvO2qIaufr4RxNyWV8B,yCiSaQP8t2Db)
	z5nOUetfoJHbP6294ghwur,Cm4xfTO625jyMtZ8GEpvuKcnbQ1gD,RZ2SwHp6GQvAy,skD7g3FxW4wCa5BR,c0ApgT8hP5FOJ,pDxy6XBiWkz08,n38oH7wd6BDyAMJQS,saSK1Iw7unP3hBMtlpz,ZhgUpDlstBPOxFn9 = O2Oj0H3ocNhaSLlsXef7KmBA
	WSQlG8mDhqsNe,Hitbcw146SAGnegpqP5zrJUxTW8vBO,vLNaxndFy5jGkTiQhYX,KKf8YWi2FyGABj = HSQlpuY1RZfmob4iqMP9kjeV5rch(Cm4xfTO625jyMtZ8GEpvuKcnbQ1gD)
	LBiAQVGuw4fhHDyZTbrYX = gdPslyFW8ITBcpA302.getSetting(tQMjXKCA5dN4xq3beVIzaEoWkFLg(u"࠭ࡡࡷ࠰ࡶࡸࡦࡺࡵࡴ࠰ࡧࡲࡸ࠭ᗭ"))
	DL8Eyx0oIsuvmXGOMt = gdPslyFW8ITBcpA302.getSetting(tQMjXKCA5dN4xq3beVIzaEoWkFLg(u"ࠧࡢࡸ࠱ࡷࡹࡧࡴࡶࡵ࠱ࡹࡸ࡫ࡤ࡯ࡵࠪᗮ"))
	tMJcb1hmia6k35QWBy7AfuYCZgKz = gdPslyFW8ITBcpA302.getSetting(IaBhDMJc17302LgSvyxd(u"ࠨࡣࡹ࠲ࡸࡺࡡࡵࡷࡶ࠲ࡺࡹࡥࡱࡴࡲࡼࡾ࠭ᗯ"))
	OOcLrGQxKCXt3MfaRySIiJqD = gBExoceumj4y8bFW9hY2aNMVSr if any(value in Cm4xfTO625jyMtZ8GEpvuKcnbQ1gD for value in LbyIPAqK30FY6wJQ9Dosch) else ag8rjZo1Vz4IPdcOT
	if IaBhDMJc17302LgSvyxd(u"ࠩࠩࡹࡷࡲ࠽ࠨᗰ") in WSQlG8mDhqsNe and OOcLrGQxKCXt3MfaRySIiJqD: BcTZjKhi3kDL8PHgsW4ynlA7 = WSQlG8mDhqsNe.rsplit(l32dnTEOU1skGKqeBtI9hmo(u"ࠪࠪࡺࡸ࡬࠾ࠩᗱ"),mZi0S72jGoHpLO)[mZi0S72jGoHpLO]
	else: BcTZjKhi3kDL8PHgsW4ynlA7 = qpFY4hAwolV3
	qqYMxbNgXZnl5QCatuUSjJH = i4bFG3rKE6.SITESURLS[dJHDqiKf12TXlIzSLkGUuxg4MBs3A(u"ࠫࡕ࡟ࡔࡉࡑࡑࠫᗲ")]
	aajVf3ZeJzWtOgGSoYEK = WSQlG8mDhqsNe in qqYMxbNgXZnl5QCatuUSjJH or BcTZjKhi3kDL8PHgsW4ynlA7 in qqYMxbNgXZnl5QCatuUSjJH
	oeH0ncGfzwjgNRk = i4bFG3rKE6.SITESURLS[iNc3KxwErnQ(u"ࠬࡘࡅࡑࡑࡖࠫᗳ")]
	PxLaqbGcJtV = WSQlG8mDhqsNe in oeH0ncGfzwjgNRk or BcTZjKhi3kDL8PHgsW4ynlA7 in oeH0ncGfzwjgNRk
	SHEgbuIJ3yXNfM5G7xFhVwsY4Urzvo = aajVf3ZeJzWtOgGSoYEK or PxLaqbGcJtV
	vwyreZIoftP6 = ag8rjZo1Vz4IPdcOT
	jr7QqZXfU8dJL0By = gBExoceumj4y8bFW9hY2aNMVSr
	ksFNn6rOWoC = Hitbcw146SAGnegpqP5zrJUxTW8vBO==None and vLNaxndFy5jGkTiQhYX==None and not OOcLrGQxKCXt3MfaRySIiJqD
	if ksFNn6rOWoC and SHEgbuIJ3yXNfM5G7xFhVwsY4Urzvo:
		if aajVf3ZeJzWtOgGSoYEK:
			W7kAXBuD2R9nHKG03wFSes8jrZ = qqYMxbNgXZnl5QCatuUSjJH.index(WSQlG8mDhqsNe)
			NkyuEzxBhWoeULwCAt8G0Qmj = i4bFG3rKE6.SITESURLS[RlOvin8YIGC2KZXJPk9m0acrMobUex(u"࠭ࡐ࡚ࡖࡋࡓࡓࡥࡂࡌࡒ࠴ࠫᗴ")][W7kAXBuD2R9nHKG03wFSes8jrZ]
			OUml3WPIB8Ffba = i4bFG3rKE6.SITESURLS[l32dnTEOU1skGKqeBtI9hmo(u"ࠧࡑ࡛ࡗࡌࡔࡔ࡟ࡃࡍࡓ࠶ࠬᗵ")][W7kAXBuD2R9nHKG03wFSes8jrZ]
			uCwzIJp2qnGP80dlQc = i4bFG3rKE6.SITESURLS[RlOvin8YIGC2KZXJPk9m0acrMobUex(u"ࠨࡒ࡜ࡘࡍࡕࡎࡠࡄࡎࡔ࠸࠭ᗶ")][W7kAXBuD2R9nHKG03wFSes8jrZ]
			RHsBilS7oU9tyMP = i4bFG3rKE6.api_python_actions[W7kAXBuD2R9nHKG03wFSes8jrZ]
			if RHsBilS7oU9tyMP==viRJWOC5jsYe84(u"ࠩࡏࡍࡘ࡚ࡐࡍࡃ࡜ࠫᗷ"): saSK1Iw7unP3hBMtlpz,ZhgUpDlstBPOxFn9,jr7QqZXfU8dJL0By = ag8rjZo1Vz4IPdcOT,ag8rjZo1Vz4IPdcOT,ag8rjZo1Vz4IPdcOT
			elif RHsBilS7oU9tyMP==tR1krDGPpO025fghMT3a7UnYj(u"ࠪࡇࡆࡖࡔࡄࡊࡄࠫᗸ"): vwyreZIoftP6 = gBExoceumj4y8bFW9hY2aNMVSr
		elif PxLaqbGcJtV:
			W7kAXBuD2R9nHKG03wFSes8jrZ = oeH0ncGfzwjgNRk.index(WSQlG8mDhqsNe)
			NkyuEzxBhWoeULwCAt8G0Qmj = i4bFG3rKE6.SITESURLS[V3VlkhgjEF4n1erPXHcC0NOsfwyAJ(u"ࠫࡗࡋࡐࡐࡕࡢࡆࡐࡖ࠱ࠨᗹ")][W7kAXBuD2R9nHKG03wFSes8jrZ]
			OUml3WPIB8Ffba = i4bFG3rKE6.SITESURLS[CC1eY6yWZUwf2TkRvnp7EJ0AimjHBX(u"ࠬࡘࡅࡑࡑࡖࡣࡇࡑࡐ࠳ࠩᗺ")][W7kAXBuD2R9nHKG03wFSes8jrZ]
			uCwzIJp2qnGP80dlQc = i4bFG3rKE6.SITESURLS[aXqWLoTdVgME(u"࠭ࡒࡆࡒࡒࡗࡤࡈࡋࡑ࠵ࠪᗻ")][W7kAXBuD2R9nHKG03wFSes8jrZ]
			RHsBilS7oU9tyMP = i4bFG3rKE6.api_repos_actions[W7kAXBuD2R9nHKG03wFSes8jrZ]
	if vLNaxndFy5jGkTiQhYX==qpFY4hAwolV3: vLNaxndFy5jGkTiQhYX = LBiAQVGuw4fhHDyZTbrYX
	elif vLNaxndFy5jGkTiQhYX==None and DL8Eyx0oIsuvmXGOMt in [dJHDqiKf12TXlIzSLkGUuxg4MBs3A(u"ࠧࡂࡗࡗࡓࠬᗼ"),iNc3KxwErnQ(u"ࠨࡃࡆࡇࡊࡖࡔࡆࡆࠪᗽ")] and saSK1Iw7unP3hBMtlpz: vLNaxndFy5jGkTiQhYX = LBiAQVGuw4fhHDyZTbrYX
	if aajVf3ZeJzWtOgGSoYEK or PxLaqbGcJtV: cBDoavTz1uIgXpmGQyMOCf3b = aXqWLoTdVgME(u"࠲࠱ᝯ")
	elif OOcLrGQxKCXt3MfaRySIiJqD: cBDoavTz1uIgXpmGQyMOCf3b = kYDaz79TFlXoR(u"࠷࠲ᝰ")
	elif n38oH7wd6BDyAMJQS in RF2gx9SMq4EGThsHNaZV: cBDoavTz1uIgXpmGQyMOCf3b = l1DZAt9XNQjqE7YOdrz(u"࠳࠳᝱")
	elif n38oH7wd6BDyAMJQS==DaFZHsThGmd0zv6e(u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡖࡊ࡜ࡅࡓࡕࡒࡣ࡙ࡘࡁࡏࡕࡏࡅ࡙ࡋ࠭࠲ࡵࡷࠫᗾ"): cBDoavTz1uIgXpmGQyMOCf3b = c2RKu0xG1eC8MiohyE(u"࠵࠴ᝲ")
	elif n38oH7wd6BDyAMJQS==YY8UDX3MJhb91AHw7fg(u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡌࡕࡏࡈࡎࡈࡣ࡙ࡘࡁࡏࡕࡏࡅ࡙ࡋ࠭࠲ࡵࡷࠫᗿ"): cBDoavTz1uIgXpmGQyMOCf3b = dJHDqiKf12TXlIzSLkGUuxg4MBs3A(u"࠶࠵ᝳ")
	elif iNc3KxwErnQ(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡂࡍ࡚ࡅࡒ࠭ᘀ") in n38oH7wd6BDyAMJQS: cBDoavTz1uIgXpmGQyMOCf3b = fWoVd0Bmtkx(u"࠼࠶᝴")
	elif IaBhDMJc17302LgSvyxd(u"࡙ࠬࡈࡐࡈࡋࡅࠬᘁ") in n38oH7wd6BDyAMJQS: cBDoavTz1uIgXpmGQyMOCf3b = c2RKu0xG1eC8MiohyE(u"࠽࠵᝵")
	elif UUDAiytEL76RTmMYsuIz5evXB(u"࠭ࡃࡊࡏࡄ࠸࡚࠭ᘂ") in n38oH7wd6BDyAMJQS: cBDoavTz1uIgXpmGQyMOCf3b = ee86G9ladLHVbh5mikzCo(u"࠲࠶᝶")
	elif IaBhDMJc17302LgSvyxd(u"ࠧࡂࡊ࡚ࡅࡐ࠭ᘃ") in n38oH7wd6BDyAMJQS: cBDoavTz1uIgXpmGQyMOCf3b = IaBhDMJc17302LgSvyxd(u"࠳࠲᝷")
	elif N3flV6EJsD5CzS(u"ࠨࡅࡌࡑࡆࡒࡉࡈࡊࡗࠫᘄ") in n38oH7wd6BDyAMJQS: cBDoavTz1uIgXpmGQyMOCf3b = mmV2nucZ5Lpl6FO1JMPEqGoQKW(u"࠴࠳᝸")
	elif sjtU6GZQg5XC2pH4(u"ࠩࡆࡍࡒࡇࡃࡍࡗࡅ࡛ࡔࡘࡋࠨᘅ") in n38oH7wd6BDyAMJQS: cBDoavTz1uIgXpmGQyMOCf3b = IaBhDMJc17302LgSvyxd(u"࠶࠴᝹")
	elif N3flV6EJsD5CzS(u"ࠪࡅࡐࡕࡁࡎࠩᘆ") in n38oH7wd6BDyAMJQS: cBDoavTz1uIgXpmGQyMOCf3b = UUDAiytEL76RTmMYsuIz5evXB(u"࠶࠺᝺")
	elif RlOvin8YIGC2KZXJPk9m0acrMobUex(u"ࠫࡆࡑࡗࡂࡏࠪᘇ") in n38oH7wd6BDyAMJQS: cBDoavTz1uIgXpmGQyMOCf3b = l1DZAt9XNQjqE7YOdrz(u"࠸࠶᝻")
	elif qoBMmfAWpFlK70xw8ZRh4naJ(u"ࠬࡌࡁࡔࡇࡏࡌࡉ࠷ࠧᘈ") in n38oH7wd6BDyAMJQS: cBDoavTz1uIgXpmGQyMOCf3b = UUDAiytEL76RTmMYsuIz5evXB(u"࠸࠰᝼")
	elif kYDaz79TFlXoR(u"࠭ࡅࡈ࡛ࡅࡉࡘ࡚࠳ࠨᘉ") in n38oH7wd6BDyAMJQS: cBDoavTz1uIgXpmGQyMOCf3b = LZWMikPEB81KSGyxfJtUsCA(u"࠶࠱᝽")
	elif ddiCzu6yahj5RtTISMJ48sNnZBU(u"ࠧࡉࡃࡏࡅࡈࡏࡍࡂࠩᘊ") in n38oH7wd6BDyAMJQS: cBDoavTz1uIgXpmGQyMOCf3b = tR1krDGPpO025fghMT3a7UnYj(u"࠵࠲᝾")
	else: cBDoavTz1uIgXpmGQyMOCf3b = DiJ8CMuYH1daWyjehfN0L(u"࠳࠸᝿")
	rsXq7No0HlMBKP1e6Rw = (Hitbcw146SAGnegpqP5zrJUxTW8vBO!=None)
	vd4zTHgN5UGt7mkenJ91VCMIrfOsl = (vLNaxndFy5jGkTiQhYX!=None and DL8Eyx0oIsuvmXGOMt!=V3VlkhgjEF4n1erPXHcC0NOsfwyAJ(u"ࠨࡕࡗࡓࡕ࠭ᘋ"))
	if rsXq7No0HlMBKP1e6Rw and not OOcLrGQxKCXt3MfaRySIiJqD: t8yiLuJp3cBA6d1QE9x7eZ4fa(UVa3fJw7k6KM(u"ࠩอๅ฾๐ไࠡสิ์ู่๊ࠡำๅ้ࠬᘌ"),Hitbcw146SAGnegpqP5zrJUxTW8vBO)
	elif vd4zTHgN5UGt7mkenJ91VCMIrfOsl: t8yiLuJp3cBA6d1QE9x7eZ4fa(sjtU6GZQg5XC2pH4(u"ࠪฮๆ฿๊ๅࠢࡇࡒࡘࠦัใ็ࠪᘍ"),vLNaxndFy5jGkTiQhYX)
	if rsXq7No0HlMBKP1e6Rw:
		vqb8raUTXynlPwQGVIzkuHM = {fWoVd0Bmtkx(u"ࠦ࡭ࡺࡴࡱࠤᘎ"):Hitbcw146SAGnegpqP5zrJUxTW8vBO,zYvEaigKWjoq50pXBLDbGJkFc(u"ࠧ࡮ࡴࡵࡲࡶࠦᘏ"):Hitbcw146SAGnegpqP5zrJUxTW8vBO}
		qqu0L592slf = Hitbcw146SAGnegpqP5zrJUxTW8vBO
	else: vqb8raUTXynlPwQGVIzkuHM,qqu0L592slf = {},qpFY4hAwolV3
	if vd4zTHgN5UGt7mkenJ91VCMIrfOsl:
		import urllib3.util.connection as oo8HOrqn1BS2YaMtue3iTlJv9CVAyI
		ZBrzkx5EH8F2eghItonls6MLDv = Hz0CltOwMNv3rA7LfSy56oiuB28R(oo8HOrqn1BS2YaMtue3iTlJv9CVAyI,LBiAQVGuw4fhHDyZTbrYX,gBExoceumj4y8bFW9hY2aNMVSr)
	rJyUwLh24i39kA0xdnBIVNmC1,FiDk4YaTn5OMVjpP,qOkwGDgV4ax0jhHN7J2KczQmB,DeaqlPoEOSRzu285p,DDJifMch4k0jwq,CiArgpSq4MLO5zQR1Z7T,verify = c0ApgT8hP5FOJ,n38oH7wd6BDyAMJQS,z5nOUetfoJHbP6294ghwur,ag8rjZo1Vz4IPdcOT,ag8rjZo1Vz4IPdcOT,ag8rjZo1Vz4IPdcOT,KKf8YWi2FyGABj
	if vwyreZIoftP6: DDJifMch4k0jwq = gBExoceumj4y8bFW9hY2aNMVSr
	if SHEgbuIJ3yXNfM5G7xFhVwsY4Urzvo or c0ApgT8hP5FOJ: rJyUwLh24i39kA0xdnBIVNmC1 = ag8rjZo1Vz4IPdcOT
	XSRoBuFEbKvZH6meTNCJx7LwQi,AGUTOIbFi4tDB1 = -mZi0S72jGoHpLO,dJHDqiKf12TXlIzSLkGUuxg4MBs3A(u"࠭ࡕ࡯࡭ࡱࡳࡼࡴࠠࡆࡴࡵࡳࡷ࠭ᘐ")
	if not i4bFG3rKE6.SAVED_FORWARDS: i4bFG3rKE6.SAVED_FORWARDS = kkMiwNXtnVaB(WoFsvbmUlDZp7PzRfdGknCV,UVa3fJw7k6KM(u"ࠧࡥ࡫ࡦࡸࠬᘑ"),RlOvin8YIGC2KZXJPk9m0acrMobUex(u"ࠨࡈࡒࡖ࡜ࡇࡒࡅࡕࠪᘒ"))
	PPCNcWdxqMThKZF = set()
	nWl2v3mTkX = AWeJuo2LhZ5xiD8KNSqd9G0rtT74FE(WSQlG8mDhqsNe,qqzwE6imYG4c2xojI(u"ࠩࡸࡶࡱ࠭ᘓ"))
	while nWl2v3mTkX in i4bFG3rKE6.SAVED_FORWARDS:
		if nWl2v3mTkX in PPCNcWdxqMThKZF: break
		PPCNcWdxqMThKZF.add(nWl2v3mTkX)
		lC37ZxrAhIuHRpTWK = i4bFG3rKE6.SAVED_FORWARDS[nWl2v3mTkX]
		WSQlG8mDhqsNe = WSQlG8mDhqsNe.replace(nWl2v3mTkX,lC37ZxrAhIuHRpTWK)
		nWl2v3mTkX = AWeJuo2LhZ5xiD8KNSqd9G0rtT74FE(WSQlG8mDhqsNe,DiJ8CMuYH1daWyjehfN0L(u"ࠪࡹࡷࡲࠧᘔ"))
	RfIasd7AZ6q8CnDQkGKrexNP2 = RZ2SwHp6GQvAy
	if aajVf3ZeJzWtOgGSoYEK:
		qOkwGDgV4ax0jhHN7J2KczQmB = ddiCzu6yahj5RtTISMJ48sNnZBU(u"ࠫࡕࡕࡓࡕࠩᘕ")
		skD7g3FxW4wCa5BR[dJHDqiKf12TXlIzSLkGUuxg4MBs3A(u"ࠬࡇࡖ࠮ࡇࡱࡧࡷࡿࡰࡵ࡫ࡲࡲࠬᘖ")] = sjtU6GZQg5XC2pH4(u"࠭ࡖࡦࡴࡶ࡭ࡴࡴࠠ࠲࠰࠳ࠫᘗ")
		ks7BEfCpjlrKGI6SyPo1eMNLuFmX4Y = A3AFYmgZLXn4MBab.dumps(RZ2SwHp6GQvAy)
		RfIasd7AZ6q8CnDQkGKrexNP2 = VzydqvZEC7alBs5kQg2he(ks7BEfCpjlrKGI6SyPo1eMNLuFmX4Y,lljaEqwTVtmKsQcOrbXxS5hgNH(u"࠻࠵࠷࠽࠴࠺࠵࠸࠺ក"))
		WSQlG8mDhqsNe = WSQlG8mDhqsNe+tQMjXKCA5dN4xq3beVIzaEoWkFLg(u"ࠧࡀࡷࡶࡩࡷࡃࠧᘘ")+sizfDGP6wWXTc3p
	import requests as lFScPefz0pyYM7QrH41n6woV
	for nnZ13Rr6tYXio0DyfLVvSxBec in range(tR1krDGPpO025fghMT3a7UnYj(u"࠵࠵ខ")):
		zlQAfuT2Z7nKhGdXs = ag8rjZo1Vz4IPdcOT
		if nnZ13Rr6tYXio0DyfLVvSxBec:
			FiDk4YaTn5OMVjpP = c2RKu0xG1eC8MiohyE(u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡒࡔࡊࡔࡕࡓࡎࡢࡖࡊࡗࡕࡆࡕࡗࡗ࠲࠷ࡳࡵࠩᘙ")
			try: lgDZd7ip5Ux.close()
			except: pass
		if OOcLrGQxKCXt3MfaRySIiJqD or not rsXq7No0HlMBKP1e6Rw: h9hOUpTxk0(qoBMmfAWpFlK70xw8ZRh4naJ(u"ࠩࡕࡉࡖ࡛ࡅࡔࡖࡖࡠࡹࡕࡐࡆࡐࡢ࡙ࡗࡒࠧᘚ"),WSQlG8mDhqsNe,RfIasd7AZ6q8CnDQkGKrexNP2,skD7g3FxW4wCa5BR,FiDk4YaTn5OMVjpP,qOkwGDgV4ax0jhHN7J2KczQmB)
		hhpztscnBD1GP = WSQlG8mDhqsNe
		try:
			lgDZd7ip5Ux = lFScPefz0pyYM7QrH41n6woV.request(qOkwGDgV4ax0jhHN7J2KczQmB,WSQlG8mDhqsNe,data=RfIasd7AZ6q8CnDQkGKrexNP2,headers=skD7g3FxW4wCa5BR,verify=verify,allow_redirects=rJyUwLh24i39kA0xdnBIVNmC1,timeout=cBDoavTz1uIgXpmGQyMOCf3b,proxies=vqb8raUTXynlPwQGVIzkuHM)
			if kYDaz79TFlXoR(u"࠸࠶࠰គ")<=lgDZd7ip5Ux.status_code<=aXqWLoTdVgME(u"࠹࠹࠺ឃ"):
				if not DeaqlPoEOSRzu285p:
					MepIvHBYNArkUOdV37shtJ = lgDZd7ip5Ux.headers.get(qoBMmfAWpFlK70xw8ZRh4naJ(u"ࠪࡐࡴࡩࡡࡵ࡫ࡲࡲࠬᘛ")) or lgDZd7ip5Ux.headers.get(qoBMmfAWpFlK70xw8ZRh4naJ(u"ࠫࡱࡵࡣࡢࡶ࡬ࡳࡳ࠭ᘜ")) or qpFY4hAwolV3
					if MepIvHBYNArkUOdV37shtJ.startswith(qqzwE6imYG4c2xojI(u"ࠬࡀࠧᘝ")): MepIvHBYNArkUOdV37shtJ = WSQlG8mDhqsNe+MepIvHBYNArkUOdV37shtJ
					if MepIvHBYNArkUOdV37shtJ: WSQlG8mDhqsNe = MepIvHBYNArkUOdV37shtJ
					else: DeaqlPoEOSRzu285p = gBExoceumj4y8bFW9hY2aNMVSr
					if not DeaqlPoEOSRzu285p: WSQlG8mDhqsNe = WSQlG8mDhqsNe.encode(rNdBKI74fAklnoCZ6(u"࠭࡬ࡢࡶ࡬ࡲ࠶࠭ᘞ"),l32dnTEOU1skGKqeBtI9hmo(u"ࠧࡪࡩࡱࡳࡷ࡫ࠧᘟ")).decode(nV3Tip6XsH1rJw79DPOU,viRJWOC5jsYe84(u"ࠨ࡫ࡪࡲࡴࡸࡥࠨᘠ"))
					if SHEgbuIJ3yXNfM5G7xFhVwsY4Urzvo and lgDZd7ip5Ux.status_code==tR1krDGPpO025fghMT3a7UnYj(u"࠳࠱࠹ង"):
						rJyUwLh24i39kA0xdnBIVNmC1 = c0ApgT8hP5FOJ
						qOkwGDgV4ax0jhHN7J2KczQmB = z5nOUetfoJHbP6294ghwur
						DeaqlPoEOSRzu285p = gBExoceumj4y8bFW9hY2aNMVSr
						E2XMPtf6TUlVQAdOWirsaJL
				if not DeaqlPoEOSRzu285p or c0ApgT8hP5FOJ:
					if DiJ8CMuYH1daWyjehfN0L(u"ࠩ࡫ࡸࡹࡶࠧᘡ") not in WSQlG8mDhqsNe:
						QgGp5LnsUFC3xAcqW = AWeJuo2LhZ5xiD8KNSqd9G0rtT74FE(hhpztscnBD1GP,IaBhDMJc17302LgSvyxd(u"ࠪࡹࡷࡲࠧᘢ"))
						WSQlG8mDhqsNe = QgGp5LnsUFC3xAcqW+ShynO8pN9idCE3+WSQlG8mDhqsNe.lstrip(ShynO8pN9idCE3)
				if WSQlG8mDhqsNe!=hhpztscnBD1GP:
					EEDpko6HQAmJ7nqbSG29KRj1r3Xt = AWeJuo2LhZ5xiD8KNSqd9G0rtT74FE(hhpztscnBD1GP,mmV2nucZ5Lpl6FO1JMPEqGoQKW(u"ࠫࡺࡸ࡬ࠨᘣ"))
					BH2fcdSjz6lKFTxu93rpGwQJhtPOVD = AWeJuo2LhZ5xiD8KNSqd9G0rtT74FE(WSQlG8mDhqsNe,sjtU6GZQg5XC2pH4(u"ࠬࡻࡲ࡭ࠩᘤ"))
					xACfI7SDyGgt6KRkMbvEm8 = hhpztscnBD1GP.replace(EEDpko6HQAmJ7nqbSG29KRj1r3Xt,qpFY4hAwolV3)
					tipU3FsR8L4zk6fqhGXejECrdoVO29 = xACfI7SDyGgt6KRkMbvEm8.rstrip(ShynO8pN9idCE3)
					TsvDJUIfRtFpKE = cTt4u6reEMKZqVLplmkNW7(WSQlG8mDhqsNe.replace(BH2fcdSjz6lKFTxu93rpGwQJhtPOVD,qpFY4hAwolV3).rstrip(ShynO8pN9idCE3))
					if BH2fcdSjz6lKFTxu93rpGwQJhtPOVD!=EEDpko6HQAmJ7nqbSG29KRj1r3Xt:
						if TsvDJUIfRtFpKE==tipU3FsR8L4zk6fqhGXejECrdoVO29:
							zOYMaQ0NgdiRVwDJXh8e(WoFsvbmUlDZp7PzRfdGknCV,dJHDqiKf12TXlIzSLkGUuxg4MBs3A(u"࠭ࡆࡐࡔ࡚ࡅࡗࡊࡓࠨᘥ"),EEDpko6HQAmJ7nqbSG29KRj1r3Xt,BH2fcdSjz6lKFTxu93rpGwQJhtPOVD,KOyPvpEztYLaZRdMQJWxfTNFHbkg)
						elif TsvDJUIfRtFpKE!=tipU3FsR8L4zk6fqhGXejECrdoVO29 and TsvDJUIfRtFpKE in [qpFY4hAwolV3,ShynO8pN9idCE3]:
							zOYMaQ0NgdiRVwDJXh8e(WoFsvbmUlDZp7PzRfdGknCV,tQMjXKCA5dN4xq3beVIzaEoWkFLg(u"ࠧࡇࡑࡕ࡛ࡆࡘࡄࡔࠩᘦ"),EEDpko6HQAmJ7nqbSG29KRj1r3Xt,BH2fcdSjz6lKFTxu93rpGwQJhtPOVD,KOyPvpEztYLaZRdMQJWxfTNFHbkg)
							WSQlG8mDhqsNe = BH2fcdSjz6lKFTxu93rpGwQJhtPOVD+xACfI7SDyGgt6KRkMbvEm8
				if not DeaqlPoEOSRzu285p:
					ee9BcoiPM5p0lbfC = lgDZd7ip5Ux
					if RRwxKI27Mk(WSQlG8mDhqsNe): DeaqlPoEOSRzu285p = gBExoceumj4y8bFW9hY2aNMVSr
			elif mmV2nucZ5Lpl6FO1JMPEqGoQKW(u"࠷࠸࠴ឆ")<=lgDZd7ip5Ux.status_code<=iNc3KxwErnQ(u"࠶࠻࠼ច"): DDJifMch4k0jwq = gBExoceumj4y8bFW9hY2aNMVSr
			else: DeaqlPoEOSRzu285p = gBExoceumj4y8bFW9hY2aNMVSr
			if not DeaqlPoEOSRzu285p and not c0ApgT8hP5FOJ and ee9BcoiPM5p0lbfC.headers: lgDZd7ip5Ux = ee9BcoiPM5p0lbfC
			hhpztscnBD1GP = lgDZd7ip5Ux.url
			XSRoBuFEbKvZH6meTNCJx7LwQi = lgDZd7ip5Ux.status_code
			AGUTOIbFi4tDB1 = lgDZd7ip5Ux.reason
			lgDZd7ip5Ux.raise_for_status()
			zlQAfuT2Z7nKhGdXs = gBExoceumj4y8bFW9hY2aNMVSr
		except lFScPefz0pyYM7QrH41n6woV.exceptions.HTTPError as Afgoj31Zzp6XeHU7I:
			pass
		except lFScPefz0pyYM7QrH41n6woV.exceptions.Timeout as Afgoj31Zzp6XeHU7I:
			if NJwViHDTMdmO0xnALqQ9voPalC3Ip: AGUTOIbFi4tDB1 = str(Afgoj31Zzp6XeHU7I.message).split(N3flV6EJsD5CzS(u"ࠨ࠼ࠣࠫᘧ"))[mZi0S72jGoHpLO]
			else: AGUTOIbFi4tDB1 = str(Afgoj31Zzp6XeHU7I).split(tQMjXKCA5dN4xq3beVIzaEoWkFLg(u"ࠩ࠽ࠤࠬᘨ"))[mZi0S72jGoHpLO]
		except lFScPefz0pyYM7QrH41n6woV.exceptions.ConnectionError as Afgoj31Zzp6XeHU7I:
			try: pnjEV0aCuY6oZ9M4k8sF1d = Afgoj31Zzp6XeHU7I.message[vvXoMLlg513]
			except: pnjEV0aCuY6oZ9M4k8sF1d = str(Afgoj31Zzp6XeHU7I)
			r3EtlSKBfmnFMGcdHYuVoxhN8R1 = ePhmG1jLD6.findall(iNc3KxwErnQ(u"ࠥࡠࡠࡋࡲࡳࡰࡲࠤ࠭ࡢࡤࠬࠫ࡟ࡡࠥ࠮࠮ࠫࡁࠬࠫࠧᘩ"),pnjEV0aCuY6oZ9M4k8sF1d)
			if not r3EtlSKBfmnFMGcdHYuVoxhN8R1: r3EtlSKBfmnFMGcdHYuVoxhN8R1 = ePhmG1jLD6.findall(DaFZHsThGmd0zv6e(u"ࠦ࠱ࠦࡥࡳࡴࡲࡶࡡ࠮ࠨ࡝ࡦ࠮࠭࠱ࠦࠧࠩ࠰࠭ࡃ࠮࠭ࠢᘪ"),pnjEV0aCuY6oZ9M4k8sF1d)
			if not r3EtlSKBfmnFMGcdHYuVoxhN8R1:
				tC48HVNZrSPYxTWukAX2 = ePhmG1jLD6.findall(RlOvin8YIGC2KZXJPk9m0acrMobUex(u"ࠧࡀࠠࠩ࠰࠭ࡃ࠮ࡀ࠮ࠫࡁࠫࡠࡩ࠱ࠩ࠻ࠤᘫ"),pnjEV0aCuY6oZ9M4k8sF1d)
				if tC48HVNZrSPYxTWukAX2: r3EtlSKBfmnFMGcdHYuVoxhN8R1 = [tC48HVNZrSPYxTWukAX2[vvXoMLlg513][mZi0S72jGoHpLO],tC48HVNZrSPYxTWukAX2[vvXoMLlg513][vvXoMLlg513]]
			if not r3EtlSKBfmnFMGcdHYuVoxhN8R1: r3EtlSKBfmnFMGcdHYuVoxhN8R1 = ePhmG1jLD6.findall(c2RKu0xG1eC8MiohyE(u"ࠨ࠺ࠩ࡞ࡧ࠯࠮ࡀࠠࠩ࠰࠭ࡃ࠮࠭ࠢᘬ"),pnjEV0aCuY6oZ9M4k8sF1d)
			if not r3EtlSKBfmnFMGcdHYuVoxhN8R1: r3EtlSKBfmnFMGcdHYuVoxhN8R1 = ePhmG1jLD6.findall(rNdBKI74fAklnoCZ6(u"ࠢࠡࠪ࡟ࡨ࠰࠯࡝ࠡࠪ࠱࠮ࡄ࠯ࠧࠣᘭ"),pnjEV0aCuY6oZ9M4k8sF1d)
			try: XSRoBuFEbKvZH6meTNCJx7LwQi,AGUTOIbFi4tDB1 = r3EtlSKBfmnFMGcdHYuVoxhN8R1[vvXoMLlg513]
			except: XSRoBuFEbKvZH6meTNCJx7LwQi,AGUTOIbFi4tDB1 = -Zwqio2AIWlD5etFa,pnjEV0aCuY6oZ9M4k8sF1d
		except lFScPefz0pyYM7QrH41n6woV.exceptions.RequestException as Afgoj31Zzp6XeHU7I:
			if NJwViHDTMdmO0xnALqQ9voPalC3Ip: AGUTOIbFi4tDB1 = Afgoj31Zzp6XeHU7I.message
			else: AGUTOIbFi4tDB1 = str(Afgoj31Zzp6XeHU7I)
		except:
			try: XSRoBuFEbKvZH6meTNCJx7LwQi = lgDZd7ip5Ux.status_code
			except: pass
			try: AGUTOIbFi4tDB1 = lgDZd7ip5Ux.reason
			except: pass
		AGUTOIbFi4tDB1 = str(AGUTOIbFi4tDB1)
		LLvyStW429DEZKlA(k8kdUSxohLVljnrY,l32dnTEOU1skGKqeBtI9hmo(u"ࠨࡑࡓࡉࡓ࡛ࡒࡍࡡࡕࡉࡖ࡛ࡅࡔࡖࡖࡠࡹࡘࡅࡔࡒࡒࡒࡘࡋࠠࠡࡅࡲࡨࡪࡀࠠ࡜ࠢࠪᘮ")+str(XSRoBuFEbKvZH6meTNCJx7LwQi)+l1DZAt9XNQjqE7YOdrz(u"ࠩࠣࡡࠥࠦࠠࡓࡧࡤࡷࡴࡴ࠺ࠡ࡝ࠣࠫᘯ")+AGUTOIbFi4tDB1+sjtU6GZQg5XC2pH4(u"ࠪࠤࡢࠦࠠࠡࡕࡲࡹࡷࡩࡥ࠻ࠢ࡞ࠤࠬᘰ")+n38oH7wd6BDyAMJQS+sjtU6GZQg5XC2pH4(u"ࠫࠥࡣࠠࠡࠢࡘࡖࡑࡀࠠ࡜ࠢࠪᘱ")+DObEAlBf39(Cm4xfTO625jyMtZ8GEpvuKcnbQ1gD,n38oH7wd6BDyAMJQS)+ee86G9ladLHVbh5mikzCo(u"ࠬࠦ࡝ࠨᘲ"))
		if ksFNn6rOWoC and SHEgbuIJ3yXNfM5G7xFhVwsY4Urzvo and not DDJifMch4k0jwq and XSRoBuFEbKvZH6meTNCJx7LwQi!=l32dnTEOU1skGKqeBtI9hmo(u"࠵࠴࠵ជ") and RlOvin8YIGC2KZXJPk9m0acrMobUex(u"࠭࠱࠳࠹࠱࠴࠳࠶࠮࠲ࠩᘳ") not in WSQlG8mDhqsNe:
			if WSQlG8mDhqsNe not in [NkyuEzxBhWoeULwCAt8G0Qmj,OUml3WPIB8Ffba,uCwzIJp2qnGP80dlQc]: WSQlG8mDhqsNe,DDJifMch4k0jwq = NkyuEzxBhWoeULwCAt8G0Qmj,ag8rjZo1Vz4IPdcOT
			elif WSQlG8mDhqsNe==NkyuEzxBhWoeULwCAt8G0Qmj: WSQlG8mDhqsNe,DDJifMch4k0jwq = OUml3WPIB8Ffba,ag8rjZo1Vz4IPdcOT
			elif WSQlG8mDhqsNe==OUml3WPIB8Ffba: WSQlG8mDhqsNe,DDJifMch4k0jwq = uCwzIJp2qnGP80dlQc,gBExoceumj4y8bFW9hY2aNMVSr
			continue
		if not DeaqlPoEOSRzu285p and zlQAfuT2Z7nKhGdXs: continue
		break
	XSRoBuFEbKvZH6meTNCJx7LwQi = int(XSRoBuFEbKvZH6meTNCJx7LwQi)
	if not zlQAfuT2Z7nKhGdXs:
		KlvQHZkBxfh8nXeLdR = cbWDd2g9hL0ZO8(rNdBKI74fAklnoCZ6(u"ࠧ࠲࠰࠴࠲࠶࠴࠱ࠨᘴ"),iNc3KxwErnQ(u"࠼࠵ឈ"))
		if KlvQHZkBxfh8nXeLdR==-mZi0S72jGoHpLO:
			LLvyStW429DEZKlA(j8gFJIMYPoBzcCvG9T,qoBMmfAWpFlK70xw8ZRh4naJ(u"ࠨࡑࡓࡉࡓ࡛ࡒࡍࡡࡕࡉࡖ࡛ࡅࡔࡖࡖࠤࠥࠦࡄࡊࡕࡆࡓࡓࡔࡅࡄࡖࡈࡈࠥࠦࠠࡕࡪࡨࠤࡩ࡫ࡶࡪࡥࡨࠤ࡮ࡹࠠ࡯ࡱࡷࠤࡨࡵ࡮࡯ࡧࡦࡸࡪࡪࠠࡵࡱࠣࡸ࡭࡫ࠠࡪࡰࡷࡩࡷࡴࡥࡵࠢࠤࠥࠬᘵ"))
			iG7Rz2kmn0x1yLNMV3u8O(qpFY4hAwolV3,qpFY4hAwolV3,GLTtERWbHnFuy4PCp,V3VlkhgjEF4n1erPXHcC0NOsfwyAJ(u"ࠩ็่ศูแࠡฮ๊หื้ࠠ฻์ิࠤ๊ืศู้ࠣฬฬ๊ล็ฬิ๊ฯࠦ࠮࠯ࠢฦ์ࠥเ๊าࠢๅหิืࠠฤ่ࠣ๎ุะฮะ็ࠣห้หๆหำ้ฮࠥ࠴࠮ࠡล๋ࠤส฿ฯศัสฮࠥา็ศิๆࠤ฿๐ัࠡืะ๎าฯࠠ࡝ࡰ࡟ࡲ๊ࠥอๅࠢสฺ่๊ใๅหࠣฮศ้ฯࠡล้ࠤัํวำๅ้ࠣึฮุ่ࠢห฻ึ๐โสุࠢั๏ำษࠡสส่ส์สา่อࠤํ็๊่ࠢส่ส์สา่อࠤฯ฿ๅๅࠢหูํืษࠡฮํำฮ࠭ᘶ"))
			xtm9pSeMInWo60()
			return lgDZd7ip5Ux
	if vLNaxndFy5jGkTiQhYX!=None and DL8Eyx0oIsuvmXGOMt!=lljaEqwTVtmKsQcOrbXxS5hgNH(u"ࠪࡗ࡙ࡕࡐࠨᘷ"): oo8HOrqn1BS2YaMtue3iTlJv9CVAyI.create_connection = ZBrzkx5EH8F2eghItonls6MLDv
	if DL8Eyx0oIsuvmXGOMt==UVa3fJw7k6KM(u"ࠫࡆࡒࡗࡂ࡛ࡖࠫᘸ") and saSK1Iw7unP3hBMtlpz: vLNaxndFy5jGkTiQhYX = None
	if not zlQAfuT2Z7nKhGdXs and Hitbcw146SAGnegpqP5zrJUxTW8vBO==None and n38oH7wd6BDyAMJQS not in RF2gx9SMq4EGThsHNaZV:
		ggnX3IOk2LPMd = ralpo6SjWw9FGVfcINEgXB0ZDnT.format_exc()
		if ggnX3IOk2LPMd!=Ie5s2cBtSfdHjzQ4rA9kYlo6D18(u"ࠬࡔ࡯࡯ࡧࡗࡽࡵ࡫࠺ࠡࡐࡲࡲࡪࡢ࡮ࠨᘹ"): TSRUP0dExYGQg.stderr.write(ggnX3IOk2LPMd)
	YzK5Mnda6GwuX1LHeI = qvfZXAI81kwTueoFgnOhWazdBR()
	if OOcLrGQxKCXt3MfaRySIiJqD: hhpztscnBD1GP = BcTZjKhi3kDL8PHgsW4ynlA7
	if not hhpztscnBD1GP: hhpztscnBD1GP = WSQlG8mDhqsNe
	YzK5Mnda6GwuX1LHeI.url = hhpztscnBD1GP
	YzK5Mnda6GwuX1LHeI.scrape = OOcLrGQxKCXt3MfaRySIiJqD
	try:
		BBRZVm4dOeTsJkbL83wMWhFDor2yj = lgDZd7ip5Ux.headers
		if not BBRZVm4dOeTsJkbL83wMWhFDor2yj.get(BRWqdruz2A0(u"࠭ࡌࡰࡥࡤࡸ࡮ࡵ࡮ࠨᘺ")) and not BBRZVm4dOeTsJkbL83wMWhFDor2yj.get(aXqWLoTdVgME(u"ࠧ࡭ࡱࡦࡥࡹ࡯࡯࡯ࠩᘻ")): BBRZVm4dOeTsJkbL83wMWhFDor2yj.headers[UVa3fJw7k6KM(u"ࠨࡎࡲࡧࡦࡺࡩࡰࡰࠪᘼ")] = hhpztscnBD1GP
	except: BBRZVm4dOeTsJkbL83wMWhFDor2yj = {}
	try:
		z34gcIahKyelnm5pL9dVrTYbvFDtBu = lgDZd7ip5Ux.content
		if aajVf3ZeJzWtOgGSoYEK and z34gcIahKyelnm5pL9dVrTYbvFDtBu:
			RsqCt48Hnpmu30ZBxzLSK71Q = {Vfpa3KcQtx5RLho7.lower(): lQz3ktUpN1qoKH6dRW9SFDLrA for Vfpa3KcQtx5RLho7, lQz3ktUpN1qoKH6dRW9SFDLrA in lgDZd7ip5Ux.headers.items()}
			if RsqCt48Hnpmu30ZBxzLSK71Q.get(l32dnTEOU1skGKqeBtI9hmo(u"ࠩࡤࡺ࠲࡫࡮ࡤࡴࡼࡴࡹ࡯࡯࡯ࠩᘽ"))==CC1eY6yWZUwf2TkRvnp7EJ0AimjHBX(u"࡚ࠪࡪࡸࡳࡪࡱࡱࠤ࠶࠴࠰ࠨᘾ"):
				z34gcIahKyelnm5pL9dVrTYbvFDtBu,WWhgvdQ2IzrM8FSmlRwNsOe = WWPFdsOCIUpz8MqGl4ByVcfDx(z34gcIahKyelnm5pL9dVrTYbvFDtBu,kYDaz79TFlXoR(u"࠽࠷࠲࠸࠶࠼࠷࠺࠼ញ"))
				if WWhgvdQ2IzrM8FSmlRwNsOe==ddiCzu6yahj5RtTISMJ48sNnZBU(u"ࠫࡎࡔࡖࡂࡎࡌࡈࡤ࡚ࡉࡎࡇࡖࡘࡆࡓࡐࠨᘿ"):
					AGUTOIbFi4tDB1,XSRoBuFEbKvZH6meTNCJx7LwQi = viRJWOC5jsYe84(u"ࠬࡏ࡮ࡷࡣ࡯࡭ࡩࠦࡁࡑࡋࠣࡶࡪࡹࡰࡰࡰࡶࡩ࠳࠭ᙀ"),-Y719atFWlPpbO6uTULjZf5VGD2o0
					zlQAfuT2Z7nKhGdXs = ag8rjZo1Vz4IPdcOT
					z34gcIahKyelnm5pL9dVrTYbvFDtBu = AGUTOIbFi4tDB1
	except: z34gcIahKyelnm5pL9dVrTYbvFDtBu = qpFY4hAwolV3
	if DLod2Of8CkRrtzJynev and isinstance(z34gcIahKyelnm5pL9dVrTYbvFDtBu,bytes):
		try: z34gcIahKyelnm5pL9dVrTYbvFDtBu = z34gcIahKyelnm5pL9dVrTYbvFDtBu.decode(nV3Tip6XsH1rJw79DPOU)
		except: z34gcIahKyelnm5pL9dVrTYbvFDtBu = z34gcIahKyelnm5pL9dVrTYbvFDtBu.decode(tB51CjmZGyJX09b8cAizhvu4T)
	if OOcLrGQxKCXt3MfaRySIiJqD:
		if qoBMmfAWpFlK70xw8ZRh4naJ(u"࠭ࠢࡴࡶࡤࡸࡺࡹࠢ࠻ࠤࡉࡅࡎࡒࠢࠨᙁ") in z34gcIahKyelnm5pL9dVrTYbvFDtBu and dJHDqiKf12TXlIzSLkGUuxg4MBs3A(u"ࠧࠣࡪࡷࡸࡵࡉ࡯ࡥࡧࠥ࠾࠷࠶࠰ࠨᙂ") in z34gcIahKyelnm5pL9dVrTYbvFDtBu: XSRoBuFEbKvZH6meTNCJx7LwQi,zlQAfuT2Z7nKhGdXs = -DAE6vkyhXGx1wBdHmcFfTVQpL0l,ag8rjZo1Vz4IPdcOT
	if aajVf3ZeJzWtOgGSoYEK and z34gcIahKyelnm5pL9dVrTYbvFDtBu and UUDAiytEL76RTmMYsuIz5evXB(u"࠵࠶࠲ឋ")<=XSRoBuFEbKvZH6meTNCJx7LwQi<=LZWMikPEB81KSGyxfJtUsCA(u"࠻࠹࠺ដ"): AGUTOIbFi4tDB1 = z34gcIahKyelnm5pL9dVrTYbvFDtBu
	try: pj0G1HSFf84mgtlNPXyTq5IroWuDY = lgDZd7ip5Ux.cookies.get_dict()
	except: pj0G1HSFf84mgtlNPXyTq5IroWuDY = {}
	try: lgDZd7ip5Ux.close()
	except: pass
	YzK5Mnda6GwuX1LHeI.code = XSRoBuFEbKvZH6meTNCJx7LwQi
	YzK5Mnda6GwuX1LHeI.reason = AGUTOIbFi4tDB1
	YzK5Mnda6GwuX1LHeI.content = z34gcIahKyelnm5pL9dVrTYbvFDtBu
	YzK5Mnda6GwuX1LHeI.headers = BBRZVm4dOeTsJkbL83wMWhFDor2yj
	YzK5Mnda6GwuX1LHeI.cookies = pj0G1HSFf84mgtlNPXyTq5IroWuDY
	YzK5Mnda6GwuX1LHeI.succeeded = zlQAfuT2Z7nKhGdXs
	YzK5Mnda6GwuX1LHeI.scrapernumber = qpFY4hAwolV3
	YzK5Mnda6GwuX1LHeI.scraperserver = qpFY4hAwolV3
	YzK5Mnda6GwuX1LHeI.scraperurl = qpFY4hAwolV3
	QHNkx2vYjC5Rzpyw = YzK5Mnda6GwuX1LHeI.content.lower() if NJwViHDTMdmO0xnALqQ9voPalC3Ip or isinstance(YzK5Mnda6GwuX1LHeI.content,str) else qpFY4hAwolV3
	xY63Sf08qUnLFo7 = (RlOvin8YIGC2KZXJPk9m0acrMobUex(u"ࠨࡥ࡯ࡳࡺࡪࡦ࡭ࡣࡵࡩࠬᙃ") in QHNkx2vYjC5Rzpyw or BRWqdruz2A0(u"ࠩࡪࡳࡴ࡭࡬ࡦࠩᙄ") in QHNkx2vYjC5Rzpyw) and QHNkx2vYjC5Rzpyw.count(Ie5s2cBtSfdHjzQ4rA9kYlo6D18(u"ࠪࡶࡪࡩࡡࡱࡶࡦ࡬ࡦ࠭ᙅ"))>Zwqio2AIWlD5etFa and ee86G9ladLHVbh5mikzCo(u"ࠫࡋࡇࡓࡆࡎࡋࡈ࠶࠭ᙆ") not in n38oH7wd6BDyAMJQS and DiJ8CMuYH1daWyjehfN0L(u"ࠬࡊࡁࡊࡎ࡜ࡑࡔ࡚ࡉࡐࡐࠪᙇ") not in n38oH7wd6BDyAMJQS and rNdBKI74fAklnoCZ6(u"࠭ࡲࡦࡥࡤࡴࡹࡩࡨࡢ࠯ࡷࡳࡰ࡫࡮ࠨᙈ") not in QHNkx2vYjC5Rzpyw
	qDcIlBFs6Q18KE75PuxgTChkYS = (dJHDqiKf12TXlIzSLkGUuxg4MBs3A(u"ࠧࡤ࡮ࡲࡹࡩ࡬࡬ࡢࡴࡨࠫᙉ") in QHNkx2vYjC5Rzpyw and UUDAiytEL76RTmMYsuIz5evXB(u"ࠨࡴࡤࡽࠥ࡯ࡤ࠻ࠢࠪᙊ") in QHNkx2vYjC5Rzpyw)
	QSDMLaPRfGtxs = (lljaEqwTVtmKsQcOrbXxS5hgNH(u"ࠩ࠸ࠤࡸ࡫ࡣࠡࠩᙋ") in QHNkx2vYjC5Rzpyw or tQMjXKCA5dN4xq3beVIzaEoWkFLg(u"ࠪࠤ࠺ࠦࡳࡦࡥࠪᙌ") in QHNkx2vYjC5Rzpyw) and qqzwE6imYG4c2xojI(u"ࠫࡧࡸ࡯ࡸࡵࡨࡶࠬᙍ") in QHNkx2vYjC5Rzpyw and c2RKu0xG1eC8MiohyE(u"ࠬࡸࡡࡺࠢ࡬ࡨ࠿ࠦࠧᙎ") in QHNkx2vYjC5Rzpyw
	mKPd4cAzopn0fVGl9WiXbs1Tg8Yhk = (XSRoBuFEbKvZH6meTNCJx7LwQi in [Ie5s2cBtSfdHjzQ4rA9kYlo6D18(u"࠵࠲࠶ឌ")] and RlOvin8YIGC2KZXJPk9m0acrMobUex(u"࠭ࡥࡳࡴࡲࡶࠥࡩ࡯ࡥࡧ࠽ࠤ࠶࠶࠲࠱ࠩᙏ") in QHNkx2vYjC5Rzpyw)
	Dkg83MoTw7VFXCEPe = (qqzwE6imYG4c2xojI(u"ࠧࡠࡥࡩࡣࡨ࡮࡬ࡠࠩᙐ") in QHNkx2vYjC5Rzpyw and c2RKu0xG1eC8MiohyE(u"ࠨࡥ࡫ࡥࡱࡲࡥ࡯ࡩࡨ࠱ࠬᙑ") in QHNkx2vYjC5Rzpyw)
	MyqwiljfTaP6doZrgNzQcHxptVn9 = (c2RKu0xG1eC8MiohyE(u"ࠩࡹࡩࡷ࡯ࡦࡺ࠰࡫ࡸࡲࡲ࠿ࡳࡧࡧ࡭ࡷ࡫ࡣࡵ࠿ࠪᙒ") in hhpztscnBD1GP)
	RUTvspclD3aCOEthuj59e7 = (l1DZAt9XNQjqE7YOdrz(u"࡛ࠪࡗࡕࡎࡈࡡ࡙ࡉࡗ࡙ࡉࡐࡐࡢࡒ࡚ࡓࡂࡆࡔࠪᙓ") in AGUTOIbFi4tDB1 or c2RKu0xG1eC8MiohyE(u"ࠫࡼࡸ࡯࡯ࡩࠣࡺࡪࡸࡳࡪࡱࡱࠤࡳࡻ࡭ࡣࡧࡵࠫᙔ") in AGUTOIbFi4tDB1)
	if XSRoBuFEbKvZH6meTNCJx7LwQi==qoBMmfAWpFlK70xw8ZRh4naJ(u"࠴࠳࠴ឍ") and any([xY63Sf08qUnLFo7,qDcIlBFs6Q18KE75PuxgTChkYS,QSDMLaPRfGtxs,mKPd4cAzopn0fVGl9WiXbs1Tg8Yhk,Dkg83MoTw7VFXCEPe,MyqwiljfTaP6doZrgNzQcHxptVn9,RUTvspclD3aCOEthuj59e7]):
		YzK5Mnda6GwuX1LHeI.succeeded = ag8rjZo1Vz4IPdcOT
	if YzK5Mnda6GwuX1LHeI.succeeded and ksFNn6rOWoC and SHEgbuIJ3yXNfM5G7xFhVwsY4Urzvo:
		UUNoXGAs6Py = RlOvin8YIGC2KZXJPk9m0acrMobUex(u"ࠬࡉࡁࡑࡖࡆࡌࡆ࠭ᙕ")+RZ2SwHp6GQvAy[aXqWLoTdVgME(u"࠭ࡪࡰࡤࠪᙖ")].upper().replace(qqzwE6imYG4c2xojI(u"ࠧࡈࡇࡗࠫᙗ"),qpFY4hAwolV3) if vwyreZIoftP6 else RHsBilS7oU9tyMP
		WRa8n54C9T(UUNoXGAs6Py)
	if not YzK5Mnda6GwuX1LHeI.succeeded and ksFNn6rOWoC:
		if   xY63Sf08qUnLFo7: AGUTOIbFi4tDB1 = BRWqdruz2A0(u"ࠨࡄ࡯ࡳࡨࡱࡥࡥࠢࡥࡽࠥࡸࡥࡤࡣࡳࡸࡨ࡮ࡡࠨᙘ")
		elif qDcIlBFs6Q18KE75PuxgTChkYS: AGUTOIbFi4tDB1 = tQMjXKCA5dN4xq3beVIzaEoWkFLg(u"ࠩࡅࡰࡴࡩ࡫ࡦࡦࠣࡦࡾࠦࡣ࡭ࡱࡸࡨ࡫ࡲࡡࡳࡧࠪᙙ")
		elif QSDMLaPRfGtxs: AGUTOIbFi4tDB1 = qoBMmfAWpFlK70xw8ZRh4naJ(u"ࠪࡆࡱࡵࡣ࡬ࡧࡧࠤࡧࡿࠠ࠶ࠢࡶࡩࡨࡵ࡮ࡥࡵࠣࡦࡷࡵࡷࡴࡧࡵࠤࡨ࡮ࡥࡤ࡭ࠪᙚ")
		elif mKPd4cAzopn0fVGl9WiXbs1Tg8Yhk: AGUTOIbFi4tDB1 = l1DZAt9XNQjqE7YOdrz(u"ࠫࡇࡲ࡯ࡤ࡭ࡨࡨࠥࡨࡹࠡࡥ࡯ࡳࡺࡪࡦ࡭ࡣࡵࡩࠥࡧࡣࡤࡧࡶࡷࠥࡪࡥ࡯࡫ࡨࡨࠬᙛ")
		elif Dkg83MoTw7VFXCEPe: AGUTOIbFi4tDB1 = UUDAiytEL76RTmMYsuIz5evXB(u"ࠬࡈ࡬ࡰࡥ࡮ࡩࡩࠦࡢࡺࠢࡦࡰࡴࡻࡤࡧ࡮ࡤࡶࡪࠦࡳࡦࡥࡸࡶ࡮ࡺࡹࠡࡥ࡫ࡩࡨࡱࠧᙜ")
		elif MyqwiljfTaP6doZrgNzQcHxptVn9: AGUTOIbFi4tDB1 = IaBhDMJc17302LgSvyxd(u"࠭ࡂ࡭ࡱࡦ࡯ࡪࡪࠠࡣࡻࠣࡱ࡮ࡹࡳࡪࡰࡪࠤ࡯ࡧࡶࡢࡵࡦࡶ࡮ࡶࡴࠡࡥ࡫ࡩࡨࡱࠧᙝ")
		elif RUTvspclD3aCOEthuj59e7: AGUTOIbFi4tDB1 = Ie5s2cBtSfdHjzQ4rA9kYlo6D18(u"ࠧࡃ࡮ࡲࡧࡰ࡫ࡤࠡࡤࡼࠤࡾࡵࡵࡳࠢࡱࡩࡹࡽ࡯ࡳ࡭ࠣࡨࡪࡼࡩࡤࡧࡶࠫᙞ")
		else: AGUTOIbFi4tDB1 = str(AGUTOIbFi4tDB1)
		jqVJT12oeDhiwf0 = DObEAlBf39(WSQlG8mDhqsNe,n38oH7wd6BDyAMJQS)
		if n38oH7wd6BDyAMJQS in GFErxOAcH5: pass
		elif n38oH7wd6BDyAMJQS in RF2gx9SMq4EGThsHNaZV:
			LLvyStW429DEZKlA(j8gFJIMYPoBzcCvG9T,lTW9p1v7uPfOxB(Q8Q0IDc6PLZajJAdTntKUmSGXz)+zYvEaigKWjoq50pXBLDbGJkFc(u"ࠨࠢࠣࡈ࡮ࡸࡥࡤࡶࠣࡧࡴࡴ࡮ࡦࡥࡷ࡭ࡴࡴࠠࡧࡣ࡬ࡰࡪࡪࠠࠡࠢࡆࡳࡩ࡫࠺ࠡ࡝ࠣࠫᙟ")+str(XSRoBuFEbKvZH6meTNCJx7LwQi)+tR1krDGPpO025fghMT3a7UnYj(u"ࠩࠣࡡࠥࠦࠠࡓࡧࡤࡷࡴࡴ࠺ࠡ࡝ࠣࠫᙠ")+AGUTOIbFi4tDB1+N3flV6EJsD5CzS(u"ࠪࠤࡢࠦࠠࠡࡕࡲࡹࡷࡩࡥ࠻ࠢ࡞ࠤࠬᙡ")+n38oH7wd6BDyAMJQS+iNc3KxwErnQ(u"ࠫࠥࡣࠠࠡࠢࡘࡖࡑࡀࠠ࡜ࠢࠪᙢ")+jqVJT12oeDhiwf0+ddiCzu6yahj5RtTISMJ48sNnZBU(u"ࠬࠦ࡝ࠨᙣ"))
		else: LLvyStW429DEZKlA(j8gFJIMYPoBzcCvG9T,lTW9p1v7uPfOxB(Q8Q0IDc6PLZajJAdTntKUmSGXz)+l1DZAt9XNQjqE7YOdrz(u"࠭ࠠࠡࠢࡇ࡭ࡷ࡫ࡣࡵࠢࡦࡳࡳࡴࡥࡤࡶ࡬ࡳࡳࠦࡦࡢ࡫࡯ࡩࡩࠦࠠࠡࡅࡲࡨࡪࡀࠠ࡜ࠢࠪᙤ")+str(XSRoBuFEbKvZH6meTNCJx7LwQi)+qoBMmfAWpFlK70xw8ZRh4naJ(u"ࠧࠡ࡟ࠣࠤࠥࡘࡥࡢࡵࡲࡲ࠿࡛ࠦࠡࠩᙥ")+AGUTOIbFi4tDB1+UVa3fJw7k6KM(u"ࠨࠢࡠࠤࠥࠦࡓࡰࡷࡵࡧࡪࡀࠠ࡜ࠢࠪᙦ")+n38oH7wd6BDyAMJQS+qqzwE6imYG4c2xojI(u"ࠩࠣࡡࠥࠦࠠࡖࡔࡏ࠾ࠥࡡࠠࠨᙧ")+jqVJT12oeDhiwf0+N3flV6EJsD5CzS(u"ࠪࠤࡢ࠭ᙨ"))
		BuevC1KHRltFfwZ5P0rMiV = BcTZjKhi3kDL8PHgsW4ynlA7 if OOcLrGQxKCXt3MfaRySIiJqD else cTt4u6reEMKZqVLplmkNW7(jqVJT12oeDhiwf0)
		if NJwViHDTMdmO0xnALqQ9voPalC3Ip and isinstance(BuevC1KHRltFfwZ5P0rMiV,unicode): BuevC1KHRltFfwZ5P0rMiV = BuevC1KHRltFfwZ5P0rMiV.encode(nV3Tip6XsH1rJw79DPOU)
		if SHEgbuIJ3yXNfM5G7xFhVwsY4Urzvo: BuevC1KHRltFfwZ5P0rMiV = BuevC1KHRltFfwZ5P0rMiV.split(ShynO8pN9idCE3)[-mZi0S72jGoHpLO]
		yiYxRXQ4wOU = str(AGUTOIbFi4tDB1)+RlOvin8YIGC2KZXJPk9m0acrMobUex(u"ࠫࡡࡴࠨࠨᙩ")+BuevC1KHRltFfwZ5P0rMiV+viRJWOC5jsYe84(u"ࠬ࠯ࠧᙪ")
		if any([xY63Sf08qUnLFo7,qDcIlBFs6Q18KE75PuxgTChkYS,QSDMLaPRfGtxs,mKPd4cAzopn0fVGl9WiXbs1Tg8Yhk,Dkg83MoTw7VFXCEPe,MyqwiljfTaP6doZrgNzQcHxptVn9,RUTvspclD3aCOEthuj59e7]):
			if ksFNn6rOWoC:
				Z0bQKOAD5c41yg9zER2p = n38oH7wd6BDyAMJQS.split(sjtU6GZQg5XC2pH4(u"࠭࠭ࠨᙫ"),tR1krDGPpO025fghMT3a7UnYj(u"࠴ណ"))[dJHDqiKf12TXlIzSLkGUuxg4MBs3A(u"࠴ត")]
				SS6T9J80gPf(Z0bQKOAD5c41yg9zER2p)
			if ZhgUpDlstBPOxFn9:
				s1L4086uUzlXvQeFCZkYiNVRcA3jtJ = Zwqio2AIWlD5etFa if RUTvspclD3aCOEthuj59e7 else mZi0S72jGoHpLO
				BBn5MeXCPD = VTJoICBmqYhF(s1L4086uUzlXvQeFCZkYiNVRcA3jtJ,z5nOUetfoJHbP6294ghwur,WSQlG8mDhqsNe,RfIasd7AZ6q8CnDQkGKrexNP2,skD7g3FxW4wCa5BR,c0ApgT8hP5FOJ,pDxy6XBiWkz08,n38oH7wd6BDyAMJQS,XSRoBuFEbKvZH6meTNCJx7LwQi,AGUTOIbFi4tDB1)
				YzK5Mnda6GwuX1LHeI.__dict__.update(BBn5MeXCPD.__dict__)
				if YzK5Mnda6GwuX1LHeI.succeeded: return YzK5Mnda6GwuX1LHeI
		o4oUxD3u18K59ghHIY = gBExoceumj4y8bFW9hY2aNMVSr
		if (DL8Eyx0oIsuvmXGOMt==l32dnTEOU1skGKqeBtI9hmo(u"ࠧࡂࡕࡎࠫᙬ") or tMJcb1hmia6k35QWBy7AfuYCZgKz==sjtU6GZQg5XC2pH4(u"ࠨࡃࡖࡏࠬ᙭")) and (saSK1Iw7unP3hBMtlpz or ZhgUpDlstBPOxFn9):
			o4oUxD3u18K59ghHIY = O9YCFUXd1von5tKE3rmMWufciwDy(XSRoBuFEbKvZH6meTNCJx7LwQi,yiYxRXQ4wOU,n38oH7wd6BDyAMJQS,pDxy6XBiWkz08)
			if o4oUxD3u18K59ghHIY and DL8Eyx0oIsuvmXGOMt==Ie5s2cBtSfdHjzQ4rA9kYlo6D18(u"ࠩࡄࡗࡐ࠭᙮"): DL8Eyx0oIsuvmXGOMt = ee86G9ladLHVbh5mikzCo(u"ࠪࡅࡈࡉࡅࡑࡖࡈࡈࠬᙯ")
			else: DL8Eyx0oIsuvmXGOMt = zYvEaigKWjoq50pXBLDbGJkFc(u"ࠫࡗࡋࡊࡆࡅࡗࡉࡉ࠭ᙰ")
			if o4oUxD3u18K59ghHIY and tMJcb1hmia6k35QWBy7AfuYCZgKz==ee86G9ladLHVbh5mikzCo(u"ࠬࡇࡓࡌࠩᙱ"): tMJcb1hmia6k35QWBy7AfuYCZgKz = mmV2nucZ5Lpl6FO1JMPEqGoQKW(u"࠭ࡁࡄࡅࡈࡔ࡙ࡋࡄࠨᙲ")
			else: tMJcb1hmia6k35QWBy7AfuYCZgKz = IaBhDMJc17302LgSvyxd(u"ࠧࡓࡇࡍࡉࡈ࡚ࡅࡅࠩᙳ")
			gdPslyFW8ITBcpA302.setSetting(c2RKu0xG1eC8MiohyE(u"ࠨࡣࡹ࠲ࡸࡺࡡࡵࡷࡶ࠲ࡺࡹࡥࡥࡰࡶࠫᙴ"),DL8Eyx0oIsuvmXGOMt)
			gdPslyFW8ITBcpA302.setSetting(aXqWLoTdVgME(u"ࠩࡤࡺ࠳ࡹࡴࡢࡶࡸࡷ࠳ࡻࡳࡦࡲࡵࡳࡽࡿࠧᙵ"),tMJcb1hmia6k35QWBy7AfuYCZgKz)
		if o4oUxD3u18K59ghHIY:
			if XSRoBuFEbKvZH6meTNCJx7LwQi==qoBMmfAWpFlK70xw8ZRh4naJ(u"࠽ថ") and lljaEqwTVtmKsQcOrbXxS5hgNH(u"ࠪ࡬ࡹࡺࡰࡴࠩᙶ") in WSQlG8mDhqsNe and jr7QqZXfU8dJL0By:
				if pDxy6XBiWkz08: t8yiLuJp3cBA6d1QE9x7eZ4fa(lljaEqwTVtmKsQcOrbXxS5hgNH(u"ࠫฯ็ู๋ๆࠣๅา฻ࠠี้สำฮࠦวๅฬืๅ๏ืࠠࡔࡕࡏࠫᙷ"),iNc3KxwErnQ(u"๊ࠬลึๆสั๋ࠥิไๆฬࠤฬ๊ล็ฬิ๊๏ะࠧᙸ"),s7FnXZYOgexlH2MPb8BJck1AKv9=V3VlkhgjEF4n1erPXHcC0NOsfwyAJ(u"࠸࠰࠱࠲ទ"))
				hhpztscnBD1GP = WSQlG8mDhqsNe+V3VlkhgjEF4n1erPXHcC0NOsfwyAJ(u"࠭ࡼࡽࡐࡲ࡚ࡪࡸࡩࡧࡻࡖࡗࡑ࠭ᙹ")
				YYAG0TXBO4hCgSRmkPZdvV = kFcsbIlVJDSA1mTOof4(z5nOUetfoJHbP6294ghwur,hhpztscnBD1GP,dimhv1XTVH8UOrc9EGJZ6,ppuvkQrgA1i8WwY3ftNJx7Ba9jH,pYyzPu7Cjal,pDxy6XBiWkz08,mmV2nucZ5Lpl6FO1JMPEqGoQKW(u"ࠧࡍࡋࡅࡖࡆࡘ࡙࠮ࡑࡓࡉࡓ࡛ࡒࡍࡡࡕࡉࡖ࡛ࡅࡔࡖࡖ࠱࠷ࡴࡤࠨᙺ"))
				if YYAG0TXBO4hCgSRmkPZdvV.succeeded:
					YzK5Mnda6GwuX1LHeI = YYAG0TXBO4hCgSRmkPZdvV
					LLvyStW429DEZKlA(d3MGHW41fvNz6rRFYix2anS,lTW9p1v7uPfOxB(Q8Q0IDc6PLZajJAdTntKUmSGXz)+IaBhDMJc17302LgSvyxd(u"ࠨࠢࠣࠤࡘࡻࡣࡤࡧࡨࡨࡪࡪࠠࡶࡵ࡬ࡲ࡬ࠦࡓࡔࡎ࠽ࠤࠥࠦࡓࡰࡷࡵࡧࡪࡀࠠ࡜ࠢࠪᙻ")+n38oH7wd6BDyAMJQS+aXqWLoTdVgME(u"ࠩࠣࡡࠥࠦࠠࡖࡔࡏ࠾ࠥࡡࠠࠨᙼ")+jqVJT12oeDhiwf0+LZWMikPEB81KSGyxfJtUsCA(u"ࠪࠤࡢ࠭ᙽ"))
					if pDxy6XBiWkz08: t8yiLuJp3cBA6d1QE9x7eZ4fa(viRJWOC5jsYe84(u"๋ࠫาวฮࠢหหุะฮะษ่ࠤࡘ࡙ࡌࠨᙾ"),ddiCzu6yahj5RtTISMJ48sNnZBU(u"๊ࠬลึๆสั๋ࠥิไๆฬࠤฬ๊ล็ฬิ๊๏ะࠧᙿ"),s7FnXZYOgexlH2MPb8BJck1AKv9=aXqWLoTdVgME(u"࠲࠱࠲࠳ធ"))
				else:
					LLvyStW429DEZKlA(j8gFJIMYPoBzcCvG9T,lTW9p1v7uPfOxB(Q8Q0IDc6PLZajJAdTntKUmSGXz)+ee86G9ladLHVbh5mikzCo(u"࠭ࠠࠡࠢࡉࡥ࡮ࡲࡥࡥࠢࡸࡷ࡮ࡴࡧࠡࡕࡖࡐ࠿ࠦࠠࠡࡕࡲࡹࡷࡩࡥ࠻ࠢ࡞ࠤࠬ ")+n38oH7wd6BDyAMJQS+V3VlkhgjEF4n1erPXHcC0NOsfwyAJ(u"ࠧࠡ࡟ࠣࠤ࡛ࠥࡒࡍ࠼ࠣ࡟ࠥ࠭ᚁ")+jqVJT12oeDhiwf0+UUDAiytEL76RTmMYsuIz5evXB(u"ࠨࠢࡠࠫᚂ"))
					if pDxy6XBiWkz08: t8yiLuJp3cBA6d1QE9x7eZ4fa(iNc3KxwErnQ(u"ࠩไุ้ࠦศศีอาิอๅࠡࡕࡖࡐࠬᚃ"),lljaEqwTVtmKsQcOrbXxS5hgNH(u"่ࠪส฻ไศฯู้้ࠣไสࠢส่ส์สา่ํฮࠬᚄ"),s7FnXZYOgexlH2MPb8BJck1AKv9=LZWMikPEB81KSGyxfJtUsCA(u"࠳࠲࠳࠴ន"))
			if not YzK5Mnda6GwuX1LHeI.succeeded and tMJcb1hmia6k35QWBy7AfuYCZgKz in [lljaEqwTVtmKsQcOrbXxS5hgNH(u"ࠫࡆ࡛ࡔࡐࠩᚅ"),lljaEqwTVtmKsQcOrbXxS5hgNH(u"ࠬࡇࡃࡄࡇࡓࡘࡊࡊࠧᚆ")] and ZhgUpDlstBPOxFn9:
				if pDxy6XBiWkz08: t8yiLuJp3cBA6d1QE9x7eZ4fa(rNdBKI74fAklnoCZ6(u"࠭สโ฻ํู่๊ࠥาใิหฯࠦศา๊ๆื๏࠭ᚇ"),c2RKu0xG1eC8MiohyE(u"ࠧๅวุ่ฬำࠠๆึๆ่ฮࠦวๅว้ฮึ์๊หࠩᚈ"),s7FnXZYOgexlH2MPb8BJck1AKv9=UVa3fJw7k6KM(u"࠴࠳࠴࠵ប"))
				YYAG0TXBO4hCgSRmkPZdvV = KKGJOx3ZIbupi2STt8sQoEanUjCRVP(z5nOUetfoJHbP6294ghwur,WSQlG8mDhqsNe,dimhv1XTVH8UOrc9EGJZ6,ppuvkQrgA1i8WwY3ftNJx7Ba9jH,pYyzPu7Cjal,pDxy6XBiWkz08,n38oH7wd6BDyAMJQS)
				if YYAG0TXBO4hCgSRmkPZdvV.succeeded:
					YzK5Mnda6GwuX1LHeI = YYAG0TXBO4hCgSRmkPZdvV
					LLvyStW429DEZKlA(d3MGHW41fvNz6rRFYix2anS,lTW9p1v7uPfOxB(Q8Q0IDc6PLZajJAdTntKUmSGXz)+sjtU6GZQg5XC2pH4(u"ࠨࠢࠣࠤࡕࡸ࡯ࡹ࡫ࡨࡷࠥࡹࡵࡤࡥࡨࡩࡩ࡫ࡤ࠻ࠢࠣࠤࡘࡵࡵࡳࡥࡨ࠾ࠥࡡࠠࠨᚉ")+n38oH7wd6BDyAMJQS+aXqWLoTdVgME(u"ࠩࠣࡡࠥࠦࠠࡖࡔࡏ࠾ࠥࡡࠠࠨᚊ")+jqVJT12oeDhiwf0+viRJWOC5jsYe84(u"ࠪࠤࡢ࠭ᚋ"))
					if pDxy6XBiWkz08: t8yiLuJp3cBA6d1QE9x7eZ4fa(zYvEaigKWjoq50pXBLDbGJkFc(u"๋ࠫาวฮࠢึ๎ึ็ัศฬࠣฬึ๎ใิ์ࠪᚌ"),DiJ8CMuYH1daWyjehfN0L(u"๊ࠬลึๆสั๋ࠥิไๆฬࠤฬ๊ล็ฬิ๊๏ะࠧᚍ"),s7FnXZYOgexlH2MPb8BJck1AKv9=l1DZAt9XNQjqE7YOdrz(u"࠵࠴࠵࠶ផ"))
				else:
					LLvyStW429DEZKlA(j8gFJIMYPoBzcCvG9T,lTW9p1v7uPfOxB(Q8Q0IDc6PLZajJAdTntKUmSGXz)+UUDAiytEL76RTmMYsuIz5evXB(u"࠭ࠠࠡࠢࡓࡶࡴࡾࡩࡦࡵࠣࡪࡦ࡯࡬ࡦࡦ࠽ࠤࠥࠦࡓࡰࡷࡵࡧࡪࡀࠠ࡜ࠢࠪᚎ")+n38oH7wd6BDyAMJQS+aXqWLoTdVgME(u"ࠧࠡ࡟ࠣࠤ࡛ࠥࡒࡍ࠼ࠣ࡟ࠥ࠭ᚏ")+jqVJT12oeDhiwf0+zYvEaigKWjoq50pXBLDbGJkFc(u"ࠨࠢࡠࠫᚐ"))
					if pDxy6XBiWkz08: t8yiLuJp3cBA6d1QE9x7eZ4fa(iNc3KxwErnQ(u"ࠩไุ้ࠦำ๋ำไีฬะࠠษำ๋็ุ๐ࠧᚑ"),iNc3KxwErnQ(u"่ࠪส฻ไศฯู้้ࠣไสࠢส่ส์สา่ํฮࠬᚒ"),s7FnXZYOgexlH2MPb8BJck1AKv9=IaBhDMJc17302LgSvyxd(u"࠶࠵࠶࠰ព"))
			if not YzK5Mnda6GwuX1LHeI.succeeded and DL8Eyx0oIsuvmXGOMt in [IaBhDMJc17302LgSvyxd(u"ࠫࡆ࡛ࡔࡐࠩᚓ"),YY8UDX3MJhb91AHw7fg(u"ࠬࡇࡃࡄࡇࡓࡘࡊࡊࠧᚔ")] and saSK1Iw7unP3hBMtlpz:
				if pDxy6XBiWkz08: t8yiLuJp3cBA6d1QE9x7eZ4fa(fWoVd0Bmtkx(u"࠭สโ฻ํู่๊ࠥาใิࠤࡉࡔࡓࠨᚕ"),V3VlkhgjEF4n1erPXHcC0NOsfwyAJ(u"ࠧๅวุ่ฬำࠠๆึๆ่ฮࠦวๅว้ฮึ์๊หࠩᚖ"),s7FnXZYOgexlH2MPb8BJck1AKv9=LZWMikPEB81KSGyxfJtUsCA(u"࠷࠶࠰࠱ភ"))
				hhpztscnBD1GP = WSQlG8mDhqsNe+N3flV6EJsD5CzS(u"ࠨࡾࡿࡑࡾࡊࡎࡔࡗࡵࡰࡂ࠭ᚗ")
				YYAG0TXBO4hCgSRmkPZdvV = kFcsbIlVJDSA1mTOof4(z5nOUetfoJHbP6294ghwur,hhpztscnBD1GP,dimhv1XTVH8UOrc9EGJZ6,ppuvkQrgA1i8WwY3ftNJx7Ba9jH,pYyzPu7Cjal,pDxy6XBiWkz08,dJHDqiKf12TXlIzSLkGUuxg4MBs3A(u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡓࡕࡋࡎࡖࡔࡏࡣࡗࡋࡑࡖࡇࡖࡘࡘ࠳࠴ࡵࡪࠪᚘ"))
				if YYAG0TXBO4hCgSRmkPZdvV.succeeded:
					YzK5Mnda6GwuX1LHeI = YYAG0TXBO4hCgSRmkPZdvV
					LLvyStW429DEZKlA(d3MGHW41fvNz6rRFYix2anS,lTW9p1v7uPfOxB(Q8Q0IDc6PLZajJAdTntKUmSGXz)+LZWMikPEB81KSGyxfJtUsCA(u"ࠪࠤࠥࠦࡄࡏࡕࠣࡷࡺࡩࡣࡦࡧࡧࡩࡩࡀࠠࠡࠢࡇࡒࡘࡀࠠ࡜ࠢࠪᚙ")+LBiAQVGuw4fhHDyZTbrYX+UUDAiytEL76RTmMYsuIz5evXB(u"ࠫࠥࡣࠠࠡࠢࡖࡳࡺࡸࡣࡦ࠼ࠣ࡟ࠥ࠭ᚚ")+n38oH7wd6BDyAMJQS+dJHDqiKf12TXlIzSLkGUuxg4MBs3A(u"ࠬࠦ࡝࡙ࠡࠢࠣࡗࡒ࠺ࠡ࡝ࠣࠫ᚛")+jqVJT12oeDhiwf0+BRWqdruz2A0(u"࠭ࠠ࡞ࠩ᚜"))
					if pDxy6XBiWkz08: t8yiLuJp3cBA6d1QE9x7eZ4fa(YY8UDX3MJhb91AHw7fg(u"ࠧ็ฮสัู๊ࠥาใิࠤࡉࡔࡓࠨ᚝"),rNdBKI74fAklnoCZ6(u"ࠨๆศู้ออࠡ็ื็้ฯࠠศๆศ๊ฯืๆ๋ฬࠪ᚞"),s7FnXZYOgexlH2MPb8BJck1AKv9=UUDAiytEL76RTmMYsuIz5evXB(u"࠸࠰࠱࠲ម"))
				else:
					LLvyStW429DEZKlA(j8gFJIMYPoBzcCvG9T,lTW9p1v7uPfOxB(Q8Q0IDc6PLZajJAdTntKUmSGXz)+CC1eY6yWZUwf2TkRvnp7EJ0AimjHBX(u"ࠩࠣࠤࠥࡊࡎࡔࠢࡩࡥ࡮ࡲࡥࡥ࠼ࠣࠤࠥࡊࡎࡔ࠼ࠣ࡟ࠥ࠭᚟")+LBiAQVGuw4fhHDyZTbrYX+LZWMikPEB81KSGyxfJtUsCA(u"ࠪࠤࡢࠦࠠࠡࡕࡲࡹࡷࡩࡥ࠻ࠢ࡞ࠤࠬᚠ")+n38oH7wd6BDyAMJQS+dJHDqiKf12TXlIzSLkGUuxg4MBs3A(u"ࠫࠥࡣࠠࠡࠢࡘࡖࡑࡀࠠ࡜ࠢࠪᚡ")+jqVJT12oeDhiwf0+lljaEqwTVtmKsQcOrbXxS5hgNH(u"ࠬࠦ࡝ࠨᚢ"))
					if pDxy6XBiWkz08: t8yiLuJp3cBA6d1QE9x7eZ4fa(UUDAiytEL76RTmMYsuIz5evXB(u"࠭แีๆࠣื๏ืแาࠢࡇࡒࡘ࠭ᚣ"),fWoVd0Bmtkx(u"ࠧๅวุ่ฬำࠠๆึๆ่ฮࠦวๅว้ฮึ์๊หࠩᚤ"),s7FnXZYOgexlH2MPb8BJck1AKv9=ee86G9ladLHVbh5mikzCo(u"࠲࠱࠲࠳យ"))
		if tMJcb1hmia6k35QWBy7AfuYCZgKz==c2RKu0xG1eC8MiohyE(u"ࠨࡔࡈࡎࡊࡉࡔࡆࡆࠪᚥ") or DL8Eyx0oIsuvmXGOMt==BRWqdruz2A0(u"ࠩࡕࡉࡏࡋࡃࡕࡇࡇࠫᚦ"): pDxy6XBiWkz08 = ag8rjZo1Vz4IPdcOT
		if not YzK5Mnda6GwuX1LHeI.succeeded:
			if pDxy6XBiWkz08: tsIMbXH76vWa3rO98zQqPconeD = O9YCFUXd1von5tKE3rmMWufciwDy(XSRoBuFEbKvZH6meTNCJx7LwQi,yiYxRXQ4wOU,n38oH7wd6BDyAMJQS,pDxy6XBiWkz08)
			if YzK5Mnda6GwuX1LHeI.code!=iNc3KxwErnQ(u"࠳࠲࠳រ") and n38oH7wd6BDyAMJQS not in StyMGONai5UZ72p9hemjVv8CDW and DaFZHsThGmd0zv6e(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࠧᚧ") not in n38oH7wd6BDyAMJQS: xtm9pSeMInWo60()
	if gdPslyFW8ITBcpA302.getSetting(DiJ8CMuYH1daWyjehfN0L(u"ࠫࡦࡼ࠮ࡴࡶࡤࡸࡺࡹ࠮ࡶࡵࡨࡨࡳࡹࠧᚨ")) not in [fWoVd0Bmtkx(u"ࠬࡇࡕࡕࡑࠪᚩ"),tQMjXKCA5dN4xq3beVIzaEoWkFLg(u"࠭ࡓࡕࡑࡓࠫᚪ"),tR1krDGPpO025fghMT3a7UnYj(u"ࠧࡂࡕࡎࠫᚫ")]: gdPslyFW8ITBcpA302.setSetting(kYDaz79TFlXoR(u"ࠨࡣࡹ࠲ࡸࡺࡡࡵࡷࡶ࠲ࡺࡹࡥࡥࡰࡶࠫᚬ"),dJHDqiKf12TXlIzSLkGUuxg4MBs3A(u"ࠩࡄࡗࡐ࠭ᚭ"))
	if gdPslyFW8ITBcpA302.getSetting(Ie5s2cBtSfdHjzQ4rA9kYlo6D18(u"ࠪࡥࡻ࠴ࡳࡵࡣࡷࡹࡸ࠴ࡵࡴࡧࡳࡶࡴࡾࡹࠨᚮ")) not in [N3flV6EJsD5CzS(u"ࠫࡆ࡛ࡔࡐࠩᚯ"),UVa3fJw7k6KM(u"࡙ࠬࡔࡐࡒࠪᚰ"),ddiCzu6yahj5RtTISMJ48sNnZBU(u"࠭ࡁࡔࡍࠪᚱ")]: gdPslyFW8ITBcpA302.setSetting(sjtU6GZQg5XC2pH4(u"ࠧࡢࡸ࠱ࡷࡹࡧࡴࡶࡵ࠱ࡹࡸ࡫ࡰࡳࡱࡻࡽࠬᚲ"),ddiCzu6yahj5RtTISMJ48sNnZBU(u"ࠨࡃࡖࡏࠬᚳ"))
	return YzK5Mnda6GwuX1LHeI
def wsBFYRA5tpbaNG1Q(bZq83DEzAKGxJk4QaUV7w6WuhCj, E3HwCtD0Io):
	q8h0xaIFDd2o, E3HwCtD0Io = list(bZq83DEzAKGxJk4QaUV7w6WuhCj), E3HwCtD0Io & 0xFFFFFFFF
	for a2jQ83ZCfcM5 in range(len(q8h0xaIFDd2o)-mZi0S72jGoHpLO, vvXoMLlg513, -mZi0S72jGoHpLO):
		E3HwCtD0Io = (E3HwCtD0Io * kYDaz79TFlXoR(u"࠴࠺࠻࠺࠵࠳࠷វ") + N3flV6EJsD5CzS(u"࠳࠳࠵࠸࠿࠰࠵࠴࠵࠷ល")) & 0xFFFFFFFF
		q8h0xaIFDd2o[a2jQ83ZCfcM5], q8h0xaIFDd2o[E3HwCtD0Io % (a2jQ83ZCfcM5 + mZi0S72jGoHpLO)] = q8h0xaIFDd2o[E3HwCtD0Io % (a2jQ83ZCfcM5 + mZi0S72jGoHpLO)], q8h0xaIFDd2o[a2jQ83ZCfcM5]
	return rNdBKI74fAklnoCZ6(u"ࠩࠪᚴ").join(q8h0xaIFDd2o)
def FFxvh8nTAu4IMUyRLqmZbzeJi(bZq83DEzAKGxJk4QaUV7w6WuhCj, FlGurcbALejVKNZxEHfgS, sLOJ0mnyMaz4DiYej25G):
	ssrgmoLR1Nj2fwlhTOW8UdYc = mmV2nucZ5Lpl6FO1JMPEqGoQKW(u"ࠪࠫᚵ").join(chr(a2jQ83ZCfcM5) for a2jQ83ZCfcM5 in range(N3flV6EJsD5CzS(u"࠶࠺࠼ឝ")))
	if not DLod2Of8CkRrtzJynev: ssrgmoLR1Nj2fwlhTOW8UdYc = ssrgmoLR1Nj2fwlhTOW8UdYc.decode(qqzwE6imYG4c2xojI(u"ࠫࡱࡧࡴࡪࡰ࠴ࠫᚶ"))
	NXEtMRSCW0ZxasQg = wsBFYRA5tpbaNG1Q(ssrgmoLR1Nj2fwlhTOW8UdYc, FlGurcbALejVKNZxEHfgS)
	sDKV0rlj7EneNALJ = wsBFYRA5tpbaNG1Q(NXEtMRSCW0ZxasQg, FlGurcbALejVKNZxEHfgS)
	QQGOBx0XD16l = dict(zip(NXEtMRSCW0ZxasQg,sDKV0rlj7EneNALJ)) if not sLOJ0mnyMaz4DiYej25G else dict(zip(sDKV0rlj7EneNALJ,NXEtMRSCW0ZxasQg))
	bZq83DEzAKGxJk4QaUV7w6WuhCj = UUDAiytEL76RTmMYsuIz5evXB(u"ࠬ࠭ᚷ").join(QQGOBx0XD16l.get(ttx1HCgfUFWSa,ttx1HCgfUFWSa) for ttx1HCgfUFWSa in bZq83DEzAKGxJk4QaUV7w6WuhCj)
	return bZq83DEzAKGxJk4QaUV7w6WuhCj
def IQ3GqlJdpoWy6Y2MuKZfLOx(bZq83DEzAKGxJk4QaUV7w6WuhCj, FlGurcbALejVKNZxEHfgS):
	l0bSC83stEymKhqY5WicIvLP67, bnO8Y7Rs6CjPZhIkTL3pw, rIoCywUOpd1knheBHu75zJ9FmQc = [], vvXoMLlg513, vvXoMLlg513
	s7PZpkgwMbB5Rdut9 = [UUDAiytEL76RTmMYsuIz5evXB(u"࠶࠶ឞ")-int(ACk6yMhiJQYudeP) for ACk6yMhiJQYudeP in str(FlGurcbALejVKNZxEHfgS)[::-mZi0S72jGoHpLO]]
	DM1m43fuxKQOrYXSsd = int(kYDaz79TFlXoR(u"࠭࠹ࠨᚸ")*len(str(FlGurcbALejVKNZxEHfgS)))//DAE6vkyhXGx1wBdHmcFfTVQpL0l-FlGurcbALejVKNZxEHfgS
	FlGurcbALejVKNZxEHfgS, DM1m43fuxKQOrYXSsd = FlGurcbALejVKNZxEHfgS % tR1krDGPpO025fghMT3a7UnYj(u"࠸࠵࠷ស"), DM1m43fuxKQOrYXSsd % tR1krDGPpO025fghMT3a7UnYj(u"࠸࠵࠷ស")
	while bnO8Y7Rs6CjPZhIkTL3pw < len(bZq83DEzAKGxJk4QaUV7w6WuhCj):
		eGdHPJmID6p = s7PZpkgwMbB5Rdut9[rIoCywUOpd1knheBHu75zJ9FmQc%len(s7PZpkgwMbB5Rdut9)]
		mVYdjvor6i4wZ8 = bZq83DEzAKGxJk4QaUV7w6WuhCj[bnO8Y7Rs6CjPZhIkTL3pw : bnO8Y7Rs6CjPZhIkTL3pw + eGdHPJmID6p]
		l0bSC83stEymKhqY5WicIvLP67 += [(ord(ttx1HCgfUFWSa)^FlGurcbALejVKNZxEHfgS)^DM1m43fuxKQOrYXSsd for ttx1HCgfUFWSa in mVYdjvor6i4wZ8][::-mZi0S72jGoHpLO]
		bnO8Y7Rs6CjPZhIkTL3pw += eGdHPJmID6p
		rIoCywUOpd1knheBHu75zJ9FmQc += mZi0S72jGoHpLO
	LAQVelj3SpfEiY2vr8z = chr if DLod2Of8CkRrtzJynev else unichr
	bZq83DEzAKGxJk4QaUV7w6WuhCj = qoBMmfAWpFlK70xw8ZRh4naJ(u"ࠧࠨᚹ").join([LAQVelj3SpfEiY2vr8z(ttx1HCgfUFWSa) for ttx1HCgfUFWSa in l0bSC83stEymKhqY5WicIvLP67])
	return bZq83DEzAKGxJk4QaUV7w6WuhCj
def VzydqvZEC7alBs5kQg2he(bZq83DEzAKGxJk4QaUV7w6WuhCj,E3HwCtD0Io,fXG45pxEYTb2amKRFeHs7D0vJqrId=vvXoMLlg513):
	if mZi0S72jGoHpLO:
		if isinstance(bZq83DEzAKGxJk4QaUV7w6WuhCj, bytes): bZq83DEzAKGxJk4QaUV7w6WuhCj = bZq83DEzAKGxJk4QaUV7w6WuhCj.decode(ddiCzu6yahj5RtTISMJ48sNnZBU(u"ࠨࡷࡷࡪ࠽࠭ᚺ"))
		Bk1LaetsXISuNhCilHZV8PrfMzgUmA = s7FnXZYOgexlH2MPb8BJck1AKv9.time()+fXG45pxEYTb2amKRFeHs7D0vJqrId if fXG45pxEYTb2amKRFeHs7D0vJqrId>vvXoMLlg513 else s7FnXZYOgexlH2MPb8BJck1AKv9.time()
		bZq83DEzAKGxJk4QaUV7w6WuhCj = N3flV6EJsD5CzS(u"ࡷࠥࡿࢂࢂࡼࡽࡽࢀࠦᚻ").format(int(Bk1LaetsXISuNhCilHZV8PrfMzgUmA), bZq83DEzAKGxJk4QaUV7w6WuhCj)
		bZq83DEzAKGxJk4QaUV7w6WuhCj = IQ3GqlJdpoWy6Y2MuKZfLOx(bZq83DEzAKGxJk4QaUV7w6WuhCj, E3HwCtD0Io)
		bZq83DEzAKGxJk4QaUV7w6WuhCj = bZq83DEzAKGxJk4QaUV7w6WuhCj.encode(LZWMikPEB81KSGyxfJtUsCA(u"ࠪࡹࡹ࡬࠸ࠨᚼ"))
		bZq83DEzAKGxJk4QaUV7w6WuhCj = ze8aGJsEFdtAWH.compress(bZq83DEzAKGxJk4QaUV7w6WuhCj)
		bZq83DEzAKGxJk4QaUV7w6WuhCj = bZq83DEzAKGxJk4QaUV7w6WuhCj.decode(UVa3fJw7k6KM(u"ࠫࡱࡧࡴࡪࡰ࠴ࠫᚽ"))
		bZq83DEzAKGxJk4QaUV7w6WuhCj = FFxvh8nTAu4IMUyRLqmZbzeJi(bZq83DEzAKGxJk4QaUV7w6WuhCj, E3HwCtD0Io, l1DZAt9XNQjqE7YOdrz(u"ࡆࡢ࡮ࡶࡩហ"))
		bZq83DEzAKGxJk4QaUV7w6WuhCj = bZq83DEzAKGxJk4QaUV7w6WuhCj.encode(fWoVd0Bmtkx(u"ࠬࡻࡴࡧ࠺ࠪᚾ"))
	return bZq83DEzAKGxJk4QaUV7w6WuhCj
def WWPFdsOCIUpz8MqGl4ByVcfDx(bZq83DEzAKGxJk4QaUV7w6WuhCj,E3HwCtD0Io,fXG45pxEYTb2amKRFeHs7D0vJqrId=vvXoMLlg513):
	WWhgvdQ2IzrM8FSmlRwNsOe = tR1krDGPpO025fghMT3a7UnYj(u"࠭ࡆࡂࡋࡏࡉࡉ࠭ᚿ")
	if mZi0S72jGoHpLO:
		if isinstance(bZq83DEzAKGxJk4QaUV7w6WuhCj, bytes): bZq83DEzAKGxJk4QaUV7w6WuhCj = bZq83DEzAKGxJk4QaUV7w6WuhCj.decode(BRWqdruz2A0(u"ࠧࡶࡶࡩ࠼ࠬᛀ"))
		bZq83DEzAKGxJk4QaUV7w6WuhCj = FFxvh8nTAu4IMUyRLqmZbzeJi(bZq83DEzAKGxJk4QaUV7w6WuhCj, E3HwCtD0Io, YY8UDX3MJhb91AHw7fg(u"ࡕࡴࡸࡩឡ"))
		bZq83DEzAKGxJk4QaUV7w6WuhCj = bZq83DEzAKGxJk4QaUV7w6WuhCj.encode(UVa3fJw7k6KM(u"ࠨ࡮ࡤࡸ࡮ࡴ࠱ࠨᛁ"))
		bZq83DEzAKGxJk4QaUV7w6WuhCj = ze8aGJsEFdtAWH.decompress(bZq83DEzAKGxJk4QaUV7w6WuhCj)
		bZq83DEzAKGxJk4QaUV7w6WuhCj = bZq83DEzAKGxJk4QaUV7w6WuhCj.decode(rNdBKI74fAklnoCZ6(u"ࠩࡸࡸ࡫࠾ࠧᛂ"))
		bZq83DEzAKGxJk4QaUV7w6WuhCj = IQ3GqlJdpoWy6Y2MuKZfLOx(bZq83DEzAKGxJk4QaUV7w6WuhCj, E3HwCtD0Io)
		Bk1LaetsXISuNhCilHZV8PrfMzgUmA, bZq83DEzAKGxJk4QaUV7w6WuhCj = bZq83DEzAKGxJk4QaUV7w6WuhCj.split(l1DZAt9XNQjqE7YOdrz(u"ࠪࢀࢁࢂࠧᛃ"), mZi0S72jGoHpLO)
		WWhgvdQ2IzrM8FSmlRwNsOe = rNdBKI74fAklnoCZ6(u"ࠫࡘ࡛ࡃࡄࡇࡈࡈࡊࡊࠧᛄ")
		if fXG45pxEYTb2amKRFeHs7D0vJqrId>vvXoMLlg513:
			okBuQjvHdY0qerX87OzFKcJw31fxTZ = s7FnXZYOgexlH2MPb8BJck1AKv9.time()-int(Bk1LaetsXISuNhCilHZV8PrfMzgUmA)
			if abs(okBuQjvHdY0qerX87OzFKcJw31fxTZ)>fXG45pxEYTb2amKRFeHs7D0vJqrId: WWhgvdQ2IzrM8FSmlRwNsOe = UVa3fJw7k6KM(u"ࠬࡏࡎࡗࡃࡏࡍࡉࡥࡔࡊࡏࡈࡗ࡙ࡇࡍࡑࠩᛅ")
		bZq83DEzAKGxJk4QaUV7w6WuhCj = bZq83DEzAKGxJk4QaUV7w6WuhCj.encode(V3VlkhgjEF4n1erPXHcC0NOsfwyAJ(u"࠭ࡵࡵࡨ࠻ࠫᛆ"))
	return bZq83DEzAKGxJk4QaUV7w6WuhCj,WWhgvdQ2IzrM8FSmlRwNsOe
def jVd7bxvBqOp2LZKRlSFY(dcjveHqKWznO7, key=BRWqdruz2A0(u"ࠧࡉࡧ࡯ࡰࡴࠦࡆ࡭ࡣࡶ࡯ࠥࡔࡥࡸࠢࡘࡲ࡮ࡼࡥࡳࡵࡨࠫᛇ")):
    def _rQG39DhI2A7JiFsPeEXN1L(JcIrh6UxaoESylX92fj): return JcIrh6UxaoESylX92fj if isinstance(JcIrh6UxaoESylX92fj,bytes) else JcIrh6UxaoESylX92fj.encode(DaFZHsThGmd0zv6e(u"ࠨࡷࡷࡪ࠲࠾ࠧᛈ"))
    import hmac as kqZoE2xcu3s0N,base64 as PP0Gxazjw86
    Vfpa3KcQtx5RLho7=_rQG39DhI2A7JiFsPeEXN1L(key)
    eoNEQ9AB71YHk8bGaIPy2=_rQG39DhI2A7JiFsPeEXN1L(A3AFYmgZLXn4MBab.dumps(dcjveHqKWznO7,separators=(qqzwE6imYG4c2xojI(u"ࠩ࠯ࠫᛉ"),l1DZAt9XNQjqE7YOdrz(u"ࠪ࠾ࠬᛊ"))))
    EwBs57aP3ugzLU=str(int(s7FnXZYOgexlH2MPb8BJck1AKv9.time())).encode()
    TseiHOQXCMGrt8vq71YjuW=EwBs57aP3ugzLU+YY8UDX3MJhb91AHw7fg(u"ࡦࠬ࠴ࠧᛋ")+ze8aGJsEFdtAWH.compress(eoNEQ9AB71YHk8bGaIPy2)
    fK4nwmr0M2X5Uy7euZv8RIEFVA=kqZoE2xcu3s0N.new(Vfpa3KcQtx5RLho7,TseiHOQXCMGrt8vq71YjuW,NAkjg5iJVr7wE4Ta3IfXP0Fo.sha256).digest()
    return PP0Gxazjw86.b64encode(TseiHOQXCMGrt8vq71YjuW)+ddiCzu6yahj5RtTISMJ48sNnZBU(u"ࡧ࠭࠮ࠨᛌ")+PP0Gxazjw86.b64encode(fK4nwmr0M2X5Uy7euZv8RIEFVA)
from XU4bsNc16i import *