# -*- coding: utf-8 -*-
from pSfaryIjBo import *
Q8Q0IDc6PLZajJAdTntKUmSGXz = 'SHAHID4U'
wwSFijdVJn1QgHW = '_SH4_'
ddBxj51bhNtaK23lDyGMVw = i4bFG3rKE6.SITESURLS[Q8Q0IDc6PLZajJAdTntKUmSGXz][0]
headers = {'User-Agent':IyjRtqkmHFBvTCDYwuQNJ0(True)}
YEIA19ehBwpNfPVzK = ['عروض مصارعة','الكل','افلام','javascript','مصارعة حرة']
def vTNE2Ck1sGnugJYW8y39aLcSH64U(mode,url,text):
	if   mode==110: MOTjA5H9XFs = nRVAZc4Dp8PSrGU3xBk()
	elif mode==111: MOTjA5H9XFs = c8U1BdtxOZS5FH(url,text)
	elif mode==112: MOTjA5H9XFs = mzcAeyplZV(url)
	elif mode==113: MOTjA5H9XFs = v1gmfxDcRrWKQ(url,True)
	elif mode==114: MOTjA5H9XFs = R9pWUgVhBGLd2CQb0z(url,'FULL_FILTER___'+text)
	elif mode==115: MOTjA5H9XFs = R9pWUgVhBGLd2CQb0z(url,'DEFINED_FILTER___'+text)
	elif mode==116: MOTjA5H9XFs = v1gmfxDcRrWKQ(url,False)
	elif mode==119: MOTjA5H9XFs = PPqUACSE3VcGLTvw05jHy9JrFNW(text)
	else: MOTjA5H9XFs = False
	return MOTjA5H9XFs
def nRVAZc4Dp8PSrGU3xBk():
	x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+'بحث في الموقع',qpFY4hAwolV3,119,qpFY4hAwolV3,qpFY4hAwolV3,'_REMEMBERRESULTS_')
	x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+'فلتر محدد',ddBxj51bhNtaK23lDyGMVw,115)
	x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+'فلتر كامل',ddBxj51bhNtaK23lDyGMVw,114)
	x3WSXnKyPhjqfHG2UrtQs('link',xupTj02bvy3O8R+' ===== ===== ===== '+fF4lt9zWYxXLKZVyAco82PgMj,qpFY4hAwolV3,9999)
	x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+'المميزة',ddBxj51bhNtaK23lDyGMVw,111,qpFY4hAwolV3,qpFY4hAwolV3,'featured')
	IAW0sh6So3NpqM = WWrExJZS3Bj4anOAkpv7(kUz8c7OqsxuPFIGfwg,'GET',ddBxj51bhNtaK23lDyGMVw,qpFY4hAwolV3,headers,qpFY4hAwolV3,qpFY4hAwolV3,'SHAHID4U-MENU-1st')
	cmWl9dOKHPIy41iaXuxrY = IAW0sh6So3NpqM.content
	pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('simple-filter(.*?)adv-filter',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	if not pfRkcVlLmUxo561g0A8qSbO:
		iG7Rz2kmn0x1yLNMV3u8O(qpFY4hAwolV3,qpFY4hAwolV3,'موقع شاهد فوريو','البرنامج لم يستطيع إيجاد عنوان الموقع أو تصميم الموقع تغير')
		return
	else:
		mVYdjvor6i4wZ8 = pfRkcVlLmUxo561g0A8qSbO[0]
		items = ePhmG1jLD6.findall('location = \'(.*?)\'.*?src="(.*?)".*?<h3>(.*?)<',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
		for filter,Sj7rMNYRuQPTtkBvpHKeDW3h,title in items:
			url = ddBxj51bhNtaK23lDyGMVw+filter
			x3WSXnKyPhjqfHG2UrtQs('folder',Q8Q0IDc6PLZajJAdTntKUmSGXz+'_SCRIPT_'+wwSFijdVJn1QgHW+title,url,111,Sj7rMNYRuQPTtkBvpHKeDW3h,qpFY4hAwolV3,filter)
		x3WSXnKyPhjqfHG2UrtQs('link',xupTj02bvy3O8R+' ===== ===== ===== '+fF4lt9zWYxXLKZVyAco82PgMj,qpFY4hAwolV3,9999)
	pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('class="dropdown"(.*?)<script>',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	if pfRkcVlLmUxo561g0A8qSbO:
		mVYdjvor6i4wZ8 = pfRkcVlLmUxo561g0A8qSbO[0]
		items = ePhmG1jLD6.findall('href="(.*?)".*?>(.*?)<',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
		for MepIvHBYNArkUOdV37shtJ,title in items:
			title = title.replace(ZLwoRpfnCWI7FgEHsz6te39lMVh,qpFY4hAwolV3).replace(SGUiazdreo6QRKLOWZj5hMX,qpFY4hAwolV3).strip(mIsDke0oK5x1zSiOWbF9thGcA)
			if title in YEIA19ehBwpNfPVzK: continue
			if 'http' not in MepIvHBYNArkUOdV37shtJ: MepIvHBYNArkUOdV37shtJ = ddBxj51bhNtaK23lDyGMVw+MepIvHBYNArkUOdV37shtJ
			if 'netflix' in MepIvHBYNArkUOdV37shtJ: title = 'نيتفلكس'
			x3WSXnKyPhjqfHG2UrtQs('folder',Q8Q0IDc6PLZajJAdTntKUmSGXz+'_SCRIPT_'+wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,111)
	return cmWl9dOKHPIy41iaXuxrY
def c8U1BdtxOZS5FH(url,emb0iauxpw6ZAKNyoLHfc1qRnB9UME=qpFY4hAwolV3,IAW0sh6So3NpqM=qpFY4hAwolV3):
	if not IAW0sh6So3NpqM: IAW0sh6So3NpqM = WWrExJZS3Bj4anOAkpv7(kUz8c7OqsxuPFIGfwg,'GET',url,qpFY4hAwolV3,headers,qpFY4hAwolV3,qpFY4hAwolV3,'SHAHID4U-TITLES-1st')
	cmWl9dOKHPIy41iaXuxrY = IAW0sh6So3NpqM.content
	pfRkcVlLmUxo561g0A8qSbO,items,aaCNAJdtsguSRELh2I = [],[],[]
	if emb0iauxpw6ZAKNyoLHfc1qRnB9UME=='featured': pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('glide__slides(.*?)</ul>',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	else: pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('shows-container(.*?)pagination',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	if not pfRkcVlLmUxo561g0A8qSbO: return
	mVYdjvor6i4wZ8 = pfRkcVlLmUxo561g0A8qSbO[0]
	if not items: items = ePhmG1jLD6.findall('href="(.*?)".*?url\((.*?)\).*?"title">(.*?)<',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
	WGid3I2kFU = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم']
	for MepIvHBYNArkUOdV37shtJ,Sj7rMNYRuQPTtkBvpHKeDW3h,title in items:
		if 'WWE' in title: continue
		if 'javascript' in MepIvHBYNArkUOdV37shtJ: continue
		MepIvHBYNArkUOdV37shtJ = cTt4u6reEMKZqVLplmkNW7(MepIvHBYNArkUOdV37shtJ).strip(ShynO8pN9idCE3)
		title = j8PDV0pthfSTidZbsQxNIOmCYKWzH(title)
		title = title.strip(mIsDke0oK5x1zSiOWbF9thGcA)
		ZDTxRSMbW7PNz = ePhmG1jLD6.findall('(.*?) الحلقة \d+',title,ePhmG1jLD6.DOTALL)
		if '/film/' in MepIvHBYNArkUOdV37shtJ or 'فيلم' in MepIvHBYNArkUOdV37shtJ or any(value in title for value in WGid3I2kFU):
			x3WSXnKyPhjqfHG2UrtQs('video',wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,112,Sj7rMNYRuQPTtkBvpHKeDW3h)
		elif ZDTxRSMbW7PNz and 'الحلقة' in title and '/list' not in url:
			title = '_MOD_' + ZDTxRSMbW7PNz[0]
			if title not in aaCNAJdtsguSRELh2I:
				x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,113,Sj7rMNYRuQPTtkBvpHKeDW3h)
				aaCNAJdtsguSRELh2I.append(title)
		elif '/actor/' in MepIvHBYNArkUOdV37shtJ:
			x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,111,Sj7rMNYRuQPTtkBvpHKeDW3h)
		elif '/series/' in MepIvHBYNArkUOdV37shtJ and '/list' not in url:
			MepIvHBYNArkUOdV37shtJ = MepIvHBYNArkUOdV37shtJ+'/list'
			x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,111,Sj7rMNYRuQPTtkBvpHKeDW3h)
		elif '/list' in url and 'حلقة' in title:
			x3WSXnKyPhjqfHG2UrtQs('video',wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,112,Sj7rMNYRuQPTtkBvpHKeDW3h)
		else: x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,113,Sj7rMNYRuQPTtkBvpHKeDW3h)
	pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('"pagination"(.*?)</ul>',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	if pfRkcVlLmUxo561g0A8qSbO and emb0iauxpw6ZAKNyoLHfc1qRnB9UME!='featured':
		mVYdjvor6i4wZ8 = pfRkcVlLmUxo561g0A8qSbO[0]
		if emb0iauxpw6ZAKNyoLHfc1qRnB9UME!='search': items = ePhmG1jLD6.findall('(updateQuery).*?>(.+?)<',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
		else: items = ePhmG1jLD6.findall('<li>.*?href="(.*?)">(.*?)<',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
		if 'page=' in url: url = url.split('page=',1)[0][:-1]
		for MepIvHBYNArkUOdV37shtJ,title in items:
			title = title.replace(ZLwoRpfnCWI7FgEHsz6te39lMVh,qpFY4hAwolV3).replace(SGUiazdreo6QRKLOWZj5hMX,qpFY4hAwolV3)
			title = title.strip(mIsDke0oK5x1zSiOWbF9thGcA)
			if emb0iauxpw6ZAKNyoLHfc1qRnB9UME!='search':
				MepIvHBYNArkUOdV37shtJ = url+'&page='+title if '?' in url else url+'?page='+title
			title = j8PDV0pthfSTidZbsQxNIOmCYKWzH(title)
			if title: x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+'صفحة '+title,MepIvHBYNArkUOdV37shtJ,111,qpFY4hAwolV3,qpFY4hAwolV3,emb0iauxpw6ZAKNyoLHfc1qRnB9UME)
	return
def v1gmfxDcRrWKQ(url,l6Avp1TZwHD7NPyh38XUz):
	IAW0sh6So3NpqM = WWrExJZS3Bj4anOAkpv7(kUz8c7OqsxuPFIGfwg,'GET',url,qpFY4hAwolV3,headers,qpFY4hAwolV3,qpFY4hAwolV3,'SHAHID4U-EPISODES-1st')
	cmWl9dOKHPIy41iaXuxrY = IAW0sh6So3NpqM.content
	pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('items d-flex(.*?)</div>',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	if len(pfRkcVlLmUxo561g0A8qSbO)>1:
		if '/season/' in pfRkcVlLmUxo561g0A8qSbO[0]: WWQOoJZpXFmLHnDht1j,pzLc3HwImv2dru = pfRkcVlLmUxo561g0A8qSbO[0],pfRkcVlLmUxo561g0A8qSbO[1]
		else: WWQOoJZpXFmLHnDht1j,pzLc3HwImv2dru = pfRkcVlLmUxo561g0A8qSbO[1],pfRkcVlLmUxo561g0A8qSbO[0]
	else: WWQOoJZpXFmLHnDht1j,pzLc3HwImv2dru = pfRkcVlLmUxo561g0A8qSbO[0],pfRkcVlLmUxo561g0A8qSbO[0]
	for nnZ13Rr6tYXio0DyfLVvSxBec in range(2):
		if l6Avp1TZwHD7NPyh38XUz: mode,type,mVYdjvor6i4wZ8 = 116,'folder',WWQOoJZpXFmLHnDht1j
		else: mode,type,mVYdjvor6i4wZ8 = 112,'video',pzLc3HwImv2dru
		items = ePhmG1jLD6.findall('href="(.*?)".*?span.*?">(.*?)<.*?span.*?">(.*?)<',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
		if l6Avp1TZwHD7NPyh38XUz and len(items)<2:
			l6Avp1TZwHD7NPyh38XUz = False
			continue
		for MepIvHBYNArkUOdV37shtJ,rr1mzIljJHqkx,UdbGw48M6rCHDRmea5qP91nKI in items:
			title = rr1mzIljJHqkx+mIsDke0oK5x1zSiOWbF9thGcA+UdbGw48M6rCHDRmea5qP91nKI
			x3WSXnKyPhjqfHG2UrtQs(type,wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,mode)
		break
	if not items and '/episodes' in cmWl9dOKHPIy41iaXuxrY:
		Tj9nPzghOXy2DGspIZHK = ePhmG1jLD6.findall('class="breadcrumb"(.*?)</div>',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
		if Tj9nPzghOXy2DGspIZHK:
			mVYdjvor6i4wZ8 = Tj9nPzghOXy2DGspIZHK[0]
			CFevtSjzbpn = ePhmG1jLD6.findall('href="(.*?)"',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
			if len(CFevtSjzbpn)>2:
				MepIvHBYNArkUOdV37shtJ = CFevtSjzbpn[2]+'list'
				c8U1BdtxOZS5FH(MepIvHBYNArkUOdV37shtJ)
	return
def mzcAeyplZV(url):
	IAW0sh6So3NpqM = WWrExJZS3Bj4anOAkpv7(KOyPvpEztYLaZRdMQJWxfTNFHbkg,'GET',url,qpFY4hAwolV3,headers,qpFY4hAwolV3,qpFY4hAwolV3,'SHAHID4U-PLAY-1st')
	cmWl9dOKHPIy41iaXuxrY = IAW0sh6So3NpqM.content
	pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('class="actions(.*?)</div>',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	if not pfRkcVlLmUxo561g0A8qSbO: return
	mVYdjvor6i4wZ8 = pfRkcVlLmUxo561g0A8qSbO[0]
	CFevtSjzbpn = ePhmG1jLD6.findall('href="(.*?)"',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
	VRnzgj0bQ4k7WeZtGFrB9mANidcv1a = '/watch/' in mVYdjvor6i4wZ8
	download = '/download/' in mVYdjvor6i4wZ8
	if   VRnzgj0bQ4k7WeZtGFrB9mANidcv1a and not download: n6HherzoNy84uV,c1QSXTU8ntIz6FK4xrE = CFevtSjzbpn[0],qpFY4hAwolV3
	elif not VRnzgj0bQ4k7WeZtGFrB9mANidcv1a and download: n6HherzoNy84uV,c1QSXTU8ntIz6FK4xrE = qpFY4hAwolV3,CFevtSjzbpn[0]
	elif VRnzgj0bQ4k7WeZtGFrB9mANidcv1a and download: n6HherzoNy84uV,c1QSXTU8ntIz6FK4xrE = CFevtSjzbpn[0],CFevtSjzbpn[1]
	else: n6HherzoNy84uV,c1QSXTU8ntIz6FK4xrE = qpFY4hAwolV3,qpFY4hAwolV3
	U7V0BQZPxXqMbyJnRw6f = []
	if VRnzgj0bQ4k7WeZtGFrB9mANidcv1a:
		IAW0sh6So3NpqM = WWrExJZS3Bj4anOAkpv7(KOyPvpEztYLaZRdMQJWxfTNFHbkg,'GET',n6HherzoNy84uV,qpFY4hAwolV3,headers,qpFY4hAwolV3,qpFY4hAwolV3,'SHAHID4U-PLAY-2nd')
		CC8IKXmYeo = IAW0sh6So3NpqM.content
		T9TAc28ayKvFgjfd6SD = ePhmG1jLD6.findall('let servers(.*?)player',CC8IKXmYeo,ePhmG1jLD6.DOTALL|ePhmG1jLD6.IGNORECASE)
		if T9TAc28ayKvFgjfd6SD:
			WqdHmfQpP0ITnjJOAbDR6u8t7EiU = T9TAc28ayKvFgjfd6SD[0]
			eKEo1iY0x8kAcU76ChWaypzHIwlRMq = ePhmG1jLD6.findall('"name":"(.*?)".*?"url":"(.*?)"',WqdHmfQpP0ITnjJOAbDR6u8t7EiU,ePhmG1jLD6.DOTALL)
			for title,MepIvHBYNArkUOdV37shtJ in eKEo1iY0x8kAcU76ChWaypzHIwlRMq:
				MepIvHBYNArkUOdV37shtJ = MepIvHBYNArkUOdV37shtJ.replace('\\/',ShynO8pN9idCE3)
				MepIvHBYNArkUOdV37shtJ = MepIvHBYNArkUOdV37shtJ+'?named='+title+'__watch'
				U7V0BQZPxXqMbyJnRw6f.append(MepIvHBYNArkUOdV37shtJ)
	if download:
		IAW0sh6So3NpqM = WWrExJZS3Bj4anOAkpv7(KOyPvpEztYLaZRdMQJWxfTNFHbkg,'GET',c1QSXTU8ntIz6FK4xrE,qpFY4hAwolV3,headers,qpFY4hAwolV3,qpFY4hAwolV3,'SHAHID4U-PLAY-3rd')
		CC8IKXmYeo = IAW0sh6So3NpqM.content
		T9TAc28ayKvFgjfd6SD = ePhmG1jLD6.findall('"servers"(.*?)info-container',CC8IKXmYeo,ePhmG1jLD6.DOTALL)
		if T9TAc28ayKvFgjfd6SD:
			WqdHmfQpP0ITnjJOAbDR6u8t7EiU = T9TAc28ayKvFgjfd6SD[0]
			eKEo1iY0x8kAcU76ChWaypzHIwlRMq = ePhmG1jLD6.findall('href="(.*?)".*?<span>(.*?)<.*?</i>.*?<span>(.*?)<',WqdHmfQpP0ITnjJOAbDR6u8t7EiU,ePhmG1jLD6.DOTALL)
			for MepIvHBYNArkUOdV37shtJ,title,Mrp5ZdGHFv9Xi6mkxfac3JDB in eKEo1iY0x8kAcU76ChWaypzHIwlRMq:
				MepIvHBYNArkUOdV37shtJ = MepIvHBYNArkUOdV37shtJ+'?named='+title+'__download'+'____'+Mrp5ZdGHFv9Xi6mkxfac3JDB
				U7V0BQZPxXqMbyJnRw6f.append(MepIvHBYNArkUOdV37shtJ)
	import inVXFK46ET
	inVXFK46ET.q4qTJvuoQUzM3mZAtegy7IXdnb5wH(U7V0BQZPxXqMbyJnRw6f,Q8Q0IDc6PLZajJAdTntKUmSGXz,'video',url)
	return
def PPqUACSE3VcGLTvw05jHy9JrFNW(search):
	search,LBylNhMdH6OV1qGk0tWiXFg3,showDialogs = LLm3sBXHPcnTDxdE5gt6hz0Wkp(search)
	if not search:
		search = jXgARlWMLVFUBnvmZwI2o5()
		if not search: return
	search = search.replace(mIsDke0oK5x1zSiOWbF9thGcA,'+')
	url = ddBxj51bhNtaK23lDyGMVw+'/search?s='+search
	c8U1BdtxOZS5FH(url,'search')
	return
def ZcGxoMbewJAYq1sSlV0(url):
	url = url.split('/smartemadfilter?')[0]
	IAW0sh6So3NpqM = WWrExJZS3Bj4anOAkpv7(KOyPvpEztYLaZRdMQJWxfTNFHbkg,'GET',url,qpFY4hAwolV3,headers,qpFY4hAwolV3,qpFY4hAwolV3,'SHAHID4U-GET_FILTERS_BLOCKS-1st')
	cmWl9dOKHPIy41iaXuxrY = IAW0sh6So3NpqM.content
	YF4LRjr6TuagQk9o3PiMeIcHx = []
	pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('adv-filter(.*?)shows-container',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	if pfRkcVlLmUxo561g0A8qSbO:
		mVYdjvor6i4wZ8 = pfRkcVlLmUxo561g0A8qSbO[0]
		YF4LRjr6TuagQk9o3PiMeIcHx = ePhmG1jLD6.findall('''updateQuery\('(.*?)'.*?value.*?>(.*?)<(.*?)</select''',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
		LL9IREeCKVltx3NmWcG1O5,Lgk6MQxwDv2zhuns5d108X3oREB,HLVwBWJ6mFa3ApoNlq178nuXgI = zip(*YF4LRjr6TuagQk9o3PiMeIcHx)
		YF4LRjr6TuagQk9o3PiMeIcHx = zip(Lgk6MQxwDv2zhuns5d108X3oREB,LL9IREeCKVltx3NmWcG1O5,HLVwBWJ6mFa3ApoNlq178nuXgI)
	return YF4LRjr6TuagQk9o3PiMeIcHx
def iiNGgPHcqX4tCAdRUz(mVYdjvor6i4wZ8):
	items = ePhmG1jLD6.findall('value="(.*?)".*?>\s*(.*?)\s*<',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
	return items
def HHetQ2EqgIl0LARySMX(url):
	if '/smartemadfilter?' not in url: url = url+'/smartemadfilter?'
	CFNSuRJWb5 = url.split('/smartemadfilter?')[0]
	TIr1DgNEH2jsp8547Fx = AWeJuo2LhZ5xiD8KNSqd9G0rtT74FE(url,'url')
	url = url.replace(CFNSuRJWb5,TIr1DgNEH2jsp8547Fx)
	url = url.replace('/smartemadfilter?','/?')
	return url
ppwy5vRWM3ISY7UOeGkrLgN9Eic = ['quality','year','genre','category']
HpUcI0nODuvPeTSkt = ['category','genre','year']
def R9pWUgVhBGLd2CQb0z(url,filter):
	url = url.split('/smartemadfilter?')[0]
	type,filter = filter.split('___',1)
	if filter==qpFY4hAwolV3: eAYm1EkvcnOzXWpFB68o9rglSQ0M5,M0jc2ZsJHPb1d3DCoyXIzmgt = qpFY4hAwolV3,qpFY4hAwolV3
	else: eAYm1EkvcnOzXWpFB68o9rglSQ0M5,M0jc2ZsJHPb1d3DCoyXIzmgt = filter.split('___')
	if type=='DEFINED_FILTER':
		if HpUcI0nODuvPeTSkt[0]+'=' not in eAYm1EkvcnOzXWpFB68o9rglSQ0M5: n1uwH0oJaGZ5WBd = HpUcI0nODuvPeTSkt[0]
		for a2jQ83ZCfcM5 in range(len(HpUcI0nODuvPeTSkt[0:-1])):
			if HpUcI0nODuvPeTSkt[a2jQ83ZCfcM5]+'=' in eAYm1EkvcnOzXWpFB68o9rglSQ0M5: n1uwH0oJaGZ5WBd = HpUcI0nODuvPeTSkt[a2jQ83ZCfcM5+1]
		OI4ExuWvaLU = eAYm1EkvcnOzXWpFB68o9rglSQ0M5+'&'+n1uwH0oJaGZ5WBd+'=0'
		vmTWLw30V2PFNC8DrRqI = M0jc2ZsJHPb1d3DCoyXIzmgt+'&'+n1uwH0oJaGZ5WBd+'=0'
		nxGqbf39mXPhwl1NtAsSYK = OI4ExuWvaLU.strip('&')+'___'+vmTWLw30V2PFNC8DrRqI.strip('&')
		ekvC3tHRVnZGM4uDsmE2pBc5x = ZX8DyBJbV4lNAG(M0jc2ZsJHPb1d3DCoyXIzmgt,'modified_filters')
		WSQlG8mDhqsNe = url+'/smartemadfilter?'+ekvC3tHRVnZGM4uDsmE2pBc5x
	elif type=='FULL_FILTER':
		Q7PrOdIzEeXgpT4HL38GK = ZX8DyBJbV4lNAG(eAYm1EkvcnOzXWpFB68o9rglSQ0M5,'modified_values')
		Q7PrOdIzEeXgpT4HL38GK = cTt4u6reEMKZqVLplmkNW7(Q7PrOdIzEeXgpT4HL38GK)
		if M0jc2ZsJHPb1d3DCoyXIzmgt!=qpFY4hAwolV3: M0jc2ZsJHPb1d3DCoyXIzmgt = ZX8DyBJbV4lNAG(M0jc2ZsJHPb1d3DCoyXIzmgt,'modified_filters')
		if M0jc2ZsJHPb1d3DCoyXIzmgt==qpFY4hAwolV3: WSQlG8mDhqsNe = url
		else: WSQlG8mDhqsNe = url+'/smartemadfilter?'+M0jc2ZsJHPb1d3DCoyXIzmgt
		hhpztscnBD1GP = HHetQ2EqgIl0LARySMX(WSQlG8mDhqsNe)
		x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+'أظهار قائمة الفيديو التي تم اختيارها ',hhpztscnBD1GP,111)
		x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+' [[   '+Q7PrOdIzEeXgpT4HL38GK+'   ]]',hhpztscnBD1GP,111)
		x3WSXnKyPhjqfHG2UrtQs('link',xupTj02bvy3O8R+' ===== ===== ===== '+fF4lt9zWYxXLKZVyAco82PgMj,qpFY4hAwolV3,9999)
	YF4LRjr6TuagQk9o3PiMeIcHx = ZcGxoMbewJAYq1sSlV0(url)
	dict = {}
	for name,CQlVpYyFN6bzXRBZIMxPWdn,mVYdjvor6i4wZ8 in YF4LRjr6TuagQk9o3PiMeIcHx:
		name = name.replace('كل ',qpFY4hAwolV3)
		items = iiNGgPHcqX4tCAdRUz(mVYdjvor6i4wZ8)
		if '=' not in WSQlG8mDhqsNe: WSQlG8mDhqsNe = url
		if type=='DEFINED_FILTER':
			if n1uwH0oJaGZ5WBd!=CQlVpYyFN6bzXRBZIMxPWdn: continue
			elif len(items)<2:
				if CQlVpYyFN6bzXRBZIMxPWdn==HpUcI0nODuvPeTSkt[-1]:
					hhpztscnBD1GP = HHetQ2EqgIl0LARySMX(WSQlG8mDhqsNe)
					c8U1BdtxOZS5FH(hhpztscnBD1GP)
				else: R9pWUgVhBGLd2CQb0z(WSQlG8mDhqsNe,'DEFINED_FILTER___'+nxGqbf39mXPhwl1NtAsSYK)
				return
			else:
				if CQlVpYyFN6bzXRBZIMxPWdn==HpUcI0nODuvPeTSkt[-1]:
					hhpztscnBD1GP = HHetQ2EqgIl0LARySMX(WSQlG8mDhqsNe)
					x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+'الجميع',hhpztscnBD1GP,111)
				else: x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+'الجميع',WSQlG8mDhqsNe,115,qpFY4hAwolV3,qpFY4hAwolV3,nxGqbf39mXPhwl1NtAsSYK)
		elif type=='FULL_FILTER':
			OI4ExuWvaLU = eAYm1EkvcnOzXWpFB68o9rglSQ0M5+'&'+CQlVpYyFN6bzXRBZIMxPWdn+'=0'
			vmTWLw30V2PFNC8DrRqI = M0jc2ZsJHPb1d3DCoyXIzmgt+'&'+CQlVpYyFN6bzXRBZIMxPWdn+'=0'
			nxGqbf39mXPhwl1NtAsSYK = OI4ExuWvaLU+'___'+vmTWLw30V2PFNC8DrRqI
			x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+'الجميع :'+name,WSQlG8mDhqsNe,114,qpFY4hAwolV3,qpFY4hAwolV3,nxGqbf39mXPhwl1NtAsSYK)
		dict[CQlVpYyFN6bzXRBZIMxPWdn] = {}
		for value,FLkeT4nCDqrQMmW6ZSlgyU5jIO32 in items:
			if value=='196533': FLkeT4nCDqrQMmW6ZSlgyU5jIO32 = 'أفلام نيتفلكس'
			elif value=='196531': FLkeT4nCDqrQMmW6ZSlgyU5jIO32 = 'مسلسلات نيتفلكس'
			if FLkeT4nCDqrQMmW6ZSlgyU5jIO32 in YEIA19ehBwpNfPVzK: continue
			dict[CQlVpYyFN6bzXRBZIMxPWdn][value] = FLkeT4nCDqrQMmW6ZSlgyU5jIO32
			OI4ExuWvaLU = eAYm1EkvcnOzXWpFB68o9rglSQ0M5+'&'+CQlVpYyFN6bzXRBZIMxPWdn+'='+FLkeT4nCDqrQMmW6ZSlgyU5jIO32
			vmTWLw30V2PFNC8DrRqI = M0jc2ZsJHPb1d3DCoyXIzmgt+'&'+CQlVpYyFN6bzXRBZIMxPWdn+'='+value
			lJWPN5EDIbft92m6iCQqAYLjav4p = OI4ExuWvaLU+'___'+vmTWLw30V2PFNC8DrRqI
			title = FLkeT4nCDqrQMmW6ZSlgyU5jIO32+' :'#+dict[CQlVpYyFN6bzXRBZIMxPWdn]['0']
			title = FLkeT4nCDqrQMmW6ZSlgyU5jIO32+' :'+name
			if type=='FULL_FILTER': x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+title,url,114,qpFY4hAwolV3,qpFY4hAwolV3,lJWPN5EDIbft92m6iCQqAYLjav4p)
			elif type=='DEFINED_FILTER' and HpUcI0nODuvPeTSkt[-2]+'=' in eAYm1EkvcnOzXWpFB68o9rglSQ0M5:
				ekvC3tHRVnZGM4uDsmE2pBc5x = ZX8DyBJbV4lNAG(vmTWLw30V2PFNC8DrRqI,'modified_filters')
				WSQlG8mDhqsNe = url+'/smartemadfilter?'+ekvC3tHRVnZGM4uDsmE2pBc5x
				hhpztscnBD1GP = HHetQ2EqgIl0LARySMX(WSQlG8mDhqsNe)
				x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+title,hhpztscnBD1GP,111)
			else: x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+title,url,115,qpFY4hAwolV3,qpFY4hAwolV3,lJWPN5EDIbft92m6iCQqAYLjav4p)
	return
def ZX8DyBJbV4lNAG(bbaYxjcVnksy,mode):
	bbaYxjcVnksy = bbaYxjcVnksy.replace('=&','=0&')
	bbaYxjcVnksy = bbaYxjcVnksy.strip('&')
	J9ASCRhfiDyTB = {}
	if '=' in bbaYxjcVnksy:
		items = bbaYxjcVnksy.split('&')
		for lkd2oKvZF03qmgMbIfQ6cD in items:
			JJAsQ4pRYXPhqugN2to9TEzLIS,value = lkd2oKvZF03qmgMbIfQ6cD.split('=')
			J9ASCRhfiDyTB[JJAsQ4pRYXPhqugN2to9TEzLIS] = value
	LxOIqpMU7E1hPKH5fSzj2iW9v = qpFY4hAwolV3
	for key in ppwy5vRWM3ISY7UOeGkrLgN9Eic:
		if key in list(J9ASCRhfiDyTB.keys()): value = J9ASCRhfiDyTB[key]
		else: value = '0'
		if '%' not in value: value = BUKlErdIu7Ggqcz3jYpf09wMePF4V(value)
		if mode=='modified_values' and value!='0': LxOIqpMU7E1hPKH5fSzj2iW9v = LxOIqpMU7E1hPKH5fSzj2iW9v+' + '+value
		elif mode=='modified_filters' and value!='0': LxOIqpMU7E1hPKH5fSzj2iW9v = LxOIqpMU7E1hPKH5fSzj2iW9v+'&'+key+'='+value
		elif mode=='all': LxOIqpMU7E1hPKH5fSzj2iW9v = LxOIqpMU7E1hPKH5fSzj2iW9v+'&'+key+'='+value
	LxOIqpMU7E1hPKH5fSzj2iW9v = LxOIqpMU7E1hPKH5fSzj2iW9v.strip(' + ')
	LxOIqpMU7E1hPKH5fSzj2iW9v = LxOIqpMU7E1hPKH5fSzj2iW9v.strip('&')
	LxOIqpMU7E1hPKH5fSzj2iW9v = LxOIqpMU7E1hPKH5fSzj2iW9v.replace('=0','=')
	return LxOIqpMU7E1hPKH5fSzj2iW9v