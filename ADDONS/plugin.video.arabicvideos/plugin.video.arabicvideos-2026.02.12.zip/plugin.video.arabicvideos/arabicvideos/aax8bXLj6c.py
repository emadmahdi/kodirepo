# -*- coding: utf-8 -*-
from pSfaryIjBo import *
Q8Q0IDc6PLZajJAdTntKUmSGXz = 'KATKOTTV'
wwSFijdVJn1QgHW = '_KTV_'
ddBxj51bhNtaK23lDyGMVw = i4bFG3rKE6.SITESURLS[Q8Q0IDc6PLZajJAdTntKUmSGXz][0]
YEIA19ehBwpNfPVzK = []
def vTNE2Ck1sGnugJYW8y39aLcSH64U(mode,url,text):
	if   mode==810: MOTjA5H9XFs = nRVAZc4Dp8PSrGU3xBk()
	elif mode==811: MOTjA5H9XFs = c8U1BdtxOZS5FH(url,text)
	elif mode==812: MOTjA5H9XFs = mzcAeyplZV(url)
	elif mode==813: MOTjA5H9XFs = A8s6orYkjplw(url)
	elif mode==819: MOTjA5H9XFs = PPqUACSE3VcGLTvw05jHy9JrFNW(text)
	else: MOTjA5H9XFs = False
	return MOTjA5H9XFs
def nRVAZc4Dp8PSrGU3xBk():
	IAW0sh6So3NpqM = WWrExJZS3Bj4anOAkpv7(kUz8c7OqsxuPFIGfwg,'GET',ddBxj51bhNtaK23lDyGMVw,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,'KATKOTTV-MENU-1st')
	cmWl9dOKHPIy41iaXuxrY = IAW0sh6So3NpqM.content
	x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+'بحث في الموقع',qpFY4hAwolV3,819,qpFY4hAwolV3,qpFY4hAwolV3,'_REMEMBERRESULTS_')
	x3WSXnKyPhjqfHG2UrtQs('link',xupTj02bvy3O8R+' ===== ===== ===== '+fF4lt9zWYxXLKZVyAco82PgMj,qpFY4hAwolV3,9999)
	pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('"primary-links"(.*?)"most-viewed"',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	mVYdjvor6i4wZ8 = pfRkcVlLmUxo561g0A8qSbO[0]
	items = ePhmG1jLD6.findall('href="(.*?)".*?<span>(.*?)<',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
	for MepIvHBYNArkUOdV37shtJ,title in items:
		if title in YEIA19ehBwpNfPVzK: continue
		x3WSXnKyPhjqfHG2UrtQs('folder',Q8Q0IDc6PLZajJAdTntKUmSGXz+'_SCRIPT_'+wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,811)
	return
def c8U1BdtxOZS5FH(url,type=qpFY4hAwolV3):
	IAW0sh6So3NpqM = WWrExJZS3Bj4anOAkpv7(kUz8c7OqsxuPFIGfwg,'GET',url,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,'KATKOTTV-TITLES-1st')
	cmWl9dOKHPIy41iaXuxrY = IAW0sh6So3NpqM.content
	pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('"home-content"(.*?)"footer"',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	if pfRkcVlLmUxo561g0A8qSbO:
		mVYdjvor6i4wZ8 = pfRkcVlLmUxo561g0A8qSbO[0]
		items = ePhmG1jLD6.findall('"thumb".*?data-src="(.*?)".*?href="(.*?)".*?title="(.*?)"',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
		aaCNAJdtsguSRELh2I = []
		for Sj7rMNYRuQPTtkBvpHKeDW3h,MepIvHBYNArkUOdV37shtJ,title in items:
			title = j8PDV0pthfSTidZbsQxNIOmCYKWzH(title)
			ZDTxRSMbW7PNz = ePhmG1jLD6.findall('(.*?) (الحلقة|حلقة).\d+',title,ePhmG1jLD6.DOTALL)
			if 'episodes' not in type and ZDTxRSMbW7PNz:
				title = '_MOD_' + ZDTxRSMbW7PNz[0][0]
				title = title.replace('اون لاين',qpFY4hAwolV3)
				if title not in aaCNAJdtsguSRELh2I:
					x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,813,Sj7rMNYRuQPTtkBvpHKeDW3h)
					aaCNAJdtsguSRELh2I.append(title)
			else: x3WSXnKyPhjqfHG2UrtQs('video',wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,812,Sj7rMNYRuQPTtkBvpHKeDW3h)
	pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall("'pagination'(.*?)footer",cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	if pfRkcVlLmUxo561g0A8qSbO:
		type = 'episodes_pages' if 'episodes' in type else 'pages'
		mVYdjvor6i4wZ8 = pfRkcVlLmUxo561g0A8qSbO[0]
		items = ePhmG1jLD6.findall('href="(.*?)">(.*?)</a>',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
		for MepIvHBYNArkUOdV37shtJ,title in items:
			title = j8PDV0pthfSTidZbsQxNIOmCYKWzH(title)
			x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+'صفحة '+title,MepIvHBYNArkUOdV37shtJ,811,qpFY4hAwolV3,qpFY4hAwolV3,type)
	return
def A8s6orYkjplw(url):
	IAW0sh6So3NpqM = WWrExJZS3Bj4anOAkpv7(kUz8c7OqsxuPFIGfwg,'GET',url,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,'KATKOTTV-SERIES-1st')
	cmWl9dOKHPIy41iaXuxrY = IAW0sh6So3NpqM.content
	MepIvHBYNArkUOdV37shtJ = ePhmG1jLD6.findall('"category".*?href="(.*?)"',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	if MepIvHBYNArkUOdV37shtJ: c8U1BdtxOZS5FH(MepIvHBYNArkUOdV37shtJ[0],'episodes')
	return
def mzcAeyplZV(url):
	tiYp9ZdbFTQMcB4vWkHw6LXIAKrN5m = []
	WSQlG8mDhqsNe = url+'?do=watch'
	IAW0sh6So3NpqM = WWrExJZS3Bj4anOAkpv7(kUz8c7OqsxuPFIGfwg,'GET',WSQlG8mDhqsNe,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,'KATKOTTV-PLAY-1st')
	cmWl9dOKHPIy41iaXuxrY = IAW0sh6So3NpqM.content
	MepIvHBYNArkUOdV37shtJ = ePhmG1jLD6.findall('" src="(.*?)"',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	if MepIvHBYNArkUOdV37shtJ:
		MepIvHBYNArkUOdV37shtJ = MepIvHBYNArkUOdV37shtJ[0]
		tiYp9ZdbFTQMcB4vWkHw6LXIAKrN5m.append(MepIvHBYNArkUOdV37shtJ)
	else:
		IAW0sh6So3NpqM = WWrExJZS3Bj4anOAkpv7(kUz8c7OqsxuPFIGfwg,'GET',url,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,'KATKOTTV-PLAY-2nd')
		cmWl9dOKHPIy41iaXuxrY = IAW0sh6So3NpqM.content
		xfBMzb7ZqP2k = ePhmG1jLD6.findall('post=(.*?)"',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
		if xfBMzb7ZqP2k:
			xfBMzb7ZqP2k = PP0Gxazjw86.b64decode(xfBMzb7ZqP2k[0])
			if DLod2Of8CkRrtzJynev: xfBMzb7ZqP2k = xfBMzb7ZqP2k.decode(nV3Tip6XsH1rJw79DPOU)
			xfBMzb7ZqP2k = wB8NUAidPbqjIr9CFasXvYnxOQpL0g('dict',xfBMzb7ZqP2k)
			CFevtSjzbpn = xfBMzb7ZqP2k['servers']
			EmejzBHJ28TqtDAZ74NUhF = list(CFevtSjzbpn.keys())
			CFevtSjzbpn = list(CFevtSjzbpn.values())
			G1EWNzkMOm35C = zip(EmejzBHJ28TqtDAZ74NUhF,CFevtSjzbpn)
			for title,MepIvHBYNArkUOdV37shtJ in G1EWNzkMOm35C:
				MepIvHBYNArkUOdV37shtJ = MepIvHBYNArkUOdV37shtJ+'?named='+title+'__watch'
				tiYp9ZdbFTQMcB4vWkHw6LXIAKrN5m.append(MepIvHBYNArkUOdV37shtJ)
	import inVXFK46ET
	inVXFK46ET.q4qTJvuoQUzM3mZAtegy7IXdnb5wH(tiYp9ZdbFTQMcB4vWkHw6LXIAKrN5m,Q8Q0IDc6PLZajJAdTntKUmSGXz,'video',url)
	return
def PPqUACSE3VcGLTvw05jHy9JrFNW(search):
	search,LBylNhMdH6OV1qGk0tWiXFg3,showDialogs = LLm3sBXHPcnTDxdE5gt6hz0Wkp(search)
	if search==qpFY4hAwolV3: search = jXgARlWMLVFUBnvmZwI2o5()
	if search==qpFY4hAwolV3: return
	search = search.replace(mIsDke0oK5x1zSiOWbF9thGcA,'+')
	url = ddBxj51bhNtaK23lDyGMVw+'/?s='+search
	c8U1BdtxOZS5FH(url,'search')
	return