# -*- coding: utf-8 -*-
from pSfaryIjBo import *
Q8Q0IDc6PLZajJAdTntKUmSGXz = 'AYLOL'
wwSFijdVJn1QgHW = '_AYL_'
ddBxj51bhNtaK23lDyGMVw = i4bFG3rKE6.SITESURLS[Q8Q0IDc6PLZajJAdTntKUmSGXz][0]
YEIA19ehBwpNfPVzK = ['الصفحة الرئيسية','Sign in','تسجيل','افلام للكبار فقط','عرض المزيد','تسجيل الدخول']
headers = {'Referer':ddBxj51bhNtaK23lDyGMVw}
def vTNE2Ck1sGnugJYW8y39aLcSH64U(mode,url,text):
	if   mode==1050: MOTjA5H9XFs = nRVAZc4Dp8PSrGU3xBk()
	elif mode==1051: MOTjA5H9XFs = c8U1BdtxOZS5FH(url,text)
	elif mode==1052: MOTjA5H9XFs = mzcAeyplZV(url)
	elif mode==1053: MOTjA5H9XFs = PXEsuKvq5fS438YWFh7gBCdrw(url,text)
	elif mode==1054: MOTjA5H9XFs = X2rO3lubqIdCGMLYWcxA6DK5(url)
	elif mode==1059: MOTjA5H9XFs = PPqUACSE3VcGLTvw05jHy9JrFNW(text)
	else: MOTjA5H9XFs = False
	return MOTjA5H9XFs
def nRVAZc4Dp8PSrGU3xBk():
	IAW0sh6So3NpqM = WWrExJZS3Bj4anOAkpv7(kUz8c7OqsxuPFIGfwg,'GET',ddBxj51bhNtaK23lDyGMVw,qpFY4hAwolV3,headers,qpFY4hAwolV3,qpFY4hAwolV3,'AYLOL-MENU-1st')
	cmWl9dOKHPIy41iaXuxrY = IAW0sh6So3NpqM.content
	x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+'بحث في الموقع',qpFY4hAwolV3,1059,qpFY4hAwolV3,qpFY4hAwolV3,'_REMEMBERRESULTS_')
	x3WSXnKyPhjqfHG2UrtQs('link',xupTj02bvy3O8R+' ===== ===== ===== '+fF4lt9zWYxXLKZVyAco82PgMj,qpFY4hAwolV3,9999)
	x3WSXnKyPhjqfHG2UrtQs('folder',Q8Q0IDc6PLZajJAdTntKUmSGXz+'_SCRIPT_'+wwSFijdVJn1QgHW+'مميز',ddBxj51bhNtaK23lDyGMVw,1051,qpFY4hAwolV3,qpFY4hAwolV3,'featured')
	pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('''["']navslide-wrap["'](.*?)</ul>''',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	if pfRkcVlLmUxo561g0A8qSbO:
		mVYdjvor6i4wZ8 = pfRkcVlLmUxo561g0A8qSbO[0]
		items = ePhmG1jLD6.findall('href="(.*?)".*?</i>(.*?)</a>',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
		for MepIvHBYNArkUOdV37shtJ,title in items:
			if title in YEIA19ehBwpNfPVzK: continue
			x3WSXnKyPhjqfHG2UrtQs('folder',Q8Q0IDc6PLZajJAdTntKUmSGXz+'_SCRIPT_'+wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,1054)
	pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('/category.php">(.*?)"navslide-divider"',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	mVYdjvor6i4wZ8 = pfRkcVlLmUxo561g0A8qSbO[0]
	pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('list-unstyled(.*?)navslide-divider',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
	for WqdHmfQpP0ITnjJOAbDR6u8t7EiU in pfRkcVlLmUxo561g0A8qSbO: mVYdjvor6i4wZ8 = mVYdjvor6i4wZ8.replace(WqdHmfQpP0ITnjJOAbDR6u8t7EiU,qpFY4hAwolV3)
	items = ePhmG1jLD6.findall('href="(.*?)".*?>(.+?)<',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
	for MepIvHBYNArkUOdV37shtJ,title in items:
		if title in YEIA19ehBwpNfPVzK: continue
		title = title.replace('<b>','').strip(' ')
		x3WSXnKyPhjqfHG2UrtQs('folder',Q8Q0IDc6PLZajJAdTntKUmSGXz+'_SCRIPT_'+wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,1054)
	return
def X2rO3lubqIdCGMLYWcxA6DK5(url):
	G8jrIS0cxzOJlk,eKEo1iY0x8kAcU76ChWaypzHIwlRMq = [],[]
	IAW0sh6So3NpqM = WWrExJZS3Bj4anOAkpv7(kUz8c7OqsxuPFIGfwg,'GET',url,qpFY4hAwolV3,headers,qpFY4hAwolV3,qpFY4hAwolV3,'AYLOL-SUBMENU-1st')
	cmWl9dOKHPIy41iaXuxrY = IAW0sh6So3NpqM.content
	NDnI9Qrpt5c8MU = ePhmG1jLD6.findall('"dropdown-menu"(.*?)</ul>',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	if NDnI9Qrpt5c8MU and '.php' in str(NDnI9Qrpt5c8MU):
		mVYdjvor6i4wZ8 = NDnI9Qrpt5c8MU[-1]
		mVYdjvor6i4wZ8 = mVYdjvor6i4wZ8.replace('"presentation"','</ul>')
		pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('"dropdown-header">(.*?)</li>(.*?)</ul>',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
		if not pfRkcVlLmUxo561g0A8qSbO: pfRkcVlLmUxo561g0A8qSbO = [(qpFY4hAwolV3,mVYdjvor6i4wZ8)]
		x3WSXnKyPhjqfHG2UrtQs('link',xupTj02bvy3O8R+' فرز أو فلتر أو ترتيب '+fF4lt9zWYxXLKZVyAco82PgMj,qpFY4hAwolV3,9999)
		for YirSOX5nC0jPyvFTN48sHE1,mVYdjvor6i4wZ8 in pfRkcVlLmUxo561g0A8qSbO:
			G8jrIS0cxzOJlk = ePhmG1jLD6.findall('href="(.*?)".*?>(.*?)</a>',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
			if YirSOX5nC0jPyvFTN48sHE1: YirSOX5nC0jPyvFTN48sHE1 = YirSOX5nC0jPyvFTN48sHE1+': '
			for MepIvHBYNArkUOdV37shtJ,title in G8jrIS0cxzOJlk:
				title = YirSOX5nC0jPyvFTN48sHE1+title
				x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,1051)
	T9TAc28ayKvFgjfd6SD = ePhmG1jLD6.findall('"pm-category-subcats"(.*?)</ul>',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	if T9TAc28ayKvFgjfd6SD:
		mVYdjvor6i4wZ8 = T9TAc28ayKvFgjfd6SD[0]
		eKEo1iY0x8kAcU76ChWaypzHIwlRMq = ePhmG1jLD6.findall('href="(.*?)">(.*?)</a>',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
		if 1 or len(eKEo1iY0x8kAcU76ChWaypzHIwlRMq)<30:
			if G8jrIS0cxzOJlk: x3WSXnKyPhjqfHG2UrtQs('link',xupTj02bvy3O8R+' ===== ===== ===== '+fF4lt9zWYxXLKZVyAco82PgMj,qpFY4hAwolV3,9999)
			for MepIvHBYNArkUOdV37shtJ,title in eKEo1iY0x8kAcU76ChWaypzHIwlRMq:
				if title in YEIA19ehBwpNfPVzK: continue
				x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,1051)
	if not NDnI9Qrpt5c8MU and not T9TAc28ayKvFgjfd6SD: c8U1BdtxOZS5FH(url)
	return
def c8U1BdtxOZS5FH(url,AMbRf4XTpQNvio6J5GELducy0k=qpFY4hAwolV3):
	if AMbRf4XTpQNvio6J5GELducy0k=='ajax-search':
		url,search = url.split('?',1)
		data = 'queryString='+search
		skD7g3FxW4wCa5BR = headers.copy()
		skD7g3FxW4wCa5BR['Content-Type'] = 'application/x-www-form-urlencoded; charset=UTF-8'
		IAW0sh6So3NpqM = WWrExJZS3Bj4anOAkpv7(kUz8c7OqsxuPFIGfwg,'POST',url,data,skD7g3FxW4wCa5BR,qpFY4hAwolV3,qpFY4hAwolV3,'AYLOL-TITLES-1st')
	else:
		IAW0sh6So3NpqM = WWrExJZS3Bj4anOAkpv7(kUz8c7OqsxuPFIGfwg,'GET',url,qpFY4hAwolV3,headers,qpFY4hAwolV3,qpFY4hAwolV3,'AYLOL-TITLES-2nd')
	cmWl9dOKHPIy41iaXuxrY = IAW0sh6So3NpqM.content
	mVYdjvor6i4wZ8,items = qpFY4hAwolV3,[]
	iipsGz2LKq = AWeJuo2LhZ5xiD8KNSqd9G0rtT74FE(url,'url')
	if AMbRf4XTpQNvio6J5GELducy0k=='ajax-search':
		mVYdjvor6i4wZ8 = cmWl9dOKHPIy41iaXuxrY
		eKEo1iY0x8kAcU76ChWaypzHIwlRMq = ePhmG1jLD6.findall('href="(.*?)">(.*?)</a>',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
		for MepIvHBYNArkUOdV37shtJ,title in eKEo1iY0x8kAcU76ChWaypzHIwlRMq: items.append((qpFY4hAwolV3,MepIvHBYNArkUOdV37shtJ,title))
	elif AMbRf4XTpQNvio6J5GELducy0k=='featured':
		pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('carousel_featuredlist(.*?)</ul>',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
		if pfRkcVlLmUxo561g0A8qSbO: mVYdjvor6i4wZ8 = pfRkcVlLmUxo561g0A8qSbO[0]
	elif AMbRf4XTpQNvio6J5GELducy0k=='new_episodes':
		pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('"row pm-ul-browse-videos(.*?)</ul>',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
		if pfRkcVlLmUxo561g0A8qSbO: mVYdjvor6i4wZ8 = pfRkcVlLmUxo561g0A8qSbO[0]
	elif AMbRf4XTpQNvio6J5GELducy0k=='new_movies':
		pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('"row pm-ul-browse-videos(.*?)</ul>',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
		if len(pfRkcVlLmUxo561g0A8qSbO)>1: mVYdjvor6i4wZ8 = pfRkcVlLmUxo561g0A8qSbO[1]
	elif AMbRf4XTpQNvio6J5GELducy0k=='featured_series':
		pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('"home-series-list"(.*?)</div>[\t|\n]*</div>',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
		if pfRkcVlLmUxo561g0A8qSbO: mVYdjvor6i4wZ8 = pfRkcVlLmUxo561g0A8qSbO[0]
	else:
		pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('"pm-grid"(.*?)</ul>',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
		if pfRkcVlLmUxo561g0A8qSbO: mVYdjvor6i4wZ8 = pfRkcVlLmUxo561g0A8qSbO[0]
	if mVYdjvor6i4wZ8 and not items: items = ePhmG1jLD6.findall('"thumbnail.*?<a href="(.*?)" title="(.*?)".*?data-echo="(.*?)"',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
	if not items: return
	aaCNAJdtsguSRELh2I = []
	WGid3I2kFU = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم','مسرحية']
	for MepIvHBYNArkUOdV37shtJ,title,Sj7rMNYRuQPTtkBvpHKeDW3h in items:
		Sj7rMNYRuQPTtkBvpHKeDW3h += '|Referer='+ddBxj51bhNtaK23lDyGMVw
		if 'http' not in MepIvHBYNArkUOdV37shtJ: MepIvHBYNArkUOdV37shtJ = iipsGz2LKq+ShynO8pN9idCE3+MepIvHBYNArkUOdV37shtJ.strip('./')
		title = j8PDV0pthfSTidZbsQxNIOmCYKWzH(title)
		ZDTxRSMbW7PNz = ePhmG1jLD6.findall('(.*?) (الحلقة|حلقة).\d+',title,ePhmG1jLD6.DOTALL)
		if any(value in title for value in WGid3I2kFU):
			x3WSXnKyPhjqfHG2UrtQs('video',wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,1052,Sj7rMNYRuQPTtkBvpHKeDW3h)
		elif AMbRf4XTpQNvio6J5GELducy0k=='new_episodes':
			x3WSXnKyPhjqfHG2UrtQs('video',wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,1052,Sj7rMNYRuQPTtkBvpHKeDW3h)
		elif ZDTxRSMbW7PNz:
			title = '_MOD_' + ZDTxRSMbW7PNz[0][0]
			if title not in aaCNAJdtsguSRELh2I:
				x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,1053,Sj7rMNYRuQPTtkBvpHKeDW3h)
				aaCNAJdtsguSRELh2I.append(title)
		else: x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,1053,Sj7rMNYRuQPTtkBvpHKeDW3h)
	if AMbRf4XTpQNvio6J5GELducy0k not in ['featured']:
		pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('"pagination(.*?)</ul>',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
		if pfRkcVlLmUxo561g0A8qSbO:
			mVYdjvor6i4wZ8 = pfRkcVlLmUxo561g0A8qSbO[0]
			items = ePhmG1jLD6.findall('href="(.*?)".*?>(.*?)</a>',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
			for MepIvHBYNArkUOdV37shtJ,title in items:
				if MepIvHBYNArkUOdV37shtJ=='#': continue
				if 'http' not in MepIvHBYNArkUOdV37shtJ: MepIvHBYNArkUOdV37shtJ = iipsGz2LKq+ShynO8pN9idCE3+MepIvHBYNArkUOdV37shtJ.strip('./')
				title = j8PDV0pthfSTidZbsQxNIOmCYKWzH(title)
				x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+'صفحة '+title,MepIvHBYNArkUOdV37shtJ,1051)
	return
def PXEsuKvq5fS438YWFh7gBCdrw(url,MaNXbtkeElTRsiK6c1u):
	iipsGz2LKq = AWeJuo2LhZ5xiD8KNSqd9G0rtT74FE(url,'url')
	IAW0sh6So3NpqM = WWrExJZS3Bj4anOAkpv7(kUz8c7OqsxuPFIGfwg,'GET',url,qpFY4hAwolV3,headers,qpFY4hAwolV3,qpFY4hAwolV3,'AYLOL-EPISODES_SEASONS-1st')
	cmWl9dOKHPIy41iaXuxrY = IAW0sh6So3NpqM.content
	NDnI9Qrpt5c8MU = ePhmG1jLD6.findall('"SeasonsBox"(.*?)"SeasonsEpisodesMain',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	BvbuigUeoJLnTaN2qWxQ415AtYMK9I = ePhmG1jLD6.findall('pm-poster-img.*?src="(.*?)"',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	Sj7rMNYRuQPTtkBvpHKeDW3h = BvbuigUeoJLnTaN2qWxQ415AtYMK9I[0] if BvbuigUeoJLnTaN2qWxQ415AtYMK9I else qpFY4hAwolV3
	Sj7rMNYRuQPTtkBvpHKeDW3h += '|Referer='+ddBxj51bhNtaK23lDyGMVw
	items = []
	BfsF3ItbJ17Mndmy = False
	if NDnI9Qrpt5c8MU and not MaNXbtkeElTRsiK6c1u:
		mVYdjvor6i4wZ8 = NDnI9Qrpt5c8MU[0]
		items = ePhmG1jLD6.findall('data-serie="(.*?)".*?>(.*?)<',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
		for MaNXbtkeElTRsiK6c1u,title in items:
			MaNXbtkeElTRsiK6c1u = MaNXbtkeElTRsiK6c1u.strip('#')
			x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+title,url,1053,Sj7rMNYRuQPTtkBvpHKeDW3h,qpFY4hAwolV3,MaNXbtkeElTRsiK6c1u)
	else: BfsF3ItbJ17Mndmy = True
	T9TAc28ayKvFgjfd6SD = ePhmG1jLD6.findall('"SeasonsEpisodes"(.*?)</div>',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	if not T9TAc28ayKvFgjfd6SD:
		T9TAc28ayKvFgjfd6SD = ePhmG1jLD6.findall('data-serie="'+MaNXbtkeElTRsiK6c1u+'"(.*?)</ul>',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
		if T9TAc28ayKvFgjfd6SD:
			mVYdjvor6i4wZ8 = T9TAc28ayKvFgjfd6SD[0]
			items = ePhmG1jLD6.findall('href="(.*?)" title="(.*?)"',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
			for MepIvHBYNArkUOdV37shtJ,title in items:
				if 'http' not in MepIvHBYNArkUOdV37shtJ: MepIvHBYNArkUOdV37shtJ = iipsGz2LKq+ShynO8pN9idCE3+MepIvHBYNArkUOdV37shtJ.strip('./')
				title = title.replace('</em><span>',mIsDke0oK5x1zSiOWbF9thGcA)
				x3WSXnKyPhjqfHG2UrtQs('video',wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,1052,Sj7rMNYRuQPTtkBvpHKeDW3h)
	elif T9TAc28ayKvFgjfd6SD and BfsF3ItbJ17Mndmy:
		mVYdjvor6i4wZ8 = T9TAc28ayKvFgjfd6SD[0]
		eKEo1iY0x8kAcU76ChWaypzHIwlRMq = ePhmG1jLD6.findall('''title=['"](.*?)['"].*?href=["'](.*?)["'].*?''',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
		if eKEo1iY0x8kAcU76ChWaypzHIwlRMq:
			qqxG8OasFg2V64DjSmoHJwrvy5LAl,MqeA0lHDmno2swp4WNfuvTX6 = zip(*eKEo1iY0x8kAcU76ChWaypzHIwlRMq)
			uu3NQaExhHIdmWRU0OGDeYfy = [Sj7rMNYRuQPTtkBvpHKeDW3h]*len(eKEo1iY0x8kAcU76ChWaypzHIwlRMq)
			items = zip(MqeA0lHDmno2swp4WNfuvTX6,qqxG8OasFg2V64DjSmoHJwrvy5LAl,uu3NQaExhHIdmWRU0OGDeYfy)
		if not items: items = ePhmG1jLD6.findall('"thumbnail".*?href="(.*?)" title="(.*?)".*?src="(.*?)"',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
		for MepIvHBYNArkUOdV37shtJ,title,Sj7rMNYRuQPTtkBvpHKeDW3h in items:
			Sj7rMNYRuQPTtkBvpHKeDW3h += '|Referer='+ddBxj51bhNtaK23lDyGMVw
			if 'http' not in MepIvHBYNArkUOdV37shtJ: MepIvHBYNArkUOdV37shtJ = iipsGz2LKq+ShynO8pN9idCE3+MepIvHBYNArkUOdV37shtJ.strip('./')
			title = title.replace('</em><span>',mIsDke0oK5x1zSiOWbF9thGcA)
			x3WSXnKyPhjqfHG2UrtQs('video',wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,1052,Sj7rMNYRuQPTtkBvpHKeDW3h)
	return
def mzcAeyplZV(url):
	tiYp9ZdbFTQMcB4vWkHw6LXIAKrN5m,MB4EzZDuWCJ8FnO9jiGNsroX = [],[]
	cmWl9dOKHPIy41iaXuxrY = ''
	if 'post=' in cmWl9dOKHPIy41iaXuxrY:
		MepIvHBYNArkUOdV37shtJ = ePhmG1jLD6.findall('id="player".*?href="(.*?)"',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
		MepIvHBYNArkUOdV37shtJ = MepIvHBYNArkUOdV37shtJ[0]
		xfBMzb7ZqP2k = MepIvHBYNArkUOdV37shtJ.split('post=')[1]
		xfBMzb7ZqP2k = PP0Gxazjw86.b64decode(xfBMzb7ZqP2k)
		if DLod2Of8CkRrtzJynev: xfBMzb7ZqP2k = xfBMzb7ZqP2k.decode(nV3Tip6XsH1rJw79DPOU)
		xfBMzb7ZqP2k = wB8NUAidPbqjIr9CFasXvYnxOQpL0g('dict',xfBMzb7ZqP2k)
		CFevtSjzbpn = xfBMzb7ZqP2k['servers']
		EmejzBHJ28TqtDAZ74NUhF = list(CFevtSjzbpn.keys())
		CFevtSjzbpn = list(CFevtSjzbpn.values())
		G1EWNzkMOm35C = zip(EmejzBHJ28TqtDAZ74NUhF,CFevtSjzbpn)
		for title,MepIvHBYNArkUOdV37shtJ in G1EWNzkMOm35C:
			MepIvHBYNArkUOdV37shtJ = MepIvHBYNArkUOdV37shtJ+'?named='+title+'__watch'
			tiYp9ZdbFTQMcB4vWkHw6LXIAKrN5m.append(MepIvHBYNArkUOdV37shtJ)
	else:
		WSQlG8mDhqsNe = url.replace('watch.php','view.php')
		IAW0sh6So3NpqM = WWrExJZS3Bj4anOAkpv7(kUz8c7OqsxuPFIGfwg,'GET',WSQlG8mDhqsNe,qpFY4hAwolV3,headers,qpFY4hAwolV3,qpFY4hAwolV3,'AYLOL-PLAY-1st')
		cmWl9dOKHPIy41iaXuxrY = IAW0sh6So3NpqM.content
		MepIvHBYNArkUOdV37shtJ = ePhmG1jLD6.findall('iframe src="(.*?)"',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
		if MepIvHBYNArkUOdV37shtJ:
			MepIvHBYNArkUOdV37shtJ = MepIvHBYNArkUOdV37shtJ[0]
			if MepIvHBYNArkUOdV37shtJ not in MB4EzZDuWCJ8FnO9jiGNsroX:
				MB4EzZDuWCJ8FnO9jiGNsroX.append(MepIvHBYNArkUOdV37shtJ)
				XPNkVcWFUr = AWeJuo2LhZ5xiD8KNSqd9G0rtT74FE(MepIvHBYNArkUOdV37shtJ,'name')
				MepIvHBYNArkUOdV37shtJ = MepIvHBYNArkUOdV37shtJ+'?named='+XPNkVcWFUr+'__embed'
				tiYp9ZdbFTQMcB4vWkHw6LXIAKrN5m.append(MepIvHBYNArkUOdV37shtJ)
		pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('"WatchServers"(.*?)</div>',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
		if pfRkcVlLmUxo561g0A8qSbO:
			mVYdjvor6i4wZ8 = pfRkcVlLmUxo561g0A8qSbO[0]
			items = ePhmG1jLD6.findall('''data-embed=['"](.*?)['"].*?</span>(.*?)<''',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
			for MepIvHBYNArkUOdV37shtJ,title in items:
				if MepIvHBYNArkUOdV37shtJ in MB4EzZDuWCJ8FnO9jiGNsroX: continue
				MB4EzZDuWCJ8FnO9jiGNsroX.append(MepIvHBYNArkUOdV37shtJ)
				XPNkVcWFUr = AWeJuo2LhZ5xiD8KNSqd9G0rtT74FE(MepIvHBYNArkUOdV37shtJ,'name')
				MepIvHBYNArkUOdV37shtJ = MepIvHBYNArkUOdV37shtJ+'?named='+XPNkVcWFUr+'__watch'
				tiYp9ZdbFTQMcB4vWkHw6LXIAKrN5m.append(MepIvHBYNArkUOdV37shtJ)
		if 0:
			WSQlG8mDhqsNe = url.replace('watch.php','download.php')
			IAW0sh6So3NpqM = WWrExJZS3Bj4anOAkpv7(kUz8c7OqsxuPFIGfwg,'GET',WSQlG8mDhqsNe,qpFY4hAwolV3,headers,qpFY4hAwolV3,False,'AYLOL-PLAY-2nd')
			cmWl9dOKHPIy41iaXuxrY = IAW0sh6So3NpqM.content
			pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('"pm-download"(.*?)</ul>',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
			for mVYdjvor6i4wZ8 in pfRkcVlLmUxo561g0A8qSbO:
				items = ePhmG1jLD6.findall('href="(.*?)".*?<strong>(.*?)<',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
				if not items: items = ePhmG1jLD6.findall('href="(.*?)".*?<span>(.*?)<',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
				for MepIvHBYNArkUOdV37shtJ,title in items:
					if MepIvHBYNArkUOdV37shtJ in MB4EzZDuWCJ8FnO9jiGNsroX: continue
					MB4EzZDuWCJ8FnO9jiGNsroX.append(MepIvHBYNArkUOdV37shtJ)
					XPNkVcWFUr = AWeJuo2LhZ5xiD8KNSqd9G0rtT74FE(MepIvHBYNArkUOdV37shtJ,'name')
					MepIvHBYNArkUOdV37shtJ = MepIvHBYNArkUOdV37shtJ+'?named='+XPNkVcWFUr+'__download'
					tiYp9ZdbFTQMcB4vWkHw6LXIAKrN5m.append(MepIvHBYNArkUOdV37shtJ)
	import inVXFK46ET
	inVXFK46ET.q4qTJvuoQUzM3mZAtegy7IXdnb5wH(tiYp9ZdbFTQMcB4vWkHw6LXIAKrN5m,Q8Q0IDc6PLZajJAdTntKUmSGXz,'video',url)
	return
def PPqUACSE3VcGLTvw05jHy9JrFNW(search):
	search,LBylNhMdH6OV1qGk0tWiXFg3,showDialogs = LLm3sBXHPcnTDxdE5gt6hz0Wkp(search)
	if search==qpFY4hAwolV3: search = jXgARlWMLVFUBnvmZwI2o5()
	if search==qpFY4hAwolV3: return
	search = search.replace(mIsDke0oK5x1zSiOWbF9thGcA,'+')
	url = ddBxj51bhNtaK23lDyGMVw+'/search.php?keywords='+search
	c8U1BdtxOZS5FH(url,'search')
	return