# -*- coding: utf-8 -*-
from pSfaryIjBo import *
Q8Q0IDc6PLZajJAdTntKUmSGXz = 'ARABSEED'
headers = {'User-Agent':IyjRtqkmHFBvTCDYwuQNJ0()}
wwSFijdVJn1QgHW = '_ARS_'
ddBxj51bhNtaK23lDyGMVw = i4bFG3rKE6.SITESURLS[Q8Q0IDc6PLZajJAdTntKUmSGXz][0]
YEIA19ehBwpNfPVzK = ['رمضان','الرئيسية','المضاف حديثاً','مصارعه','اعلن معنا – For ads','موبايلات','برامج كمبيوتر','العاب كمبيوتر','اسلاميات','اخرى','اقسام اخري','اشتراكات']
def vTNE2Ck1sGnugJYW8y39aLcSH64U(mode,url,text):
	if   mode==250: MOTjA5H9XFs = nRVAZc4Dp8PSrGU3xBk()
	elif mode==251: MOTjA5H9XFs = c8U1BdtxOZS5FH(url,text)
	elif mode==252: MOTjA5H9XFs = mzcAeyplZV(url)
	elif mode==253: MOTjA5H9XFs = v1gmfxDcRrWKQ(url)
	elif mode==254: MOTjA5H9XFs = R9pWUgVhBGLd2CQb0z(url,'CATEGORIES___'+text)
	elif mode==255: MOTjA5H9XFs = R9pWUgVhBGLd2CQb0z(url,'FILTERS___'+text)
	elif mode==259: MOTjA5H9XFs = PPqUACSE3VcGLTvw05jHy9JrFNW(text)
	else: MOTjA5H9XFs = False
	return MOTjA5H9XFs
def nRVAZc4Dp8PSrGU3xBk():
	IAW0sh6So3NpqM = WWrExJZS3Bj4anOAkpv7(KOyPvpEztYLaZRdMQJWxfTNFHbkg,'GET',ddBxj51bhNtaK23lDyGMVw+'/main',qpFY4hAwolV3,headers,qpFY4hAwolV3,qpFY4hAwolV3,'ARABSEED-MENU-1st')
	cmWl9dOKHPIy41iaXuxrY = IAW0sh6So3NpqM.content
	x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+'بحث في الموقع',qpFY4hAwolV3,259,qpFY4hAwolV3,qpFY4hAwolV3,'_REMEMBERRESULTS_')
	x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+'فلتر محدد',ddBxj51bhNtaK23lDyGMVw+'/category/اخرى',254)
	x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+'فلتر كامل',ddBxj51bhNtaK23lDyGMVw+'/category/اخرى',255)
	x3WSXnKyPhjqfHG2UrtQs('link',xupTj02bvy3O8R+' ===== ===== ===== '+fF4lt9zWYxXLKZVyAco82PgMj,qpFY4hAwolV3,9999)
	x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+'المميزة',ddBxj51bhNtaK23lDyGMVw+'/main',251,qpFY4hAwolV3,qpFY4hAwolV3,'featured_main')
	x3WSXnKyPhjqfHG2UrtQs('folder',Q8Q0IDc6PLZajJAdTntKUmSGXz+'_SCRIPT_'+wwSFijdVJn1QgHW+'احدث الافلام',ddBxj51bhNtaK23lDyGMVw+'/main',251,qpFY4hAwolV3,qpFY4hAwolV3,'new_movies')
	x3WSXnKyPhjqfHG2UrtQs('folder',Q8Q0IDc6PLZajJAdTntKUmSGXz+'_SCRIPT_'+wwSFijdVJn1QgHW+'احدث الحلقات',ddBxj51bhNtaK23lDyGMVw+'/main',251,qpFY4hAwolV3,qpFY4hAwolV3,'new_episodes')
	x3WSXnKyPhjqfHG2UrtQs('link',xupTj02bvy3O8R+' ===== ===== ===== '+fF4lt9zWYxXLKZVyAco82PgMj,qpFY4hAwolV3,9999)
	T9TAc28ayKvFgjfd6SD = ePhmG1jLD6.findall('"menu__bar hide__md"(.*?)</div>',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	WqdHmfQpP0ITnjJOAbDR6u8t7EiU = T9TAc28ayKvFgjfd6SD[vvXoMLlg513]
	eKEo1iY0x8kAcU76ChWaypzHIwlRMq = ePhmG1jLD6.findall('href="(.*?)".*?<span>(.*?)<',WqdHmfQpP0ITnjJOAbDR6u8t7EiU,ePhmG1jLD6.DOTALL)
	for MepIvHBYNArkUOdV37shtJ,title in eKEo1iY0x8kAcU76ChWaypzHIwlRMq:
		if '/category/' not in MepIvHBYNArkUOdV37shtJ: continue
		title = j8PDV0pthfSTidZbsQxNIOmCYKWzH(title)
		if title not in YEIA19ehBwpNfPVzK and title!=qpFY4hAwolV3:
			if 'http' not in MepIvHBYNArkUOdV37shtJ: MepIvHBYNArkUOdV37shtJ = ddBxj51bhNtaK23lDyGMVw+MepIvHBYNArkUOdV37shtJ
			x3WSXnKyPhjqfHG2UrtQs('folder',Q8Q0IDc6PLZajJAdTntKUmSGXz+'_SCRIPT_'+wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,251)
	return cmWl9dOKHPIy41iaXuxrY
def X2rO3lubqIdCGMLYWcxA6DK5(url,type):
	IAW0sh6So3NpqM = WWrExJZS3Bj4anOAkpv7(kUz8c7OqsxuPFIGfwg,'GET',url,qpFY4hAwolV3,headers,qpFY4hAwolV3,qpFY4hAwolV3,'ARABSEED-SUBMENU-1st')
	cmWl9dOKHPIy41iaXuxrY = IAW0sh6So3NpqM.content
	if 'class="SliderInSection' in cmWl9dOKHPIy41iaXuxrY: x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+'الأكثر مشاهدة',url,251,qpFY4hAwolV3,qpFY4hAwolV3,'most')
	if 'class="MainSlides' in cmWl9dOKHPIy41iaXuxrY: x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+'المميزة',url,251,qpFY4hAwolV3,qpFY4hAwolV3,'featured')
	if 'class="LinksList' in cmWl9dOKHPIy41iaXuxrY:
		pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('class="LinksList(.*?)</ul>',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
		if pfRkcVlLmUxo561g0A8qSbO:
			mVYdjvor6i4wZ8 = pfRkcVlLmUxo561g0A8qSbO[0]
			if len(pfRkcVlLmUxo561g0A8qSbO)>1 and type=='new_episodes': mVYdjvor6i4wZ8 = pfRkcVlLmUxo561g0A8qSbO[1]
			items = ePhmG1jLD6.findall('href="(.*?)"(.*?)</a>',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
			for MepIvHBYNArkUOdV37shtJ,title in items:
				UdbGw48M6rCHDRmea5qP91nKI = ePhmG1jLD6.findall('</i>(.*?)<span>(.*?)<',title,ePhmG1jLD6.DOTALL)
				try: Z0JRfngy6coNe8FsCIu2O9tip = UdbGw48M6rCHDRmea5qP91nKI[0][0].replace(ZLwoRpfnCWI7FgEHsz6te39lMVh,qpFY4hAwolV3).strip(mIsDke0oK5x1zSiOWbF9thGcA)
				except: Z0JRfngy6coNe8FsCIu2O9tip = qpFY4hAwolV3
				try: hhsuDxXYlIiQmZqeW = UdbGw48M6rCHDRmea5qP91nKI[0][1].replace(ZLwoRpfnCWI7FgEHsz6te39lMVh,qpFY4hAwolV3).strip(mIsDke0oK5x1zSiOWbF9thGcA)
				except: hhsuDxXYlIiQmZqeW = qpFY4hAwolV3
				UdbGw48M6rCHDRmea5qP91nKI = Z0JRfngy6coNe8FsCIu2O9tip+mIsDke0oK5x1zSiOWbF9thGcA+hhsuDxXYlIiQmZqeW
				if '<strong>' in title:
					R3hSvFlT8O65oLkb7Kyaw4cz9P = ePhmG1jLD6.findall('</i>(.*?)<',title,ePhmG1jLD6.DOTALL)
					if R3hSvFlT8O65oLkb7Kyaw4cz9P: UdbGw48M6rCHDRmea5qP91nKI = R3hSvFlT8O65oLkb7Kyaw4cz9P[0]
				if not UdbGw48M6rCHDRmea5qP91nKI:
					R3hSvFlT8O65oLkb7Kyaw4cz9P = ePhmG1jLD6.findall('alt="(.*?)"',title,ePhmG1jLD6.DOTALL)
					if R3hSvFlT8O65oLkb7Kyaw4cz9P: UdbGw48M6rCHDRmea5qP91nKI = R3hSvFlT8O65oLkb7Kyaw4cz9P[0]
				if UdbGw48M6rCHDRmea5qP91nKI:
					if 'key=' in MepIvHBYNArkUOdV37shtJ: type = MepIvHBYNArkUOdV37shtJ.split('key=')[1]
					else: type = 'newest'
					UdbGw48M6rCHDRmea5qP91nKI = UdbGw48M6rCHDRmea5qP91nKI.strip(mIsDke0oK5x1zSiOWbF9thGcA)
					x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+UdbGw48M6rCHDRmea5qP91nKI,MepIvHBYNArkUOdV37shtJ,251,qpFY4hAwolV3,qpFY4hAwolV3,type)
	return
def c8U1BdtxOZS5FH(url,kJ358BIeXtYvzn):
	SUxNlIGhcy,data,items = 'GET',qpFY4hAwolV3,[]
	if kJ358BIeXtYvzn=='filters':
		if '?' in url:
			qOkwGDgV4ax0jhHN7J2KczQmB,RZ2SwHp6GQvAy = 'POST',{}
			WSQlG8mDhqsNe,bZq83DEzAKGxJk4QaUV7w6WuhCj = url.split('?')
			Mm8BldxpifLUa5s2 = bZq83DEzAKGxJk4QaUV7w6WuhCj.split('&')
			for N3S5LUH7Fwztgu9qshjIfvKn8Txlk1 in Mm8BldxpifLUa5s2:
				key,value = N3S5LUH7Fwztgu9qshjIfvKn8Txlk1.split('=')
				RZ2SwHp6GQvAy[key] = value
			if Mm8BldxpifLUa5s2: SUxNlIGhcy,url,data = qOkwGDgV4ax0jhHN7J2KczQmB,WSQlG8mDhqsNe,RZ2SwHp6GQvAy
	IAW0sh6So3NpqM = WWrExJZS3Bj4anOAkpv7(kUz8c7OqsxuPFIGfwg,SUxNlIGhcy,url,data,headers,qpFY4hAwolV3,qpFY4hAwolV3,'ARABSEED-TITLES-1st')
	cmWl9dOKHPIy41iaXuxrY = IAW0sh6So3NpqM.content
	if kJ358BIeXtYvzn=='filters': pfRkcVlLmUxo561g0A8qSbO = [cmWl9dOKHPIy41iaXuxrY]
	elif 'featured' in kJ358BIeXtYvzn: pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('"swiper-wrapper"(.*?)</section>',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	elif kJ358BIeXtYvzn=='new_movies': pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('<b>احدث الافلام</b>(.*?)</section>',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	elif kJ358BIeXtYvzn=='new_episodes': pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('<b>احدث الحلقات</b>(.*?)</section>',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	elif kJ358BIeXtYvzn=='most': pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('class="SliderInSection(.*?)class="LinksList',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	else: pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('"blocks__section(.*?)"paginate"',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	if 'featured' in kJ358BIeXtYvzn:
		mVYdjvor6i4wZ8 = pfRkcVlLmUxo561g0A8qSbO[0]
	else: mVYdjvor6i4wZ8 = pfRkcVlLmUxo561g0A8qSbO[0]
	items = ePhmG1jLD6.findall('"item__contents.*?href="(.*?)".*? title="(.*?)".*?src="(.*?)"',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
	if not items: items = ePhmG1jLD6.findall('href="(.*?)" title="(.*?)".*?src="(.*?)"',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
	aaCNAJdtsguSRELh2I = []
	for MepIvHBYNArkUOdV37shtJ,title,Sj7rMNYRuQPTtkBvpHKeDW3h in items:
		if 'WWE' in title: continue
		title = j8PDV0pthfSTidZbsQxNIOmCYKWzH(title)
		if 'الحلقة' in title:
			ZDTxRSMbW7PNz = ePhmG1jLD6.findall('(.*?) الحلقة \d+',title,ePhmG1jLD6.DOTALL)
			if ZDTxRSMbW7PNz:
				title = '_MOD_' + ZDTxRSMbW7PNz[0]
				if title not in aaCNAJdtsguSRELh2I:
					aaCNAJdtsguSRELh2I.append(title)
					x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,253,Sj7rMNYRuQPTtkBvpHKeDW3h)
			else: x3WSXnKyPhjqfHG2UrtQs('video',wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,252,Sj7rMNYRuQPTtkBvpHKeDW3h)
		elif '/selary/' in MepIvHBYNArkUOdV37shtJ or 'مسلسل' in title:
			x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,253,Sj7rMNYRuQPTtkBvpHKeDW3h)
		else:
			x3WSXnKyPhjqfHG2UrtQs('video',wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,252,Sj7rMNYRuQPTtkBvpHKeDW3h)
	if not kJ358BIeXtYvzn or kJ358BIeXtYvzn in ['search','filters']:
		pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('"paginate"(.*?)</section>',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
		if pfRkcVlLmUxo561g0A8qSbO:
			mVYdjvor6i4wZ8 = pfRkcVlLmUxo561g0A8qSbO[0]
			items = ePhmG1jLD6.findall('href="(.*?)">(.*?)<',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
			for MepIvHBYNArkUOdV37shtJ,title in items:
				title = j8PDV0pthfSTidZbsQxNIOmCYKWzH(title)
				x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+'صفحة '+title,MepIvHBYNArkUOdV37shtJ,251,qpFY4hAwolV3,qpFY4hAwolV3,kJ358BIeXtYvzn)
	return
def v1gmfxDcRrWKQ(url):
	IAW0sh6So3NpqM = WWrExJZS3Bj4anOAkpv7(kUz8c7OqsxuPFIGfwg,'GET',url,qpFY4hAwolV3,headers,qpFY4hAwolV3,qpFY4hAwolV3,'ARABSEED-EPISODES-1st')
	cmWl9dOKHPIy41iaXuxrY = IAW0sh6So3NpqM.content
	items = ePhmG1jLD6.findall('"poster__single".*?src="(.*?)".*?alt="(.*?)"',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	if not items: return
	Sj7rMNYRuQPTtkBvpHKeDW3h,name = items[0]
	if 'الحلقة' in name: name = name.split('الحلقة')[0].strip(mIsDke0oK5x1zSiOWbF9thGcA)
	elif 'حلقة' in name: name = name.split('حلقة')[0].strip(mIsDke0oK5x1zSiOWbF9thGcA)
	pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('"episodes__list boxs__wrapper(.*?)</ul>',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	if pfRkcVlLmUxo561g0A8qSbO:
		mVYdjvor6i4wZ8 = pfRkcVlLmUxo561g0A8qSbO[0]
		items = ePhmG1jLD6.findall('href="(.*?)".*?"epi__num">.*?<b>(.*?)</b>',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
		for MepIvHBYNArkUOdV37shtJ,ZDTxRSMbW7PNz in items:
			title = name+' - حلقة رقم '+ZDTxRSMbW7PNz
			x3WSXnKyPhjqfHG2UrtQs('video',wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,252,Sj7rMNYRuQPTtkBvpHKeDW3h)
	else: x3WSXnKyPhjqfHG2UrtQs('video',wwSFijdVJn1QgHW+'ملف التشغيل',url,252,Sj7rMNYRuQPTtkBvpHKeDW3h)
	return
def JzeZDPO8VxLY2v5KjpcfuRMtIS7(title,MepIvHBYNArkUOdV37shtJ):
	UdbGw48M6rCHDRmea5qP91nKI = ePhmG1jLD6.findall('[a-zA-Z-]+',title,ePhmG1jLD6.DOTALL)
	if UdbGw48M6rCHDRmea5qP91nKI: title = UdbGw48M6rCHDRmea5qP91nKI[0]
	else: title = title+mIsDke0oK5x1zSiOWbF9thGcA+AWeJuo2LhZ5xiD8KNSqd9G0rtT74FE(MepIvHBYNArkUOdV37shtJ,'name')
	title = title.replace('عرب سيد',qpFY4hAwolV3).replace('مباشر',qpFY4hAwolV3).replace('مشاهدة',qpFY4hAwolV3)
	title = title.replace('ٍ',qpFY4hAwolV3)
	title = title.replace(r1roOXYi7UQw9FLThzPEdD0ZlvAnRc,mIsDke0oK5x1zSiOWbF9thGcA).replace(r1roOXYi7UQw9FLThzPEdD0ZlvAnRc,mIsDke0oK5x1zSiOWbF9thGcA)
	return title
def mzcAeyplZV(url):
	IAW0sh6So3NpqM = WWrExJZS3Bj4anOAkpv7(KOyPvpEztYLaZRdMQJWxfTNFHbkg,'GET',url,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,'ARABSEED-PLAY-1st')
	cmWl9dOKHPIy41iaXuxrY = IAW0sh6So3NpqM.content
	XPNkVcWFUr = AWeJuo2LhZ5xiD8KNSqd9G0rtT74FE(url,'url')
	headers = {'Referer':XPNkVcWFUr}
	tiYp9ZdbFTQMcB4vWkHw6LXIAKrN5m,wGOBvuSfQJn = [],[]
	c1QSXTU8ntIz6FK4xrE = ePhmG1jLD6.findall('href="([^"]*)" class="btton download__btn"',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	if c1QSXTU8ntIz6FK4xrE:
		c1QSXTU8ntIz6FK4xrE = c1QSXTU8ntIz6FK4xrE[0]
		IAW0sh6So3NpqM = WWrExJZS3Bj4anOAkpv7(KOyPvpEztYLaZRdMQJWxfTNFHbkg,'GET',c1QSXTU8ntIz6FK4xrE,qpFY4hAwolV3,headers,qpFY4hAwolV3,qpFY4hAwolV3,'ARABSEED-PLAY-2nd')
		CC8IKXmYeo = IAW0sh6So3NpqM.content
		pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('"tabs__holder(.*?)</section>',CC8IKXmYeo,ePhmG1jLD6.DOTALL)
		if pfRkcVlLmUxo561g0A8qSbO:
			mVYdjvor6i4wZ8 = pfRkcVlLmUxo561g0A8qSbO[0]
			items = ePhmG1jLD6.findall('href="(.*?)".*?<h4>(.*?)</h4>.*?<p>(.*?)</p>',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
			for MepIvHBYNArkUOdV37shtJ,rr1mzIljJHqkx,UdbGw48M6rCHDRmea5qP91nKI in items:
				Mrp5ZdGHFv9Xi6mkxfac3JDB = ePhmG1jLD6.findall('\d+',UdbGw48M6rCHDRmea5qP91nKI,ePhmG1jLD6.DOTALL)
				Mrp5ZdGHFv9Xi6mkxfac3JDB = '__'+Mrp5ZdGHFv9Xi6mkxfac3JDB[0] if Mrp5ZdGHFv9Xi6mkxfac3JDB else qpFY4hAwolV3
				if '/l/' in MepIvHBYNArkUOdV37shtJ:
					MepIvHBYNArkUOdV37shtJ = MepIvHBYNArkUOdV37shtJ.split('/l/')[1]
					MepIvHBYNArkUOdV37shtJ = PP0Gxazjw86.b64decode(MepIvHBYNArkUOdV37shtJ)
					if DLod2Of8CkRrtzJynev: MepIvHBYNArkUOdV37shtJ = MepIvHBYNArkUOdV37shtJ.decode(nV3Tip6XsH1rJw79DPOU)
				if MepIvHBYNArkUOdV37shtJ in wGOBvuSfQJn: continue
				wGOBvuSfQJn.append(MepIvHBYNArkUOdV37shtJ)
				MepIvHBYNArkUOdV37shtJ = MepIvHBYNArkUOdV37shtJ+'?named='+rr1mzIljJHqkx+'__download'+Mrp5ZdGHFv9Xi6mkxfac3JDB
				tiYp9ZdbFTQMcB4vWkHw6LXIAKrN5m.append(MepIvHBYNArkUOdV37shtJ)
	n6HherzoNy84uV = ePhmG1jLD6.findall('href="([^"<>]+)" class="btton watch__btn"',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	if n6HherzoNy84uV:
		n6HherzoNy84uV = n6HherzoNy84uV[0]
		IAW0sh6So3NpqM = WWrExJZS3Bj4anOAkpv7(KOyPvpEztYLaZRdMQJWxfTNFHbkg,'GET',n6HherzoNy84uV,qpFY4hAwolV3,headers,qpFY4hAwolV3,qpFY4hAwolV3,'ARABSEED-PLAY-3rd')
		CC8IKXmYeo = IAW0sh6So3NpqM.content
		pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('class="servers__list(.*?)</ul>',CC8IKXmYeo,ePhmG1jLD6.DOTALL)
		if pfRkcVlLmUxo561g0A8qSbO:
			mVYdjvor6i4wZ8 = pfRkcVlLmUxo561g0A8qSbO[0]
			items = ePhmG1jLD6.findall('data-qu="(.*?)".*?data-link="(.*?)".*?<span>(.*?)<',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
			for Mrp5ZdGHFv9Xi6mkxfac3JDB,MepIvHBYNArkUOdV37shtJ,title in items:
				if '=aHR0' in MepIvHBYNArkUOdV37shtJ:
					cId2FvNn50ylH83KrJCwT = ePhmG1jLD6.findall('=(aHR0.*?)$',MepIvHBYNArkUOdV37shtJ,ePhmG1jLD6.DOTALL)
					if cId2FvNn50ylH83KrJCwT:
						MepIvHBYNArkUOdV37shtJ = PP0Gxazjw86.b64decode(cId2FvNn50ylH83KrJCwT[0]+'===').decode(nV3Tip6XsH1rJw79DPOU)
						MepIvHBYNArkUOdV37shtJ = LORGsjk7foHQa2bxnNmKSwDAqpl1T(MepIvHBYNArkUOdV37shtJ)
				if 'http' not in MepIvHBYNArkUOdV37shtJ: MepIvHBYNArkUOdV37shtJ = ddBxj51bhNtaK23lDyGMVw+MepIvHBYNArkUOdV37shtJ
				if MepIvHBYNArkUOdV37shtJ in wGOBvuSfQJn: continue
				wGOBvuSfQJn.append(MepIvHBYNArkUOdV37shtJ)
				MepIvHBYNArkUOdV37shtJ = MepIvHBYNArkUOdV37shtJ+'?named='+title+'__watch__'+Mrp5ZdGHFv9Xi6mkxfac3JDB
				tiYp9ZdbFTQMcB4vWkHw6LXIAKrN5m.append(MepIvHBYNArkUOdV37shtJ)
		lkd2oKvZF03qmgMbIfQ6cD = ePhmG1jLD6.findall('"video_frame" src="(.*?)".*?height="(.*?)"',CC8IKXmYeo,ePhmG1jLD6.DOTALL|ePhmG1jLD6.IGNORECASE)
		if lkd2oKvZF03qmgMbIfQ6cD:
			MepIvHBYNArkUOdV37shtJ,Mrp5ZdGHFv9Xi6mkxfac3JDB = lkd2oKvZF03qmgMbIfQ6cD[0]
			if '=aHR0' in MepIvHBYNArkUOdV37shtJ:
				cId2FvNn50ylH83KrJCwT = ePhmG1jLD6.findall('=(aHR0.*?)$',MepIvHBYNArkUOdV37shtJ,ePhmG1jLD6.DOTALL)
				if cId2FvNn50ylH83KrJCwT:
					MepIvHBYNArkUOdV37shtJ = PP0Gxazjw86.b64decode(cId2FvNn50ylH83KrJCwT[0]+'===').decode(nV3Tip6XsH1rJw79DPOU)
					MepIvHBYNArkUOdV37shtJ = LORGsjk7foHQa2bxnNmKSwDAqpl1T(MepIvHBYNArkUOdV37shtJ)
			if 'http' not in MepIvHBYNArkUOdV37shtJ: MepIvHBYNArkUOdV37shtJ = ddBxj51bhNtaK23lDyGMVw+MepIvHBYNArkUOdV37shtJ
			name = AWeJuo2LhZ5xiD8KNSqd9G0rtT74FE(MepIvHBYNArkUOdV37shtJ,'name')
			if MepIvHBYNArkUOdV37shtJ not in wGOBvuSfQJn:
				wGOBvuSfQJn.append(MepIvHBYNArkUOdV37shtJ)
				MepIvHBYNArkUOdV37shtJ = MepIvHBYNArkUOdV37shtJ+'?named='+name+'__embed__'+Mrp5ZdGHFv9Xi6mkxfac3JDB
				tiYp9ZdbFTQMcB4vWkHw6LXIAKrN5m.append(MepIvHBYNArkUOdV37shtJ)
	import inVXFK46ET
	inVXFK46ET.q4qTJvuoQUzM3mZAtegy7IXdnb5wH(tiYp9ZdbFTQMcB4vWkHw6LXIAKrN5m,Q8Q0IDc6PLZajJAdTntKUmSGXz,'video',url)
	return
def ykKTvYf5DalbNxe7(url):
	IAW0sh6So3NpqM = WWrExJZS3Bj4anOAkpv7(KOyPvpEztYLaZRdMQJWxfTNFHbkg,'GET',url,qpFY4hAwolV3,headers,qpFY4hAwolV3,qpFY4hAwolV3,'ARABSEED-PLAY-1st')
	cmWl9dOKHPIy41iaXuxrY = IAW0sh6So3NpqM.content
	WSQlG8mDhqsNe = IAW0sh6So3NpqM.url
	XPNkVcWFUr = AWeJuo2LhZ5xiD8KNSqd9G0rtT74FE(WSQlG8mDhqsNe,'url')
	headers['Referer'] = XPNkVcWFUr+ShynO8pN9idCE3
	headers['Content-Type'] = 'application/x-www-form-urlencoded'
	U7V0BQZPxXqMbyJnRw6f,rKgLoOfMy5H0lIGjxB4tq = [],[]
	nePzHi3G1vc7D,ddMBbNqplVcmDo0hTwQktK2Re,V0TyOLl78cEZNRUHK5GtJFPeC = qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3
	eD0qAk8mas,GkHsz3BXrqw8iYEUyt1LuNZjVIPJ,rtniYh38Ou2p6sEmNMv = qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3
	ffRTdPi5qAJsKHwpgC = ePhmG1jLD6.findall('"WatchButtons"(.*?)</div>',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	if ffRTdPi5qAJsKHwpgC:
		mVYdjvor6i4wZ8 = ffRTdPi5qAJsKHwpgC[vvXoMLlg513]
		if '<form' in mVYdjvor6i4wZ8:
			rKgLoOfMy5H0lIGjxB4tq = ePhmG1jLD6.findall('<form action="(.*?)".*?name="(.*?)".*?value="(.*?)"',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
			if rKgLoOfMy5H0lIGjxB4tq:
				SUxNlIGhcy = 'POST'
				for RHsBilS7oU9tyMP,name,value in rKgLoOfMy5H0lIGjxB4tq:
					if 'wpost' in name: nePzHi3G1vc7D,ddMBbNqplVcmDo0hTwQktK2Re,V0TyOLl78cEZNRUHK5GtJFPeC = RHsBilS7oU9tyMP,name,value
					elif 'dpost' in name: eD0qAk8mas,GkHsz3BXrqw8iYEUyt1LuNZjVIPJ,rtniYh38Ou2p6sEmNMv = RHsBilS7oU9tyMP,name,value
				Uk5ujhbY2nFX8ZfgKPSo1sHyM = ddMBbNqplVcmDo0hTwQktK2Re+'='+V0TyOLl78cEZNRUHK5GtJFPeC
				quNa5f2s4phnvVJdK0mDr6OH = GkHsz3BXrqw8iYEUyt1LuNZjVIPJ+'='+rtniYh38Ou2p6sEmNMv
		else:
			rKgLoOfMy5H0lIGjxB4tq = ePhmG1jLD6.findall('href="(.*?)"',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
			if rKgLoOfMy5H0lIGjxB4tq:
				SUxNlIGhcy = 'GET'
				for MepIvHBYNArkUOdV37shtJ in rKgLoOfMy5H0lIGjxB4tq:
					if 'wpost' in MepIvHBYNArkUOdV37shtJ: nePzHi3G1vc7D = MepIvHBYNArkUOdV37shtJ
					elif 'dpost' in MepIvHBYNArkUOdV37shtJ: eD0qAk8mas = MepIvHBYNArkUOdV37shtJ
				Uk5ujhbY2nFX8ZfgKPSo1sHyM = qpFY4hAwolV3
				quNa5f2s4phnvVJdK0mDr6OH = qpFY4hAwolV3
	if nePzHi3G1vc7D:
		IAW0sh6So3NpqM = WWrExJZS3Bj4anOAkpv7(KOyPvpEztYLaZRdMQJWxfTNFHbkg,SUxNlIGhcy,nePzHi3G1vc7D,Uk5ujhbY2nFX8ZfgKPSo1sHyM,headers,qpFY4hAwolV3,qpFY4hAwolV3,'ARABSEED-PLAY-2nd')
		cmWl9dOKHPIy41iaXuxrY = IAW0sh6So3NpqM.content
		pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('class="WatcherArea(.*?</ul>)',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
		if pfRkcVlLmUxo561g0A8qSbO:
			byp4gitNZUDPKmqvdF6zBx2rEhI1 = pfRkcVlLmUxo561g0A8qSbO[0]
			byp4gitNZUDPKmqvdF6zBx2rEhI1 = byp4gitNZUDPKmqvdF6zBx2rEhI1.replace('</ul>','<h3>')
			byp4gitNZUDPKmqvdF6zBx2rEhI1 = byp4gitNZUDPKmqvdF6zBx2rEhI1.replace('<h3>','<h3><h3>')
			HLVwBWJ6mFa3ApoNlq178nuXgI = ePhmG1jLD6.findall('<h3>.*?(\d+)(.*?)<h3>',byp4gitNZUDPKmqvdF6zBx2rEhI1,ePhmG1jLD6.DOTALL)
			if not HLVwBWJ6mFa3ApoNlq178nuXgI: HLVwBWJ6mFa3ApoNlq178nuXgI = [(qpFY4hAwolV3,byp4gitNZUDPKmqvdF6zBx2rEhI1)]
			for Mrp5ZdGHFv9Xi6mkxfac3JDB,mVYdjvor6i4wZ8 in HLVwBWJ6mFa3ApoNlq178nuXgI:
				if Mrp5ZdGHFv9Xi6mkxfac3JDB: Mrp5ZdGHFv9Xi6mkxfac3JDB = '____'+Mrp5ZdGHFv9Xi6mkxfac3JDB
				items = ePhmG1jLD6.findall('data-link="(.*?)".*?<span>(.*?)</span>',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
				for MepIvHBYNArkUOdV37shtJ,name in items:
					if 'http' not in MepIvHBYNArkUOdV37shtJ: MepIvHBYNArkUOdV37shtJ = 'http:'+MepIvHBYNArkUOdV37shtJ
					MepIvHBYNArkUOdV37shtJ = MepIvHBYNArkUOdV37shtJ+'?named='+name+'__watch'+Mrp5ZdGHFv9Xi6mkxfac3JDB
					U7V0BQZPxXqMbyJnRw6f.append(MepIvHBYNArkUOdV37shtJ)
		CFevtSjzbpn = ePhmG1jLD6.findall('class="containerIframe".*? src="(.*?)".*? height="(.*?)"',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL|ePhmG1jLD6.IGNORECASE)
		if CFevtSjzbpn:
			MepIvHBYNArkUOdV37shtJ,Mrp5ZdGHFv9Xi6mkxfac3JDB = CFevtSjzbpn[0]
			name = AWeJuo2LhZ5xiD8KNSqd9G0rtT74FE(MepIvHBYNArkUOdV37shtJ,'name')
			if '%' in Mrp5ZdGHFv9Xi6mkxfac3JDB: MepIvHBYNArkUOdV37shtJ = MepIvHBYNArkUOdV37shtJ+'?named='+name+'__embed__'
			else: MepIvHBYNArkUOdV37shtJ = MepIvHBYNArkUOdV37shtJ+'?named='+name+'__embed____'+Mrp5ZdGHFv9Xi6mkxfac3JDB
			U7V0BQZPxXqMbyJnRw6f.append(MepIvHBYNArkUOdV37shtJ)
	if eD0qAk8mas:
		IAW0sh6So3NpqM = WWrExJZS3Bj4anOAkpv7(KOyPvpEztYLaZRdMQJWxfTNFHbkg,SUxNlIGhcy,eD0qAk8mas,quNa5f2s4phnvVJdK0mDr6OH,headers,qpFY4hAwolV3,qpFY4hAwolV3,'ARABSEED-PLAY-3rd')
		cmWl9dOKHPIy41iaXuxrY = IAW0sh6So3NpqM.content
		pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('class="DownloadArea(.*?)<script src=',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
		if pfRkcVlLmUxo561g0A8qSbO:
			byp4gitNZUDPKmqvdF6zBx2rEhI1 = pfRkcVlLmUxo561g0A8qSbO[0]
			HLVwBWJ6mFa3ApoNlq178nuXgI = ePhmG1jLD6.findall('class="DownloadServers(.*?)</ul>',byp4gitNZUDPKmqvdF6zBx2rEhI1,ePhmG1jLD6.DOTALL)
			for mVYdjvor6i4wZ8 in HLVwBWJ6mFa3ApoNlq178nuXgI:
				items = ePhmG1jLD6.findall('href="(.*?)".*?<span>(.*?)</span>.*?<p>(.*?)</p>',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
				for MepIvHBYNArkUOdV37shtJ,title,Mrp5ZdGHFv9Xi6mkxfac3JDB in items:
					if not MepIvHBYNArkUOdV37shtJ: continue
					if 'reviewstation' in MepIvHBYNArkUOdV37shtJ: continue
					MepIvHBYNArkUOdV37shtJ = cTt4u6reEMKZqVLplmkNW7(MepIvHBYNArkUOdV37shtJ)
					MepIvHBYNArkUOdV37shtJ = MepIvHBYNArkUOdV37shtJ+'?named='+title+'__download____'+Mrp5ZdGHFv9Xi6mkxfac3JDB
					U7V0BQZPxXqMbyJnRw6f.append(MepIvHBYNArkUOdV37shtJ)
	CnHdR6WtDAsBqgmwvJ9 = str(U7V0BQZPxXqMbyJnRw6f)
	O6O02mbflHBjci9MgTLIzXJ8 = ['.zip?','.rar?','.txt?','.pdf?','.tar?','.iso?','.zip.','.rar.','.txt.','.pdf.','.tar.','.iso.']
	if any(value in CnHdR6WtDAsBqgmwvJ9 for value in O6O02mbflHBjci9MgTLIzXJ8):
		iG7Rz2kmn0x1yLNMV3u8O(qpFY4hAwolV3,qpFY4hAwolV3,GLTtERWbHnFuy4PCp,'جرب رابط مختلف لأن هذا الرابط ليس من نوع الروابط التي فيها ملفات فيديو .. لأن هذا الموقع فيه خدمات أخرى غير ملفات الفيديو')
		return
	import inVXFK46ET
	inVXFK46ET.q4qTJvuoQUzM3mZAtegy7IXdnb5wH(U7V0BQZPxXqMbyJnRw6f,Q8Q0IDc6PLZajJAdTntKUmSGXz,'video',url)
	return
def PPqUACSE3VcGLTvw05jHy9JrFNW(search):
	search,LBylNhMdH6OV1qGk0tWiXFg3,showDialogs = LLm3sBXHPcnTDxdE5gt6hz0Wkp(search)
	if not search: search = jXgARlWMLVFUBnvmZwI2o5()
	if not search: return
	search = search.replace(mIsDke0oK5x1zSiOWbF9thGcA,'+')
	url = ddBxj51bhNtaK23lDyGMVw+'/find/?word='+search+'&type='
	c8U1BdtxOZS5FH(url,'search')
	return
def R9pWUgVhBGLd2CQb0z(url,filter):
	if '??' in url: url = url.split('//getposts??')[0]
	type,filter = filter.split('___',1)
	if filter==qpFY4hAwolV3: eAYm1EkvcnOzXWpFB68o9rglSQ0M5,M0jc2ZsJHPb1d3DCoyXIzmgt = qpFY4hAwolV3,qpFY4hAwolV3
	else: eAYm1EkvcnOzXWpFB68o9rglSQ0M5,M0jc2ZsJHPb1d3DCoyXIzmgt = filter.split('___')
	if type=='CATEGORIES':
		if xOc1qk9GYV[0]+'==' not in eAYm1EkvcnOzXWpFB68o9rglSQ0M5: n1uwH0oJaGZ5WBd = xOc1qk9GYV[0]
		for a2jQ83ZCfcM5 in range(len(xOc1qk9GYV[0:-1])):
			if xOc1qk9GYV[a2jQ83ZCfcM5]+'==' in eAYm1EkvcnOzXWpFB68o9rglSQ0M5: n1uwH0oJaGZ5WBd = xOc1qk9GYV[a2jQ83ZCfcM5+1]
		OI4ExuWvaLU = eAYm1EkvcnOzXWpFB68o9rglSQ0M5+'&&'+n1uwH0oJaGZ5WBd+'==0'
		vmTWLw30V2PFNC8DrRqI = M0jc2ZsJHPb1d3DCoyXIzmgt+'&&'+n1uwH0oJaGZ5WBd+'==0'
		nxGqbf39mXPhwl1NtAsSYK = OI4ExuWvaLU.strip('&&')+'___'+vmTWLw30V2PFNC8DrRqI.strip('&&')
		ekvC3tHRVnZGM4uDsmE2pBc5x = ZX8DyBJbV4lNAG(M0jc2ZsJHPb1d3DCoyXIzmgt,'modified_filters')
		WSQlG8mDhqsNe = url+'//getposts??'+ekvC3tHRVnZGM4uDsmE2pBc5x
	elif type=='FILTERS':
		Q7PrOdIzEeXgpT4HL38GK = ZX8DyBJbV4lNAG(eAYm1EkvcnOzXWpFB68o9rglSQ0M5,'modified_values')
		Q7PrOdIzEeXgpT4HL38GK = cTt4u6reEMKZqVLplmkNW7(Q7PrOdIzEeXgpT4HL38GK)
		if M0jc2ZsJHPb1d3DCoyXIzmgt!=qpFY4hAwolV3: M0jc2ZsJHPb1d3DCoyXIzmgt = ZX8DyBJbV4lNAG(M0jc2ZsJHPb1d3DCoyXIzmgt,'modified_filters')
		if M0jc2ZsJHPb1d3DCoyXIzmgt==qpFY4hAwolV3: WSQlG8mDhqsNe = url
		else: WSQlG8mDhqsNe = url+'//getposts??'+M0jc2ZsJHPb1d3DCoyXIzmgt
		y2SIoiHRUhNMmqPYjrwA3TWg69pxV = BMWgGkaVvlpfeHY4r8sI(WSQlG8mDhqsNe)
		x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+'أظهار قائمة الفيديو التي تم اختيارها ',y2SIoiHRUhNMmqPYjrwA3TWg69pxV,251,qpFY4hAwolV3,qpFY4hAwolV3,'filters')
		x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+' [[   '+Q7PrOdIzEeXgpT4HL38GK+'   ]]',y2SIoiHRUhNMmqPYjrwA3TWg69pxV,251,qpFY4hAwolV3,qpFY4hAwolV3,'filters')
		x3WSXnKyPhjqfHG2UrtQs('link',xupTj02bvy3O8R+' ===== ===== ===== '+fF4lt9zWYxXLKZVyAco82PgMj,qpFY4hAwolV3,9999)
	IAW0sh6So3NpqM = WWrExJZS3Bj4anOAkpv7(KOyPvpEztYLaZRdMQJWxfTNFHbkg,'POST',url,qpFY4hAwolV3,headers,qpFY4hAwolV3,qpFY4hAwolV3,'ARABSEED-FILTERS_MENU-1st')
	cmWl9dOKHPIy41iaXuxrY = IAW0sh6So3NpqM.content
	pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('class="TaxPageFilter"(.*?)class="TermBTNs"',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	mVYdjvor6i4wZ8 = pfRkcVlLmUxo561g0A8qSbO[0]
	JqWayciU64ujh2Y = ePhmG1jLD6.findall('class="TaxPageFilterItem".*?<em>(.*?)</em>.*?data-tax="(.*?)"(.*?)</ul>',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
	SBubzy7NvJo = ePhmG1jLD6.findall('class="RatingFilter".*?<h4>(.*?)</h4>.*?(<ul>)(.*?)</ul>',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
	YF4LRjr6TuagQk9o3PiMeIcHx = JqWayciU64ujh2Y+SBubzy7NvJo
	dict = {}
	for name,CQlVpYyFN6bzXRBZIMxPWdn,mVYdjvor6i4wZ8 in YF4LRjr6TuagQk9o3PiMeIcHx:
		items = ePhmG1jLD6.findall('data-name="(.*?)".*?data-tax="(.*?)".*?data-term="(.*?)"',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
		if name=='اخرى': name = 'الاقسام'
		if not items:
			eKEo1iY0x8kAcU76ChWaypzHIwlRMq = ePhmG1jLD6.findall('data-rate="(.*?)".*?<em>(.*?)</em>',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
			items = []
			for FLkeT4nCDqrQMmW6ZSlgyU5jIO32,value in eKEo1iY0x8kAcU76ChWaypzHIwlRMq: items.append([FLkeT4nCDqrQMmW6ZSlgyU5jIO32,qpFY4hAwolV3,value])
			CQlVpYyFN6bzXRBZIMxPWdn = 'rate'
			name = 'التقييم'
		else: CQlVpYyFN6bzXRBZIMxPWdn = items[0][1]
		if '==' not in WSQlG8mDhqsNe: WSQlG8mDhqsNe = url
		if type=='CATEGORIES':
			if n1uwH0oJaGZ5WBd!=CQlVpYyFN6bzXRBZIMxPWdn: continue
			elif len(items)<=1:
				if CQlVpYyFN6bzXRBZIMxPWdn==xOc1qk9GYV[-1]: c8U1BdtxOZS5FH(WSQlG8mDhqsNe)
				else: R9pWUgVhBGLd2CQb0z(WSQlG8mDhqsNe,'CATEGORIES___'+nxGqbf39mXPhwl1NtAsSYK)
				return
			else:
				y2SIoiHRUhNMmqPYjrwA3TWg69pxV = BMWgGkaVvlpfeHY4r8sI(WSQlG8mDhqsNe)
				if CQlVpYyFN6bzXRBZIMxPWdn==xOc1qk9GYV[-1]: x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+'الجميع ',y2SIoiHRUhNMmqPYjrwA3TWg69pxV,251,qpFY4hAwolV3,qpFY4hAwolV3,'filters')
				else: x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+'الجميع ',WSQlG8mDhqsNe,254,qpFY4hAwolV3,qpFY4hAwolV3,nxGqbf39mXPhwl1NtAsSYK)
		elif type=='FILTERS':
			OI4ExuWvaLU = eAYm1EkvcnOzXWpFB68o9rglSQ0M5+'&&'+CQlVpYyFN6bzXRBZIMxPWdn+'==0'
			vmTWLw30V2PFNC8DrRqI = M0jc2ZsJHPb1d3DCoyXIzmgt+'&&'+CQlVpYyFN6bzXRBZIMxPWdn+'==0'
			nxGqbf39mXPhwl1NtAsSYK = OI4ExuWvaLU+'___'+vmTWLw30V2PFNC8DrRqI
			x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+'الجميع :'+name,WSQlG8mDhqsNe,255,qpFY4hAwolV3,qpFY4hAwolV3,nxGqbf39mXPhwl1NtAsSYK)
		dict[CQlVpYyFN6bzXRBZIMxPWdn] = {}
		for FLkeT4nCDqrQMmW6ZSlgyU5jIO32,oF67yxKdB8nY3TiH9gAMvlOhaPSws0,value in items:
			if FLkeT4nCDqrQMmW6ZSlgyU5jIO32 in YEIA19ehBwpNfPVzK: continue
			if 'الكل' in FLkeT4nCDqrQMmW6ZSlgyU5jIO32: continue
			FLkeT4nCDqrQMmW6ZSlgyU5jIO32 = j8PDV0pthfSTidZbsQxNIOmCYKWzH(FLkeT4nCDqrQMmW6ZSlgyU5jIO32)
			rr1mzIljJHqkx,UdbGw48M6rCHDRmea5qP91nKI = FLkeT4nCDqrQMmW6ZSlgyU5jIO32,FLkeT4nCDqrQMmW6ZSlgyU5jIO32
			UdbGw48M6rCHDRmea5qP91nKI = name+': '+rr1mzIljJHqkx
			dict[CQlVpYyFN6bzXRBZIMxPWdn][value] = UdbGw48M6rCHDRmea5qP91nKI
			OI4ExuWvaLU = eAYm1EkvcnOzXWpFB68o9rglSQ0M5+'&&'+CQlVpYyFN6bzXRBZIMxPWdn+'=='+rr1mzIljJHqkx
			vmTWLw30V2PFNC8DrRqI = M0jc2ZsJHPb1d3DCoyXIzmgt+'&&'+CQlVpYyFN6bzXRBZIMxPWdn+'=='+value
			lJWPN5EDIbft92m6iCQqAYLjav4p = OI4ExuWvaLU+'___'+vmTWLw30V2PFNC8DrRqI
			if type=='FILTERS':
				x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+UdbGw48M6rCHDRmea5qP91nKI,url,255,qpFY4hAwolV3,qpFY4hAwolV3,lJWPN5EDIbft92m6iCQqAYLjav4p)
			elif type=='CATEGORIES' and xOc1qk9GYV[-2]+'==' in eAYm1EkvcnOzXWpFB68o9rglSQ0M5:
				ekvC3tHRVnZGM4uDsmE2pBc5x = ZX8DyBJbV4lNAG(vmTWLw30V2PFNC8DrRqI,'modified_filters')
				hhpztscnBD1GP = url+'//getposts??'+ekvC3tHRVnZGM4uDsmE2pBc5x
				y2SIoiHRUhNMmqPYjrwA3TWg69pxV = BMWgGkaVvlpfeHY4r8sI(hhpztscnBD1GP)
				x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+UdbGw48M6rCHDRmea5qP91nKI,y2SIoiHRUhNMmqPYjrwA3TWg69pxV,251,qpFY4hAwolV3,qpFY4hAwolV3,'filters')
			else: x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+UdbGw48M6rCHDRmea5qP91nKI,url,254,qpFY4hAwolV3,qpFY4hAwolV3,lJWPN5EDIbft92m6iCQqAYLjav4p)
	return
xOc1qk9GYV = ['category','country','release-year']
D4QyIwCApsmkBLr = ['category','country','genre','release-year','language','quality','rate']
def BMWgGkaVvlpfeHY4r8sI(url):
	enkOgFQMpBadWlwVKh6cGEtNr = '/wp-content/themes/Elshaikh2021/Ajaxat/Home/FilteringHome.php'
	url = url.replace('//getposts',enkOgFQMpBadWlwVKh6cGEtNr)
	url = url.replace('/category/اخرى',qpFY4hAwolV3)
	if enkOgFQMpBadWlwVKh6cGEtNr not in url: url = url+enkOgFQMpBadWlwVKh6cGEtNr
	url = url.replace('release-year','year')
	url = url.replace('??','?')
	url = url.replace('&&','&')
	url = url.replace('==','=')
	return url
def ZX8DyBJbV4lNAG(bbaYxjcVnksy,mode):
	bbaYxjcVnksy = bbaYxjcVnksy.strip('&&')
	J9ASCRhfiDyTB,LxOIqpMU7E1hPKH5fSzj2iW9v = {},qpFY4hAwolV3
	if '==' in bbaYxjcVnksy:
		items = bbaYxjcVnksy.split('&&')
		for lkd2oKvZF03qmgMbIfQ6cD in items:
			JJAsQ4pRYXPhqugN2to9TEzLIS,value = lkd2oKvZF03qmgMbIfQ6cD.split('==')
			J9ASCRhfiDyTB[JJAsQ4pRYXPhqugN2to9TEzLIS] = value
	for key in D4QyIwCApsmkBLr:
		if key in list(J9ASCRhfiDyTB.keys()): value = J9ASCRhfiDyTB[key]
		else: value = '0'
		if '%' not in value: value = BUKlErdIu7Ggqcz3jYpf09wMePF4V(value)
		if mode=='modified_values' and value!='0': LxOIqpMU7E1hPKH5fSzj2iW9v = LxOIqpMU7E1hPKH5fSzj2iW9v+' + '+value
		elif mode=='modified_filters' and value!='0': LxOIqpMU7E1hPKH5fSzj2iW9v = LxOIqpMU7E1hPKH5fSzj2iW9v+'&&'+key+'=='+value
		elif mode=='all': LxOIqpMU7E1hPKH5fSzj2iW9v = LxOIqpMU7E1hPKH5fSzj2iW9v+'&&'+key+'=='+value
	LxOIqpMU7E1hPKH5fSzj2iW9v = LxOIqpMU7E1hPKH5fSzj2iW9v.strip(' + ')
	LxOIqpMU7E1hPKH5fSzj2iW9v = LxOIqpMU7E1hPKH5fSzj2iW9v.strip('&&')
	return LxOIqpMU7E1hPKH5fSzj2iW9v