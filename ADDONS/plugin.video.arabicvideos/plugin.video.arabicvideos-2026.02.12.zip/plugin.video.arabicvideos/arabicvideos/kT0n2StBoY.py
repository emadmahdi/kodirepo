# -*- coding: utf-8 -*-
from pSfaryIjBo import *
Q8Q0IDc6PLZajJAdTntKUmSGXz = 'KATKOUTE'
wwSFijdVJn1QgHW = '_KTK_'
ddBxj51bhNtaK23lDyGMVw = i4bFG3rKE6.SITESURLS[Q8Q0IDc6PLZajJAdTntKUmSGXz][0]
YEIA19ehBwpNfPVzK = ['الصفحة الرئيسية','Sign in','الأقسام']
def vTNE2Ck1sGnugJYW8y39aLcSH64U(mode,url,text):
	if   mode==670: MOTjA5H9XFs = nRVAZc4Dp8PSrGU3xBk()
	elif mode==671: MOTjA5H9XFs = c8U1BdtxOZS5FH(url,text)
	elif mode==672: MOTjA5H9XFs = mzcAeyplZV(url)
	elif mode==673: MOTjA5H9XFs = PXEsuKvq5fS438YWFh7gBCdrw(url,text)
	elif mode==674: MOTjA5H9XFs = X2rO3lubqIdCGMLYWcxA6DK5(url)
	elif mode==679: MOTjA5H9XFs = PPqUACSE3VcGLTvw05jHy9JrFNW(text)
	else: MOTjA5H9XFs = False
	return MOTjA5H9XFs
def nRVAZc4Dp8PSrGU3xBk():
	IAW0sh6So3NpqM = WWrExJZS3Bj4anOAkpv7(kUz8c7OqsxuPFIGfwg,'GET',ddBxj51bhNtaK23lDyGMVw,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,'KATKOUTE-MENU-1st')
	cmWl9dOKHPIy41iaXuxrY = IAW0sh6So3NpqM.content
	x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+'بحث في الموقع',qpFY4hAwolV3,679,qpFY4hAwolV3,qpFY4hAwolV3,'_REMEMBERRESULTS_')
	x3WSXnKyPhjqfHG2UrtQs('link',xupTj02bvy3O8R+' ===== ===== ===== '+fF4lt9zWYxXLKZVyAco82PgMj,qpFY4hAwolV3,9999)
	pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('"navslide-divider"(.*?)</ul>',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	if pfRkcVlLmUxo561g0A8qSbO:
		mVYdjvor6i4wZ8 = pfRkcVlLmUxo561g0A8qSbO[0]
		items = ePhmG1jLD6.findall('href="(.*?)">(.*?)</a>',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
		for MepIvHBYNArkUOdV37shtJ,title in items:
			if title in YEIA19ehBwpNfPVzK: continue
			if title=='الأقسام': mode = 675
			else: mode = 674
			x3WSXnKyPhjqfHG2UrtQs('folder',Q8Q0IDc6PLZajJAdTntKUmSGXz+'_SCRIPT_'+wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,mode)
	x3WSXnKyPhjqfHG2UrtQs('link',xupTj02bvy3O8R+' ===== ===== ===== '+fF4lt9zWYxXLKZVyAco82PgMj,qpFY4hAwolV3,9999)
	items = KK3QFHikTNzwY8j25G7vr14cWh(ddBxj51bhNtaK23lDyGMVw+'/watch/browse.html')
	for MepIvHBYNArkUOdV37shtJ,Sj7rMNYRuQPTtkBvpHKeDW3h,title in items:
		x3WSXnKyPhjqfHG2UrtQs('folder',Q8Q0IDc6PLZajJAdTntKUmSGXz+'_SCRIPT_'+wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,674,Sj7rMNYRuQPTtkBvpHKeDW3h)
	return
def KK3QFHikTNzwY8j25G7vr14cWh(url):
	VVn8DUgwNTFzEchAd6fi3 = XXyMBNAVJvKiq7jc20bEw6(WoFsvbmUlDZp7PzRfdGknCV,'list','KATKOUTE','CATEGORIES')
	if VVn8DUgwNTFzEchAd6fi3: return VVn8DUgwNTFzEchAd6fi3
	VVn8DUgwNTFzEchAd6fi3 = []
	IAW0sh6So3NpqM = WWrExJZS3Bj4anOAkpv7(dzcNuIbsgK3yZ6SXGaEHPfOj5vk,'GET',url,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,'KATKOUTE-CATEGORIES-1st')
	cmWl9dOKHPIy41iaXuxrY = IAW0sh6So3NpqM.content
	pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('"category-header"(.*?)<footer>',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	if pfRkcVlLmUxo561g0A8qSbO:
		mVYdjvor6i4wZ8 = pfRkcVlLmUxo561g0A8qSbO[0]
		VVn8DUgwNTFzEchAd6fi3 = ePhmG1jLD6.findall('href="(.*?)".*?src="(.*?)" alt="(.*?)"',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
		if VVn8DUgwNTFzEchAd6fi3: zOYMaQ0NgdiRVwDJXh8e(WoFsvbmUlDZp7PzRfdGknCV,'KATKOUTE','CATEGORIES',VVn8DUgwNTFzEchAd6fi3,KOyPvpEztYLaZRdMQJWxfTNFHbkg)
	return VVn8DUgwNTFzEchAd6fi3
def X2rO3lubqIdCGMLYWcxA6DK5(url):
	IAW0sh6So3NpqM = WWrExJZS3Bj4anOAkpv7(kUz8c7OqsxuPFIGfwg,'GET',url,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,'KATKOUTE-SUBMENU-1st')
	cmWl9dOKHPIy41iaXuxrY = IAW0sh6So3NpqM.content
	NDnI9Qrpt5c8MU = ePhmG1jLD6.findall('"caret"(.*?)</ul>',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	if NDnI9Qrpt5c8MU:
		mVYdjvor6i4wZ8 = NDnI9Qrpt5c8MU[0]
		mVYdjvor6i4wZ8 = mVYdjvor6i4wZ8.replace('"presentation"','</ul>')
		pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('"dropdown-header">(.*?)</li>(.*?)</ul>',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
		if not pfRkcVlLmUxo561g0A8qSbO: pfRkcVlLmUxo561g0A8qSbO = [(qpFY4hAwolV3,mVYdjvor6i4wZ8)]
		x3WSXnKyPhjqfHG2UrtQs('link',xupTj02bvy3O8R+' فرز أو فلتر أو ترتيب '+fF4lt9zWYxXLKZVyAco82PgMj,qpFY4hAwolV3,9999)
		for YirSOX5nC0jPyvFTN48sHE1,mVYdjvor6i4wZ8 in pfRkcVlLmUxo561g0A8qSbO:
			items = ePhmG1jLD6.findall('href="(.*?)".*?>(.*?)</a>',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
			if YirSOX5nC0jPyvFTN48sHE1: YirSOX5nC0jPyvFTN48sHE1 = YirSOX5nC0jPyvFTN48sHE1+': '
			for MepIvHBYNArkUOdV37shtJ,title in items:
				title = YirSOX5nC0jPyvFTN48sHE1+title
				x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,671)
	T9TAc28ayKvFgjfd6SD = ePhmG1jLD6.findall('"pm-category-subcats"(.*?)</ul>',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	if T9TAc28ayKvFgjfd6SD:
		mVYdjvor6i4wZ8 = T9TAc28ayKvFgjfd6SD[0]
		items = ePhmG1jLD6.findall('href="(.*?)">(.*?)</a>',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
		if len(items)<30:
			x3WSXnKyPhjqfHG2UrtQs('link',xupTj02bvy3O8R+' ===== ===== ===== '+fF4lt9zWYxXLKZVyAco82PgMj,qpFY4hAwolV3,9999)
			for MepIvHBYNArkUOdV37shtJ,title in items:
				x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,671)
	if not NDnI9Qrpt5c8MU and not T9TAc28ayKvFgjfd6SD: c8U1BdtxOZS5FH(url)
	return
def c8U1BdtxOZS5FH(url,AMbRf4XTpQNvio6J5GELducy0k=qpFY4hAwolV3):
	if AMbRf4XTpQNvio6J5GELducy0k=='ajax-search':
		url,search = url.split('?',1)
		data = 'queryString='+search
		headers = {'Content-Type':'application/x-www-form-urlencoded; charset=UTF-8'}
		IAW0sh6So3NpqM = WWrExJZS3Bj4anOAkpv7(kUz8c7OqsxuPFIGfwg,'POST',url,data,headers,qpFY4hAwolV3,qpFY4hAwolV3,'KATKOUTE-TITLES-1st')
	else:
		IAW0sh6So3NpqM = WWrExJZS3Bj4anOAkpv7(kUz8c7OqsxuPFIGfwg,'GET',url,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,'KATKOUTE-TITLES-2nd')
	cmWl9dOKHPIy41iaXuxrY = IAW0sh6So3NpqM.content
	mVYdjvor6i4wZ8,items = qpFY4hAwolV3,[]
	iipsGz2LKq = AWeJuo2LhZ5xiD8KNSqd9G0rtT74FE(url,'url')
	if AMbRf4XTpQNvio6J5GELducy0k=='ajax-search':
		mVYdjvor6i4wZ8 = cmWl9dOKHPIy41iaXuxrY
		eKEo1iY0x8kAcU76ChWaypzHIwlRMq = ePhmG1jLD6.findall('href="(.*?)">(.*?)</a>',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
		for MepIvHBYNArkUOdV37shtJ,title in eKEo1iY0x8kAcU76ChWaypzHIwlRMq: items.append((qpFY4hAwolV3,MepIvHBYNArkUOdV37shtJ,title))
	elif AMbRf4XTpQNvio6J5GELducy0k=='featured':
		pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('"pm-video-watch-featured"(.*?)</ul>',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
		if pfRkcVlLmUxo561g0A8qSbO: mVYdjvor6i4wZ8 = pfRkcVlLmUxo561g0A8qSbO[0]
	elif AMbRf4XTpQNvio6J5GELducy0k=='new_episodes':
		pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('"row pm-ul-browse-videos(.*?)</ul>',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
		if pfRkcVlLmUxo561g0A8qSbO: mVYdjvor6i4wZ8 = pfRkcVlLmUxo561g0A8qSbO[0]
	elif AMbRf4XTpQNvio6J5GELducy0k=='new_movies':
		pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('"row pm-ul-browse-videos(.*?)</ul>',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
		if len(pfRkcVlLmUxo561g0A8qSbO)>1: mVYdjvor6i4wZ8 = pfRkcVlLmUxo561g0A8qSbO[1]
	elif AMbRf4XTpQNvio6J5GELducy0k=='featured_series':
		pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('"home-series-list"(.*?)</div>[\t|\n]*</div>',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
		if pfRkcVlLmUxo561g0A8qSbO: mVYdjvor6i4wZ8 = pfRkcVlLmUxo561g0A8qSbO[0]
		eKEo1iY0x8kAcU76ChWaypzHIwlRMq = ePhmG1jLD6.findall('href="(.*?)">(.*?)</a>',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
		for MepIvHBYNArkUOdV37shtJ,title in eKEo1iY0x8kAcU76ChWaypzHIwlRMq: items.append((qpFY4hAwolV3,MepIvHBYNArkUOdV37shtJ,title))
	else:
		pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('(data-echo=".*?)</ul>',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
		if pfRkcVlLmUxo561g0A8qSbO: mVYdjvor6i4wZ8 = pfRkcVlLmUxo561g0A8qSbO[0]
	if mVYdjvor6i4wZ8 and not items: items = ePhmG1jLD6.findall('data-echo="(.*?)".*?href="(.*?)".*?>(.*?)<',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
	if not items: return
	aaCNAJdtsguSRELh2I = []
	WGid3I2kFU = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم','مسرحية','فلم']
	for Sj7rMNYRuQPTtkBvpHKeDW3h,MepIvHBYNArkUOdV37shtJ,title in items:
		ZDTxRSMbW7PNz = ePhmG1jLD6.findall('(.*?) (الحلقة|حلقة).\d+',title,ePhmG1jLD6.DOTALL)
		if any(value in title for value in WGid3I2kFU):
			x3WSXnKyPhjqfHG2UrtQs('video',wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,672,Sj7rMNYRuQPTtkBvpHKeDW3h)
		elif AMbRf4XTpQNvio6J5GELducy0k=='new_episodes':
			x3WSXnKyPhjqfHG2UrtQs('video',wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,672,Sj7rMNYRuQPTtkBvpHKeDW3h)
		elif ZDTxRSMbW7PNz:
			title = '_MOD_' + ZDTxRSMbW7PNz[0][0]
			if title not in aaCNAJdtsguSRELh2I:
				x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,673,Sj7rMNYRuQPTtkBvpHKeDW3h)
				aaCNAJdtsguSRELh2I.append(title)
		elif '/movseries/' in MepIvHBYNArkUOdV37shtJ:
			x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,671,Sj7rMNYRuQPTtkBvpHKeDW3h)
		else: x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,673,Sj7rMNYRuQPTtkBvpHKeDW3h)
	pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('"pagination(.*?)</ul>',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	if pfRkcVlLmUxo561g0A8qSbO:
		mVYdjvor6i4wZ8 = pfRkcVlLmUxo561g0A8qSbO[0]
		items = ePhmG1jLD6.findall('href="(.*?)".*?>(.*?)</a>',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
		for MepIvHBYNArkUOdV37shtJ,title in items:
			if MepIvHBYNArkUOdV37shtJ=='#': continue
			if 'http' not in MepIvHBYNArkUOdV37shtJ:
				WSQlG8mDhqsNe = url.rsplit(ShynO8pN9idCE3,1)[0]
				MepIvHBYNArkUOdV37shtJ = WSQlG8mDhqsNe+ShynO8pN9idCE3+MepIvHBYNArkUOdV37shtJ.strip(ShynO8pN9idCE3)
			title = j8PDV0pthfSTidZbsQxNIOmCYKWzH(title)
			x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+'صفحة '+title,MepIvHBYNArkUOdV37shtJ,671,qpFY4hAwolV3,qpFY4hAwolV3,AMbRf4XTpQNvio6J5GELducy0k)
	return
def PXEsuKvq5fS438YWFh7gBCdrw(url,MaNXbtkeElTRsiK6c1u):
	x3WSXnKyPhjqfHG2UrtQs('video',wwSFijdVJn1QgHW+'تشغيل الفيديو',url,672)
	x3WSXnKyPhjqfHG2UrtQs('link',xupTj02bvy3O8R+' ===== ===== ===== '+fF4lt9zWYxXLKZVyAco82PgMj,qpFY4hAwolV3,9999)
	VVn8DUgwNTFzEchAd6fi3 = KK3QFHikTNzwY8j25G7vr14cWh(ddBxj51bhNtaK23lDyGMVw+'/watch/browse.html')
	gku2Plq43U5i9TwRdIGCvDS7Ffch,kmZfITz5OQUsc1xrBRYFVliWvKwu0,zgUSItP2CqlNQ6WAhOebK8H7i1cu = zip(*VVn8DUgwNTFzEchAd6fi3)
	aXZiN3Py9qx7kHj5f1ow042uAKnTY = []
	IAW0sh6So3NpqM = WWrExJZS3Bj4anOAkpv7(kUz8c7OqsxuPFIGfwg,'GET',url,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,'KATKOUTE-EPISODES-2nd')
	cmWl9dOKHPIy41iaXuxrY = IAW0sh6So3NpqM.content
	pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('"row pm-video-heading"(.*?)id="player"',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	if pfRkcVlLmUxo561g0A8qSbO:
		mVYdjvor6i4wZ8 = pfRkcVlLmUxo561g0A8qSbO[0]
		CFevtSjzbpn = ePhmG1jLD6.findall('class="myButton".*?href="(.*?)".*?<b>(.*?)<',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
		for MepIvHBYNArkUOdV37shtJ,title in CFevtSjzbpn:
			if MepIvHBYNArkUOdV37shtJ not in gku2Plq43U5i9TwRdIGCvDS7Ffch:
				lkd2oKvZF03qmgMbIfQ6cD = (MepIvHBYNArkUOdV37shtJ,title)
				aXZiN3Py9qx7kHj5f1ow042uAKnTY.append(lkd2oKvZF03qmgMbIfQ6cD)
		if len(aXZiN3Py9qx7kHj5f1ow042uAKnTY)==1:
			MepIvHBYNArkUOdV37shtJ,title = aXZiN3Py9qx7kHj5f1ow042uAKnTY[0]
			c8U1BdtxOZS5FH(MepIvHBYNArkUOdV37shtJ,'new_episodes')
			return
		else:
			for MepIvHBYNArkUOdV37shtJ,title in aXZiN3Py9qx7kHj5f1ow042uAKnTY:
				x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,671,qpFY4hAwolV3,qpFY4hAwolV3,'new_episodes')
	if not aXZiN3Py9qx7kHj5f1ow042uAKnTY: c8U1BdtxOZS5FH(url,'new_episodes')
	return
def mzcAeyplZV(url):
	tiYp9ZdbFTQMcB4vWkHw6LXIAKrN5m = []
	IAW0sh6So3NpqM = WWrExJZS3Bj4anOAkpv7(kUz8c7OqsxuPFIGfwg,'GET',url,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,'KATKOUTE-PLAY-1st')
	cmWl9dOKHPIy41iaXuxrY = IAW0sh6So3NpqM.content
	pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('sources:(.*?)flashplayer',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	if pfRkcVlLmUxo561g0A8qSbO:
		mVYdjvor6i4wZ8 = pfRkcVlLmUxo561g0A8qSbO[0]
		CFevtSjzbpn = ePhmG1jLD6.findall('file: "(.*?)".*?label: "(.*?)"',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
		for MepIvHBYNArkUOdV37shtJ,Mrp5ZdGHFv9Xi6mkxfac3JDB in CFevtSjzbpn:
			MepIvHBYNArkUOdV37shtJ = MepIvHBYNArkUOdV37shtJ+'?named=__watch__'+Mrp5ZdGHFv9Xi6mkxfac3JDB
			tiYp9ZdbFTQMcB4vWkHw6LXIAKrN5m.append(MepIvHBYNArkUOdV37shtJ)
	CFevtSjzbpn = ePhmG1jLD6.findall('"embedded-video".*?src="(.*?)"',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	if not CFevtSjzbpn: CFevtSjzbpn = ePhmG1jLD6.findall("file: '(.*?)'",cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	if CFevtSjzbpn:
		MepIvHBYNArkUOdV37shtJ = CFevtSjzbpn[0]
		if 'http' not in MepIvHBYNArkUOdV37shtJ: MepIvHBYNArkUOdV37shtJ = 'http:'+MepIvHBYNArkUOdV37shtJ
		tiYp9ZdbFTQMcB4vWkHw6LXIAKrN5m.append(MepIvHBYNArkUOdV37shtJ+'?named=__embed')
	import inVXFK46ET
	inVXFK46ET.q4qTJvuoQUzM3mZAtegy7IXdnb5wH(tiYp9ZdbFTQMcB4vWkHw6LXIAKrN5m,Q8Q0IDc6PLZajJAdTntKUmSGXz,'video',url)
	return
def PPqUACSE3VcGLTvw05jHy9JrFNW(search):
	search,LBylNhMdH6OV1qGk0tWiXFg3,showDialogs = LLm3sBXHPcnTDxdE5gt6hz0Wkp(search)
	if search==qpFY4hAwolV3: search = jXgARlWMLVFUBnvmZwI2o5()
	if search==qpFY4hAwolV3: return
	search = search.replace(mIsDke0oK5x1zSiOWbF9thGcA,'+')
	url = ddBxj51bhNtaK23lDyGMVw+'/watch/search.php?keywords='+search
	c8U1BdtxOZS5FH(url,'search')
	return