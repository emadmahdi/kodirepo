# -*- coding: utf-8 -*-
from pSfaryIjBo import *
VwkA0oma2Nf = 'FAVORITES'
def iPV7rXlx3Za(ZyiMa3BXVk2xWG0b,F7nlDUR3o6V1rOMg):
	if   ZyiMa3BXVk2xWG0b==270: slKYBZe0zC3WF6XSunQar = XwvsYGlxEn5dSNybeJkBcg9(F7nlDUR3o6V1rOMg)
	else: slKYBZe0zC3WF6XSunQar = False
	return slKYBZe0zC3WF6XSunQar
def dmFAy3UQ2eRbJDfiNLBMX6H9tsrv(fdD0wQgTuni,F7nlDUR3o6V1rOMg,TMRW0JhwHFDn7Ko3qfLcbPv46a1):
	if not fdD0wQgTuni: return
	if   TMRW0JhwHFDn7Ko3qfLcbPv46a1=='UP1'	: YKPWb27nNVfJsXyDAS(F7nlDUR3o6V1rOMg,True,mZi0S72jGoHpLO)
	elif TMRW0JhwHFDn7Ko3qfLcbPv46a1=='DOWN1'	: YKPWb27nNVfJsXyDAS(F7nlDUR3o6V1rOMg,False,mZi0S72jGoHpLO)
	elif TMRW0JhwHFDn7Ko3qfLcbPv46a1=='UP4'	: YKPWb27nNVfJsXyDAS(F7nlDUR3o6V1rOMg,True,wn4bG51vUENfaS0Zg)
	elif TMRW0JhwHFDn7Ko3qfLcbPv46a1=='DOWN4'	: YKPWb27nNVfJsXyDAS(F7nlDUR3o6V1rOMg,False,wn4bG51vUENfaS0Zg)
	elif TMRW0JhwHFDn7Ko3qfLcbPv46a1=='ADD1'	: SNE2sLGQrF(F7nlDUR3o6V1rOMg)
	elif TMRW0JhwHFDn7Ko3qfLcbPv46a1=='REMOVE1': eetlV0NLqgTSbWMGmoJzjO1uKiEU7(F7nlDUR3o6V1rOMg)
	elif TMRW0JhwHFDn7Ko3qfLcbPv46a1=='DELETELIST': GLltvJoeusC6Z(F7nlDUR3o6V1rOMg)
	return
def XwvsYGlxEn5dSNybeJkBcg9(F7nlDUR3o6V1rOMg):
	Ggj8DCRVQfcApnONbZtlS9wB7Lm = ZTGzMyPwfKn79()
	if F7nlDUR3o6V1rOMg in list(Ggj8DCRVQfcApnONbZtlS9wB7Lm.keys()):
		try:
			oojCRW12KYVtrDImx5 = Ggj8DCRVQfcApnONbZtlS9wB7Lm[F7nlDUR3o6V1rOMg]
			if vvXoMLlg513 and F7nlDUR3o6V1rOMg in ['5','11','12','13']:
				for lQnA93TCSoqKwIMJNz8L,mMgEh8S9xkCA5atcIP4GWOJlpDdKQ,WWowRmHkj1ZAO2SUhtNvdrcKa9E6C,ZyiMa3BXVk2xWG0b,xCei3u0k2rAVK9o7zQcdZaGXT,aazJgfh6MTFGtP8SRoCDW9UZq,HY7yaJeI89xE56sbTjdBRZPDwQKFX,fdD0wQgTuni,mDgvl5LzhR26eNVM3UaIuHtpif in oojCRW12KYVtrDImx5:
					if lQnA93TCSoqKwIMJNz8L=='video':
						x3WSXnKyPhjqfHG2UrtQs('video',xupTj02bvy3O8R+'تشغيل من الأعلى إلى الأسفل'+fF4lt9zWYxXLKZVyAco82PgMj,WWowRmHkj1ZAO2SUhtNvdrcKa9E6C,ZyiMa3BXVk2xWG0b,xCei3u0k2rAVK9o7zQcdZaGXT,aazJgfh6MTFGtP8SRoCDW9UZq,HY7yaJeI89xE56sbTjdBRZPDwQKFX,fdD0wQgTuni)
						x3WSXnKyPhjqfHG2UrtQs('link',xupTj02bvy3O8R+' ===== ===== ===== '+fF4lt9zWYxXLKZVyAco82PgMj,qpFY4hAwolV3,9999)
						break
			for lQnA93TCSoqKwIMJNz8L,mMgEh8S9xkCA5atcIP4GWOJlpDdKQ,WWowRmHkj1ZAO2SUhtNvdrcKa9E6C,ZyiMa3BXVk2xWG0b,xCei3u0k2rAVK9o7zQcdZaGXT,aazJgfh6MTFGtP8SRoCDW9UZq,HY7yaJeI89xE56sbTjdBRZPDwQKFX,fdD0wQgTuni,mDgvl5LzhR26eNVM3UaIuHtpif in oojCRW12KYVtrDImx5:
				x3WSXnKyPhjqfHG2UrtQs(lQnA93TCSoqKwIMJNz8L,mMgEh8S9xkCA5atcIP4GWOJlpDdKQ,WWowRmHkj1ZAO2SUhtNvdrcKa9E6C,ZyiMa3BXVk2xWG0b,xCei3u0k2rAVK9o7zQcdZaGXT,aazJgfh6MTFGtP8SRoCDW9UZq,HY7yaJeI89xE56sbTjdBRZPDwQKFX,fdD0wQgTuni,mDgvl5LzhR26eNVM3UaIuHtpif)
		except:
			Ggj8DCRVQfcApnONbZtlS9wB7Lm = O8UnIZ9TiHSzXbvxGgs7wlR(V2JfszPWt6jq1hCxYKpyM53RL)
			oojCRW12KYVtrDImx5 = Ggj8DCRVQfcApnONbZtlS9wB7Lm[F7nlDUR3o6V1rOMg]
			for lQnA93TCSoqKwIMJNz8L,mMgEh8S9xkCA5atcIP4GWOJlpDdKQ,WWowRmHkj1ZAO2SUhtNvdrcKa9E6C,ZyiMa3BXVk2xWG0b,xCei3u0k2rAVK9o7zQcdZaGXT,aazJgfh6MTFGtP8SRoCDW9UZq,HY7yaJeI89xE56sbTjdBRZPDwQKFX,fdD0wQgTuni,mDgvl5LzhR26eNVM3UaIuHtpif in oojCRW12KYVtrDImx5:
				x3WSXnKyPhjqfHG2UrtQs(lQnA93TCSoqKwIMJNz8L,mMgEh8S9xkCA5atcIP4GWOJlpDdKQ,WWowRmHkj1ZAO2SUhtNvdrcKa9E6C,ZyiMa3BXVk2xWG0b,xCei3u0k2rAVK9o7zQcdZaGXT,aazJgfh6MTFGtP8SRoCDW9UZq,HY7yaJeI89xE56sbTjdBRZPDwQKFX,fdD0wQgTuni,mDgvl5LzhR26eNVM3UaIuHtpif)
	return
def SNE2sLGQrF(F7nlDUR3o6V1rOMg):
	lQnA93TCSoqKwIMJNz8L,mMgEh8S9xkCA5atcIP4GWOJlpDdKQ,WWowRmHkj1ZAO2SUhtNvdrcKa9E6C,ZyiMa3BXVk2xWG0b,xCei3u0k2rAVK9o7zQcdZaGXT,aazJgfh6MTFGtP8SRoCDW9UZq,HY7yaJeI89xE56sbTjdBRZPDwQKFX,fdD0wQgTuni,mDgvl5LzhR26eNVM3UaIuHtpif = GGhmwblaotTRZJCfcWDX50gxELS4(Ry9jtldkPEA)
	if F7nlDUR3o6V1rOMg in ['5','11','12','13'] and lQnA93TCSoqKwIMJNz8L!='video':
		iG7Rz2kmn0x1yLNMV3u8O('','',GLTtERWbHnFuy4PCp,'هذا العنصر ليس ملف فيديو .. قوائم التشغيل فائدتها تشغيل الفيديوهات خلف بعضها أوتوماتيكيا .. ولهذا قوائم التشغيل يجب أن تحتوي على فيديوهات فقط')
		return
	pNF0KZjukGYwd = lQnA93TCSoqKwIMJNz8L,mMgEh8S9xkCA5atcIP4GWOJlpDdKQ,WWowRmHkj1ZAO2SUhtNvdrcKa9E6C,ZyiMa3BXVk2xWG0b,xCei3u0k2rAVK9o7zQcdZaGXT,aazJgfh6MTFGtP8SRoCDW9UZq,HY7yaJeI89xE56sbTjdBRZPDwQKFX,qpFY4hAwolV3,mDgvl5LzhR26eNVM3UaIuHtpif
	Ggj8DCRVQfcApnONbZtlS9wB7Lm = ZTGzMyPwfKn79()
	CLJf8uchxNtzWprDkjU2Z = {}
	for vYxzVFkdK810ygJS9I6pD in list(Ggj8DCRVQfcApnONbZtlS9wB7Lm.keys()):
		if vYxzVFkdK810ygJS9I6pD!=F7nlDUR3o6V1rOMg: CLJf8uchxNtzWprDkjU2Z[vYxzVFkdK810ygJS9I6pD] = Ggj8DCRVQfcApnONbZtlS9wB7Lm[vYxzVFkdK810ygJS9I6pD]
		else:
			if mMgEh8S9xkCA5atcIP4GWOJlpDdKQ and mMgEh8S9xkCA5atcIP4GWOJlpDdKQ!='..':
				vvSGFzjWOAZcHd5kPxteRm29bET = Ggj8DCRVQfcApnONbZtlS9wB7Lm[vYxzVFkdK810ygJS9I6pD]
				if pNF0KZjukGYwd in vvSGFzjWOAZcHd5kPxteRm29bET:
					uuUgCzPxaq = vvSGFzjWOAZcHd5kPxteRm29bET.index(pNF0KZjukGYwd)
					del vvSGFzjWOAZcHd5kPxteRm29bET[uuUgCzPxaq]
				snGaXUQZmhb9g0AM1 = vvSGFzjWOAZcHd5kPxteRm29bET+[pNF0KZjukGYwd]
				CLJf8uchxNtzWprDkjU2Z[vYxzVFkdK810ygJS9I6pD] = snGaXUQZmhb9g0AM1
			else: CLJf8uchxNtzWprDkjU2Z[vYxzVFkdK810ygJS9I6pD] = Ggj8DCRVQfcApnONbZtlS9wB7Lm[vYxzVFkdK810ygJS9I6pD]
	if F7nlDUR3o6V1rOMg not in list(CLJf8uchxNtzWprDkjU2Z.keys()): CLJf8uchxNtzWprDkjU2Z[F7nlDUR3o6V1rOMg] = [pNF0KZjukGYwd]
	mMQq4ObPrtC1INcjfV3GzkUKHisyY = str(CLJf8uchxNtzWprDkjU2Z)
	if DLod2Of8CkRrtzJynev: mMQq4ObPrtC1INcjfV3GzkUKHisyY = mMQq4ObPrtC1INcjfV3GzkUKHisyY.encode(nV3Tip6XsH1rJw79DPOU)
	open(V2JfszPWt6jq1hCxYKpyM53RL,'wb').write(mMQq4ObPrtC1INcjfV3GzkUKHisyY)
	return
def eetlV0NLqgTSbWMGmoJzjO1uKiEU7(F7nlDUR3o6V1rOMg):
	lQnA93TCSoqKwIMJNz8L,mMgEh8S9xkCA5atcIP4GWOJlpDdKQ,WWowRmHkj1ZAO2SUhtNvdrcKa9E6C,ZyiMa3BXVk2xWG0b,xCei3u0k2rAVK9o7zQcdZaGXT,aazJgfh6MTFGtP8SRoCDW9UZq,HY7yaJeI89xE56sbTjdBRZPDwQKFX,fdD0wQgTuni,mDgvl5LzhR26eNVM3UaIuHtpif = GGhmwblaotTRZJCfcWDX50gxELS4(Ry9jtldkPEA)
	pNF0KZjukGYwd = lQnA93TCSoqKwIMJNz8L,mMgEh8S9xkCA5atcIP4GWOJlpDdKQ,WWowRmHkj1ZAO2SUhtNvdrcKa9E6C,ZyiMa3BXVk2xWG0b,xCei3u0k2rAVK9o7zQcdZaGXT,aazJgfh6MTFGtP8SRoCDW9UZq,HY7yaJeI89xE56sbTjdBRZPDwQKFX,qpFY4hAwolV3,mDgvl5LzhR26eNVM3UaIuHtpif
	Ggj8DCRVQfcApnONbZtlS9wB7Lm = ZTGzMyPwfKn79()
	if F7nlDUR3o6V1rOMg in list(Ggj8DCRVQfcApnONbZtlS9wB7Lm.keys()) and pNF0KZjukGYwd in Ggj8DCRVQfcApnONbZtlS9wB7Lm[F7nlDUR3o6V1rOMg]:
		Ggj8DCRVQfcApnONbZtlS9wB7Lm[F7nlDUR3o6V1rOMg].remove(pNF0KZjukGYwd)
		if len(Ggj8DCRVQfcApnONbZtlS9wB7Lm[F7nlDUR3o6V1rOMg])==vvXoMLlg513: del Ggj8DCRVQfcApnONbZtlS9wB7Lm[F7nlDUR3o6V1rOMg]
		mMQq4ObPrtC1INcjfV3GzkUKHisyY = str(Ggj8DCRVQfcApnONbZtlS9wB7Lm)
		if DLod2Of8CkRrtzJynev: mMQq4ObPrtC1INcjfV3GzkUKHisyY = mMQq4ObPrtC1INcjfV3GzkUKHisyY.encode(nV3Tip6XsH1rJw79DPOU)
		open(V2JfszPWt6jq1hCxYKpyM53RL,'wb').write(mMQq4ObPrtC1INcjfV3GzkUKHisyY)
	return
def YKPWb27nNVfJsXyDAS(F7nlDUR3o6V1rOMg,YRvIZs8wgF3ciOjM15xJlC,oNMLzHUikbfJ4nxQV53rYhPB):
	lQnA93TCSoqKwIMJNz8L,mMgEh8S9xkCA5atcIP4GWOJlpDdKQ,WWowRmHkj1ZAO2SUhtNvdrcKa9E6C,ZyiMa3BXVk2xWG0b,xCei3u0k2rAVK9o7zQcdZaGXT,aazJgfh6MTFGtP8SRoCDW9UZq,HY7yaJeI89xE56sbTjdBRZPDwQKFX,fdD0wQgTuni,mDgvl5LzhR26eNVM3UaIuHtpif = GGhmwblaotTRZJCfcWDX50gxELS4(Ry9jtldkPEA)
	pNF0KZjukGYwd = lQnA93TCSoqKwIMJNz8L,mMgEh8S9xkCA5atcIP4GWOJlpDdKQ,WWowRmHkj1ZAO2SUhtNvdrcKa9E6C,ZyiMa3BXVk2xWG0b,xCei3u0k2rAVK9o7zQcdZaGXT,aazJgfh6MTFGtP8SRoCDW9UZq,HY7yaJeI89xE56sbTjdBRZPDwQKFX,qpFY4hAwolV3,mDgvl5LzhR26eNVM3UaIuHtpif
	Ggj8DCRVQfcApnONbZtlS9wB7Lm = ZTGzMyPwfKn79()
	if F7nlDUR3o6V1rOMg in list(Ggj8DCRVQfcApnONbZtlS9wB7Lm.keys()):
		vvSGFzjWOAZcHd5kPxteRm29bET = Ggj8DCRVQfcApnONbZtlS9wB7Lm[F7nlDUR3o6V1rOMg]
		if pNF0KZjukGYwd not in vvSGFzjWOAZcHd5kPxteRm29bET: return
		KsmyZuaFUSd6P3AOwjhJ5MGogc = len(vvSGFzjWOAZcHd5kPxteRm29bET)
		for av3QBl1coTFsq9jLgydwf in range(vvXoMLlg513,oNMLzHUikbfJ4nxQV53rYhPB):
			wKtUM5F6OkQ = vvSGFzjWOAZcHd5kPxteRm29bET.index(pNF0KZjukGYwd)
			if YRvIZs8wgF3ciOjM15xJlC: Gh1dJSDjMC6O = wKtUM5F6OkQ-mZi0S72jGoHpLO
			else: Gh1dJSDjMC6O = wKtUM5F6OkQ+mZi0S72jGoHpLO
			if Gh1dJSDjMC6O>=KsmyZuaFUSd6P3AOwjhJ5MGogc: Gh1dJSDjMC6O = Gh1dJSDjMC6O-KsmyZuaFUSd6P3AOwjhJ5MGogc
			if Gh1dJSDjMC6O<vvXoMLlg513: Gh1dJSDjMC6O = Gh1dJSDjMC6O+KsmyZuaFUSd6P3AOwjhJ5MGogc
			vvSGFzjWOAZcHd5kPxteRm29bET.insert(Gh1dJSDjMC6O, vvSGFzjWOAZcHd5kPxteRm29bET.pop(wKtUM5F6OkQ))
		Ggj8DCRVQfcApnONbZtlS9wB7Lm[F7nlDUR3o6V1rOMg] = vvSGFzjWOAZcHd5kPxteRm29bET
		mMQq4ObPrtC1INcjfV3GzkUKHisyY = str(Ggj8DCRVQfcApnONbZtlS9wB7Lm)
		if DLod2Of8CkRrtzJynev: mMQq4ObPrtC1INcjfV3GzkUKHisyY = mMQq4ObPrtC1INcjfV3GzkUKHisyY.encode(nV3Tip6XsH1rJw79DPOU)
		open(V2JfszPWt6jq1hCxYKpyM53RL,'wb').write(mMQq4ObPrtC1INcjfV3GzkUKHisyY)
	return
def fmPCuwI01sa5cLS96XQ2Ob(F7nlDUR3o6V1rOMg):
	if F7nlDUR3o6V1rOMg in ['1','2','3','4']: xOv63ijNpWc2kw0ChPy8XoAgVfK9l,FwgirJAZuMVO4Ndjx6l = 'مفضلة',F7nlDUR3o6V1rOMg
	elif F7nlDUR3o6V1rOMg in ['5']: xOv63ijNpWc2kw0ChPy8XoAgVfK9l,FwgirJAZuMVO4Ndjx6l = 'تشغيل','1'
	elif F7nlDUR3o6V1rOMg in ['11']: xOv63ijNpWc2kw0ChPy8XoAgVfK9l,FwgirJAZuMVO4Ndjx6l = 'تشغيل','2'
	else: xOv63ijNpWc2kw0ChPy8XoAgVfK9l,FwgirJAZuMVO4Ndjx6l = qpFY4hAwolV3,qpFY4hAwolV3
	wxKGIMeL0Pl3Zf = xOv63ijNpWc2kw0ChPy8XoAgVfK9l+mIsDke0oK5x1zSiOWbF9thGcA+FwgirJAZuMVO4Ndjx6l
	return wxKGIMeL0Pl3Zf
def GLltvJoeusC6Z(F7nlDUR3o6V1rOMg):
	wxKGIMeL0Pl3Zf = fmPCuwI01sa5cLS96XQ2Ob(F7nlDUR3o6V1rOMg)
	fN4Cnx6kjp = VVpbtSKYUGXrNMwAWFo9IOjZP('center',qpFY4hAwolV3,qpFY4hAwolV3,GLTtERWbHnFuy4PCp,'هل تريد فعلا مسح جميع محتويات قائمة '+wxKGIMeL0Pl3Zf+' ؟!')
	if fN4Cnx6kjp!=1: return
	Ggj8DCRVQfcApnONbZtlS9wB7Lm = ZTGzMyPwfKn79()
	if F7nlDUR3o6V1rOMg in list(Ggj8DCRVQfcApnONbZtlS9wB7Lm.keys()):
		del Ggj8DCRVQfcApnONbZtlS9wB7Lm[F7nlDUR3o6V1rOMg]
		mMQq4ObPrtC1INcjfV3GzkUKHisyY = str(Ggj8DCRVQfcApnONbZtlS9wB7Lm)
		if DLod2Of8CkRrtzJynev: mMQq4ObPrtC1INcjfV3GzkUKHisyY = mMQq4ObPrtC1INcjfV3GzkUKHisyY.encode(nV3Tip6XsH1rJw79DPOU)
		open(V2JfszPWt6jq1hCxYKpyM53RL,'wb').write(mMQq4ObPrtC1INcjfV3GzkUKHisyY)
		iG7Rz2kmn0x1yLNMV3u8O(qpFY4hAwolV3,qpFY4hAwolV3,GLTtERWbHnFuy4PCp,'تم مسح جميع محتويات قائمة '+wxKGIMeL0Pl3Zf)
	return
def ZTGzMyPwfKn79():
	Ggj8DCRVQfcApnONbZtlS9wB7Lm = {}
	if RPbaxsNFVTwek5Kfv21DiJuzCnjMZp.path.exists(V2JfszPWt6jq1hCxYKpyM53RL):
		ZnGCqfrk0mseT8h2jpwYRWPIK = open(V2JfszPWt6jq1hCxYKpyM53RL,'rb').read()
		if DLod2Of8CkRrtzJynev: ZnGCqfrk0mseT8h2jpwYRWPIK = ZnGCqfrk0mseT8h2jpwYRWPIK.decode(nV3Tip6XsH1rJw79DPOU)
		Ggj8DCRVQfcApnONbZtlS9wB7Lm = wB8NUAidPbqjIr9CFasXvYnxOQpL0g('dict',ZnGCqfrk0mseT8h2jpwYRWPIK)
	return Ggj8DCRVQfcApnONbZtlS9wB7Lm
def ddPaUKj765q3mJh8EWzDQln241(Ggj8DCRVQfcApnONbZtlS9wB7Lm,pNF0KZjukGYwd,q0arK1mxVoX):
	lQnA93TCSoqKwIMJNz8L,mMgEh8S9xkCA5atcIP4GWOJlpDdKQ,WWowRmHkj1ZAO2SUhtNvdrcKa9E6C,ZyiMa3BXVk2xWG0b,xCei3u0k2rAVK9o7zQcdZaGXT,aazJgfh6MTFGtP8SRoCDW9UZq,HY7yaJeI89xE56sbTjdBRZPDwQKFX,fdD0wQgTuni,mDgvl5LzhR26eNVM3UaIuHtpif = pNF0KZjukGYwd
	if not ZyiMa3BXVk2xWG0b: lQnA93TCSoqKwIMJNz8L,ZyiMa3BXVk2xWG0b = 'folder','260'
	LU9jR08vNcAFdxbKw15JGq,F7nlDUR3o6V1rOMg = [],qpFY4hAwolV3
	if 'context=' in Ry9jtldkPEA:
		K0unsIl8CvgDr7EQAFwNm3hL = ePhmG1jLD6.findall('context=(\d+)',Ry9jtldkPEA,ePhmG1jLD6.DOTALL)
		if K0unsIl8CvgDr7EQAFwNm3hL: F7nlDUR3o6V1rOMg = str(K0unsIl8CvgDr7EQAFwNm3hL[vvXoMLlg513])
	if ZyiMa3BXVk2xWG0b=='270':
		F7nlDUR3o6V1rOMg = fdD0wQgTuni
		if F7nlDUR3o6V1rOMg in list(Ggj8DCRVQfcApnONbZtlS9wB7Lm.keys()):
			wxKGIMeL0Pl3Zf = fmPCuwI01sa5cLS96XQ2Ob(F7nlDUR3o6V1rOMg)
			LU9jR08vNcAFdxbKw15JGq.append(('مسح قائمة '+wxKGIMeL0Pl3Zf,'RunPlugin('+q0arK1mxVoX+'&context='+F7nlDUR3o6V1rOMg+'_DELETELIST'+')'))
	else:
		if F7nlDUR3o6V1rOMg in list(Ggj8DCRVQfcApnONbZtlS9wB7Lm.keys()):
			count = len(Ggj8DCRVQfcApnONbZtlS9wB7Lm[F7nlDUR3o6V1rOMg])
			if count>mZi0S72jGoHpLO: LU9jR08vNcAFdxbKw15JGq.append(('تحريك 1 للأعلى','RunPlugin('+q0arK1mxVoX+'&context='+F7nlDUR3o6V1rOMg+'_UP1)'))
			if count>wn4bG51vUENfaS0Zg: LU9jR08vNcAFdxbKw15JGq.append(('تحريك 4 للأعلى','RunPlugin('+q0arK1mxVoX+'&context='+F7nlDUR3o6V1rOMg+'_UP4)'))
			if count>mZi0S72jGoHpLO: LU9jR08vNcAFdxbKw15JGq.append(('تحريك 1 للأسفل','RunPlugin('+q0arK1mxVoX+'&context='+F7nlDUR3o6V1rOMg+'_DOWN1)'))
			if count>wn4bG51vUENfaS0Zg: LU9jR08vNcAFdxbKw15JGq.append(('تحريك 4 للأسفل','RunPlugin('+q0arK1mxVoX+'&context='+F7nlDUR3o6V1rOMg+'_DOWN4)'))
		for F7nlDUR3o6V1rOMg in ['1','2','3','4','5','11']:
			wxKGIMeL0Pl3Zf = fmPCuwI01sa5cLS96XQ2Ob(F7nlDUR3o6V1rOMg)
			if F7nlDUR3o6V1rOMg in list(Ggj8DCRVQfcApnONbZtlS9wB7Lm.keys()) and pNF0KZjukGYwd in Ggj8DCRVQfcApnONbZtlS9wB7Lm[F7nlDUR3o6V1rOMg]:
				LU9jR08vNcAFdxbKw15JGq.append(('مسح من '+wxKGIMeL0Pl3Zf,'RunPlugin('+q0arK1mxVoX+'&context='+F7nlDUR3o6V1rOMg+'_REMOVE1)'))
			else: LU9jR08vNcAFdxbKw15JGq.append(('إضافة ل'+wxKGIMeL0Pl3Zf,'RunPlugin('+q0arK1mxVoX+'&context='+F7nlDUR3o6V1rOMg+'_ADD1)'))
	KvP4g8UWph = []
	for hMp3wZCS0WzXs,MG7bZY0Dkn6m8uJPRzCUSxX9We in LU9jR08vNcAFdxbKw15JGq:
		hMp3wZCS0WzXs = IQ2KCmObsTGuiRdEzt931a40jLg+hMp3wZCS0WzXs+fF4lt9zWYxXLKZVyAco82PgMj
		KvP4g8UWph.append((hMp3wZCS0WzXs,MG7bZY0Dkn6m8uJPRzCUSxX9We,))
	return KvP4g8UWph