# -*- coding: utf-8 -*-
from pSfaryIjBo import *
Q8Q0IDc6PLZajJAdTntKUmSGXz = 'EGYBEST3'
wwSFijdVJn1QgHW = '_EB3_'
ddBxj51bhNtaK23lDyGMVw = i4bFG3rKE6.SITESURLS[Q8Q0IDc6PLZajJAdTntKUmSGXz][0]
YEIA19ehBwpNfPVzK = ['المصارعة الحرة','ايجي بست','التصميم الجديد','عروض المصارعة','مكتبتي','ايجي بست الجديد','ايجي بست البديل','egybest','موقع ايجي بست','موقع نتفليكس']
def vTNE2Ck1sGnugJYW8y39aLcSH64U(mode,url,i02wfPp5EM,text):
	if   mode==790: MOTjA5H9XFs = nRVAZc4Dp8PSrGU3xBk()
	elif mode==791: MOTjA5H9XFs = c8U1BdtxOZS5FH(url,i02wfPp5EM)
	elif mode==792: MOTjA5H9XFs = X2rO3lubqIdCGMLYWcxA6DK5(url)
	elif mode==793: MOTjA5H9XFs = mzcAeyplZV(url)
	elif mode==796: MOTjA5H9XFs = eewkhcztmSDWKrPIX(url,i02wfPp5EM)
	elif mode==799: MOTjA5H9XFs = PPqUACSE3VcGLTvw05jHy9JrFNW(text)
	else: MOTjA5H9XFs = False
	return MOTjA5H9XFs
def nRVAZc4Dp8PSrGU3xBk():
	IAW0sh6So3NpqM = WWrExJZS3Bj4anOAkpv7(KOyPvpEztYLaZRdMQJWxfTNFHbkg,'GET',ddBxj51bhNtaK23lDyGMVw,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,'EGYBEST3-MENU-1st')
	cmWl9dOKHPIy41iaXuxrY = IAW0sh6So3NpqM.content
	pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('list-pages(.*?)fa-folder',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	if pfRkcVlLmUxo561g0A8qSbO:
		mVYdjvor6i4wZ8 = pfRkcVlLmUxo561g0A8qSbO[0]
		items = ePhmG1jLD6.findall('href="(.*?)".*?<span>(.*?)</span>',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
		for MepIvHBYNArkUOdV37shtJ,title in items:
			title = title.strip(mIsDke0oK5x1zSiOWbF9thGcA)
			if any(value in title for value in YEIA19ehBwpNfPVzK): continue
			if 'http' not in MepIvHBYNArkUOdV37shtJ: MepIvHBYNArkUOdV37shtJ = ddBxj51bhNtaK23lDyGMVw+MepIvHBYNArkUOdV37shtJ
			x3WSXnKyPhjqfHG2UrtQs('folder',Q8Q0IDc6PLZajJAdTntKUmSGXz+'_SCRIPT_'+wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,791)
		x3WSXnKyPhjqfHG2UrtQs('link',xupTj02bvy3O8R+' ===== ===== ===== '+fF4lt9zWYxXLKZVyAco82PgMj,qpFY4hAwolV3,9999)
	pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('main-article(.*?)social-box',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	if pfRkcVlLmUxo561g0A8qSbO:
		mVYdjvor6i4wZ8 = pfRkcVlLmUxo561g0A8qSbO[0]
		items = ePhmG1jLD6.findall('main-title.*?">(.*?)<.*?href="(.*?)"',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
		for title,MepIvHBYNArkUOdV37shtJ in items:
			title = title.strip(mIsDke0oK5x1zSiOWbF9thGcA)
			if any(value in title for value in YEIA19ehBwpNfPVzK): continue
			if 'http' not in MepIvHBYNArkUOdV37shtJ: MepIvHBYNArkUOdV37shtJ = ddBxj51bhNtaK23lDyGMVw+MepIvHBYNArkUOdV37shtJ
			x3WSXnKyPhjqfHG2UrtQs('folder',Q8Q0IDc6PLZajJAdTntKUmSGXz+'_SCRIPT_'+wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,791,qpFY4hAwolV3,'mainmenu')
		x3WSXnKyPhjqfHG2UrtQs('link',xupTj02bvy3O8R+' ===== ===== ===== '+fF4lt9zWYxXLKZVyAco82PgMj,qpFY4hAwolV3,9999)
	pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('main-menu(.*?)</ul>',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	if pfRkcVlLmUxo561g0A8qSbO:
		mVYdjvor6i4wZ8 = pfRkcVlLmUxo561g0A8qSbO[0]
		items = ePhmG1jLD6.findall('href="(.*?)">(.*?)<',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
		for MepIvHBYNArkUOdV37shtJ,title in items:
			title = title.strip(mIsDke0oK5x1zSiOWbF9thGcA)
			if any(value in title for value in YEIA19ehBwpNfPVzK): continue
			if 'http' not in MepIvHBYNArkUOdV37shtJ: MepIvHBYNArkUOdV37shtJ = ddBxj51bhNtaK23lDyGMVw+MepIvHBYNArkUOdV37shtJ
			x3WSXnKyPhjqfHG2UrtQs('folder',Q8Q0IDc6PLZajJAdTntKUmSGXz+'_SCRIPT_'+wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,791)
	return cmWl9dOKHPIy41iaXuxrY
def eewkhcztmSDWKrPIX(url,type=qpFY4hAwolV3):
	IAW0sh6So3NpqM = WWrExJZS3Bj4anOAkpv7(kUz8c7OqsxuPFIGfwg,'GET',url,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,'EGYBEST3-SEASONS_EPISODES-1st')
	cmWl9dOKHPIy41iaXuxrY = IAW0sh6So3NpqM.content
	pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('main-article".*?">(.*?)<(.*?)article',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	if pfRkcVlLmUxo561g0A8qSbO:
		WWQOoJZpXFmLHnDht1j,pzLc3HwImv2dru,items = qpFY4hAwolV3,qpFY4hAwolV3,[]
		for name,mVYdjvor6i4wZ8 in pfRkcVlLmUxo561g0A8qSbO:
			if 'حلقات' in name: pzLc3HwImv2dru = mVYdjvor6i4wZ8
			if 'مواسم' in name: WWQOoJZpXFmLHnDht1j = mVYdjvor6i4wZ8
		if WWQOoJZpXFmLHnDht1j and not type:
			items = ePhmG1jLD6.findall('href="(.*?)".*?data-src="(.*?)".*?"title">(.*?)<',WWQOoJZpXFmLHnDht1j,ePhmG1jLD6.DOTALL)
			if len(items)>1:
				for MepIvHBYNArkUOdV37shtJ,Sj7rMNYRuQPTtkBvpHKeDW3h,title in items:
					x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,796,Sj7rMNYRuQPTtkBvpHKeDW3h,'season')
		if pzLc3HwImv2dru and len(items)<2:
			items = ePhmG1jLD6.findall('href="(.*?)".*?data-src="(.*?)".*?class="title">(.*?)<',pzLc3HwImv2dru,ePhmG1jLD6.DOTALL)
			if items:
				for MepIvHBYNArkUOdV37shtJ,Sj7rMNYRuQPTtkBvpHKeDW3h,title in items:
					x3WSXnKyPhjqfHG2UrtQs('video',wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,793,Sj7rMNYRuQPTtkBvpHKeDW3h)
			else:
				items = ePhmG1jLD6.findall('href="(.*?)">(.*?)<',pzLc3HwImv2dru,ePhmG1jLD6.DOTALL)
				for MepIvHBYNArkUOdV37shtJ,title in items:
					x3WSXnKyPhjqfHG2UrtQs('video',wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,793)
	return
def c8U1BdtxOZS5FH(url,type=qpFY4hAwolV3):
	SRumox0JwQpaA8MidjtKLPe,start,kJ358BIeXtYvzn,select,bjnCmiwSGHJlrL8qo = 0,0,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3
	if 'pagination' in type:
		MMfLBt5gmXl40KWdcbTvoxQnYR,data = D02sQSgOGhTJxtKyFEId74Nrv8bYU(url)
		SRumox0JwQpaA8MidjtKLPe = int(data['limit'])
		start = int(data['start'])
		kJ358BIeXtYvzn = data['type']
		select = data['select']
		RZ2SwHp6GQvAy = 'limit='+str(SRumox0JwQpaA8MidjtKLPe)+'&start='+str(start)+'&type='+kJ358BIeXtYvzn+'&select='+select
		skD7g3FxW4wCa5BR = {'Content-Type':'application/x-www-form-urlencoded'}
		IAW0sh6So3NpqM = WWrExJZS3Bj4anOAkpv7(kUz8c7OqsxuPFIGfwg,'POST',MMfLBt5gmXl40KWdcbTvoxQnYR,RZ2SwHp6GQvAy,skD7g3FxW4wCa5BR,qpFY4hAwolV3,qpFY4hAwolV3,'EGYBEST3-TITLES-1st')
		cmWl9dOKHPIy41iaXuxrY = IAW0sh6So3NpqM.content
		CC8IKXmYeo = 'blocks'+cmWl9dOKHPIy41iaXuxrY+'article'
	else:
		IAW0sh6So3NpqM = WWrExJZS3Bj4anOAkpv7(kUz8c7OqsxuPFIGfwg,'GET',url,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,'EGYBEST3-TITLES-2nd')
		cmWl9dOKHPIy41iaXuxrY = IAW0sh6So3NpqM.content
		CC8IKXmYeo = cmWl9dOKHPIy41iaXuxrY
		code = ePhmG1jLD6.findall("<script>(var.*?=.*?;var.*?=.*?;var.*?=.*?;var.*?=.*?;var.*?=.*?);</script>",cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
		if code:
			code = code[0].replace('var',qpFY4hAwolV3).replace(mIsDke0oK5x1zSiOWbF9thGcA,qpFY4hAwolV3).replace("'",qpFY4hAwolV3).replace(';','&')
			oF67yxKdB8nY3TiH9gAMvlOhaPSws0,data = D02sQSgOGhTJxtKyFEId74Nrv8bYU('?'+code)
			SRumox0JwQpaA8MidjtKLPe = int(data['limit'])
			start = int(data['start'])
			kJ358BIeXtYvzn = data['type']
			select = data['select']
			bjnCmiwSGHJlrL8qo = data['ajaxurl']
			RZ2SwHp6GQvAy = 'limit='+str(SRumox0JwQpaA8MidjtKLPe)+'&start='+str(start)+'&type='+kJ358BIeXtYvzn+'&select='+select
			MMfLBt5gmXl40KWdcbTvoxQnYR = ddBxj51bhNtaK23lDyGMVw+bjnCmiwSGHJlrL8qo
			skD7g3FxW4wCa5BR = {'Content-Type':'application/x-www-form-urlencoded'}
			IAW0sh6So3NpqM = WWrExJZS3Bj4anOAkpv7(kUz8c7OqsxuPFIGfwg,'POST',MMfLBt5gmXl40KWdcbTvoxQnYR,RZ2SwHp6GQvAy,skD7g3FxW4wCa5BR,qpFY4hAwolV3,qpFY4hAwolV3,'EGYBEST3-TITLES-3rd')
			CC8IKXmYeo = IAW0sh6So3NpqM.content
			CC8IKXmYeo = 'blocks'+CC8IKXmYeo+'article'
	items,Iun1xvJFmCopwhd0XbH9BqPgMAV7Zt,bbaYxjcVnksy = [],False,False
	if not type:
		pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('main-content(.*?)</div>',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
		if pfRkcVlLmUxo561g0A8qSbO:
			mVYdjvor6i4wZ8 = pfRkcVlLmUxo561g0A8qSbO[0]
			items = ePhmG1jLD6.findall('href="(.*?)".*?</i>(.*?)</a>',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
			for MepIvHBYNArkUOdV37shtJ,title in items:
				title = title.strip(mIsDke0oK5x1zSiOWbF9thGcA)
				x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,791,qpFY4hAwolV3,'submenu')
				Iun1xvJFmCopwhd0XbH9BqPgMAV7Zt = True
	if not type:
		bbaYxjcVnksy = nIDfHyeBjxrkwYO8v2dAPNTuqUK(cmWl9dOKHPIy41iaXuxrY)
	if not Iun1xvJFmCopwhd0XbH9BqPgMAV7Zt and not bbaYxjcVnksy:
		pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('blocks(.*?)article',CC8IKXmYeo,ePhmG1jLD6.DOTALL)
		if pfRkcVlLmUxo561g0A8qSbO:
			mVYdjvor6i4wZ8 = pfRkcVlLmUxo561g0A8qSbO[0]
			items = ePhmG1jLD6.findall('href="(.*?)".*?src="(.*?)".*?class="title">(.*?)<',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
			for MepIvHBYNArkUOdV37shtJ,Sj7rMNYRuQPTtkBvpHKeDW3h,title in items:
				Sj7rMNYRuQPTtkBvpHKeDW3h = Sj7rMNYRuQPTtkBvpHKeDW3h.strip(ZLwoRpfnCWI7FgEHsz6te39lMVh)
				MepIvHBYNArkUOdV37shtJ = cTt4u6reEMKZqVLplmkNW7(MepIvHBYNArkUOdV37shtJ)
				if '/selary/' in MepIvHBYNArkUOdV37shtJ: x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,791,Sj7rMNYRuQPTtkBvpHKeDW3h)
				elif 'مسلسل' in MepIvHBYNArkUOdV37shtJ and 'حلقة' not in MepIvHBYNArkUOdV37shtJ: x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,796,Sj7rMNYRuQPTtkBvpHKeDW3h)
				elif 'موسم' in MepIvHBYNArkUOdV37shtJ and 'حلقة' not in MepIvHBYNArkUOdV37shtJ: x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,796,Sj7rMNYRuQPTtkBvpHKeDW3h)
				else: x3WSXnKyPhjqfHG2UrtQs('video',wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,793,Sj7rMNYRuQPTtkBvpHKeDW3h)
		denzA2syBrtfKGZ7gER = 12
		data = ePhmG1jLD6.findall('class="(load-more.*?)<',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
		if len(items)==denzA2syBrtfKGZ7gER and (data or 'pagination' in type):
			RZ2SwHp6GQvAy = 'limit='+str(denzA2syBrtfKGZ7gER)+'&start='+str(start+denzA2syBrtfKGZ7gER)+'&type='+kJ358BIeXtYvzn+'&select='+select
			WSQlG8mDhqsNe = MMfLBt5gmXl40KWdcbTvoxQnYR+'?next=page&'+RZ2SwHp6GQvAy
			x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+'المزيد',WSQlG8mDhqsNe,791,qpFY4hAwolV3,'pagination_'+type)
	return
def nIDfHyeBjxrkwYO8v2dAPNTuqUK(cmWl9dOKHPIy41iaXuxrY):
	bbaYxjcVnksy = False
	pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('main-article(.*?)article',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	if pfRkcVlLmUxo561g0A8qSbO:
		mVYdjvor6i4wZ8 = pfRkcVlLmUxo561g0A8qSbO[0]
		HLVwBWJ6mFa3ApoNlq178nuXgI = ePhmG1jLD6.findall('data-tax="(.*?)".*?<span>(.*?)<(.*?)</ul>',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
		if HLVwBWJ6mFa3ApoNlq178nuXgI: x3WSXnKyPhjqfHG2UrtQs('link',xupTj02bvy3O8R+' ===== ===== ===== '+fF4lt9zWYxXLKZVyAco82PgMj,qpFY4hAwolV3,9999)
		for n1uwH0oJaGZ5WBd,name,mVYdjvor6i4wZ8 in HLVwBWJ6mFa3ApoNlq178nuXgI:
			name = name.strip(mIsDke0oK5x1zSiOWbF9thGcA)
			items = ePhmG1jLD6.findall('href="(.*?)">(.*?)<',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
			for MepIvHBYNArkUOdV37shtJ,value in items:
				title = name+':  '+value
				x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,791,qpFY4hAwolV3,'filter')
				bbaYxjcVnksy = True
	return bbaYxjcVnksy
def mzcAeyplZV(url):
	IAW0sh6So3NpqM = WWrExJZS3Bj4anOAkpv7(dzcNuIbsgK3yZ6SXGaEHPfOj5vk,'GET',url,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,'EGYBEST3-PLAY-1st')
	cmWl9dOKHPIy41iaXuxrY = IAW0sh6So3NpqM.content
	tiYp9ZdbFTQMcB4vWkHw6LXIAKrN5m,GSFxVaA5P1pd9D = [],[]
	items = ePhmG1jLD6.findall('server-item.*?data-code="(.*?)"',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	for t9WewROA6I1GjVzu5mF in items:
		aar4x9BsSXyVJv = PP0Gxazjw86.b64decode(t9WewROA6I1GjVzu5mF)
		if DLod2Of8CkRrtzJynev: aar4x9BsSXyVJv = aar4x9BsSXyVJv.decode(nV3Tip6XsH1rJw79DPOU)
		MepIvHBYNArkUOdV37shtJ = ePhmG1jLD6.findall('src="(.*?)"',aar4x9BsSXyVJv,ePhmG1jLD6.DOTALL)
		if MepIvHBYNArkUOdV37shtJ:
			MepIvHBYNArkUOdV37shtJ = MepIvHBYNArkUOdV37shtJ[0]
			if MepIvHBYNArkUOdV37shtJ not in GSFxVaA5P1pd9D:
				GSFxVaA5P1pd9D.append(MepIvHBYNArkUOdV37shtJ)
				XPNkVcWFUr = AWeJuo2LhZ5xiD8KNSqd9G0rtT74FE(MepIvHBYNArkUOdV37shtJ,'name')
				tiYp9ZdbFTQMcB4vWkHw6LXIAKrN5m.append(MepIvHBYNArkUOdV37shtJ+'?named='+XPNkVcWFUr+'__watch')
	pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('class="downloads(.*?)</section>',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	if pfRkcVlLmUxo561g0A8qSbO:
		mVYdjvor6i4wZ8 = pfRkcVlLmUxo561g0A8qSbO[0]
		items = ePhmG1jLD6.findall('"tr flex-start".*?<div>[ a-zA-Z]*(\d{3,4})[ a-zA-Z]*</div>.*?href="(.*?)"',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
		for Mrp5ZdGHFv9Xi6mkxfac3JDB,MepIvHBYNArkUOdV37shtJ in items:
			if MepIvHBYNArkUOdV37shtJ not in GSFxVaA5P1pd9D:
				if '/?url=' in MepIvHBYNArkUOdV37shtJ: MepIvHBYNArkUOdV37shtJ = MepIvHBYNArkUOdV37shtJ.split('/?url=')[1]
				GSFxVaA5P1pd9D.append(MepIvHBYNArkUOdV37shtJ)
				XPNkVcWFUr = AWeJuo2LhZ5xiD8KNSqd9G0rtT74FE(MepIvHBYNArkUOdV37shtJ,'name')
				tiYp9ZdbFTQMcB4vWkHw6LXIAKrN5m.append(MepIvHBYNArkUOdV37shtJ+'?named='+XPNkVcWFUr+'__download____'+Mrp5ZdGHFv9Xi6mkxfac3JDB)
	import inVXFK46ET
	inVXFK46ET.q4qTJvuoQUzM3mZAtegy7IXdnb5wH(tiYp9ZdbFTQMcB4vWkHw6LXIAKrN5m,Q8Q0IDc6PLZajJAdTntKUmSGXz,'video',url)
	return
def PPqUACSE3VcGLTvw05jHy9JrFNW(text):
	return