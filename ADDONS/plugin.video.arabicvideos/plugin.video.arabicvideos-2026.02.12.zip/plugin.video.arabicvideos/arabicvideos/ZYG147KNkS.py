# -*- coding: utf-8 -*-
from pSfaryIjBo import *
headers = { 'User-Agent' : qpFY4hAwolV3 }
Q8Q0IDc6PLZajJAdTntKUmSGXz = 'AKWAM'
wwSFijdVJn1QgHW = '_AKW_'
ddBxj51bhNtaK23lDyGMVw = i4bFG3rKE6.SITESURLS[Q8Q0IDc6PLZajJAdTntKUmSGXz][0]
hlNKJiB6gAuGzxtdT7QDV2sP = qpFY4hAwolV3
YEIA19ehBwpNfPVzK = ['ألعاب','المصارعة الحرة','القران الكريم','الكتب و الابحاث','الصور و الخلفيات','المسلسلات الاذاعية']
def vTNE2Ck1sGnugJYW8y39aLcSH64U(mode,url,text):
	if   mode==240: MOTjA5H9XFs = nRVAZc4Dp8PSrGU3xBk()
	elif mode==241: MOTjA5H9XFs = c8U1BdtxOZS5FH(url,text)
	elif mode==242: MOTjA5H9XFs = v1gmfxDcRrWKQ(url)
	elif mode==243: MOTjA5H9XFs = mzcAeyplZV(url)
	elif mode==244: MOTjA5H9XFs = R9pWUgVhBGLd2CQb0z(url,'FILTERS___'+text)
	elif mode==245: MOTjA5H9XFs = R9pWUgVhBGLd2CQb0z(url,'CATEGORIES___'+text)
	elif mode==246: MOTjA5H9XFs = TTeJxDswtly1q(url)
	elif mode==247: MOTjA5H9XFs = ITbnr8vt6KykEOwY0l7SzAfCDQmaJg(url)
	elif mode==248: MOTjA5H9XFs = x1VJ7CS0Esj()
	elif mode==249: MOTjA5H9XFs = PPqUACSE3VcGLTvw05jHy9JrFNW(text)
	else: MOTjA5H9XFs = False
	return MOTjA5H9XFs
def x1VJ7CS0Esj():
	iG7Rz2kmn0x1yLNMV3u8O(qpFY4hAwolV3,qpFY4hAwolV3,GLTtERWbHnFuy4PCp,'هذا الموقع "أكوام الجديد" في بعض الأحيان فيه نوع من الحجب ضد البرامج . وهذا يسبب مشكلة في تشغيل الفيديوهات . هذه المشكلة سببها من الموقع الأصلي وهي تظهر وتختفي بصورة عشوائية')
	return
def nRVAZc4Dp8PSrGU3xBk():
	IAW0sh6So3NpqM = WWrExJZS3Bj4anOAkpv7(kUz8c7OqsxuPFIGfwg,'GET',ddBxj51bhNtaK23lDyGMVw,qpFY4hAwolV3,headers,qpFY4hAwolV3,qpFY4hAwolV3,'AKWAM-MENU-1st')
	cmWl9dOKHPIy41iaXuxrY = IAW0sh6So3NpqM.content
	BhHm0jrokRlnpQIN1qwcS9Ei3 = ePhmG1jLD6.findall('home-site-btn-container.*?href="(.*?)"',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	if BhHm0jrokRlnpQIN1qwcS9Ei3: BhHm0jrokRlnpQIN1qwcS9Ei3 = BhHm0jrokRlnpQIN1qwcS9Ei3[0]
	else: BhHm0jrokRlnpQIN1qwcS9Ei3 = ddBxj51bhNtaK23lDyGMVw
	IAW0sh6So3NpqM = WWrExJZS3Bj4anOAkpv7(kUz8c7OqsxuPFIGfwg,'GET',BhHm0jrokRlnpQIN1qwcS9Ei3,qpFY4hAwolV3,headers,qpFY4hAwolV3,qpFY4hAwolV3,'AKWAM-MENU-2nd')
	cmWl9dOKHPIy41iaXuxrY = IAW0sh6So3NpqM.content
	x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+'بحث في الموقع',qpFY4hAwolV3,249,qpFY4hAwolV3,qpFY4hAwolV3,'_REMEMBERRESULTS_')
	x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+'فلتر محدد',ddBxj51bhNtaK23lDyGMVw,246)
	x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+'فلتر كامل',ddBxj51bhNtaK23lDyGMVw,247)
	x3WSXnKyPhjqfHG2UrtQs('link',xupTj02bvy3O8R+' ===== ===== ===== '+fF4lt9zWYxXLKZVyAco82PgMj,qpFY4hAwolV3,9999)
	x3WSXnKyPhjqfHG2UrtQs('folder',Q8Q0IDc6PLZajJAdTntKUmSGXz+'_SCRIPT_'+wwSFijdVJn1QgHW+'المميزة',BhHm0jrokRlnpQIN1qwcS9Ei3,241,qpFY4hAwolV3,qpFY4hAwolV3,'featured')
	M5Iz1HeLA3mlSW6uRUChv9PrZ = ePhmG1jLD6.findall('recently-container.*?href="(.*?)"',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	MepIvHBYNArkUOdV37shtJ = M5Iz1HeLA3mlSW6uRUChv9PrZ[0]
	x3WSXnKyPhjqfHG2UrtQs('folder',Q8Q0IDc6PLZajJAdTntKUmSGXz+'_SCRIPT_'+wwSFijdVJn1QgHW+'أضيف حديثا',MepIvHBYNArkUOdV37shtJ,241)
	x3WSXnKyPhjqfHG2UrtQs('link',xupTj02bvy3O8R+' ===== ===== ===== '+fF4lt9zWYxXLKZVyAco82PgMj,qpFY4hAwolV3,9999)
	pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('mb-4 d-flex align-items-center.*?href="(.*?)".*?class="header-link text-white">(.*?)<.*?class="menu"(.*?)</div>',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	for MepIvHBYNArkUOdV37shtJ,name,mVYdjvor6i4wZ8 in pfRkcVlLmUxo561g0A8qSbO:
		if name in YEIA19ehBwpNfPVzK: continue
		x3WSXnKyPhjqfHG2UrtQs('folder',Q8Q0IDc6PLZajJAdTntKUmSGXz+'_SCRIPT_'+wwSFijdVJn1QgHW+name,MepIvHBYNArkUOdV37shtJ,241)
		items = ePhmG1jLD6.findall('href="(.*?)">(.*?)<',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
		for MepIvHBYNArkUOdV37shtJ,title in items:
			if title in YEIA19ehBwpNfPVzK: continue
			title = name+mIsDke0oK5x1zSiOWbF9thGcA+title
			x3WSXnKyPhjqfHG2UrtQs('folder',Q8Q0IDc6PLZajJAdTntKUmSGXz+'_SCRIPT_'+wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,241)
	return
def TTeJxDswtly1q(website=qpFY4hAwolV3):
	cmWl9dOKHPIy41iaXuxrY = GMqfDK9V4F8eTPE1pNOAaiYUbhr(KOyPvpEztYLaZRdMQJWxfTNFHbkg,ddBxj51bhNtaK23lDyGMVw,qpFY4hAwolV3,headers,qpFY4hAwolV3,'AKWAM-MENU-1st')
	pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('class="menu(.*?)<nav',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	if pfRkcVlLmUxo561g0A8qSbO:
		mVYdjvor6i4wZ8 = pfRkcVlLmUxo561g0A8qSbO[0]
		items = ePhmG1jLD6.findall('href="(.*?)".*?text">(.*?)<',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
		for MepIvHBYNArkUOdV37shtJ,title in items:
			if title not in YEIA19ehBwpNfPVzK:
				title = title+' مصنفة'
				x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,245)
		if website==qpFY4hAwolV3: x3WSXnKyPhjqfHG2UrtQs('link',xupTj02bvy3O8R+' ===== ===== ===== '+fF4lt9zWYxXLKZVyAco82PgMj,qpFY4hAwolV3,9999)
	return cmWl9dOKHPIy41iaXuxrY
def ITbnr8vt6KykEOwY0l7SzAfCDQmaJg(website=qpFY4hAwolV3):
	cmWl9dOKHPIy41iaXuxrY = GMqfDK9V4F8eTPE1pNOAaiYUbhr(KOyPvpEztYLaZRdMQJWxfTNFHbkg,ddBxj51bhNtaK23lDyGMVw,qpFY4hAwolV3,headers,qpFY4hAwolV3,'AKWAM-MENU-1st')
	pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('class="menu(.*?)<nav',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	if pfRkcVlLmUxo561g0A8qSbO:
		mVYdjvor6i4wZ8 = pfRkcVlLmUxo561g0A8qSbO[0]
		items = ePhmG1jLD6.findall('href="(.*?)".*?text">(.*?)<',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
		for MepIvHBYNArkUOdV37shtJ,title in items:
			if title not in YEIA19ehBwpNfPVzK:
				title = title+' مفلترة'
				x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,244)
		if website==qpFY4hAwolV3: x3WSXnKyPhjqfHG2UrtQs('link',xupTj02bvy3O8R+' ===== ===== ===== '+fF4lt9zWYxXLKZVyAco82PgMj,qpFY4hAwolV3,9999)
	return cmWl9dOKHPIy41iaXuxrY
def c8U1BdtxOZS5FH(url,type=qpFY4hAwolV3):
	cmWl9dOKHPIy41iaXuxrY = GMqfDK9V4F8eTPE1pNOAaiYUbhr(kUz8c7OqsxuPFIGfwg,url,qpFY4hAwolV3,headers,True,'AKWAM-TITLES-1st')
	if type=='featured': pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('swiper-container(.*?)swiper-button-prev',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	else: pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('class="widget"(.*?)main-footer',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	if pfRkcVlLmUxo561g0A8qSbO:
		mVYdjvor6i4wZ8 = pfRkcVlLmUxo561g0A8qSbO[0]
		items = ePhmG1jLD6.findall('data-src="(.*?)".*?href="(.*?)".*?text-white">(.*?)<',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
		if not items:
			items = ePhmG1jLD6.findall('src="(.*?)".*?href="(.*?)".*?text-white">(.*?)<',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
		for Sj7rMNYRuQPTtkBvpHKeDW3h,MepIvHBYNArkUOdV37shtJ,title in items:
			if '/series/' in MepIvHBYNArkUOdV37shtJ or '/shows/' in MepIvHBYNArkUOdV37shtJ:
				x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,242,Sj7rMNYRuQPTtkBvpHKeDW3h)
			elif '/movies/' in MepIvHBYNArkUOdV37shtJ:
				x3WSXnKyPhjqfHG2UrtQs('video',wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,243,Sj7rMNYRuQPTtkBvpHKeDW3h)
			elif '/games/' not in MepIvHBYNArkUOdV37shtJ:
				x3WSXnKyPhjqfHG2UrtQs('video',wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,243,Sj7rMNYRuQPTtkBvpHKeDW3h)
	pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('pagination(.*?)</div>',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	if pfRkcVlLmUxo561g0A8qSbO:
		mVYdjvor6i4wZ8 = pfRkcVlLmUxo561g0A8qSbO[0]
		items = ePhmG1jLD6.findall('href="(.*?)".*?>(.*?)<',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
		for MepIvHBYNArkUOdV37shtJ,title in items:
			if title=='&lsaquo;': title = 'سابقة'
			if title=='&rsaquo;': title = 'لاحقة'
			MepIvHBYNArkUOdV37shtJ = j8PDV0pthfSTidZbsQxNIOmCYKWzH(MepIvHBYNArkUOdV37shtJ)
			x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+'صفحة '+title,MepIvHBYNArkUOdV37shtJ,241)
	return
def PPqUACSE3VcGLTvw05jHy9JrFNW(search):
	search,LBylNhMdH6OV1qGk0tWiXFg3,showDialogs = LLm3sBXHPcnTDxdE5gt6hz0Wkp(search)
	if search==qpFY4hAwolV3: search = jXgARlWMLVFUBnvmZwI2o5()
	if search==qpFY4hAwolV3: return
	K7m9Otk3h1VYIN8rcP6jp2 = search.replace(mIsDke0oK5x1zSiOWbF9thGcA,'%20')
	url = ddBxj51bhNtaK23lDyGMVw + '/search?q='+K7m9Otk3h1VYIN8rcP6jp2
	MOTjA5H9XFs = c8U1BdtxOZS5FH(url)
	return
def v1gmfxDcRrWKQ(url):
	cmWl9dOKHPIy41iaXuxrY = GMqfDK9V4F8eTPE1pNOAaiYUbhr(kUz8c7OqsxuPFIGfwg,url,qpFY4hAwolV3,headers,True,'AKWAM-EPISODES-1st')
	if '-episodes">' not in cmWl9dOKHPIy41iaXuxrY:
		Sj7rMNYRuQPTtkBvpHKeDW3h = Rqvw05BorCgcye7VE32Sf.getInfoLabel('ListItem.Icon')
		x3WSXnKyPhjqfHG2UrtQs('video',wwSFijdVJn1QgHW+'رابط التشغيل',url,243,Sj7rMNYRuQPTtkBvpHKeDW3h)
	else:
		pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('-episodes">(.*?)<div class="widget-4',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
		mVYdjvor6i4wZ8 = pfRkcVlLmUxo561g0A8qSbO[0]
		pzLc3HwImv2dru = ePhmG1jLD6.findall('href="(http.*?)".*?>(.*?)<.*?src="(.*?)"',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
		for MepIvHBYNArkUOdV37shtJ,title,Sj7rMNYRuQPTtkBvpHKeDW3h in pzLc3HwImv2dru:
			title = title.replace(r1roOXYi7UQw9FLThzPEdD0ZlvAnRc,mIsDke0oK5x1zSiOWbF9thGcA)
			if 'الحلقات' in title or 'مواسم اخرى' in title: continue
			if '/series/' in MepIvHBYNArkUOdV37shtJ: x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,242,Sj7rMNYRuQPTtkBvpHKeDW3h)
			else: x3WSXnKyPhjqfHG2UrtQs('video',wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,243,Sj7rMNYRuQPTtkBvpHKeDW3h)
	return
def mzcAeyplZV(url):
	cmWl9dOKHPIy41iaXuxrY = GMqfDK9V4F8eTPE1pNOAaiYUbhr(KOyPvpEztYLaZRdMQJWxfTNFHbkg,url,qpFY4hAwolV3,headers,True,'AKWAM-PLAY-1st')
	GIE2XSj0vVJPZA6dgmOs9TMDy8UkQW = ePhmG1jLD6.findall('badge-danger.*?>(.*?)<',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	if GIE2XSj0vVJPZA6dgmOs9TMDy8UkQW and u0E18eO3HnCzr(Q8Q0IDc6PLZajJAdTntKUmSGXz,url,GIE2XSj0vVJPZA6dgmOs9TMDy8UkQW): return
	TOzNltPw3x6BDgvKJaWjGs8bfFkHn4 = ePhmG1jLD6.findall('li><a href="#(.*?)".*?>(.*?)<',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	U7V0BQZPxXqMbyJnRw6f,QQLqrElamjfneR8GoP9IpuZ,HLVwBWJ6mFa3ApoNlq178nuXgI,oz7D4iwkIOURGny9 = [],[],[],[]
	if TOzNltPw3x6BDgvKJaWjGs8bfFkHn4:
		jGoKM4rgu7YFfm5WtPEin0sNRTq = 'mp4'
		for WWY8eD3uCfLFNyR0wJXpZUT6S7,Mrp5ZdGHFv9Xi6mkxfac3JDB in TOzNltPw3x6BDgvKJaWjGs8bfFkHn4:
			pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('tab-content quality" id="'+WWY8eD3uCfLFNyR0wJXpZUT6S7+'".*?</div>.\s*</div>',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
			mVYdjvor6i4wZ8 = pfRkcVlLmUxo561g0A8qSbO[0]
			HLVwBWJ6mFa3ApoNlq178nuXgI.append(mVYdjvor6i4wZ8)
			oz7D4iwkIOURGny9.append(Mrp5ZdGHFv9Xi6mkxfac3JDB)
	else:
		pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('class="qualities(.*?)<h3.*?>(.*?)<',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
		if not pfRkcVlLmUxo561g0A8qSbO:
			iG7Rz2kmn0x1yLNMV3u8O(qpFY4hAwolV3,qpFY4hAwolV3,GLTtERWbHnFuy4PCp,'لا يوجد ملف فيديو في هذا الرابط')
			return
		else:
			mVYdjvor6i4wZ8,filename = pfRkcVlLmUxo561g0A8qSbO[0]
			O6O02mbflHBjci9MgTLIzXJ8 = ['zip','rar','txt','pdf','htm','tar','iso','html']
			jGoKM4rgu7YFfm5WtPEin0sNRTq = filename.rsplit('.',1)[1].strip(mIsDke0oK5x1zSiOWbF9thGcA)
			if jGoKM4rgu7YFfm5WtPEin0sNRTq in O6O02mbflHBjci9MgTLIzXJ8:
				iG7Rz2kmn0x1yLNMV3u8O(qpFY4hAwolV3,qpFY4hAwolV3,GLTtERWbHnFuy4PCp,'الملف ليس فيديو ولا صوت')
				return
		HLVwBWJ6mFa3ApoNlq178nuXgI.append(mVYdjvor6i4wZ8)
		oz7D4iwkIOURGny9.append(qpFY4hAwolV3)
	for a2jQ83ZCfcM5 in range(len(HLVwBWJ6mFa3ApoNlq178nuXgI)):
		CFevtSjzbpn = ePhmG1jLD6.findall('href="(.*?)".*?icon-(.*?)"',HLVwBWJ6mFa3ApoNlq178nuXgI[a2jQ83ZCfcM5],ePhmG1jLD6.DOTALL)
		for MepIvHBYNArkUOdV37shtJ,ktTdfKQo0bhyq14izc2VevISDN in CFevtSjzbpn:
			if 'torrent' in ktTdfKQo0bhyq14izc2VevISDN: continue
			elif 'download' in ktTdfKQo0bhyq14izc2VevISDN: type = 'download'
			elif 'play' in ktTdfKQo0bhyq14izc2VevISDN: type = 'watch'
			else: type = 'unknown'
			MepIvHBYNArkUOdV37shtJ = MepIvHBYNArkUOdV37shtJ+'?named=__'+type+'____'+oz7D4iwkIOURGny9[a2jQ83ZCfcM5]+'__akwam'
			U7V0BQZPxXqMbyJnRw6f.append(MepIvHBYNArkUOdV37shtJ)
	import inVXFK46ET
	inVXFK46ET.q4qTJvuoQUzM3mZAtegy7IXdnb5wH(U7V0BQZPxXqMbyJnRw6f,Q8Q0IDc6PLZajJAdTntKUmSGXz,'video',url)
	return
def R9pWUgVhBGLd2CQb0z(url,filter):
	LLAbR2tC6J7OuvqfV4iYg = ['section','category','year','rating']
	if '?' in url: url = url.split('?')[0]
	type,filter = filter.split('___',1)
	if filter==qpFY4hAwolV3: eAYm1EkvcnOzXWpFB68o9rglSQ0M5,M0jc2ZsJHPb1d3DCoyXIzmgt = qpFY4hAwolV3,qpFY4hAwolV3
	else: eAYm1EkvcnOzXWpFB68o9rglSQ0M5,M0jc2ZsJHPb1d3DCoyXIzmgt = filter.split('___')
	if type=='CATEGORIES':
		if LLAbR2tC6J7OuvqfV4iYg[0]+'=' not in eAYm1EkvcnOzXWpFB68o9rglSQ0M5: n1uwH0oJaGZ5WBd = LLAbR2tC6J7OuvqfV4iYg[0]
		for a2jQ83ZCfcM5 in range(len(LLAbR2tC6J7OuvqfV4iYg[0:-1])):
			if LLAbR2tC6J7OuvqfV4iYg[a2jQ83ZCfcM5]+'=' in eAYm1EkvcnOzXWpFB68o9rglSQ0M5: n1uwH0oJaGZ5WBd = LLAbR2tC6J7OuvqfV4iYg[a2jQ83ZCfcM5+1]
		OI4ExuWvaLU = eAYm1EkvcnOzXWpFB68o9rglSQ0M5+'&'+n1uwH0oJaGZ5WBd+'=0'
		vmTWLw30V2PFNC8DrRqI = M0jc2ZsJHPb1d3DCoyXIzmgt+'&'+n1uwH0oJaGZ5WBd+'=0'
		nxGqbf39mXPhwl1NtAsSYK = OI4ExuWvaLU.strip('&')+'___'+vmTWLw30V2PFNC8DrRqI.strip('&')
		ekvC3tHRVnZGM4uDsmE2pBc5x = ZX8DyBJbV4lNAG(M0jc2ZsJHPb1d3DCoyXIzmgt,'all')
		WSQlG8mDhqsNe = url+'?'+ekvC3tHRVnZGM4uDsmE2pBc5x
	elif type=='FILTERS':
		Q7PrOdIzEeXgpT4HL38GK = ZX8DyBJbV4lNAG(eAYm1EkvcnOzXWpFB68o9rglSQ0M5,'modified_values')
		Q7PrOdIzEeXgpT4HL38GK = cTt4u6reEMKZqVLplmkNW7(Q7PrOdIzEeXgpT4HL38GK)
		if M0jc2ZsJHPb1d3DCoyXIzmgt!=qpFY4hAwolV3: M0jc2ZsJHPb1d3DCoyXIzmgt = ZX8DyBJbV4lNAG(M0jc2ZsJHPb1d3DCoyXIzmgt,'all')
		if M0jc2ZsJHPb1d3DCoyXIzmgt==qpFY4hAwolV3: WSQlG8mDhqsNe = url
		else: WSQlG8mDhqsNe = url+'?'+M0jc2ZsJHPb1d3DCoyXIzmgt
		x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+'أظهار قائمة الفيديو التي تم اختيارها',WSQlG8mDhqsNe,241,qpFY4hAwolV3,'1')
		x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+' [[   '+Q7PrOdIzEeXgpT4HL38GK+'   ]]',WSQlG8mDhqsNe,241,qpFY4hAwolV3,'1')
		x3WSXnKyPhjqfHG2UrtQs('link',xupTj02bvy3O8R+' ===== ===== ===== '+fF4lt9zWYxXLKZVyAco82PgMj,qpFY4hAwolV3,9999)
	cmWl9dOKHPIy41iaXuxrY = GMqfDK9V4F8eTPE1pNOAaiYUbhr(KOyPvpEztYLaZRdMQJWxfTNFHbkg,url,qpFY4hAwolV3,headers,True,'AKWAM-FILTERS_MENU-1st')
	pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('<form id(.*?)</form>',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	mVYdjvor6i4wZ8 = pfRkcVlLmUxo561g0A8qSbO[0]
	YF4LRjr6TuagQk9o3PiMeIcHx = ePhmG1jLD6.findall('<select.*?name="(.*?)".*?">(.*?)<(.*?)</select>',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
	dict = {}
	for CQlVpYyFN6bzXRBZIMxPWdn,name,mVYdjvor6i4wZ8 in YF4LRjr6TuagQk9o3PiMeIcHx:
		items = ePhmG1jLD6.findall('<option(.*?)>(.*?)<',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
		if '=' not in WSQlG8mDhqsNe: WSQlG8mDhqsNe = url
		if type=='CATEGORIES':
			if n1uwH0oJaGZ5WBd!=CQlVpYyFN6bzXRBZIMxPWdn: continue
			elif len(items)<=1:
				if CQlVpYyFN6bzXRBZIMxPWdn==LLAbR2tC6J7OuvqfV4iYg[-1]: c8U1BdtxOZS5FH(WSQlG8mDhqsNe)
				else: R9pWUgVhBGLd2CQb0z(WSQlG8mDhqsNe,'CATEGORIES___'+nxGqbf39mXPhwl1NtAsSYK)
				return
			else:
				if CQlVpYyFN6bzXRBZIMxPWdn==LLAbR2tC6J7OuvqfV4iYg[-1]: x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+'الجميع',WSQlG8mDhqsNe,241,qpFY4hAwolV3,'1')
				else: x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+'الجميع',WSQlG8mDhqsNe,245,qpFY4hAwolV3,qpFY4hAwolV3,nxGqbf39mXPhwl1NtAsSYK)
		elif type=='FILTERS':
			OI4ExuWvaLU = eAYm1EkvcnOzXWpFB68o9rglSQ0M5+'&'+CQlVpYyFN6bzXRBZIMxPWdn+'=0'
			vmTWLw30V2PFNC8DrRqI = M0jc2ZsJHPb1d3DCoyXIzmgt+'&'+CQlVpYyFN6bzXRBZIMxPWdn+'=0'
			nxGqbf39mXPhwl1NtAsSYK = OI4ExuWvaLU+'___'+vmTWLw30V2PFNC8DrRqI
			x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+'الجميع : '+name,WSQlG8mDhqsNe,244,qpFY4hAwolV3,qpFY4hAwolV3,nxGqbf39mXPhwl1NtAsSYK)
		dict[CQlVpYyFN6bzXRBZIMxPWdn] = {}
		for value,FLkeT4nCDqrQMmW6ZSlgyU5jIO32 in items:
			if FLkeT4nCDqrQMmW6ZSlgyU5jIO32 in YEIA19ehBwpNfPVzK: continue
			if 'value' not in value: value = FLkeT4nCDqrQMmW6ZSlgyU5jIO32
			else: value = ePhmG1jLD6.findall('"(.*?)"',value,ePhmG1jLD6.DOTALL)[0]
			dict[CQlVpYyFN6bzXRBZIMxPWdn][value] = FLkeT4nCDqrQMmW6ZSlgyU5jIO32
			OI4ExuWvaLU = eAYm1EkvcnOzXWpFB68o9rglSQ0M5+'&'+CQlVpYyFN6bzXRBZIMxPWdn+'='+FLkeT4nCDqrQMmW6ZSlgyU5jIO32
			vmTWLw30V2PFNC8DrRqI = M0jc2ZsJHPb1d3DCoyXIzmgt+'&'+CQlVpYyFN6bzXRBZIMxPWdn+'='+value
			lJWPN5EDIbft92m6iCQqAYLjav4p = OI4ExuWvaLU+'___'+vmTWLw30V2PFNC8DrRqI
			title = FLkeT4nCDqrQMmW6ZSlgyU5jIO32+' : '#+dict[CQlVpYyFN6bzXRBZIMxPWdn]['0']
			title = FLkeT4nCDqrQMmW6ZSlgyU5jIO32+' : '+name
			if type=='FILTERS': x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+title,url,244,qpFY4hAwolV3,qpFY4hAwolV3,lJWPN5EDIbft92m6iCQqAYLjav4p)
			elif type=='CATEGORIES' and LLAbR2tC6J7OuvqfV4iYg[-2]+'=' in eAYm1EkvcnOzXWpFB68o9rglSQ0M5:
				ekvC3tHRVnZGM4uDsmE2pBc5x = ZX8DyBJbV4lNAG(vmTWLw30V2PFNC8DrRqI,'all')
				hhpztscnBD1GP = url+'?'+ekvC3tHRVnZGM4uDsmE2pBc5x
				x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+title,hhpztscnBD1GP,241,qpFY4hAwolV3,'1')
			else: x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+title,url,245,qpFY4hAwolV3,qpFY4hAwolV3,lJWPN5EDIbft92m6iCQqAYLjav4p)
	return
def ZX8DyBJbV4lNAG(bbaYxjcVnksy,mode):
	bbaYxjcVnksy = bbaYxjcVnksy.strip('&')
	J9ASCRhfiDyTB = {}
	if '=' in bbaYxjcVnksy:
		items = bbaYxjcVnksy.split('&')
		for lkd2oKvZF03qmgMbIfQ6cD in items:
			JJAsQ4pRYXPhqugN2to9TEzLIS,value = lkd2oKvZF03qmgMbIfQ6cD.split('=')
			J9ASCRhfiDyTB[JJAsQ4pRYXPhqugN2to9TEzLIS] = value
	LxOIqpMU7E1hPKH5fSzj2iW9v = qpFY4hAwolV3
	VlsAo2qQ0BbEhZTgNL9u = ['section','category','rating','year','language','formats','quality']
	for key in VlsAo2qQ0BbEhZTgNL9u:
		if key in list(J9ASCRhfiDyTB.keys()): value = J9ASCRhfiDyTB[key]
		else: value = '0'
		if mode=='modified_values' and value!='0': LxOIqpMU7E1hPKH5fSzj2iW9v = LxOIqpMU7E1hPKH5fSzj2iW9v+' + '+value
		elif mode=='modified_filters' and value!='0': LxOIqpMU7E1hPKH5fSzj2iW9v = LxOIqpMU7E1hPKH5fSzj2iW9v+'&'+key+'='+value
		elif mode=='all': LxOIqpMU7E1hPKH5fSzj2iW9v = LxOIqpMU7E1hPKH5fSzj2iW9v+'&'+key+'='+value
	LxOIqpMU7E1hPKH5fSzj2iW9v = LxOIqpMU7E1hPKH5fSzj2iW9v.strip(' + ')
	LxOIqpMU7E1hPKH5fSzj2iW9v = LxOIqpMU7E1hPKH5fSzj2iW9v.strip('&')
	return LxOIqpMU7E1hPKH5fSzj2iW9v