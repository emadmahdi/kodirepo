# -*- coding: utf-8 -*-
from pSfaryIjBo import *
Q8Q0IDc6PLZajJAdTntKUmSGXz = 'FABRAKA'
wwSFijdVJn1QgHW = '_FBK_'
ddBxj51bhNtaK23lDyGMVw = i4bFG3rKE6.SITESURLS[Q8Q0IDc6PLZajJAdTntKUmSGXz][0]
YEIA19ehBwpNfPVzK = ['الصفحة الرئيسية','Sign in']
def vTNE2Ck1sGnugJYW8y39aLcSH64U(mode,url,text):
	if   mode==620: MOTjA5H9XFs = nRVAZc4Dp8PSrGU3xBk()
	elif mode==621: MOTjA5H9XFs = c8U1BdtxOZS5FH(url,text)
	elif mode==622: MOTjA5H9XFs = mzcAeyplZV(url)
	elif mode==623: MOTjA5H9XFs = PXEsuKvq5fS438YWFh7gBCdrw(url,text)
	elif mode==624: MOTjA5H9XFs = X2rO3lubqIdCGMLYWcxA6DK5(url)
	elif mode==629: MOTjA5H9XFs = PPqUACSE3VcGLTvw05jHy9JrFNW(text)
	else: MOTjA5H9XFs = False
	return MOTjA5H9XFs
def nRVAZc4Dp8PSrGU3xBk():
	iipsGz2LKq,url,IAW0sh6So3NpqM = YBNhACRib2dlgwp7869GJ(dzcNuIbsgK3yZ6SXGaEHPfOj5vk,'GET',ddBxj51bhNtaK23lDyGMVw,'fabraka','فبركة azureedge.net','كافة الحقوق محفوظة')
	cmWl9dOKHPIy41iaXuxrY = IAW0sh6So3NpqM.content
	x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+'بحث في الموقع',qpFY4hAwolV3,629,qpFY4hAwolV3,qpFY4hAwolV3,'_REMEMBERRESULTS_')
	x3WSXnKyPhjqfHG2UrtQs('link',xupTj02bvy3O8R+' ===== ===== ===== '+fF4lt9zWYxXLKZVyAco82PgMj,qpFY4hAwolV3,9999)
	x3WSXnKyPhjqfHG2UrtQs('folder',Q8Q0IDc6PLZajJAdTntKUmSGXz+'_SCRIPT_'+wwSFijdVJn1QgHW+'جديد الحلقات',iipsGz2LKq,621,qpFY4hAwolV3,qpFY4hAwolV3,'new_episodes')
	x3WSXnKyPhjqfHG2UrtQs('folder',Q8Q0IDc6PLZajJAdTntKUmSGXz+'_SCRIPT_'+wwSFijdVJn1QgHW+'جديد الأفلام',iipsGz2LKq,621,qpFY4hAwolV3,qpFY4hAwolV3,'new_movies')
	x3WSXnKyPhjqfHG2UrtQs('folder',Q8Q0IDc6PLZajJAdTntKUmSGXz+'_SCRIPT_'+wwSFijdVJn1QgHW+'المسلسلات المميزة',iipsGz2LKq,621,qpFY4hAwolV3,qpFY4hAwolV3,'featured_series')
	x3WSXnKyPhjqfHG2UrtQs('link',xupTj02bvy3O8R+' ===== ===== ===== '+fF4lt9zWYxXLKZVyAco82PgMj,qpFY4hAwolV3,9999)
	pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('"navslide-wrap"(.*?)</ul>',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	if not pfRkcVlLmUxo561g0A8qSbO:
		iG7Rz2kmn0x1yLNMV3u8O(qpFY4hAwolV3,qpFY4hAwolV3,'موقع فبركة','البرنامج لم يستطيع إيجاد عنوان الموقع أو تصميم الموقع تغير')
		return
	mVYdjvor6i4wZ8 = pfRkcVlLmUxo561g0A8qSbO[0]
	items = ePhmG1jLD6.findall('href="(.*?)".*?</i>(.*?)</a>',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
	for MepIvHBYNArkUOdV37shtJ,title in items:
		if title in YEIA19ehBwpNfPVzK: continue
		x3WSXnKyPhjqfHG2UrtQs('folder',Q8Q0IDc6PLZajJAdTntKUmSGXz+'_SCRIPT_'+wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,624)
	x3WSXnKyPhjqfHG2UrtQs('link',xupTj02bvy3O8R+' ===== ===== ===== '+fF4lt9zWYxXLKZVyAco82PgMj,qpFY4hAwolV3,9999)
	pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('/category.php">(.*?)"navslide-divider"',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	mVYdjvor6i4wZ8 = pfRkcVlLmUxo561g0A8qSbO[0]
	pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall("'dropdown-menu'(.*?)</ul>",cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	for WqdHmfQpP0ITnjJOAbDR6u8t7EiU in pfRkcVlLmUxo561g0A8qSbO: mVYdjvor6i4wZ8 = mVYdjvor6i4wZ8.replace(WqdHmfQpP0ITnjJOAbDR6u8t7EiU,qpFY4hAwolV3)
	items = ePhmG1jLD6.findall('href="(.*?)".*?>(.*?)</a>',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
	for MepIvHBYNArkUOdV37shtJ,title in items:
		if title in YEIA19ehBwpNfPVzK: continue
		x3WSXnKyPhjqfHG2UrtQs('folder',Q8Q0IDc6PLZajJAdTntKUmSGXz+'_SCRIPT_'+wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,624)
	return
def X2rO3lubqIdCGMLYWcxA6DK5(url):
	IAW0sh6So3NpqM = WWrExJZS3Bj4anOAkpv7(kUz8c7OqsxuPFIGfwg,'GET',url,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,'FABRAKA-SUBMENU-1st')
	cmWl9dOKHPIy41iaXuxrY = IAW0sh6So3NpqM.content
	NDnI9Qrpt5c8MU = ePhmG1jLD6.findall('"caret"(.*?)</ul>',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	if NDnI9Qrpt5c8MU:
		mVYdjvor6i4wZ8 = NDnI9Qrpt5c8MU[0]
		mVYdjvor6i4wZ8 = mVYdjvor6i4wZ8.replace('"presentation"','</ul>')
		pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('"dropdown-header">(.*?)</li>(.*?)</ul>',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
		if not pfRkcVlLmUxo561g0A8qSbO: pfRkcVlLmUxo561g0A8qSbO = [(qpFY4hAwolV3,mVYdjvor6i4wZ8)]
		x3WSXnKyPhjqfHG2UrtQs('link',xupTj02bvy3O8R+' فرز أو فلتر أو ترتيب '+fF4lt9zWYxXLKZVyAco82PgMj,qpFY4hAwolV3,9999)
		for YirSOX5nC0jPyvFTN48sHE1,mVYdjvor6i4wZ8 in pfRkcVlLmUxo561g0A8qSbO:
			items = ePhmG1jLD6.findall('href="(.*?)".*?>(.*?)</a>',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
			if YirSOX5nC0jPyvFTN48sHE1: YirSOX5nC0jPyvFTN48sHE1 = YirSOX5nC0jPyvFTN48sHE1+': '
			for MepIvHBYNArkUOdV37shtJ,title in items:
				title = YirSOX5nC0jPyvFTN48sHE1+title
				x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,621)
	T9TAc28ayKvFgjfd6SD = ePhmG1jLD6.findall('"pm-category-subcats"(.*?)</ul>',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	if T9TAc28ayKvFgjfd6SD:
		mVYdjvor6i4wZ8 = T9TAc28ayKvFgjfd6SD[0]
		items = ePhmG1jLD6.findall('href="(.*?)">(.*?)</a>',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
		if len(items)<30:
			x3WSXnKyPhjqfHG2UrtQs('link',xupTj02bvy3O8R+' ===== ===== ===== '+fF4lt9zWYxXLKZVyAco82PgMj,qpFY4hAwolV3,9999)
			for MepIvHBYNArkUOdV37shtJ,title in items:
				x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,621)
	if not NDnI9Qrpt5c8MU and not T9TAc28ayKvFgjfd6SD: c8U1BdtxOZS5FH(url)
	return
def c8U1BdtxOZS5FH(url,AMbRf4XTpQNvio6J5GELducy0k=qpFY4hAwolV3):
	if AMbRf4XTpQNvio6J5GELducy0k=='ajax-search':
		url,search = url.split('?',1)
		data = 'queryString='+search
		headers = {'Content-Type':'application/x-www-form-urlencoded; charset=UTF-8'}
		IAW0sh6So3NpqM = WWrExJZS3Bj4anOAkpv7(kUz8c7OqsxuPFIGfwg,'POST',url,data,headers,qpFY4hAwolV3,qpFY4hAwolV3,'FABRAKA-TITLES-1st')
	else:
		IAW0sh6So3NpqM = WWrExJZS3Bj4anOAkpv7(kUz8c7OqsxuPFIGfwg,'GET',url,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,'FABRAKA-TITLES-2nd')
	cmWl9dOKHPIy41iaXuxrY = IAW0sh6So3NpqM.content
	mVYdjvor6i4wZ8,items = qpFY4hAwolV3,[]
	iipsGz2LKq = AWeJuo2LhZ5xiD8KNSqd9G0rtT74FE(url,'url')
	if AMbRf4XTpQNvio6J5GELducy0k=='ajax-search':
		mVYdjvor6i4wZ8 = cmWl9dOKHPIy41iaXuxrY
		eKEo1iY0x8kAcU76ChWaypzHIwlRMq = ePhmG1jLD6.findall('href="(.*?)">(.*?)</a>',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
		for MepIvHBYNArkUOdV37shtJ,title in eKEo1iY0x8kAcU76ChWaypzHIwlRMq: items.append((qpFY4hAwolV3,MepIvHBYNArkUOdV37shtJ,title))
	elif AMbRf4XTpQNvio6J5GELducy0k=='featured':
		pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('"pm-video-watch-featured"(.*?)</ul>',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
		if pfRkcVlLmUxo561g0A8qSbO: mVYdjvor6i4wZ8 = pfRkcVlLmUxo561g0A8qSbO[0]
	elif AMbRf4XTpQNvio6J5GELducy0k=='new_episodes':
		pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('"row pm-ul-browse-videos(.*?)</ul>',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
		if pfRkcVlLmUxo561g0A8qSbO: mVYdjvor6i4wZ8 = pfRkcVlLmUxo561g0A8qSbO[0]
	elif AMbRf4XTpQNvio6J5GELducy0k=='new_movies':
		pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('"row pm-ul-browse-videos(.*?)</ul>',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
		if len(pfRkcVlLmUxo561g0A8qSbO)>1: mVYdjvor6i4wZ8 = pfRkcVlLmUxo561g0A8qSbO[1]
	elif AMbRf4XTpQNvio6J5GELducy0k=='featured_series':
		pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('"home-series-list"(.*?)</div>[\t|\n]*</div>',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
		if pfRkcVlLmUxo561g0A8qSbO: mVYdjvor6i4wZ8 = pfRkcVlLmUxo561g0A8qSbO[0]
		eKEo1iY0x8kAcU76ChWaypzHIwlRMq = ePhmG1jLD6.findall('href="(.*?)">(.*?)</a>',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
		for MepIvHBYNArkUOdV37shtJ,title in eKEo1iY0x8kAcU76ChWaypzHIwlRMq: items.append((qpFY4hAwolV3,MepIvHBYNArkUOdV37shtJ,title))
	else:
		pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('(data-echo=".*?)</ul>',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
		if pfRkcVlLmUxo561g0A8qSbO: mVYdjvor6i4wZ8 = pfRkcVlLmUxo561g0A8qSbO[0]
	if mVYdjvor6i4wZ8 and not items: items = ePhmG1jLD6.findall('data-echo="(.*?)".*?href="(.*?)".*?>(.*?)<',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
	if not items: return
	aaCNAJdtsguSRELh2I = []
	WGid3I2kFU = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم','مسرحية']
	for Sj7rMNYRuQPTtkBvpHKeDW3h,MepIvHBYNArkUOdV37shtJ,title in items:
		ZDTxRSMbW7PNz = ePhmG1jLD6.findall('(.*?) (الحلقة|حلقة).\d+',title,ePhmG1jLD6.DOTALL)
		if any(value in title for value in WGid3I2kFU):
			x3WSXnKyPhjqfHG2UrtQs('video',wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,622,Sj7rMNYRuQPTtkBvpHKeDW3h)
		elif AMbRf4XTpQNvio6J5GELducy0k=='new_episodes':
			x3WSXnKyPhjqfHG2UrtQs('video',wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,622,Sj7rMNYRuQPTtkBvpHKeDW3h)
		elif ZDTxRSMbW7PNz:
			title = '_MOD_' + ZDTxRSMbW7PNz[0][0]
			if title not in aaCNAJdtsguSRELh2I:
				x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,623,Sj7rMNYRuQPTtkBvpHKeDW3h)
				aaCNAJdtsguSRELh2I.append(title)
		else: x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,623,Sj7rMNYRuQPTtkBvpHKeDW3h)
	if 1:
		pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('"pagination(.*?)</ul>',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
		if pfRkcVlLmUxo561g0A8qSbO:
			mVYdjvor6i4wZ8 = pfRkcVlLmUxo561g0A8qSbO[0]
			items = ePhmG1jLD6.findall('href="(.*?)".*?>(.*?)</a>',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
			for MepIvHBYNArkUOdV37shtJ,title in items:
				if MepIvHBYNArkUOdV37shtJ=='#': continue
				MepIvHBYNArkUOdV37shtJ = iipsGz2LKq+ShynO8pN9idCE3+MepIvHBYNArkUOdV37shtJ.strip(ShynO8pN9idCE3)
				title = j8PDV0pthfSTidZbsQxNIOmCYKWzH(title)
				x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+'صفحة '+title,MepIvHBYNArkUOdV37shtJ,621)
	return
def PXEsuKvq5fS438YWFh7gBCdrw(url,MaNXbtkeElTRsiK6c1u):
	iipsGz2LKq = AWeJuo2LhZ5xiD8KNSqd9G0rtT74FE(url,'url')
	IAW0sh6So3NpqM = WWrExJZS3Bj4anOAkpv7(kUz8c7OqsxuPFIGfwg,'GET',url,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,'FABRAKA-EPISODES-2nd')
	cmWl9dOKHPIy41iaXuxrY = IAW0sh6So3NpqM.content
	NDnI9Qrpt5c8MU = ePhmG1jLD6.findall('"SeasonsBox"(.*?)"SeasonsEpisodesMain',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	BvbuigUeoJLnTaN2qWxQ415AtYMK9I = ePhmG1jLD6.findall('"series-header".*?src="(.*?)"',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	if BvbuigUeoJLnTaN2qWxQ415AtYMK9I: Sj7rMNYRuQPTtkBvpHKeDW3h = BvbuigUeoJLnTaN2qWxQ415AtYMK9I[0]
	else: Sj7rMNYRuQPTtkBvpHKeDW3h = qpFY4hAwolV3
	items = []
	BfsF3ItbJ17Mndmy = False
	if NDnI9Qrpt5c8MU and not MaNXbtkeElTRsiK6c1u:
		mVYdjvor6i4wZ8 = NDnI9Qrpt5c8MU[0]
		items = ePhmG1jLD6.findall('''onclick="openCity\(event, '(.*?)'\)">(.*?)</button>''',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
		for MaNXbtkeElTRsiK6c1u,title in items:
			MaNXbtkeElTRsiK6c1u = MaNXbtkeElTRsiK6c1u.strip('#')
			if len(items)>1: x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+title,url,623,Sj7rMNYRuQPTtkBvpHKeDW3h,qpFY4hAwolV3,MaNXbtkeElTRsiK6c1u)
			else: BfsF3ItbJ17Mndmy = True
	else: BfsF3ItbJ17Mndmy = True
	T9TAc28ayKvFgjfd6SD = ePhmG1jLD6.findall('id="'+MaNXbtkeElTRsiK6c1u+'"(.*?)</ul>',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	if T9TAc28ayKvFgjfd6SD and BfsF3ItbJ17Mndmy:
		mVYdjvor6i4wZ8 = T9TAc28ayKvFgjfd6SD[0]
		eKEo1iY0x8kAcU76ChWaypzHIwlRMq = ePhmG1jLD6.findall('''href=['"](.*?)['"]><li><em>(.*?)</span>''',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
		items = []
		for MepIvHBYNArkUOdV37shtJ,title in eKEo1iY0x8kAcU76ChWaypzHIwlRMq: items.append((MepIvHBYNArkUOdV37shtJ,title,Sj7rMNYRuQPTtkBvpHKeDW3h))
		if not items: items = ePhmG1jLD6.findall('"thumbnail".*?href="(.*?)" title="(.*?)".*?src="(.*?)"',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
		for MepIvHBYNArkUOdV37shtJ,title,Sj7rMNYRuQPTtkBvpHKeDW3h in items:
			MepIvHBYNArkUOdV37shtJ = iipsGz2LKq+ShynO8pN9idCE3+MepIvHBYNArkUOdV37shtJ.strip(ShynO8pN9idCE3)
			title = title.replace('</em><span>',mIsDke0oK5x1zSiOWbF9thGcA)
			x3WSXnKyPhjqfHG2UrtQs('video',wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,622,Sj7rMNYRuQPTtkBvpHKeDW3h)
	return
def mzcAeyplZV(url):
	tiYp9ZdbFTQMcB4vWkHw6LXIAKrN5m = []
	url = url.replace('watch.php','see.php')
	IAW0sh6So3NpqM = WWrExJZS3Bj4anOAkpv7(kUz8c7OqsxuPFIGfwg,'GET',url,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,'FABRAKA-PLAY-1st')
	cmWl9dOKHPIy41iaXuxrY = IAW0sh6So3NpqM.content
	pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('"WatchList"(.*?)</ul>',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	if pfRkcVlLmUxo561g0A8qSbO:
		mVYdjvor6i4wZ8 = pfRkcVlLmUxo561g0A8qSbO[0]
		items = ePhmG1jLD6.findall('embed-url="(.*?)".*?<strong>(.*?)</strong>',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
		for MepIvHBYNArkUOdV37shtJ,title in items:
			MepIvHBYNArkUOdV37shtJ = MepIvHBYNArkUOdV37shtJ+'?named='+title+'__watch'
			tiYp9ZdbFTQMcB4vWkHw6LXIAKrN5m.append(MepIvHBYNArkUOdV37shtJ)
	MepIvHBYNArkUOdV37shtJ = ePhmG1jLD6.findall('<iframe src="(.*?)"',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	if MepIvHBYNArkUOdV37shtJ:
		MepIvHBYNArkUOdV37shtJ = MepIvHBYNArkUOdV37shtJ[0]+'?named='+title+'__embed'
		tiYp9ZdbFTQMcB4vWkHw6LXIAKrN5m.append(MepIvHBYNArkUOdV37shtJ)
	pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('"downloadlist"(.*?)</ul>',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	if pfRkcVlLmUxo561g0A8qSbO:
		mVYdjvor6i4wZ8 = pfRkcVlLmUxo561g0A8qSbO[0]
		items = ePhmG1jLD6.findall('download-url="(.*?)".*?<strong>(.*?)</strong>',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
		for MepIvHBYNArkUOdV37shtJ,title in items:
			MepIvHBYNArkUOdV37shtJ = MepIvHBYNArkUOdV37shtJ+'?named='+title+'__download'
			tiYp9ZdbFTQMcB4vWkHw6LXIAKrN5m.append(MepIvHBYNArkUOdV37shtJ)
	import inVXFK46ET
	inVXFK46ET.q4qTJvuoQUzM3mZAtegy7IXdnb5wH(tiYp9ZdbFTQMcB4vWkHw6LXIAKrN5m,Q8Q0IDc6PLZajJAdTntKUmSGXz,'video',url)
	return
def PPqUACSE3VcGLTvw05jHy9JrFNW(search):
	search,LBylNhMdH6OV1qGk0tWiXFg3,showDialogs = LLm3sBXHPcnTDxdE5gt6hz0Wkp(search)
	if search==qpFY4hAwolV3: search = jXgARlWMLVFUBnvmZwI2o5()
	if search==qpFY4hAwolV3: return
	search = search.replace(mIsDke0oK5x1zSiOWbF9thGcA,'+')
	url = ddBxj51bhNtaK23lDyGMVw+'/search.php?keywords='+search
	iipsGz2LKq,WSQlG8mDhqsNe,YzK5Mnda6GwuX1LHeI = YBNhACRib2dlgwp7869GJ(dzcNuIbsgK3yZ6SXGaEHPfOj5vk,'GET',url,'fabraka','فبركة azureedge.net','كافة الحقوق محفوظة')
	c8U1BdtxOZS5FH(WSQlG8mDhqsNe,'search')
	return