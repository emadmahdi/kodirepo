# -*- coding: utf-8 -*-
from pSfaryIjBo import *
Q8Q0IDc6PLZajJAdTntKUmSGXz = 'CIMANOW'
wwSFijdVJn1QgHW = '_CMN_'
ddBxj51bhNtaK23lDyGMVw = i4bFG3rKE6.SITESURLS[Q8Q0IDc6PLZajJAdTntKUmSGXz][0]
YEIA19ehBwpNfPVzK = ['قائمتي']
def vTNE2Ck1sGnugJYW8y39aLcSH64U(mode,url,text):
	if   mode==300: MOTjA5H9XFs = nRVAZc4Dp8PSrGU3xBk()
	elif mode==301: MOTjA5H9XFs = X2rO3lubqIdCGMLYWcxA6DK5(url)
	elif mode==302: MOTjA5H9XFs = c8U1BdtxOZS5FH(url)
	elif mode==303: MOTjA5H9XFs = GMJIVNSa4Ridv5Ou(url)
	elif mode==304: MOTjA5H9XFs = v1gmfxDcRrWKQ(url)
	elif mode==305: MOTjA5H9XFs = mzcAeyplZV(url)
	elif mode==306: MOTjA5H9XFs = TJopmWqUYFQRi4l93KHPXNyZOj()
	elif mode==309: MOTjA5H9XFs = PPqUACSE3VcGLTvw05jHy9JrFNW(text)
	else: MOTjA5H9XFs = False
	return MOTjA5H9XFs
def nRVAZc4Dp8PSrGU3xBk():
	x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+'بحث في الموقع',qpFY4hAwolV3,309,qpFY4hAwolV3,qpFY4hAwolV3,'_REMEMBERRESULTS_')
	x3WSXnKyPhjqfHG2UrtQs('link',xupTj02bvy3O8R+' ===== ===== ===== '+fF4lt9zWYxXLKZVyAco82PgMj,qpFY4hAwolV3,9999)
	IAW0sh6So3NpqM = WWrExJZS3Bj4anOAkpv7(KOyPvpEztYLaZRdMQJWxfTNFHbkg,'GET',ddBxj51bhNtaK23lDyGMVw+'/home',qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,'CIMANOW-MENU-1st')
	cmWl9dOKHPIy41iaXuxrY = IAW0sh6So3NpqM.content
	pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('<header(.*?)</header>',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	mVYdjvor6i4wZ8 = pfRkcVlLmUxo561g0A8qSbO[0]
	items = ePhmG1jLD6.findall('<li><a href="(.*?)">(.*?)<',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
	for MepIvHBYNArkUOdV37shtJ,title in items:
		title = title.strip(mIsDke0oK5x1zSiOWbF9thGcA)
		if not any(value in title for value in YEIA19ehBwpNfPVzK):
			x3WSXnKyPhjqfHG2UrtQs('folder',Q8Q0IDc6PLZajJAdTntKUmSGXz+'_SCRIPT_'+wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,301)
	x3WSXnKyPhjqfHG2UrtQs('link',xupTj02bvy3O8R+' ===== ===== ===== '+fF4lt9zWYxXLKZVyAco82PgMj,qpFY4hAwolV3,9999)
	X2rO3lubqIdCGMLYWcxA6DK5(ddBxj51bhNtaK23lDyGMVw+'/home',cmWl9dOKHPIy41iaXuxrY)
	return cmWl9dOKHPIy41iaXuxrY
def TJopmWqUYFQRi4l93KHPXNyZOj():
	iG7Rz2kmn0x1yLNMV3u8O(qpFY4hAwolV3,qpFY4hAwolV3,GLTtERWbHnFuy4PCp,'موقع سيما ناو بطيء من المصدر .. بسبب قيام أصحاب الموقع بتشفير محتويات جميع صفحات الموقع .. والوقت الضائع يذهب في معالجة تشفير الصفحات المشفرة قبل عرض محتوياتها في قوائم هذا البرنامج')
	return
def X2rO3lubqIdCGMLYWcxA6DK5(url,cmWl9dOKHPIy41iaXuxrY=qpFY4hAwolV3):
	if not cmWl9dOKHPIy41iaXuxrY:
		IAW0sh6So3NpqM = WWrExJZS3Bj4anOAkpv7(KOyPvpEztYLaZRdMQJWxfTNFHbkg,'GET',url,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,'CIMANOW-SUBMENU-1st')
		cmWl9dOKHPIy41iaXuxrY = IAW0sh6So3NpqM.content
	P71nY8vWLi4xBOr9tZVNRQzJUbSG6 = 0
	pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('<section>.*?</section>',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	for mVYdjvor6i4wZ8 in pfRkcVlLmUxo561g0A8qSbO:
		P71nY8vWLi4xBOr9tZVNRQzJUbSG6 += 1
		items = ePhmG1jLD6.findall('<section>.*?<span>(.*?)<(.*?)href="(.*?)"',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
		for title,nxM1iW7PkVIzX3j5U,MepIvHBYNArkUOdV37shtJ in items:
			title = title.strip(mIsDke0oK5x1zSiOWbF9thGcA)
			if title==qpFY4hAwolV3: title = 'بووووو'
			if 'em><a' not in nxM1iW7PkVIzX3j5U:
				if mVYdjvor6i4wZ8.count('/category/')>0:
					VVn8DUgwNTFzEchAd6fi3 = ePhmG1jLD6.findall('href="(.*?)"',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
					for MepIvHBYNArkUOdV37shtJ in VVn8DUgwNTFzEchAd6fi3:
						title = MepIvHBYNArkUOdV37shtJ.split(ShynO8pN9idCE3)[-2]
						x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,301)
					continue
				else: MepIvHBYNArkUOdV37shtJ = url+'?sequence='+str(P71nY8vWLi4xBOr9tZVNRQzJUbSG6)
			if not any(value in title for value in YEIA19ehBwpNfPVzK):
				x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,302)
	if not pfRkcVlLmUxo561g0A8qSbO: c8U1BdtxOZS5FH(url,cmWl9dOKHPIy41iaXuxrY)
	return
def c8U1BdtxOZS5FH(url,cmWl9dOKHPIy41iaXuxrY=qpFY4hAwolV3):
	if cmWl9dOKHPIy41iaXuxrY==qpFY4hAwolV3:
		IAW0sh6So3NpqM = WWrExJZS3Bj4anOAkpv7(kUz8c7OqsxuPFIGfwg,'GET',url,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,'CIMANOW-TITLES-1st')
		cmWl9dOKHPIy41iaXuxrY = IAW0sh6So3NpqM.content
	if '?sequence=' in url:
		url,P71nY8vWLi4xBOr9tZVNRQzJUbSG6 = url.split('?sequence=')
		pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('(<section>.*?</section>)',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
		mVYdjvor6i4wZ8 = pfRkcVlLmUxo561g0A8qSbO[int(P71nY8vWLi4xBOr9tZVNRQzJUbSG6)-1]
	else:
		pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('"posts"(.*?)</body>',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
		mVYdjvor6i4wZ8 = pfRkcVlLmUxo561g0A8qSbO[0]
	items = ePhmG1jLD6.findall('<a.*?href="(.*?)"(.*?)data-src="(.*?)"',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
	aaCNAJdtsguSRELh2I = []
	for MepIvHBYNArkUOdV37shtJ,data,Sj7rMNYRuQPTtkBvpHKeDW3h in items:
		title = ePhmG1jLD6.findall('<em>(.*?)</em>(.*?)</li>.*?</em>(.*?)<em>',data,ePhmG1jLD6.DOTALL)
		if title: title = title[0][2].replace(ZLwoRpfnCWI7FgEHsz6te39lMVh,qpFY4hAwolV3).strip(mIsDke0oK5x1zSiOWbF9thGcA)
		if not title or title==qpFY4hAwolV3:
			title = ePhmG1jLD6.findall('title">.*?</em>(.*?)<',data,ePhmG1jLD6.DOTALL)
			if title: title = title[0].replace(ZLwoRpfnCWI7FgEHsz6te39lMVh,qpFY4hAwolV3).strip(mIsDke0oK5x1zSiOWbF9thGcA)
			if not title or title==qpFY4hAwolV3:
				title = ePhmG1jLD6.findall('title">(.*?)<',data,ePhmG1jLD6.DOTALL)
				title = title[0].replace(ZLwoRpfnCWI7FgEHsz6te39lMVh,qpFY4hAwolV3).strip(mIsDke0oK5x1zSiOWbF9thGcA)
		title = j8PDV0pthfSTidZbsQxNIOmCYKWzH(title)
		title = title.replace(r1roOXYi7UQw9FLThzPEdD0ZlvAnRc,mIsDke0oK5x1zSiOWbF9thGcA)
		if title not in aaCNAJdtsguSRELh2I:
			aaCNAJdtsguSRELh2I.append(title)
			WqdHmfQpP0ITnjJOAbDR6u8t7EiU = MepIvHBYNArkUOdV37shtJ+data+Sj7rMNYRuQPTtkBvpHKeDW3h
			if '/selary/' in WqdHmfQpP0ITnjJOAbDR6u8t7EiU or 'مسلسل' in WqdHmfQpP0ITnjJOAbDR6u8t7EiU or '"episode"' in WqdHmfQpP0ITnjJOAbDR6u8t7EiU:
				if 'برامج' in data: title = 'برنامج '+title
				elif 'مسلسل' in data or 'موسم' in data: title = 'مسلسل '+title
				x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,303,Sj7rMNYRuQPTtkBvpHKeDW3h)
			else: x3WSXnKyPhjqfHG2UrtQs('video',wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,305,Sj7rMNYRuQPTtkBvpHKeDW3h)
	pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('"pagination"(.*?)</div>',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	if pfRkcVlLmUxo561g0A8qSbO:
		mVYdjvor6i4wZ8 = pfRkcVlLmUxo561g0A8qSbO[0]
		items = ePhmG1jLD6.findall('<li><a href="(.*?)">(.*?)<',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
		for MepIvHBYNArkUOdV37shtJ,title in items:
			x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+'صفحة '+title,MepIvHBYNArkUOdV37shtJ,302)
	return
def GMJIVNSa4Ridv5Ou(url):
	IAW0sh6So3NpqM = WWrExJZS3Bj4anOAkpv7(kUz8c7OqsxuPFIGfwg,'GET',url,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,'CIMANOW-SEASONS-1st')
	cmWl9dOKHPIy41iaXuxrY = IAW0sh6So3NpqM.content
	name = ePhmG1jLD6.findall('<title>(.*?)</title>',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	if name:
		name = name[0].replace('| سيما ناو',qpFY4hAwolV3).replace('Cima Now',qpFY4hAwolV3).strip(mIsDke0oK5x1zSiOWbF9thGcA).replace(r1roOXYi7UQw9FLThzPEdD0ZlvAnRc,mIsDke0oK5x1zSiOWbF9thGcA)
		name = name.split('الحلقة')[0].strip(mIsDke0oK5x1zSiOWbF9thGcA)+' - '
	else: name = qpFY4hAwolV3
	pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('<section(.*?)</section>',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	if pfRkcVlLmUxo561g0A8qSbO:
		mVYdjvor6i4wZ8 = pfRkcVlLmUxo561g0A8qSbO[0]
		items = ePhmG1jLD6.findall('href="(.*?)">(.*?)<',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
		if len(items)>1:
			for MepIvHBYNArkUOdV37shtJ,title in items:
				title = name+title.replace(ZLwoRpfnCWI7FgEHsz6te39lMVh,qpFY4hAwolV3).strip(mIsDke0oK5x1zSiOWbF9thGcA)
				x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,304)
		elif len(items)==1:
			MepIvHBYNArkUOdV37shtJ,title = items[0]
			v1gmfxDcRrWKQ(MepIvHBYNArkUOdV37shtJ)
		else: v1gmfxDcRrWKQ(url)
	return
def v1gmfxDcRrWKQ(url):
	if '/selary/' not in url: url = url.strip(ShynO8pN9idCE3)+'/watching'
	IAW0sh6So3NpqM = WWrExJZS3Bj4anOAkpv7(kUz8c7OqsxuPFIGfwg,'GET',url,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,'CIMANOW-EPISODES-1st')
	cmWl9dOKHPIy41iaXuxrY = IAW0sh6So3NpqM.content
	if '/selary/' not in url:
		pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('"episodes"(.*?)</ul>',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
		mVYdjvor6i4wZ8 = pfRkcVlLmUxo561g0A8qSbO[vvXoMLlg513]
		items = ePhmG1jLD6.findall('href="(.*?)">(.*?)</a>',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
		for MepIvHBYNArkUOdV37shtJ,title in items:
			title = title.replace(ZLwoRpfnCWI7FgEHsz6te39lMVh,qpFY4hAwolV3).strip(mIsDke0oK5x1zSiOWbF9thGcA)
			title = 'الحلقة '+title
			x3WSXnKyPhjqfHG2UrtQs('video',wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,305)
	else:
		pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('"details"(.*?)"related"',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
		mVYdjvor6i4wZ8 = pfRkcVlLmUxo561g0A8qSbO[vvXoMLlg513]
		items = ePhmG1jLD6.findall('href="(.*?)".*?src=.*?src="(.*?)".*?alt="(.*?)"',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
		for MepIvHBYNArkUOdV37shtJ,Sj7rMNYRuQPTtkBvpHKeDW3h,title in items:
			title = title.replace(ZLwoRpfnCWI7FgEHsz6te39lMVh,qpFY4hAwolV3).strip(mIsDke0oK5x1zSiOWbF9thGcA)
			x3WSXnKyPhjqfHG2UrtQs('video',wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,305,Sj7rMNYRuQPTtkBvpHKeDW3h)
	return
def mzcAeyplZV(url):
	IAW0sh6So3NpqM = WWrExJZS3Bj4anOAkpv7(kUz8c7OqsxuPFIGfwg,'GET',url,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,'CIMANOW-PLAY-1st')
	cmWl9dOKHPIy41iaXuxrY = IAW0sh6So3NpqM.content
	DGnt2BTPSj63wxulpzLOdK7s94ME85 = ePhmG1jLD6.findall('class="shine" href="(.*?)"',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	if DGnt2BTPSj63wxulpzLOdK7s94ME85:
		XPNkVcWFUr = AWeJuo2LhZ5xiD8KNSqd9G0rtT74FE(DGnt2BTPSj63wxulpzLOdK7s94ME85[0],'url')
		headers = {'Referer':XPNkVcWFUr}
	else: headers = qpFY4hAwolV3
	WSQlG8mDhqsNe = url+'watching/'
	IAW0sh6So3NpqM = WWrExJZS3Bj4anOAkpv7(kUz8c7OqsxuPFIGfwg,'GET',WSQlG8mDhqsNe,qpFY4hAwolV3,headers,qpFY4hAwolV3,qpFY4hAwolV3,'CIMANOW-PLAY-5th')
	cmWl9dOKHPIy41iaXuxrY = IAW0sh6So3NpqM.content
	U7V0BQZPxXqMbyJnRw6f = []
	pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('"download"(.*?)</ul>',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	if pfRkcVlLmUxo561g0A8qSbO:
		mVYdjvor6i4wZ8 = pfRkcVlLmUxo561g0A8qSbO[0]
		items = ePhmG1jLD6.findall('href="(.*?)".*?</i>(.*?)</a>',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
		for MepIvHBYNArkUOdV37shtJ,title in items:
			title = title.replace(ZLwoRpfnCWI7FgEHsz6te39lMVh,qpFY4hAwolV3).strip(mIsDke0oK5x1zSiOWbF9thGcA)
			Mrp5ZdGHFv9Xi6mkxfac3JDB = ePhmG1jLD6.findall('\d\d\d+',title,ePhmG1jLD6.DOTALL)
			if Mrp5ZdGHFv9Xi6mkxfac3JDB:
				Mrp5ZdGHFv9Xi6mkxfac3JDB = '____'+Mrp5ZdGHFv9Xi6mkxfac3JDB[0]
				title = AWeJuo2LhZ5xiD8KNSqd9G0rtT74FE(MepIvHBYNArkUOdV37shtJ,'name')
			else: Mrp5ZdGHFv9Xi6mkxfac3JDB = qpFY4hAwolV3
			OexQX2mTwfGkuU6AIBLz9vWlHjdF8 = MepIvHBYNArkUOdV37shtJ+'?named='+title+'__download'+Mrp5ZdGHFv9Xi6mkxfac3JDB
			U7V0BQZPxXqMbyJnRw6f.append(OexQX2mTwfGkuU6AIBLz9vWlHjdF8)
	pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('"watch"(.*?)</ul>',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	if pfRkcVlLmUxo561g0A8qSbO:
		mVYdjvor6i4wZ8 = pfRkcVlLmUxo561g0A8qSbO[0]
		CFevtSjzbpn = ePhmG1jLD6.findall('"embed".*?src="(.*?)"',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
		for MepIvHBYNArkUOdV37shtJ in CFevtSjzbpn:
			if 'http' not in MepIvHBYNArkUOdV37shtJ: MepIvHBYNArkUOdV37shtJ = 'http:'+MepIvHBYNArkUOdV37shtJ
			title = AWeJuo2LhZ5xiD8KNSqd9G0rtT74FE(MepIvHBYNArkUOdV37shtJ,'name')
			MepIvHBYNArkUOdV37shtJ = MepIvHBYNArkUOdV37shtJ+'?named='+title+'__embed'
			U7V0BQZPxXqMbyJnRw6f.append(MepIvHBYNArkUOdV37shtJ)
		CFevtSjzbpn = [ddBxj51bhNtaK23lDyGMVw+'/wp-content/themes/Cima%20Now%20New/core.php']
		if CFevtSjzbpn:
			items = ePhmG1jLD6.findall('data-index="(.*?)".*?data-id="(.*?)".*?>(.*?)</li>',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
			for P9gc0wx41l3y26iufIkWtaUGnMZ,id,title in items:
				title = title.replace(ZLwoRpfnCWI7FgEHsz6te39lMVh,qpFY4hAwolV3).strip(mIsDke0oK5x1zSiOWbF9thGcA)
				MepIvHBYNArkUOdV37shtJ = CFevtSjzbpn[0]+'?action=switch&index='+P9gc0wx41l3y26iufIkWtaUGnMZ+'&id='+id+'?named='+title+'__watch'
				U7V0BQZPxXqMbyJnRw6f.append(MepIvHBYNArkUOdV37shtJ)
	import inVXFK46ET
	inVXFK46ET.q4qTJvuoQUzM3mZAtegy7IXdnb5wH(U7V0BQZPxXqMbyJnRw6f,Q8Q0IDc6PLZajJAdTntKUmSGXz,'video',url)
	return
def PPqUACSE3VcGLTvw05jHy9JrFNW(search):
	search,LBylNhMdH6OV1qGk0tWiXFg3,showDialogs = LLm3sBXHPcnTDxdE5gt6hz0Wkp(search)
	if search==qpFY4hAwolV3: search = jXgARlWMLVFUBnvmZwI2o5()
	if search==qpFY4hAwolV3: return
	search = search.replace(mIsDke0oK5x1zSiOWbF9thGcA,'+')
	url = ddBxj51bhNtaK23lDyGMVw + '/?s='+search
	c8U1BdtxOZS5FH(url)
	return