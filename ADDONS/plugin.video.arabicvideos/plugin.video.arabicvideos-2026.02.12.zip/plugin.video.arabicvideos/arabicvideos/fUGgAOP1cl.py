# -*- coding: utf-8 -*-
from pSfaryIjBo import *
import bs4 as AUKntekCmMRFda
Q8Q0IDc6PLZajJAdTntKUmSGXz = 'ELCINEMA'
wwSFijdVJn1QgHW = '_ELC_'
ddBxj51bhNtaK23lDyGMVw = i4bFG3rKE6.SITESURLS[Q8Q0IDc6PLZajJAdTntKUmSGXz][0]
headers = {'Referer':ddBxj51bhNtaK23lDyGMVw}
YEIA19ehBwpNfPVzK = []
def vTNE2Ck1sGnugJYW8y39aLcSH64U(mode,url,text):
	if   mode==510: MOTjA5H9XFs = nRVAZc4Dp8PSrGU3xBk()
	elif mode==511: MOTjA5H9XFs = h8HbfF2DRSTXGUoZexKcIwV71n9ldm(url)
	elif mode==512: MOTjA5H9XFs = ycj2oiD4MrSYT9(url)
	elif mode==513: MOTjA5H9XFs = un6CmqRygD4PfaVvkWO320oYhiQ1TK(url)
	elif mode==514: MOTjA5H9XFs = P0Nsf3Btwo5zhqRDv(url,'ALL_ITEMS_FILTER___'+text)
	elif mode==515: MOTjA5H9XFs = P0Nsf3Btwo5zhqRDv(url,'SPECIFIED_FILTER___'+text)
	elif mode==516: MOTjA5H9XFs = zV0Yir1JGoHUKnmwxOcgysB(text)
	elif mode==517: MOTjA5H9XFs = x9ODY4hekKZyzcX3HFAL8jawvt6r(url)
	elif mode==518: MOTjA5H9XFs = ddtXrhw3S8Apv2yqcs06ikOzFT(url)
	elif mode==519: MOTjA5H9XFs = PPqUACSE3VcGLTvw05jHy9JrFNW(text)
	elif mode==520: MOTjA5H9XFs = MOlvN6tfud1sS2gbU37GryoRJkT(url)
	elif mode==521: MOTjA5H9XFs = eRi7kJwPzbBu8gWy4hsO(url)
	elif mode==522: MOTjA5H9XFs = mzcAeyplZV(url)
	elif mode==523: MOTjA5H9XFs = ccuDmH5rph(text)
	elif mode==524: MOTjA5H9XFs = OOucQ3IaptVrdeFKS7PXJBo1()
	elif mode==525: MOTjA5H9XFs = F2p7CdH3INE9v1u5JzksxSBXGPbOj()
	elif mode==526: MOTjA5H9XFs = ccHtekmIEAOulDC()
	elif mode==527: MOTjA5H9XFs = R4ujWMzBdP3kOp()
	else: MOTjA5H9XFs = False
	return MOTjA5H9XFs
def nRVAZc4Dp8PSrGU3xBk():
	x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+'بحث بموسوعة السينما',qpFY4hAwolV3,519)
	x3WSXnKyPhjqfHG2UrtQs('link',xupTj02bvy3O8R+' ===== ===== ===== '+fF4lt9zWYxXLKZVyAco82PgMj,qpFY4hAwolV3,9999)
	x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+'موسوعة الأعمال',qpFY4hAwolV3,525)
	x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+'موسوعة الأشخاص',qpFY4hAwolV3,526)
	x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+'موسوعة المصنفات',qpFY4hAwolV3,527)
	x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+'موسوعة المنوعات',qpFY4hAwolV3,524)
	return
def OOucQ3IaptVrdeFKS7PXJBo1():
	x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+' فيديوهات - خاصة',ddBxj51bhNtaK23lDyGMVw+'/video',520)
	x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+'فيديوهات - أحدث',ddBxj51bhNtaK23lDyGMVw+'/video/latest',521)
	x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+'فيديوهات - أقدم',ddBxj51bhNtaK23lDyGMVw+'/video/oldest',521)
	x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+'فيديوهات - أكثر مشاهدة',ddBxj51bhNtaK23lDyGMVw+'/video/views',521)
	return
def F2p7CdH3INE9v1u5JzksxSBXGPbOj():
	OjpTYEdcHqSUoBt8J = ddBxj51bhNtaK23lDyGMVw+'/lineup?utf8=%E2%9C%93'
	ccx5itXBmuIqe7bYQJSzVEjsG = OjpTYEdcHqSUoBt8J+'&type=2&category=1&foreign=false&tag='
	SdATiLcxvyY = OjpTYEdcHqSUoBt8J+'&type=2&category=3&foreign=false&tag='
	xAIzeW1V8yPgaRcGZFbC5XmD0BHOj = OjpTYEdcHqSUoBt8J+'&type=2&category=1&foreign=true&tag='
	BzGHI90yMOniKqJL3Qh = OjpTYEdcHqSUoBt8J+'&type=2&category=3&foreign=true&tag='
	x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+'مصنفات أفلام عربي',ccx5itXBmuIqe7bYQJSzVEjsG,511)
	x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+'مصنفات مسلسلات عربي',SdATiLcxvyY,511)
	x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+'مصنفات أفلام اجنبي',xAIzeW1V8yPgaRcGZFbC5XmD0BHOj,511)
	x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+'مصنفات مسلسلات اجنبي',BzGHI90yMOniKqJL3Qh,511)
	x3WSXnKyPhjqfHG2UrtQs('link',xupTj02bvy3O8R+' ===== ===== ===== '+fF4lt9zWYxXLKZVyAco82PgMj,qpFY4hAwolV3,9999)
	x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+'فهرس أعمال أبجدي',ddBxj51bhNtaK23lDyGMVw+'/index/work/alphabet',517)
	x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+'فهرس  بلد الإنتاج',ddBxj51bhNtaK23lDyGMVw+'/index/work/country',517)
	x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+'فهرس اللغة',ddBxj51bhNtaK23lDyGMVw+'/index/work/language',517)
	x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+'فهرس مصنفات العمل',ddBxj51bhNtaK23lDyGMVw+'/index/work/genre',517)
	x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+'فهرس سنة الإصدار',ddBxj51bhNtaK23lDyGMVw+'/index/work/release_year',517)
	x3WSXnKyPhjqfHG2UrtQs('link',xupTj02bvy3O8R+' ===== ===== ===== '+fF4lt9zWYxXLKZVyAco82PgMj,qpFY4hAwolV3,9999)
	x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+'مواسم - فلتر محدد',ddBxj51bhNtaK23lDyGMVw+'/seasonals',515)
	x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+'مواسم - فلتر كامل',ddBxj51bhNtaK23lDyGMVw+'/seasonals',514)
	x3WSXnKyPhjqfHG2UrtQs('link',xupTj02bvy3O8R+' ===== ===== ===== '+fF4lt9zWYxXLKZVyAco82PgMj,qpFY4hAwolV3,9999)
	x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+'مصنفات - فلتر محدد',ddBxj51bhNtaK23lDyGMVw+'/lineup',515)
	x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+'مصنفات - فلتر كامل',ddBxj51bhNtaK23lDyGMVw+'/lineup',514)
	return
def R4ujWMzBdP3kOp():
	IAW0sh6So3NpqM = WWrExJZS3Bj4anOAkpv7(KOyPvpEztYLaZRdMQJWxfTNFHbkg,'GET',ddBxj51bhNtaK23lDyGMVw+'/lineup',qpFY4hAwolV3,headers,qpFY4hAwolV3,qpFY4hAwolV3,'ELCINEMA-MENU-1st')
	cmWl9dOKHPIy41iaXuxrY = IAW0sh6So3NpqM.content
	RsAkIZWdfPVpan = AUKntekCmMRFda.BeautifulSoup(cmWl9dOKHPIy41iaXuxrY,'html.parser',multi_valued_attributes=None)
	mVYdjvor6i4wZ8 = RsAkIZWdfPVpan.find('select',attrs={'name':'tag'})
	LBylNhMdH6OV1qGk0tWiXFg3 = mVYdjvor6i4wZ8.find_all('option')
	for FLkeT4nCDqrQMmW6ZSlgyU5jIO32 in LBylNhMdH6OV1qGk0tWiXFg3:
		value = FLkeT4nCDqrQMmW6ZSlgyU5jIO32.get('value')
		if not value: continue
		title = FLkeT4nCDqrQMmW6ZSlgyU5jIO32.text
		if NJwViHDTMdmO0xnALqQ9voPalC3Ip:
			title = title.encode(nV3Tip6XsH1rJw79DPOU)
			value = value.encode(nV3Tip6XsH1rJw79DPOU)
		MepIvHBYNArkUOdV37shtJ = ddBxj51bhNtaK23lDyGMVw+'/lineup?utf8=%E2%9C%93&type=&category=&foreign=&tag='+value
		title = title.replace('قائمة ',qpFY4hAwolV3)
		x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,511)
	return
def ccHtekmIEAOulDC():
	OjpTYEdcHqSUoBt8J = ddBxj51bhNtaK23lDyGMVw+'/lineup?utf8=%E2%9C%93'
	MMd9xVz64U = OjpTYEdcHqSUoBt8J+'&type=1&category=&foreign=&tag='
	x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+'مصنفات أشخاص',MMd9xVz64U,511)
	x3WSXnKyPhjqfHG2UrtQs('link',xupTj02bvy3O8R+' ===== ===== ===== '+fF4lt9zWYxXLKZVyAco82PgMj,qpFY4hAwolV3,9999)
	x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+'فهرس أشخاص أبجدي',ddBxj51bhNtaK23lDyGMVw+'/index/person/alphabet',517)
	x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+'فهرس موطن',ddBxj51bhNtaK23lDyGMVw+'/index/person/nationality',517)
	x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+'فهرس  تاريخ الميلاد',ddBxj51bhNtaK23lDyGMVw+'/index/person/birth_year',517)
	x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+'فهرس  تاريخ الوفاة',ddBxj51bhNtaK23lDyGMVw+'/index/person/death_year',517)
	x3WSXnKyPhjqfHG2UrtQs('link',xupTj02bvy3O8R+' ===== ===== ===== '+fF4lt9zWYxXLKZVyAco82PgMj,qpFY4hAwolV3,9999)
	x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+'مصنفات - فلتر محدد',ddBxj51bhNtaK23lDyGMVw+'/lineup',515)
	x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+'مصنفات - فلتر كامل',ddBxj51bhNtaK23lDyGMVw+'/lineup',514)
	return
def h8HbfF2DRSTXGUoZexKcIwV71n9ldm(url):
	if '/seasonals' in url: P9gc0wx41l3y26iufIkWtaUGnMZ = 0
	elif '/lineup' in url: P9gc0wx41l3y26iufIkWtaUGnMZ = 1
	IAW0sh6So3NpqM = WWrExJZS3Bj4anOAkpv7(KOyPvpEztYLaZRdMQJWxfTNFHbkg,'GET',url,qpFY4hAwolV3,headers,qpFY4hAwolV3,qpFY4hAwolV3,'ELCINEMA-LISTS-1st')
	cmWl9dOKHPIy41iaXuxrY = IAW0sh6So3NpqM.content
	RsAkIZWdfPVpan = AUKntekCmMRFda.BeautifulSoup(cmWl9dOKHPIy41iaXuxrY,'html.parser',multi_valued_attributes=None)
	HLVwBWJ6mFa3ApoNlq178nuXgI = RsAkIZWdfPVpan.find_all(class_='jumbo-theater clearfix')
	for mVYdjvor6i4wZ8 in HLVwBWJ6mFa3ApoNlq178nuXgI:
		title = mVYdjvor6i4wZ8.find_all('a')[P9gc0wx41l3y26iufIkWtaUGnMZ].text
		MepIvHBYNArkUOdV37shtJ = ddBxj51bhNtaK23lDyGMVw+mVYdjvor6i4wZ8.find_all('a')[P9gc0wx41l3y26iufIkWtaUGnMZ].get('href')
		if NJwViHDTMdmO0xnALqQ9voPalC3Ip:
			title = title.encode(nV3Tip6XsH1rJw79DPOU)
			MepIvHBYNArkUOdV37shtJ = MepIvHBYNArkUOdV37shtJ.encode(nV3Tip6XsH1rJw79DPOU)
		if not HLVwBWJ6mFa3ApoNlq178nuXgI:
			ycj2oiD4MrSYT9(MepIvHBYNArkUOdV37shtJ)
			return
		else:
			title = title.replace('قائمة ',qpFY4hAwolV3)
			x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,512)
	RPaQ1dgMHVXltF2(RsAkIZWdfPVpan,511)
	return
def RPaQ1dgMHVXltF2(RsAkIZWdfPVpan,mode):
	mVYdjvor6i4wZ8 = RsAkIZWdfPVpan.find(class_='pagination')
	if mVYdjvor6i4wZ8:
		cTXW5v87yZeEu1sf = mVYdjvor6i4wZ8.find_all('a')
		mSD9IrzqTovayJhtcC = mVYdjvor6i4wZ8.find_all('li')
		ggrDu1VLfioN8zpvdIR5GajwYKWxT = list(zip(cTXW5v87yZeEu1sf,mSD9IrzqTovayJhtcC))
		nnZ13Rr6tYXio0DyfLVvSxBec = -1
		denzA2syBrtfKGZ7gER = len(ggrDu1VLfioN8zpvdIR5GajwYKWxT)
		for oIPJVAsxMyShfcYrqWng,GDhEtUVl5fS4P6nZexONyB in ggrDu1VLfioN8zpvdIR5GajwYKWxT:
			nnZ13Rr6tYXio0DyfLVvSxBec += 1
			GDhEtUVl5fS4P6nZexONyB = GDhEtUVl5fS4P6nZexONyB['class']
			if 'unavailable' in GDhEtUVl5fS4P6nZexONyB or 'current' in GDhEtUVl5fS4P6nZexONyB: continue
			YblzdQaeVqgF = oIPJVAsxMyShfcYrqWng.text
			OexQX2mTwfGkuU6AIBLz9vWlHjdF8 = ddBxj51bhNtaK23lDyGMVw+oIPJVAsxMyShfcYrqWng.get('href')
			if NJwViHDTMdmO0xnALqQ9voPalC3Ip:
				YblzdQaeVqgF = YblzdQaeVqgF.encode(nV3Tip6XsH1rJw79DPOU)
				OexQX2mTwfGkuU6AIBLz9vWlHjdF8 = OexQX2mTwfGkuU6AIBLz9vWlHjdF8.encode(nV3Tip6XsH1rJw79DPOU)
			if   nnZ13Rr6tYXio0DyfLVvSxBec==0: YblzdQaeVqgF = 'أولى'
			elif nnZ13Rr6tYXio0DyfLVvSxBec==1: YblzdQaeVqgF = 'سابقة'
			elif nnZ13Rr6tYXio0DyfLVvSxBec==denzA2syBrtfKGZ7gER-2: YblzdQaeVqgF = 'لاحقة'
			elif nnZ13Rr6tYXio0DyfLVvSxBec==denzA2syBrtfKGZ7gER-1: YblzdQaeVqgF = 'أخيرة'
			x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+'صفحة '+YblzdQaeVqgF,OexQX2mTwfGkuU6AIBLz9vWlHjdF8,mode)
	return
def ycj2oiD4MrSYT9(url):
	IAW0sh6So3NpqM = WWrExJZS3Bj4anOAkpv7(KOyPvpEztYLaZRdMQJWxfTNFHbkg,'GET',url,qpFY4hAwolV3,headers,qpFY4hAwolV3,qpFY4hAwolV3,'ELCINEMA-TITLES1-1st')
	cmWl9dOKHPIy41iaXuxrY = IAW0sh6So3NpqM.content
	RsAkIZWdfPVpan = AUKntekCmMRFda.BeautifulSoup(cmWl9dOKHPIy41iaXuxrY,'html.parser',multi_valued_attributes=None)
	HLVwBWJ6mFa3ApoNlq178nuXgI = RsAkIZWdfPVpan.find_all(class_='row')
	items,QrAXouklfYpzqd = [],True
	for mVYdjvor6i4wZ8 in HLVwBWJ6mFa3ApoNlq178nuXgI:
		if not mVYdjvor6i4wZ8.find(class_='thumbnail-wrapper'): continue
		if QrAXouklfYpzqd: QrAXouklfYpzqd = False ; continue
		XnLPcKfDjH5tZJUI = []
		R5v8lPBX4UDuy9qts1VZdM7nYaIrH = mVYdjvor6i4wZ8.find_all(class_=['censorship red','censorship purple'])
		for hFUrLzpAPBSxdKsXlan6jw3VQieg1 in R5v8lPBX4UDuy9qts1VZdM7nYaIrH:
			kM2XNqgeE1ls47whaRVmTZPd3D5Cn = hFUrLzpAPBSxdKsXlan6jw3VQieg1.find_all('li')[1].text
			if NJwViHDTMdmO0xnALqQ9voPalC3Ip:
				kM2XNqgeE1ls47whaRVmTZPd3D5Cn = kM2XNqgeE1ls47whaRVmTZPd3D5Cn.encode(nV3Tip6XsH1rJw79DPOU)
			XnLPcKfDjH5tZJUI.append(kM2XNqgeE1ls47whaRVmTZPd3D5Cn)
		if not u0E18eO3HnCzr(Q8Q0IDc6PLZajJAdTntKUmSGXz,qpFY4hAwolV3,XnLPcKfDjH5tZJUI,False):
			BvbuigUeoJLnTaN2qWxQ415AtYMK9I = mVYdjvor6i4wZ8.find('img').get('data-src')
			title = mVYdjvor6i4wZ8.find('h3')
			name = title.find('a').text
			MepIvHBYNArkUOdV37shtJ = ddBxj51bhNtaK23lDyGMVw+title.find('a').get('href')
			gvHbq3cC61F = mVYdjvor6i4wZ8.find(class_='no-margin')
			FIwV5JCpGORuNomPAal7k0bvd = mVYdjvor6i4wZ8.find(class_='legend')
			if gvHbq3cC61F: gvHbq3cC61F = gvHbq3cC61F.text
			if FIwV5JCpGORuNomPAal7k0bvd: FIwV5JCpGORuNomPAal7k0bvd = FIwV5JCpGORuNomPAal7k0bvd.text
			if NJwViHDTMdmO0xnALqQ9voPalC3Ip:
				BvbuigUeoJLnTaN2qWxQ415AtYMK9I = BvbuigUeoJLnTaN2qWxQ415AtYMK9I.encode(nV3Tip6XsH1rJw79DPOU)
				name = name.encode(nV3Tip6XsH1rJw79DPOU)
				MepIvHBYNArkUOdV37shtJ = MepIvHBYNArkUOdV37shtJ.encode(nV3Tip6XsH1rJw79DPOU)
				if gvHbq3cC61F: gvHbq3cC61F = gvHbq3cC61F.encode(nV3Tip6XsH1rJw79DPOU)
			uu5WqOEaRZIibszwTc6t1nmLfAj = {}
			if FIwV5JCpGORuNomPAal7k0bvd: uu5WqOEaRZIibszwTc6t1nmLfAj['stars'] = FIwV5JCpGORuNomPAal7k0bvd
			if gvHbq3cC61F:
				gvHbq3cC61F = gvHbq3cC61F.replace(ZLwoRpfnCWI7FgEHsz6te39lMVh,' .. ')
				uu5WqOEaRZIibszwTc6t1nmLfAj['plot'] = gvHbq3cC61F.replace('...اقرأ المزيد',qpFY4hAwolV3)
			if '/work/' in MepIvHBYNArkUOdV37shtJ:
				x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+name,MepIvHBYNArkUOdV37shtJ,516,BvbuigUeoJLnTaN2qWxQ415AtYMK9I,qpFY4hAwolV3,name,qpFY4hAwolV3,uu5WqOEaRZIibszwTc6t1nmLfAj)
			elif '/person/' in MepIvHBYNArkUOdV37shtJ: x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+name,MepIvHBYNArkUOdV37shtJ,513,BvbuigUeoJLnTaN2qWxQ415AtYMK9I,qpFY4hAwolV3,name,qpFY4hAwolV3,uu5WqOEaRZIibszwTc6t1nmLfAj)
	RPaQ1dgMHVXltF2(RsAkIZWdfPVpan,512)
	return
def un6CmqRygD4PfaVvkWO320oYhiQ1TK(url):
	IAW0sh6So3NpqM = WWrExJZS3Bj4anOAkpv7(KOyPvpEztYLaZRdMQJWxfTNFHbkg,'GET',url,qpFY4hAwolV3,headers,qpFY4hAwolV3,qpFY4hAwolV3,'ELCINEMA-TITLES2-1st')
	cmWl9dOKHPIy41iaXuxrY = IAW0sh6So3NpqM.content
	RsAkIZWdfPVpan = AUKntekCmMRFda.BeautifulSoup(cmWl9dOKHPIy41iaXuxrY,'html.parser',multi_valued_attributes=None)
	HLVwBWJ6mFa3ApoNlq178nuXgI = RsAkIZWdfPVpan.find_all('li')
	Lgk6MQxwDv2zhuns5d108X3oREB,items = [],[]
	for mVYdjvor6i4wZ8 in HLVwBWJ6mFa3ApoNlq178nuXgI:
		if not mVYdjvor6i4wZ8.find(class_='thumbnail-wrapper'): continue
		if not mVYdjvor6i4wZ8.find(class_=['unstyled','unstyled text-center']): continue
		if mVYdjvor6i4wZ8.find(class_='hide'): continue
		title = mVYdjvor6i4wZ8.find(class_=['unstyled','unstyled text-center'])
		name = title.find('a').text
		if name in Lgk6MQxwDv2zhuns5d108X3oREB: continue
		Lgk6MQxwDv2zhuns5d108X3oREB.append(name)
		MepIvHBYNArkUOdV37shtJ = ddBxj51bhNtaK23lDyGMVw+title.find('a').get('href')
		if '/search/work/' in url: BvbuigUeoJLnTaN2qWxQ415AtYMK9I = mVYdjvor6i4wZ8.find('img').get('src')
		elif '/search/person/' in url: BvbuigUeoJLnTaN2qWxQ415AtYMK9I = mVYdjvor6i4wZ8.find('img').get('data-src')
		elif '/search/video/' in url: BvbuigUeoJLnTaN2qWxQ415AtYMK9I = mVYdjvor6i4wZ8.find('img').get('data-src')
		else: BvbuigUeoJLnTaN2qWxQ415AtYMK9I = mVYdjvor6i4wZ8.find('img').get('src')
		if NJwViHDTMdmO0xnALqQ9voPalC3Ip:
			name = name.encode(nV3Tip6XsH1rJw79DPOU)
			MepIvHBYNArkUOdV37shtJ = MepIvHBYNArkUOdV37shtJ.encode(nV3Tip6XsH1rJw79DPOU)
			BvbuigUeoJLnTaN2qWxQ415AtYMK9I = BvbuigUeoJLnTaN2qWxQ415AtYMK9I.encode(nV3Tip6XsH1rJw79DPOU)
		name = name.strip(mIsDke0oK5x1zSiOWbF9thGcA)
		items.append((name,MepIvHBYNArkUOdV37shtJ,BvbuigUeoJLnTaN2qWxQ415AtYMK9I))
	if '/search/person/' in url: items = sorted(items,reverse=False,key=lambda key: key[0])
	for name,MepIvHBYNArkUOdV37shtJ,BvbuigUeoJLnTaN2qWxQ415AtYMK9I in items:
		if '/search/video/' in url: x3WSXnKyPhjqfHG2UrtQs('video',wwSFijdVJn1QgHW+name,MepIvHBYNArkUOdV37shtJ,522,BvbuigUeoJLnTaN2qWxQ415AtYMK9I)
		elif '/search/person/' in url: x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+name,MepIvHBYNArkUOdV37shtJ,513,BvbuigUeoJLnTaN2qWxQ415AtYMK9I,qpFY4hAwolV3,name)
		else: x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+name,MepIvHBYNArkUOdV37shtJ,516,BvbuigUeoJLnTaN2qWxQ415AtYMK9I,qpFY4hAwolV3,name)
	return
def zV0Yir1JGoHUKnmwxOcgysB(text):
	text = text.replace('الإعلان',qpFY4hAwolV3).replace('لفيلم',qpFY4hAwolV3).replace('الرسمي',qpFY4hAwolV3)
	text = text.replace('إعلان',qpFY4hAwolV3).replace('فيلم',qpFY4hAwolV3).replace('البرومو',qpFY4hAwolV3)
	text = text.replace('التشويقي',qpFY4hAwolV3).replace('لمسلسل',qpFY4hAwolV3).replace('مسلسل',qpFY4hAwolV3)
	text = text.replace(':',qpFY4hAwolV3).replace(')',qpFY4hAwolV3).replace('(',qpFY4hAwolV3).replace(',',qpFY4hAwolV3)
	text = text.replace('_',qpFY4hAwolV3).replace(';',qpFY4hAwolV3).replace('-',qpFY4hAwolV3).replace('.',qpFY4hAwolV3)
	text = text.replace('\'',qpFY4hAwolV3).replace('\"',qpFY4hAwolV3)
	text = text.replace(M04Bcjvt8SFaeQEK,mIsDke0oK5x1zSiOWbF9thGcA).replace(bJGaEk9wcz,mIsDke0oK5x1zSiOWbF9thGcA).replace(r1roOXYi7UQw9FLThzPEdD0ZlvAnRc,mIsDke0oK5x1zSiOWbF9thGcA)
	text = text.strip(mIsDke0oK5x1zSiOWbF9thGcA)
	Y2JHqRtUBTAcN97QIzV3GFXOKd = text.count(mIsDke0oK5x1zSiOWbF9thGcA)+1
	if Y2JHqRtUBTAcN97QIzV3GFXOKd==1:
		ccuDmH5rph(text)
		return
	x3WSXnKyPhjqfHG2UrtQs('link',wwSFijdVJn1QgHW+xupTj02bvy3O8R+'==== كلمات للبحث ===='+fF4lt9zWYxXLKZVyAco82PgMj,qpFY4hAwolV3,9999)
	l3iHLRtXxBqSdopm = text.split(mIsDke0oK5x1zSiOWbF9thGcA)
	y9yWl0mTvxce8GFDNuhQwOiK = pow(2,Y2JHqRtUBTAcN97QIzV3GFXOKd)
	FpJNgywLfen8jchWB9YqSDA13z = []
	def rBbVpkt38saLDhU9X5(U6UELYIMPuNj8xo9pBWS7vQa5Vgdq,WH8njriXB9oRIZmVKbvPJx):
		if U6UELYIMPuNj8xo9pBWS7vQa5Vgdq=='1': return WH8njriXB9oRIZmVKbvPJx
		return qpFY4hAwolV3
	for nnZ13Rr6tYXio0DyfLVvSxBec in range(y9yWl0mTvxce8GFDNuhQwOiK,0,-1):
		c5cmMZjBkg = list(Y2JHqRtUBTAcN97QIzV3GFXOKd*'0'+bin(nnZ13Rr6tYXio0DyfLVvSxBec)[2:])[-Y2JHqRtUBTAcN97QIzV3GFXOKd:]
		c5cmMZjBkg = reversed(c5cmMZjBkg)
		l0bSC83stEymKhqY5WicIvLP67 = map(rBbVpkt38saLDhU9X5,c5cmMZjBkg,l3iHLRtXxBqSdopm)
		title = mIsDke0oK5x1zSiOWbF9thGcA.join(filter(None,l0bSC83stEymKhqY5WicIvLP67))
		if NJwViHDTMdmO0xnALqQ9voPalC3Ip: UdbGw48M6rCHDRmea5qP91nKI = title.decode(nV3Tip6XsH1rJw79DPOU)
		else: UdbGw48M6rCHDRmea5qP91nKI = title
		if len(UdbGw48M6rCHDRmea5qP91nKI)>2 and title not in FpJNgywLfen8jchWB9YqSDA13z:
			FpJNgywLfen8jchWB9YqSDA13z.append(title)
			x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+title,qpFY4hAwolV3,523,qpFY4hAwolV3,qpFY4hAwolV3,title)
	return
def ccuDmH5rph(BoVz38peOtwnXF9Dry6f15):
	if NJwViHDTMdmO0xnALqQ9voPalC3Ip:
		BoVz38peOtwnXF9Dry6f15 = BoVz38peOtwnXF9Dry6f15.decode(nV3Tip6XsH1rJw79DPOU)
		import arabic_reshaper as BBepFOxkrVbgy39zC1WXHa627m,bidi.algorithm as B4BgYe6SZcIobzPEUDHQs5kyiV
		BoVz38peOtwnXF9Dry6f15 = BBepFOxkrVbgy39zC1WXHa627m.ArabicReshaper().reshape(BoVz38peOtwnXF9Dry6f15)
		BoVz38peOtwnXF9Dry6f15 = B4BgYe6SZcIobzPEUDHQs5kyiV.get_display(BoVz38peOtwnXF9Dry6f15)
	import JSEBrVPTh9
	BoVz38peOtwnXF9Dry6f15 = jXgARlWMLVFUBnvmZwI2o5(DYd8SIqKtoNLVye5Q=BoVz38peOtwnXF9Dry6f15)
	JSEBrVPTh9.PPqUACSE3VcGLTvw05jHy9JrFNW(BoVz38peOtwnXF9Dry6f15)
	return
def x9ODY4hekKZyzcX3HFAL8jawvt6r(url):
	IAW0sh6So3NpqM = WWrExJZS3Bj4anOAkpv7(KOyPvpEztYLaZRdMQJWxfTNFHbkg,'GET',url,qpFY4hAwolV3,headers,qpFY4hAwolV3,qpFY4hAwolV3,'ELCINEMA-INDEXES_LISTS-1st')
	cmWl9dOKHPIy41iaXuxrY = IAW0sh6So3NpqM.content
	RsAkIZWdfPVpan = AUKntekCmMRFda.BeautifulSoup(cmWl9dOKHPIy41iaXuxrY,'html.parser',multi_valued_attributes=None)
	mVYdjvor6i4wZ8 = RsAkIZWdfPVpan.find(class_='list-separator list-title')
	EmejzBHJ28TqtDAZ74NUhF = mVYdjvor6i4wZ8.find_all('a')
	items = []
	for title in EmejzBHJ28TqtDAZ74NUhF:
		name = title.text
		MepIvHBYNArkUOdV37shtJ = ddBxj51bhNtaK23lDyGMVw+title.get('href')
		if NJwViHDTMdmO0xnALqQ9voPalC3Ip:
			name = name.encode(nV3Tip6XsH1rJw79DPOU)
			MepIvHBYNArkUOdV37shtJ = MepIvHBYNArkUOdV37shtJ.encode(nV3Tip6XsH1rJw79DPOU)
		if '#' not in MepIvHBYNArkUOdV37shtJ: items.append((name,MepIvHBYNArkUOdV37shtJ))
	items = sorted(items,reverse=False,key=lambda key: key[0])
	for lkd2oKvZF03qmgMbIfQ6cD in items:
		name,MepIvHBYNArkUOdV37shtJ = lkd2oKvZF03qmgMbIfQ6cD
		x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+name,MepIvHBYNArkUOdV37shtJ,518)
	return
def ddtXrhw3S8Apv2yqcs06ikOzFT(url):
	IAW0sh6So3NpqM = WWrExJZS3Bj4anOAkpv7(KOyPvpEztYLaZRdMQJWxfTNFHbkg,'GET',url,qpFY4hAwolV3,headers,qpFY4hAwolV3,qpFY4hAwolV3,'ELCINEMA-INDEXES_TITLES-1st')
	cmWl9dOKHPIy41iaXuxrY = IAW0sh6So3NpqM.content
	RsAkIZWdfPVpan = AUKntekCmMRFda.BeautifulSoup(cmWl9dOKHPIy41iaXuxrY,'html.parser',multi_valued_attributes=None)
	HLVwBWJ6mFa3ApoNlq178nuXgI = RsAkIZWdfPVpan.find(class_='expand').find_all('tr')
	for mVYdjvor6i4wZ8 in HLVwBWJ6mFa3ApoNlq178nuXgI:
		QQBofdKyERh6lHsFWuk89c7Vt2Sj3 = mVYdjvor6i4wZ8.find_all('a')
		if not QQBofdKyERh6lHsFWuk89c7Vt2Sj3: continue
		BvbuigUeoJLnTaN2qWxQ415AtYMK9I = mVYdjvor6i4wZ8.find('img').get('data-src')
		name = QQBofdKyERh6lHsFWuk89c7Vt2Sj3[1].text
		MepIvHBYNArkUOdV37shtJ = ddBxj51bhNtaK23lDyGMVw+QQBofdKyERh6lHsFWuk89c7Vt2Sj3[1].get('href')
		FIwV5JCpGORuNomPAal7k0bvd = mVYdjvor6i4wZ8.find(class_='legend')
		if FIwV5JCpGORuNomPAal7k0bvd: FIwV5JCpGORuNomPAal7k0bvd = FIwV5JCpGORuNomPAal7k0bvd.text
		if NJwViHDTMdmO0xnALqQ9voPalC3Ip:
			name = name.encode(nV3Tip6XsH1rJw79DPOU)
			MepIvHBYNArkUOdV37shtJ = MepIvHBYNArkUOdV37shtJ.encode(nV3Tip6XsH1rJw79DPOU)
			BvbuigUeoJLnTaN2qWxQ415AtYMK9I = BvbuigUeoJLnTaN2qWxQ415AtYMK9I.encode(nV3Tip6XsH1rJw79DPOU)
		uu5WqOEaRZIibszwTc6t1nmLfAj = {}
		if FIwV5JCpGORuNomPAal7k0bvd: uu5WqOEaRZIibszwTc6t1nmLfAj['stars'] = FIwV5JCpGORuNomPAal7k0bvd
		if '/work/' in MepIvHBYNArkUOdV37shtJ:
			x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+name,MepIvHBYNArkUOdV37shtJ,516,BvbuigUeoJLnTaN2qWxQ415AtYMK9I,qpFY4hAwolV3,name,qpFY4hAwolV3,uu5WqOEaRZIibszwTc6t1nmLfAj)
		elif '/person/' in MepIvHBYNArkUOdV37shtJ: x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+name,MepIvHBYNArkUOdV37shtJ,513,BvbuigUeoJLnTaN2qWxQ415AtYMK9I,qpFY4hAwolV3,name,qpFY4hAwolV3,uu5WqOEaRZIibszwTc6t1nmLfAj)
	RPaQ1dgMHVXltF2(RsAkIZWdfPVpan,518)
	return
def MOlvN6tfud1sS2gbU37GryoRJkT(url):
	IAW0sh6So3NpqM = WWrExJZS3Bj4anOAkpv7(KOyPvpEztYLaZRdMQJWxfTNFHbkg,'GET',url,qpFY4hAwolV3,headers,qpFY4hAwolV3,qpFY4hAwolV3,'ELCINEMA-VIDEOS_LISTS-1st')
	cmWl9dOKHPIy41iaXuxrY = IAW0sh6So3NpqM.content
	RsAkIZWdfPVpan = AUKntekCmMRFda.BeautifulSoup(cmWl9dOKHPIy41iaXuxrY,'html.parser',multi_valued_attributes=None)
	EmejzBHJ28TqtDAZ74NUhF = RsAkIZWdfPVpan.find_all(class_='section-title inline')
	CFevtSjzbpn = RsAkIZWdfPVpan.find_all(class_='button green small right')
	items = zip(EmejzBHJ28TqtDAZ74NUhF,CFevtSjzbpn)
	for title,MepIvHBYNArkUOdV37shtJ in items:
		title = title.text
		MepIvHBYNArkUOdV37shtJ = ddBxj51bhNtaK23lDyGMVw+MepIvHBYNArkUOdV37shtJ.get('href')
		if NJwViHDTMdmO0xnALqQ9voPalC3Ip:
			title = title.encode(nV3Tip6XsH1rJw79DPOU)
			MepIvHBYNArkUOdV37shtJ = MepIvHBYNArkUOdV37shtJ.encode(nV3Tip6XsH1rJw79DPOU)
		title = title.replace(M04Bcjvt8SFaeQEK,mIsDke0oK5x1zSiOWbF9thGcA).replace(bJGaEk9wcz,mIsDke0oK5x1zSiOWbF9thGcA).replace(r1roOXYi7UQw9FLThzPEdD0ZlvAnRc,mIsDke0oK5x1zSiOWbF9thGcA)
		x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,521)
	return
def eRi7kJwPzbBu8gWy4hsO(url):
	IAW0sh6So3NpqM = WWrExJZS3Bj4anOAkpv7(KOyPvpEztYLaZRdMQJWxfTNFHbkg,'GET',url,qpFY4hAwolV3,headers,qpFY4hAwolV3,qpFY4hAwolV3,'ELCINEMA-VIDEOS_TITLES-1st')
	cmWl9dOKHPIy41iaXuxrY = IAW0sh6So3NpqM.content
	RsAkIZWdfPVpan = AUKntekCmMRFda.BeautifulSoup(cmWl9dOKHPIy41iaXuxrY,'html.parser',multi_valued_attributes=None)
	XCVv8wmLKZjBsSI = RsAkIZWdfPVpan.find(class_='large-block-grid-4 medium-block-grid-4 small-block-grid-2')
	HLVwBWJ6mFa3ApoNlq178nuXgI = XCVv8wmLKZjBsSI.find_all('li')
	for mVYdjvor6i4wZ8 in HLVwBWJ6mFa3ApoNlq178nuXgI:
		title = mVYdjvor6i4wZ8.find(class_='title').text
		MepIvHBYNArkUOdV37shtJ = ddBxj51bhNtaK23lDyGMVw+mVYdjvor6i4wZ8.find('a').get('href')
		BvbuigUeoJLnTaN2qWxQ415AtYMK9I = mVYdjvor6i4wZ8.find('img').get('data-src')
		dq0kBrGuKXiP = mVYdjvor6i4wZ8.find(class_='duration').text
		if NJwViHDTMdmO0xnALqQ9voPalC3Ip:
			title = title.encode(nV3Tip6XsH1rJw79DPOU)
			MepIvHBYNArkUOdV37shtJ = MepIvHBYNArkUOdV37shtJ.encode(nV3Tip6XsH1rJw79DPOU)
			BvbuigUeoJLnTaN2qWxQ415AtYMK9I = BvbuigUeoJLnTaN2qWxQ415AtYMK9I.encode(nV3Tip6XsH1rJw79DPOU)
			dq0kBrGuKXiP = dq0kBrGuKXiP.encode(nV3Tip6XsH1rJw79DPOU)
		dq0kBrGuKXiP = dq0kBrGuKXiP.replace(ZLwoRpfnCWI7FgEHsz6te39lMVh,qpFY4hAwolV3).strip(mIsDke0oK5x1zSiOWbF9thGcA)
		x3WSXnKyPhjqfHG2UrtQs('video',wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,522,BvbuigUeoJLnTaN2qWxQ415AtYMK9I,dq0kBrGuKXiP)
	RPaQ1dgMHVXltF2(RsAkIZWdfPVpan,521)
	return
def mzcAeyplZV(url):
	IAW0sh6So3NpqM = WWrExJZS3Bj4anOAkpv7(KOyPvpEztYLaZRdMQJWxfTNFHbkg,'GET',url,qpFY4hAwolV3,headers,qpFY4hAwolV3,qpFY4hAwolV3,'ELCINEMA-PLAY-1st')
	cmWl9dOKHPIy41iaXuxrY = IAW0sh6So3NpqM.content
	RsAkIZWdfPVpan = AUKntekCmMRFda.BeautifulSoup(cmWl9dOKHPIy41iaXuxrY,'html.parser',multi_valued_attributes=None)
	MepIvHBYNArkUOdV37shtJ = RsAkIZWdfPVpan.find(class_='flex-video').find('iframe').get('src')
	if NJwViHDTMdmO0xnALqQ9voPalC3Ip: MepIvHBYNArkUOdV37shtJ = MepIvHBYNArkUOdV37shtJ.encode(nV3Tip6XsH1rJw79DPOU)
	import inVXFK46ET
	inVXFK46ET.q4qTJvuoQUzM3mZAtegy7IXdnb5wH([MepIvHBYNArkUOdV37shtJ],Q8Q0IDc6PLZajJAdTntKUmSGXz,'video',url)
	return
def PPqUACSE3VcGLTvw05jHy9JrFNW(search):
	search,LBylNhMdH6OV1qGk0tWiXFg3,showDialogs = LLm3sBXHPcnTDxdE5gt6hz0Wkp(search)
	if search==qpFY4hAwolV3: search = jXgARlWMLVFUBnvmZwI2o5()
	if search==qpFY4hAwolV3: return
	search = search.replace(mIsDke0oK5x1zSiOWbF9thGcA,'%20')
	url = ddBxj51bhNtaK23lDyGMVw+'/search/?q='+search
	IAW0sh6So3NpqM = WWrExJZS3Bj4anOAkpv7(KOyPvpEztYLaZRdMQJWxfTNFHbkg,'GET',url,qpFY4hAwolV3,headers,qpFY4hAwolV3,qpFY4hAwolV3,'ELCINEMA-SEARCH-1st')
	if not IAW0sh6So3NpqM.succeeded:
		MMd9xVz64U = ddBxj51bhNtaK23lDyGMVw+'/search_entity/?q='+search+'&entity=work'
		OexQX2mTwfGkuU6AIBLz9vWlHjdF8 = ddBxj51bhNtaK23lDyGMVw+'/search_entity/?q='+search+'&entity=person'
		VGDeqXnNCzwJB4LbUvo = ddBxj51bhNtaK23lDyGMVw+'/search_entity/?q='+search+'&entity=video'
		x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+'بحث عن أعمال',MMd9xVz64U,513,qpFY4hAwolV3,search)
		x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+'بحث عن أشخاص',OexQX2mTwfGkuU6AIBLz9vWlHjdF8,513,qpFY4hAwolV3,search)
		x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+'بحث عن فيديوهات',VGDeqXnNCzwJB4LbUvo,513,qpFY4hAwolV3,search)
		return
	cmWl9dOKHPIy41iaXuxrY = IAW0sh6So3NpqM.content
	RsAkIZWdfPVpan = AUKntekCmMRFda.BeautifulSoup(cmWl9dOKHPIy41iaXuxrY,'html.parser',multi_valued_attributes=None)
	HLVwBWJ6mFa3ApoNlq178nuXgI = RsAkIZWdfPVpan.find_all(class_='section-title left')
	for mVYdjvor6i4wZ8 in HLVwBWJ6mFa3ApoNlq178nuXgI:
		title = mVYdjvor6i4wZ8.text
		if NJwViHDTMdmO0xnALqQ9voPalC3Ip:
			title = title.encode(nV3Tip6XsH1rJw79DPOU)
		title = title.split('(',1)[0].strip(mIsDke0oK5x1zSiOWbF9thGcA)
		if   'أعمال' in title: MepIvHBYNArkUOdV37shtJ = url.replace('/search/','/search/work/')
		elif 'أشخاص' in title: MepIvHBYNArkUOdV37shtJ = url.replace('/search/','/search/person/')
		elif 'فيديوهات' in title: MepIvHBYNArkUOdV37shtJ = url.replace('/search/','/search/video/')
		else: continue
		x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,513)
	return
def P0Nsf3Btwo5zhqRDv(url,text):
	global LLAbR2tC6J7OuvqfV4iYg,VlsAo2qQ0BbEhZTgNL9u
	if '/seasonals' in url:
		LLAbR2tC6J7OuvqfV4iYg = ['seasonal','year','category']
		VlsAo2qQ0BbEhZTgNL9u = ['seasonal','year','category']
	elif '/lineup' in url:
		LLAbR2tC6J7OuvqfV4iYg = ['category','foreign','type']
		VlsAo2qQ0BbEhZTgNL9u = ['category','foreign','type']
	R9pWUgVhBGLd2CQb0z(url,text)
	return
def ZcGxoMbewJAYq1sSlV0(url):
	url = url.split('/smartemadfilter?')[0]
	IAW0sh6So3NpqM = WWrExJZS3Bj4anOAkpv7(KOyPvpEztYLaZRdMQJWxfTNFHbkg,'GET',url,qpFY4hAwolV3,headers,qpFY4hAwolV3,qpFY4hAwolV3,'ELCINEMA-GET_FILTERS_BLOCKS-1st')
	cmWl9dOKHPIy41iaXuxrY = IAW0sh6So3NpqM.content
	pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('form action="/(.*?)</form>',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	mVYdjvor6i4wZ8 = pfRkcVlLmUxo561g0A8qSbO[0]
	YF4LRjr6TuagQk9o3PiMeIcHx = ePhmG1jLD6.findall('<select name="(.*?)" id="(.*?)".*?>(.*?)</div>',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
	return YF4LRjr6TuagQk9o3PiMeIcHx
def iiNGgPHcqX4tCAdRUz(mVYdjvor6i4wZ8):
	items = ePhmG1jLD6.findall('<option value="(.*?)">(.*?)<',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
	return items
def L0LEtmdaBXk5VTMpnPx7(url):
	CFNSuRJWb5 = url.split('/smartemadfilter?')[0]
	TIr1DgNEH2jsp8547Fx = AWeJuo2LhZ5xiD8KNSqd9G0rtT74FE(url,'url')
	url = url.replace('/smartemadfilter?','/?utf8=%E2%9C%93&')
	return url
def HgksOMvPnyLEezAjx07bVQJC8a6d(vmTWLw30V2PFNC8DrRqI,url):
	ekvC3tHRVnZGM4uDsmE2pBc5x = ZX8DyBJbV4lNAG(vmTWLw30V2PFNC8DrRqI,'all_filters')
	hhpztscnBD1GP = url+'/smartemadfilter?'+ekvC3tHRVnZGM4uDsmE2pBc5x
	hhpztscnBD1GP = L0LEtmdaBXk5VTMpnPx7(hhpztscnBD1GP)
	return hhpztscnBD1GP
def R9pWUgVhBGLd2CQb0z(url,filter):
	if '?' in url: url = url.split('/smartemadfilter?')[0]
	type,filter = filter.split('___',1)
	if filter==qpFY4hAwolV3: eAYm1EkvcnOzXWpFB68o9rglSQ0M5,M0jc2ZsJHPb1d3DCoyXIzmgt = qpFY4hAwolV3,qpFY4hAwolV3
	else: eAYm1EkvcnOzXWpFB68o9rglSQ0M5,M0jc2ZsJHPb1d3DCoyXIzmgt = filter.split('___')
	if type=='SPECIFIED_FILTER':
		if LLAbR2tC6J7OuvqfV4iYg[0]+'=' not in eAYm1EkvcnOzXWpFB68o9rglSQ0M5: n1uwH0oJaGZ5WBd = LLAbR2tC6J7OuvqfV4iYg[0]
		for a2jQ83ZCfcM5 in range(len(LLAbR2tC6J7OuvqfV4iYg[0:-1])):
			if LLAbR2tC6J7OuvqfV4iYg[a2jQ83ZCfcM5]+'=' in eAYm1EkvcnOzXWpFB68o9rglSQ0M5: n1uwH0oJaGZ5WBd = LLAbR2tC6J7OuvqfV4iYg[a2jQ83ZCfcM5+1]
		OI4ExuWvaLU = eAYm1EkvcnOzXWpFB68o9rglSQ0M5+'&'+n1uwH0oJaGZ5WBd+'=0'
		vmTWLw30V2PFNC8DrRqI = M0jc2ZsJHPb1d3DCoyXIzmgt+'&'+n1uwH0oJaGZ5WBd+'=0'
		nxGqbf39mXPhwl1NtAsSYK = OI4ExuWvaLU.strip('&')+'___'+vmTWLw30V2PFNC8DrRqI.strip('&')
		ekvC3tHRVnZGM4uDsmE2pBc5x = ZX8DyBJbV4lNAG(M0jc2ZsJHPb1d3DCoyXIzmgt,'modified_filters')
		WSQlG8mDhqsNe = url+'/smartemadfilter?'+ekvC3tHRVnZGM4uDsmE2pBc5x
	elif type=='ALL_ITEMS_FILTER':
		Q7PrOdIzEeXgpT4HL38GK = ZX8DyBJbV4lNAG(eAYm1EkvcnOzXWpFB68o9rglSQ0M5,'modified_values')
		Q7PrOdIzEeXgpT4HL38GK = cTt4u6reEMKZqVLplmkNW7(Q7PrOdIzEeXgpT4HL38GK)
		if M0jc2ZsJHPb1d3DCoyXIzmgt!=qpFY4hAwolV3: M0jc2ZsJHPb1d3DCoyXIzmgt = ZX8DyBJbV4lNAG(M0jc2ZsJHPb1d3DCoyXIzmgt,'modified_filters')
		if M0jc2ZsJHPb1d3DCoyXIzmgt==qpFY4hAwolV3: WSQlG8mDhqsNe = url
		else: WSQlG8mDhqsNe = url+'/smartemadfilter?'+M0jc2ZsJHPb1d3DCoyXIzmgt
		WSQlG8mDhqsNe = L0LEtmdaBXk5VTMpnPx7(WSQlG8mDhqsNe)
		x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+'أظهار قائمة الفيديو التي تم اختيارها ',WSQlG8mDhqsNe,511)
		x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+' [[   '+Q7PrOdIzEeXgpT4HL38GK+'   ]]',WSQlG8mDhqsNe,511)
		x3WSXnKyPhjqfHG2UrtQs('link',xupTj02bvy3O8R+' ===== ===== ===== '+fF4lt9zWYxXLKZVyAco82PgMj,qpFY4hAwolV3,9999)
	YF4LRjr6TuagQk9o3PiMeIcHx = ZcGxoMbewJAYq1sSlV0(url)
	dict = {}
	for name,CQlVpYyFN6bzXRBZIMxPWdn,mVYdjvor6i4wZ8 in YF4LRjr6TuagQk9o3PiMeIcHx:
		name = name.replace('--',qpFY4hAwolV3)
		items = iiNGgPHcqX4tCAdRUz(mVYdjvor6i4wZ8)
		if '=' not in WSQlG8mDhqsNe: WSQlG8mDhqsNe = url
		if type=='SPECIFIED_FILTER':
			if CQlVpYyFN6bzXRBZIMxPWdn not in LLAbR2tC6J7OuvqfV4iYg: continue
			if n1uwH0oJaGZ5WBd!=CQlVpYyFN6bzXRBZIMxPWdn: continue
			elif len(items)<2:
				if CQlVpYyFN6bzXRBZIMxPWdn==LLAbR2tC6J7OuvqfV4iYg[-1]:
					url = L0LEtmdaBXk5VTMpnPx7(url)
					ycj2oiD4MrSYT9(url)
				else: R9pWUgVhBGLd2CQb0z(WSQlG8mDhqsNe,'SPECIFIED_FILTER___'+nxGqbf39mXPhwl1NtAsSYK)
				return
			else:
				WSQlG8mDhqsNe = L0LEtmdaBXk5VTMpnPx7(WSQlG8mDhqsNe)
				if CQlVpYyFN6bzXRBZIMxPWdn==LLAbR2tC6J7OuvqfV4iYg[-1]: x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+'الجميع',WSQlG8mDhqsNe,511)
				else: x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+'الجميع',WSQlG8mDhqsNe,515,qpFY4hAwolV3,qpFY4hAwolV3,nxGqbf39mXPhwl1NtAsSYK)
		elif type=='ALL_ITEMS_FILTER':
			if CQlVpYyFN6bzXRBZIMxPWdn not in VlsAo2qQ0BbEhZTgNL9u: continue
			OI4ExuWvaLU = eAYm1EkvcnOzXWpFB68o9rglSQ0M5+'&'+CQlVpYyFN6bzXRBZIMxPWdn+'=0'
			vmTWLw30V2PFNC8DrRqI = M0jc2ZsJHPb1d3DCoyXIzmgt+'&'+CQlVpYyFN6bzXRBZIMxPWdn+'=0'
			nxGqbf39mXPhwl1NtAsSYK = OI4ExuWvaLU+'___'+vmTWLw30V2PFNC8DrRqI
			if   name=='type': name = 'النوع'
			elif name=='category': name = 'العمل'
			elif name=='foreign': name = 'اللغة'
			elif name=='year': name = 'السنة'
			elif name=='seasonal': name = 'الموسم'
			x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+'الجميع: '+name,WSQlG8mDhqsNe,514,qpFY4hAwolV3,qpFY4hAwolV3,nxGqbf39mXPhwl1NtAsSYK)
		dict[CQlVpYyFN6bzXRBZIMxPWdn] = {}
		for value,FLkeT4nCDqrQMmW6ZSlgyU5jIO32 in items:
			if FLkeT4nCDqrQMmW6ZSlgyU5jIO32 in YEIA19ehBwpNfPVzK: continue
			if 'مصنفات أخرى' in FLkeT4nCDqrQMmW6ZSlgyU5jIO32: continue
			if 'الكل' in FLkeT4nCDqrQMmW6ZSlgyU5jIO32: continue
			if 'اللغة' in FLkeT4nCDqrQMmW6ZSlgyU5jIO32: continue
			FLkeT4nCDqrQMmW6ZSlgyU5jIO32 = FLkeT4nCDqrQMmW6ZSlgyU5jIO32.replace('قائمة ',qpFY4hAwolV3)
			if   name=='type': name = 'النوع'
			elif name=='category': name = 'العمل'
			elif name=='foreign': name = 'اللغة'
			elif name=='year': name = 'السنة'
			elif name=='seasonal': name = 'الموسم'
			dict[CQlVpYyFN6bzXRBZIMxPWdn][value] = FLkeT4nCDqrQMmW6ZSlgyU5jIO32
			OI4ExuWvaLU = eAYm1EkvcnOzXWpFB68o9rglSQ0M5+'&'+CQlVpYyFN6bzXRBZIMxPWdn+'='+FLkeT4nCDqrQMmW6ZSlgyU5jIO32
			vmTWLw30V2PFNC8DrRqI = M0jc2ZsJHPb1d3DCoyXIzmgt+'&'+CQlVpYyFN6bzXRBZIMxPWdn+'='+value
			lJWPN5EDIbft92m6iCQqAYLjav4p = OI4ExuWvaLU+'___'+vmTWLw30V2PFNC8DrRqI
			if name: title = FLkeT4nCDqrQMmW6ZSlgyU5jIO32+' :'+name
			else: title = FLkeT4nCDqrQMmW6ZSlgyU5jIO32
			if type=='ALL_ITEMS_FILTER': x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+title,url,514,qpFY4hAwolV3,qpFY4hAwolV3,lJWPN5EDIbft92m6iCQqAYLjav4p)
			elif type=='SPECIFIED_FILTER' and LLAbR2tC6J7OuvqfV4iYg[-2]+'=' in eAYm1EkvcnOzXWpFB68o9rglSQ0M5:
				hhpztscnBD1GP = HgksOMvPnyLEezAjx07bVQJC8a6d(vmTWLw30V2PFNC8DrRqI,url)
				x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+title,hhpztscnBD1GP,511)
			else: x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+title,url,515,qpFY4hAwolV3,qpFY4hAwolV3,lJWPN5EDIbft92m6iCQqAYLjav4p)
	return
def ZX8DyBJbV4lNAG(bbaYxjcVnksy,mode):
	bbaYxjcVnksy = bbaYxjcVnksy.replace('=&','=0&')
	bbaYxjcVnksy = bbaYxjcVnksy.strip('&')
	J9ASCRhfiDyTB = {}
	if '=' in bbaYxjcVnksy:
		items = bbaYxjcVnksy.split('&')
		for lkd2oKvZF03qmgMbIfQ6cD in items:
			JJAsQ4pRYXPhqugN2to9TEzLIS,value = lkd2oKvZF03qmgMbIfQ6cD.split('=')
			J9ASCRhfiDyTB[JJAsQ4pRYXPhqugN2to9TEzLIS] = value
	LxOIqpMU7E1hPKH5fSzj2iW9v = qpFY4hAwolV3
	for key in VlsAo2qQ0BbEhZTgNL9u:
		if key in list(J9ASCRhfiDyTB.keys()): value = J9ASCRhfiDyTB[key]
		else: value = '0'
		if '%' not in value: value = BUKlErdIu7Ggqcz3jYpf09wMePF4V(value)
		if mode=='modified_values' and value!='0': LxOIqpMU7E1hPKH5fSzj2iW9v = LxOIqpMU7E1hPKH5fSzj2iW9v+' + '+value
		elif mode=='modified_filters' and value!='0': LxOIqpMU7E1hPKH5fSzj2iW9v = LxOIqpMU7E1hPKH5fSzj2iW9v+'&'+key+'='+value
		elif mode=='all_filters': LxOIqpMU7E1hPKH5fSzj2iW9v = LxOIqpMU7E1hPKH5fSzj2iW9v+'&'+key+'='+value
	LxOIqpMU7E1hPKH5fSzj2iW9v = LxOIqpMU7E1hPKH5fSzj2iW9v.strip(' + ')
	LxOIqpMU7E1hPKH5fSzj2iW9v = LxOIqpMU7E1hPKH5fSzj2iW9v.strip('&')
	LxOIqpMU7E1hPKH5fSzj2iW9v = LxOIqpMU7E1hPKH5fSzj2iW9v.replace('=0','=')
	return LxOIqpMU7E1hPKH5fSzj2iW9v
LLAbR2tC6J7OuvqfV4iYg = []
VlsAo2qQ0BbEhZTgNL9u = []