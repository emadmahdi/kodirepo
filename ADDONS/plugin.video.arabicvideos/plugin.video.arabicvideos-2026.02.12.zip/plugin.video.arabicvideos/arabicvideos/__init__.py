# -*- coding: utf-8 -*-
import sys as TSRUP0dExYGQg
mgNMJhrjcq1xb = TSRUP0dExYGQg.version_info [0] == 2
lQJvf8UXo2de9gjCatY4yH = 2048
YuTB2OjotvlR = 7
def kk0DKyarxq9eS1zwGLMFQTZN35dj (neqP2if8IOJ50aNKcCBLrXdZk):
	global sWerUpk6nQwT7zY43
	vxdNQUujz7ZFV4rtOSK2 = ord (neqP2if8IOJ50aNKcCBLrXdZk [-1])
	yyshZX35KO7JodYjD9qVib6 = neqP2if8IOJ50aNKcCBLrXdZk [:-1]
	fuKReXJ3HPIAU7c = vxdNQUujz7ZFV4rtOSK2 % len (yyshZX35KO7JodYjD9qVib6)
	EEFQdvXog7LPC4Sie0jDkUKxn6M = yyshZX35KO7JodYjD9qVib6 [:fuKReXJ3HPIAU7c] + yyshZX35KO7JodYjD9qVib6 [fuKReXJ3HPIAU7c:]
	if mgNMJhrjcq1xb:
		Clh5YS0XPue68EgT4Uq17GL = unicode () .join ([unichr (ord (AsGVDZFgmuH06jviYrWXTz) - lQJvf8UXo2de9gjCatY4yH - (XvhDIL4ZpzaPs91WkoGnedCEA2rt + vxdNQUujz7ZFV4rtOSK2) % YuTB2OjotvlR) for XvhDIL4ZpzaPs91WkoGnedCEA2rt, AsGVDZFgmuH06jviYrWXTz in enumerate (EEFQdvXog7LPC4Sie0jDkUKxn6M)])
	else:
		Clh5YS0XPue68EgT4Uq17GL = str () .join ([chr (ord (AsGVDZFgmuH06jviYrWXTz) - lQJvf8UXo2de9gjCatY4yH - (XvhDIL4ZpzaPs91WkoGnedCEA2rt + vxdNQUujz7ZFV4rtOSK2) % YuTB2OjotvlR) for XvhDIL4ZpzaPs91WkoGnedCEA2rt, AsGVDZFgmuH06jviYrWXTz in enumerate (EEFQdvXog7LPC4Sie0jDkUKxn6M)])
	return eval (Clh5YS0XPue68EgT4Uq17GL)
qoBMmfAWpFlK70xw8ZRh4naJ,lljaEqwTVtmKsQcOrbXxS5hgNH,aXqWLoTdVgME=kk0DKyarxq9eS1zwGLMFQTZN35dj,kk0DKyarxq9eS1zwGLMFQTZN35dj,kk0DKyarxq9eS1zwGLMFQTZN35dj
UVa3fJw7k6KM,fWoVd0Bmtkx,tQMjXKCA5dN4xq3beVIzaEoWkFLg=aXqWLoTdVgME,lljaEqwTVtmKsQcOrbXxS5hgNH,qoBMmfAWpFlK70xw8ZRh4naJ
viRJWOC5jsYe84,Ie5s2cBtSfdHjzQ4rA9kYlo6D18,sjtU6GZQg5XC2pH4=tQMjXKCA5dN4xq3beVIzaEoWkFLg,fWoVd0Bmtkx,UVa3fJw7k6KM
LZWMikPEB81KSGyxfJtUsCA,rNdBKI74fAklnoCZ6,BRWqdruz2A0=sjtU6GZQg5XC2pH4,Ie5s2cBtSfdHjzQ4rA9kYlo6D18,viRJWOC5jsYe84
CC1eY6yWZUwf2TkRvnp7EJ0AimjHBX,qqzwE6imYG4c2xojI,N3flV6EJsD5CzS=BRWqdruz2A0,rNdBKI74fAklnoCZ6,LZWMikPEB81KSGyxfJtUsCA
UUDAiytEL76RTmMYsuIz5evXB,IaBhDMJc17302LgSvyxd,ddiCzu6yahj5RtTISMJ48sNnZBU=N3flV6EJsD5CzS,qqzwE6imYG4c2xojI,CC1eY6yWZUwf2TkRvnp7EJ0AimjHBX
dJHDqiKf12TXlIzSLkGUuxg4MBs3A,l1DZAt9XNQjqE7YOdrz,l32dnTEOU1skGKqeBtI9hmo=ddiCzu6yahj5RtTISMJ48sNnZBU,IaBhDMJc17302LgSvyxd,UUDAiytEL76RTmMYsuIz5evXB
zYvEaigKWjoq50pXBLDbGJkFc,iNc3KxwErnQ,V3VlkhgjEF4n1erPXHcC0NOsfwyAJ=l32dnTEOU1skGKqeBtI9hmo,l1DZAt9XNQjqE7YOdrz,dJHDqiKf12TXlIzSLkGUuxg4MBs3A
tR1krDGPpO025fghMT3a7UnYj,c2RKu0xG1eC8MiohyE,RlOvin8YIGC2KZXJPk9m0acrMobUex=V3VlkhgjEF4n1erPXHcC0NOsfwyAJ,iNc3KxwErnQ,zYvEaigKWjoq50pXBLDbGJkFc
YY8UDX3MJhb91AHw7fg,ee86G9ladLHVbh5mikzCo,mmV2nucZ5Lpl6FO1JMPEqGoQKW=RlOvin8YIGC2KZXJPk9m0acrMobUex,c2RKu0xG1eC8MiohyE,tR1krDGPpO025fghMT3a7UnYj
DaFZHsThGmd0zv6e,kYDaz79TFlXoR,DiJ8CMuYH1daWyjehfN0L=mmV2nucZ5Lpl6FO1JMPEqGoQKW,ee86G9ladLHVbh5mikzCo,YY8UDX3MJhb91AHw7fg
from NKn4FXivsk import *
Q8Q0IDc6PLZajJAdTntKUmSGXz = l32dnTEOU1skGKqeBtI9hmo(u"ࠫࡎࡔࡉࡕࠩᏥ")
qUvjlnCTrhWOEbwNHyAzfp = DiJ8CMuYH1daWyjehfN0L(u"ࠬࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠬᏦ")
kc8s5wJ4Px9zbiWQm,mJjTE9o7ecN8dt,Cm4xfTO625jyMtZ8GEpvuKcnbQ1gD,HNdWR8p36CtO,BvbuigUeoJLnTaN2qWxQ415AtYMK9I,i02wfPp5EM,Z4vQNwLcAiPVufj9sOgCMU6ezEWG,AArDKw6baWehCSOz7,uu5WqOEaRZIibszwTc6t1nmLfAj = GGhmwblaotTRZJCfcWDX50gxELS4(Ry9jtldkPEA)
wc8X04F1e6u = int(HNdWR8p36CtO)
yyV93CAujmWlEMsbf0Iv = Rqvw05BorCgcye7VE32Sf.getInfoLabel(rNdBKI74fAklnoCZ6(u"࠭ࡌࡪࡵࡷࡍࡹ࡫࡭࠯ࡎࡤࡦࡪࡲࠧᏧ"))
yyV93CAujmWlEMsbf0Iv = yyV93CAujmWlEMsbf0Iv.replace(AqhZ0J2BSD9xrRwM8UflykVmE,qpFY4hAwolV3).replace(iijW0NsODK8odeFuBEvIx5lpawkb9n,qpFY4hAwolV3)
if wc8X04F1e6u==DiJ8CMuYH1daWyjehfN0L(u"࠷࠼࠰ᐐ"): LNoercE1x8bRQPTI = N3flV6EJsD5CzS(u"࡚ࠧࠡࠢࠣࡪࡸࡳࡪࡱࡱ࠾ࠥࡡࠠࠨᏨ")+Q8q1YzIF6icWtSp2L+UVa3fJw7k6KM(u"ࠨࠢࡠࠤࠥࠦࡋࡰࡦ࡬࠾ࠥࡡࠠࠨᏩ")+wjuB8sDm0oPfShXWp+qqzwE6imYG4c2xojI(u"ࠩࠣࡡࠬᏪ")
else:
	MdpnvycqN0lBk = cTt4u6reEMKZqVLplmkNW7(Ry9jtldkPEA).replace(xupTj02bvy3O8R,qpFY4hAwolV3).replace(IQ2KCmObsTGuiRdEzt931a40jLg,qpFY4hAwolV3)
	MdpnvycqN0lBk = MdpnvycqN0lBk.replace(fF4lt9zWYxXLKZVyAco82PgMj,qpFY4hAwolV3).strip(mIsDke0oK5x1zSiOWbF9thGcA)
	MdpnvycqN0lBk = MdpnvycqN0lBk.replace(M04Bcjvt8SFaeQEK,mIsDke0oK5x1zSiOWbF9thGcA).replace(bJGaEk9wcz,mIsDke0oK5x1zSiOWbF9thGcA).replace(r1roOXYi7UQw9FLThzPEdD0ZlvAnRc,mIsDke0oK5x1zSiOWbF9thGcA)
	if l32dnTEOU1skGKqeBtI9hmo(u"ࠪࠪࡺࡸ࡬࠾ࠩᏫ") in MdpnvycqN0lBk:
		MdpnvycqN0lBk,EPdcnA0gsh6 = MdpnvycqN0lBk.rsplit(N3flV6EJsD5CzS(u"ࠫࠫࡻࡲ࡭࠿ࠪᏬ"),qqzwE6imYG4c2xojI(u"࠷ᐑ"))
		MdpnvycqN0lBk += rNdBKI74fAklnoCZ6(u"ࠬࠬࡵࡳ࡮ࡀࠫᏭ")+DObEAlBf39(EPdcnA0gsh6,Q8Q0IDc6PLZajJAdTntKUmSGXz)
	LNoercE1x8bRQPTI = iNc3KxwErnQ(u"࠭ࠠࠡࠢࡏࡥࡧ࡫࡬࠻ࠢ࡞ࠤࠬᏮ")+yyV93CAujmWlEMsbf0Iv+zYvEaigKWjoq50pXBLDbGJkFc(u"ࠧࠡ࡟ࠣࠤࠥࡓ࡯ࡥࡧ࠽ࠤࡠࠦࠧᏯ")+HNdWR8p36CtO+aXqWLoTdVgME(u"ࠨࠢࡠࠤࠥࠦࡐࡢࡶ࡫࠾ࠥࡡࠠࠨᏰ")+MdpnvycqN0lBk+BRWqdruz2A0(u"ࠩࠣࡡࠬᏱ")
LLvyStW429DEZKlA(k8kdUSxohLVljnrY,qUvjlnCTrhWOEbwNHyAzfp+ZLwoRpfnCWI7FgEHsz6te39lMVh+lTW9p1v7uPfOxB(Q8Q0IDc6PLZajJAdTntKUmSGXz)+LNoercE1x8bRQPTI)
if UVa3fJw7k6KM(u"ࠪࡣࠬᏲ") in AArDKw6baWehCSOz7: TILw6pQSxlhMUCJK5qZbv4o,DRbhWYuzweV3IMNCyJv8oZj10Tk = AArDKw6baWehCSOz7.split(DaFZHsThGmd0zv6e(u"ࠫࡤ࠭Ᏻ"),mZi0S72jGoHpLO)
else: TILw6pQSxlhMUCJK5qZbv4o,DRbhWYuzweV3IMNCyJv8oZj10Tk = AArDKw6baWehCSOz7,qpFY4hAwolV3
i4bFG3rKE6.YYhTKn1kR9i,ggnX3IOk2LPMd = ag8rjZo1Vz4IPdcOT,qpFY4hAwolV3
lnfb4aphe1BE508kjPcqM3OoUvg2 = ag8rjZo1Vz4IPdcOT
if TILw6pQSxlhMUCJK5qZbv4o in [tR1krDGPpO025fghMT3a7UnYj(u"ࠬ࠷ࠧᏴ"),BRWqdruz2A0(u"࠭࠲ࠨᏵ"),dJHDqiKf12TXlIzSLkGUuxg4MBs3A(u"ࠧ࠴ࠩ᏶"),UVa3fJw7k6KM(u"ࠨ࠶ࠪ᏷"),ddiCzu6yahj5RtTISMJ48sNnZBU(u"ࠩ࠸ࠫᏸ"),ddiCzu6yahj5RtTISMJ48sNnZBU(u"ࠪ࠵࠶࠭ᏹ"),ee86G9ladLHVbh5mikzCo(u"ࠫ࠶࠸ࠧᏺ"),dJHDqiKf12TXlIzSLkGUuxg4MBs3A(u"ࠬ࠷࠳ࠨᏻ")] and (rNdBKI74fAklnoCZ6(u"࠭ࡁࡅࡆࠪᏼ") in DRbhWYuzweV3IMNCyJv8oZj10Tk or BRWqdruz2A0(u"ࠧࡓࡇࡐࡓ࡛ࡋࠧᏽ") in DRbhWYuzweV3IMNCyJv8oZj10Tk or ddiCzu6yahj5RtTISMJ48sNnZBU(u"ࠨࡗࡓࠫ᏾") in DRbhWYuzweV3IMNCyJv8oZj10Tk or DiJ8CMuYH1daWyjehfN0L(u"ࠩࡇࡓ࡜ࡔࠧ᏿") in DRbhWYuzweV3IMNCyJv8oZj10Tk):
	from SAyf06eKY3 import dmFAy3UQ2eRbJDfiNLBMX6H9tsrv
	dmFAy3UQ2eRbJDfiNLBMX6H9tsrv(AArDKw6baWehCSOz7,TILw6pQSxlhMUCJK5qZbv4o,DRbhWYuzweV3IMNCyJv8oZj10Tk)
	gdPslyFW8ITBcpA302.setSetting(N3flV6EJsD5CzS(u"ࠪࡥࡻ࠴ࡳࡵࡣࡷࡹࡸ࠴ࡲࡦࡨࡵࡩࡸ࡮ࠧ᐀"),Ry9jtldkPEA)
	i4bFG3rKE6.YYhTKn1kR9i = gBExoceumj4y8bFW9hY2aNMVSr
elif not TILw6pQSxlhMUCJK5qZbv4o and not sOYTrW4HDRgG and wc8X04F1e6u in [RlOvin8YIGC2KZXJPk9m0acrMobUex(u"࠲࠴࠷ᐒ"),IaBhDMJc17302LgSvyxd(u"࠸࠳࠸ᐓ")]:
	LLcgQ6E12OZezYbh4CVdIa = str(uu5WqOEaRZIibszwTc6t1nmLfAj[tR1krDGPpO025fghMT3a7UnYj(u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᐁ")])
	Q8Q0IDc6PLZajJAdTntKUmSGXz = l1DZAt9XNQjqE7YOdrz(u"ࠬࡏࡐࡕࡘࠪᐂ") if wc8X04F1e6u==DaFZHsThGmd0zv6e(u"࠴࠶࠹ᐔ") else CC1eY6yWZUwf2TkRvnp7EJ0AimjHBX(u"࠭ࡍ࠴ࡗࠪᐃ")
	rhYMFkl6HCx = Q8Q0IDc6PLZajJAdTntKUmSGXz.lower()
	NNWJKEyq13t2kglAZ7d = gdPslyFW8ITBcpA302.getSetting(IaBhDMJc17302LgSvyxd(u"ࠧࡢࡸ࠱ࠫᐄ")+rhYMFkl6HCx+IaBhDMJc17302LgSvyxd(u"ࠨ࠰ࡸࡷࡪࡸࡡࡨࡧࡱࡸࡤ࠭ᐅ")+LLcgQ6E12OZezYbh4CVdIa)
	SPhHAEby41Wa = gdPslyFW8ITBcpA302.getSetting(UUDAiytEL76RTmMYsuIz5evXB(u"ࠩࡤࡺ࠳࠭ᐆ")+rhYMFkl6HCx+DiJ8CMuYH1daWyjehfN0L(u"ࠪ࠲ࡷ࡫ࡦࡦࡴࡨࡶࡤ࠭ᐇ")+LLcgQ6E12OZezYbh4CVdIa)
	if NNWJKEyq13t2kglAZ7d or SPhHAEby41Wa:
		Cm4xfTO625jyMtZ8GEpvuKcnbQ1gD += UUDAiytEL76RTmMYsuIz5evXB(u"ࠫࢁ࠭ᐈ")
		if NNWJKEyq13t2kglAZ7d: Cm4xfTO625jyMtZ8GEpvuKcnbQ1gD += mmV2nucZ5Lpl6FO1JMPEqGoQKW(u"ࠬࠬࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࡀࠫᐉ")+NNWJKEyq13t2kglAZ7d
		if SPhHAEby41Wa: Cm4xfTO625jyMtZ8GEpvuKcnbQ1gD += YY8UDX3MJhb91AHw7fg(u"࠭ࠦࡓࡧࡩࡩࡷ࡫ࡲ࠾ࠩᐊ")+SPhHAEby41Wa
		Cm4xfTO625jyMtZ8GEpvuKcnbQ1gD = Cm4xfTO625jyMtZ8GEpvuKcnbQ1gD.replace(viRJWOC5jsYe84(u"ࠧࡽࠨࠪᐋ"),iNc3KxwErnQ(u"ࠨࡾࠪᐌ"))
	G2zVpmYHBC6FNJtOUPe97iA0 = gdPslyFW8ITBcpA302.getSetting(viRJWOC5jsYe84(u"ࠩࡤࡺ࠳࠭ᐍ")+rhYMFkl6HCx+viRJWOC5jsYe84(u"ࠪ࠲ࡸ࡫ࡲࡷࡧࡵࡣࠬᐎ")+LLcgQ6E12OZezYbh4CVdIa)
	if G2zVpmYHBC6FNJtOUPe97iA0:
		Hj9ehmP3QoVzKEsUtTJA = ePhmG1jLD6.findall(tQMjXKCA5dN4xq3beVIzaEoWkFLg(u"ࠫ࠿࠵࠯ࠩ࠰࠭ࡃ࠮࠵ࠧᐏ"),Cm4xfTO625jyMtZ8GEpvuKcnbQ1gD,ePhmG1jLD6.DOTALL)
		Cm4xfTO625jyMtZ8GEpvuKcnbQ1gD = Cm4xfTO625jyMtZ8GEpvuKcnbQ1gD.replace(Hj9ehmP3QoVzKEsUtTJA[vvXoMLlg513],G2zVpmYHBC6FNJtOUPe97iA0)
	dORtnXbEgi5A8m0CH(Cm4xfTO625jyMtZ8GEpvuKcnbQ1gD,Q8Q0IDc6PLZajJAdTntKUmSGXz,kc8s5wJ4Px9zbiWQm)
	lnfb4aphe1BE508kjPcqM3OoUvg2 = gBExoceumj4y8bFW9hY2aNMVSr
else:
	import pSfaryIjBo
	try: pSfaryIjBo.pu5OZtyNK1LCqUR0n37wlxP9DTG(kc8s5wJ4Px9zbiWQm,mJjTE9o7ecN8dt,Cm4xfTO625jyMtZ8GEpvuKcnbQ1gD,HNdWR8p36CtO,BvbuigUeoJLnTaN2qWxQ415AtYMK9I,i02wfPp5EM,Z4vQNwLcAiPVufj9sOgCMU6ezEWG,AArDKw6baWehCSOz7,uu5WqOEaRZIibszwTc6t1nmLfAj,wc8X04F1e6u,TILw6pQSxlhMUCJK5qZbv4o,DRbhWYuzweV3IMNCyJv8oZj10Tk,yyV93CAujmWlEMsbf0Iv)
	except Exception as pnjEV0aCuY6oZ9M4k8sF1d: ggnX3IOk2LPMd = ralpo6SjWw9FGVfcINEgXB0ZDnT.format_exc()
HXj5aRF6VDA4bMkwWBOc1oJ(i4bFG3rKE6.YYhTKn1kR9i,ggnX3IOk2LPMd,lnfb4aphe1BE508kjPcqM3OoUvg2)