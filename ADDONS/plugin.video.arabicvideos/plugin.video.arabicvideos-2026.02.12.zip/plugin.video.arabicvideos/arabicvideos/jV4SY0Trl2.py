# -*- coding: utf-8 -*-
from pSfaryIjBo import *
VwkA0oma2Nf = 'M3U'
KKxc2jv9sQZOpV = '_M3U_'
Va04phzWlCG = [
		 'IGNORED'
		,'LIVE_UNKNOWN_GROUPED','LIVE_UNKNOWN_GROUPED_SORTED'
		,'VOD_UNKNOWN_GROUPED','VOD_UNKNOWN_GROUPED_SORTED'
		,'LIVE_GROUPED','LIVE_GROUPED_SORTED'
		,'LIVE_ORIGINAL_GROUPED','LIVE_FROM_GROUP_SORTED','LIVE_FROM_NAME_SORTED'
		,'VOD_MOVIES_GROUPED','VOD_MOVIES_GROUPED_SORTED'
		,'VOD_SERIES_GROUPED','VOD_SERIES_GROUPED_SORTED'
		,'VOD_ORIGINAL_GROUPED','VOD_FROM_GROUP_SORTED','VOD_FROM_NAME_SORTED'
		]
cqSFolBs7A1G0X9u4a6K = 4
def iPV7rXlx3Za(ZyiMa3BXVk2xWG0b,WWowRmHkj1ZAO2SUhtNvdrcKa9E6C,HY7yaJeI89xE56sbTjdBRZPDwQKFX,lQnA93TCSoqKwIMJNz8L,aazJgfh6MTFGtP8SRoCDW9UZq,mDgvl5LzhR26eNVM3UaIuHtpif):
	global KKxc2jv9sQZOpV
	try:
		m4W3gU71on2PF = str(mDgvl5LzhR26eNVM3UaIuHtpif['folder'])
		KKxc2jv9sQZOpV = '_MU'+m4W3gU71on2PF+'_'
	except: m4W3gU71on2PF = qpFY4hAwolV3
	try: rrgusv6oweD3tT = str(mDgvl5LzhR26eNVM3UaIuHtpif['sequence'])
	except: rrgusv6oweD3tT = qpFY4hAwolV3
	if   ZyiMa3BXVk2xWG0b==710: slKYBZe0zC3WF6XSunQar = MpPhKn6Rw3A()
	elif ZyiMa3BXVk2xWG0b==711: slKYBZe0zC3WF6XSunQar = aF2eXlORwA5Dr(m4W3gU71on2PF,rrgusv6oweD3tT)
	elif ZyiMa3BXVk2xWG0b==712: slKYBZe0zC3WF6XSunQar = bzdJ7qHRfEuKghjnNwD04MPYa(m4W3gU71on2PF)
	elif ZyiMa3BXVk2xWG0b==713: slKYBZe0zC3WF6XSunQar = xxHg8EI03NwfKGpYtjrs7WDinR(m4W3gU71on2PF,WWowRmHkj1ZAO2SUhtNvdrcKa9E6C,HY7yaJeI89xE56sbTjdBRZPDwQKFX,aazJgfh6MTFGtP8SRoCDW9UZq)
	elif ZyiMa3BXVk2xWG0b==714: slKYBZe0zC3WF6XSunQar = I19sHuzZ8RryYXSwgV7mQ3Dh(m4W3gU71on2PF,WWowRmHkj1ZAO2SUhtNvdrcKa9E6C,HY7yaJeI89xE56sbTjdBRZPDwQKFX,aazJgfh6MTFGtP8SRoCDW9UZq)
	elif ZyiMa3BXVk2xWG0b==715: slKYBZe0zC3WF6XSunQar = mzcAeyplZV(m4W3gU71on2PF,WWowRmHkj1ZAO2SUhtNvdrcKa9E6C,lQnA93TCSoqKwIMJNz8L)
	elif ZyiMa3BXVk2xWG0b==716: slKYBZe0zC3WF6XSunQar = KIRfl5Tr3Vs(m4W3gU71on2PF,True)
	elif ZyiMa3BXVk2xWG0b==717: slKYBZe0zC3WF6XSunQar = F7jBEp8OsVkZ(m4W3gU71on2PF,True)
	elif ZyiMa3BXVk2xWG0b==718: slKYBZe0zC3WF6XSunQar = x9KgQBLDPCRF0yhnmt4Jj2XHEIvza(m4W3gU71on2PF,WWowRmHkj1ZAO2SUhtNvdrcKa9E6C,HY7yaJeI89xE56sbTjdBRZPDwQKFX)
	elif ZyiMa3BXVk2xWG0b==719: slKYBZe0zC3WF6XSunQar = DpkVswXMr9iWB0OPAYqFNaK7(HY7yaJeI89xE56sbTjdBRZPDwQKFX,m4W3gU71on2PF,WWowRmHkj1ZAO2SUhtNvdrcKa9E6C,aazJgfh6MTFGtP8SRoCDW9UZq)
	elif ZyiMa3BXVk2xWG0b==720: slKYBZe0zC3WF6XSunQar = XwvsYGlxEn5dSNybeJkBcg9(m4W3gU71on2PF,True)
	elif ZyiMa3BXVk2xWG0b==721: slKYBZe0zC3WF6XSunQar = vcU6kyVAKWY3S2ue7tOr5XihJ9xo(m4W3gU71on2PF)
	elif ZyiMa3BXVk2xWG0b==722: slKYBZe0zC3WF6XSunQar = SwbDsXYkc4g7AyQoINO6(m4W3gU71on2PF)
	elif ZyiMa3BXVk2xWG0b==723: slKYBZe0zC3WF6XSunQar = Jx4WKDnLzw7vea(m4W3gU71on2PF)
	elif ZyiMa3BXVk2xWG0b==726: slKYBZe0zC3WF6XSunQar = OOFloIqBfA5VKvs78d3E1k(m4W3gU71on2PF)
	elif ZyiMa3BXVk2xWG0b==729: slKYBZe0zC3WF6XSunQar = N1aBfRWYkGAK(HY7yaJeI89xE56sbTjdBRZPDwQKFX,m4W3gU71on2PF,WWowRmHkj1ZAO2SUhtNvdrcKa9E6C,aazJgfh6MTFGtP8SRoCDW9UZq)
	else: slKYBZe0zC3WF6XSunQar = False
	return slKYBZe0zC3WF6XSunQar
def MpPhKn6Rw3A():
	for m4W3gU71on2PF in range(1,v2ir6R7FZASfMOl4wqTLKBNupX5E+1):
		KKxc2jv9sQZOpV = '_MU'+str(m4W3gU71on2PF)+'_'
		x3WSXnKyPhjqfHG2UrtQs('folder',KKxc2jv9sQZOpV+'قائمة مجلد '+ppn5vq8QdBsEhckl[m4W3gU71on2PF],qpFY4hAwolV3,720,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,{'folder':m4W3gU71on2PF})
	return
def XwvsYGlxEn5dSNybeJkBcg9(m4W3gU71on2PF=qpFY4hAwolV3,kcmbnMYF2WpDg0ti4UyCf3AV=qpFY4hAwolV3):
	if m4W3gU71on2PF:
		PPz1VyOXFYhk2IT35c = {'folder':m4W3gU71on2PF}
		s2lOfK1TeCx = qpFY4hAwolV3
	else:
		PPz1VyOXFYhk2IT35c = qpFY4hAwolV3
		s2lOfK1TeCx = qpFY4hAwolV3
	WD6IJtMcbZn7rwNk = N4mtgDP83waX9(m4W3gU71on2PF,kcmbnMYF2WpDg0ti4UyCf3AV)
	if not WD6IJtMcbZn7rwNk:
		x3WSXnKyPhjqfHG2UrtQs('link',KKxc2jv9sQZOpV+IQ2KCmObsTGuiRdEzt931a40jLg+' إضافة وتغيير رابط'+s2lOfK1TeCx+mIsDke0oK5x1zSiOWbF9thGcA+ppn5vq8QdBsEhckl[1]+' '+fF4lt9zWYxXLKZVyAco82PgMj,qpFY4hAwolV3,711,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,{'folder':m4W3gU71on2PF,'sequence':1})
		x3WSXnKyPhjqfHG2UrtQs('link',KKxc2jv9sQZOpV+IQ2KCmObsTGuiRdEzt931a40jLg+' جلب ملفات'+s2lOfK1TeCx+' '+fF4lt9zWYxXLKZVyAco82PgMj,qpFY4hAwolV3,712,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,PPz1VyOXFYhk2IT35c)
		x3WSXnKyPhjqfHG2UrtQs('link',xupTj02bvy3O8R+' ===== ===== ===== '+fF4lt9zWYxXLKZVyAco82PgMj,qpFY4hAwolV3,9999)
	else:
		x3WSXnKyPhjqfHG2UrtQs('folder',KKxc2jv9sQZOpV+'بحث في الملفات'+s2lOfK1TeCx,qpFY4hAwolV3,729,qpFY4hAwolV3,qpFY4hAwolV3,'_REMEMBERRESULTS_',qpFY4hAwolV3,PPz1VyOXFYhk2IT35c)
		x3WSXnKyPhjqfHG2UrtQs('link',xupTj02bvy3O8R+' ===== ===== ===== '+fF4lt9zWYxXLKZVyAco82PgMj,qpFY4hAwolV3,9999)
		x3WSXnKyPhjqfHG2UrtQs('folder',KKxc2jv9sQZOpV+'قنوات مصنفة مرتبة'+s2lOfK1TeCx,'LIVE_GROUPED_SORTED',713,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,PPz1VyOXFYhk2IT35c)
		x3WSXnKyPhjqfHG2UrtQs('folder',KKxc2jv9sQZOpV+'قنوات مصنفة من القسم'+s2lOfK1TeCx,'LIVE_FROM_GROUP_SORTED',713,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,PPz1VyOXFYhk2IT35c)
		x3WSXnKyPhjqfHG2UrtQs('folder',KKxc2jv9sQZOpV+'قنوات مصنفة من الاسم'+s2lOfK1TeCx,'LIVE_FROM_NAME_SORTED',713,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,PPz1VyOXFYhk2IT35c)
		x3WSXnKyPhjqfHG2UrtQs('folder',KKxc2jv9sQZOpV+'قنوات مصنفة بلا ترتيب'+s2lOfK1TeCx,'LIVE_GROUPED',713,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,PPz1VyOXFYhk2IT35c)
		x3WSXnKyPhjqfHG2UrtQs('folder',KKxc2jv9sQZOpV+'قنوات بلا ترتيب'+s2lOfK1TeCx,'LIVE_ORIGINAL_GROUPED',713,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,PPz1VyOXFYhk2IT35c)
		x3WSXnKyPhjqfHG2UrtQs('folder',KKxc2jv9sQZOpV+'قنوات مجهولة مرتبة'+s2lOfK1TeCx,'LIVE_UNKNOWN_GROUPED_SORTED',713,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,PPz1VyOXFYhk2IT35c)
		x3WSXnKyPhjqfHG2UrtQs('folder',KKxc2jv9sQZOpV+'قنوات مجهولة بلا ترتيب'+s2lOfK1TeCx,'LIVE_UNKNOWN_GROUPED',713,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,PPz1VyOXFYhk2IT35c)
		x3WSXnKyPhjqfHG2UrtQs('link',xupTj02bvy3O8R+' ===== ===== ===== '+fF4lt9zWYxXLKZVyAco82PgMj,qpFY4hAwolV3,9999)
		x3WSXnKyPhjqfHG2UrtQs('folder',KKxc2jv9sQZOpV+'فيديوهات بلا ترتيب'+s2lOfK1TeCx,'VOD_ORIGINAL_GROUPED',713,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,PPz1VyOXFYhk2IT35c)
		x3WSXnKyPhjqfHG2UrtQs('folder',KKxc2jv9sQZOpV+'فيديوهات مصنفة القسم'+s2lOfK1TeCx,'VOD_FROM_GROUP_SORTED',713,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,PPz1VyOXFYhk2IT35c)
		x3WSXnKyPhjqfHG2UrtQs('folder',KKxc2jv9sQZOpV+'فيديوهات مصنفة من الاسم'+s2lOfK1TeCx,'VOD_FROM_NAME_SORTED',713,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,PPz1VyOXFYhk2IT35c)
		x3WSXnKyPhjqfHG2UrtQs('folder',KKxc2jv9sQZOpV+'فيديوهات مجهولة بلا ترتيب'+s2lOfK1TeCx,'VOD_UNKNOWN_GROUPED',713,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,PPz1VyOXFYhk2IT35c)
		x3WSXnKyPhjqfHG2UrtQs('folder',KKxc2jv9sQZOpV+'فيديوهات مجهولة مرتبة'+s2lOfK1TeCx,'VOD_UNKNOWN_GROUPED_SORTED',713,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,PPz1VyOXFYhk2IT35c)
		x3WSXnKyPhjqfHG2UrtQs('link',xupTj02bvy3O8R+' ===== ===== ===== '+fF4lt9zWYxXLKZVyAco82PgMj,qpFY4hAwolV3,9999)
	for PC1WedfcN6i0sD in range(1,cqSFolBs7A1G0X9u4a6K+1):
		x3WSXnKyPhjqfHG2UrtQs('link',KKxc2jv9sQZOpV+'إضافة وتغيير رابط'+s2lOfK1TeCx+mIsDke0oK5x1zSiOWbF9thGcA+ppn5vq8QdBsEhckl[PC1WedfcN6i0sD],qpFY4hAwolV3,711,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,{'folder':m4W3gU71on2PF,'sequence':PC1WedfcN6i0sD})
	x3WSXnKyPhjqfHG2UrtQs('link',KKxc2jv9sQZOpV+'جلب ملفات'+s2lOfK1TeCx,qpFY4hAwolV3,712,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,PPz1VyOXFYhk2IT35c)
	x3WSXnKyPhjqfHG2UrtQs('link',KKxc2jv9sQZOpV+'مسح ملفات'+s2lOfK1TeCx,qpFY4hAwolV3,717,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,PPz1VyOXFYhk2IT35c)
	x3WSXnKyPhjqfHG2UrtQs('link',KKxc2jv9sQZOpV+'عدد فيديوهات'+s2lOfK1TeCx,qpFY4hAwolV3,721,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,PPz1VyOXFYhk2IT35c)
	x3WSXnKyPhjqfHG2UrtQs('link',KKxc2jv9sQZOpV+'Referer تغيير'+s2lOfK1TeCx,qpFY4hAwolV3,726,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,PPz1VyOXFYhk2IT35c)
	x3WSXnKyPhjqfHG2UrtQs('link',KKxc2jv9sQZOpV+'User-Agent تغيير'+s2lOfK1TeCx,qpFY4hAwolV3,723,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,PPz1VyOXFYhk2IT35c)
	return
def KIRfl5Tr3Vs(m4W3gU71on2PF,kcmbnMYF2WpDg0ti4UyCf3AV=True):
	C4j6M0yOYpx2Kg,AqT9RQuKBx = False,qpFY4hAwolV3
	ww0xnaWtDVSJjOFzqCB1IXldL,lS9vTBxMWYGDw62hjtQ1 = qpFY4hAwolV3,qpFY4hAwolV3
	KDMqU0V7YydkBHSbmrNwpXCIncA,GC6JEjSfpxU5OmTaFBrbL,zzW8eQFgtur1U,liSOfMZdp6qxC9a,ge6LsiVYWbxy5ovGIwrlPkOznd = ggPLfiFuwAYdDG(m4W3gU71on2PF)
	if liSOfMZdp6qxC9a==qpFY4hAwolV3: return False,qpFY4hAwolV3,qpFY4hAwolV3
	EBOwuZ71x92omaIKbGFU3A54pqkc = O1O0wLKjB2yV5kg9AhbC(m4W3gU71on2PF)
	if KDMqU0V7YydkBHSbmrNwpXCIncA:
		UEey2i9D3MTfhd7okHj6QSqJp0VBYA = WWrExJZS3Bj4anOAkpv7(dzcNuIbsgK3yZ6SXGaEHPfOj5vk,'GET',KDMqU0V7YydkBHSbmrNwpXCIncA,qpFY4hAwolV3,EBOwuZ71x92omaIKbGFU3A54pqkc,False,qpFY4hAwolV3,'M3U-CHECK_ACCOUNT-1st')
		xBGN0iopjaHKy = UEey2i9D3MTfhd7okHj6QSqJp0VBYA.content
		if UEey2i9D3MTfhd7okHj6QSqJp0VBYA.succeeded:
			MGyFhcTzRkaOtVfCs,t1KZUnOuC20yJGNHmgwrL,iZu3r5jVHB2O6Uh1SnJgXl,PHk7634LAdRBfe1Ojc,Z9fMAPHN2SEqjWwGbQUX = 0,0,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3
			try:
				fwvqtnE3zal5g = wB8NUAidPbqjIr9CFasXvYnxOQpL0g('dict',xBGN0iopjaHKy)
				AqT9RQuKBx = fwvqtnE3zal5g['user_info']['status']
				C4j6M0yOYpx2Kg = True
				iZu3r5jVHB2O6Uh1SnJgXl = fwvqtnE3zal5g['server_info']['time_now']
			except: pass
			if iZu3r5jVHB2O6Uh1SnJgXl:
				try:
					o5rIjCqaMFknR90YG3 = s7FnXZYOgexlH2MPb8BJck1AKv9.strptime(iZu3r5jVHB2O6Uh1SnJgXl,'%Y.%m.%d %H:%M:%S')
					MGyFhcTzRkaOtVfCs = int(s7FnXZYOgexlH2MPb8BJck1AKv9.mktime(o5rIjCqaMFknR90YG3))
					t1KZUnOuC20yJGNHmgwrL = int(dAeP20gNJ6ltq-MGyFhcTzRkaOtVfCs)
					t1KZUnOuC20yJGNHmgwrL = int((t1KZUnOuC20yJGNHmgwrL+900)/1800)*1800
				except: pass
				try:
					o5rIjCqaMFknR90YG3 = s7FnXZYOgexlH2MPb8BJck1AKv9.localtime(int(fwvqtnE3zal5g['user_info']['created_at']))
					PHk7634LAdRBfe1Ojc = s7FnXZYOgexlH2MPb8BJck1AKv9.strftime('%Y.%m.%d %H:%M:%S',o5rIjCqaMFknR90YG3)
				except: pass
				try:
					o5rIjCqaMFknR90YG3 = s7FnXZYOgexlH2MPb8BJck1AKv9.localtime(int(fwvqtnE3zal5g['user_info']['exp_date']))
					Z9fMAPHN2SEqjWwGbQUX = s7FnXZYOgexlH2MPb8BJck1AKv9.strftime('%Y.%m.%d %H:%M:%S',o5rIjCqaMFknR90YG3)
				except: pass
			gdPslyFW8ITBcpA302.setSetting('av.m3u.timestamp_'+m4W3gU71on2PF,str(dAeP20gNJ6ltq))
			gdPslyFW8ITBcpA302.setSetting('av.m3u.timediff_'+m4W3gU71on2PF,str(t1KZUnOuC20yJGNHmgwrL))
			try:
				hIYd4TUF9w7b = '"server_info":'+xBGN0iopjaHKy.split('"server_info":')[1]
				hIYd4TUF9w7b = hIYd4TUF9w7b.replace(':',': ').replace(',',', ').replace('}}','}')
				YYeV7Ro5sPhqX8JpKz = ePhmG1jLD6.findall('"url": "(.*?)", "port": "(.*?)"',hIYd4TUF9w7b,ePhmG1jLD6.DOTALL)
				ww0xnaWtDVSJjOFzqCB1IXldL,lS9vTBxMWYGDw62hjtQ1 = YYeV7Ro5sPhqX8JpKz[0]
			except: C4j6M0yOYpx2Kg = False
			if C4j6M0yOYpx2Kg and kcmbnMYF2WpDg0ti4UyCf3AV:
				max = fwvqtnE3zal5g['user_info']['max_connections']
				SmgrulxN82 = fwvqtnE3zal5g['user_info']['active_cons']
				S4onDvUfHB3dEPr = fwvqtnE3zal5g['user_info']['is_trial']
				dq6vJoPcV0NgFBQG = KDMqU0V7YydkBHSbmrNwpXCIncA.split('?',1)
				w0CZ6B3WDJknhEsdRYyH1XAM = 'URL:  '+xupTj02bvy3O8R+KDMqU0V7YydkBHSbmrNwpXCIncA+fF4lt9zWYxXLKZVyAco82PgMj
				w0CZ6B3WDJknhEsdRYyH1XAM += '\n\nStatus:  '+xupTj02bvy3O8R+AqT9RQuKBx+fF4lt9zWYxXLKZVyAco82PgMj
				w0CZ6B3WDJknhEsdRYyH1XAM += '\nTrial:    '+xupTj02bvy3O8R+str(S4onDvUfHB3dEPr=='1')+fF4lt9zWYxXLKZVyAco82PgMj
				w0CZ6B3WDJknhEsdRYyH1XAM += '\nCreated  At:  '+xupTj02bvy3O8R+PHk7634LAdRBfe1Ojc+fF4lt9zWYxXLKZVyAco82PgMj
				w0CZ6B3WDJknhEsdRYyH1XAM += '\nExpiry Date:  '+xupTj02bvy3O8R+Z9fMAPHN2SEqjWwGbQUX+fF4lt9zWYxXLKZVyAco82PgMj
				w0CZ6B3WDJknhEsdRYyH1XAM += '\nConnections   ( Active / Maximum ) :  '+xupTj02bvy3O8R+SmgrulxN82+' / '+max+fF4lt9zWYxXLKZVyAco82PgMj
				w0CZ6B3WDJknhEsdRYyH1XAM += '\nAllowed Outputs:   '+xupTj02bvy3O8R+" , ".join(fwvqtnE3zal5g['user_info']['allowed_output_formats'])+fF4lt9zWYxXLKZVyAco82PgMj
				w0CZ6B3WDJknhEsdRYyH1XAM += '\n\n'+hIYd4TUF9w7b
				if AqT9RQuKBx=='Active': fGChDJbmZANnS('الاشتراك يعمل بدون مشاكل',w0CZ6B3WDJknhEsdRYyH1XAM)
				else: fGChDJbmZANnS('يبدو أن هناك مشكلة في الاشتراك',w0CZ6B3WDJknhEsdRYyH1XAM)
	if KDMqU0V7YydkBHSbmrNwpXCIncA and C4j6M0yOYpx2Kg and AqT9RQuKBx=='Active':
		LLvyStW429DEZKlA(k8kdUSxohLVljnrY,'.\tChecking M3U URL   [ M3U account is OK ]   [ '+KDMqU0V7YydkBHSbmrNwpXCIncA+' ]')
		M3tdPukY1NHD = True
	else:
		LLvyStW429DEZKlA(j8gFJIMYPoBzcCvG9T,'Checking M3U URL   [ Does not work ]   [ '+KDMqU0V7YydkBHSbmrNwpXCIncA+' ]')
		if kcmbnMYF2WpDg0ti4UyCf3AV: iG7Rz2kmn0x1yLNMV3u8O(qpFY4hAwolV3,qpFY4hAwolV3,'فحص اشتراك ـM3U','رابط اشتراك ـM3U الذي قمت انت بإضافته إلى البرنامج لا يعمل أو الرابط غير موجود في البرنامج . أذهب إلى قائمة اشتراك ـM3U وقم بإضافة رابط ـM3U جديد أو قم بإصلاح الرابط القديم')
		M3tdPukY1NHD = False
	return M3tdPukY1NHD,ww0xnaWtDVSJjOFzqCB1IXldL,lS9vTBxMWYGDw62hjtQ1
def I19sHuzZ8RryYXSwgV7mQ3Dh(m4W3gU71on2PF,muKG29tPNiTYQJMxkpl87CbLwXSV0,OhwCpWyUzYsKA35fa7Hg6Mi,tPH05EC8L6cYqTX4xIUurnjk1MOG,kcmbnMYF2WpDg0ti4UyCf3AV=True):
	if not tPH05EC8L6cYqTX4xIUurnjk1MOG: tPH05EC8L6cYqTX4xIUurnjk1MOG = '1'
	if not N4mtgDP83waX9(m4W3gU71on2PF,kcmbnMYF2WpDg0ti4UyCf3AV): return
	LeuKy7JsdxW = PPlUAWKhqTdmnfwLrcYxDS8(m4W3gU71on2PF,muKG29tPNiTYQJMxkpl87CbLwXSV0)
	LUejlIa7XQWtrik21xfFMAGYwEp4y = XXyMBNAVJvKiq7jc20bEw6(LeuKy7JsdxW,'list',muKG29tPNiTYQJMxkpl87CbLwXSV0,OhwCpWyUzYsKA35fa7Hg6Mi)
	U2HhzcVNKdLmCGvDw3Mpy0aEQtqu = int(tPH05EC8L6cYqTX4xIUurnjk1MOG)*100
	UlCROBLmVEJhPosDQSietN76gw = U2HhzcVNKdLmCGvDw3Mpy0aEQtqu-100
	for fdD0wQgTuni,zaDq3igbdyhsSnRcxoQ7uYPkl,WWowRmHkj1ZAO2SUhtNvdrcKa9E6C,xNF9bfr3tm in LUejlIa7XQWtrik21xfFMAGYwEp4y[UlCROBLmVEJhPosDQSietN76gw:U2HhzcVNKdLmCGvDw3Mpy0aEQtqu]:
		XiCad4FNLAxT1znHkf = ('GROUPED' in muKG29tPNiTYQJMxkpl87CbLwXSV0 or muKG29tPNiTYQJMxkpl87CbLwXSV0=='ALL')
		fAlVmB6SnOWb5xNFIvuwjRaYk7 = ('GROUPED' not in muKG29tPNiTYQJMxkpl87CbLwXSV0 and muKG29tPNiTYQJMxkpl87CbLwXSV0!='ALL')
		if XiCad4FNLAxT1znHkf or fAlVmB6SnOWb5xNFIvuwjRaYk7:
			if   'ARCHIVED'  in muKG29tPNiTYQJMxkpl87CbLwXSV0: i4bFG3rKE6.menuItemsLIST.append(['folder',KKxc2jv9sQZOpV+zaDq3igbdyhsSnRcxoQ7uYPkl,WWowRmHkj1ZAO2SUhtNvdrcKa9E6C,718,xNF9bfr3tm,qpFY4hAwolV3,'ARCHIVED',qpFY4hAwolV3,{'folder':m4W3gU71on2PF}])
			elif 'EPG' 		 in muKG29tPNiTYQJMxkpl87CbLwXSV0: i4bFG3rKE6.menuItemsLIST.append(['folder',KKxc2jv9sQZOpV+zaDq3igbdyhsSnRcxoQ7uYPkl,WWowRmHkj1ZAO2SUhtNvdrcKa9E6C,718,xNF9bfr3tm,qpFY4hAwolV3,'FULL_EPG',qpFY4hAwolV3,{'folder':m4W3gU71on2PF}])
			elif 'TIMESHIFT' in muKG29tPNiTYQJMxkpl87CbLwXSV0: i4bFG3rKE6.menuItemsLIST.append(['folder',KKxc2jv9sQZOpV+zaDq3igbdyhsSnRcxoQ7uYPkl,WWowRmHkj1ZAO2SUhtNvdrcKa9E6C,718,xNF9bfr3tm,qpFY4hAwolV3,'TIMESHIFT',qpFY4hAwolV3,{'folder':m4W3gU71on2PF}])
			elif 'LIVE' 	 in muKG29tPNiTYQJMxkpl87CbLwXSV0: i4bFG3rKE6.menuItemsLIST.append(['live',KKxc2jv9sQZOpV+zaDq3igbdyhsSnRcxoQ7uYPkl,WWowRmHkj1ZAO2SUhtNvdrcKa9E6C,715,xNF9bfr3tm,qpFY4hAwolV3,qpFY4hAwolV3,fdD0wQgTuni,{'folder':m4W3gU71on2PF}])
			else: i4bFG3rKE6.menuItemsLIST.append(['video',KKxc2jv9sQZOpV+zaDq3igbdyhsSnRcxoQ7uYPkl,WWowRmHkj1ZAO2SUhtNvdrcKa9E6C,715,xNF9bfr3tm,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,{'folder':m4W3gU71on2PF}])
	PT7f3Zk6WgXY = len(LUejlIa7XQWtrik21xfFMAGYwEp4y)
	RPaQ1dgMHVXltF2(m4W3gU71on2PF,tPH05EC8L6cYqTX4xIUurnjk1MOG,muKG29tPNiTYQJMxkpl87CbLwXSV0,714,PT7f3Zk6WgXY,OhwCpWyUzYsKA35fa7Hg6Mi)
	return
def eP73Tl6y8b(Jz3O1RuKrsovc5ZtLAkXHefl):
	x3WSXnKyPhjqfHG2UrtQs('link',Jz3O1RuKrsovc5ZtLAkXHefl+'هذه القائمة إما فارغة أو غير موجودة',qpFY4hAwolV3,9999)
	x3WSXnKyPhjqfHG2UrtQs('link',Jz3O1RuKrsovc5ZtLAkXHefl+'أو الخدمة غير موجودة في اشتراكك',qpFY4hAwolV3,9999)
	x3WSXnKyPhjqfHG2UrtQs('link',Jz3O1RuKrsovc5ZtLAkXHefl+'أو رابط M3U الذي أنت أضفته غير صحيح',qpFY4hAwolV3,9999)
	return
def xxHg8EI03NwfKGpYtjrs7WDinR(m4W3gU71on2PF,muKG29tPNiTYQJMxkpl87CbLwXSV0,OhwCpWyUzYsKA35fa7Hg6Mi,tPH05EC8L6cYqTX4xIUurnjk1MOG,QfD1mGzEaiS98vwrkVbRn3=qpFY4hAwolV3,kcmbnMYF2WpDg0ti4UyCf3AV=True):
	if not tPH05EC8L6cYqTX4xIUurnjk1MOG: tPH05EC8L6cYqTX4xIUurnjk1MOG = '1'
	Jz3O1RuKrsovc5ZtLAkXHefl = KKxc2jv9sQZOpV
	if not N4mtgDP83waX9(m4W3gU71on2PF,kcmbnMYF2WpDg0ti4UyCf3AV): return False
	if '__SERIES__' in OhwCpWyUzYsKA35fa7Hg6Mi: oMdVUvCTtr9ZlP7njDaec4hsBNF52Q,aatNmYeZ175ihDv3uUBL = OhwCpWyUzYsKA35fa7Hg6Mi.split('__SERIES__')
	else: oMdVUvCTtr9ZlP7njDaec4hsBNF52Q,aatNmYeZ175ihDv3uUBL = OhwCpWyUzYsKA35fa7Hg6Mi,qpFY4hAwolV3
	LeuKy7JsdxW = PPlUAWKhqTdmnfwLrcYxDS8(m4W3gU71on2PF,muKG29tPNiTYQJMxkpl87CbLwXSV0)
	V2cBf3oYFG = XXyMBNAVJvKiq7jc20bEw6(LeuKy7JsdxW,'list',muKG29tPNiTYQJMxkpl87CbLwXSV0,'__GROUPS__')
	if not V2cBf3oYFG: return False
	Gw3lVypcOL8aitR = []
	for dW4u3hS9wKCqD6xvIbylR,xNF9bfr3tm in V2cBf3oYFG:
		if '===== ===== =====' in dW4u3hS9wKCqD6xvIbylR:
			x3WSXnKyPhjqfHG2UrtQs('link',Jz3O1RuKrsovc5ZtLAkXHefl+dW4u3hS9wKCqD6xvIbylR,qpFY4hAwolV3,9999)
			x3WSXnKyPhjqfHG2UrtQs('link',Jz3O1RuKrsovc5ZtLAkXHefl+dW4u3hS9wKCqD6xvIbylR,qpFY4hAwolV3,9999)
			continue
		if QfD1mGzEaiS98vwrkVbRn3:
			if '__SERIES__' in dW4u3hS9wKCqD6xvIbylR: Jz3O1RuKrsovc5ZtLAkXHefl = 'SERIES'
			elif '!!__UNKNOWN__!!' in dW4u3hS9wKCqD6xvIbylR: Jz3O1RuKrsovc5ZtLAkXHefl = 'UNKNOWN'
			elif 'LIVE' in muKG29tPNiTYQJMxkpl87CbLwXSV0: Jz3O1RuKrsovc5ZtLAkXHefl = 'LIVE'
			else: Jz3O1RuKrsovc5ZtLAkXHefl = 'VIDEOS'
			Jz3O1RuKrsovc5ZtLAkXHefl = ','+xupTj02bvy3O8R+Jz3O1RuKrsovc5ZtLAkXHefl+': '+fF4lt9zWYxXLKZVyAco82PgMj
		if '__SERIES__' in dW4u3hS9wKCqD6xvIbylR: gMkqSFHydAuTf1,kZjnrmf4q63Y = dW4u3hS9wKCqD6xvIbylR.split('__SERIES__')
		else: gMkqSFHydAuTf1,kZjnrmf4q63Y = dW4u3hS9wKCqD6xvIbylR,qpFY4hAwolV3
		if not OhwCpWyUzYsKA35fa7Hg6Mi:
			if gMkqSFHydAuTf1 in Gw3lVypcOL8aitR: continue
			Gw3lVypcOL8aitR.append(gMkqSFHydAuTf1)
			if 'RANDOM' in QfD1mGzEaiS98vwrkVbRn3: x3WSXnKyPhjqfHG2UrtQs('folder',Jz3O1RuKrsovc5ZtLAkXHefl+gMkqSFHydAuTf1,muKG29tPNiTYQJMxkpl87CbLwXSV0,168,qpFY4hAwolV3,'1',dW4u3hS9wKCqD6xvIbylR,qpFY4hAwolV3,{'folder':m4W3gU71on2PF})
			elif '__SERIES__' in dW4u3hS9wKCqD6xvIbylR: x3WSXnKyPhjqfHG2UrtQs('folder',Jz3O1RuKrsovc5ZtLAkXHefl+gMkqSFHydAuTf1,muKG29tPNiTYQJMxkpl87CbLwXSV0,713,qpFY4hAwolV3,'1',dW4u3hS9wKCqD6xvIbylR,qpFY4hAwolV3,{'folder':m4W3gU71on2PF})
			else: x3WSXnKyPhjqfHG2UrtQs('folder',Jz3O1RuKrsovc5ZtLAkXHefl+gMkqSFHydAuTf1,muKG29tPNiTYQJMxkpl87CbLwXSV0,714,qpFY4hAwolV3,'1',dW4u3hS9wKCqD6xvIbylR,qpFY4hAwolV3,{'folder':m4W3gU71on2PF})
		elif '__SERIES__' in dW4u3hS9wKCqD6xvIbylR and gMkqSFHydAuTf1==oMdVUvCTtr9ZlP7njDaec4hsBNF52Q:
			if kZjnrmf4q63Y in Gw3lVypcOL8aitR: continue
			Gw3lVypcOL8aitR.append(kZjnrmf4q63Y)
			if 'RANDOM' in QfD1mGzEaiS98vwrkVbRn3: x3WSXnKyPhjqfHG2UrtQs('folder',Jz3O1RuKrsovc5ZtLAkXHefl+kZjnrmf4q63Y,muKG29tPNiTYQJMxkpl87CbLwXSV0,168,qpFY4hAwolV3,'1',dW4u3hS9wKCqD6xvIbylR,qpFY4hAwolV3,{'folder':m4W3gU71on2PF})
			else: x3WSXnKyPhjqfHG2UrtQs('folder',Jz3O1RuKrsovc5ZtLAkXHefl+kZjnrmf4q63Y,muKG29tPNiTYQJMxkpl87CbLwXSV0,714,xNF9bfr3tm,'1',dW4u3hS9wKCqD6xvIbylR,qpFY4hAwolV3,{'folder':m4W3gU71on2PF})
	i4bFG3rKE6.menuItemsLIST[:] = sorted(i4bFG3rKE6.menuItemsLIST,reverse=False,key=lambda f79ZnTkH0m45a1vj63xuQSd: f79ZnTkH0m45a1vj63xuQSd[1].lower())
	if not QfD1mGzEaiS98vwrkVbRn3:
		U2HhzcVNKdLmCGvDw3Mpy0aEQtqu = int(tPH05EC8L6cYqTX4xIUurnjk1MOG)*100
		UlCROBLmVEJhPosDQSietN76gw = U2HhzcVNKdLmCGvDw3Mpy0aEQtqu-100
		PT7f3Zk6WgXY = len(i4bFG3rKE6.menuItemsLIST)
		i4bFG3rKE6.menuItemsLIST[:] = i4bFG3rKE6.menuItemsLIST[UlCROBLmVEJhPosDQSietN76gw:U2HhzcVNKdLmCGvDw3Mpy0aEQtqu]
		RPaQ1dgMHVXltF2(m4W3gU71on2PF,tPH05EC8L6cYqTX4xIUurnjk1MOG,muKG29tPNiTYQJMxkpl87CbLwXSV0,713,PT7f3Zk6WgXY,OhwCpWyUzYsKA35fa7Hg6Mi)
	return True
def x9KgQBLDPCRF0yhnmt4Jj2XHEIvza(m4W3gU71on2PF,WWowRmHkj1ZAO2SUhtNvdrcKa9E6C,R4prTUoZPaM6HDl5JVntwbdKi):
	if not N4mtgDP83waX9(m4W3gU71on2PF,True): return
	EBOwuZ71x92omaIKbGFU3A54pqkc = O1O0wLKjB2yV5kg9AhbC(m4W3gU71on2PF)
	MGyFhcTzRkaOtVfCs = gdPslyFW8ITBcpA302.getSetting('av.m3u.timestamp_'+m4W3gU71on2PF)
	if not MGyFhcTzRkaOtVfCs or dAeP20gNJ6ltq-int(MGyFhcTzRkaOtVfCs)>24*Yz7BvqTS1wVGPey0XlojpUh5:
		M3tdPukY1NHD,ww0xnaWtDVSJjOFzqCB1IXldL,lS9vTBxMWYGDw62hjtQ1 = KIRfl5Tr3Vs(m4W3gU71on2PF,False)
		if not M3tdPukY1NHD: return
	t1KZUnOuC20yJGNHmgwrL = int(gdPslyFW8ITBcpA302.getSetting('av.m3u.timediff_'+m4W3gU71on2PF))
	zzW8eQFgtur1U = gdPslyFW8ITBcpA302.getSetting('av.m3u.server_'+m4W3gU71on2PF)
	liSOfMZdp6qxC9a = gdPslyFW8ITBcpA302.getSetting('av.m3u.username_'+m4W3gU71on2PF)
	ge6LsiVYWbxy5ovGIwrlPkOznd = gdPslyFW8ITBcpA302.getSetting('av.m3u.password_'+m4W3gU71on2PF)
	xsDmiNVQeBtR2MW = WWowRmHkj1ZAO2SUhtNvdrcKa9E6C.split(ShynO8pN9idCE3)
	eER8IuqPTAJDLa1Szndb9 = xsDmiNVQeBtR2MW[-1].replace('.ts',qpFY4hAwolV3).replace('.m3u8',qpFY4hAwolV3)
	if R4prTUoZPaM6HDl5JVntwbdKi=='SHORT_EPG': aQT5izKD13BIyN76ewdmj8fog0Pt = 'get_short_epg'
	else: aQT5izKD13BIyN76ewdmj8fog0Pt = 'get_simple_data_table'
	KDMqU0V7YydkBHSbmrNwpXCIncA,GC6JEjSfpxU5OmTaFBrbL,zzW8eQFgtur1U,liSOfMZdp6qxC9a,ge6LsiVYWbxy5ovGIwrlPkOznd = ggPLfiFuwAYdDG(m4W3gU71on2PF)
	if not liSOfMZdp6qxC9a: return
	bchMNGJlFoZiYAOqU = KDMqU0V7YydkBHSbmrNwpXCIncA+'&action='+aQT5izKD13BIyN76ewdmj8fog0Pt+'&stream_id='+eER8IuqPTAJDLa1Szndb9
	xBGN0iopjaHKy = DjwTKbltWkf7RyJ(dzcNuIbsgK3yZ6SXGaEHPfOj5vk,bchMNGJlFoZiYAOqU,qpFY4hAwolV3,EBOwuZ71x92omaIKbGFU3A54pqkc,qpFY4hAwolV3,'M3U-EPG_ITEMS-2nd')
	GGKQkRvHzeqT0b94DN5SErx = wB8NUAidPbqjIr9CFasXvYnxOQpL0g('dict',xBGN0iopjaHKy)
	Luvi0V38T24KepSZ6EImJdsloWBFH = GGKQkRvHzeqT0b94DN5SErx['epg_listings']
	XzUrwVA8pS6BvgyIlL4 = []
	if R4prTUoZPaM6HDl5JVntwbdKi in ['ARCHIVED','TIMESHIFT']:
		for fwvqtnE3zal5g in Luvi0V38T24KepSZ6EImJdsloWBFH:
			if fwvqtnE3zal5g['has_archive']==1:
				XzUrwVA8pS6BvgyIlL4.append(fwvqtnE3zal5g)
				if R4prTUoZPaM6HDl5JVntwbdKi in ['TIMESHIFT']: break
		if not XzUrwVA8pS6BvgyIlL4: return
		x3WSXnKyPhjqfHG2UrtQs('link',KKxc2jv9sQZOpV+xupTj02bvy3O8R+'الملفات الأولي بهذه القائمة قد لا تعمل'+fF4lt9zWYxXLKZVyAco82PgMj,qpFY4hAwolV3,9999)
		if R4prTUoZPaM6HDl5JVntwbdKi in ['TIMESHIFT']:
			zOJvVejUZIhoCy8q94SNfYpdk = 2
			kDAFHq5rP10nGz4spxUfecR6STj = zOJvVejUZIhoCy8q94SNfYpdk*Yz7BvqTS1wVGPey0XlojpUh5
			XzUrwVA8pS6BvgyIlL4 = []
			Tb9V6L4JweXBs0nZWmNPlt8 = int(int(fwvqtnE3zal5g['start_timestamp'])/kDAFHq5rP10nGz4spxUfecR6STj)*kDAFHq5rP10nGz4spxUfecR6STj
			NTQRHYsVuv2Di5A3ymeO = dAeP20gNJ6ltq+kDAFHq5rP10nGz4spxUfecR6STj
			md3tlr2gxz4iZMyA0 = int((NTQRHYsVuv2Di5A3ymeO-Tb9V6L4JweXBs0nZWmNPlt8)/Yz7BvqTS1wVGPey0XlojpUh5)
			for y1FEOnmUq6eaTbVRCL9j in range(md3tlr2gxz4iZMyA0):
				if y1FEOnmUq6eaTbVRCL9j>=6:
					if y1FEOnmUq6eaTbVRCL9j%zOJvVejUZIhoCy8q94SNfYpdk!=0: continue
					ru1kcNbmp6GLJTSgMDP5CKAIZhQify = kDAFHq5rP10nGz4spxUfecR6STj
				else: ru1kcNbmp6GLJTSgMDP5CKAIZhQify = kDAFHq5rP10nGz4spxUfecR6STj//2
				hH5EVLb3CrMn7uz9N1Jkc = Tb9V6L4JweXBs0nZWmNPlt8+y1FEOnmUq6eaTbVRCL9j*Yz7BvqTS1wVGPey0XlojpUh5
				fwvqtnE3zal5g = {}
				fwvqtnE3zal5g['title'] = qpFY4hAwolV3
				o5rIjCqaMFknR90YG3 = s7FnXZYOgexlH2MPb8BJck1AKv9.localtime(hH5EVLb3CrMn7uz9N1Jkc-t1KZUnOuC20yJGNHmgwrL-Yz7BvqTS1wVGPey0XlojpUh5)
				fwvqtnE3zal5g['start'] = s7FnXZYOgexlH2MPb8BJck1AKv9.strftime('%Y.%m.%d %H:%M:%S',o5rIjCqaMFknR90YG3)
				fwvqtnE3zal5g['start_timestamp'] = str(hH5EVLb3CrMn7uz9N1Jkc)
				fwvqtnE3zal5g['stop_timestamp'] = str(hH5EVLb3CrMn7uz9N1Jkc+ru1kcNbmp6GLJTSgMDP5CKAIZhQify)
				XzUrwVA8pS6BvgyIlL4.append(fwvqtnE3zal5g)
	elif R4prTUoZPaM6HDl5JVntwbdKi in ['SHORT_EPG','FULL_EPG']: XzUrwVA8pS6BvgyIlL4 = Luvi0V38T24KepSZ6EImJdsloWBFH
	if R4prTUoZPaM6HDl5JVntwbdKi=='FULL_EPG' and len(XzUrwVA8pS6BvgyIlL4)>0:
		x3WSXnKyPhjqfHG2UrtQs('link',KKxc2jv9sQZOpV+xupTj02bvy3O8R+'هذه قائمة برامج القنوات (جدول فقط)ـ'+fF4lt9zWYxXLKZVyAco82PgMj,qpFY4hAwolV3,9999)
	mm0yHJgTGhOL3fQDajciPAEv = []
	xNF9bfr3tm = Rqvw05BorCgcye7VE32Sf.getInfoLabel('ListItem.Icon')
	for fwvqtnE3zal5g in XzUrwVA8pS6BvgyIlL4:
		zaDq3igbdyhsSnRcxoQ7uYPkl = PP0Gxazjw86.b64decode(fwvqtnE3zal5g['title'])
		if DLod2Of8CkRrtzJynev: zaDq3igbdyhsSnRcxoQ7uYPkl = zaDq3igbdyhsSnRcxoQ7uYPkl.decode(nV3Tip6XsH1rJw79DPOU)
		hH5EVLb3CrMn7uz9N1Jkc = int(fwvqtnE3zal5g['start_timestamp'])
		ovMOu09SiHNyblCA2agLdrqcE7hsRf = int(fwvqtnE3zal5g['stop_timestamp'])
		Dm0ENGqXjTigzSnBtJuHf35V = str(int((ovMOu09SiHNyblCA2agLdrqcE7hsRf-hH5EVLb3CrMn7uz9N1Jkc+59)/60))
		a5UHLvJnZRo = fwvqtnE3zal5g['start'].replace(mIsDke0oK5x1zSiOWbF9thGcA,':')
		o5rIjCqaMFknR90YG3 = s7FnXZYOgexlH2MPb8BJck1AKv9.localtime(hH5EVLb3CrMn7uz9N1Jkc-Yz7BvqTS1wVGPey0XlojpUh5)
		BRa9NpsYJQqHjbyfzr1Du = s7FnXZYOgexlH2MPb8BJck1AKv9.strftime('%H:%M',o5rIjCqaMFknR90YG3)
		AKVDvue1kGXzOyBJlZ5 = s7FnXZYOgexlH2MPb8BJck1AKv9.strftime('%a',o5rIjCqaMFknR90YG3)
		if R4prTUoZPaM6HDl5JVntwbdKi=='SHORT_EPG': zaDq3igbdyhsSnRcxoQ7uYPkl = IQ2KCmObsTGuiRdEzt931a40jLg+BRa9NpsYJQqHjbyfzr1Du+' ـ '+zaDq3igbdyhsSnRcxoQ7uYPkl+fF4lt9zWYxXLKZVyAco82PgMj
		elif R4prTUoZPaM6HDl5JVntwbdKi=='TIMESHIFT': zaDq3igbdyhsSnRcxoQ7uYPkl = AKVDvue1kGXzOyBJlZ5+mIsDke0oK5x1zSiOWbF9thGcA+BRa9NpsYJQqHjbyfzr1Du+' ('+Dm0ENGqXjTigzSnBtJuHf35V+'min)'
		else: zaDq3igbdyhsSnRcxoQ7uYPkl = AKVDvue1kGXzOyBJlZ5+mIsDke0oK5x1zSiOWbF9thGcA+BRa9NpsYJQqHjbyfzr1Du+' ('+Dm0ENGqXjTigzSnBtJuHf35V+'min)   '+zaDq3igbdyhsSnRcxoQ7uYPkl+' ـ'
		if R4prTUoZPaM6HDl5JVntwbdKi in ['ARCHIVED','FULL_EPG','TIMESHIFT']:
			ALQHbkGn9od25pPV = zzW8eQFgtur1U+'/timeshift/'+liSOfMZdp6qxC9a+ShynO8pN9idCE3+ge6LsiVYWbxy5ovGIwrlPkOznd+ShynO8pN9idCE3+Dm0ENGqXjTigzSnBtJuHf35V+ShynO8pN9idCE3+a5UHLvJnZRo+ShynO8pN9idCE3+eER8IuqPTAJDLa1Szndb9+'.m3u8'
			if R4prTUoZPaM6HDl5JVntwbdKi=='FULL_EPG': x3WSXnKyPhjqfHG2UrtQs('link',KKxc2jv9sQZOpV+zaDq3igbdyhsSnRcxoQ7uYPkl,ALQHbkGn9od25pPV,9999,xNF9bfr3tm,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,{'folder':m4W3gU71on2PF})
			else: x3WSXnKyPhjqfHG2UrtQs('video',KKxc2jv9sQZOpV+zaDq3igbdyhsSnRcxoQ7uYPkl,ALQHbkGn9od25pPV,715,xNF9bfr3tm,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,{'folder':m4W3gU71on2PF})
		mm0yHJgTGhOL3fQDajciPAEv.append(zaDq3igbdyhsSnRcxoQ7uYPkl)
	if R4prTUoZPaM6HDl5JVntwbdKi=='SHORT_EPG' and mm0yHJgTGhOL3fQDajciPAEv: ZKqQMpYH5yCkXLbrD = UpqiBMsKgPF9wZQGv3zEx7Nf(mm0yHJgTGhOL3fQDajciPAEv)
	return mm0yHJgTGhOL3fQDajciPAEv
def SwbDsXYkc4g7AyQoINO6(m4W3gU71on2PF):
	if not N4mtgDP83waX9(m4W3gU71on2PF,True): return
	zzW8eQFgtur1U,OMKhCgJ39NdwY1DP7xmv8EIQ6TUiS,w9zE5caOVtW1Qx = qpFY4hAwolV3,0,0
	M3tdPukY1NHD,ww0xnaWtDVSJjOFzqCB1IXldL,lS9vTBxMWYGDw62hjtQ1 = KIRfl5Tr3Vs(m4W3gU71on2PF,False)
	if M3tdPukY1NHD:
		boDGycW3XOKriA760 = pbLZ4tTDeY8rVdRwGFQPh2A7c0us(ww0xnaWtDVSJjOFzqCB1IXldL)
		OMKhCgJ39NdwY1DP7xmv8EIQ6TUiS = cbWDd2g9hL0ZO8(boDGycW3XOKriA760[0],int(lS9vTBxMWYGDw62hjtQ1))
		LeuKy7JsdxW = PPlUAWKhqTdmnfwLrcYxDS8(m4W3gU71on2PF,'LIVE_GROUPED')
		ZteRaHumGPidbpsf1C = XXyMBNAVJvKiq7jc20bEw6(LeuKy7JsdxW,'list','LIVE_GROUPED')
		LUejlIa7XQWtrik21xfFMAGYwEp4y = XXyMBNAVJvKiq7jc20bEw6(LeuKy7JsdxW,'list','LIVE_GROUPED',ZteRaHumGPidbpsf1C[1])
		WWowRmHkj1ZAO2SUhtNvdrcKa9E6C = LUejlIa7XQWtrik21xfFMAGYwEp4y[0][2]
		eTcVEC91b5owhrKSkJ4 = ePhmG1jLD6.findall('://(.*?)/',WWowRmHkj1ZAO2SUhtNvdrcKa9E6C,ePhmG1jLD6.DOTALL)
		eTcVEC91b5owhrKSkJ4 = eTcVEC91b5owhrKSkJ4[0]
		if ':' in eTcVEC91b5owhrKSkJ4: SrJzqgkIUO,S5pi3e4aQChF0ZWsDqEbBGgLKVIj = eTcVEC91b5owhrKSkJ4.split(':')
		else: SrJzqgkIUO,S5pi3e4aQChF0ZWsDqEbBGgLKVIj = eTcVEC91b5owhrKSkJ4,'80'
		TJovP4i9ltf51rY = pbLZ4tTDeY8rVdRwGFQPh2A7c0us(SrJzqgkIUO)
		w9zE5caOVtW1Qx = cbWDd2g9hL0ZO8(TJovP4i9ltf51rY[0],int(S5pi3e4aQChF0ZWsDqEbBGgLKVIj))
	if OMKhCgJ39NdwY1DP7xmv8EIQ6TUiS and w9zE5caOVtW1Qx:
		w0CZ6B3WDJknhEsdRYyH1XAM = 'هل تريد استخدام السيرفر الأصلي أم السيرفر الأسرع ؟!!'
		w0CZ6B3WDJknhEsdRYyH1XAM += '\n\n'+'وقت ضائع في السيرفر الأصلي'+ZLwoRpfnCWI7FgEHsz6te39lMVh+str(int(w9zE5caOVtW1Qx*1000))+' ملي ثانية'
		w0CZ6B3WDJknhEsdRYyH1XAM += '\n\n'+'وقت ضائع في السيرفر البديل'+ZLwoRpfnCWI7FgEHsz6te39lMVh+str(int(OMKhCgJ39NdwY1DP7xmv8EIQ6TUiS*1000))+' ملي ثانية'
		fN4Cnx6kjp = VVpbtSKYUGXrNMwAWFo9IOjZP('center','السيرفر الأصلي','السيرفر الأسرع',GLTtERWbHnFuy4PCp,w0CZ6B3WDJknhEsdRYyH1XAM)
		if fN4Cnx6kjp==1 and OMKhCgJ39NdwY1DP7xmv8EIQ6TUiS<w9zE5caOVtW1Qx: zzW8eQFgtur1U = ww0xnaWtDVSJjOFzqCB1IXldL+':'+lS9vTBxMWYGDw62hjtQ1
	else: iG7Rz2kmn0x1yLNMV3u8O(qpFY4hAwolV3,qpFY4hAwolV3,GLTtERWbHnFuy4PCp,'البرنامج لم يجد السيرفر البديل')
	gdPslyFW8ITBcpA302.setSetting('av.m3u.server_'+m4W3gU71on2PF,zzW8eQFgtur1U)
	return
def mzcAeyplZV(m4W3gU71on2PF,WWowRmHkj1ZAO2SUhtNvdrcKa9E6C,lQnA93TCSoqKwIMJNz8L):
	wxJgGsHzXkIE1CPuDLq49lbyKAFNp = gdPslyFW8ITBcpA302.getSetting('av.m3u.useragent_'+m4W3gU71on2PF)
	Idtguj9ye2nMQKiEPlpsf58CoqF3 = gdPslyFW8ITBcpA302.getSetting('av.m3u.referer_'+m4W3gU71on2PF)
	if wxJgGsHzXkIE1CPuDLq49lbyKAFNp or Idtguj9ye2nMQKiEPlpsf58CoqF3:
		WWowRmHkj1ZAO2SUhtNvdrcKa9E6C += '|'
		if wxJgGsHzXkIE1CPuDLq49lbyKAFNp: WWowRmHkj1ZAO2SUhtNvdrcKa9E6C += '&User-Agent='+wxJgGsHzXkIE1CPuDLq49lbyKAFNp
		if Idtguj9ye2nMQKiEPlpsf58CoqF3: WWowRmHkj1ZAO2SUhtNvdrcKa9E6C += '&Referer='+Idtguj9ye2nMQKiEPlpsf58CoqF3
		WWowRmHkj1ZAO2SUhtNvdrcKa9E6C = WWowRmHkj1ZAO2SUhtNvdrcKa9E6C.replace('|&','|')
	dORtnXbEgi5A8m0CH(WWowRmHkj1ZAO2SUhtNvdrcKa9E6C,VwkA0oma2Nf,lQnA93TCSoqKwIMJNz8L)
	return
def Jx4WKDnLzw7vea(m4W3gU71on2PF):
	iG7Rz2kmn0x1yLNMV3u8O(qpFY4hAwolV3,qpFY4hAwolV3,GLTtERWbHnFuy4PCp,'تحذير مهم وهام جدا . يرجى عدم تغييره إذا كنت لا تعرف ما هو .  وعدم تغييره إلا عند الضرورة القصوى . الحاجة لهذا التغيير هي فقط إذا طلبت منك شركة ـM3U أن تعمل هذا التغيير . وفقط عندما تستخدم خدمة ـM3U تحتاج ـUser-Agent خاص')
	wxJgGsHzXkIE1CPuDLq49lbyKAFNp = gdPslyFW8ITBcpA302.getSetting('av.m3u.useragent_'+m4W3gU71on2PF)
	VkgcMxaGr8yf4FmSslP5Udh = VVpbtSKYUGXrNMwAWFo9IOjZP('center','استخدام الأصلي','تعديل القديم',wxJgGsHzXkIE1CPuDLq49lbyKAFNp,'هذا هو ـUser-Agent المستخدم حاليا مع ـM3U الذي في هذا البرنامج . هل تريد تعديله أم تريد إعادته إلى وضعية التثبيت الأصلي والتي تقريبا تناسب جميع شركات ـM3U ؟!')
	if VkgcMxaGr8yf4FmSslP5Udh==1: wxJgGsHzXkIE1CPuDLq49lbyKAFNp = jXgARlWMLVFUBnvmZwI2o5('أكتب ـM3U User-Agent جديد',wxJgGsHzXkIE1CPuDLq49lbyKAFNp,True)
	else: wxJgGsHzXkIE1CPuDLq49lbyKAFNp = 'Unknown'
	if wxJgGsHzXkIE1CPuDLq49lbyKAFNp==mIsDke0oK5x1zSiOWbF9thGcA:
		iG7Rz2kmn0x1yLNMV3u8O(qpFY4hAwolV3,qpFY4hAwolV3,GLTtERWbHnFuy4PCp,'غير مسموح أستخدام فراغ لوحده أو عدة فراغات لوحدها ... يجب إما تركه فارغ تماما أو إضافة حرف أو أي شي آخر معها')
		return
	VkgcMxaGr8yf4FmSslP5Udh = VVpbtSKYUGXrNMwAWFo9IOjZP('center',qpFY4hAwolV3,qpFY4hAwolV3,wxJgGsHzXkIE1CPuDLq49lbyKAFNp,'هل تريد استخدام هذا ـUser-Agent بدلا من  القديم ؟')
	if VkgcMxaGr8yf4FmSslP5Udh!=1:
		iG7Rz2kmn0x1yLNMV3u8O(qpFY4hAwolV3,qpFY4hAwolV3,GLTtERWbHnFuy4PCp,'تم الإلغاء')
		return
	gdPslyFW8ITBcpA302.setSetting('av.m3u.useragent_'+m4W3gU71on2PF,wxJgGsHzXkIE1CPuDLq49lbyKAFNp)
	sGN5rVnhIaTqz14FPdki(m4W3gU71on2PF)
	return
def OOFloIqBfA5VKvs78d3E1k(m4W3gU71on2PF):
	iG7Rz2kmn0x1yLNMV3u8O(qpFY4hAwolV3,qpFY4hAwolV3,GLTtERWbHnFuy4PCp,'تحذير مهم وهام جدا . يرجى عدم تغييره إذا كنت لا تعرف ما هو .  وعدم تغييره إلا عند الضرورة القصوى . الحاجة لهذا التغيير هي فقط إذا طلبت منك شركة ـM3U أن تعمل هذا التغيير . وفقط عندما تستخدم خدمة ـM3U تحتاج ـReferer خاص')
	Idtguj9ye2nMQKiEPlpsf58CoqF3 = gdPslyFW8ITBcpA302.getSetting('av.m3u.referer_'+m4W3gU71on2PF)
	VkgcMxaGr8yf4FmSslP5Udh = VVpbtSKYUGXrNMwAWFo9IOjZP('center','استخدام الأصلي','تعديل القديم',Idtguj9ye2nMQKiEPlpsf58CoqF3,'هذا هو ـReferer المستخدم حاليا مع ـM3U الذي في هذا البرنامج . هل تريد تعديله أم تريد إعادته إلى وضعية التثبيت الأصلي والتي تقريبا تناسب جميع شركات ـM3U ؟!')
	if VkgcMxaGr8yf4FmSslP5Udh==1: Idtguj9ye2nMQKiEPlpsf58CoqF3 = jXgARlWMLVFUBnvmZwI2o5('أكتب ـM3U Referer جديد',Idtguj9ye2nMQKiEPlpsf58CoqF3,True)
	else: Idtguj9ye2nMQKiEPlpsf58CoqF3 = qpFY4hAwolV3
	if Idtguj9ye2nMQKiEPlpsf58CoqF3==mIsDke0oK5x1zSiOWbF9thGcA:
		iG7Rz2kmn0x1yLNMV3u8O(qpFY4hAwolV3,qpFY4hAwolV3,GLTtERWbHnFuy4PCp,'غير مسموح أستخدام فراغ لوحده أو عدة فراغات لوحدها ... يجب إما تركه فارغ تماما أو إضافة حرف أو أي شي آخر معها')
		return
	VkgcMxaGr8yf4FmSslP5Udh = VVpbtSKYUGXrNMwAWFo9IOjZP('center',qpFY4hAwolV3,qpFY4hAwolV3,Idtguj9ye2nMQKiEPlpsf58CoqF3,'هل تريد استخدام هذا ـReferer بدلا من  القديم ؟')
	if VkgcMxaGr8yf4FmSslP5Udh!=1:
		iG7Rz2kmn0x1yLNMV3u8O(qpFY4hAwolV3,qpFY4hAwolV3,GLTtERWbHnFuy4PCp,'تم الإلغاء')
		return
	gdPslyFW8ITBcpA302.setSetting('av.m3u.referer_'+m4W3gU71on2PF,Idtguj9ye2nMQKiEPlpsf58CoqF3)
	sGN5rVnhIaTqz14FPdki(m4W3gU71on2PF)
	return
def ggPLfiFuwAYdDG(m4W3gU71on2PF,kadq3VoypwBZtM61ju0Clb5Px2=qpFY4hAwolV3):
	if not T8TdC0Lmhl2fwnGbz4WNxiHX: T8TdC0Lmhl2fwnGbz4WNxiHX = gdPslyFW8ITBcpA302.getSetting('av.m3u.url_'+m4W3gU71on2PF)
	zzW8eQFgtur1U = AWeJuo2LhZ5xiD8KNSqd9G0rtT74FE(T8TdC0Lmhl2fwnGbz4WNxiHX,'url')
	liSOfMZdp6qxC9a = ePhmG1jLD6.findall('username=(.*?)&',T8TdC0Lmhl2fwnGbz4WNxiHX+'&',ePhmG1jLD6.DOTALL)
	ge6LsiVYWbxy5ovGIwrlPkOznd = ePhmG1jLD6.findall('password=(.*?)&',T8TdC0Lmhl2fwnGbz4WNxiHX+'&',ePhmG1jLD6.DOTALL)
	if not liSOfMZdp6qxC9a or not ge6LsiVYWbxy5ovGIwrlPkOznd:
		iG7Rz2kmn0x1yLNMV3u8O(qpFY4hAwolV3,qpFY4hAwolV3,'فحص اشتراك M3U','رابط اشتراك ـM3U الذي قمت انت بإضافته إلى البرنامج لا يعمل أو الرابط غير موجود في البرنامج . أذهب إلى قائمة اشتراك ـM3U وقم بإضافة رابط ـM3U جديد أو قم بإصلاح الرابط القديم')
		return qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3
	liSOfMZdp6qxC9a = liSOfMZdp6qxC9a[0]
	ge6LsiVYWbxy5ovGIwrlPkOznd = ge6LsiVYWbxy5ovGIwrlPkOznd[0]
	KDMqU0V7YydkBHSbmrNwpXCIncA = zzW8eQFgtur1U+'/player_api.php?username='+liSOfMZdp6qxC9a+'&password='+ge6LsiVYWbxy5ovGIwrlPkOznd
	GC6JEjSfpxU5OmTaFBrbL = zzW8eQFgtur1U+'/get.php?username='+liSOfMZdp6qxC9a+'&password='+ge6LsiVYWbxy5ovGIwrlPkOznd+'&type=m3u_plus'
	return KDMqU0V7YydkBHSbmrNwpXCIncA,GC6JEjSfpxU5OmTaFBrbL,zzW8eQFgtur1U,liSOfMZdp6qxC9a,ge6LsiVYWbxy5ovGIwrlPkOznd
def ibNZLwusz1MCVIO3B(m4W3gU71on2PF,LSF3Q57vH29qrm1zlo=qpFY4hAwolV3):
	wV9SCT2earhG = LSF3Q57vH29qrm1zlo.replace(ShynO8pN9idCE3,'_').replace(':','_').replace('.','_')
	wV9SCT2earhG = wV9SCT2earhG.replace('?','_').replace('=','_').replace('&','_')
	wV9SCT2earhG = RPbaxsNFVTwek5Kfv21DiJuzCnjMZp.path.join(F8qeAKZjGRMNXimho2gntaV0,wV9SCT2earhG).strip('.m3u')+'.m3u'
	return wV9SCT2earhG
def aF2eXlORwA5Dr(m4W3gU71on2PF,rrgusv6oweD3tT):
	bliDsLuP2A = gdPslyFW8ITBcpA302.getSetting('av.m3u.url_'+m4W3gU71on2PF+'_'+rrgusv6oweD3tT)
	H4KxvVgnADm3XuNaMoR5k7eqzfLE = True
	if bliDsLuP2A:
		VkgcMxaGr8yf4FmSslP5Udh = eVLmAIGFiwpr94UK6MRP5('center','كتابة جديد','تعديل القديم','مسح القديم','الرابط الحالي هو:',xupTj02bvy3O8R+bliDsLuP2A+fF4lt9zWYxXLKZVyAco82PgMj+'\n\n هذا هو رابط M3U المسجل في البرنامج .. هل تريد تعديله أم تريد كتابة رابط جديد ؟!')
		if VkgcMxaGr8yf4FmSslP5Udh==-1: return
		elif VkgcMxaGr8yf4FmSslP5Udh==0: bliDsLuP2A = qpFY4hAwolV3
		elif VkgcMxaGr8yf4FmSslP5Udh==2:
			VkgcMxaGr8yf4FmSslP5Udh = VVpbtSKYUGXrNMwAWFo9IOjZP('center',qpFY4hAwolV3,qpFY4hAwolV3,GLTtERWbHnFuy4PCp,'هل تريد مسح الرابط المسجل في البرنامج ؟!')
			if VkgcMxaGr8yf4FmSslP5Udh in [-1,0]: return
			iG7Rz2kmn0x1yLNMV3u8O(qpFY4hAwolV3,qpFY4hAwolV3,GLTtERWbHnFuy4PCp,'تم مسح الرابط')
			H4KxvVgnADm3XuNaMoR5k7eqzfLE = False
			X8X04nZF1tiBqjP2yOQcRkoVzbr7 = qpFY4hAwolV3
	if H4KxvVgnADm3XuNaMoR5k7eqzfLE:
		X8X04nZF1tiBqjP2yOQcRkoVzbr7 = jXgARlWMLVFUBnvmZwI2o5('اكتب رابط M3U كاملا',bliDsLuP2A)
		X8X04nZF1tiBqjP2yOQcRkoVzbr7 = X8X04nZF1tiBqjP2yOQcRkoVzbr7.strip(mIsDke0oK5x1zSiOWbF9thGcA)
		if not X8X04nZF1tiBqjP2yOQcRkoVzbr7:
			VkgcMxaGr8yf4FmSslP5Udh = VVpbtSKYUGXrNMwAWFo9IOjZP('center',qpFY4hAwolV3,qpFY4hAwolV3,GLTtERWbHnFuy4PCp,'لقد قمت بإدخال رابط فارغ .. هل تريد مسح الرابط المسجل في البرنامج ؟!')
			if VkgcMxaGr8yf4FmSslP5Udh in [-1,0]: return
			iG7Rz2kmn0x1yLNMV3u8O(qpFY4hAwolV3,qpFY4hAwolV3,GLTtERWbHnFuy4PCp,'تم مسح الرابط')
		else:
			w0CZ6B3WDJknhEsdRYyH1XAM = 'هذه المعلومات تم أخذها من رابط ـM3U الذي انت كتبته . هل تريد استخدامها ؟!\n'
			VkgcMxaGr8yf4FmSslP5Udh = VVpbtSKYUGXrNMwAWFo9IOjZP(qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,'الرابط الجديد هو:',xupTj02bvy3O8R+X8X04nZF1tiBqjP2yOQcRkoVzbr7+fF4lt9zWYxXLKZVyAco82PgMj+'\n\n'+w0CZ6B3WDJknhEsdRYyH1XAM)
			if VkgcMxaGr8yf4FmSslP5Udh!=1:
				iG7Rz2kmn0x1yLNMV3u8O(qpFY4hAwolV3,qpFY4hAwolV3,GLTtERWbHnFuy4PCp,'تم الإلغاء')
				return
	gdPslyFW8ITBcpA302.setSetting('av.m3u.url_'+m4W3gU71on2PF+'_'+rrgusv6oweD3tT,X8X04nZF1tiBqjP2yOQcRkoVzbr7)
	wxJgGsHzXkIE1CPuDLq49lbyKAFNp = gdPslyFW8ITBcpA302.getSetting('av.m3u.useragent_'+m4W3gU71on2PF)
	if not wxJgGsHzXkIE1CPuDLq49lbyKAFNp: gdPslyFW8ITBcpA302.setSetting('av.m3u.useragent_'+m4W3gU71on2PF,'Unknown')
	sGN5rVnhIaTqz14FPdki(m4W3gU71on2PF)
	return
def iYvF5Ml1sjV3f7J4(ooW8A4LRvgDeIr0CNO,hVcaD8tkOduIXoWYpPJ37L,SSxK27Ps5w3R1Y4CnMelB6m8TZXVpc,lndB4MyFXmN9CjUV3g,OMNGzgPQ3sfTRZ6V,Il0c1rSN46qmWzJZTks3UteLExn,GC6JEjSfpxU5OmTaFBrbL):
	LUejlIa7XQWtrik21xfFMAGYwEp4y,q96MucKzm87aopEb = [],[]
	Ub3e2KDTjgnrQFfti = ['.avi','.mp4','.mkv','.mp3','.webm','.aac']
	for wYeU08VTvm3fXJ in ooW8A4LRvgDeIr0CNO:
		if Il0c1rSN46qmWzJZTks3UteLExn%473==0:
			fgVlCuI8wy0znKvp1E5oj9xmD(lndB4MyFXmN9CjUV3g,40+int(10*Il0c1rSN46qmWzJZTks3UteLExn/OMNGzgPQ3sfTRZ6V),'قراءة الفيديوهات','الفيديو رقم:-',str(Il0c1rSN46qmWzJZTks3UteLExn)+' / '+str(OMNGzgPQ3sfTRZ6V))
			if lndB4MyFXmN9CjUV3g.iscanceled():
				lndB4MyFXmN9CjUV3g.close()
				return None,None,None
		WWowRmHkj1ZAO2SUhtNvdrcKa9E6C = ePhmG1jLD6.findall('^(.*?)\n+((http|https|rtmp).*?)$',wYeU08VTvm3fXJ,ePhmG1jLD6.DOTALL)
		if WWowRmHkj1ZAO2SUhtNvdrcKa9E6C:
			wYeU08VTvm3fXJ,WWowRmHkj1ZAO2SUhtNvdrcKa9E6C,mv9MSqEQYLU2cW8tklbKZzO = WWowRmHkj1ZAO2SUhtNvdrcKa9E6C[0]
			WWowRmHkj1ZAO2SUhtNvdrcKa9E6C = WWowRmHkj1ZAO2SUhtNvdrcKa9E6C.replace(ZLwoRpfnCWI7FgEHsz6te39lMVh,qpFY4hAwolV3)
			wYeU08VTvm3fXJ = wYeU08VTvm3fXJ.replace(ZLwoRpfnCWI7FgEHsz6te39lMVh,qpFY4hAwolV3)
		else:
			q96MucKzm87aopEb.append({'line':wYeU08VTvm3fXJ})
			continue
		vDCftBx0I7nUkNKHuVTRM,fdD0wQgTuni,dW4u3hS9wKCqD6xvIbylR,zaDq3igbdyhsSnRcxoQ7uYPkl,lQnA93TCSoqKwIMJNz8L,Aax3ejDyEIk0lWFLHzB71grVXNm = {},qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,False
		try:
			wYeU08VTvm3fXJ,zaDq3igbdyhsSnRcxoQ7uYPkl = wYeU08VTvm3fXJ.rsplit('",',1)
			wYeU08VTvm3fXJ = wYeU08VTvm3fXJ+'"'
		except:
			try: wYeU08VTvm3fXJ,zaDq3igbdyhsSnRcxoQ7uYPkl = wYeU08VTvm3fXJ.rsplit('1,',1)
			except: zaDq3igbdyhsSnRcxoQ7uYPkl = qpFY4hAwolV3
		vDCftBx0I7nUkNKHuVTRM['url'] = WWowRmHkj1ZAO2SUhtNvdrcKa9E6C
		giKMaYDB0E7jw = ePhmG1jLD6.findall(' (.*?)="(.*?)"',wYeU08VTvm3fXJ,ePhmG1jLD6.DOTALL)
		for f79ZnTkH0m45a1vj63xuQSd,Y9fDWnXar1c7bdThim0AKJx8jF64L5 in giKMaYDB0E7jw:
			f79ZnTkH0m45a1vj63xuQSd = f79ZnTkH0m45a1vj63xuQSd.replace('"',qpFY4hAwolV3).strip(mIsDke0oK5x1zSiOWbF9thGcA)
			vDCftBx0I7nUkNKHuVTRM[f79ZnTkH0m45a1vj63xuQSd] = Y9fDWnXar1c7bdThim0AKJx8jF64L5.strip(mIsDke0oK5x1zSiOWbF9thGcA)
		bUdOjz1ys0HelJvk5KGnDL = list(vDCftBx0I7nUkNKHuVTRM.keys())
		if not zaDq3igbdyhsSnRcxoQ7uYPkl:
			if 'name' in bUdOjz1ys0HelJvk5KGnDL and vDCftBx0I7nUkNKHuVTRM['name']: zaDq3igbdyhsSnRcxoQ7uYPkl = vDCftBx0I7nUkNKHuVTRM['name']
		vDCftBx0I7nUkNKHuVTRM['title'] = zaDq3igbdyhsSnRcxoQ7uYPkl.strip(mIsDke0oK5x1zSiOWbF9thGcA).replace(r1roOXYi7UQw9FLThzPEdD0ZlvAnRc,mIsDke0oK5x1zSiOWbF9thGcA).replace(r1roOXYi7UQw9FLThzPEdD0ZlvAnRc,mIsDke0oK5x1zSiOWbF9thGcA)
		if 'logo' in bUdOjz1ys0HelJvk5KGnDL:
			vDCftBx0I7nUkNKHuVTRM['img'] = vDCftBx0I7nUkNKHuVTRM['logo']
			del vDCftBx0I7nUkNKHuVTRM['logo']
		else: vDCftBx0I7nUkNKHuVTRM['img'] = qpFY4hAwolV3
		if 'group' in bUdOjz1ys0HelJvk5KGnDL and vDCftBx0I7nUkNKHuVTRM['group']: dW4u3hS9wKCqD6xvIbylR = vDCftBx0I7nUkNKHuVTRM['group']
		if any(value in WWowRmHkj1ZAO2SUhtNvdrcKa9E6C.lower() for value in Ub3e2KDTjgnrQFfti):
			Aax3ejDyEIk0lWFLHzB71grVXNm = True if 'm3u' not in WWowRmHkj1ZAO2SUhtNvdrcKa9E6C else False
		if Aax3ejDyEIk0lWFLHzB71grVXNm or '__SERIES__' in dW4u3hS9wKCqD6xvIbylR or '__MOVIES__' in dW4u3hS9wKCqD6xvIbylR:
			lQnA93TCSoqKwIMJNz8L = 'VOD'
			if '__SERIES__' in dW4u3hS9wKCqD6xvIbylR: lQnA93TCSoqKwIMJNz8L = lQnA93TCSoqKwIMJNz8L+'_SERIES'
			elif '__MOVIES__' in dW4u3hS9wKCqD6xvIbylR: lQnA93TCSoqKwIMJNz8L = lQnA93TCSoqKwIMJNz8L+'_MOVIES'
			else: lQnA93TCSoqKwIMJNz8L = lQnA93TCSoqKwIMJNz8L+'_UNKNOWN'
			dW4u3hS9wKCqD6xvIbylR = dW4u3hS9wKCqD6xvIbylR.replace('__SERIES__',qpFY4hAwolV3).replace('__MOVIES__',qpFY4hAwolV3)
		else:
			lQnA93TCSoqKwIMJNz8L = 'LIVE'
			if zaDq3igbdyhsSnRcxoQ7uYPkl in hVcaD8tkOduIXoWYpPJ37L: fdD0wQgTuni = fdD0wQgTuni+'_EPG'
			if zaDq3igbdyhsSnRcxoQ7uYPkl in SSxK27Ps5w3R1Y4CnMelB6m8TZXVpc: fdD0wQgTuni = fdD0wQgTuni+'_ARCHIVED'
			if not dW4u3hS9wKCqD6xvIbylR: lQnA93TCSoqKwIMJNz8L = lQnA93TCSoqKwIMJNz8L+'_UNKNOWN'
			else: lQnA93TCSoqKwIMJNz8L = lQnA93TCSoqKwIMJNz8L+fdD0wQgTuni
		dW4u3hS9wKCqD6xvIbylR = dW4u3hS9wKCqD6xvIbylR.strip(mIsDke0oK5x1zSiOWbF9thGcA).replace(r1roOXYi7UQw9FLThzPEdD0ZlvAnRc,mIsDke0oK5x1zSiOWbF9thGcA).replace(r1roOXYi7UQw9FLThzPEdD0ZlvAnRc,mIsDke0oK5x1zSiOWbF9thGcA)
		if 'LIVE_UNKNOWN' in lQnA93TCSoqKwIMJNz8L: dW4u3hS9wKCqD6xvIbylR = '!!__UNKNOWN_LIVE__!!'
		elif 'VOD_UNKNOWN' in lQnA93TCSoqKwIMJNz8L: dW4u3hS9wKCqD6xvIbylR = '!!__UNKNOWN_VOD__!!'
		elif 'VOD_SERIES' in lQnA93TCSoqKwIMJNz8L:
			QzLslni0E3PrqM8 = ePhmG1jLD6.findall('(.*?) [Ss]\d+ +[Ee]\d+',vDCftBx0I7nUkNKHuVTRM['title'],ePhmG1jLD6.DOTALL)
			if QzLslni0E3PrqM8: QzLslni0E3PrqM8 = QzLslni0E3PrqM8[0]
			else: QzLslni0E3PrqM8 = '!!__UNKNOWN_SERIES__!!'
			dW4u3hS9wKCqD6xvIbylR = dW4u3hS9wKCqD6xvIbylR+'__SERIES__'+QzLslni0E3PrqM8
		if 'id' in bUdOjz1ys0HelJvk5KGnDL: del vDCftBx0I7nUkNKHuVTRM['id']
		if 'ID' in bUdOjz1ys0HelJvk5KGnDL: del vDCftBx0I7nUkNKHuVTRM['ID']
		if 'name' in bUdOjz1ys0HelJvk5KGnDL: del vDCftBx0I7nUkNKHuVTRM['name']
		zaDq3igbdyhsSnRcxoQ7uYPkl = vDCftBx0I7nUkNKHuVTRM['title']
		zaDq3igbdyhsSnRcxoQ7uYPkl = N8E37XwL6iQbmBY(zaDq3igbdyhsSnRcxoQ7uYPkl)
		zaDq3igbdyhsSnRcxoQ7uYPkl = w7ONAM6yfZh5ouEDe1blIVUPnt(zaDq3igbdyhsSnRcxoQ7uYPkl)
		ZMGgr3Tc6lOH948QvFX,dW4u3hS9wKCqD6xvIbylR = YJwRE4xkf2mOASBhncTMr1y8(dW4u3hS9wKCqD6xvIbylR)
		w35Hu0LsNEmO4Zx1JFnp8DvR9,zaDq3igbdyhsSnRcxoQ7uYPkl = YJwRE4xkf2mOASBhncTMr1y8(zaDq3igbdyhsSnRcxoQ7uYPkl)
		vDCftBx0I7nUkNKHuVTRM['type'] = lQnA93TCSoqKwIMJNz8L
		vDCftBx0I7nUkNKHuVTRM['context'] = fdD0wQgTuni
		vDCftBx0I7nUkNKHuVTRM['group'] = dW4u3hS9wKCqD6xvIbylR.upper()
		vDCftBx0I7nUkNKHuVTRM['title'] = zaDq3igbdyhsSnRcxoQ7uYPkl.upper()
		vDCftBx0I7nUkNKHuVTRM['country'] = w35Hu0LsNEmO4Zx1JFnp8DvR9.upper()
		vDCftBx0I7nUkNKHuVTRM['language'] = ZMGgr3Tc6lOH948QvFX.upper()
		LUejlIa7XQWtrik21xfFMAGYwEp4y.append(vDCftBx0I7nUkNKHuVTRM)
		Il0c1rSN46qmWzJZTks3UteLExn += 1
	return LUejlIa7XQWtrik21xfFMAGYwEp4y,Il0c1rSN46qmWzJZTks3UteLExn,q96MucKzm87aopEb
def w7ONAM6yfZh5ouEDe1blIVUPnt(zaDq3igbdyhsSnRcxoQ7uYPkl):
	zaDq3igbdyhsSnRcxoQ7uYPkl = zaDq3igbdyhsSnRcxoQ7uYPkl.replace(r1roOXYi7UQw9FLThzPEdD0ZlvAnRc,mIsDke0oK5x1zSiOWbF9thGcA).replace(r1roOXYi7UQw9FLThzPEdD0ZlvAnRc,mIsDke0oK5x1zSiOWbF9thGcA).replace(r1roOXYi7UQw9FLThzPEdD0ZlvAnRc,mIsDke0oK5x1zSiOWbF9thGcA)
	zaDq3igbdyhsSnRcxoQ7uYPkl = zaDq3igbdyhsSnRcxoQ7uYPkl.replace('||','|').replace('___',':').replace('--','-')
	zaDq3igbdyhsSnRcxoQ7uYPkl = zaDq3igbdyhsSnRcxoQ7uYPkl.replace('[[','[').replace(']]',']')
	zaDq3igbdyhsSnRcxoQ7uYPkl = zaDq3igbdyhsSnRcxoQ7uYPkl.replace('((','(').replace('))',')')
	zaDq3igbdyhsSnRcxoQ7uYPkl = zaDq3igbdyhsSnRcxoQ7uYPkl.replace('<<','<').replace('>>','>')
	zaDq3igbdyhsSnRcxoQ7uYPkl = zaDq3igbdyhsSnRcxoQ7uYPkl.strip(mIsDke0oK5x1zSiOWbF9thGcA)
	return zaDq3igbdyhsSnRcxoQ7uYPkl
def UBExO375Z6WQiuF(nSdvk9W5IsZRxTtFlMyw7CEXpe,lndB4MyFXmN9CjUV3g,rrgusv6oweD3tT):
	gqi6dfmFMp4aeu5jDrSz1ny7QsW = {}
	for cXClv9mVOutd2YQDBWiTrU in Va04phzWlCG: gqi6dfmFMp4aeu5jDrSz1ny7QsW[cXClv9mVOutd2YQDBWiTrU+'_'+rrgusv6oweD3tT] = []
	OMNGzgPQ3sfTRZ6V = len(nSdvk9W5IsZRxTtFlMyw7CEXpe)
	iiUcnWt9OKmCJhQYTzseVx7XL = str(OMNGzgPQ3sfTRZ6V)
	Il0c1rSN46qmWzJZTks3UteLExn = 0
	q96MucKzm87aopEb = []
	for vDCftBx0I7nUkNKHuVTRM in nSdvk9W5IsZRxTtFlMyw7CEXpe:
		if Il0c1rSN46qmWzJZTks3UteLExn%873==0:
			fgVlCuI8wy0znKvp1E5oj9xmD(lndB4MyFXmN9CjUV3g,50+int(5*Il0c1rSN46qmWzJZTks3UteLExn/OMNGzgPQ3sfTRZ6V),'تصنيف الفيديوهات الغير مرتبة','الفيديو رقم:-',str(Il0c1rSN46qmWzJZTks3UteLExn)+' / '+iiUcnWt9OKmCJhQYTzseVx7XL)
			if lndB4MyFXmN9CjUV3g.iscanceled():
				lndB4MyFXmN9CjUV3g.close()
				return None,None
		dW4u3hS9wKCqD6xvIbylR,fdD0wQgTuni,zaDq3igbdyhsSnRcxoQ7uYPkl,WWowRmHkj1ZAO2SUhtNvdrcKa9E6C,xNF9bfr3tm = vDCftBx0I7nUkNKHuVTRM['group'],vDCftBx0I7nUkNKHuVTRM['context'],vDCftBx0I7nUkNKHuVTRM['title'],vDCftBx0I7nUkNKHuVTRM['url'],vDCftBx0I7nUkNKHuVTRM['img']
		w35Hu0LsNEmO4Zx1JFnp8DvR9,ZMGgr3Tc6lOH948QvFX,cXClv9mVOutd2YQDBWiTrU = vDCftBx0I7nUkNKHuVTRM['country'],vDCftBx0I7nUkNKHuVTRM['language'],vDCftBx0I7nUkNKHuVTRM['type']
		d2ULr3M4oRugmJQwZYnF = (dW4u3hS9wKCqD6xvIbylR,fdD0wQgTuni,zaDq3igbdyhsSnRcxoQ7uYPkl,WWowRmHkj1ZAO2SUhtNvdrcKa9E6C,xNF9bfr3tm)
		RxMJ137UKDy9wXZe2kFO5PACcomQsa = False
		if 'LIVE' in cXClv9mVOutd2YQDBWiTrU:
			if 'UNKNOWN' in cXClv9mVOutd2YQDBWiTrU: gqi6dfmFMp4aeu5jDrSz1ny7QsW['LIVE_UNKNOWN_GROUPED_'+rrgusv6oweD3tT].append(d2ULr3M4oRugmJQwZYnF)
			elif 'LIVE' in cXClv9mVOutd2YQDBWiTrU: gqi6dfmFMp4aeu5jDrSz1ny7QsW['LIVE_GROUPED_'+rrgusv6oweD3tT].append(d2ULr3M4oRugmJQwZYnF)
			else: RxMJ137UKDy9wXZe2kFO5PACcomQsa = True
			gqi6dfmFMp4aeu5jDrSz1ny7QsW['LIVE_ORIGINAL_GROUPED_'+rrgusv6oweD3tT].append(d2ULr3M4oRugmJQwZYnF)
		elif 'VOD' in cXClv9mVOutd2YQDBWiTrU:
			if 'UNKNOWN' in cXClv9mVOutd2YQDBWiTrU: gqi6dfmFMp4aeu5jDrSz1ny7QsW['VOD_UNKNOWN_GROUPED_'+rrgusv6oweD3tT].append(d2ULr3M4oRugmJQwZYnF)
			elif 'MOVIES' in cXClv9mVOutd2YQDBWiTrU: gqi6dfmFMp4aeu5jDrSz1ny7QsW['VOD_MOVIES_GROUPED_'+rrgusv6oweD3tT].append(d2ULr3M4oRugmJQwZYnF)
			elif 'SERIES' in cXClv9mVOutd2YQDBWiTrU: gqi6dfmFMp4aeu5jDrSz1ny7QsW['VOD_SERIES_GROUPED_'+rrgusv6oweD3tT].append(d2ULr3M4oRugmJQwZYnF)
			else: RxMJ137UKDy9wXZe2kFO5PACcomQsa = True
			gqi6dfmFMp4aeu5jDrSz1ny7QsW['VOD_ORIGINAL_GROUPED_'+rrgusv6oweD3tT].append(d2ULr3M4oRugmJQwZYnF)
		else: RxMJ137UKDy9wXZe2kFO5PACcomQsa = True
		if RxMJ137UKDy9wXZe2kFO5PACcomQsa: q96MucKzm87aopEb.append(vDCftBx0I7nUkNKHuVTRM)
		Il0c1rSN46qmWzJZTks3UteLExn += 1
	lEm9jTS1OJohVyZLn5p0xBYaefD = sorted(nSdvk9W5IsZRxTtFlMyw7CEXpe,reverse=False,key=lambda f79ZnTkH0m45a1vj63xuQSd: f79ZnTkH0m45a1vj63xuQSd['title'].lower())
	del nSdvk9W5IsZRxTtFlMyw7CEXpe
	iiUcnWt9OKmCJhQYTzseVx7XL = str(OMNGzgPQ3sfTRZ6V)
	Il0c1rSN46qmWzJZTks3UteLExn = 0
	for vDCftBx0I7nUkNKHuVTRM in lEm9jTS1OJohVyZLn5p0xBYaefD:
		Il0c1rSN46qmWzJZTks3UteLExn += 1
		if Il0c1rSN46qmWzJZTks3UteLExn%873==0:
			fgVlCuI8wy0znKvp1E5oj9xmD(lndB4MyFXmN9CjUV3g,55+int(5*Il0c1rSN46qmWzJZTks3UteLExn/OMNGzgPQ3sfTRZ6V),'تصنيف الفيديوهات المرتبة','الفيديو رقم:-',str(Il0c1rSN46qmWzJZTks3UteLExn)+' / '+iiUcnWt9OKmCJhQYTzseVx7XL)
			if lndB4MyFXmN9CjUV3g.iscanceled():
				lndB4MyFXmN9CjUV3g.close()
				return None,None
		cXClv9mVOutd2YQDBWiTrU = vDCftBx0I7nUkNKHuVTRM['type']
		dW4u3hS9wKCqD6xvIbylR,fdD0wQgTuni,zaDq3igbdyhsSnRcxoQ7uYPkl,WWowRmHkj1ZAO2SUhtNvdrcKa9E6C,xNF9bfr3tm = vDCftBx0I7nUkNKHuVTRM['group'],vDCftBx0I7nUkNKHuVTRM['context'],vDCftBx0I7nUkNKHuVTRM['title'],vDCftBx0I7nUkNKHuVTRM['url'],vDCftBx0I7nUkNKHuVTRM['img']
		w35Hu0LsNEmO4Zx1JFnp8DvR9,ZMGgr3Tc6lOH948QvFX = vDCftBx0I7nUkNKHuVTRM['country'],vDCftBx0I7nUkNKHuVTRM['language']
		BGFN2v9iXuf5Kreo4q73P0mIRJMtbC = (dW4u3hS9wKCqD6xvIbylR,fdD0wQgTuni+'_TIMESHIFT',zaDq3igbdyhsSnRcxoQ7uYPkl,WWowRmHkj1ZAO2SUhtNvdrcKa9E6C,xNF9bfr3tm)
		d2ULr3M4oRugmJQwZYnF = (dW4u3hS9wKCqD6xvIbylR,fdD0wQgTuni,zaDq3igbdyhsSnRcxoQ7uYPkl,WWowRmHkj1ZAO2SUhtNvdrcKa9E6C,xNF9bfr3tm)
		X21v5aT7Scb3x = (w35Hu0LsNEmO4Zx1JFnp8DvR9,fdD0wQgTuni,zaDq3igbdyhsSnRcxoQ7uYPkl,WWowRmHkj1ZAO2SUhtNvdrcKa9E6C,xNF9bfr3tm)
		i7iChAGubMY4TROat8ELo9mZFXq = (ZMGgr3Tc6lOH948QvFX,fdD0wQgTuni,zaDq3igbdyhsSnRcxoQ7uYPkl,WWowRmHkj1ZAO2SUhtNvdrcKa9E6C,xNF9bfr3tm)
		if 'LIVE' in cXClv9mVOutd2YQDBWiTrU:
			if 'UNKNOWN' in cXClv9mVOutd2YQDBWiTrU: gqi6dfmFMp4aeu5jDrSz1ny7QsW['LIVE_UNKNOWN_GROUPED_SORTED_'+rrgusv6oweD3tT].append(d2ULr3M4oRugmJQwZYnF)
			else: gqi6dfmFMp4aeu5jDrSz1ny7QsW['LIVE_GROUPED_SORTED_'+rrgusv6oweD3tT].append(d2ULr3M4oRugmJQwZYnF)
			if 'EPG'		in cXClv9mVOutd2YQDBWiTrU: gqi6dfmFMp4aeu5jDrSz1ny7QsW['LIVE_EPG_GROUPED_SORTED_'+rrgusv6oweD3tT].append(d2ULr3M4oRugmJQwZYnF)
			if 'ARCHIVED'	in cXClv9mVOutd2YQDBWiTrU: gqi6dfmFMp4aeu5jDrSz1ny7QsW['LIVE_ARCHIVED_GROUPED_SORTED_'+rrgusv6oweD3tT].append(d2ULr3M4oRugmJQwZYnF)
			if 'ARCHIVED'	in cXClv9mVOutd2YQDBWiTrU: gqi6dfmFMp4aeu5jDrSz1ny7QsW['LIVE_TIMESHIFT_GROUPED_SORTED_'+rrgusv6oweD3tT].append(BGFN2v9iXuf5Kreo4q73P0mIRJMtbC)
			gqi6dfmFMp4aeu5jDrSz1ny7QsW['LIVE_FROM_NAME_SORTED_'+rrgusv6oweD3tT].append(X21v5aT7Scb3x)
			gqi6dfmFMp4aeu5jDrSz1ny7QsW['LIVE_FROM_GROUP_SORTED_'+rrgusv6oweD3tT].append(i7iChAGubMY4TROat8ELo9mZFXq)
		elif 'VOD' in cXClv9mVOutd2YQDBWiTrU:
			if   'UNKNOWN'	in cXClv9mVOutd2YQDBWiTrU: gqi6dfmFMp4aeu5jDrSz1ny7QsW['VOD_UNKNOWN_GROUPED_SORTED_'+rrgusv6oweD3tT].append(d2ULr3M4oRugmJQwZYnF)
			elif 'MOVIES'	in cXClv9mVOutd2YQDBWiTrU: gqi6dfmFMp4aeu5jDrSz1ny7QsW['VOD_MOVIES_GROUPED_SORTED_'+rrgusv6oweD3tT].append(d2ULr3M4oRugmJQwZYnF)
			elif 'SERIES'	in cXClv9mVOutd2YQDBWiTrU: gqi6dfmFMp4aeu5jDrSz1ny7QsW['VOD_SERIES_GROUPED_SORTED_'+rrgusv6oweD3tT].append(d2ULr3M4oRugmJQwZYnF)
			gqi6dfmFMp4aeu5jDrSz1ny7QsW['VOD_FROM_NAME_SORTED_'+rrgusv6oweD3tT].append(X21v5aT7Scb3x)
			gqi6dfmFMp4aeu5jDrSz1ny7QsW['VOD_FROM_GROUP_SORTED_'+rrgusv6oweD3tT].append(i7iChAGubMY4TROat8ELo9mZFXq)
	return gqi6dfmFMp4aeu5jDrSz1ny7QsW,q96MucKzm87aopEb
def YJwRE4xkf2mOASBhncTMr1y8(zaDq3igbdyhsSnRcxoQ7uYPkl):
	if len(zaDq3igbdyhsSnRcxoQ7uYPkl)<3: return zaDq3igbdyhsSnRcxoQ7uYPkl,zaDq3igbdyhsSnRcxoQ7uYPkl
	MzIEZB1bwPuenW3imvkt,EI5ned2czsgPa9ZQxTyB = qpFY4hAwolV3,qpFY4hAwolV3
	ZHtRw8bN6h4Pam3KsEUQxgySFjA = zaDq3igbdyhsSnRcxoQ7uYPkl
	EviSAhs8t760 = zaDq3igbdyhsSnRcxoQ7uYPkl[:1]
	lpqu2D1jMwT = zaDq3igbdyhsSnRcxoQ7uYPkl[1:]
	if   EviSAhs8t760=='(': EI5ned2czsgPa9ZQxTyB = ')'
	elif EviSAhs8t760=='[': EI5ned2czsgPa9ZQxTyB = ']'
	elif EviSAhs8t760=='<': EI5ned2czsgPa9ZQxTyB = '>'
	elif EviSAhs8t760=='|': EI5ned2czsgPa9ZQxTyB = '|'
	if EI5ned2czsgPa9ZQxTyB and (EI5ned2czsgPa9ZQxTyB in lpqu2D1jMwT):
		BrlTYC4uVqvfdmhMZWRJ0E3PAKxGbN,QfS2yH8j3GYicvbWo = lpqu2D1jMwT.split(EI5ned2czsgPa9ZQxTyB,1)
		MzIEZB1bwPuenW3imvkt = BrlTYC4uVqvfdmhMZWRJ0E3PAKxGbN
		ZHtRw8bN6h4Pam3KsEUQxgySFjA = EviSAhs8t760+BrlTYC4uVqvfdmhMZWRJ0E3PAKxGbN+EI5ned2czsgPa9ZQxTyB+mIsDke0oK5x1zSiOWbF9thGcA+QfS2yH8j3GYicvbWo
	elif zaDq3igbdyhsSnRcxoQ7uYPkl.count('|')>=2:
		BrlTYC4uVqvfdmhMZWRJ0E3PAKxGbN,QfS2yH8j3GYicvbWo = zaDq3igbdyhsSnRcxoQ7uYPkl.split('|',1)
		MzIEZB1bwPuenW3imvkt = BrlTYC4uVqvfdmhMZWRJ0E3PAKxGbN
		ZHtRw8bN6h4Pam3KsEUQxgySFjA = BrlTYC4uVqvfdmhMZWRJ0E3PAKxGbN+' |'+QfS2yH8j3GYicvbWo
	else:
		EI5ned2czsgPa9ZQxTyB = ePhmG1jLD6.findall('^\w{2}( |\:|\-|\||\]|\)|'+'#'+'|\.|\,|\$|\'|\!|\@|\%|\&|\*|\^)',zaDq3igbdyhsSnRcxoQ7uYPkl,ePhmG1jLD6.DOTALL)
		if not EI5ned2czsgPa9ZQxTyB: EI5ned2czsgPa9ZQxTyB = ePhmG1jLD6.findall('^\w{3}( |\:|\-|\||\]|\)|'+'#'+'|\.|\,|\$|\'|\!|\@|\%|\&|\*|\^)',zaDq3igbdyhsSnRcxoQ7uYPkl,ePhmG1jLD6.DOTALL)
		if not EI5ned2czsgPa9ZQxTyB: EI5ned2czsgPa9ZQxTyB = ePhmG1jLD6.findall('^\w{4}( |\:|\-|\||\]|\)|'+'#'+'|\.|\,|\$|\'|\!|\@|\%|\&|\*|\^)',zaDq3igbdyhsSnRcxoQ7uYPkl,ePhmG1jLD6.DOTALL)
		if EI5ned2czsgPa9ZQxTyB:
			BrlTYC4uVqvfdmhMZWRJ0E3PAKxGbN,QfS2yH8j3GYicvbWo = zaDq3igbdyhsSnRcxoQ7uYPkl.split(EI5ned2czsgPa9ZQxTyB[0],1)
			MzIEZB1bwPuenW3imvkt = BrlTYC4uVqvfdmhMZWRJ0E3PAKxGbN
			ZHtRw8bN6h4Pam3KsEUQxgySFjA = BrlTYC4uVqvfdmhMZWRJ0E3PAKxGbN+mIsDke0oK5x1zSiOWbF9thGcA+EI5ned2czsgPa9ZQxTyB[0]+mIsDke0oK5x1zSiOWbF9thGcA+QfS2yH8j3GYicvbWo
	ZHtRw8bN6h4Pam3KsEUQxgySFjA = ZHtRw8bN6h4Pam3KsEUQxgySFjA.replace(bJGaEk9wcz,mIsDke0oK5x1zSiOWbF9thGcA).replace(r1roOXYi7UQw9FLThzPEdD0ZlvAnRc,mIsDke0oK5x1zSiOWbF9thGcA)
	MzIEZB1bwPuenW3imvkt = MzIEZB1bwPuenW3imvkt.replace(r1roOXYi7UQw9FLThzPEdD0ZlvAnRc,mIsDke0oK5x1zSiOWbF9thGcA)
	if not MzIEZB1bwPuenW3imvkt: MzIEZB1bwPuenW3imvkt = '!!__UNKNOWN__!!'
	MzIEZB1bwPuenW3imvkt = MzIEZB1bwPuenW3imvkt.strip(mIsDke0oK5x1zSiOWbF9thGcA)
	ZHtRw8bN6h4Pam3KsEUQxgySFjA = ZHtRw8bN6h4Pam3KsEUQxgySFjA.strip(mIsDke0oK5x1zSiOWbF9thGcA)
	return MzIEZB1bwPuenW3imvkt,ZHtRw8bN6h4Pam3KsEUQxgySFjA
def O1O0wLKjB2yV5kg9AhbC(m4W3gU71on2PF):
	EBOwuZ71x92omaIKbGFU3A54pqkc = {}
	wxJgGsHzXkIE1CPuDLq49lbyKAFNp = gdPslyFW8ITBcpA302.getSetting('av.m3u.useragent_'+m4W3gU71on2PF)
	if wxJgGsHzXkIE1CPuDLq49lbyKAFNp: EBOwuZ71x92omaIKbGFU3A54pqkc['User-Agent'] = wxJgGsHzXkIE1CPuDLq49lbyKAFNp
	Idtguj9ye2nMQKiEPlpsf58CoqF3 = gdPslyFW8ITBcpA302.getSetting('av.m3u.referer_'+m4W3gU71on2PF)
	if Idtguj9ye2nMQKiEPlpsf58CoqF3: EBOwuZ71x92omaIKbGFU3A54pqkc['Referer'] = Idtguj9ye2nMQKiEPlpsf58CoqF3
	return EBOwuZ71x92omaIKbGFU3A54pqkc
def F8YMO5Ecs1A(m4W3gU71on2PF,rrgusv6oweD3tT):
	global lndB4MyFXmN9CjUV3g,gqi6dfmFMp4aeu5jDrSz1ny7QsW,HfDhSC8Rueq5s,w2n4cuRIMVU37Af1Zl,tbCJirHuVPxLA20hM,ZteRaHumGPidbpsf1C,jJWoA3SLya,CCBfSVIQ3t9EuMos,I2jYgyCTA3KBuM6VedEips
	GC6JEjSfpxU5OmTaFBrbL = gdPslyFW8ITBcpA302.getSetting('av.m3u.url_'+m4W3gU71on2PF+'_'+rrgusv6oweD3tT)
	wxJgGsHzXkIE1CPuDLq49lbyKAFNp = gdPslyFW8ITBcpA302.getSetting('av.m3u.useragent_'+m4W3gU71on2PF)
	EBOwuZ71x92omaIKbGFU3A54pqkc = {'User-Agent':wxJgGsHzXkIE1CPuDLq49lbyKAFNp}
	wV9SCT2earhG = v3DXdfGq7VeBh9ousFNOw8yrkEM1n.replace('___','_'+m4W3gU71on2PF+'_'+rrgusv6oweD3tT)
	if 1:
		M3tdPukY1NHD,ww0xnaWtDVSJjOFzqCB1IXldL,lS9vTBxMWYGDw62hjtQ1 = True,qpFY4hAwolV3,qpFY4hAwolV3
		if not M3tdPukY1NHD:
			iG7Rz2kmn0x1yLNMV3u8O(qpFY4hAwolV3,qpFY4hAwolV3,GLTtERWbHnFuy4PCp,'فشل بسحب ملفات ـM3U . أحتمال رابط ـM3U غير صحيح أو قديم أو لا يعمل .. علما أن هذه الخدمة تحتاج اشتراك مدفوع وصحيح ويجب أن تضيف رابط الاشتراك بنفسك للبرنامج باستخدام قائمة ـM3U الموجودة بهذا البرنامج')
			if not GC6JEjSfpxU5OmTaFBrbL: LLvyStW429DEZKlA(j8gFJIMYPoBzcCvG9T,lTW9p1v7uPfOxB(Q8Q0IDc6PLZajJAdTntKUmSGXz)+'   No M3U URL found to download M3U files')
			else: LLvyStW429DEZKlA(j8gFJIMYPoBzcCvG9T,lTW9p1v7uPfOxB(VwkA0oma2Nf)+'   Failed to download M3U files')
			return
		ySHspGNYfmdJqV0bAvIZx6Mwz = OPCnG7Q8agh4wcdeZ(GC6JEjSfpxU5OmTaFBrbL,EBOwuZ71x92omaIKbGFU3A54pqkc,True)
		if not ySHspGNYfmdJqV0bAvIZx6Mwz: return
		open(wV9SCT2earhG,'wb').write(ySHspGNYfmdJqV0bAvIZx6Mwz)
	else: ySHspGNYfmdJqV0bAvIZx6Mwz = open(wV9SCT2earhG,'rb').read()
	if DLod2Of8CkRrtzJynev and ySHspGNYfmdJqV0bAvIZx6Mwz: ySHspGNYfmdJqV0bAvIZx6Mwz = ySHspGNYfmdJqV0bAvIZx6Mwz.decode(nV3Tip6XsH1rJw79DPOU)
	lndB4MyFXmN9CjUV3g = W4HCP0bkSsNZlXp()
	lndB4MyFXmN9CjUV3g.create('جلب ملفات M3U جديدة',qpFY4hAwolV3)
	fgVlCuI8wy0znKvp1E5oj9xmD(lndB4MyFXmN9CjUV3g,15,'تنظيف الملف الرئيسي',qpFY4hAwolV3)
	ySHspGNYfmdJqV0bAvIZx6Mwz = ySHspGNYfmdJqV0bAvIZx6Mwz.replace('"tvg-','" tvg-')
	ySHspGNYfmdJqV0bAvIZx6Mwz = ySHspGNYfmdJqV0bAvIZx6Mwz.replace('َ',qpFY4hAwolV3).replace('ً',qpFY4hAwolV3).replace('ُ',qpFY4hAwolV3).replace('ٌ',qpFY4hAwolV3)
	ySHspGNYfmdJqV0bAvIZx6Mwz = ySHspGNYfmdJqV0bAvIZx6Mwz.replace('ّ',qpFY4hAwolV3).replace('ِ',qpFY4hAwolV3).replace('ٍ',qpFY4hAwolV3).replace('ْ',qpFY4hAwolV3)
	ySHspGNYfmdJqV0bAvIZx6Mwz = ySHspGNYfmdJqV0bAvIZx6Mwz.replace('group-title=','group=').replace('tvg-',qpFY4hAwolV3)
	SSxK27Ps5w3R1Y4CnMelB6m8TZXVpc,hVcaD8tkOduIXoWYpPJ37L = [],[]
	ySHspGNYfmdJqV0bAvIZx6Mwz = ySHspGNYfmdJqV0bAvIZx6Mwz.replace(SGUiazdreo6QRKLOWZj5hMX,ZLwoRpfnCWI7FgEHsz6te39lMVh)
	ooW8A4LRvgDeIr0CNO = ePhmG1jLD6.findall('NF:(.+?)'+'#'+'EXTI',ySHspGNYfmdJqV0bAvIZx6Mwz+'\n+'+'#'+'EXTINF:',ePhmG1jLD6.DOTALL)
	if not ooW8A4LRvgDeIr0CNO:
		LLvyStW429DEZKlA(j8gFJIMYPoBzcCvG9T,lTW9p1v7uPfOxB(VwkA0oma2Nf)+'   Folder:'+m4W3gU71on2PF+'  Sequence:'+rrgusv6oweD3tT+'   No video links found in M3U file')
		iG7Rz2kmn0x1yLNMV3u8O(qpFY4hAwolV3,qpFY4hAwolV3,GLTtERWbHnFuy4PCp,'رابط ـM3U الذي أنت أضفته لا توجد فيه فيديوهات .. احتمال رابط ـM3U غير صحيح'+ZLwoRpfnCWI7FgEHsz6te39lMVh+IQ2KCmObsTGuiRdEzt931a40jLg+'مجلد رقم '+m4W3gU71on2PF+'      رابط رقم '+rrgusv6oweD3tT+fF4lt9zWYxXLKZVyAco82PgMj)
		lndB4MyFXmN9CjUV3g.close()
		return
	XGwpuHq0zYi5CKyFEQsg1 = []
	for wYeU08VTvm3fXJ in ooW8A4LRvgDeIr0CNO:
		zLyERd1vMcZFrWNjU4H = wYeU08VTvm3fXJ.lower()
		if 'adult' in zLyERd1vMcZFrWNjU4H: continue
		if 'xxx' in zLyERd1vMcZFrWNjU4H: continue
		XGwpuHq0zYi5CKyFEQsg1.append(wYeU08VTvm3fXJ)
	ooW8A4LRvgDeIr0CNO = XGwpuHq0zYi5CKyFEQsg1
	del XGwpuHq0zYi5CKyFEQsg1
	if 'iptv-org' in GC6JEjSfpxU5OmTaFBrbL:
		XGwpuHq0zYi5CKyFEQsg1,ddpREPKAqy5efZUS4BO = [],[]
		for wYeU08VTvm3fXJ in ooW8A4LRvgDeIr0CNO:
			ZteRaHumGPidbpsf1C = ePhmG1jLD6.findall('group="(.*?)"',wYeU08VTvm3fXJ,ePhmG1jLD6.DOTALL)
			if ZteRaHumGPidbpsf1C:
				ZteRaHumGPidbpsf1C = ZteRaHumGPidbpsf1C[0]
				M4tchvn9eGFgB5xLarYkqmDbJNdHQT = ZteRaHumGPidbpsf1C.split(';')
				if 'region' in GC6JEjSfpxU5OmTaFBrbL: ruvXwe7LiYQcEofF6UpVNMWxgP = '1_'
				elif 'category' in GC6JEjSfpxU5OmTaFBrbL: ruvXwe7LiYQcEofF6UpVNMWxgP = '2_'
				elif 'language' in GC6JEjSfpxU5OmTaFBrbL: ruvXwe7LiYQcEofF6UpVNMWxgP = '3_'
				elif 'country' in GC6JEjSfpxU5OmTaFBrbL: ruvXwe7LiYQcEofF6UpVNMWxgP = '4_'
				else: ruvXwe7LiYQcEofF6UpVNMWxgP = '5_'
				LLFq2AXgoMPEyjiSDhvbc8r436 = wYeU08VTvm3fXJ.replace('group="'+ZteRaHumGPidbpsf1C+'"','group="'+ruvXwe7LiYQcEofF6UpVNMWxgP+'~'+xupTj02bvy3O8R+' ===== ===== ===== '+fF4lt9zWYxXLKZVyAco82PgMj+'"')
				XGwpuHq0zYi5CKyFEQsg1.append(LLFq2AXgoMPEyjiSDhvbc8r436)
				for dW4u3hS9wKCqD6xvIbylR in M4tchvn9eGFgB5xLarYkqmDbJNdHQT:
					LLFq2AXgoMPEyjiSDhvbc8r436 = wYeU08VTvm3fXJ.replace('group="'+ZteRaHumGPidbpsf1C+'"','group="'+ruvXwe7LiYQcEofF6UpVNMWxgP+dW4u3hS9wKCqD6xvIbylR+'"')
					XGwpuHq0zYi5CKyFEQsg1.append(LLFq2AXgoMPEyjiSDhvbc8r436)
			else: XGwpuHq0zYi5CKyFEQsg1.append(wYeU08VTvm3fXJ)
		ooW8A4LRvgDeIr0CNO = XGwpuHq0zYi5CKyFEQsg1
		del XGwpuHq0zYi5CKyFEQsg1,ddpREPKAqy5efZUS4BO
	eedPit7oAxNVXWs5Da4Qp2MISlmwg = 1024*1024
	fTAqPJibv1EZzBXWCuDl5ya6O9HYg = 1+len(ySHspGNYfmdJqV0bAvIZx6Mwz)//eedPit7oAxNVXWs5Da4Qp2MISlmwg//10
	del ySHspGNYfmdJqV0bAvIZx6Mwz
	E49TIBRfyCGJlta1sFPDnhv75SOrwH = len(ooW8A4LRvgDeIr0CNO)
	ddpREPKAqy5efZUS4BO = mG853yUPCJW(ooW8A4LRvgDeIr0CNO,fTAqPJibv1EZzBXWCuDl5ya6O9HYg)
	del ooW8A4LRvgDeIr0CNO
	for av3QBl1coTFsq9jLgydwf in range(fTAqPJibv1EZzBXWCuDl5ya6O9HYg):
		fgVlCuI8wy0znKvp1E5oj9xmD(lndB4MyFXmN9CjUV3g,35+int(5*av3QBl1coTFsq9jLgydwf/fTAqPJibv1EZzBXWCuDl5ya6O9HYg),'تقطيع الملف الرئيسي','الجزء رقم:-',str(av3QBl1coTFsq9jLgydwf+1)+' / '+str(fTAqPJibv1EZzBXWCuDl5ya6O9HYg))
		if lndB4MyFXmN9CjUV3g.iscanceled():
			lndB4MyFXmN9CjUV3g.close()
			return
		Q3SmOx7Eol = str(ddpREPKAqy5efZUS4BO[av3QBl1coTFsq9jLgydwf])
		if DLod2Of8CkRrtzJynev: Q3SmOx7Eol = Q3SmOx7Eol.encode(nV3Tip6XsH1rJw79DPOU)
		open(wV9SCT2earhG+'.00'+str(av3QBl1coTFsq9jLgydwf),'wb').write(Q3SmOx7Eol)
	del ddpREPKAqy5efZUS4BO,Q3SmOx7Eol
	LXUAl0dZ8HVrEz9DmC1Kuv53MWOyI,nSdvk9W5IsZRxTtFlMyw7CEXpe,Il0c1rSN46qmWzJZTks3UteLExn = [],[],0
	for av3QBl1coTFsq9jLgydwf in range(fTAqPJibv1EZzBXWCuDl5ya6O9HYg):
		if lndB4MyFXmN9CjUV3g.iscanceled():
			lndB4MyFXmN9CjUV3g.close()
			return
		Q3SmOx7Eol = open(wV9SCT2earhG+'.00'+str(av3QBl1coTFsq9jLgydwf),'rb').read()
		s7FnXZYOgexlH2MPb8BJck1AKv9.sleep(1)
		try: RPbaxsNFVTwek5Kfv21DiJuzCnjMZp.remove(wV9SCT2earhG+'.00'+str(av3QBl1coTFsq9jLgydwf))
		except: pass
		if DLod2Of8CkRrtzJynev: Q3SmOx7Eol = Q3SmOx7Eol.decode(nV3Tip6XsH1rJw79DPOU)
		pQ8Nzwj29WdUDtBTh = wB8NUAidPbqjIr9CFasXvYnxOQpL0g('list',Q3SmOx7Eol)
		del Q3SmOx7Eol
		LUejlIa7XQWtrik21xfFMAGYwEp4y,Il0c1rSN46qmWzJZTks3UteLExn,q96MucKzm87aopEb = iYvF5Ml1sjV3f7J4(pQ8Nzwj29WdUDtBTh,hVcaD8tkOduIXoWYpPJ37L,SSxK27Ps5w3R1Y4CnMelB6m8TZXVpc,lndB4MyFXmN9CjUV3g,E49TIBRfyCGJlta1sFPDnhv75SOrwH,Il0c1rSN46qmWzJZTks3UteLExn,GC6JEjSfpxU5OmTaFBrbL)
		if lndB4MyFXmN9CjUV3g.iscanceled():
			lndB4MyFXmN9CjUV3g.close()
			return
		if not LUejlIa7XQWtrik21xfFMAGYwEp4y:
			lndB4MyFXmN9CjUV3g.close()
			return
		nSdvk9W5IsZRxTtFlMyw7CEXpe += LUejlIa7XQWtrik21xfFMAGYwEp4y
		LXUAl0dZ8HVrEz9DmC1Kuv53MWOyI += q96MucKzm87aopEb
	del pQ8Nzwj29WdUDtBTh,LUejlIa7XQWtrik21xfFMAGYwEp4y
	gqi6dfmFMp4aeu5jDrSz1ny7QsW,q96MucKzm87aopEb = UBExO375Z6WQiuF(nSdvk9W5IsZRxTtFlMyw7CEXpe,lndB4MyFXmN9CjUV3g,rrgusv6oweD3tT)
	if lndB4MyFXmN9CjUV3g.iscanceled():
		lndB4MyFXmN9CjUV3g.close()
		return
	LXUAl0dZ8HVrEz9DmC1Kuv53MWOyI += q96MucKzm87aopEb
	del nSdvk9W5IsZRxTtFlMyw7CEXpe,q96MucKzm87aopEb
	w2n4cuRIMVU37Af1Zl,tbCJirHuVPxLA20hM,ZteRaHumGPidbpsf1C,jJWoA3SLya,CCBfSVIQ3t9EuMos = {},{},{},0,0
	pIDwuzh9UGHAoZn2M58KQcLtdBFm = list(gqi6dfmFMp4aeu5jDrSz1ny7QsW.keys())
	I2jYgyCTA3KBuM6VedEips = len(pIDwuzh9UGHAoZn2M58KQcLtdBFm)*3
	if 1:
		qqQ8sTZ5BaCOKxGPblkzvwcnEgfYe = {}
		for muKG29tPNiTYQJMxkpl87CbLwXSV0 in pIDwuzh9UGHAoZn2M58KQcLtdBFm:
			qqQ8sTZ5BaCOKxGPblkzvwcnEgfYe[muKG29tPNiTYQJMxkpl87CbLwXSV0] = MqWf2atLi7QDnOF0YKuZhrE53gbv1(daemon=gBExoceumj4y8bFW9hY2aNMVSr,target=ZHKpFedjLvNuh,args=(muKG29tPNiTYQJMxkpl87CbLwXSV0,))
			qqQ8sTZ5BaCOKxGPblkzvwcnEgfYe[muKG29tPNiTYQJMxkpl87CbLwXSV0].start()
		for muKG29tPNiTYQJMxkpl87CbLwXSV0 in pIDwuzh9UGHAoZn2M58KQcLtdBFm:
			qqQ8sTZ5BaCOKxGPblkzvwcnEgfYe[muKG29tPNiTYQJMxkpl87CbLwXSV0].join()
		if lndB4MyFXmN9CjUV3g.iscanceled():
			lndB4MyFXmN9CjUV3g.close()
			return
	else:
		for muKG29tPNiTYQJMxkpl87CbLwXSV0 in pIDwuzh9UGHAoZn2M58KQcLtdBFm:
			ZHKpFedjLvNuh(muKG29tPNiTYQJMxkpl87CbLwXSV0)
			if lndB4MyFXmN9CjUV3g.iscanceled():
				lndB4MyFXmN9CjUV3g.close()
				return
	sVYc0z8LbRf7nrj4NJUmEkQ(m4W3gU71on2PF,rrgusv6oweD3tT,False)
	pIDwuzh9UGHAoZn2M58KQcLtdBFm = list(w2n4cuRIMVU37Af1Zl.keys())
	HfDhSC8Rueq5s = 0
	if 1:
		qqQ8sTZ5BaCOKxGPblkzvwcnEgfYe = {}
		for muKG29tPNiTYQJMxkpl87CbLwXSV0 in pIDwuzh9UGHAoZn2M58KQcLtdBFm:
			qqQ8sTZ5BaCOKxGPblkzvwcnEgfYe[muKG29tPNiTYQJMxkpl87CbLwXSV0] = MqWf2atLi7QDnOF0YKuZhrE53gbv1(daemon=gBExoceumj4y8bFW9hY2aNMVSr,target=HzxsiCym94ETcNDka2UZ5F,args=(m4W3gU71on2PF,muKG29tPNiTYQJMxkpl87CbLwXSV0))
			qqQ8sTZ5BaCOKxGPblkzvwcnEgfYe[muKG29tPNiTYQJMxkpl87CbLwXSV0].start()
		for muKG29tPNiTYQJMxkpl87CbLwXSV0 in pIDwuzh9UGHAoZn2M58KQcLtdBFm:
			qqQ8sTZ5BaCOKxGPblkzvwcnEgfYe[muKG29tPNiTYQJMxkpl87CbLwXSV0].join()
		if lndB4MyFXmN9CjUV3g.iscanceled():
			lndB4MyFXmN9CjUV3g.close()
			return
	else:
		for muKG29tPNiTYQJMxkpl87CbLwXSV0 in pIDwuzh9UGHAoZn2M58KQcLtdBFm:
			HzxsiCym94ETcNDka2UZ5F(m4W3gU71on2PF,muKG29tPNiTYQJMxkpl87CbLwXSV0)
			if lndB4MyFXmN9CjUV3g.iscanceled():
				lndB4MyFXmN9CjUV3g.close()
				return
	av3QBl1coTFsq9jLgydwf = 0
	YpkrtaNixI8QZu9 = len(LXUAl0dZ8HVrEz9DmC1Kuv53MWOyI)
	LeuKy7JsdxW = PPlUAWKhqTdmnfwLrcYxDS8(m4W3gU71on2PF,'IGNORED')
	for iibIF5yUZjQuPWBH2TltMGL3qd in LXUAl0dZ8HVrEz9DmC1Kuv53MWOyI:
		if av3QBl1coTFsq9jLgydwf%27==0:
			fgVlCuI8wy0znKvp1E5oj9xmD(lndB4MyFXmN9CjUV3g,95+int(5*av3QBl1coTFsq9jLgydwf//YpkrtaNixI8QZu9),'تخزين المهملة','الفيديو رقم:-',str(av3QBl1coTFsq9jLgydwf)+' / '+str(YpkrtaNixI8QZu9))
			if lndB4MyFXmN9CjUV3g.iscanceled():
				lndB4MyFXmN9CjUV3g.close()
				return
		zOYMaQ0NgdiRVwDJXh8e(LeuKy7JsdxW,'IGNORED_'+rrgusv6oweD3tT,str(iibIF5yUZjQuPWBH2TltMGL3qd),qpFY4hAwolV3,ivLg9zRnGF83u)
		av3QBl1coTFsq9jLgydwf += 1
	zOYMaQ0NgdiRVwDJXh8e(LeuKy7JsdxW,'IGNORED_'+rrgusv6oweD3tT,'__COUNT__',str(YpkrtaNixI8QZu9),ivLg9zRnGF83u)
	lndB4MyFXmN9CjUV3g.close()
	s7FnXZYOgexlH2MPb8BJck1AKv9.sleep(1)
	sGN5rVnhIaTqz14FPdki(m4W3gU71on2PF)
	return
def ZHKpFedjLvNuh(muKG29tPNiTYQJMxkpl87CbLwXSV0):
	global lndB4MyFXmN9CjUV3g,gqi6dfmFMp4aeu5jDrSz1ny7QsW,HfDhSC8Rueq5s,w2n4cuRIMVU37Af1Zl,tbCJirHuVPxLA20hM,ZteRaHumGPidbpsf1C,jJWoA3SLya,CCBfSVIQ3t9EuMos,I2jYgyCTA3KBuM6VedEips
	w2n4cuRIMVU37Af1Zl[muKG29tPNiTYQJMxkpl87CbLwXSV0] = {}
	KXdTf9jsStMvuGFUDHqo5yblx1m,d56JqyOjIm41a = {},[]
	EE5xks1brlOUCH = len(gqi6dfmFMp4aeu5jDrSz1ny7QsW[muKG29tPNiTYQJMxkpl87CbLwXSV0])
	w2n4cuRIMVU37Af1Zl[muKG29tPNiTYQJMxkpl87CbLwXSV0]['__COUNT__'] = EE5xks1brlOUCH
	if EE5xks1brlOUCH>0:
		jkTGy1zAcb94lNVRUF72XvDwugdxO0,iI03aPf6YoRUNGOeLVq,lD8S5rkgYPFNU6Ia1M,vN2Rdz1sKxZQcbkuShOg8B,AAD6JGFR1UcOpm4thqgsw9HP = zip(*gqi6dfmFMp4aeu5jDrSz1ny7QsW[muKG29tPNiTYQJMxkpl87CbLwXSV0])
		del iI03aPf6YoRUNGOeLVq,lD8S5rkgYPFNU6Ia1M,vN2Rdz1sKxZQcbkuShOg8B
		M4tchvn9eGFgB5xLarYkqmDbJNdHQT = list(set(jkTGy1zAcb94lNVRUF72XvDwugdxO0))
		for dW4u3hS9wKCqD6xvIbylR in M4tchvn9eGFgB5xLarYkqmDbJNdHQT:
			KXdTf9jsStMvuGFUDHqo5yblx1m[dW4u3hS9wKCqD6xvIbylR] = qpFY4hAwolV3
			w2n4cuRIMVU37Af1Zl[muKG29tPNiTYQJMxkpl87CbLwXSV0][dW4u3hS9wKCqD6xvIbylR] = []
		fgVlCuI8wy0znKvp1E5oj9xmD(lndB4MyFXmN9CjUV3g,60+int(15*CCBfSVIQ3t9EuMos//I2jYgyCTA3KBuM6VedEips),'تصنيع القوائم','الجزء رقم:-',str(CCBfSVIQ3t9EuMos)+' / '+str(I2jYgyCTA3KBuM6VedEips))
		if lndB4MyFXmN9CjUV3g.iscanceled(): return
		CCBfSVIQ3t9EuMos += 1
		m81OkdXrNDEHsJnCov0pZbjUShP = len(M4tchvn9eGFgB5xLarYkqmDbJNdHQT)
		del M4tchvn9eGFgB5xLarYkqmDbJNdHQT
		d56JqyOjIm41a = list(set(zip(jkTGy1zAcb94lNVRUF72XvDwugdxO0,AAD6JGFR1UcOpm4thqgsw9HP)))
		del jkTGy1zAcb94lNVRUF72XvDwugdxO0,AAD6JGFR1UcOpm4thqgsw9HP
		for dW4u3hS9wKCqD6xvIbylR,xCei3u0k2rAVK9o7zQcdZaGXT in d56JqyOjIm41a:
			if not KXdTf9jsStMvuGFUDHqo5yblx1m[dW4u3hS9wKCqD6xvIbylR] and xCei3u0k2rAVK9o7zQcdZaGXT: KXdTf9jsStMvuGFUDHqo5yblx1m[dW4u3hS9wKCqD6xvIbylR] = xCei3u0k2rAVK9o7zQcdZaGXT
		fgVlCuI8wy0znKvp1E5oj9xmD(lndB4MyFXmN9CjUV3g,60+int(15*CCBfSVIQ3t9EuMos//I2jYgyCTA3KBuM6VedEips),'تصنيع القوائم','الجزء رقم:-',str(CCBfSVIQ3t9EuMos)+' / '+str(I2jYgyCTA3KBuM6VedEips))
		if lndB4MyFXmN9CjUV3g.iscanceled(): return
		CCBfSVIQ3t9EuMos += 1
		z7YVwGhP08 = list(KXdTf9jsStMvuGFUDHqo5yblx1m.keys())
		w79voRpa2hkOJG = list(KXdTf9jsStMvuGFUDHqo5yblx1m.values())
		del KXdTf9jsStMvuGFUDHqo5yblx1m
		d56JqyOjIm41a = list(zip(z7YVwGhP08,w79voRpa2hkOJG))
		del z7YVwGhP08,w79voRpa2hkOJG
		d56JqyOjIm41a = sorted(d56JqyOjIm41a)
	else: CCBfSVIQ3t9EuMos += 2
	w2n4cuRIMVU37Af1Zl[muKG29tPNiTYQJMxkpl87CbLwXSV0]['__GROUPS__'] = d56JqyOjIm41a
	del d56JqyOjIm41a
	for dW4u3hS9wKCqD6xvIbylR,fdD0wQgTuni,zaDq3igbdyhsSnRcxoQ7uYPkl,WWowRmHkj1ZAO2SUhtNvdrcKa9E6C,xNF9bfr3tm in gqi6dfmFMp4aeu5jDrSz1ny7QsW[muKG29tPNiTYQJMxkpl87CbLwXSV0]:
		w2n4cuRIMVU37Af1Zl[muKG29tPNiTYQJMxkpl87CbLwXSV0][dW4u3hS9wKCqD6xvIbylR].append((fdD0wQgTuni,zaDq3igbdyhsSnRcxoQ7uYPkl,WWowRmHkj1ZAO2SUhtNvdrcKa9E6C,xNF9bfr3tm))
	fgVlCuI8wy0znKvp1E5oj9xmD(lndB4MyFXmN9CjUV3g,60+int(15*CCBfSVIQ3t9EuMos//I2jYgyCTA3KBuM6VedEips),'تصنيع القوائم','الجزء رقم:-',str(CCBfSVIQ3t9EuMos)+' / '+str(I2jYgyCTA3KBuM6VedEips))
	if lndB4MyFXmN9CjUV3g.iscanceled(): return
	CCBfSVIQ3t9EuMos += 1
	del gqi6dfmFMp4aeu5jDrSz1ny7QsW[muKG29tPNiTYQJMxkpl87CbLwXSV0]
	ZteRaHumGPidbpsf1C[muKG29tPNiTYQJMxkpl87CbLwXSV0] = list(w2n4cuRIMVU37Af1Zl[muKG29tPNiTYQJMxkpl87CbLwXSV0].keys())
	tbCJirHuVPxLA20hM[muKG29tPNiTYQJMxkpl87CbLwXSV0] = len(ZteRaHumGPidbpsf1C[muKG29tPNiTYQJMxkpl87CbLwXSV0])
	jJWoA3SLya += tbCJirHuVPxLA20hM[muKG29tPNiTYQJMxkpl87CbLwXSV0]
	return
def HzxsiCym94ETcNDka2UZ5F(m4W3gU71on2PF,muKG29tPNiTYQJMxkpl87CbLwXSV0):
	global lndB4MyFXmN9CjUV3g,gqi6dfmFMp4aeu5jDrSz1ny7QsW,HfDhSC8Rueq5s,w2n4cuRIMVU37Af1Zl,tbCJirHuVPxLA20hM,ZteRaHumGPidbpsf1C,jJWoA3SLya,CCBfSVIQ3t9EuMos,I2jYgyCTA3KBuM6VedEips
	LeuKy7JsdxW = PPlUAWKhqTdmnfwLrcYxDS8(m4W3gU71on2PF,muKG29tPNiTYQJMxkpl87CbLwXSV0)
	for Il0c1rSN46qmWzJZTks3UteLExn in range(1+tbCJirHuVPxLA20hM[muKG29tPNiTYQJMxkpl87CbLwXSV0]//273):
		nuhP7paEBIiZo4twqfJ = []
		NKLCe0BFt9cZu7PHmSw1oQhzyU5fq = ZteRaHumGPidbpsf1C[muKG29tPNiTYQJMxkpl87CbLwXSV0][0:273]
		for dW4u3hS9wKCqD6xvIbylR in NKLCe0BFt9cZu7PHmSw1oQhzyU5fq:
			nuhP7paEBIiZo4twqfJ.append(w2n4cuRIMVU37Af1Zl[muKG29tPNiTYQJMxkpl87CbLwXSV0][dW4u3hS9wKCqD6xvIbylR])
		zOYMaQ0NgdiRVwDJXh8e(LeuKy7JsdxW,muKG29tPNiTYQJMxkpl87CbLwXSV0,NKLCe0BFt9cZu7PHmSw1oQhzyU5fq,nuhP7paEBIiZo4twqfJ,ivLg9zRnGF83u,True)
		HfDhSC8Rueq5s += len(NKLCe0BFt9cZu7PHmSw1oQhzyU5fq)
		fgVlCuI8wy0znKvp1E5oj9xmD(lndB4MyFXmN9CjUV3g,75+int(20*HfDhSC8Rueq5s//jJWoA3SLya),'تخزين القوائم','القائمة رقم:-',str(HfDhSC8Rueq5s)+' / '+str(jJWoA3SLya))
		if lndB4MyFXmN9CjUV3g.iscanceled(): return
		del ZteRaHumGPidbpsf1C[muKG29tPNiTYQJMxkpl87CbLwXSV0][0:273]
	del w2n4cuRIMVU37Af1Zl[muKG29tPNiTYQJMxkpl87CbLwXSV0],ZteRaHumGPidbpsf1C[muKG29tPNiTYQJMxkpl87CbLwXSV0],tbCJirHuVPxLA20hM[muKG29tPNiTYQJMxkpl87CbLwXSV0]
	return
def fflBH1UhzSIKN(m4W3gU71on2PF,rrgusv6oweD3tT,kcmbnMYF2WpDg0ti4UyCf3AV=True):
	V5H3lkO74n8Ci09uEPfyMYKW = 'عدد فيديوهات جميع الروابط'
	TayBusQohi5qdXWRVzI34JSDgNeE = PPlUAWKhqTdmnfwLrcYxDS8(m4W3gU71on2PF,'LIVE_ORIGINAL_GROUPED')
	EEOuefLodKxyaJ56ZbGjqA = PPlUAWKhqTdmnfwLrcYxDS8(m4W3gU71on2PF,'VOD_ORIGINAL_GROUPED')
	if rrgusv6oweD3tT:
		V5H3lkO74n8Ci09uEPfyMYKW = 'عدد فيديوهات رابط '+ppn5vq8QdBsEhckl[int(rrgusv6oweD3tT)]
		rrgusv6oweD3tT = '_'+rrgusv6oweD3tT
	YpkrtaNixI8QZu9 = XXyMBNAVJvKiq7jc20bEw6(TayBusQohi5qdXWRVzI34JSDgNeE,'int','IGNORED'+rrgusv6oweD3tT,'__COUNT__')
	U9WZkjSKFqo52iJQEmH8etdn4AsV = XXyMBNAVJvKiq7jc20bEw6(TayBusQohi5qdXWRVzI34JSDgNeE,'int','LIVE_ORIGINAL_GROUPED'+rrgusv6oweD3tT,'__COUNT__')
	KYpHjLhiPXANqBeVO = XXyMBNAVJvKiq7jc20bEw6(EEOuefLodKxyaJ56ZbGjqA,'int','VOD_ORIGINAL_GROUPED'+rrgusv6oweD3tT,'__COUNT__')
	rFlU0Kw1nb7js3xRoQBytAuTiH8V46 = XXyMBNAVJvKiq7jc20bEw6(TayBusQohi5qdXWRVzI34JSDgNeE,'int','LIVE_GROUPED'+rrgusv6oweD3tT,'__COUNT__')
	ofc8wS6liJKqjbkB5FNTaxXpAvR = XXyMBNAVJvKiq7jc20bEw6(TayBusQohi5qdXWRVzI34JSDgNeE,'int','LIVE_UNKNOWN_GROUPED'+rrgusv6oweD3tT,'__COUNT__')
	nNEqba4iQrseVvgCPGRZzILXkMo1T7 = XXyMBNAVJvKiq7jc20bEw6(TayBusQohi5qdXWRVzI34JSDgNeE,'int','VOD_MOVIES_GROUPED'+rrgusv6oweD3tT,'__COUNT__')
	s9xnYXrh8io = XXyMBNAVJvKiq7jc20bEw6(EEOuefLodKxyaJ56ZbGjqA,'int','VOD_SERIES_GROUPED'+rrgusv6oweD3tT,'__COUNT__')
	pHM9KmgC7D8jP0Vr = XXyMBNAVJvKiq7jc20bEw6(TayBusQohi5qdXWRVzI34JSDgNeE,'int','VOD_UNKNOWN_GROUPED'+rrgusv6oweD3tT,'__COUNT__')
	ZteRaHumGPidbpsf1C = XXyMBNAVJvKiq7jc20bEw6(EEOuefLodKxyaJ56ZbGjqA,'list','VOD_SERIES_GROUPED'+rrgusv6oweD3tT,'__GROUPS__')
	ARcdkJFw1oSMiKlX9CpNsrzH = []
	for dW4u3hS9wKCqD6xvIbylR,xNF9bfr3tm in ZteRaHumGPidbpsf1C:
		jElOeu4yVSHg6 = dW4u3hS9wKCqD6xvIbylR.split('__SERIES__')[1]
		ARcdkJFw1oSMiKlX9CpNsrzH.append(jElOeu4yVSHg6)
	rbcFyoXAvTlp1x5MCW = len(ARcdkJFw1oSMiKlX9CpNsrzH)
	PT7f3Zk6WgXY = int(nNEqba4iQrseVvgCPGRZzILXkMo1T7)+int(s9xnYXrh8io)+int(pHM9KmgC7D8jP0Vr)+int(ofc8wS6liJKqjbkB5FNTaxXpAvR)+int(rFlU0Kw1nb7js3xRoQBytAuTiH8V46)
	U36sYteOgkXlp7DdEBioaQMTmrR = qpFY4hAwolV3
	U36sYteOgkXlp7DdEBioaQMTmrR += 'قنوات: '+str(rFlU0Kw1nb7js3xRoQBytAuTiH8V46)
	U36sYteOgkXlp7DdEBioaQMTmrR += '   .   أفلام: '+str(nNEqba4iQrseVvgCPGRZzILXkMo1T7)
	U36sYteOgkXlp7DdEBioaQMTmrR += '\nمسلسلات: '+str(rbcFyoXAvTlp1x5MCW)
	U36sYteOgkXlp7DdEBioaQMTmrR += '   .   حلقات: '+str(s9xnYXrh8io)
	U36sYteOgkXlp7DdEBioaQMTmrR += '\nقنوات مجهولة: '+str(ofc8wS6liJKqjbkB5FNTaxXpAvR)
	U36sYteOgkXlp7DdEBioaQMTmrR += '   .   فيدوهات مجهولة: '+str(pHM9KmgC7D8jP0Vr)
	U36sYteOgkXlp7DdEBioaQMTmrR += '\nمجموع القنوات: '+str(U9WZkjSKFqo52iJQEmH8etdn4AsV)
	U36sYteOgkXlp7DdEBioaQMTmrR += '   .   مجموع الفيديوهات: '+str(KYpHjLhiPXANqBeVO)
	U36sYteOgkXlp7DdEBioaQMTmrR += '\n\nمجموع المضافة: '+str(PT7f3Zk6WgXY)
	U36sYteOgkXlp7DdEBioaQMTmrR += '   .   مجموع المهملة: '+str(YpkrtaNixI8QZu9)
	if kcmbnMYF2WpDg0ti4UyCf3AV: iG7Rz2kmn0x1yLNMV3u8O('center',qpFY4hAwolV3,V5H3lkO74n8Ci09uEPfyMYKW,U36sYteOgkXlp7DdEBioaQMTmrR)
	uu9onmyXVlqTpKdL28DNM3WF4PvegA = U36sYteOgkXlp7DdEBioaQMTmrR.replace('\n\n',ZLwoRpfnCWI7FgEHsz6te39lMVh)
	if not rrgusv6oweD3tT: rrgusv6oweD3tT = 'All'
	else: rrgusv6oweD3tT = rrgusv6oweD3tT[1]
	LLvyStW429DEZKlA(k8kdUSxohLVljnrY,'.\tCounts of M3U videos   Folder: '+m4W3gU71on2PF+'   Sequence: '+rrgusv6oweD3tT+ZLwoRpfnCWI7FgEHsz6te39lMVh+uu9onmyXVlqTpKdL28DNM3WF4PvegA)
	return U36sYteOgkXlp7DdEBioaQMTmrR
def sVYc0z8LbRf7nrj4NJUmEkQ(m4W3gU71on2PF,rrgusv6oweD3tT,kcmbnMYF2WpDg0ti4UyCf3AV=True):
	if kcmbnMYF2WpDg0ti4UyCf3AV:
		fN4Cnx6kjp = VVpbtSKYUGXrNMwAWFo9IOjZP('center',qpFY4hAwolV3,qpFY4hAwolV3,'مسح ملفات M3U','هل تريد مسح الملفات القديمة المخزنة في البرنامج ؟! \n\n علما انك تستطيع في أي وقت الدخول إلى قائمة M3U وجلب ملفات M3U جديدة')
		if fN4Cnx6kjp!=1: return
		ESqRDuntjYZFBO2oXVkGQfNa = v3DXdfGq7VeBh9ousFNOw8yrkEM1n.replace('___','_'+m4W3gU71on2PF+'_'+rrgusv6oweD3tT)
		try: RPbaxsNFVTwek5Kfv21DiJuzCnjMZp.remove(ESqRDuntjYZFBO2oXVkGQfNa)
		except: pass
	LeuKy7JsdxW = PPlUAWKhqTdmnfwLrcYxDS8(m4W3gU71on2PF,qpFY4hAwolV3)
	if rrgusv6oweD3tT:
		VYi9cdMGpAtkFajoTL3O5PwWZ6b = []
		for jyrOTw46WtNHXA in Va04phzWlCG:
			VYi9cdMGpAtkFajoTL3O5PwWZ6b.append(jyrOTw46WtNHXA+'_'+rrgusv6oweD3tT)
		mlykPoGXbJIjFnarp9KihxfN(LeuKy7JsdxW,'LINK_'+rrgusv6oweD3tT)
	else:
		VYi9cdMGpAtkFajoTL3O5PwWZ6b = Va04phzWlCG
		mlykPoGXbJIjFnarp9KihxfN(LeuKy7JsdxW,'DUMMY')
		mlykPoGXbJIjFnarp9KihxfN(LeuKy7JsdxW,'GROUPS')
		mlykPoGXbJIjFnarp9KihxfN(LeuKy7JsdxW,'ITEMS')
		mlykPoGXbJIjFnarp9KihxfN(LeuKy7JsdxW,'SEARCH')
	mlykPoGXbJIjFnarp9KihxfN(WoFsvbmUlDZp7PzRfdGknCV,'SECTIONS_M3U','SECTIONS_M3U_'+m4W3gU71on2PF)
	mlykPoGXbJIjFnarp9KihxfN(WoFsvbmUlDZp7PzRfdGknCV,'SECTIONS_M3U','SECTIONS_M3U_ALL')
	for muKG29tPNiTYQJMxkpl87CbLwXSV0 in VYi9cdMGpAtkFajoTL3O5PwWZ6b:
		mlykPoGXbJIjFnarp9KihxfN(LeuKy7JsdxW,muKG29tPNiTYQJMxkpl87CbLwXSV0)
	PAfd3TnXb2oz(False)
	sGN5rVnhIaTqz14FPdki(m4W3gU71on2PF)
	if kcmbnMYF2WpDg0ti4UyCf3AV: iG7Rz2kmn0x1yLNMV3u8O(qpFY4hAwolV3,qpFY4hAwolV3,GLTtERWbHnFuy4PCp,'تم مسح جميع ملفات ـM3U')
	return
def N4mtgDP83waX9(m4W3gU71on2PF=qpFY4hAwolV3,kcmbnMYF2WpDg0ti4UyCf3AV=True):
	if m4W3gU71on2PF:
		LeuKy7JsdxW = PPlUAWKhqTdmnfwLrcYxDS8(str(m4W3gU71on2PF),'DUMMY')
		mv9MSqEQYLU2cW8tklbKZzO = XXyMBNAVJvKiq7jc20bEw6(LeuKy7JsdxW,'str','DUMMY','__DUMMY__')
		if mv9MSqEQYLU2cW8tklbKZzO: return True
	else:
		m4W3gU71on2PF = '1'
		for s2lOfK1TeCx in range(1,v2ir6R7FZASfMOl4wqTLKBNupX5E+1):
			LeuKy7JsdxW = PPlUAWKhqTdmnfwLrcYxDS8(str(s2lOfK1TeCx),'DUMMY')
			mv9MSqEQYLU2cW8tklbKZzO = XXyMBNAVJvKiq7jc20bEw6(LeuKy7JsdxW,'str','DUMMY','__DUMMY__')
			if mv9MSqEQYLU2cW8tklbKZzO: return True
	if kcmbnMYF2WpDg0ti4UyCf3AV:
		NvOh5wIkFpxaD9XmGQsu8eC7Ho = 'https://iptv-org.github.io/iptv/index.category.m3u'
		X9UPejJYStRZI7lwG1 = 'https://iptv-org.github.io/iptv/index.language.m3u'
		ukiCZe5VRvDIcpLBPJS = 'https://iptv-org.github.io/iptv/index.country.m3u'
		CCPQZvSNoemnXRd8sq4 = NvOh5wIkFpxaD9XmGQsu8eC7Ho+ZLwoRpfnCWI7FgEHsz6te39lMVh+X9UPejJYStRZI7lwG1+ZLwoRpfnCWI7FgEHsz6te39lMVh+ukiCZe5VRvDIcpLBPJS
		fN4Cnx6kjp = VVpbtSKYUGXrNMwAWFo9IOjZP(qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,GLTtERWbHnFuy4PCp,'هذه القوائم تحتاج رابط فيديوهات نوعه M3U . وهو متوفر في الإنترنت مجانا . وأيضا تبيعه الشركات المختصة . الموقع أدناه فيه روابط مجانية وهي ليست ملك المبرمج (صاحب هذا البرنامج) . ولا علاقة للمبرمج بمحتوياتها . والمبرمج لا يتحمل أي مسؤولية بسبب استخدام روابط مجانية أو غير مجانية\n'+xupTj02bvy3O8R+'http://github.com/iptv-org/iptv'+fF4lt9zWYxXLKZVyAco82PgMj+'\nالروابط أدناه مجانية ومأخوذة من الموقع أعلاه هل تريد استخدامها\n '+xupTj02bvy3O8R+CCPQZvSNoemnXRd8sq4+fF4lt9zWYxXLKZVyAco82PgMj,profile='confirm_smallfont')
		if fN4Cnx6kjp==1:
			gdPslyFW8ITBcpA302.setSetting('av.m3u.url_'+str(m4W3gU71on2PF)+'_1',NvOh5wIkFpxaD9XmGQsu8eC7Ho)
			gdPslyFW8ITBcpA302.setSetting('av.m3u.url_'+str(m4W3gU71on2PF)+'_2',X9UPejJYStRZI7lwG1)
			gdPslyFW8ITBcpA302.setSetting('av.m3u.url_'+str(m4W3gU71on2PF)+'_3',ukiCZe5VRvDIcpLBPJS)
			fN4Cnx6kjp = VVpbtSKYUGXrNMwAWFo9IOjZP(qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,GLTtERWbHnFuy4PCp,'للاستفادة من روابط M3U التي أنت أضفتها للبرنامج .. أنت بحاجة إلى جلب ملفات هذه الروابط الجديدة .. هل تريد الآن جلب ملفات روابط M3U التي أنت أضفتها للبرنامج ؟!')
			if fN4Cnx6kjp==1:
				A9V6YO2CohGbULQ4X = bzdJ7qHRfEuKghjnNwD04MPYa(m4W3gU71on2PF)
				return A9V6YO2CohGbULQ4X
		else:
			V5H3lkO74n8Ci09uEPfyMYKW = 'إضافة وتغيير رابط '+ppn5vq8QdBsEhckl[1]+' (مجلد '+ppn5vq8QdBsEhckl[int(m4W3gU71on2PF)]+')'
			fN4Cnx6kjp = VVpbtSKYUGXrNMwAWFo9IOjZP(qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,V5H3lkO74n8Ci09uEPfyMYKW,'لإضافة رابط M3U .. أولا أفتح قائمة M3U .. ثانيا أنقر على إضافة رابط أو اشتراك M3U .. ثالثا أنقر على جلب ملفات ـM3U \n\n هل تريد إضافة أو تغيير رابط M3U الآن ؟!')
			if fN4Cnx6kjp==1: aF2eXlORwA5Dr(m4W3gU71on2PF,'1')
	return False
def DpkVswXMr9iWB0OPAYqFNaK7(SCgJ4Lio6WFs,m4W3gU71on2PF=qpFY4hAwolV3,muKG29tPNiTYQJMxkpl87CbLwXSV0=qpFY4hAwolV3,tPH05EC8L6cYqTX4xIUurnjk1MOG=qpFY4hAwolV3):
	if not tPH05EC8L6cYqTX4xIUurnjk1MOG: tPH05EC8L6cYqTX4xIUurnjk1MOG = '1'
	v9hig4t8jT,ZZCk6FGHRa8,kcmbnMYF2WpDg0ti4UyCf3AV = LLm3sBXHPcnTDxdE5gt6hz0Wkp(SCgJ4Lio6WFs)
	if not N4mtgDP83waX9(m4W3gU71on2PF,kcmbnMYF2WpDg0ti4UyCf3AV): return
	if not v9hig4t8jT:
		v9hig4t8jT = jXgARlWMLVFUBnvmZwI2o5()
		if not v9hig4t8jT: return
	tClLJ8cm5vAsFT0hx2kKYPME7O9 = [qpFY4hAwolV3,'LIVE_GROUPED_SORTED','VOD_MOVIES_GROUPED_SORTED','VOD_SERIES_GROUPED_SORTED','VOD_UNKNOWN_GROUPED_SORTED','LIVE_UNKNOWN_GROUPED_SORTED']
	if not muKG29tPNiTYQJMxkpl87CbLwXSV0:
		if not kcmbnMYF2WpDg0ti4UyCf3AV:
			if   '_M3U-LIVE_' in ZZCk6FGHRa8: muKG29tPNiTYQJMxkpl87CbLwXSV0 = tClLJ8cm5vAsFT0hx2kKYPME7O9[1]
			elif '_M3U-MOVIES' in ZZCk6FGHRa8: muKG29tPNiTYQJMxkpl87CbLwXSV0 = tClLJ8cm5vAsFT0hx2kKYPME7O9[2]
			elif '_M3U-SERIES' in ZZCk6FGHRa8: muKG29tPNiTYQJMxkpl87CbLwXSV0 = tClLJ8cm5vAsFT0hx2kKYPME7O9[3]
			else: muKG29tPNiTYQJMxkpl87CbLwXSV0 = tClLJ8cm5vAsFT0hx2kKYPME7O9[0]
		else:
			J5XbwseKOm = ['الكل','قنوات','أفلام','مسلسلات','فيديوهات مجهولة','قنوات مجهولة']
			r7MXibnK2fa6S31ctA = xVzqWbrFXJ('أختر البحث المناسب', J5XbwseKOm)
			if r7MXibnK2fa6S31ctA==-1: return
			muKG29tPNiTYQJMxkpl87CbLwXSV0 = tClLJ8cm5vAsFT0hx2kKYPME7O9[r7MXibnK2fa6S31ctA]
	v9hig4t8jT = v9hig4t8jT+'_NODIALOGS_'
	if m4W3gU71on2PF: N1aBfRWYkGAK(v9hig4t8jT,m4W3gU71on2PF,muKG29tPNiTYQJMxkpl87CbLwXSV0,tPH05EC8L6cYqTX4xIUurnjk1MOG)
	else:
		for m4W3gU71on2PF in range(1,v2ir6R7FZASfMOl4wqTLKBNupX5E+1):
			N1aBfRWYkGAK(v9hig4t8jT,str(m4W3gU71on2PF),muKG29tPNiTYQJMxkpl87CbLwXSV0,tPH05EC8L6cYqTX4xIUurnjk1MOG)
		i4bFG3rKE6.menuItemsLIST[:] = sorted(i4bFG3rKE6.menuItemsLIST,reverse=False,key=lambda f79ZnTkH0m45a1vj63xuQSd: f79ZnTkH0m45a1vj63xuQSd[1].lower())
	return
def N1aBfRWYkGAK(SCgJ4Lio6WFs,m4W3gU71on2PF,muKG29tPNiTYQJMxkpl87CbLwXSV0=qpFY4hAwolV3,tPH05EC8L6cYqTX4xIUurnjk1MOG=qpFY4hAwolV3):
	if not tPH05EC8L6cYqTX4xIUurnjk1MOG: tPH05EC8L6cYqTX4xIUurnjk1MOG = '1'
	v9hig4t8jT,ZZCk6FGHRa8,kcmbnMYF2WpDg0ti4UyCf3AV = LLm3sBXHPcnTDxdE5gt6hz0Wkp(SCgJ4Lio6WFs)
	if not m4W3gU71on2PF: return
	if not N4mtgDP83waX9(m4W3gU71on2PF,kcmbnMYF2WpDg0ti4UyCf3AV): return
	if not v9hig4t8jT:
		v9hig4t8jT = jXgARlWMLVFUBnvmZwI2o5()
		if not v9hig4t8jT: return
	tClLJ8cm5vAsFT0hx2kKYPME7O9 = [qpFY4hAwolV3,'LIVE_GROUPED_SORTED','VOD_MOVIES_GROUPED_SORTED','VOD_SERIES_GROUPED_SORTED','VOD_UNKNOWN_GROUPED_SORTED','LIVE_UNKNOWN_GROUPED_SORTED']
	if not muKG29tPNiTYQJMxkpl87CbLwXSV0:
		if not kcmbnMYF2WpDg0ti4UyCf3AV:
			if   '_M3U-LIVE_' in ZZCk6FGHRa8: muKG29tPNiTYQJMxkpl87CbLwXSV0 = tClLJ8cm5vAsFT0hx2kKYPME7O9[1]
			elif '_M3U-MOVIES' in ZZCk6FGHRa8: muKG29tPNiTYQJMxkpl87CbLwXSV0 = tClLJ8cm5vAsFT0hx2kKYPME7O9[2]
			elif '_M3U-SERIES' in ZZCk6FGHRa8: muKG29tPNiTYQJMxkpl87CbLwXSV0 = tClLJ8cm5vAsFT0hx2kKYPME7O9[3]
			else: muKG29tPNiTYQJMxkpl87CbLwXSV0 = tClLJ8cm5vAsFT0hx2kKYPME7O9[0]
		else:
			J5XbwseKOm = ['الكل','قنوات','أفلام','مسلسلات','فيديوهات مجهولة','قنوات مجهولة']
			r7MXibnK2fa6S31ctA = xVzqWbrFXJ('أختر البحث المناسب', J5XbwseKOm)
			if r7MXibnK2fa6S31ctA==-1: return
			muKG29tPNiTYQJMxkpl87CbLwXSV0 = tClLJ8cm5vAsFT0hx2kKYPME7O9[r7MXibnK2fa6S31ctA]
	iXIurhcJSVbtUHF0jPp2nNd4mEM = v9hig4t8jT.lower()
	LeuKy7JsdxW = PPlUAWKhqTdmnfwLrcYxDS8(m4W3gU71on2PF,'SEARCH')
	slKYBZe0zC3WF6XSunQar = XXyMBNAVJvKiq7jc20bEw6(LeuKy7JsdxW,'list','SEARCH',(muKG29tPNiTYQJMxkpl87CbLwXSV0,iXIurhcJSVbtUHF0jPp2nNd4mEM))
	if not slKYBZe0zC3WF6XSunQar:
		EaLNPM9IH1kVA7CZXQJyc05U4eWp,tB359Y7ZbjTyJVI0Ug8 = [],[]
		if not muKG29tPNiTYQJMxkpl87CbLwXSV0: f0IQwTciWlRO5bys = [1,2,3,4,5]
		else: f0IQwTciWlRO5bys = [tClLJ8cm5vAsFT0hx2kKYPME7O9.index(muKG29tPNiTYQJMxkpl87CbLwXSV0)]
		for av3QBl1coTFsq9jLgydwf in f0IQwTciWlRO5bys:
			if av3QBl1coTFsq9jLgydwf!=3:
				LUejlIa7XQWtrik21xfFMAGYwEp4y = XXyMBNAVJvKiq7jc20bEw6(LeuKy7JsdxW,'dict',tClLJ8cm5vAsFT0hx2kKYPME7O9[av3QBl1coTFsq9jLgydwf])
				del LUejlIa7XQWtrik21xfFMAGYwEp4y['__COUNT__']
				del LUejlIa7XQWtrik21xfFMAGYwEp4y['__GROUPS__']
				del LUejlIa7XQWtrik21xfFMAGYwEp4y['__SEQUENCED_COLUMNS__']
				ZteRaHumGPidbpsf1C = list(LUejlIa7XQWtrik21xfFMAGYwEp4y.keys())
				for dW4u3hS9wKCqD6xvIbylR in ZteRaHumGPidbpsf1C:
					for fdD0wQgTuni,zaDq3igbdyhsSnRcxoQ7uYPkl,WWowRmHkj1ZAO2SUhtNvdrcKa9E6C,xNF9bfr3tm in LUejlIa7XQWtrik21xfFMAGYwEp4y[dW4u3hS9wKCqD6xvIbylR]:
						if iXIurhcJSVbtUHF0jPp2nNd4mEM in zaDq3igbdyhsSnRcxoQ7uYPkl.lower(): tB359Y7ZbjTyJVI0Ug8.append((zaDq3igbdyhsSnRcxoQ7uYPkl,WWowRmHkj1ZAO2SUhtNvdrcKa9E6C,xNF9bfr3tm))
					del LUejlIa7XQWtrik21xfFMAGYwEp4y[dW4u3hS9wKCqD6xvIbylR]
				del LUejlIa7XQWtrik21xfFMAGYwEp4y
			else: ZteRaHumGPidbpsf1C = XXyMBNAVJvKiq7jc20bEw6(LeuKy7JsdxW,'list',tClLJ8cm5vAsFT0hx2kKYPME7O9[av3QBl1coTFsq9jLgydwf],'__GROUPS__')
			for dW4u3hS9wKCqD6xvIbylR in ZteRaHumGPidbpsf1C:
				try: dW4u3hS9wKCqD6xvIbylR,xNF9bfr3tm = dW4u3hS9wKCqD6xvIbylR
				except: xNF9bfr3tm = qpFY4hAwolV3
				if iXIurhcJSVbtUHF0jPp2nNd4mEM in dW4u3hS9wKCqD6xvIbylR.lower():
					if av3QBl1coTFsq9jLgydwf!=3: DzEy7AYvkUZciV1mGNneC = dW4u3hS9wKCqD6xvIbylR
					else:
						gMkqSFHydAuTf1,kZjnrmf4q63Y = dW4u3hS9wKCqD6xvIbylR.split('__SERIES__')
						if iXIurhcJSVbtUHF0jPp2nNd4mEM in gMkqSFHydAuTf1.lower(): DzEy7AYvkUZciV1mGNneC = gMkqSFHydAuTf1
						else: DzEy7AYvkUZciV1mGNneC = kZjnrmf4q63Y
					EaLNPM9IH1kVA7CZXQJyc05U4eWp.append((dW4u3hS9wKCqD6xvIbylR,DzEy7AYvkUZciV1mGNneC,tClLJ8cm5vAsFT0hx2kKYPME7O9[av3QBl1coTFsq9jLgydwf],xNF9bfr3tm))
			del ZteRaHumGPidbpsf1C
		EaLNPM9IH1kVA7CZXQJyc05U4eWp = set(EaLNPM9IH1kVA7CZXQJyc05U4eWp)
		tB359Y7ZbjTyJVI0Ug8 = set(tB359Y7ZbjTyJVI0Ug8)
		EaLNPM9IH1kVA7CZXQJyc05U4eWp = sorted(EaLNPM9IH1kVA7CZXQJyc05U4eWp,reverse=False,key=lambda f79ZnTkH0m45a1vj63xuQSd: f79ZnTkH0m45a1vj63xuQSd[1])
		tB359Y7ZbjTyJVI0Ug8 = sorted(tB359Y7ZbjTyJVI0Ug8,reverse=False,key=lambda f79ZnTkH0m45a1vj63xuQSd: f79ZnTkH0m45a1vj63xuQSd[0])
		zOYMaQ0NgdiRVwDJXh8e(LeuKy7JsdxW,'SEARCH',(muKG29tPNiTYQJMxkpl87CbLwXSV0,iXIurhcJSVbtUHF0jPp2nNd4mEM),(EaLNPM9IH1kVA7CZXQJyc05U4eWp,tB359Y7ZbjTyJVI0Ug8),ivLg9zRnGF83u)
	else: EaLNPM9IH1kVA7CZXQJyc05U4eWp,tB359Y7ZbjTyJVI0Ug8 = slKYBZe0zC3WF6XSunQar
	ZteRaHumGPidbpsf1C = len(EaLNPM9IH1kVA7CZXQJyc05U4eWp)
	nn6kx0CwQbjZprvieXUmlyhgYLPTBM = len(tB359Y7ZbjTyJVI0Ug8)
	aazJgfh6MTFGtP8SRoCDW9UZq = int(tPH05EC8L6cYqTX4xIUurnjk1MOG)
	EGC5b2fjYrVaiu7qmy81ILxN3ZA = max(0,(aazJgfh6MTFGtP8SRoCDW9UZq-1)*100)
	btxJBSh7GjXPkdvTAH = max(0,aazJgfh6MTFGtP8SRoCDW9UZq*100)
	EjSPpQDRVHJc = max(0,EGC5b2fjYrVaiu7qmy81ILxN3ZA-ZteRaHumGPidbpsf1C)
	zM4C2weqgLDyrEkm3clv8o = max(0,btxJBSh7GjXPkdvTAH-ZteRaHumGPidbpsf1C)
	for dW4u3hS9wKCqD6xvIbylR,DzEy7AYvkUZciV1mGNneC,ByD861PpQ4UvSToZA90xsI2,xNF9bfr3tm in EaLNPM9IH1kVA7CZXQJyc05U4eWp[EGC5b2fjYrVaiu7qmy81ILxN3ZA:btxJBSh7GjXPkdvTAH]:
		x3WSXnKyPhjqfHG2UrtQs('folder',KKxc2jv9sQZOpV+DzEy7AYvkUZciV1mGNneC,ByD861PpQ4UvSToZA90xsI2,714,xNF9bfr3tm,'1',dW4u3hS9wKCqD6xvIbylR,qpFY4hAwolV3,{'folder':m4W3gU71on2PF})
	del EaLNPM9IH1kVA7CZXQJyc05U4eWp
	for zaDq3igbdyhsSnRcxoQ7uYPkl,WWowRmHkj1ZAO2SUhtNvdrcKa9E6C,xNF9bfr3tm in tB359Y7ZbjTyJVI0Ug8[EjSPpQDRVHJc:zM4C2weqgLDyrEkm3clv8o]:
		UeIhAGn1T29tS4QdoJzu3fvZYCq = RRwxKI27Mk(WWowRmHkj1ZAO2SUhtNvdrcKa9E6C)
		lQnA93TCSoqKwIMJNz8L = 'live'
		if '.mkv' in UeIhAGn1T29tS4QdoJzu3fvZYCq or 'VOD' in muKG29tPNiTYQJMxkpl87CbLwXSV0: lQnA93TCSoqKwIMJNz8L = 'video'
		x3WSXnKyPhjqfHG2UrtQs(lQnA93TCSoqKwIMJNz8L,KKxc2jv9sQZOpV+zaDq3igbdyhsSnRcxoQ7uYPkl,WWowRmHkj1ZAO2SUhtNvdrcKa9E6C,715,xNF9bfr3tm,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,{'folder':m4W3gU71on2PF})
	del tB359Y7ZbjTyJVI0Ug8
	RPaQ1dgMHVXltF2(m4W3gU71on2PF,tPH05EC8L6cYqTX4xIUurnjk1MOG,muKG29tPNiTYQJMxkpl87CbLwXSV0,719,ZteRaHumGPidbpsf1C+nn6kx0CwQbjZprvieXUmlyhgYLPTBM,v9hig4t8jT+'_NODIALOGS_')
	return
def RPaQ1dgMHVXltF2(m4W3gU71on2PF,tPH05EC8L6cYqTX4xIUurnjk1MOG,muKG29tPNiTYQJMxkpl87CbLwXSV0,ZyiMa3BXVk2xWG0b,PT7f3Zk6WgXY,HY7yaJeI89xE56sbTjdBRZPDwQKFX):
	if not tPH05EC8L6cYqTX4xIUurnjk1MOG: tPH05EC8L6cYqTX4xIUurnjk1MOG = '1'
	if tPH05EC8L6cYqTX4xIUurnjk1MOG!='1': x3WSXnKyPhjqfHG2UrtQs('folder',KKxc2jv9sQZOpV+'صفحة '+str(1),muKG29tPNiTYQJMxkpl87CbLwXSV0,ZyiMa3BXVk2xWG0b,qpFY4hAwolV3,str(1),HY7yaJeI89xE56sbTjdBRZPDwQKFX,qpFY4hAwolV3,{'folder':m4W3gU71on2PF})
	if not PT7f3Zk6WgXY: PT7f3Zk6WgXY = 0
	brfgRc4AJMs = int(PT7f3Zk6WgXY/100)+1
	for aazJgfh6MTFGtP8SRoCDW9UZq in range(2,brfgRc4AJMs):
		XiCad4FNLAxT1znHkf = (aazJgfh6MTFGtP8SRoCDW9UZq%10==0 or int(tPH05EC8L6cYqTX4xIUurnjk1MOG)-4<aazJgfh6MTFGtP8SRoCDW9UZq<int(tPH05EC8L6cYqTX4xIUurnjk1MOG)+4)
		fAlVmB6SnOWb5xNFIvuwjRaYk7 = (XiCad4FNLAxT1znHkf and int(tPH05EC8L6cYqTX4xIUurnjk1MOG)-40<aazJgfh6MTFGtP8SRoCDW9UZq<int(tPH05EC8L6cYqTX4xIUurnjk1MOG)+40)
		if str(aazJgfh6MTFGtP8SRoCDW9UZq)!=tPH05EC8L6cYqTX4xIUurnjk1MOG and (aazJgfh6MTFGtP8SRoCDW9UZq%100==0 or fAlVmB6SnOWb5xNFIvuwjRaYk7):
			x3WSXnKyPhjqfHG2UrtQs('folder',KKxc2jv9sQZOpV+'صفحة '+str(aazJgfh6MTFGtP8SRoCDW9UZq),muKG29tPNiTYQJMxkpl87CbLwXSV0,ZyiMa3BXVk2xWG0b,qpFY4hAwolV3,str(aazJgfh6MTFGtP8SRoCDW9UZq),HY7yaJeI89xE56sbTjdBRZPDwQKFX,qpFY4hAwolV3,{'folder':m4W3gU71on2PF})
	if str(brfgRc4AJMs)!=tPH05EC8L6cYqTX4xIUurnjk1MOG: x3WSXnKyPhjqfHG2UrtQs('folder',KKxc2jv9sQZOpV+'أخر صفحة '+str(brfgRc4AJMs),muKG29tPNiTYQJMxkpl87CbLwXSV0,ZyiMa3BXVk2xWG0b,qpFY4hAwolV3,str(brfgRc4AJMs),HY7yaJeI89xE56sbTjdBRZPDwQKFX,qpFY4hAwolV3,{'folder':m4W3gU71on2PF})
	return
def PPlUAWKhqTdmnfwLrcYxDS8(m4W3gU71on2PF,muKG29tPNiTYQJMxkpl87CbLwXSV0):
	LeuKy7JsdxW = qmnFDxEPc1.replace('___','_'+m4W3gU71on2PF)
	return LeuKy7JsdxW
def bzdJ7qHRfEuKghjnNwD04MPYa(m4W3gU71on2PF):
	LeuKy7JsdxW = PPlUAWKhqTdmnfwLrcYxDS8(m4W3gU71on2PF,qpFY4hAwolV3)
	fN4Cnx6kjp = VVpbtSKYUGXrNMwAWFo9IOjZP('center',qpFY4hAwolV3,qpFY4hAwolV3,GLTtERWbHnFuy4PCp,'جلب ملفات M3U جديدة قد تحتاج عدة دقائق .. هل تريد أن تجلب الملفات الآن ؟!')
	if fN4Cnx6kjp!=1: return False
	F7jBEp8OsVkZ(m4W3gU71on2PF,False)
	O0sLXmveaEyZpJC53w9kofzlNU7jg = [0]
	for PC1WedfcN6i0sD in range(1,cqSFolBs7A1G0X9u4a6K+1):
		LSF3Q57vH29qrm1zlo = gdPslyFW8ITBcpA302.getSetting('av.m3u.url_'+m4W3gU71on2PF+'_'+str(PC1WedfcN6i0sD))
		if LSF3Q57vH29qrm1zlo: F8YMO5Ecs1A(m4W3gU71on2PF,str(PC1WedfcN6i0sD))
		O0sLXmveaEyZpJC53w9kofzlNU7jg.append(0)
	for muKG29tPNiTYQJMxkpl87CbLwXSV0 in Va04phzWlCG:
		Kjx4itXMpSlCz7,djGfPzEDioXktW,rrbcamNCFdI,TQEMIiBtRdyCGz38Kv2XFkVujo0m,KXdTf9jsStMvuGFUDHqo5yblx1m = 0,{},[],[],[]
		for PC1WedfcN6i0sD in range(1,cqSFolBs7A1G0X9u4a6K+1):
			ByD861PpQ4UvSToZA90xsI2 = muKG29tPNiTYQJMxkpl87CbLwXSV0+'_'+str(PC1WedfcN6i0sD)
			gqi6dfmFMp4aeu5jDrSz1ny7QsW = XXyMBNAVJvKiq7jc20bEw6(LeuKy7JsdxW,'dict',ByD861PpQ4UvSToZA90xsI2)
			try:
				qQ7sepI1fj8PcNuHJl = gqi6dfmFMp4aeu5jDrSz1ny7QsW['__GROUPS__']
				y1FEOnmUq6eaTbVRCL9j = gqi6dfmFMp4aeu5jDrSz1ny7QsW['__COUNT__']
			except: qQ7sepI1fj8PcNuHJl,y1FEOnmUq6eaTbVRCL9j = [],'0'
			for VgJ2I3bqMrht in qQ7sepI1fj8PcNuHJl:
				dW4u3hS9wKCqD6xvIbylR,xCei3u0k2rAVK9o7zQcdZaGXT = VgJ2I3bqMrht
				LUejlIa7XQWtrik21xfFMAGYwEp4y = gqi6dfmFMp4aeu5jDrSz1ny7QsW[dW4u3hS9wKCqD6xvIbylR]
				if dW4u3hS9wKCqD6xvIbylR not in TQEMIiBtRdyCGz38Kv2XFkVujo0m:
					TQEMIiBtRdyCGz38Kv2XFkVujo0m.append(dW4u3hS9wKCqD6xvIbylR)
					KXdTf9jsStMvuGFUDHqo5yblx1m.append(VgJ2I3bqMrht)
					djGfPzEDioXktW[dW4u3hS9wKCqD6xvIbylR] = []
				djGfPzEDioXktW[dW4u3hS9wKCqD6xvIbylR] += LUejlIa7XQWtrik21xfFMAGYwEp4y
			mlykPoGXbJIjFnarp9KihxfN(LeuKy7JsdxW,ByD861PpQ4UvSToZA90xsI2)
			zOYMaQ0NgdiRVwDJXh8e(LeuKy7JsdxW,ByD861PpQ4UvSToZA90xsI2,'__COUNT__',y1FEOnmUq6eaTbVRCL9j,ivLg9zRnGF83u)
			O0sLXmveaEyZpJC53w9kofzlNU7jg[PC1WedfcN6i0sD] += int(y1FEOnmUq6eaTbVRCL9j)
		for dW4u3hS9wKCqD6xvIbylR in TQEMIiBtRdyCGz38Kv2XFkVujo0m:
			LUejlIa7XQWtrik21xfFMAGYwEp4y = list(set(djGfPzEDioXktW[dW4u3hS9wKCqD6xvIbylR]))
			if 'SORTED' in muKG29tPNiTYQJMxkpl87CbLwXSV0: LUejlIa7XQWtrik21xfFMAGYwEp4y = sorted(LUejlIa7XQWtrik21xfFMAGYwEp4y,reverse=False,key=lambda key: key[1].lower())
			Kjx4itXMpSlCz7 += len(LUejlIa7XQWtrik21xfFMAGYwEp4y)
			rrbcamNCFdI.append(LUejlIa7XQWtrik21xfFMAGYwEp4y)
		zOYMaQ0NgdiRVwDJXh8e(LeuKy7JsdxW,muKG29tPNiTYQJMxkpl87CbLwXSV0,'__COUNT__',str(Kjx4itXMpSlCz7),ivLg9zRnGF83u)
		zOYMaQ0NgdiRVwDJXh8e(LeuKy7JsdxW,muKG29tPNiTYQJMxkpl87CbLwXSV0,'__GROUPS__',KXdTf9jsStMvuGFUDHqo5yblx1m,ivLg9zRnGF83u)
		zOYMaQ0NgdiRVwDJXh8e(LeuKy7JsdxW,muKG29tPNiTYQJMxkpl87CbLwXSV0,TQEMIiBtRdyCGz38Kv2XFkVujo0m,rrbcamNCFdI,ivLg9zRnGF83u,True)
	xpXGa8v9Yjw = False
	for PC1WedfcN6i0sD in range(1,cqSFolBs7A1G0X9u4a6K+1):
		if int(O0sLXmveaEyZpJC53w9kofzlNU7jg[PC1WedfcN6i0sD])>0:
			LSF3Q57vH29qrm1zlo = gdPslyFW8ITBcpA302.getSetting('av.m3u.url_'+m4W3gU71on2PF+'_'+str(PC1WedfcN6i0sD))
			zOYMaQ0NgdiRVwDJXh8e(LeuKy7JsdxW,'LINK_'+str(PC1WedfcN6i0sD),'__LINK__',LSF3Q57vH29qrm1zlo,ivLg9zRnGF83u)
			xpXGa8v9Yjw = True
	zOYMaQ0NgdiRVwDJXh8e(LeuKy7JsdxW,'DUMMY','__DUMMY__','DUMMY',ivLg9zRnGF83u)
	if not xpXGa8v9Yjw:
		iG7Rz2kmn0x1yLNMV3u8O(qpFY4hAwolV3,qpFY4hAwolV3,GLTtERWbHnFuy4PCp,'فشل بسحب ملفات M3U .. أحتمال روابط M3U التي أنت أضفتها للبرنامج غير صحيحة .. علما أن هذه الخدمة تحتاج منك أن تضيف الرابط بنفسك للبرنامج باستخدام قائمة M3U الموجودة في هذا البرنامج')
		return False
	iG7Rz2kmn0x1yLNMV3u8O(qpFY4hAwolV3,qpFY4hAwolV3,GLTtERWbHnFuy4PCp,'تم جلب ملفات M3U جديدة')
	vcU6kyVAKWY3S2ue7tOr5XihJ9xo(m4W3gU71on2PF)
	PAfd3TnXb2oz(False)
	E2E18vJ4hLaZpuWSfoMlY9yBzj6b(False)
	return True
def vcU6kyVAKWY3S2ue7tOr5XihJ9xo(m4W3gU71on2PF):
	LeuKy7JsdxW = PPlUAWKhqTdmnfwLrcYxDS8(m4W3gU71on2PF,qpFY4hAwolV3)
	if not N4mtgDP83waX9(m4W3gU71on2PF,True): return
	for PC1WedfcN6i0sD in range(1,cqSFolBs7A1G0X9u4a6K+1):
		LSF3Q57vH29qrm1zlo = XXyMBNAVJvKiq7jc20bEw6(LeuKy7JsdxW,'str','LINK_'+str(PC1WedfcN6i0sD),'__LINK__')
		if LSF3Q57vH29qrm1zlo: U36sYteOgkXlp7DdEBioaQMTmrR = fflBH1UhzSIKN(m4W3gU71on2PF,str(PC1WedfcN6i0sD))
	fflBH1UhzSIKN(m4W3gU71on2PF,qpFY4hAwolV3)
	return
def F7jBEp8OsVkZ(m4W3gU71on2PF,kcmbnMYF2WpDg0ti4UyCf3AV):
	if kcmbnMYF2WpDg0ti4UyCf3AV:
		fN4Cnx6kjp = VVpbtSKYUGXrNMwAWFo9IOjZP('center',qpFY4hAwolV3,qpFY4hAwolV3,'مسح ملفات ـM3U','هل تريد مسح الملفات القديمة المخزنة في البرنامج ؟! \n\n علما انك تستطيع في أي وقت الدخول إلى قائمة M3U وجلب ملفات M3U جديدة')
		if fN4Cnx6kjp!=1: return
	LeuKy7JsdxW = PPlUAWKhqTdmnfwLrcYxDS8(m4W3gU71on2PF,qpFY4hAwolV3)
	try: RPbaxsNFVTwek5Kfv21DiJuzCnjMZp.remove(LeuKy7JsdxW)
	except: pass
	for PC1WedfcN6i0sD in range(1,cqSFolBs7A1G0X9u4a6K+1):
		vvKPsk74UZ9q = v3DXdfGq7VeBh9ousFNOw8yrkEM1n.replace('___','_'+m4W3gU71on2PF+'_'+str(PC1WedfcN6i0sD))
		Hmxbqar4CpIji = RPbaxsNFVTwek5Kfv21DiJuzCnjMZp.path.join(F8qeAKZjGRMNXimho2gntaV0,vvKPsk74UZ9q)
		try: RPbaxsNFVTwek5Kfv21DiJuzCnjMZp.remove(Hmxbqar4CpIji)
		except: pass
	mlykPoGXbJIjFnarp9KihxfN(WoFsvbmUlDZp7PzRfdGknCV,'SECTIONS_M3U','SECTIONS_M3U_'+m4W3gU71on2PF)
	mlykPoGXbJIjFnarp9KihxfN(WoFsvbmUlDZp7PzRfdGknCV,'SECTIONS_M3U','SECTIONS_M3U_ALL')
	if kcmbnMYF2WpDg0ti4UyCf3AV:
		iG7Rz2kmn0x1yLNMV3u8O(qpFY4hAwolV3,qpFY4hAwolV3,GLTtERWbHnFuy4PCp,'تم مسح جميع ملفات ـM3U')
		E2E18vJ4hLaZpuWSfoMlY9yBzj6b(False)
	return
def sGN5rVnhIaTqz14FPdki(m4W3gU71on2PF):
	yYEov8Z6AigIXPKG3ScDl = gdPslyFW8ITBcpA302.getSetting('av.language.provider')
	ifagUjOkwHnCcJ5 = gdPslyFW8ITBcpA302.getSetting('av.language.code')
	mlykPoGXbJIjFnarp9KihxfN(WoFsvbmUlDZp7PzRfdGknCV,'MENUS_CACHE_'+yYEov8Z6AigIXPKG3ScDl+'_'+ifagUjOkwHnCcJ5,'%_MU'+m4W3gU71on2PF+'_%')
	return
ko8iWQPSTC = {
		 'AF':'Afghanistan'
		,'AL':'Albania'
		,'DZ':'Algeria'
		,'AS':'American Samoa'
		,'AD':'Andorra'
		,'AO':'Angola'
		,'AI':'Anguilla'
		,'AQ':'Antarctica'
		,'AG':'Antigua and Barbuda'
		,'AR':'Argentina'
		,'AM':'Armenia'
		,'AW':'Aruba'
		,'AU':'Australia'
		,'AT':'Austria'
		,'AZ':'Azerbaijan'
		,'BS':'Bahamas'
		,'BH':'Bahrain'
		,'BD':'Bangladesh'
		,'BB':'Barbados'
		,'BY':'Belarus'
		,'BE':'Belgium'
		,'BZ':'Belize'
		,'BJ':'Benin'
		,'BM':'Bermuda'
		,'BT':'Bhutan'
		,'BO':'Bolivia'
		,'BQ':'Bonaire'
		,'BA':'Bosnia and Herzegovina'
		,'BW':'Botswana'
		,'BV':'Bouvet Island'
		,'BR':'Brazil'
		,'IO':'British Indian Ocean Territory'
		,'VG':'British Virgin Islands'
		,'BN':'Brunei'
		,'BG':'Bulgaria'
		,'BF':'Burkina Faso'
		,'BI':'Burundi'
		,'KH':'Cambodia'
		,'CM':'Cameroon'
		,'CA':'Canada'
		,'CV':'Cape Verde'
		,'KY':'Cayman Islands'
		,'CF':'Central African Republic'
		,'TD':'Chad'
		,'CL':'Chile'
		,'CN':'China'
		,'CX':'Christmas Island'
		,'CC':'Cocos (Keeling) Islands'
		,'CO':'Colombia'
		,'KM':'Comoros'
		,'CK':'Cook Islands'
		,'CR':'Costa Rica'
		,'HR':'Croatia'
		,'CU':'Cuba'
		,'CW':'Curacao'
		,'CY':'Cyprus'
		,'CZ':'Czech Republic'
		,'CD':'Democratic Republic of the Congo'
		,'DK':'Denmark'
		,'DJ':'Djibouti'
		,'DM':'Dominica'
		,'DO':'Dominican Republic'
		,'TL':'East Timor'
		,'EC':'Ecuador'
		,'EG':'Egypt'
		,'SV':'El Salvador'
		,'GQ':'Equatorial Guinea'
		,'ER':'Eritrea'
		,'EE':'Estonia'
		,'ET':'Ethiopia'
		,'FK':'Falkland Islands'
		,'FO':'Faroe Islands'
		,'FJ':'Fiji'
		,'FI':'Finland'
		,'FR':'France'
		,'GF':'French Guiana'
		,'PF':'French Polynesia'
		,'TF':'French Southern Territories'
		,'GA':'Gabon'
		,'GM':'Gambia'
		,'GE':'Georgia'
		,'DE':'Germany'
		,'GH':'Ghana'
		,'GI':'Gibraltar'
		,'GR':'Greece'
		,'GL':'Greenland'
		,'GD':'Grenada'
		,'GP':'Guadeloupe'
		,'GU':'Guam'
		,'GT':'Guatemala'
		,'GG':'Guernsey'
		,'GN':'Guinea'
		,'GW':'Guinea-Bissau'
		,'GY':'Guyana'
		,'HT':'Haiti'
		,'HM':'Heard Island and McDonald Islands'
		,'HN':'Honduras'
		,'HK':'Hong Kong'
		,'HU':'Hungary'
		,'IS':'Iceland'
		,'IN':'India'
		,'ID':'Indonesia'
		,'IR':'Iran'
		,'IQ':'Iraq'
		,'IE':'Ireland'
		,'IM':'Isle of Man'
		,'IL':'Israel'
		,'IT':'Italy'
		,'CI':'Ivory Coast'
		,'JM':'Jamaica'
		,'JP':'Japan'
		,'JE':'Jersey'
		,'JO':'Jordan'
		,'KZ':'Kazakhstan'
		,'KE':'Kenya'
		,'KI':'Kiribati'
		,'XK':'Kosovo'
		,'KW':'Kuwait'
		,'KG':'Kyrgyzstan'
		,'LA':'Laos'
		,'LV':'Latvia'
		,'LB':'Lebanon'
		,'LS':'Lesotho'
		,'LR':'Liberia'
		,'LY':'Libya'
		,'LI':'Liechtenstein'
		,'LT':'Lithuania'
		,'LU':'Luxembourg'
		,'MO':'Macao'
		,'MG':'Madagascar'
		,'MW':'Malawi'
		,'MY':'Malaysia'
		,'MV':'Maldives'
		,'ML':'Mali'
		,'MT':'Malta'
		,'MH':'Marshall Islands'
		,'MQ':'Martinique'
		,'MR':'Mauritania'
		,'MU':'Mauritius'
		,'YT':'Mayotte'
		,'MX':'Mexico'
		,'FM':'Micronesia'
		,'MD':'Moldova'
		,'MC':'Monaco'
		,'MN':'Mongolia'
		,'ME':'Montenegro'
		,'MS':'Montserrat'
		,'MA':'Morocco'
		,'MZ':'Mozambique'
		,'MM':'Myanmar (Burma)'
		,'NA':'Namibia'
		,'NR':'Nauru'
		,'NP':'Nepal'
		,'NL':'Netherlands'
		,'NC':'New Caledonia'
		,'NZ':'New Zealand'
		,'NI':'Nicaragua'
		,'NE':'Niger'
		,'NG':'Nigeria'
		,'NU':'Niue'
		,'NF':'Norfolk Island'
		,'KP':'North Korea'
		,'MK':'North Macedonia'
		,'MP':'Northern Mariana Islands'
		,'NO':'Norway'
		,'OM':'Oman'
		,'PK':'Pakistan'
		,'PW':'Palau'
		,'PS':'Palestine'
		,'PA':'Panama'
		,'PG':'Papua New Guinea'
		,'PY':'Paraguay'
		,'PE':'Peru'
		,'PH':'Philippines'
		,'PN':'Pitcairn Islands'
		,'PL':'Poland'
		,'PT':'Portugal'
		,'PR':'Puerto Rico'
		,'QA':'Qatar'
		,'CG':'Republic of the Congo'
		,'RO':'Romania'
		,'RU':'Russia'
		,'RW':'Rwanda'
		,'RE':'Réunion'
		,'BL':'Saint Barthélemy'
		,'SH':'Saint Helena'
		,'KN':'Saint Kitts and Nevis'
		,'LC':'Saint Lucia'
		,'MF':'Saint Martin'
		,'PM':'Saint Pierre and Miquelon'
		,'VC':'Saint Vincent and the Grenadines'
		,'WS':'Samoa'
		,'SM':'San Marino'
		,'SA':'Saudi Arabia'
		,'SN':'Senegal'
		,'RS':'Serbia'
		,'SC':'Seychelles'
		,'SL':'Sierra Leone'
		,'SG':'Singapore'
		,'SX':'Sint Maarten'
		,'SK':'Slovakia'
		,'SI':'Slovenia'
		,'SB':'Solomon Islands'
		,'SO':'Somalia'
		,'ZA':'South Africa'
		,'GS':'South Georgia and the South Sandwich Islands'
		,'KR':'South Korea'
		,'SS':'South Sudan'
		,'ES':'Spain'
		,'LK':'Sri Lanka'
		,'SD':'Sudan'
		,'SR':'Suriname'
		,'SJ':'Svalbard and Jan Mayen'
		,'SZ':'Swaziland'
		,'SE':'Sweden'
		,'CH':'Switzerland'
		,'SY':'Syria'
		,'ST':'São Tomé and Príncipe'
		,'TW':'Taiwan'
		,'TJ':'Tajikistan'
		,'TZ':'Tanzania'
		,'TH':'Thailand'
		,'TG':'Togo'
		,'TK':'Tokelau'
		,'TO':'Tonga'
		,'TT':'Trinidad and Tobago'
		,'TN':'Tunisia'
		,'TR':'Turkey'
		,'TM':'Turkmenistan'
		,'TC':'Turks and Caicos Islands'
		,'TV':'Tuvalu'
		,'UM':'U.S. Minor Outlying Islands'
		,'VI':'U.S. Virgin Islands'
		,'UG':'Uganda'
		,'UA':'Ukraine'
		,'AE':'United Arab Emirates'
		,'UK':'United Kingdom'
		,'US':'United States'
		,'UY':'Uruguay'
		,'UZ':'Uzbekistan'
		,'VU':'Vanuatu'
		,'VA':'Vatican City'
		,'VE':'Venezuela'
		,'VN':'Vietnam'
		,'WF':'Wallis and Futuna'
		,'EH':'Western Sahara'
		,'YE':'Yemen'
		,'ZM':'Zambia'
		,'ZW':'Zimbabwe'
		,'AX':'Åland'
		}