# -*- coding: utf-8 -*-
from pSfaryIjBo import *
Q8Q0IDc6PLZajJAdTntKUmSGXz = 'EGYBEST1'
wwSFijdVJn1QgHW = '_EB1_'
ddBxj51bhNtaK23lDyGMVw = i4bFG3rKE6.SITESURLS[Q8Q0IDc6PLZajJAdTntKUmSGXz][0]
YEIA19ehBwpNfPVzK = ['مكتبتي','ايجي بست']
def vTNE2Ck1sGnugJYW8y39aLcSH64U(mode,url,i02wfPp5EM,text):
	if   mode==770: MOTjA5H9XFs = nRVAZc4Dp8PSrGU3xBk()
	elif mode==771: MOTjA5H9XFs = c8U1BdtxOZS5FH(url,i02wfPp5EM)
	elif mode==772: MOTjA5H9XFs = X2rO3lubqIdCGMLYWcxA6DK5(url)
	elif mode==773: MOTjA5H9XFs = mzcAeyplZV(url)
	elif mode==774: MOTjA5H9XFs = R9pWUgVhBGLd2CQb0z(url,'FULL_FILTER___'+text)
	elif mode==775: MOTjA5H9XFs = R9pWUgVhBGLd2CQb0z(url,'DEFINED_FILTER___'+text)
	elif mode==776: MOTjA5H9XFs = eewkhcztmSDWKrPIX(url,i02wfPp5EM)
	elif mode==779: MOTjA5H9XFs = PPqUACSE3VcGLTvw05jHy9JrFNW(text,url)
	else: MOTjA5H9XFs = False
	return MOTjA5H9XFs
def nRVAZc4Dp8PSrGU3xBk():
	x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+'بحث في الموقع',qpFY4hAwolV3,779,qpFY4hAwolV3,qpFY4hAwolV3,'_REMEMBERRESULTS_')
	x3WSXnKyPhjqfHG2UrtQs('link',xupTj02bvy3O8R+' ===== ===== ===== '+fF4lt9zWYxXLKZVyAco82PgMj,qpFY4hAwolV3,9999)
	IAW0sh6So3NpqM = WWrExJZS3Bj4anOAkpv7(KOyPvpEztYLaZRdMQJWxfTNFHbkg,'GET',ddBxj51bhNtaK23lDyGMVw,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,'EGYBEST1-MENU-1st')
	cmWl9dOKHPIy41iaXuxrY = IAW0sh6So3NpqM.content
	pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('nav-list(.*?)</ul>',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	if pfRkcVlLmUxo561g0A8qSbO:
		mVYdjvor6i4wZ8 = pfRkcVlLmUxo561g0A8qSbO[0]
		items = ePhmG1jLD6.findall('href="(.*?)".*?<span>(.*?)</span>',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
		for MepIvHBYNArkUOdV37shtJ,title in items:
			title = title.strip(mIsDke0oK5x1zSiOWbF9thGcA)
			if any(value in title for value in YEIA19ehBwpNfPVzK): continue
			x3WSXnKyPhjqfHG2UrtQs('folder',Q8Q0IDc6PLZajJAdTntKUmSGXz+'_SCRIPT_'+wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,771)
		x3WSXnKyPhjqfHG2UrtQs('link',xupTj02bvy3O8R+' ===== ===== ===== '+fF4lt9zWYxXLKZVyAco82PgMj,qpFY4hAwolV3,9999)
	pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('main-article(.*?)social-box',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	if pfRkcVlLmUxo561g0A8qSbO:
		mVYdjvor6i4wZ8 = pfRkcVlLmUxo561g0A8qSbO[0]
		items = ePhmG1jLD6.findall('main-title.*?">(.*?)<.*?href="(.*?)"',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
		for title,MepIvHBYNArkUOdV37shtJ in items:
			title = title.strip(mIsDke0oK5x1zSiOWbF9thGcA)
			x3WSXnKyPhjqfHG2UrtQs('folder',Q8Q0IDc6PLZajJAdTntKUmSGXz+'_SCRIPT_'+wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,771,qpFY4hAwolV3,'mainmenu')
		x3WSXnKyPhjqfHG2UrtQs('link',xupTj02bvy3O8R+' ===== ===== ===== '+fF4lt9zWYxXLKZVyAco82PgMj,qpFY4hAwolV3,9999)
	pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('main-menu(.*?)</div></div>',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	if pfRkcVlLmUxo561g0A8qSbO:
		mVYdjvor6i4wZ8 = pfRkcVlLmUxo561g0A8qSbO[0]
		items = ePhmG1jLD6.findall('href="(.*?)">(.*?)<',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
		for MepIvHBYNArkUOdV37shtJ,title in items:
			title = title.strip(mIsDke0oK5x1zSiOWbF9thGcA)
			x3WSXnKyPhjqfHG2UrtQs('folder',Q8Q0IDc6PLZajJAdTntKUmSGXz+'_SCRIPT_'+wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,771)
	return cmWl9dOKHPIy41iaXuxrY
def eewkhcztmSDWKrPIX(url,type=qpFY4hAwolV3):
	IAW0sh6So3NpqM = WWrExJZS3Bj4anOAkpv7(kUz8c7OqsxuPFIGfwg,'GET',url,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,'EGYBEST1-SEASONS_EPISODES-1st')
	cmWl9dOKHPIy41iaXuxrY = IAW0sh6So3NpqM.content
	pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('main-article".*?">(.*?)<(.*?)article',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	if pfRkcVlLmUxo561g0A8qSbO:
		WWQOoJZpXFmLHnDht1j,pzLc3HwImv2dru,items = qpFY4hAwolV3,qpFY4hAwolV3,[]
		for name,mVYdjvor6i4wZ8 in pfRkcVlLmUxo561g0A8qSbO:
			if 'حلقات' in name: pzLc3HwImv2dru = mVYdjvor6i4wZ8
			if 'مواسم' in name: WWQOoJZpXFmLHnDht1j = mVYdjvor6i4wZ8
		if WWQOoJZpXFmLHnDht1j and not type:
			items = ePhmG1jLD6.findall('href="(.*?)".*?data-src="(.*?)".*?"title">(.*?)<',WWQOoJZpXFmLHnDht1j,ePhmG1jLD6.DOTALL)
			if len(items)>1:
				for MepIvHBYNArkUOdV37shtJ,Sj7rMNYRuQPTtkBvpHKeDW3h,title in items:
					x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,776,Sj7rMNYRuQPTtkBvpHKeDW3h,'season')
		if pzLc3HwImv2dru and len(items)<2:
			items = ePhmG1jLD6.findall('href="(.*?)".*?data-src="(.*?)".*?title="(.*?)"',pzLc3HwImv2dru,ePhmG1jLD6.DOTALL)
			if items:
				for MepIvHBYNArkUOdV37shtJ,Sj7rMNYRuQPTtkBvpHKeDW3h,title in items:
					x3WSXnKyPhjqfHG2UrtQs('video',wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,773,Sj7rMNYRuQPTtkBvpHKeDW3h)
			else:
				items = ePhmG1jLD6.findall('href="(.*?)">(.*?)<',pzLc3HwImv2dru,ePhmG1jLD6.DOTALL)
				for MepIvHBYNArkUOdV37shtJ,title in items:
					x3WSXnKyPhjqfHG2UrtQs('video',wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,773)
	return
def c8U1BdtxOZS5FH(url,type=qpFY4hAwolV3):
	IAW0sh6So3NpqM = WWrExJZS3Bj4anOAkpv7(kUz8c7OqsxuPFIGfwg,'GET',url,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,'EGYBEST1-TITLES-1st')
	cmWl9dOKHPIy41iaXuxrY = IAW0sh6So3NpqM.content
	items,Iun1xvJFmCopwhd0XbH9BqPgMAV7Zt,bbaYxjcVnksy = [],False,False
	if not type:
		pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('main-content(.*?)</div>',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
		if pfRkcVlLmUxo561g0A8qSbO:
			mVYdjvor6i4wZ8 = pfRkcVlLmUxo561g0A8qSbO[0]
			items = ePhmG1jLD6.findall('href="(.*?)".*?</i>(.*?)</a>',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
			for MepIvHBYNArkUOdV37shtJ,title in items:
				title = title.strip(mIsDke0oK5x1zSiOWbF9thGcA)
				x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,771,qpFY4hAwolV3,'submenu')
				Iun1xvJFmCopwhd0XbH9BqPgMAV7Zt = True
	if not type and 'p=' not in url:
		pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('searchform(.*?)</form>',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
		if pfRkcVlLmUxo561g0A8qSbO:
			if Iun1xvJFmCopwhd0XbH9BqPgMAV7Zt: x3WSXnKyPhjqfHG2UrtQs('link',xupTj02bvy3O8R+' ===== ===== ===== '+fF4lt9zWYxXLKZVyAco82PgMj,qpFY4hAwolV3,9999)
			x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+'فلتر محدد',url,775,qpFY4hAwolV3,'filter')
			x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+'فلتر كامل',url,774,qpFY4hAwolV3,'filter')
			x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+'بحث',url,779)
			x3WSXnKyPhjqfHG2UrtQs('link',xupTj02bvy3O8R+' ===== ===== ===== '+fF4lt9zWYxXLKZVyAco82PgMj,qpFY4hAwolV3,9999)
			bbaYxjcVnksy = True
	if not Iun1xvJFmCopwhd0XbH9BqPgMAV7Zt:
		pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('blocks(.*?)article',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
		if pfRkcVlLmUxo561g0A8qSbO:
			mVYdjvor6i4wZ8 = pfRkcVlLmUxo561g0A8qSbO[0]
			items = ePhmG1jLD6.findall('href="(.*?)".*?src="(.*?)".*?class="title">(.*?)<',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
			for MepIvHBYNArkUOdV37shtJ,Sj7rMNYRuQPTtkBvpHKeDW3h,title in items:
				Sj7rMNYRuQPTtkBvpHKeDW3h = Sj7rMNYRuQPTtkBvpHKeDW3h.strip(ZLwoRpfnCWI7FgEHsz6te39lMVh)
				MepIvHBYNArkUOdV37shtJ = cTt4u6reEMKZqVLplmkNW7(MepIvHBYNArkUOdV37shtJ)
				if '/serie/' in MepIvHBYNArkUOdV37shtJ: x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,776,Sj7rMNYRuQPTtkBvpHKeDW3h,'season')
				else: x3WSXnKyPhjqfHG2UrtQs('video',wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,773,Sj7rMNYRuQPTtkBvpHKeDW3h)
			i02wfPp5EM = '1'
			if 'p=' in url: url,i02wfPp5EM = url.split('p=',1)
			MkQL5RWVxPpz2mi63ADrt = '&' if '?' in url else '?'
			url = url+MkQL5RWVxPpz2mi63ADrt
			url = url.replace('?&','?')
			if len(items)==40:
				url = url+'p='+str(int(i02wfPp5EM)+1)
				x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+'الصفحة التالية',url,771)
			elif i02wfPp5EM!='1':
				url = url+'p='+str(int(i02wfPp5EM)-1)
				x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+'الصفحة السابقة',url,771)
	return
def mzcAeyplZV(url):
	IAW0sh6So3NpqM = WWrExJZS3Bj4anOAkpv7(dzcNuIbsgK3yZ6SXGaEHPfOj5vk,'GET',url,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,'EGYBEST1-PLAY-1st')
	cmWl9dOKHPIy41iaXuxrY = IAW0sh6So3NpqM.content
	GIE2XSj0vVJPZA6dgmOs9TMDy8UkQW = ePhmG1jLD6.findall('<label>التصنيف</label>.*?">(.*?)<',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	if GIE2XSj0vVJPZA6dgmOs9TMDy8UkQW and u0E18eO3HnCzr(Q8Q0IDc6PLZajJAdTntKUmSGXz,url,GIE2XSj0vVJPZA6dgmOs9TMDy8UkQW): return
	uanHAxOJdPW,tiYp9ZdbFTQMcB4vWkHw6LXIAKrN5m,GSFxVaA5P1pd9D = [],[],[]
	MepIvHBYNArkUOdV37shtJ = ePhmG1jLD6.findall('download-section.*?action="(.*?)"',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	if MepIvHBYNArkUOdV37shtJ:
		MepIvHBYNArkUOdV37shtJ = MepIvHBYNArkUOdV37shtJ[0]
		if MepIvHBYNArkUOdV37shtJ not in GSFxVaA5P1pd9D:
			GSFxVaA5P1pd9D.append(MepIvHBYNArkUOdV37shtJ)
			tiYp9ZdbFTQMcB4vWkHw6LXIAKrN5m.append(MepIvHBYNArkUOdV37shtJ+'?named=__embed______'+BUKlErdIu7Ggqcz3jYpf09wMePF4V(url))
	HLVwBWJ6mFa3ApoNlq178nuXgI = ePhmG1jLD6.findall('WatchServers(.*?)</div>',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	for mVYdjvor6i4wZ8 in HLVwBWJ6mFa3ApoNlq178nuXgI:
		CFevtSjzbpn = ePhmG1jLD6.findall("url='(.*?)'.*?>(.*?)<",mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
		for MepIvHBYNArkUOdV37shtJ,XPNkVcWFUr in CFevtSjzbpn:
			if MepIvHBYNArkUOdV37shtJ not in GSFxVaA5P1pd9D:
				GSFxVaA5P1pd9D.append(MepIvHBYNArkUOdV37shtJ)
				tiYp9ZdbFTQMcB4vWkHw6LXIAKrN5m.append(MepIvHBYNArkUOdV37shtJ+'?named='+XPNkVcWFUr+'__both______'+BUKlErdIu7Ggqcz3jYpf09wMePF4V(url))
	import inVXFK46ET
	inVXFK46ET.q4qTJvuoQUzM3mZAtegy7IXdnb5wH(tiYp9ZdbFTQMcB4vWkHw6LXIAKrN5m,Q8Q0IDc6PLZajJAdTntKUmSGXz,'video',url)
	return
def PPqUACSE3VcGLTvw05jHy9JrFNW(search,url=qpFY4hAwolV3):
	search,LBylNhMdH6OV1qGk0tWiXFg3,showDialogs = LLm3sBXHPcnTDxdE5gt6hz0Wkp(search)
	if not search: search = jXgARlWMLVFUBnvmZwI2o5()
	if not search: return
	K7m9Otk3h1VYIN8rcP6jp2 = search.replace(mIsDke0oK5x1zSiOWbF9thGcA,'%20')
	if not url: url = ddBxj51bhNtaK23lDyGMVw+'/search?query='+K7m9Otk3h1VYIN8rcP6jp2
	else: url = url+'?title='+K7m9Otk3h1VYIN8rcP6jp2+'&genre=&year=&lang='
	c8U1BdtxOZS5FH(url,'search')
	return
def ZcGxoMbewJAYq1sSlV0(url):
	url = url.split('/smartemadfilter?')[0]
	IAW0sh6So3NpqM = WWrExJZS3Bj4anOAkpv7(KOyPvpEztYLaZRdMQJWxfTNFHbkg,'GET',url,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,'EGYBEST1-GET_FILTERS_BLOCKS-1st')
	cmWl9dOKHPIy41iaXuxrY = IAW0sh6So3NpqM.content
	YF4LRjr6TuagQk9o3PiMeIcHx = []
	pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('form-row(.*?)</form>',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	if pfRkcVlLmUxo561g0A8qSbO:
		mVYdjvor6i4wZ8 = pfRkcVlLmUxo561g0A8qSbO[0]
		YF4LRjr6TuagQk9o3PiMeIcHx = ePhmG1jLD6.findall('select name="(.*?)".*?value>(.*?)<(.*?)</select',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
		LL9IREeCKVltx3NmWcG1O5,Lgk6MQxwDv2zhuns5d108X3oREB,HLVwBWJ6mFa3ApoNlq178nuXgI = zip(*YF4LRjr6TuagQk9o3PiMeIcHx)
		YF4LRjr6TuagQk9o3PiMeIcHx = zip(Lgk6MQxwDv2zhuns5d108X3oREB,LL9IREeCKVltx3NmWcG1O5,HLVwBWJ6mFa3ApoNlq178nuXgI)
	return YF4LRjr6TuagQk9o3PiMeIcHx
def iiNGgPHcqX4tCAdRUz(mVYdjvor6i4wZ8):
	items = ePhmG1jLD6.findall('value="(.*?)">(.*?)<',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
	return items
def HHetQ2EqgIl0LARySMX(url):
	url = url.replace('/smartemadfilter?','?title=&')
	return url
ppwy5vRWM3ISY7UOeGkrLgN9Eic = ['year','lang','genre']
HpUcI0nODuvPeTSkt = ['year','lang','genre']
def R9pWUgVhBGLd2CQb0z(url,filter):
	url = url.split('/smartemadfilter?')[0]
	type,filter = filter.split('___',1)
	if filter==qpFY4hAwolV3: eAYm1EkvcnOzXWpFB68o9rglSQ0M5,M0jc2ZsJHPb1d3DCoyXIzmgt = qpFY4hAwolV3,qpFY4hAwolV3
	else: eAYm1EkvcnOzXWpFB68o9rglSQ0M5,M0jc2ZsJHPb1d3DCoyXIzmgt = filter.split('___')
	if type=='DEFINED_FILTER':
		if HpUcI0nODuvPeTSkt[0]+'=' not in eAYm1EkvcnOzXWpFB68o9rglSQ0M5: n1uwH0oJaGZ5WBd = HpUcI0nODuvPeTSkt[0]
		for a2jQ83ZCfcM5 in range(len(HpUcI0nODuvPeTSkt[0:-1])):
			if HpUcI0nODuvPeTSkt[a2jQ83ZCfcM5]+'=' in eAYm1EkvcnOzXWpFB68o9rglSQ0M5: n1uwH0oJaGZ5WBd = HpUcI0nODuvPeTSkt[a2jQ83ZCfcM5+1]
		OI4ExuWvaLU = eAYm1EkvcnOzXWpFB68o9rglSQ0M5+'&'+n1uwH0oJaGZ5WBd+'=0'
		vmTWLw30V2PFNC8DrRqI = M0jc2ZsJHPb1d3DCoyXIzmgt+'&'+n1uwH0oJaGZ5WBd+'=0'
		nxGqbf39mXPhwl1NtAsSYK = OI4ExuWvaLU.strip('&')+'___'+vmTWLw30V2PFNC8DrRqI.strip('&')
		ekvC3tHRVnZGM4uDsmE2pBc5x = ZX8DyBJbV4lNAG(M0jc2ZsJHPb1d3DCoyXIzmgt,'all')
		WSQlG8mDhqsNe = url+'/smartemadfilter?'+ekvC3tHRVnZGM4uDsmE2pBc5x
	elif type=='FULL_FILTER':
		Q7PrOdIzEeXgpT4HL38GK = ZX8DyBJbV4lNAG(eAYm1EkvcnOzXWpFB68o9rglSQ0M5,'modified_values')
		Q7PrOdIzEeXgpT4HL38GK = cTt4u6reEMKZqVLplmkNW7(Q7PrOdIzEeXgpT4HL38GK)
		if M0jc2ZsJHPb1d3DCoyXIzmgt: M0jc2ZsJHPb1d3DCoyXIzmgt = ZX8DyBJbV4lNAG(M0jc2ZsJHPb1d3DCoyXIzmgt,'all')
		if not M0jc2ZsJHPb1d3DCoyXIzmgt: WSQlG8mDhqsNe = url
		else: WSQlG8mDhqsNe = url+'/smartemadfilter?'+M0jc2ZsJHPb1d3DCoyXIzmgt
		hhpztscnBD1GP = HHetQ2EqgIl0LARySMX(WSQlG8mDhqsNe)
		x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+'أظهار قائمة الفيديو التي تم اختيارها ',hhpztscnBD1GP,771,qpFY4hAwolV3,'filter')
		x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+' [[   '+Q7PrOdIzEeXgpT4HL38GK+'   ]]',hhpztscnBD1GP,771,qpFY4hAwolV3,'filter')
		x3WSXnKyPhjqfHG2UrtQs('link',xupTj02bvy3O8R+' ===== ===== ===== '+fF4lt9zWYxXLKZVyAco82PgMj,qpFY4hAwolV3,9999)
	YF4LRjr6TuagQk9o3PiMeIcHx = ZcGxoMbewJAYq1sSlV0(url)
	dict = {}
	for name,CQlVpYyFN6bzXRBZIMxPWdn,mVYdjvor6i4wZ8 in YF4LRjr6TuagQk9o3PiMeIcHx:
		name = name.replace('كل ',qpFY4hAwolV3)
		items = iiNGgPHcqX4tCAdRUz(mVYdjvor6i4wZ8)
		if '=' not in WSQlG8mDhqsNe: WSQlG8mDhqsNe = url
		if type=='DEFINED_FILTER':
			if n1uwH0oJaGZ5WBd!=CQlVpYyFN6bzXRBZIMxPWdn: continue
			elif len(items)<2:
				if CQlVpYyFN6bzXRBZIMxPWdn==HpUcI0nODuvPeTSkt[-1]:
					hhpztscnBD1GP = HHetQ2EqgIl0LARySMX(WSQlG8mDhqsNe)
					c8U1BdtxOZS5FH(hhpztscnBD1GP)
				else: R9pWUgVhBGLd2CQb0z(WSQlG8mDhqsNe,'DEFINED_FILTER___'+nxGqbf39mXPhwl1NtAsSYK)
				return
			else:
				if CQlVpYyFN6bzXRBZIMxPWdn==HpUcI0nODuvPeTSkt[-1]:
					hhpztscnBD1GP = HHetQ2EqgIl0LARySMX(WSQlG8mDhqsNe)
					x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+'الجميع ',hhpztscnBD1GP,771,qpFY4hAwolV3,'filter')
				else: x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+'الجميع ',WSQlG8mDhqsNe,775,qpFY4hAwolV3,qpFY4hAwolV3,nxGqbf39mXPhwl1NtAsSYK)
		elif type=='FULL_FILTER':
			OI4ExuWvaLU = eAYm1EkvcnOzXWpFB68o9rglSQ0M5+'&'+CQlVpYyFN6bzXRBZIMxPWdn+'=0'
			vmTWLw30V2PFNC8DrRqI = M0jc2ZsJHPb1d3DCoyXIzmgt+'&'+CQlVpYyFN6bzXRBZIMxPWdn+'=0'
			nxGqbf39mXPhwl1NtAsSYK = OI4ExuWvaLU+'___'+vmTWLw30V2PFNC8DrRqI
			x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+'الجميع :'+name,WSQlG8mDhqsNe,774,qpFY4hAwolV3,qpFY4hAwolV3,nxGqbf39mXPhwl1NtAsSYK)
		dict[CQlVpYyFN6bzXRBZIMxPWdn] = {}
		for value,FLkeT4nCDqrQMmW6ZSlgyU5jIO32 in items:
			if not value: continue
			if FLkeT4nCDqrQMmW6ZSlgyU5jIO32 in YEIA19ehBwpNfPVzK: continue
			dict[CQlVpYyFN6bzXRBZIMxPWdn][value] = FLkeT4nCDqrQMmW6ZSlgyU5jIO32
			OI4ExuWvaLU = eAYm1EkvcnOzXWpFB68o9rglSQ0M5+'&'+CQlVpYyFN6bzXRBZIMxPWdn+'='+FLkeT4nCDqrQMmW6ZSlgyU5jIO32
			vmTWLw30V2PFNC8DrRqI = M0jc2ZsJHPb1d3DCoyXIzmgt+'&'+CQlVpYyFN6bzXRBZIMxPWdn+'='+value
			lJWPN5EDIbft92m6iCQqAYLjav4p = OI4ExuWvaLU+'___'+vmTWLw30V2PFNC8DrRqI
			title = FLkeT4nCDqrQMmW6ZSlgyU5jIO32+' :'#+dict[CQlVpYyFN6bzXRBZIMxPWdn]['0']
			title = FLkeT4nCDqrQMmW6ZSlgyU5jIO32+' :'+name
			if type=='FULL_FILTER': x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+title,url,774,qpFY4hAwolV3,qpFY4hAwolV3,lJWPN5EDIbft92m6iCQqAYLjav4p)
			elif type=='DEFINED_FILTER' and HpUcI0nODuvPeTSkt[-2]+'=' in eAYm1EkvcnOzXWpFB68o9rglSQ0M5:
				ekvC3tHRVnZGM4uDsmE2pBc5x = ZX8DyBJbV4lNAG(vmTWLw30V2PFNC8DrRqI,'modified_filters')
				WSQlG8mDhqsNe = url+'/smartemadfilter?'+ekvC3tHRVnZGM4uDsmE2pBc5x
				hhpztscnBD1GP = HHetQ2EqgIl0LARySMX(WSQlG8mDhqsNe)
				x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+title,hhpztscnBD1GP,771,qpFY4hAwolV3,'filter')
			elif type=='DEFINED_FILTER': x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+title,url,775,qpFY4hAwolV3,qpFY4hAwolV3,lJWPN5EDIbft92m6iCQqAYLjav4p)
	return
def ZX8DyBJbV4lNAG(bbaYxjcVnksy,mode):
	bbaYxjcVnksy = bbaYxjcVnksy.replace('=&','=0&')
	bbaYxjcVnksy = bbaYxjcVnksy.strip('&')
	J9ASCRhfiDyTB = {}
	if '=' in bbaYxjcVnksy:
		items = bbaYxjcVnksy.split('&')
		for lkd2oKvZF03qmgMbIfQ6cD in items:
			JJAsQ4pRYXPhqugN2to9TEzLIS,value = lkd2oKvZF03qmgMbIfQ6cD.split('=')
			J9ASCRhfiDyTB[JJAsQ4pRYXPhqugN2to9TEzLIS] = value
	LxOIqpMU7E1hPKH5fSzj2iW9v = qpFY4hAwolV3
	for key in ppwy5vRWM3ISY7UOeGkrLgN9Eic:
		if key in list(J9ASCRhfiDyTB.keys()): value = J9ASCRhfiDyTB[key]
		else: value = '0'
		if '%' not in value: value = BUKlErdIu7Ggqcz3jYpf09wMePF4V(value)
		if mode=='modified_values' and value!='0': LxOIqpMU7E1hPKH5fSzj2iW9v = LxOIqpMU7E1hPKH5fSzj2iW9v+' + '+value
		elif mode=='modified_filters' and value!='0': LxOIqpMU7E1hPKH5fSzj2iW9v = LxOIqpMU7E1hPKH5fSzj2iW9v+'&'+key+'='+value
		elif mode=='all': LxOIqpMU7E1hPKH5fSzj2iW9v = LxOIqpMU7E1hPKH5fSzj2iW9v+'&'+key+'='+value
	LxOIqpMU7E1hPKH5fSzj2iW9v = LxOIqpMU7E1hPKH5fSzj2iW9v.strip(' + ')
	LxOIqpMU7E1hPKH5fSzj2iW9v = LxOIqpMU7E1hPKH5fSzj2iW9v.strip('&')
	LxOIqpMU7E1hPKH5fSzj2iW9v = LxOIqpMU7E1hPKH5fSzj2iW9v.replace('=0','=')
	return LxOIqpMU7E1hPKH5fSzj2iW9v