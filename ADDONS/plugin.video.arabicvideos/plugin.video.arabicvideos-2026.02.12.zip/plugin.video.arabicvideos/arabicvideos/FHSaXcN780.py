# -*- coding: utf-8 -*-
import sys as TSRUP0dExYGQg
mgNMJhrjcq1xb = TSRUP0dExYGQg.version_info [0] == 2
lQJvf8UXo2de9gjCatY4yH = 2048
YuTB2OjotvlR = 7
def kk0DKyarxq9eS1zwGLMFQTZN35dj (neqP2if8IOJ50aNKcCBLrXdZk):
	global sWerUpk6nQwT7zY43
	vxdNQUujz7ZFV4rtOSK2 = ord (neqP2if8IOJ50aNKcCBLrXdZk [-1])
	yyshZX35KO7JodYjD9qVib6 = neqP2if8IOJ50aNKcCBLrXdZk [:-1]
	fuKReXJ3HPIAU7c = vxdNQUujz7ZFV4rtOSK2 % len (yyshZX35KO7JodYjD9qVib6)
	EEFQdvXog7LPC4Sie0jDkUKxn6M = yyshZX35KO7JodYjD9qVib6 [:fuKReXJ3HPIAU7c] + yyshZX35KO7JodYjD9qVib6 [fuKReXJ3HPIAU7c:]
	if mgNMJhrjcq1xb:
		Clh5YS0XPue68EgT4Uq17GL = unicode () .join ([unichr (ord (AsGVDZFgmuH06jviYrWXTz) - lQJvf8UXo2de9gjCatY4yH - (XvhDIL4ZpzaPs91WkoGnedCEA2rt + vxdNQUujz7ZFV4rtOSK2) % YuTB2OjotvlR) for XvhDIL4ZpzaPs91WkoGnedCEA2rt, AsGVDZFgmuH06jviYrWXTz in enumerate (EEFQdvXog7LPC4Sie0jDkUKxn6M)])
	else:
		Clh5YS0XPue68EgT4Uq17GL = str () .join ([chr (ord (AsGVDZFgmuH06jviYrWXTz) - lQJvf8UXo2de9gjCatY4yH - (XvhDIL4ZpzaPs91WkoGnedCEA2rt + vxdNQUujz7ZFV4rtOSK2) % YuTB2OjotvlR) for XvhDIL4ZpzaPs91WkoGnedCEA2rt, AsGVDZFgmuH06jviYrWXTz in enumerate (EEFQdvXog7LPC4Sie0jDkUKxn6M)])
	return eval (Clh5YS0XPue68EgT4Uq17GL)
qoBMmfAWpFlK70xw8ZRh4naJ,lljaEqwTVtmKsQcOrbXxS5hgNH,aXqWLoTdVgME=kk0DKyarxq9eS1zwGLMFQTZN35dj,kk0DKyarxq9eS1zwGLMFQTZN35dj,kk0DKyarxq9eS1zwGLMFQTZN35dj
UVa3fJw7k6KM,fWoVd0Bmtkx,tQMjXKCA5dN4xq3beVIzaEoWkFLg=aXqWLoTdVgME,lljaEqwTVtmKsQcOrbXxS5hgNH,qoBMmfAWpFlK70xw8ZRh4naJ
viRJWOC5jsYe84,Ie5s2cBtSfdHjzQ4rA9kYlo6D18,sjtU6GZQg5XC2pH4=tQMjXKCA5dN4xq3beVIzaEoWkFLg,fWoVd0Bmtkx,UVa3fJw7k6KM
LZWMikPEB81KSGyxfJtUsCA,rNdBKI74fAklnoCZ6,BRWqdruz2A0=sjtU6GZQg5XC2pH4,Ie5s2cBtSfdHjzQ4rA9kYlo6D18,viRJWOC5jsYe84
CC1eY6yWZUwf2TkRvnp7EJ0AimjHBX,qqzwE6imYG4c2xojI,N3flV6EJsD5CzS=BRWqdruz2A0,rNdBKI74fAklnoCZ6,LZWMikPEB81KSGyxfJtUsCA
UUDAiytEL76RTmMYsuIz5evXB,IaBhDMJc17302LgSvyxd,ddiCzu6yahj5RtTISMJ48sNnZBU=N3flV6EJsD5CzS,qqzwE6imYG4c2xojI,CC1eY6yWZUwf2TkRvnp7EJ0AimjHBX
dJHDqiKf12TXlIzSLkGUuxg4MBs3A,l1DZAt9XNQjqE7YOdrz,l32dnTEOU1skGKqeBtI9hmo=ddiCzu6yahj5RtTISMJ48sNnZBU,IaBhDMJc17302LgSvyxd,UUDAiytEL76RTmMYsuIz5evXB
zYvEaigKWjoq50pXBLDbGJkFc,iNc3KxwErnQ,V3VlkhgjEF4n1erPXHcC0NOsfwyAJ=l32dnTEOU1skGKqeBtI9hmo,l1DZAt9XNQjqE7YOdrz,dJHDqiKf12TXlIzSLkGUuxg4MBs3A
tR1krDGPpO025fghMT3a7UnYj,c2RKu0xG1eC8MiohyE,RlOvin8YIGC2KZXJPk9m0acrMobUex=V3VlkhgjEF4n1erPXHcC0NOsfwyAJ,iNc3KxwErnQ,zYvEaigKWjoq50pXBLDbGJkFc
YY8UDX3MJhb91AHw7fg,ee86G9ladLHVbh5mikzCo,mmV2nucZ5Lpl6FO1JMPEqGoQKW=RlOvin8YIGC2KZXJPk9m0acrMobUex,c2RKu0xG1eC8MiohyE,tR1krDGPpO025fghMT3a7UnYj
DaFZHsThGmd0zv6e,kYDaz79TFlXoR,DiJ8CMuYH1daWyjehfN0L=mmV2nucZ5Lpl6FO1JMPEqGoQKW,ee86G9ladLHVbh5mikzCo,YY8UDX3MJhb91AHw7fg
from pSfaryIjBo import *
Q8Q0IDc6PLZajJAdTntKUmSGXz = sjtU6GZQg5XC2pH4(u"ࠫࡈࡒࡅࡂࡐࡈࡖࠬࠀ")
wwSFijdVJn1QgHW = rNdBKI74fAklnoCZ6(u"ࠬࡥࡃࡍࡐࡢࠫࠁ")
vvOjftRM30cDL = RPbaxsNFVTwek5Kfv21DiJuzCnjMZp.path.join(ABbonyRm60ptY7ErO4UD19SXu,DiJ8CMuYH1daWyjehfN0L(u"࠭ࡴࡦ࡯ࡳࠫࠂ"))
bAlErF2ZgvWimGOXnJpfTSL = RPbaxsNFVTwek5Kfv21DiJuzCnjMZp.path.join(ABbonyRm60ptY7ErO4UD19SXu,iNc3KxwErnQ(u"ࠧࡱࡣࡦ࡯ࡦ࡭ࡥࡴࠩࠃ"))
ZZ71IKwvflo = RPbaxsNFVTwek5Kfv21DiJuzCnjMZp.path.join(ssQ5T7em6WrVwIGtXoxNKaBv48zHAM,DiJ8CMuYH1daWyjehfN0L(u"ࠨࡷࡶࡩࡷࡪࡡࡵࡣࠪࠄ"),mmV2nucZ5Lpl6FO1JMPEqGoQKW(u"ࠩࡗ࡬ࡺࡳࡢ࡯ࡣ࡬ࡰࡸ࠭ࠅ"))
WtnhR2EeN105AMSIJyO = mmV2nucZ5Lpl6FO1JMPEqGoQKW(u"ࠪ࠳ࡩࡧࡴࡢ࠱ࡶࡽࡸࡺࡥ࡮࠱ࡸࡷࡦ࡭ࡥࡴࡶࡤࡸࡸ࠭ࠆ")
FZWXjOn8EbYoxBeRl9y7fvM3 = YY8UDX3MJhb91AHw7fg(u"ࠫ࠴ࡪࡡࡵࡣ࠲ࡷࡾࡹࡴࡦ࡯࠲ࡨࡷࡵࡰࡣࡱࡻࠫࠇ")
LkTd81Um4Dgqy9ruzSa5oF = LZWMikPEB81KSGyxfJtUsCA(u"ࠬ࠵ࡤࡢࡶࡤ࠳ࡹࡵ࡭ࡣࡵࡷࡳࡳ࡫ࡳࠨࠈ")
CwgGtRHSZqBl = CC1eY6yWZUwf2TkRvnp7EJ0AimjHBX(u"࠭࠯ࡥࡣࡷࡥ࠴ࡲ࡯ࡨࡩࡨࡶࠬࠉ")
qLcJFYT6NdtkHARXwol9Mr = c2RKu0xG1eC8MiohyE(u"ࠧ࠰ࡦࡤࡸࡦ࠵࡬ࡰࡩࠪࠊ")
N9lpLo3rCM0de2 = tQMjXKCA5dN4xq3beVIzaEoWkFLg(u"ࠨ࠱ࡧࡥࡹࡧ࠯ࡢࡰࡵࠫࠋ")
iatIK4PbM8crk5Zy9oJgfBQz0qx72N = MZRS4rVzdoqwH
FAzQIDyWj2unSN93Uix = F8qeAKZjGRMNXimho2gntaV0
oz4BAaVlGTqZLW = cIFbpqOmxJWYGVkD
def vTNE2Ck1sGnugJYW8y39aLcSH64U(ZyiMa3BXVk2xWG0b):
	if   ZyiMa3BXVk2xWG0b==tR1krDGPpO025fghMT3a7UnYj(u"࠸࠶࠳ࣈ"): MOTjA5H9XFs = o16KsZGXEUykaf53j7dAJ94rWT()
	elif ZyiMa3BXVk2xWG0b==DiJ8CMuYH1daWyjehfN0L(u"࠹࠷࠵ࣉ"): MOTjA5H9XFs = EOJmze1pUvdCgVPLRt3(vvOjftRM30cDL,gBExoceumj4y8bFW9hY2aNMVSr,gBExoceumj4y8bFW9hY2aNMVSr);hjtsPY6qN5pgnX9aCiyZmR3d7MK2k(MOTjA5H9XFs)
	elif ZyiMa3BXVk2xWG0b==LZWMikPEB81KSGyxfJtUsCA(u"࠺࠸࠷࣊"): MOTjA5H9XFs = EOJmze1pUvdCgVPLRt3(bAlErF2ZgvWimGOXnJpfTSL,gBExoceumj4y8bFW9hY2aNMVSr,gBExoceumj4y8bFW9hY2aNMVSr);hjtsPY6qN5pgnX9aCiyZmR3d7MK2k(MOTjA5H9XFs)
	elif ZyiMa3BXVk2xWG0b==sjtU6GZQg5XC2pH4(u"࠻࠹࠹࣋"): MOTjA5H9XFs = EOJmze1pUvdCgVPLRt3(ZZ71IKwvflo,ag8rjZo1Vz4IPdcOT,gBExoceumj4y8bFW9hY2aNMVSr);hjtsPY6qN5pgnX9aCiyZmR3d7MK2k(MOTjA5H9XFs)
	elif ZyiMa3BXVk2xWG0b==lljaEqwTVtmKsQcOrbXxS5hgNH(u"࠼࠺࠴࣌"): MOTjA5H9XFs = itFcjX8GyQprb4IDAzwJq2fhS(gBExoceumj4y8bFW9hY2aNMVSr);hjtsPY6qN5pgnX9aCiyZmR3d7MK2k(MOTjA5H9XFs)
	elif ZyiMa3BXVk2xWG0b==IaBhDMJc17302LgSvyxd(u"࠽࠴࠶࣍"): MOTjA5H9XFs = U6ZfAs2Ke0G318tWlXjaNyS(gBExoceumj4y8bFW9hY2aNMVSr);hjtsPY6qN5pgnX9aCiyZmR3d7MK2k(MOTjA5H9XFs)
	elif ZyiMa3BXVk2xWG0b==RlOvin8YIGC2KZXJPk9m0acrMobUex(u"࠷࠵࠸࣎"): MOTjA5H9XFs = vvEItel7mRYbLuj(gBExoceumj4y8bFW9hY2aNMVSr);hjtsPY6qN5pgnX9aCiyZmR3d7MK2k(MOTjA5H9XFs)
	elif ZyiMa3BXVk2xWG0b==UUDAiytEL76RTmMYsuIz5evXB(u"࠸࠷࠳࣏"): MOTjA5H9XFs = ocKEY7eL0iSlIxPnA()
	elif ZyiMa3BXVk2xWG0b==zYvEaigKWjoq50pXBLDbGJkFc(u"࠹࠸࠵࣐"): MOTjA5H9XFs = EOJmze1pUvdCgVPLRt3(WtnhR2EeN105AMSIJyO,ag8rjZo1Vz4IPdcOT,gBExoceumj4y8bFW9hY2aNMVSr);hjtsPY6qN5pgnX9aCiyZmR3d7MK2k(MOTjA5H9XFs)
	elif ZyiMa3BXVk2xWG0b==mmV2nucZ5Lpl6FO1JMPEqGoQKW(u"࠺࠹࠷࣑"): MOTjA5H9XFs = EOJmze1pUvdCgVPLRt3(FZWXjOn8EbYoxBeRl9y7fvM3,ag8rjZo1Vz4IPdcOT,gBExoceumj4y8bFW9hY2aNMVSr);hjtsPY6qN5pgnX9aCiyZmR3d7MK2k(MOTjA5H9XFs)
	elif ZyiMa3BXVk2xWG0b==CC1eY6yWZUwf2TkRvnp7EJ0AimjHBX(u"࠻࠺࠹࣒"): MOTjA5H9XFs = EOJmze1pUvdCgVPLRt3(LkTd81Um4Dgqy9ruzSa5oF,ag8rjZo1Vz4IPdcOT,gBExoceumj4y8bFW9hY2aNMVSr);hjtsPY6qN5pgnX9aCiyZmR3d7MK2k(MOTjA5H9XFs)
	elif ZyiMa3BXVk2xWG0b==ddiCzu6yahj5RtTISMJ48sNnZBU(u"࠼࠻࠴࣓"): MOTjA5H9XFs = EOJmze1pUvdCgVPLRt3(CwgGtRHSZqBl,ag8rjZo1Vz4IPdcOT,gBExoceumj4y8bFW9hY2aNMVSr);hjtsPY6qN5pgnX9aCiyZmR3d7MK2k(MOTjA5H9XFs)
	elif ZyiMa3BXVk2xWG0b==dJHDqiKf12TXlIzSLkGUuxg4MBs3A(u"࠽࠵࠶ࣔ"): MOTjA5H9XFs = EOJmze1pUvdCgVPLRt3(qLcJFYT6NdtkHARXwol9Mr,ag8rjZo1Vz4IPdcOT,gBExoceumj4y8bFW9hY2aNMVSr);hjtsPY6qN5pgnX9aCiyZmR3d7MK2k(MOTjA5H9XFs)
	elif ZyiMa3BXVk2xWG0b==CC1eY6yWZUwf2TkRvnp7EJ0AimjHBX(u"࠷࠶࠸ࣕ"): MOTjA5H9XFs = EOJmze1pUvdCgVPLRt3(N9lpLo3rCM0de2,ag8rjZo1Vz4IPdcOT,gBExoceumj4y8bFW9hY2aNMVSr);hjtsPY6qN5pgnX9aCiyZmR3d7MK2k(MOTjA5H9XFs)
	elif ZyiMa3BXVk2xWG0b==YY8UDX3MJhb91AHw7fg(u"࠸࠷࠺ࣖ"): MOTjA5H9XFs = BBU0EjAJLXHfo18CKg6FQ(gBExoceumj4y8bFW9hY2aNMVSr);hjtsPY6qN5pgnX9aCiyZmR3d7MK2k(MOTjA5H9XFs)
	elif ZyiMa3BXVk2xWG0b==mmV2nucZ5Lpl6FO1JMPEqGoQKW(u"࠹࠸࠼ࣗ"): MOTjA5H9XFs = qODQgEMK95ebfToyZAdm();hjtsPY6qN5pgnX9aCiyZmR3d7MK2k(MOTjA5H9XFs)
	elif ZyiMa3BXVk2xWG0b==mmV2nucZ5Lpl6FO1JMPEqGoQKW(u"࠴࠴࠽࠶ࣘ"): MOTjA5H9XFs = BSrmY6nk1a29dxAoGiCpgbMeUEILjR()
	elif ZyiMa3BXVk2xWG0b==ee86G9ladLHVbh5mikzCo(u"࠵࠵࠾࠱ࣙ"): MOTjA5H9XFs = LXTFozR0Ew6yDBKc7bH1qrA8(gBExoceumj4y8bFW9hY2aNMVSr);hjtsPY6qN5pgnX9aCiyZmR3d7MK2k(MOTjA5H9XFs)
	elif ZyiMa3BXVk2xWG0b==DaFZHsThGmd0zv6e(u"࠶࠶࠸࠳ࣚ"): MOTjA5H9XFs = akzAYuG1n2Csx4PbjDR();hjtsPY6qN5pgnX9aCiyZmR3d7MK2k(MOTjA5H9XFs)
	elif ZyiMa3BXVk2xWG0b==UVa3fJw7k6KM(u"࠷࠰࠹࠵ࣛ"): MOTjA5H9XFs = LD7WXhZtwn9yHGVxFPN();hjtsPY6qN5pgnX9aCiyZmR3d7MK2k(MOTjA5H9XFs)
	elif ZyiMa3BXVk2xWG0b==BRWqdruz2A0(u"࠱࠱࠺࠷ࣜ"): MOTjA5H9XFs = fzkW5ctBNuasJZU();hjtsPY6qN5pgnX9aCiyZmR3d7MK2k(MOTjA5H9XFs)
	elif ZyiMa3BXVk2xWG0b==Ie5s2cBtSfdHjzQ4rA9kYlo6D18(u"࠲࠲࠻࠹ࣝ"): MOTjA5H9XFs = nRVAZc4Dp8PSrGU3xBk()
	elif ZyiMa3BXVk2xWG0b==BRWqdruz2A0(u"࠳࠳࠼࠻ࣞ"): MOTjA5H9XFs = FawjZCEXnus6TJ3iy9PYWGK8tIHzg1()
	else: MOTjA5H9XFs = ag8rjZo1Vz4IPdcOT
	return MOTjA5H9XFs
def FawjZCEXnus6TJ3iy9PYWGK8tIHzg1():
	aHgp7ChWjV32 = lljaEqwTVtmKsQcOrbXxS5hgNH(u"࠴࠴࠷࠺ࣟ")*lljaEqwTVtmKsQcOrbXxS5hgNH(u"࠴࠴࠷࠺ࣟ")
	J8QWl5zrS0FHyhBtqPK2kOCi3djXVE = O8YxFVZUhBXd6wDcb()//aHgp7ChWjV32
	c8yldswIVUEnNkM2Y = J8QWl5zrS0FHyhBtqPK2kOCi3djXVE<l32dnTEOU1skGKqeBtI9hmo(u"࠹࠵࣠")
	size = xupTj02bvy3O8R+tR1krDGPpO025fghMT3a7UnYj(u"ࠩ็ำ๏้ࠠๆีสัฮࠦแศำ฽อࠥࠦࠧࠌ")+str(J8QWl5zrS0FHyhBtqPK2kOCi3djXVE)+CC1eY6yWZUwf2TkRvnp7EJ0AimjHBX(u"ࠪࠤ๋๊ࠥอษหห๏ะࠧࠍ")+fF4lt9zWYxXLKZVyAco82PgMj
	if c8yldswIVUEnNkM2Y:
		LLvyStW429DEZKlA(j8gFJIMYPoBzcCvG9T,N3flV6EJsD5CzS(u"ࠫࡈࡎࡅࡄࡍࡢࡈࡎ࡙ࡋࡠࡕࡓࡅࡈࡋࠠࠡࠢࡖࡘࡔࡘࡁࡈࡇࠣࡍࡘࠦࡆࡖࡎࡏࠤࠥࠦࠧࠎ")+str(J8QWl5zrS0FHyhBtqPK2kOCi3djXVE)+RlOvin8YIGC2KZXJPk9m0acrMobUex(u"ࠬࠦࡍࡃࠢࠤࠥࠬࠏ"))
		iG7Rz2kmn0x1yLNMV3u8O(qpFY4hAwolV3,qpFY4hAwolV3,GLTtERWbHnFuy4PCp,rNdBKI74fAklnoCZ6(u"࠭ๅิษะอࠥอไหะี๎๋ࠦแ๋ࠢฯ๋ฬุใࠡลุฬาะࠠๆ็อ่หฯࠠ࠯࠰ࠣ์์ึวࠡ์ึฬอࠦๅีษๆ่้ࠥห๋ำฬࠤๆ๐ࠠหึ฽๎้ࠦวๅฮ๊หื่ࠦหึ฽๎้ࠦใ้ัํࠤํะิ฻์็ࠤอืๆศ็ฯࠤ฾๋วะࠢ࠱࠲ࠥอๆหࠢหัฬาษࠡว็ํࠥะๆู์ไࠤัํวำๅࠣ์ฯ์ื๋ใࠣ็ํี๊๊ࠡอ๊฽๐แ้ࠡำหࠥอไษำ้ห๊า࡜࡯࡞ࡱࠫࠐ")+size)
	else: iG7Rz2kmn0x1yLNMV3u8O(qpFY4hAwolV3,qpFY4hAwolV3,GLTtERWbHnFuy4PCp,DaFZHsThGmd0zv6e(u"ࠧๆีสัฮࠦวๅฬัึ๏์ࠠโ์ࠣะ์อาไࠢฯ๎ิฯ࡜࡯࡞ࡱࠫࠑ")+size)
	return c8yldswIVUEnNkM2Y
def hjtsPY6qN5pgnX9aCiyZmR3d7MK2k(yybfMXcSVHaGio9xpuEDZwLl4e):
	if yybfMXcSVHaGio9xpuEDZwLl4e: E2E18vJ4hLaZpuWSfoMlY9yBzj6b(gBExoceumj4y8bFW9hY2aNMVSr)
	return
def nRVAZc4Dp8PSrGU3xBk():
	x3WSXnKyPhjqfHG2UrtQs(BRWqdruz2A0(u"ࠨ࡮࡬ࡲࡰ࠭ࠒ"),fWoVd0Bmtkx(u"ࠩไัฺࠦๅิษะอࠥอไหะี๎๋࠭ࠓ"),qpFY4hAwolV3,DaFZHsThGmd0zv6e(u"࠶࠶࠸࠷࣡"))
	x3WSXnKyPhjqfHG2UrtQs(ddiCzu6yahj5RtTISMJ48sNnZBU(u"ࠪࡪࡴࡲࡤࡦࡴࠪࠔ"),mmV2nucZ5Lpl6FO1JMPEqGoQKW(u"ࠫฯ์ุ๋ใࠣห้า็ศิࠪࠕ"),qpFY4hAwolV3,ddiCzu6yahj5RtTISMJ48sNnZBU(u"࠽࠵࠱࣢"))
	x3WSXnKyPhjqfHG2UrtQs(sjtU6GZQg5XC2pH4(u"ࠬ࡬࡯࡭ࡦࡨࡶࠬࠖ"),LZWMikPEB81KSGyxfJtUsCA(u"࠭สแ่฻๎ๆࠦใแ๊า๎ࠬࠗ"),qpFY4hAwolV3,V3VlkhgjEF4n1erPXHcC0NOsfwyAJ(u"࠷࠵࠲ࣣ"))
	x3WSXnKyPhjqfHG2UrtQs(qoBMmfAWpFlK70xw8ZRh4naJ(u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ࠘"),RlOvin8YIGC2KZXJPk9m0acrMobUex(u"ࠨฬ้฼๏็ࠠศๆหี๋อๅอࠩ࠙"),qpFY4hAwolV3,tR1krDGPpO025fghMT3a7UnYj(u"࠲࠲࠻࠴ࣤ"))
	return
def BSrmY6nk1a29dxAoGiCpgbMeUEILjR():
	D6vV0OxCcteLi1aXFTB2IbEpy,qOFUGe0lEDu4SKYk68VTCsH = B817EpDgwvKybXn6JhiQ43rT0HYUc(iatIK4PbM8crk5Zy9oJgfBQz0qx72N)
	lQvuJfRI1hi8aP7sBrCGmTq,zcxrwuK5T0pmdGXtM = B817EpDgwvKybXn6JhiQ43rT0HYUc(FAzQIDyWj2unSN93Uix)
	ChDPLoAVgWj3Xp4e6d8IsvT1t7m5yU,YrTBZHeO42v = e2YrFAdw9WBl8740uPKUcGCbL(oz4BAaVlGTqZLW)
	AQ8zYcPUorMOGWeT6Kl,mkTZpj5DnX3oq9A8GucKLEdBVhRQl = D6vV0OxCcteLi1aXFTB2IbEpy+lQvuJfRI1hi8aP7sBrCGmTq+ChDPLoAVgWj3Xp4e6d8IsvT1t7m5yU,qOFUGe0lEDu4SKYk68VTCsH+zcxrwuK5T0pmdGXtM+YrTBZHeO42v
	owkcGMKPsR24z790 = viRJWOC5jsYe84(u"ࠩࠣࠬࠬࠚ")+kfxKmu7cQhe(D6vV0OxCcteLi1aXFTB2IbEpy)+lljaEqwTVtmKsQcOrbXxS5hgNH(u"ࠪࠤ࠲ࠦࠧࠛ")+str(qOFUGe0lEDu4SKYk68VTCsH)+YY8UDX3MJhb91AHw7fg(u"ࠫࠥ࡬ࡩ࡭ࡧࡶ࠭ࠬࠜ")
	TRw3lZxuU0hiKtJa = LZWMikPEB81KSGyxfJtUsCA(u"ࠬࠦࠨࠨࠝ")+kfxKmu7cQhe(lQvuJfRI1hi8aP7sBrCGmTq)+YY8UDX3MJhb91AHw7fg(u"࠭ࠠ࠮ࠢࠪࠞ")+str(zcxrwuK5T0pmdGXtM)+BRWqdruz2A0(u"ࠧࠡࡨ࡬ࡰࡪࡹࠩࠨࠟ")
	AiDhS4QCJKxgU = LZWMikPEB81KSGyxfJtUsCA(u"ࠨࠢࠫࠫࠠ")+kfxKmu7cQhe(ChDPLoAVgWj3Xp4e6d8IsvT1t7m5yU)+qoBMmfAWpFlK70xw8ZRh4naJ(u"ࠩࠣ࠱ࠥ࠭ࠡ")+str(YrTBZHeO42v)+CC1eY6yWZUwf2TkRvnp7EJ0AimjHBX(u"ࠪࠤ࡫࡯࡬ࡦࡵࠬࠫࠢ")
	wcgKBRM9eIjpSbCPhN = l1DZAt9XNQjqE7YOdrz(u"ࠫࠥ࠮ࠧࠣ")+kfxKmu7cQhe(AQ8zYcPUorMOGWeT6Kl)+BRWqdruz2A0(u"ࠬࠦ࠭ࠡࠩࠤ")+str(mkTZpj5DnX3oq9A8GucKLEdBVhRQl)+lljaEqwTVtmKsQcOrbXxS5hgNH(u"࠭ࠠࡧ࡫࡯ࡩࡸ࠯ࠧࠥ")
	x3WSXnKyPhjqfHG2UrtQs(V3VlkhgjEF4n1erPXHcC0NOsfwyAJ(u"ࠧ࡭࡫ࡱ࡯ࠬࠦ"),wwSFijdVJn1QgHW+rNdBKI74fAklnoCZ6(u"ࠨ็ึัࠥอไอ็ํ฽ࠬࠧ")+wcgKBRM9eIjpSbCPhN,qpFY4hAwolV3,dJHDqiKf12TXlIzSLkGUuxg4MBs3A(u"࠳࠳࠼࠹ࣥ"))
	x3WSXnKyPhjqfHG2UrtQs(ee86G9ladLHVbh5mikzCo(u"ࠩ࡯࡭ࡳࡱࠧࠨ"),xupTj02bvy3O8R+ddiCzu6yahj5RtTISMJ48sNnZBU(u"ࠪࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡࠩࠩ")+fF4lt9zWYxXLKZVyAco82PgMj,qpFY4hAwolV3,tQMjXKCA5dN4xq3beVIzaEoWkFLg(u"࠼࠽࠾࠿ࣦ"))
	x3WSXnKyPhjqfHG2UrtQs(c2RKu0xG1eC8MiohyE(u"ࠫࡱ࡯࡮࡬ࠩࠪ"),wwSFijdVJn1QgHW+tQMjXKCA5dN4xq3beVIzaEoWkFLg(u"๋ࠬำฮุࠢ์ึࠦวๅๅอหอฯࠧࠫ")+owkcGMKPsR24z790,qpFY4hAwolV3,zYvEaigKWjoq50pXBLDbGJkFc(u"࠵࠵࠾࠱ࣧ"))
	x3WSXnKyPhjqfHG2UrtQs(UVa3fJw7k6KM(u"࠭࡬ࡪࡰ࡮ࠫࠬ"),wwSFijdVJn1QgHW+IaBhDMJc17302LgSvyxd(u"ࠧๆีะࠤ่อิࠡษ็ฬึ์วๆฮࠪ࠭")+TRw3lZxuU0hiKtJa,qpFY4hAwolV3,V3VlkhgjEF4n1erPXHcC0NOsfwyAJ(u"࠶࠶࠸࠳ࣨ"))
	x3WSXnKyPhjqfHG2UrtQs(l1DZAt9XNQjqE7YOdrz(u"ࠨ࡮࡬ࡲࡰ࠭࠮"),wwSFijdVJn1QgHW+CC1eY6yWZUwf2TkRvnp7EJ0AimjHBX(u"่ࠩืาࠦลฺัสำฬะࠠศๆหี๋อๅอࠩ࠯")+AiDhS4QCJKxgU,qpFY4hAwolV3,mmV2nucZ5Lpl6FO1JMPEqGoQKW(u"࠷࠰࠹࠵ࣩ"))
	x3WSXnKyPhjqfHG2UrtQs(sjtU6GZQg5XC2pH4(u"ࠪࡰ࡮ࡴ࡫ࠨ࠰"),wwSFijdVJn1QgHW+fWoVd0Bmtkx(u"ࠫฯ฻แ๋ำࠣห้ฮั็ษ่ะࠬ࠱")+wcgKBRM9eIjpSbCPhN,qpFY4hAwolV3,zYvEaigKWjoq50pXBLDbGJkFc(u"࠱࠱࠺࠷࣪"))
	return
def fzkW5ctBNuasJZU():
	yybfMXcSVHaGio9xpuEDZwLl4e = ag8rjZo1Vz4IPdcOT
	o4oUxD3u18K59ghHIY = VVpbtSKYUGXrNMwAWFo9IOjZP(qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,GLTtERWbHnFuy4PCp,zYvEaigKWjoq50pXBLDbGJkFc(u"ࠬํไࠡฬิ๎ิࠦแฺๆสࠤู๊อࠡฮ่๎฾ࠦลฺัสำฬะࠠศๆหี๋อๅอࠢ࠱࠲ࠥ๎ๅิฯࠣะ๊๐ูࠡ็็ๅฬะࠠศๆหี๋อๅอࠢส่็ี๊ๆหࠣ࠲࠳ࠦอห๋ࠣ๎฾๎ฯࠡษ็ฬึ์วๆฮࠣษ้๏ࠠฮษ็อࠥอไึใิࠤ࠳࠴๋ࠠ฻้๎ࠥำวๅหࠣ์฻฿๊สูࠢฬ฼ࠦวๅ็ุ๊฾ࠦ࠮࠯ࠢํ฽๋๐ࠠศๆะห้ฯࠠศๆอ๎ࠥ๎ึฺ้สࠤฬ๊ๅษำ่ะ๊ࠥไษำ้ห๊าࠠ࠯࠰๋ࠣีํࠠศๆ฼้้๐ษࠡฬอ้ࠥฮๅิฯ้ࠣั๊ฯࠡๅสุࠥอไษำ้ห๊า้ࠠ็ึั๋ࠥไโࠢศ฽ิอฯศฬࠣห้ฮั็ษ่ะࠥลࠡࠨ࠲"))
	if o4oUxD3u18K59ghHIY:
		YfMSckQnVDPxU724r1gNKmz0 = LD7WXhZtwn9yHGVxFPN()
		OG3S6bN0tXmxYEITcZQ89 = EOJmze1pUvdCgVPLRt3(F8qeAKZjGRMNXimho2gntaV0,gBExoceumj4y8bFW9hY2aNMVSr,ag8rjZo1Vz4IPdcOT)
		yybfMXcSVHaGio9xpuEDZwLl4e = YfMSckQnVDPxU724r1gNKmz0 and OG3S6bN0tXmxYEITcZQ89
		if yybfMXcSVHaGio9xpuEDZwLl4e: iG7Rz2kmn0x1yLNMV3u8O(qpFY4hAwolV3,qpFY4hAwolV3,GLTtERWbHnFuy4PCp,DaFZHsThGmd0zv6e(u"࠭ฬ๋ัࠣ࠲࠳ࠦๆอฯอࠤ฾๋ไ๋หุ้ࠣำࠠศๆ่่ๆอสࠡษ็ๆิ๐ๅสࠢ็่อืๆศ็ฯࠤ࠳࠴้ࠠ฻สำࠥอไษำ้ห๊าࠠฦๆ์ࠤํ฼ู๋หࠣห้฻แาࠢ࠱࠲ࠥ๎ึฺ์ฬࠤ฻ฮืࠡษ็ฺ้์ูࠨ࠳"))
		else: iG7Rz2kmn0x1yLNMV3u8O(qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,aXqWLoTdVgME(u"ࠧๅๆฦืๆࠦ࠮࠯ࠢไุ้ะฺࠠ็็๎ฮࠦสึใํีࠥอไษำ้ห๊า้ࠠว฼หิะ็ࠡว็ํࠥ๎ึฺ์ฬࠤ฻ฮืࠡษ็ฺ้์ูࠨ࠴"))
	return yybfMXcSVHaGio9xpuEDZwLl4e
def akzAYuG1n2Csx4PbjDR():
	import t5tWekJ6XG
	t5tWekJ6XG.hhL6vp9bzkHJQ5qjD1C()
	zlQAfuT2Z7nKhGdXs = ag8rjZo1Vz4IPdcOT
	o4oUxD3u18K59ghHIY = VVpbtSKYUGXrNMwAWFo9IOjZP(sjtU6GZQg5XC2pH4(u"ࠨࡥࡨࡲࡹ࡫ࡲࠨ࠵"),qpFY4hAwolV3,qpFY4hAwolV3,BRWqdruz2A0(u"๊่ࠩࠥะั๋ัุ้ࠣำࠠอ็ํ฽ࠥอไไษืࠤฤ࠭࠶"),UUDAiytEL76RTmMYsuIz5evXB(u"ࠪห้้วีࠢํืึ฿ฺࠠ็็ࠤฬ๊ศา่ส้ั่ࠦๆีะ๋ࠥ๐ู๋ัࠣืาฮࠠศๆุๅาอสࠡ็้ࠤฬ๊ล็ฬิ๊ฯูࠦ็ัࠣห้ำวอหࠣษ้๐็ศࠢ࠱࠲ࠥ฿ไๆษࠣว๋ࠦวๅ็ึัࠥ๐สๆࠢอ่็อฦ๋ษࠣ฽๋ีࠠศ่อ๋ฬวฺࠠ็ิࠤฬ๊ีโฯสฮࠥ࠴࠮๊ࠡฦ๎฻อࠠศๆ่ืาࠦไศࠢํฺึ่ࠦๆ็ๆ๊ࠥ๐อๅࠢห฽฻ࠦวๅ็ืห่๊ࠧ࠷"))
	if o4oUxD3u18K59ghHIY==mZi0S72jGoHpLO:
		zlQAfuT2Z7nKhGdXs = EOJmze1pUvdCgVPLRt3(F8qeAKZjGRMNXimho2gntaV0,gBExoceumj4y8bFW9hY2aNMVSr,ag8rjZo1Vz4IPdcOT)
		if zlQAfuT2Z7nKhGdXs: iG7Rz2kmn0x1yLNMV3u8O(qpFY4hAwolV3,qpFY4hAwolV3,GLTtERWbHnFuy4PCp,Ie5s2cBtSfdHjzQ4rA9kYlo6D18(u"ࠫา๐ฯࠡ࠰࠱ࠤ๋าอหࠢ฼้้๐ษࠡ็ึั๋ࠥฬๅัࠣ็ฬฺࠠศๆหี๋อๅอࠩ࠸"))
		else: iG7Rz2kmn0x1yLNMV3u8O(qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,IaBhDMJc17302LgSvyxd(u"๊ࠬไฤีไࠤ࠳࠴ࠠโึ็ฮࠥ฿ๅๅ์ฬࠤู๊อࠡ็ฯ่ิࠦใศึࠣห้ฮั็ษ่ะࠬ࠹"))
	return zlQAfuT2Z7nKhGdXs
def LD7WXhZtwn9yHGVxFPN():
	zlQAfuT2Z7nKhGdXs = ag8rjZo1Vz4IPdcOT
	o4oUxD3u18K59ghHIY = VVpbtSKYUGXrNMwAWFo9IOjZP(tQMjXKCA5dN4xq3beVIzaEoWkFLg(u"࠭ࡣࡦࡰࡷࡩࡷ࠭࠺"),qpFY4hAwolV3,qpFY4hAwolV3,RlOvin8YIGC2KZXJPk9m0acrMobUex(u"ࠧิฦส่ࠬ࠻"),qoBMmfAWpFlK70xw8ZRh4naJ(u"ࠨ้็ࠤศ์สࠡ็อว่ี้ࠠฬิ๎ิࠦๅิฯࠣ์ฯ฻แ๋ำࠣะ๊๐ูࠡว฼ำฬีวหࠢหี๋อๅอࠢ฼้ฬีࠠๅๆไ๎ิ๐่่ษอࠤฬู๊าสํอࠥ࠴ࠠฮ์ฮࠤฯ฿่ะࠢฯ้๏฿ࠠศๆศ฽ิอฯศฬࠣษ้๏ุ้ࠠ฼๎ฮࠦสฬสํฮࠥอไษำ้ห๊าࠠภࠩ࠼"))
	if o4oUxD3u18K59ghHIY==mZi0S72jGoHpLO:
		try:
			RPbaxsNFVTwek5Kfv21DiJuzCnjMZp.remove(cIFbpqOmxJWYGVkD)
			zlQAfuT2Z7nKhGdXs = gBExoceumj4y8bFW9hY2aNMVSr
		except: pass
		if zlQAfuT2Z7nKhGdXs: iG7Rz2kmn0x1yLNMV3u8O(qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,l32dnTEOU1skGKqeBtI9hmo(u"ࠩอ้ࠥฮๆอษะࠤู๊อ๊ࠡอูๆ๐ัࠡ็็ๅࠥหูะษาหฯࠦศา่ส้ัูࠦๆษาࠤ้๊แ๋ัํ์์อสࠡษ็฽ึฮ๊สࠩ࠽"))
		else: iG7Rz2kmn0x1yLNMV3u8O(qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,viRJWOC5jsYe84(u"่้ࠪษำโࠢไุ้ะฺࠠ็็๎ฮࠦๅิฯ้้ࠣ็ࠠศๆศ฽ิอฯศฬࠪ࠾"))
	return zlQAfuT2Z7nKhGdXs
def BSrmY6nk1a29dxAoGiCpgbMeUEILjR():
	D6vV0OxCcteLi1aXFTB2IbEpy,qOFUGe0lEDu4SKYk68VTCsH = B817EpDgwvKybXn6JhiQ43rT0HYUc(iatIK4PbM8crk5Zy9oJgfBQz0qx72N)
	lQvuJfRI1hi8aP7sBrCGmTq,zcxrwuK5T0pmdGXtM = B817EpDgwvKybXn6JhiQ43rT0HYUc(FAzQIDyWj2unSN93Uix)
	ChDPLoAVgWj3Xp4e6d8IsvT1t7m5yU,YrTBZHeO42v = e2YrFAdw9WBl8740uPKUcGCbL(oz4BAaVlGTqZLW)
	AQ8zYcPUorMOGWeT6Kl,mkTZpj5DnX3oq9A8GucKLEdBVhRQl = D6vV0OxCcteLi1aXFTB2IbEpy+lQvuJfRI1hi8aP7sBrCGmTq+ChDPLoAVgWj3Xp4e6d8IsvT1t7m5yU,qOFUGe0lEDu4SKYk68VTCsH+zcxrwuK5T0pmdGXtM+YrTBZHeO42v
	owkcGMKPsR24z790 = ee86G9ladLHVbh5mikzCo(u"ࠫࠥ࠮ࠧ࠿")+kfxKmu7cQhe(D6vV0OxCcteLi1aXFTB2IbEpy)+N3flV6EJsD5CzS(u"ࠬࠦ࠭ࠡࠩࡀ")+str(qOFUGe0lEDu4SKYk68VTCsH)+DiJ8CMuYH1daWyjehfN0L(u"࠭ࠠࡧ࡫࡯ࡩࡸ࠯ࠧࡁ")
	TRw3lZxuU0hiKtJa = sjtU6GZQg5XC2pH4(u"ࠧࠡࠪࠪࡂ")+kfxKmu7cQhe(lQvuJfRI1hi8aP7sBrCGmTq)+DiJ8CMuYH1daWyjehfN0L(u"ࠨࠢ࠰ࠤࠬࡃ")+str(zcxrwuK5T0pmdGXtM)+RlOvin8YIGC2KZXJPk9m0acrMobUex(u"ࠩࠣࡪ࡮ࡲࡥࡴࠫࠪࡄ")
	AiDhS4QCJKxgU = N3flV6EJsD5CzS(u"ࠪࠤ࠭࠭ࡅ")+kfxKmu7cQhe(ChDPLoAVgWj3Xp4e6d8IsvT1t7m5yU)+sjtU6GZQg5XC2pH4(u"ࠫࠥ࠳ࠠࠨࡆ")+str(YrTBZHeO42v)+DaFZHsThGmd0zv6e(u"ࠬࠦࡦࡪ࡮ࡨࡷ࠮࠭ࡇ")
	wcgKBRM9eIjpSbCPhN = YY8UDX3MJhb91AHw7fg(u"࠭ࠠࠩࠩࡈ")+kfxKmu7cQhe(AQ8zYcPUorMOGWeT6Kl)+YY8UDX3MJhb91AHw7fg(u"ࠧࠡ࠯ࠣࠫࡉ")+str(mkTZpj5DnX3oq9A8GucKLEdBVhRQl)+Ie5s2cBtSfdHjzQ4rA9kYlo6D18(u"ࠨࠢࡩ࡭ࡱ࡫ࡳࠪࠩࡊ")
	x3WSXnKyPhjqfHG2UrtQs(BRWqdruz2A0(u"ࠩ࡯࡭ࡳࡱࠧࡋ"),wwSFijdVJn1QgHW+rNdBKI74fAklnoCZ6(u"ุ้ࠪำࠠศๆฯ้๏฿ࠧࡌ")+wcgKBRM9eIjpSbCPhN,qpFY4hAwolV3,DaFZHsThGmd0zv6e(u"࠲࠲࠻࠸࣫"))
	x3WSXnKyPhjqfHG2UrtQs(l32dnTEOU1skGKqeBtI9hmo(u"ࠫࡱ࡯࡮࡬ࠩࡍ"),xupTj02bvy3O8R+rNdBKI74fAklnoCZ6(u"ࠬࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࠫࡎ")+fF4lt9zWYxXLKZVyAco82PgMj,qpFY4hAwolV3,viRJWOC5jsYe84(u"࠻࠼࠽࠾࣬"))
	x3WSXnKyPhjqfHG2UrtQs(l1DZAt9XNQjqE7YOdrz(u"࠭࡬ࡪࡰ࡮ࠫࡏ"),wwSFijdVJn1QgHW+viRJWOC5jsYe84(u"ࠧๆีะࠤฺ๎ัࠡษ็็ฯอศสࠩࡐ")+owkcGMKPsR24z790,qpFY4hAwolV3,iNc3KxwErnQ(u"࠴࠴࠽࠷࣭"))
	x3WSXnKyPhjqfHG2UrtQs(UVa3fJw7k6KM(u"ࠨ࡮࡬ࡲࡰ࠭ࡑ"),wwSFijdVJn1QgHW+l32dnTEOU1skGKqeBtI9hmo(u"่ࠩืาࠦใศึࠣห้ฮั็ษ่ะࠬࡒ")+TRw3lZxuU0hiKtJa,qpFY4hAwolV3,Ie5s2cBtSfdHjzQ4rA9kYlo6D18(u"࠵࠵࠾࠲࣮"))
	x3WSXnKyPhjqfHG2UrtQs(lljaEqwTVtmKsQcOrbXxS5hgNH(u"ࠪࡰ࡮ࡴ࡫ࠨࡓ"),wwSFijdVJn1QgHW+ee86G9ladLHVbh5mikzCo(u"ู๊ࠫอࠡว฼ำฬีวหࠢส่อืๆศ็ฯࠫࡔ")+AiDhS4QCJKxgU,qpFY4hAwolV3,aXqWLoTdVgME(u"࠶࠶࠸࠴࣯"))
	x3WSXnKyPhjqfHG2UrtQs(LZWMikPEB81KSGyxfJtUsCA(u"ࠬࡲࡩ࡯࡭ࠪࡕ"),wwSFijdVJn1QgHW+lljaEqwTVtmKsQcOrbXxS5hgNH(u"࠭สึใํีࠥอไษำ้ห๊าࠧࡖ")+wcgKBRM9eIjpSbCPhN,qpFY4hAwolV3,kYDaz79TFlXoR(u"࠷࠰࠹࠶ࣰ"))
	return
def o16KsZGXEUykaf53j7dAJ94rWT():
	D6vV0OxCcteLi1aXFTB2IbEpy,qOFUGe0lEDu4SKYk68VTCsH = B817EpDgwvKybXn6JhiQ43rT0HYUc(vvOjftRM30cDL)
	lQvuJfRI1hi8aP7sBrCGmTq,zcxrwuK5T0pmdGXtM = B817EpDgwvKybXn6JhiQ43rT0HYUc(bAlErF2ZgvWimGOXnJpfTSL)
	ChDPLoAVgWj3Xp4e6d8IsvT1t7m5yU,YrTBZHeO42v = B817EpDgwvKybXn6JhiQ43rT0HYUc(ZZ71IKwvflo)
	AQ8zYcPUorMOGWeT6Kl,mkTZpj5DnX3oq9A8GucKLEdBVhRQl = e2YrFAdw9WBl8740uPKUcGCbL(y9fZ7hgXSTt8)
	AQ8zYcPUorMOGWeT6Kl -= l1DZAt9XNQjqE7YOdrz(u"࠳࠷࠺࠹࠸ࣱ")
	mkTZpj5DnX3oq9A8GucKLEdBVhRQl -= mZi0S72jGoHpLO
	vN0gZI3nVwehLcsEjxm6 = str(RPbaxsNFVTwek5Kfv21DiJuzCnjMZp.listdir(tn7RmrxkdVJi2PISA1uoG))
	nK5ytToILE74CpY6O9h = vN0gZI3nVwehLcsEjxm6.count(N3flV6EJsD5CzS(u"ࠧ࡬ࡱࡧ࡭ࡤࡹࡴࡢࡥ࡮ࡸࡷࡧࡣࡦࠩࡗ"))+vN0gZI3nVwehLcsEjxm6.count(UVa3fJw7k6KM(u"ࠨ࡭ࡲࡨ࡮ࡥࡣࡳࡣࡶ࡬ࡱࡵࡧࠨࡘ"))
	owkcGMKPsR24z790 = iNc3KxwErnQ(u"࡙ࠩࠣࠬࠬ")+kfxKmu7cQhe(D6vV0OxCcteLi1aXFTB2IbEpy)+RlOvin8YIGC2KZXJPk9m0acrMobUex(u"ࠪࠤ࠲࡚ࠦࠧ")+str(qOFUGe0lEDu4SKYk68VTCsH)+LZWMikPEB81KSGyxfJtUsCA(u"ࠫࠥ࡬ࡩ࡭ࡧࡶ࡛࠭ࠬ")
	TRw3lZxuU0hiKtJa = l1DZAt9XNQjqE7YOdrz(u"ࠬࠦࠨࠨ࡜")+kfxKmu7cQhe(lQvuJfRI1hi8aP7sBrCGmTq)+l32dnTEOU1skGKqeBtI9hmo(u"࠭ࠠ࠮ࠢࠪ࡝")+str(zcxrwuK5T0pmdGXtM)+aXqWLoTdVgME(u"ࠧࠡࡨ࡬ࡰࡪࡹࠩࠨ࡞")
	AiDhS4QCJKxgU = ee86G9ladLHVbh5mikzCo(u"ࠨࠢࠫࠫ࡟")+kfxKmu7cQhe(ChDPLoAVgWj3Xp4e6d8IsvT1t7m5yU)+kYDaz79TFlXoR(u"ࠩࠣ࠱ࠥ࠭ࡠ")+str(YrTBZHeO42v)+aXqWLoTdVgME(u"ࠪࠤ࡫࡯࡬ࡦࡵࠬࠫࡡ")
	wcgKBRM9eIjpSbCPhN = aXqWLoTdVgME(u"ࠫࠥ࠮ࠧࡢ")+kfxKmu7cQhe(AQ8zYcPUorMOGWeT6Kl)+l32dnTEOU1skGKqeBtI9hmo(u"ࠬ࠯ࠧࡣ")
	eKAhRNdrx51FDb = viRJWOC5jsYe84(u"࠭ࠠࠩࠩࡤ")+str(nK5ytToILE74CpY6O9h)+ee86G9ladLHVbh5mikzCo(u"ࠧࠡࡨ࡬ࡰࡪࡹࠩࠨࡥ")
	KsmyZuaFUSd6P3AOwjhJ5MGogc = D6vV0OxCcteLi1aXFTB2IbEpy+lQvuJfRI1hi8aP7sBrCGmTq+ChDPLoAVgWj3Xp4e6d8IsvT1t7m5yU+AQ8zYcPUorMOGWeT6Kl
	y1FEOnmUq6eaTbVRCL9j = qOFUGe0lEDu4SKYk68VTCsH+zcxrwuK5T0pmdGXtM+YrTBZHeO42v+mkTZpj5DnX3oq9A8GucKLEdBVhRQl+nK5ytToILE74CpY6O9h
	HY7yaJeI89xE56sbTjdBRZPDwQKFX = l1DZAt9XNQjqE7YOdrz(u"ࠨࠢࠫࠫࡦ")+kfxKmu7cQhe(KsmyZuaFUSd6P3AOwjhJ5MGogc)+qoBMmfAWpFlK70xw8ZRh4naJ(u"ࠩࠣ࠱ࠥ࠭ࡧ")+str(y1FEOnmUq6eaTbVRCL9j)+rNdBKI74fAklnoCZ6(u"ࠪࠤ࡫࡯࡬ࡦࡵࠬࠫࡨ")
	x3WSXnKyPhjqfHG2UrtQs(YY8UDX3MJhb91AHw7fg(u"ࠫࡱ࡯࡮࡬ࠩࡩ"),wwSFijdVJn1QgHW+BRWqdruz2A0(u"๋ࠬำฮࠢส่ัฺ๋๊ࠩࡪ")+HY7yaJeI89xE56sbTjdBRZPDwQKFX,qpFY4hAwolV3,qoBMmfAWpFlK70xw8ZRh4naJ(u"࠸࠶࠸ࣲ"))
	x3WSXnKyPhjqfHG2UrtQs(qoBMmfAWpFlK70xw8ZRh4naJ(u"࠭࡬ࡪࡰ࡮ࠫ࡫"),xupTj02bvy3O8R+lljaEqwTVtmKsQcOrbXxS5hgNH(u"ࠧࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥ࠭࡬")+fF4lt9zWYxXLKZVyAco82PgMj,qpFY4hAwolV3,sjtU6GZQg5XC2pH4(u"࠻࠼࠽࠾ࣳ"))
	x3WSXnKyPhjqfHG2UrtQs(l1DZAt9XNQjqE7YOdrz(u"ࠨ࡮࡬ࡲࡰ࠭࡭"),wwSFijdVJn1QgHW+lljaEqwTVtmKsQcOrbXxS5hgNH(u"่ࠩืาࠦวๅ็็ๅฬะࠠศๆ่ศ็ะษࠨ࡮")+owkcGMKPsR24z790,qpFY4hAwolV3,DiJ8CMuYH1daWyjehfN0L(u"࠺࠸࠶ࣴ"))
	x3WSXnKyPhjqfHG2UrtQs(sjtU6GZQg5XC2pH4(u"ࠪࡰ࡮ࡴ࡫ࠨ࡯"),wwSFijdVJn1QgHW+IaBhDMJc17302LgSvyxd(u"ู๊ࠫอࠡษ็้้็วหࠢส่๊฼ฺู้ฬࠫࡰ")+TRw3lZxuU0hiKtJa,qpFY4hAwolV3,DaFZHsThGmd0zv6e(u"࠻࠹࠸ࣵ"))
	x3WSXnKyPhjqfHG2UrtQs(l1DZAt9XNQjqE7YOdrz(u"ࠬࡲࡩ࡯࡭ࠪࡱ"),wwSFijdVJn1QgHW+tQMjXKCA5dN4xq3beVIzaEoWkFLg(u"࠭ๅิฯࠣห้฻่าࠢส่็ี๊ๆหࠪࡲ")+AiDhS4QCJKxgU,qpFY4hAwolV3,lljaEqwTVtmKsQcOrbXxS5hgNH(u"࠼࠺࠳ࣶ"))
	x3WSXnKyPhjqfHG2UrtQs(N3flV6EJsD5CzS(u"ࠧ࡭࡫ࡱ࡯ࠬࡳ"),wwSFijdVJn1QgHW+BRWqdruz2A0(u"ࠨฬไี๏เࠠๆๆไࠤฺ๎ัࠡษ็ษ฻อแศฬࠪࡴ")+wcgKBRM9eIjpSbCPhN,qpFY4hAwolV3,tR1krDGPpO025fghMT3a7UnYj(u"࠽࠴࠵ࣷ"))
	x3WSXnKyPhjqfHG2UrtQs(UUDAiytEL76RTmMYsuIz5evXB(u"ࠩ࡯࡭ࡳࡱࠧࡵ"),wwSFijdVJn1QgHW+rNdBKI74fAklnoCZ6(u"ุ้ࠪำࠠๆๆไหฯࠦวๅๅิหูࠦวๅ็วๆฯฯࠧࡶ")+eKAhRNdrx51FDb,qpFY4hAwolV3,N3flV6EJsD5CzS(u"࠷࠵࠸ࣸ"))
	return
def ocKEY7eL0iSlIxPnA():
	LYmWRFUb8Ov = gBExoceumj4y8bFW9hY2aNMVSr if ShynO8pN9idCE3 in ssQ5T7em6WrVwIGtXoxNKaBv48zHAM else ag8rjZo1Vz4IPdcOT
	if not LYmWRFUb8Ov:
		iG7Rz2kmn0x1yLNMV3u8O(qpFY4hAwolV3,qpFY4hAwolV3,GLTtERWbHnFuy4PCp,tQMjXKCA5dN4xq3beVIzaEoWkFLg(u"ࠫ฾๋ไ๋หࠣฮ๋฾๊โࠢส่ัํวำ่ࠢฮํ็ัสࠢไๆ฼ࠦไฤฮ๊ึฮ๊้่ࠦๆืࠥ࠴࠮ࠡ็ฮ่ࠥษฬ่ิฬࠤศฮไ๊ࠡฦ๊ิื่๋ัࠣ์้๐่็ๅึࠤ࠳࠴้ࠠฮ๊หื้ࠠๅ์ึࠤ๊์่ࠠาสࠤฬ๊ๆ้฻ࠪࡷ"))
		return
	OXhzNInrpK = gdPslyFW8ITBcpA302.getSetting(BRWqdruz2A0(u"ࠬࡧࡶ࠯ࡵࡷࡥࡹࡻࡳ࠯ࡴࡨࡪࡷ࡫ࡳࡩࠩࡸ"))
	if not OXhzNInrpK: qODQgEMK95ebfToyZAdm()
	D6vV0OxCcteLi1aXFTB2IbEpy,qOFUGe0lEDu4SKYk68VTCsH = B817EpDgwvKybXn6JhiQ43rT0HYUc(WtnhR2EeN105AMSIJyO)
	lQvuJfRI1hi8aP7sBrCGmTq,zcxrwuK5T0pmdGXtM = B817EpDgwvKybXn6JhiQ43rT0HYUc(FZWXjOn8EbYoxBeRl9y7fvM3)
	ChDPLoAVgWj3Xp4e6d8IsvT1t7m5yU,YrTBZHeO42v = B817EpDgwvKybXn6JhiQ43rT0HYUc(LkTd81Um4Dgqy9ruzSa5oF)
	AQ8zYcPUorMOGWeT6Kl,mkTZpj5DnX3oq9A8GucKLEdBVhRQl = B817EpDgwvKybXn6JhiQ43rT0HYUc(CwgGtRHSZqBl)
	a073H9PQoA6yW8TbmdRJGwg,nK5ytToILE74CpY6O9h = B817EpDgwvKybXn6JhiQ43rT0HYUc(qLcJFYT6NdtkHARXwol9Mr)
	R8Cy0NwoKb5kBAF,OXQi6wjD5oKeZgLTNl = B817EpDgwvKybXn6JhiQ43rT0HYUc(N9lpLo3rCM0de2)
	owkcGMKPsR24z790 = rNdBKI74fAklnoCZ6(u"࠭ࠠࠩࠩࡹ")+kfxKmu7cQhe(D6vV0OxCcteLi1aXFTB2IbEpy)+LZWMikPEB81KSGyxfJtUsCA(u"ࠧࠡ࠯ࠣࠫࡺ")+str(qOFUGe0lEDu4SKYk68VTCsH)+ddiCzu6yahj5RtTISMJ48sNnZBU(u"ࠨࠢࡩ࡭ࡱ࡫ࡳࠪࠩࡻ")
	TRw3lZxuU0hiKtJa = BRWqdruz2A0(u"ࠩࠣࠬࠬࡼ")+kfxKmu7cQhe(lQvuJfRI1hi8aP7sBrCGmTq)+UUDAiytEL76RTmMYsuIz5evXB(u"ࠪࠤ࠲ࠦࠧࡽ")+str(zcxrwuK5T0pmdGXtM)+tR1krDGPpO025fghMT3a7UnYj(u"ࠫࠥ࡬ࡩ࡭ࡧࡶ࠭ࠬࡾ")
	AiDhS4QCJKxgU = zYvEaigKWjoq50pXBLDbGJkFc(u"ࠬࠦࠨࠨࡿ")+kfxKmu7cQhe(ChDPLoAVgWj3Xp4e6d8IsvT1t7m5yU)+zYvEaigKWjoq50pXBLDbGJkFc(u"࠭ࠠ࠮ࠢࠪࢀ")+str(YrTBZHeO42v)+DiJ8CMuYH1daWyjehfN0L(u"ࠧࠡࡨ࡬ࡰࡪࡹࠩࠨࢁ")
	wcgKBRM9eIjpSbCPhN = sjtU6GZQg5XC2pH4(u"ࠨࠢࠫࠫࢂ")+kfxKmu7cQhe(AQ8zYcPUorMOGWeT6Kl)+CC1eY6yWZUwf2TkRvnp7EJ0AimjHBX(u"ࠩࠣ࠱ࠥ࠭ࢃ")+str(mkTZpj5DnX3oq9A8GucKLEdBVhRQl)+qqzwE6imYG4c2xojI(u"ࠪࠤ࡫࡯࡬ࡦࡵࠬࠫࢄ")
	eKAhRNdrx51FDb = BRWqdruz2A0(u"ࠫࠥ࠮ࠧࢅ")+kfxKmu7cQhe(a073H9PQoA6yW8TbmdRJGwg)+kYDaz79TFlXoR(u"ࠬࠦ࠭ࠡࠩࢆ")+str(nK5ytToILE74CpY6O9h)+RlOvin8YIGC2KZXJPk9m0acrMobUex(u"࠭ࠠࡧ࡫࡯ࡩࡸ࠯ࠧࢇ")
	DLZsrPxQgtme0nHhzl = c2RKu0xG1eC8MiohyE(u"ࠧࠡࠪࠪ࢈")+kfxKmu7cQhe(R8Cy0NwoKb5kBAF)+YY8UDX3MJhb91AHw7fg(u"ࠨࠢ࠰ࠤࠬࢉ")+str(OXQi6wjD5oKeZgLTNl)+l32dnTEOU1skGKqeBtI9hmo(u"ࠩࠣࡪ࡮ࡲࡥࡴࠫࠪࢊ")
	KsmyZuaFUSd6P3AOwjhJ5MGogc = D6vV0OxCcteLi1aXFTB2IbEpy+lQvuJfRI1hi8aP7sBrCGmTq+ChDPLoAVgWj3Xp4e6d8IsvT1t7m5yU+AQ8zYcPUorMOGWeT6Kl+a073H9PQoA6yW8TbmdRJGwg+R8Cy0NwoKb5kBAF
	y1FEOnmUq6eaTbVRCL9j = qOFUGe0lEDu4SKYk68VTCsH+zcxrwuK5T0pmdGXtM+YrTBZHeO42v+mkTZpj5DnX3oq9A8GucKLEdBVhRQl+nK5ytToILE74CpY6O9h+OXQi6wjD5oKeZgLTNl
	HY7yaJeI89xE56sbTjdBRZPDwQKFX = V3VlkhgjEF4n1erPXHcC0NOsfwyAJ(u"ࠪࠤ࠭࠭ࢋ")+kfxKmu7cQhe(KsmyZuaFUSd6P3AOwjhJ5MGogc)+zYvEaigKWjoq50pXBLDbGJkFc(u"ࠫࠥ࠳ࠠࠨࢌ")+str(y1FEOnmUq6eaTbVRCL9j)+N3flV6EJsD5CzS(u"ࠬࠦࡦࡪ࡮ࡨࡷ࠮࠭ࢍ")
	x3WSXnKyPhjqfHG2UrtQs(IaBhDMJc17302LgSvyxd(u"࠭࡬ࡪࡰ࡮ࠫࢎ"),wwSFijdVJn1QgHW+qqzwE6imYG4c2xojI(u"ࠧฦ฻ฺหฦࠦัฯืฬࠤ็ืวยหࠣ์่ะวษหࠪ࢏"),qpFY4hAwolV3,CC1eY6yWZUwf2TkRvnp7EJ0AimjHBX(u"࠸࠷࠻ࣹ"))
	x3WSXnKyPhjqfHG2UrtQs(ee86G9ladLHVbh5mikzCo(u"ࠨ࡮࡬ࡲࡰ࠭࢐"),wwSFijdVJn1QgHW+c2RKu0xG1eC8MiohyE(u"่ࠩืาࠦวๅฮ่๎฾࠭࢑")+HY7yaJeI89xE56sbTjdBRZPDwQKFX,qpFY4hAwolV3,ddiCzu6yahj5RtTISMJ48sNnZBU(u"࠹࠸࠻ࣺ"))
	x3WSXnKyPhjqfHG2UrtQs(RlOvin8YIGC2KZXJPk9m0acrMobUex(u"ࠪࡰ࡮ࡴ࡫ࠨ࢒"),xupTj02bvy3O8R+DaFZHsThGmd0zv6e(u"ࠫࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࠪ࢓")+fF4lt9zWYxXLKZVyAco82PgMj,qpFY4hAwolV3,ddiCzu6yahj5RtTISMJ48sNnZBU(u"࠼࠽࠾࠿ࣻ"))
	x3WSXnKyPhjqfHG2UrtQs(zYvEaigKWjoq50pXBLDbGJkFc(u"ࠬࡲࡩ࡯࡭ࠪ࢔"),wwSFijdVJn1QgHW+DiJ8CMuYH1daWyjehfN0L(u"࠭ๅิฯ้้ࠣ็วหࠢࡸࡷࡦ࡭ࡥࡴࡶࡤࡸࡸ࠭࢕")+owkcGMKPsR24z790,qpFY4hAwolV3,UVa3fJw7k6KM(u"࠻࠺࠷ࣼ"))
	x3WSXnKyPhjqfHG2UrtQs(zYvEaigKWjoq50pXBLDbGJkFc(u"ࠧ࡭࡫ࡱ࡯ࠬ࢖"),wwSFijdVJn1QgHW+tR1krDGPpO025fghMT3a7UnYj(u"ࠨ็ึั๋ࠥไโษอࠤࡩࡸ࡯ࡱࡤࡲࡼࠬࢗ")+TRw3lZxuU0hiKtJa,qpFY4hAwolV3,sjtU6GZQg5XC2pH4(u"࠼࠻࠲ࣽ"))
	x3WSXnKyPhjqfHG2UrtQs(iNc3KxwErnQ(u"ࠩ࡯࡭ࡳࡱࠧ࢘"),wwSFijdVJn1QgHW+lljaEqwTVtmKsQcOrbXxS5hgNH(u"ุ้ࠪำࠠๆๆไหฯࠦࡴࡰ࡯ࡥࡷࡹࡵ࡮ࡦࡵ࢙ࠪ")+AiDhS4QCJKxgU,qpFY4hAwolV3,UUDAiytEL76RTmMYsuIz5evXB(u"࠽࠵࠴ࣾ"))
	x3WSXnKyPhjqfHG2UrtQs(YY8UDX3MJhb91AHw7fg(u"ࠫࡱ࡯࡮࡬࢚ࠩ"),wwSFijdVJn1QgHW+qoBMmfAWpFlK70xw8ZRh4naJ(u"๋ࠬำฮ่่ࠢๆอสࠡ࡮ࡲ࡫࡬࡫ࡲࠨ࢛")+wcgKBRM9eIjpSbCPhN,qpFY4hAwolV3,DaFZHsThGmd0zv6e(u"࠷࠶࠶ࣿ"))
	x3WSXnKyPhjqfHG2UrtQs(V3VlkhgjEF4n1erPXHcC0NOsfwyAJ(u"࠭࡬ࡪࡰ࡮ࠫ࢜"),wwSFijdVJn1QgHW+N3flV6EJsD5CzS(u"ࠧๆีะࠤ๊๊แศฬࠣࡰࡴ࡭ࠧ࢝")+eKAhRNdrx51FDb,qpFY4hAwolV3,ee86G9ladLHVbh5mikzCo(u"࠸࠷࠸ऀ"))
	x3WSXnKyPhjqfHG2UrtQs(fWoVd0Bmtkx(u"ࠨ࡮࡬ࡲࡰ࠭࢞"),wwSFijdVJn1QgHW+l32dnTEOU1skGKqeBtI9hmo(u"่ࠩืาࠦๅๅใสฮࠥࡧ࡮ࡳࠩ࢟")+DLZsrPxQgtme0nHhzl,qpFY4hAwolV3,YY8UDX3MJhb91AHw7fg(u"࠹࠸࠺ँ"))
	return
def LXTFozR0Ew6yDBKc7bH1qrA8(showDialogs):
	if showDialogs: iG7Rz2kmn0x1yLNMV3u8O(qpFY4hAwolV3,qpFY4hAwolV3,GLTtERWbHnFuy4PCp,lljaEqwTVtmKsQcOrbXxS5hgNH(u"้ࠪั๊ฯࠡื๋ี้ࠥสศสฬࠤฬ๊โ้ษษ้ࠥ࠴࠮้ࠡำหࠥอไๆฮ็ำࠥ็๊่ࠢห฽฻ࠦโ้ษษ้ࠥอไษำ้ห๊าࠠๆะี๊ฮࠦศีๅ็ࠤฺ๎ัࠡสา่ฬࠦๅ็ࠢส่่ะวษหࠣ࠲࠳ูࠦ็ัุ้ࠣำࠠศๆ่ะ้ีࠠิ์ๅ์๊ࠦวๅสิ๊ฬ๋ฬࠡสั่็ࠦๅอๆาࠤัี๊ะ๋ࠢ๎อีรࠡ็ิอࠥษฮา๋ࠣฬ๊๊ฦ่ࠢหห้฻่าࠢ฼๊ิࠦแหฯࠣห้่่ศศ่ࠫࢠ"))
	fJV8ONbeU0MXvmgxD,hhl5TGHrdZ9tJeVuf8 = [],vvXoMLlg513
	for f9wTYGXyuPAbWQRB6o5MNzZgJ1nO,DnaYxijN2h,EOoWlmzJs246FkMRtepyCaDXY1 in RPbaxsNFVTwek5Kfv21DiJuzCnjMZp.walk(MZRS4rVzdoqwH,topdown=ag8rjZo1Vz4IPdcOT):
		FAWr1s5YQdyKqVwCB4 = len(EOoWlmzJs246FkMRtepyCaDXY1)
		if FAWr1s5YQdyKqVwCB4>fWoVd0Bmtkx(u"࠸࠴࠵ं"): fJV8ONbeU0MXvmgxD.append(DnaYxijN2h)
		hhl5TGHrdZ9tJeVuf8 += FAWr1s5YQdyKqVwCB4
	YDjUQlWN0TCI9btX = hhl5TGHrdZ9tJeVuf8>qoBMmfAWpFlK70xw8ZRh4naJ(u"࠹࠵࠶࠰ः")
	if showDialogs:
		count = xupTj02bvy3O8R+rNdBKI74fAklnoCZ6(u"้ࠫี๊ไࠢࠣࠫࢡ")+str(hhl5TGHrdZ9tJeVuf8)+CC1eY6yWZUwf2TkRvnp7EJ0AimjHBX(u"ࠬࠦࠠึ๊ิอࠬࢢ")+fF4lt9zWYxXLKZVyAco82PgMj
		if not fJV8ONbeU0MXvmgxD and not YDjUQlWN0TCI9btX: o4oUxD3u18K59ghHIY = VVpbtSKYUGXrNMwAWFo9IOjZP(qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,GLTtERWbHnFuy4PCp,aXqWLoTdVgME(u"࠭ไศࠢํ์ัีฺ่ࠠา็ࠥ฻่าࠢๆฮฬฮษࠡๅฮ๎ึฯࠠ࠯࠰ࠣ์้ํะศࠢ็หࠥะอหษฯࠤศ์ࠠห็ึัࠥ฻่าࠢส่่ะวษหࠣ࠲࠳ࠦ็ๅࠢอี๏ีࠠๆีะࠤฺ๎ัࠡษ็็ฯอศสࠢส่ว์ࠠภࠣࠣࡠࡳࡢ࡮ࠨࢣ")+count)
		else: o4oUxD3u18K59ghHIY = VVpbtSKYUGXrNMwAWFo9IOjZP(qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,GLTtERWbHnFuy4PCp,V3VlkhgjEF4n1erPXHcC0NOsfwyAJ(u"ࠧๅัํ็ࠥ฻่าࠢๆฮฬฮษࠡๅฮ๎ึฯࠠ࠯࠰ࠣ์์ึวࠡไาࠤ๏ูศษุ่ࠢฬ้ไࠡใํࠤฯฺฺ๋ๆࠣห้า็ศิࠣ์ฯฺฺ๋ๆࠣฬึ์วๆฮࠣ฽๊อฯࠡ࠰࠱ࠤศ์สࠡสะหัฯࠠฦๆ์ࠤู๊อ้ࠡำ๋ࠥอไึ๊ิࠤ࠳࠴่ࠠๆࠣฮึ๐ฯࠡ็ึัࠥ฻่าࠢส่่ะวษหࠣห้ศๆࠡมࠤࠤࡡࡴ࡜࡯ࠩࢤ")+count)
	else: o4oUxD3u18K59ghHIY = mZi0S72jGoHpLO
	if o4oUxD3u18K59ghHIY==mZi0S72jGoHpLO:
		if YDjUQlWN0TCI9btX: EOJmze1pUvdCgVPLRt3(f9wTYGXyuPAbWQRB6o5MNzZgJ1nO,ag8rjZo1Vz4IPdcOT,ag8rjZo1Vz4IPdcOT)
		elif fJV8ONbeU0MXvmgxD:
			for DnaYxijN2h in fJV8ONbeU0MXvmgxD: EOJmze1pUvdCgVPLRt3(DnaYxijN2h,ag8rjZo1Vz4IPdcOT,ag8rjZo1Vz4IPdcOT)
	return
def qODQgEMK95ebfToyZAdm():
	yybfMXcSVHaGio9xpuEDZwLl4e = ag8rjZo1Vz4IPdcOT
	o4oUxD3u18K59ghHIY = VVpbtSKYUGXrNMwAWFo9IOjZP(qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,GLTtERWbHnFuy4PCp,lljaEqwTVtmKsQcOrbXxS5hgNH(u"ࠨๆๆ๎ࠥ๐ูๆๆࠣห้ะๆู์ไࠤ฾์ฯไࠢ࠱࠲ࠥฮั็ษ่ะࠥ฿ๅศัࠣฬาอฬสࠢศ่๎ࠦลฺูสลࠥืฮึหࠣห้่ัศรฬࠤํอไไฬสฬฮࠦไๅ็็ๅฬะ้ࠠษ็้ั๊ฯศฬࠣห้ะ๊ࠡี๋ๅࠥ๐ๅิฯ๊หࠥอไษำ้ห๊าࠠ࠯࠰๋้ࠣࠦสา์าࠤส฿ืศร๋ࠣีํࠠศๆิาฺฯࠠศๆล๊ࠥลࠡࠨࢥ"))
	if o4oUxD3u18K59ghHIY==-iNc3KxwErnQ(u"࠶ऄ"): return
	if o4oUxD3u18K59ghHIY:
		import subprocess as br4VvwS3oy1mOf2aAz
		try:
			br4VvwS3oy1mOf2aAz.Popen(DaFZHsThGmd0zv6e(u"ࠩࡶࡹࠬࢦ"))
			yybfMXcSVHaGio9xpuEDZwLl4e = gBExoceumj4y8bFW9hY2aNMVSr
		except: pass
		if yybfMXcSVHaGio9xpuEDZwLl4e:
			aa5gLqdKlFprxQW = WtnhR2EeN105AMSIJyO+mIsDke0oK5x1zSiOWbF9thGcA+FZWXjOn8EbYoxBeRl9y7fvM3+mIsDke0oK5x1zSiOWbF9thGcA+LkTd81Um4Dgqy9ruzSa5oF+mIsDke0oK5x1zSiOWbF9thGcA+CwgGtRHSZqBl+mIsDke0oK5x1zSiOWbF9thGcA+qLcJFYT6NdtkHARXwol9Mr+mIsDke0oK5x1zSiOWbF9thGcA+N9lpLo3rCM0de2
			yKpGah5H3tXduIcCoi8frMZN4PzV = br4VvwS3oy1mOf2aAz.Popen(qoBMmfAWpFlK70xw8ZRh4naJ(u"ࠪࡷࡺࠦ࠭ࡤࠢࠥࡧ࡭ࡳ࡯ࡥࠢ࠰ࡖࠥ࠶࠷࠸࠹ࠣࠫࢧ")+aa5gLqdKlFprxQW+UUDAiytEL76RTmMYsuIz5evXB(u"ࠫࠧ࠭ࢨ"),shell=gBExoceumj4y8bFW9hY2aNMVSr,stdin=br4VvwS3oy1mOf2aAz.PIPE,stdout=br4VvwS3oy1mOf2aAz.PIPE,stderr=br4VvwS3oy1mOf2aAz.PIPE)
			iG7Rz2kmn0x1yLNMV3u8O(qpFY4hAwolV3,qpFY4hAwolV3,GLTtERWbHnFuy4PCp,lljaEqwTVtmKsQcOrbXxS5hgNH(u"ࠬ์ฬฮฬࠣ฽๊๊๊สࠢศ฽฼อมࠡษ็ีำ฻ษࠨࢩ"))
		else: iG7Rz2kmn0x1yLNMV3u8O(qpFY4hAwolV3,qpFY4hAwolV3,GLTtERWbHnFuy4PCp,c2RKu0xG1eC8MiohyE(u"ู࠭ๆๆํอࠥหูุษฤࠤึิีสࠢส่็ืวยหࠣ์ฬ๊ใหษหอࠥะอหษฯࠤอืๆศ็ฯࠤࠥࡸ࡯ࡰࡶࠣࠤศ๎ࠠࠡࡵࡸࡴࡪࡸࡵࡴࡧࡵࠤࠥษ่ࠡࠢࡶࡹ่ࠥࠦอ้สึ่ࠦไศࠢํ์ัีࠠโ์๊ࠤ์ึวࠡษ็ฬึ์วๆฮࠣ࠲࠳ࠦร้ࠢๆ์ิ๐ࠠ฻์ิࠤ็อฯาࠢ฼่๎ࠦวิฬัำฬ๋่ࠠาสࠤฬ๊ศา่ส้ั࠭ࢪ"))
	return yybfMXcSVHaGio9xpuEDZwLl4e
def kfxKmu7cQhe(KsmyZuaFUSd6P3AOwjhJ5MGogc):
	for JcIrh6UxaoESylX92fj in [RlOvin8YIGC2KZXJPk9m0acrMobUex(u"ࠧࡃࠩࢫ"),V3VlkhgjEF4n1erPXHcC0NOsfwyAJ(u"ࠨࡍࡅࠫࢬ"),N3flV6EJsD5CzS(u"ࠩࡐࡆࠬࢭ"),ddiCzu6yahj5RtTISMJ48sNnZBU(u"ࠪࡋࡇ࠭ࢮ"),RlOvin8YIGC2KZXJPk9m0acrMobUex(u"࡙ࠫࡈࠧࢯ")]:
		if KsmyZuaFUSd6P3AOwjhJ5MGogc<UUDAiytEL76RTmMYsuIz5evXB(u"࠷࠰࠳࠶अ"): break
		else: KsmyZuaFUSd6P3AOwjhJ5MGogc /= l1DZAt9XNQjqE7YOdrz(u"࠱࠱࠴࠷࠲࠵आ")
	HY7yaJeI89xE56sbTjdBRZPDwQKFX = lljaEqwTVtmKsQcOrbXxS5hgNH(u"ࠧࠫ࠳࠯࠳ࡩࠤࠪࡹࠢࢰ")%(KsmyZuaFUSd6P3AOwjhJ5MGogc,JcIrh6UxaoESylX92fj)
	return HY7yaJeI89xE56sbTjdBRZPDwQKFX
def B817EpDgwvKybXn6JhiQ43rT0HYUc(anw4UjSxLOCM=viRJWOC5jsYe84(u"࠭࠮ࠨࢱ")):
	global t1gmIf9eaMN6JObKZnVqcFApH,CWXeMtmKRG9uoA8kFbaSjs2qZVIPi
	t1gmIf9eaMN6JObKZnVqcFApH,CWXeMtmKRG9uoA8kFbaSjs2qZVIPi = vvXoMLlg513,vvXoMLlg513
	def m3VNaCZsd7brnWPwBX6(anw4UjSxLOCM):
		global t1gmIf9eaMN6JObKZnVqcFApH,CWXeMtmKRG9uoA8kFbaSjs2qZVIPi
		if RPbaxsNFVTwek5Kfv21DiJuzCnjMZp.path.exists(anw4UjSxLOCM):
			if vvXoMLlg513 and CC1eY6yWZUwf2TkRvnp7EJ0AimjHBX(u"ࠧࡴࡥࡤࡲࡩ࡯ࡲࠨࢲ") in dir(RPbaxsNFVTwek5Kfv21DiJuzCnjMZp):
				for HkKn7pqNvZ8ty in RPbaxsNFVTwek5Kfv21DiJuzCnjMZp.scandir(anw4UjSxLOCM):
					if HkKn7pqNvZ8ty.is_dir(follow_symlinks=ag8rjZo1Vz4IPdcOT):
						m3VNaCZsd7brnWPwBX6(HkKn7pqNvZ8ty.path)
					elif HkKn7pqNvZ8ty.is_file(follow_symlinks=ag8rjZo1Vz4IPdcOT):
						t1gmIf9eaMN6JObKZnVqcFApH += HkKn7pqNvZ8ty.stat().st_size
						CWXeMtmKRG9uoA8kFbaSjs2qZVIPi += mZi0S72jGoHpLO
			else:
				for HkKn7pqNvZ8ty in RPbaxsNFVTwek5Kfv21DiJuzCnjMZp.listdir(anw4UjSxLOCM):
					wo1ZAyVmBEzYOsQ = RPbaxsNFVTwek5Kfv21DiJuzCnjMZp.path.abspath(RPbaxsNFVTwek5Kfv21DiJuzCnjMZp.path.join(anw4UjSxLOCM,HkKn7pqNvZ8ty))
					if RPbaxsNFVTwek5Kfv21DiJuzCnjMZp.path.isdir(wo1ZAyVmBEzYOsQ):
						m3VNaCZsd7brnWPwBX6(wo1ZAyVmBEzYOsQ)
					elif RPbaxsNFVTwek5Kfv21DiJuzCnjMZp.path.isfile(wo1ZAyVmBEzYOsQ):
						KsmyZuaFUSd6P3AOwjhJ5MGogc,y1FEOnmUq6eaTbVRCL9j = e2YrFAdw9WBl8740uPKUcGCbL(wo1ZAyVmBEzYOsQ)
						t1gmIf9eaMN6JObKZnVqcFApH += KsmyZuaFUSd6P3AOwjhJ5MGogc
						CWXeMtmKRG9uoA8kFbaSjs2qZVIPi += y1FEOnmUq6eaTbVRCL9j
		return
	try: m3VNaCZsd7brnWPwBX6(anw4UjSxLOCM)
	except: pass
	return t1gmIf9eaMN6JObKZnVqcFApH,CWXeMtmKRG9uoA8kFbaSjs2qZVIPi
def U6ZfAs2Ke0G318tWlXjaNyS(showDialogs):
	if showDialogs:
		o4oUxD3u18K59ghHIY = VVpbtSKYUGXrNMwAWFo9IOjZP(qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,GLTtERWbHnFuy4PCp,xupTj02bvy3O8R+l32dnTEOU1skGKqeBtI9hmo(u"ࠨ้็ࠤฯื๊ะ่ࠢืา࠭ࢳ")+ZLwoRpfnCWI7FgEHsz6te39lMVh+iNc3KxwErnQ(u"่ࠩะ้ีࠠศๆ่่ๆอสࠡษ็้ษ่สสࠢ࠱࠲ࠥ๎ๅอๆาࠤฬ๊ๅๅใสฮࠥอไๆุ฽์฼ฯࠠ࠯࠰ࠣ์๊าไะࠢสฺ่๎ัࠡษ็ๆิ๐ๅสࠢ࠱࠲ࠥ๎สโำํ฾๋ࠥไโุࠢ์ึࠦวๅวูหๆอสࠡ࠰࠱ࠤํ๋ไโษอࠤฬ๊ใาษืࠫࢴ")+ZLwoRpfnCWI7FgEHsz6te39lMVh+ddiCzu6yahj5RtTISMJ48sNnZBU(u"ࠪรࠦࠧࠧࢵ")+fF4lt9zWYxXLKZVyAco82PgMj)
		if o4oUxD3u18K59ghHIY!=mZi0S72jGoHpLO: return
	dB3WynaLlomRX = EOJmze1pUvdCgVPLRt3(vvOjftRM30cDL,gBExoceumj4y8bFW9hY2aNMVSr,ag8rjZo1Vz4IPdcOT)
	MkDAHUwnlSgVi8LtRFzueyIx7G4 = EOJmze1pUvdCgVPLRt3(bAlErF2ZgvWimGOXnJpfTSL,gBExoceumj4y8bFW9hY2aNMVSr,ag8rjZo1Vz4IPdcOT)
	Wny7QDYmHoX6I0k8hcpAe = EOJmze1pUvdCgVPLRt3(ZZ71IKwvflo,ag8rjZo1Vz4IPdcOT,ag8rjZo1Vz4IPdcOT)
	DXzcisHBMGoS6YVEU9bAtLZjP = itFcjX8GyQprb4IDAzwJq2fhS(ag8rjZo1Vz4IPdcOT)
	USrJNDZfduxpmzsHgao1IOt = vvEItel7mRYbLuj(ag8rjZo1Vz4IPdcOT)
	succeeded = all([dB3WynaLlomRX,MkDAHUwnlSgVi8LtRFzueyIx7G4,Wny7QDYmHoX6I0k8hcpAe,DXzcisHBMGoS6YVEU9bAtLZjP,USrJNDZfduxpmzsHgao1IOt])
	if showDialogs:
		if succeeded: iG7Rz2kmn0x1yLNMV3u8O(qpFY4hAwolV3,qpFY4hAwolV3,GLTtERWbHnFuy4PCp,V3VlkhgjEF4n1erPXHcC0NOsfwyAJ(u"ࠫฯ๋ࠠศๆ่ืาࠦศ็ฮสัࠬࢶ"))
		else: iG7Rz2kmn0x1yLNMV3u8O(qpFY4hAwolV3,qpFY4hAwolV3,GLTtERWbHnFuy4PCp,Ie5s2cBtSfdHjzQ4rA9kYlo6D18(u"๊ࠬไฤีไࠤๆฺไหࠢ฼้้๐ษࠡษ็ุ้ำࠧࢷ"))
	return succeeded
def BBU0EjAJLXHfo18CKg6FQ(showDialogs):
	if showDialogs:
		aa5gLqdKlFprxQW = WtnhR2EeN105AMSIJyO+ZLwoRpfnCWI7FgEHsz6te39lMVh+FZWXjOn8EbYoxBeRl9y7fvM3+ZLwoRpfnCWI7FgEHsz6te39lMVh+LkTd81Um4Dgqy9ruzSa5oF+ZLwoRpfnCWI7FgEHsz6te39lMVh+CwgGtRHSZqBl+ZLwoRpfnCWI7FgEHsz6te39lMVh+qLcJFYT6NdtkHARXwol9Mr+ZLwoRpfnCWI7FgEHsz6te39lMVh+N9lpLo3rCM0de2
		o4oUxD3u18K59ghHIY = VVpbtSKYUGXrNMwAWFo9IOjZP(qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,GLTtERWbHnFuy4PCp,xupTj02bvy3O8R+l32dnTEOU1skGKqeBtI9hmo(u"࠭็ๅࠢอี๏ีࠠๆีะࠤฬ๊ๅๅใสฮࠥอไๆฦๅฮฮࠦวๅฬํࠤๆ๐่ࠠา๊ࠤฬ๊ๅอๆาหฯࡢ࡮࡝ࡰࠪࢸ")+aa5gLqdKlFprxQW+fF4lt9zWYxXLKZVyAco82PgMj)
		if o4oUxD3u18K59ghHIY!=mZi0S72jGoHpLO: return
	dB3WynaLlomRX = EOJmze1pUvdCgVPLRt3(WtnhR2EeN105AMSIJyO,ag8rjZo1Vz4IPdcOT,ag8rjZo1Vz4IPdcOT)
	MkDAHUwnlSgVi8LtRFzueyIx7G4 = EOJmze1pUvdCgVPLRt3(FZWXjOn8EbYoxBeRl9y7fvM3,ag8rjZo1Vz4IPdcOT,ag8rjZo1Vz4IPdcOT)
	Wny7QDYmHoX6I0k8hcpAe = EOJmze1pUvdCgVPLRt3(LkTd81Um4Dgqy9ruzSa5oF,ag8rjZo1Vz4IPdcOT,ag8rjZo1Vz4IPdcOT)
	DXzcisHBMGoS6YVEU9bAtLZjP = EOJmze1pUvdCgVPLRt3(CwgGtRHSZqBl,ag8rjZo1Vz4IPdcOT,ag8rjZo1Vz4IPdcOT)
	USrJNDZfduxpmzsHgao1IOt = EOJmze1pUvdCgVPLRt3(qLcJFYT6NdtkHARXwol9Mr,ag8rjZo1Vz4IPdcOT,ag8rjZo1Vz4IPdcOT)
	xLXChbNVMTYcIQBml = EOJmze1pUvdCgVPLRt3(N9lpLo3rCM0de2,ag8rjZo1Vz4IPdcOT,ag8rjZo1Vz4IPdcOT)
	succeeded = all([dB3WynaLlomRX,MkDAHUwnlSgVi8LtRFzueyIx7G4,Wny7QDYmHoX6I0k8hcpAe,DXzcisHBMGoS6YVEU9bAtLZjP,USrJNDZfduxpmzsHgao1IOt,xLXChbNVMTYcIQBml])
	if showDialogs:
		if succeeded: iG7Rz2kmn0x1yLNMV3u8O(qpFY4hAwolV3,qpFY4hAwolV3,GLTtERWbHnFuy4PCp,viRJWOC5jsYe84(u"ࠧห็ࠣห้๋ำฮࠢห๊ัออࠨࢹ"))
		else: iG7Rz2kmn0x1yLNMV3u8O(qpFY4hAwolV3,qpFY4hAwolV3,GLTtERWbHnFuy4PCp,fWoVd0Bmtkx(u"ࠨๆ็วุ็ࠠโึ็ฮࠥ฿ๅๅ์ฬࠤฬ๊ๅิฯࠪࢺ"))
	return succeeded
def itFcjX8GyQprb4IDAzwJq2fhS(showDialogs):
	if showDialogs:
		o4oUxD3u18K59ghHIY = VVpbtSKYUGXrNMwAWFo9IOjZP(qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,GLTtERWbHnFuy4PCp,xupTj02bvy3O8R+BRWqdruz2A0(u"๊่ࠩࠥะั๋ัุ้ࠣำࠠๆฯอ์๏อสࠡ็็ๅࠥ฻่าࠢส่ั๊ฯࠡมࠤࠥࠬࢻ")+fF4lt9zWYxXLKZVyAco82PgMj)
		if o4oUxD3u18K59ghHIY!=viRJWOC5jsYe84(u"࠲इ"): return mmV2nucZ5Lpl6FO1JMPEqGoQKW(u"ࡈࡤࡰࡸ࡫ई")
	try:
		succeeded = BRWqdruz2A0(u"ࡗࡶࡺ࡫उ")
		MkQL5RWVxPpz2mi63ADrt = IkS3LDtnyvAh2NaQU5p6P1KHZ.connect(y9fZ7hgXSTt8)
		MkQL5RWVxPpz2mi63ADrt.text_factory = str
		EHQhicPzSdtkG = MkQL5RWVxPpz2mi63ADrt.cursor()
		EHQhicPzSdtkG.execute(ddiCzu6yahj5RtTISMJ48sNnZBU(u"ࠪࡈࡊࡒࡅࡕࡇࠣࡊࡗࡕࡍࠡࡲࡤࡸ࡭ࡁࠧࢼ"))
		EHQhicPzSdtkG.execute(UUDAiytEL76RTmMYsuIz5evXB(u"ࠫࡉࡋࡌࡆࡖࡈࠤࡋࡘࡏࡎࠢࡶ࡭ࡿ࡫ࡳ࠼ࠩࢽ"))
		EHQhicPzSdtkG.execute(dJHDqiKf12TXlIzSLkGUuxg4MBs3A(u"ࠬࡊࡅࡍࡇࡗࡉࠥࡌࡒࡐࡏࠣࡸࡪࡾࡴࡶࡴࡨ࠿ࠬࢾ"))
		MkQL5RWVxPpz2mi63ADrt.commit()
		EHQhicPzSdtkG.execute(lljaEqwTVtmKsQcOrbXxS5hgNH(u"࠭ࡖࡂࡅࡘ࡙ࡒࡁࠧࢿ"))
		MkQL5RWVxPpz2mi63ADrt.close()
	except: succeeded = CC1eY6yWZUwf2TkRvnp7EJ0AimjHBX(u"ࡊࡦࡲࡳࡦऊ")
	if showDialogs:
		if succeeded: iG7Rz2kmn0x1yLNMV3u8O(qpFY4hAwolV3,qpFY4hAwolV3,GLTtERWbHnFuy4PCp,UUDAiytEL76RTmMYsuIz5evXB(u"ࠧห็ࠣห้๋ำฮࠢห๊ัออࠨࣀ"))
		else: iG7Rz2kmn0x1yLNMV3u8O(qpFY4hAwolV3,qpFY4hAwolV3,GLTtERWbHnFuy4PCp,lljaEqwTVtmKsQcOrbXxS5hgNH(u"ࠨๆ็วุ็ࠠโึ็ฮࠥ฿ๅๅ์ฬࠤฬ๊ๅิฯࠪࣁ"))
	return succeeded
def vvEItel7mRYbLuj(showDialogs):
	if showDialogs:
		o4oUxD3u18K59ghHIY = VVpbtSKYUGXrNMwAWFo9IOjZP(qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,GLTtERWbHnFuy4PCp,ee86G9ladLHVbh5mikzCo(u"่่ࠩๆอสࠡษ็็ึอิ้ࠡํࠤ๊๊แศฬࠣ๎ฺ์ู่ษࠣ็ํี๊ࠡ฻้ำ๊อ๋ࠠ฼็ๆࠥ์แิ้ࠣฬฺ๎ัส่ࠢๅฬารสࠢ࠱࠲ࠥํะ่ࠢส่๊๊แศฬࠣ๎าะวอ้สࠤ๊ฮัๆฮํࠤ่๎ฯ๋ࠢะฮ๎ฺ๊ࠦำไ์๋ࠦๅ็้สࠤ่๐แࠡฯาฯฯࠦวๅ็ื็้ฯࠧࣂ")+ZLwoRpfnCWI7FgEHsz6te39lMVh+ZLwoRpfnCWI7FgEHsz6te39lMVh+xupTj02bvy3O8R+ee86G9ladLHVbh5mikzCo(u"๋้ࠪࠦสา์าࠤู๊อࠡ็็ๅฬะࠠศๆๆีฬฺࠠศๆ่ศ็ะษࠡมࠤࠥࠬࣃ")+fF4lt9zWYxXLKZVyAco82PgMj)
		if o4oUxD3u18K59ghHIY!=mZi0S72jGoHpLO: return l1DZAt9XNQjqE7YOdrz(u"ࡋࡧ࡬ࡴࡧऋ")
	succeeded = viRJWOC5jsYe84(u"࡚ࡲࡶࡧऌ")
	for file in RPbaxsNFVTwek5Kfv21DiJuzCnjMZp.listdir(tn7RmrxkdVJi2PISA1uoG):
		if mmV2nucZ5Lpl6FO1JMPEqGoQKW(u"ࠫࡰࡵࡤࡪࡡࡶࡸࡦࡩ࡫ࡵࡴࡤࡧࡪ࠭ࣄ") not in file and YY8UDX3MJhb91AHw7fg(u"ࠬࡱ࡯ࡥ࡫ࡢࡧࡷࡧࡳࡩ࡮ࡲ࡫ࠬࣅ") not in file: continue
		Pz546fUa8OM2ihjSR1Yl3LW = RPbaxsNFVTwek5Kfv21DiJuzCnjMZp.path.join(tn7RmrxkdVJi2PISA1uoG,file)
		try: RPbaxsNFVTwek5Kfv21DiJuzCnjMZp.remove(Pz546fUa8OM2ihjSR1Yl3LW)
		except Exception as Afgoj31Zzp6XeHU7I:
			succeeded = N3flV6EJsD5CzS(u"ࡆࡢ࡮ࡶࡩऍ")
			if showDialogs: iG7Rz2kmn0x1yLNMV3u8O(qpFY4hAwolV3,qpFY4hAwolV3,GLTtERWbHnFuy4PCp,str(Afgoj31Zzp6XeHU7I))
	if showDialogs:
		if succeeded: iG7Rz2kmn0x1yLNMV3u8O(qpFY4hAwolV3,qpFY4hAwolV3,GLTtERWbHnFuy4PCp,l32dnTEOU1skGKqeBtI9hmo(u"࠭สๆࠢสู่๊อࠡส้ะฬำࠧࣆ"))
		else: iG7Rz2kmn0x1yLNMV3u8O(qpFY4hAwolV3,qpFY4hAwolV3,GLTtERWbHnFuy4PCp,DaFZHsThGmd0zv6e(u"ࠧๅๆฦืๆࠦแีๆอࠤ฾๋ไ๋หࠣห้๋ำฮࠩࣇ"))
	return succeeded