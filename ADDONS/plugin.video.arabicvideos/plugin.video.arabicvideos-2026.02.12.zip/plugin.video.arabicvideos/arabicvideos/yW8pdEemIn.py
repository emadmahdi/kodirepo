# -*- coding: utf-8 -*-
from pSfaryIjBo import *
Q8Q0IDc6PLZajJAdTntKUmSGXz = 'MOVIZLAND'
headers = { 'User-Agent' : qpFY4hAwolV3 }
wwSFijdVJn1QgHW = '_MVZ_'
ddBxj51bhNtaK23lDyGMVw = i4bFG3rKE6.SITESURLS[Q8Q0IDc6PLZajJAdTntKUmSGXz][0]
WsvFbLApfU = i4bFG3rKE6.SITESURLS[Q8Q0IDc6PLZajJAdTntKUmSGXz][1]
def vTNE2Ck1sGnugJYW8y39aLcSH64U(mode,url,text):
	if   mode==180: MOTjA5H9XFs = nRVAZc4Dp8PSrGU3xBk()
	elif mode==181: MOTjA5H9XFs = c8U1BdtxOZS5FH(url,text)
	elif mode==182: MOTjA5H9XFs = mzcAeyplZV(url)
	elif mode==183: MOTjA5H9XFs = v1gmfxDcRrWKQ(url)
	elif mode==188: MOTjA5H9XFs = iiYEWDK1NLFGdlTrgcewfa2nks()
	elif mode==189: MOTjA5H9XFs = PPqUACSE3VcGLTvw05jHy9JrFNW(text)
	else: MOTjA5H9XFs = False
	return MOTjA5H9XFs
def iiYEWDK1NLFGdlTrgcewfa2nks():
	message = 'هذا الموقع تغير بالكامل ... وبحاجة الى اعادة برمجة من الصفر ... والمبرمج حاليا مشغول ويعاني من وعكة صحية ... ولهذا سوف يبقى الموقع مغلق الى ما شاء الله'
	iG7Rz2kmn0x1yLNMV3u8O(qpFY4hAwolV3,qpFY4hAwolV3,GLTtERWbHnFuy4PCp,message)
	return
def nRVAZc4Dp8PSrGU3xBk():
	x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+'بحث في الموقع',qpFY4hAwolV3,189,qpFY4hAwolV3,qpFY4hAwolV3,'_REMEMBERRESULTS_')
	x3WSXnKyPhjqfHG2UrtQs('folder',Q8Q0IDc6PLZajJAdTntKUmSGXz+'_SCRIPT_'+wwSFijdVJn1QgHW+'بوكس اوفيس موفيز لاند',ddBxj51bhNtaK23lDyGMVw,181,qpFY4hAwolV3,qpFY4hAwolV3,'box-office')
	x3WSXnKyPhjqfHG2UrtQs('folder',Q8Q0IDc6PLZajJAdTntKUmSGXz+'_SCRIPT_'+wwSFijdVJn1QgHW+'أحدث الافلام',ddBxj51bhNtaK23lDyGMVw,181,qpFY4hAwolV3,qpFY4hAwolV3,'latest-movies')
	x3WSXnKyPhjqfHG2UrtQs('folder',Q8Q0IDc6PLZajJAdTntKUmSGXz+'_SCRIPT_'+wwSFijdVJn1QgHW+'تليفزيون موفيز لاند',ddBxj51bhNtaK23lDyGMVw,181,qpFY4hAwolV3,qpFY4hAwolV3,'tv')
	x3WSXnKyPhjqfHG2UrtQs('folder',Q8Q0IDc6PLZajJAdTntKUmSGXz+'_SCRIPT_'+wwSFijdVJn1QgHW+'الاكثر مشاهدة',ddBxj51bhNtaK23lDyGMVw,181,qpFY4hAwolV3,qpFY4hAwolV3,'top-views')
	x3WSXnKyPhjqfHG2UrtQs('folder',Q8Q0IDc6PLZajJAdTntKUmSGXz+'_SCRIPT_'+wwSFijdVJn1QgHW+'أقوى الافلام الحالية',ddBxj51bhNtaK23lDyGMVw,181,qpFY4hAwolV3,qpFY4hAwolV3,'top-movies')
	cmWl9dOKHPIy41iaXuxrY = GMqfDK9V4F8eTPE1pNOAaiYUbhr(KOyPvpEztYLaZRdMQJWxfTNFHbkg,ddBxj51bhNtaK23lDyGMVw,qpFY4hAwolV3,headers,qpFY4hAwolV3,'MOVIZLAND-MENU-1st')
	items = ePhmG1jLD6.findall('<h2><a href="(.*?)".*?">(.*?)<',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	for MepIvHBYNArkUOdV37shtJ,title in items:
		x3WSXnKyPhjqfHG2UrtQs('folder',Q8Q0IDc6PLZajJAdTntKUmSGXz+'_SCRIPT_'+wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,181)
	return cmWl9dOKHPIy41iaXuxrY
def c8U1BdtxOZS5FH(url,type=qpFY4hAwolV3):
	cmWl9dOKHPIy41iaXuxrY = GMqfDK9V4F8eTPE1pNOAaiYUbhr(kUz8c7OqsxuPFIGfwg,url,qpFY4hAwolV3,headers,qpFY4hAwolV3,'MOVIZLAND-ITEMS-1st')
	if type=='latest-movies': mVYdjvor6i4wZ8 = ePhmG1jLD6.findall('class="titleSection">أحدث الأفلام</h1>(.*?)<h1',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)[0]
	elif type=='box-office': mVYdjvor6i4wZ8 = ePhmG1jLD6.findall('class="titleSection">بوكس اوفيس موفيز لاند</h1>(.*?)<h1',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)[0]
	elif type=='top-movies': mVYdjvor6i4wZ8 = ePhmG1jLD6.findall('btn-2-overlay(.*?)<style>',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)[0]
	elif type=='top-views': mVYdjvor6i4wZ8 = ePhmG1jLD6.findall('btn-1 btn-absoly(.*?)btn-2 btn-absoly',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)[0]
	elif type=='tv': mVYdjvor6i4wZ8 = ePhmG1jLD6.findall('class="titleSection">تليفزيون موفيز لاند</h1>(.*?)class="paging"',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)[0]
	else: mVYdjvor6i4wZ8 = cmWl9dOKHPIy41iaXuxrY
	if type in ['top-views','top-movies']:
		items = ePhmG1jLD6.findall('style="background-image:url\(\'(.*?)\'.*?href="(.*?)".*?href="(.*?)".*?bottom-title.*?>(.*?)<',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
	else: items = ePhmG1jLD6.findall('height="3[0-9]+" src="(.*?)".*?bottom-title.*?href=.*?>(.*?)<.*?href="(.*?)".*?href="(.*?)"',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
	aaCNAJdtsguSRELh2I = []
	ajJz5tpLxbnIiH3ewKcrM2UskVqAh = ['فيلم','الحلقة','الحلقه','عرض','Raw','SmackDown','اعلان','اجزاء']
	for Sj7rMNYRuQPTtkBvpHKeDW3h,IIlp6evJZOsRD,nrBC7GIPf1QXADqFHitl,YFvrkKx43cqTSIXlsiwfgz0aL in items:
		if type in ['top-views','top-movies']:
			Sj7rMNYRuQPTtkBvpHKeDW3h,MepIvHBYNArkUOdV37shtJ,OexQX2mTwfGkuU6AIBLz9vWlHjdF8,title = Sj7rMNYRuQPTtkBvpHKeDW3h,IIlp6evJZOsRD,nrBC7GIPf1QXADqFHitl,YFvrkKx43cqTSIXlsiwfgz0aL
		else: Sj7rMNYRuQPTtkBvpHKeDW3h,title,MepIvHBYNArkUOdV37shtJ,OexQX2mTwfGkuU6AIBLz9vWlHjdF8 = Sj7rMNYRuQPTtkBvpHKeDW3h,IIlp6evJZOsRD,nrBC7GIPf1QXADqFHitl,YFvrkKx43cqTSIXlsiwfgz0aL
		MepIvHBYNArkUOdV37shtJ = cTt4u6reEMKZqVLplmkNW7(MepIvHBYNArkUOdV37shtJ)
		MepIvHBYNArkUOdV37shtJ = MepIvHBYNArkUOdV37shtJ.replace('?view=true',qpFY4hAwolV3)
		title = j8PDV0pthfSTidZbsQxNIOmCYKWzH(title)
		if 'بجودة ' in title or 'بجوده ' in title:
			title = '_MOD_' + title.replace('بجودة ',qpFY4hAwolV3).replace('بجوده ',qpFY4hAwolV3)
		title = title.strip(mIsDke0oK5x1zSiOWbF9thGcA)
		if 'الحلقة' in title or 'الحلقه' in title:
			ZDTxRSMbW7PNz = ePhmG1jLD6.findall('(.*?) (الحلقة|الحلقه) \d+',title,ePhmG1jLD6.DOTALL)
			if ZDTxRSMbW7PNz:
				title = '_MOD_' + ZDTxRSMbW7PNz[0][0]
				if title not in aaCNAJdtsguSRELh2I:
					x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,183,Sj7rMNYRuQPTtkBvpHKeDW3h)
					aaCNAJdtsguSRELh2I.append(title)
		elif any(value in title for value in ajJz5tpLxbnIiH3ewKcrM2UskVqAh):
			MepIvHBYNArkUOdV37shtJ = MepIvHBYNArkUOdV37shtJ + '?servers=' + OexQX2mTwfGkuU6AIBLz9vWlHjdF8
			x3WSXnKyPhjqfHG2UrtQs('video',wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,182,Sj7rMNYRuQPTtkBvpHKeDW3h)
		else:
			MepIvHBYNArkUOdV37shtJ = MepIvHBYNArkUOdV37shtJ + '?servers=' + OexQX2mTwfGkuU6AIBLz9vWlHjdF8
			x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,183,Sj7rMNYRuQPTtkBvpHKeDW3h)
	if type==qpFY4hAwolV3:
		items = ePhmG1jLD6.findall('\n<li><a href="(.*?)".*?>(.*?)<',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
		for MepIvHBYNArkUOdV37shtJ,title in items:
			title = j8PDV0pthfSTidZbsQxNIOmCYKWzH(title)
			title = title.replace('الصفحة ',qpFY4hAwolV3)
			if title!=qpFY4hAwolV3:
				x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+'صفحة '+title,MepIvHBYNArkUOdV37shtJ,181)
	return
def v1gmfxDcRrWKQ(url):
	WSQlG8mDhqsNe = url.split('?servers=')[0]
	cmWl9dOKHPIy41iaXuxrY = GMqfDK9V4F8eTPE1pNOAaiYUbhr(kUz8c7OqsxuPFIGfwg,WSQlG8mDhqsNe,qpFY4hAwolV3,headers,qpFY4hAwolV3,'MOVIZLAND-EPISODES-1st')
	mVYdjvor6i4wZ8 = ePhmG1jLD6.findall('<title>(.*?)</title>.*?height="([0-9]+)" src="(.*?)"',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	title,oF67yxKdB8nY3TiH9gAMvlOhaPSws0,Sj7rMNYRuQPTtkBvpHKeDW3h = mVYdjvor6i4wZ8[0]
	name = ePhmG1jLD6.findall('(.*?) (الحلقة|الحلقه) [0-9]+',title,ePhmG1jLD6.DOTALL)
	if name: name = '_MOD_' + name[0][0]
	else: name = title
	items = []
	pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('class="episodesNumbers"(.*?)</div>',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	if pfRkcVlLmUxo561g0A8qSbO:
		mVYdjvor6i4wZ8 = pfRkcVlLmUxo561g0A8qSbO[0]
		items = ePhmG1jLD6.findall('href="(.*?)"',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
		for MepIvHBYNArkUOdV37shtJ in items:
			MepIvHBYNArkUOdV37shtJ = cTt4u6reEMKZqVLplmkNW7(MepIvHBYNArkUOdV37shtJ)
			title = ePhmG1jLD6.findall('(الحلقة|الحلقه)-([0-9]+)',MepIvHBYNArkUOdV37shtJ.split(ShynO8pN9idCE3)[-2],ePhmG1jLD6.DOTALL)
			if not title: title = ePhmG1jLD6.findall('()-([0-9]+)',MepIvHBYNArkUOdV37shtJ.split(ShynO8pN9idCE3)[-2],ePhmG1jLD6.DOTALL)
			if title: title = mIsDke0oK5x1zSiOWbF9thGcA + title[0][1]
			else: title = qpFY4hAwolV3
			title = name + ' - ' + 'الحلقة' + title
			title = j8PDV0pthfSTidZbsQxNIOmCYKWzH(title)
			x3WSXnKyPhjqfHG2UrtQs('video',wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,182,Sj7rMNYRuQPTtkBvpHKeDW3h)
	if not items:
		title = j8PDV0pthfSTidZbsQxNIOmCYKWzH(title)
		if 'بجودة ' in title or 'بجوده ' in title:
			title = '_MOD_' + title.replace('بجودة ',qpFY4hAwolV3).replace('بجوده ',qpFY4hAwolV3)
		x3WSXnKyPhjqfHG2UrtQs('video',wwSFijdVJn1QgHW+title,url,182,Sj7rMNYRuQPTtkBvpHKeDW3h)
	return
def mzcAeyplZV(url):
	nzv3N0TtRyAM9eqDl6ZOkhB1 = url.split('?servers=')
	WSQlG8mDhqsNe = nzv3N0TtRyAM9eqDl6ZOkhB1[0]
	del nzv3N0TtRyAM9eqDl6ZOkhB1[0]
	cmWl9dOKHPIy41iaXuxrY = GMqfDK9V4F8eTPE1pNOAaiYUbhr(KOyPvpEztYLaZRdMQJWxfTNFHbkg,WSQlG8mDhqsNe,qpFY4hAwolV3,headers,qpFY4hAwolV3,'MOVIZLAND-PLAY-1st')
	MepIvHBYNArkUOdV37shtJ = ePhmG1jLD6.findall('font-size: 25px;" href="(.*?)"',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)[0]
	if MepIvHBYNArkUOdV37shtJ not in nzv3N0TtRyAM9eqDl6ZOkhB1: nzv3N0TtRyAM9eqDl6ZOkhB1.append(MepIvHBYNArkUOdV37shtJ)
	U7V0BQZPxXqMbyJnRw6f = []
	for MepIvHBYNArkUOdV37shtJ in nzv3N0TtRyAM9eqDl6ZOkhB1:
		if '://moshahda.' in MepIvHBYNArkUOdV37shtJ:
			hK3vLUoy6OuM5 = MepIvHBYNArkUOdV37shtJ
			U7V0BQZPxXqMbyJnRw6f.append(hK3vLUoy6OuM5+'?named=Main')
	for MepIvHBYNArkUOdV37shtJ in nzv3N0TtRyAM9eqDl6ZOkhB1:
		if '://vb.movizland.' in MepIvHBYNArkUOdV37shtJ:
			cmWl9dOKHPIy41iaXuxrY = GMqfDK9V4F8eTPE1pNOAaiYUbhr(KOyPvpEztYLaZRdMQJWxfTNFHbkg,MepIvHBYNArkUOdV37shtJ,qpFY4hAwolV3,headers,qpFY4hAwolV3,'MOVIZLAND-PLAY-2nd')
			cmWl9dOKHPIy41iaXuxrY = cmWl9dOKHPIy41iaXuxrY.decode(Fufxt0VHDZgPJGAE).encode(nV3Tip6XsH1rJw79DPOU)
			cmWl9dOKHPIy41iaXuxrY = cmWl9dOKHPIy41iaXuxrY.replace('src="http://up.movizland.com/uploads/13721411411.png"','src="/uploads/13721411411.png"  \n  src="/uploads/13721411411.png"')
			cmWl9dOKHPIy41iaXuxrY = cmWl9dOKHPIy41iaXuxrY.replace('src="http://up.movizland.online/uploads/13721411411.png"','src="/uploads/13721411411.png"  \n  src="/uploads/13721411411.png"')
			cmWl9dOKHPIy41iaXuxrY = cmWl9dOKHPIy41iaXuxrY.replace('</a></div><br /><div align="center">','src="/uploads/13721411411.png"')
			cmWl9dOKHPIy41iaXuxrY = cmWl9dOKHPIy41iaXuxrY.replace('class="tborder" align="center"','src="/uploads/13721411411.png"')
			pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('(src="/uploads/13721411411.png".*?href="http://moshahda\..*?/\w+.html".*?src="/uploads/13721411411.png")',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
			if pfRkcVlLmUxo561g0A8qSbO:
				Oxb3egLHy9IJ8nKfiFs5Yt4rZ,fxYHq8pUSoAPt4RndK7uj6mC = [],[]
				if len(pfRkcVlLmUxo561g0A8qSbO)==1:
					title = qpFY4hAwolV3
					mVYdjvor6i4wZ8 = cmWl9dOKHPIy41iaXuxrY
				else:
					for mVYdjvor6i4wZ8 in pfRkcVlLmUxo561g0A8qSbO:
						WqdHmfQpP0ITnjJOAbDR6u8t7EiU = ePhmG1jLD6.findall('src="/uploads/13721411411.png".*?http://up.movizland.(online|com)/uploads/.*?\*\*\*\*\*\*\*+(.*?src="/uploads/13721411411.png")',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
						if WqdHmfQpP0ITnjJOAbDR6u8t7EiU: mVYdjvor6i4wZ8 = 'src="/uploads/13721411411.png"  \n  ' + WqdHmfQpP0ITnjJOAbDR6u8t7EiU[0][1]
						WqdHmfQpP0ITnjJOAbDR6u8t7EiU = ePhmG1jLD6.findall('src="/uploads/13721411411.png".*?<hr size="1" style="color:'+'#'+'333; background-color:'+'#'+'333" />(.*?href="http://moshahda\..*?/\w+.html".*?src="/uploads/13721411411.png")',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
						if WqdHmfQpP0ITnjJOAbDR6u8t7EiU: mVYdjvor6i4wZ8 = 'src="/uploads/13721411411.png"  \n  ' + WqdHmfQpP0ITnjJOAbDR6u8t7EiU[0]
						WqdHmfQpP0ITnjJOAbDR6u8t7EiU = ePhmG1jLD6.findall('(src="/uploads/13721411411.png".*?href="http://moshahda\..*?/\w+.html".*?)<hr size="1" style="color:'+'#'+'333; background-color:'+'#'+'333" />.*?src="/uploads/13721411411.png"',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
						if WqdHmfQpP0ITnjJOAbDR6u8t7EiU: mVYdjvor6i4wZ8 = WqdHmfQpP0ITnjJOAbDR6u8t7EiU[0] + '  \n  src="/uploads/13721411411.png"'
						UfVWYzTESugmA1cD869Msb0khad = ePhmG1jLD6.findall('<(.*?)http://up.movizland.(online|com)/uploads/',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
						title = ePhmG1jLD6.findall('> *([^<>]+) *<',UfVWYzTESugmA1cD869Msb0khad[0][0],ePhmG1jLD6.DOTALL)
						title = mIsDke0oK5x1zSiOWbF9thGcA.join(title)
						title = title.strip(mIsDke0oK5x1zSiOWbF9thGcA)
						title = title.replace(r1roOXYi7UQw9FLThzPEdD0ZlvAnRc,mIsDke0oK5x1zSiOWbF9thGcA).replace(r1roOXYi7UQw9FLThzPEdD0ZlvAnRc,mIsDke0oK5x1zSiOWbF9thGcA).replace(r1roOXYi7UQw9FLThzPEdD0ZlvAnRc,mIsDke0oK5x1zSiOWbF9thGcA).replace(r1roOXYi7UQw9FLThzPEdD0ZlvAnRc,mIsDke0oK5x1zSiOWbF9thGcA).replace(r1roOXYi7UQw9FLThzPEdD0ZlvAnRc,mIsDke0oK5x1zSiOWbF9thGcA)
						Oxb3egLHy9IJ8nKfiFs5Yt4rZ.append(title)
					ndm6kKswPpgGHNEbtB = xVzqWbrFXJ('أختر الفيديو المطلوب:', Oxb3egLHy9IJ8nKfiFs5Yt4rZ)
					if ndm6kKswPpgGHNEbtB == -1 : return
					title = Oxb3egLHy9IJ8nKfiFs5Yt4rZ[ndm6kKswPpgGHNEbtB]
					mVYdjvor6i4wZ8 = pfRkcVlLmUxo561g0A8qSbO[ndm6kKswPpgGHNEbtB]
				MepIvHBYNArkUOdV37shtJ = ePhmG1jLD6.findall('href="(http://moshahda\..*?/\w+.html)"',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
				quWN1E5DBym2p4Aohr = MepIvHBYNArkUOdV37shtJ[0]
				U7V0BQZPxXqMbyJnRw6f.append(quWN1E5DBym2p4Aohr+'?named=Forum')
				mVYdjvor6i4wZ8 = mVYdjvor6i4wZ8.replace('ـ',qpFY4hAwolV3)
				mVYdjvor6i4wZ8 = mVYdjvor6i4wZ8.replace('src="http://up.movizland.online/uploads/1517412175296.png"','src="/uploads/13721411411.png"  \n  src="/uploads/13721411411.png"  \n  typetype="both"  \n  ')
				mVYdjvor6i4wZ8 = mVYdjvor6i4wZ8.replace('src="http://up.movizland.com/uploads/1517412175296.png"','src="/uploads/13721411411.png"  \n  src="/uploads/13721411411.png"  \n  typetype="both"  \n  ')
				mVYdjvor6i4wZ8 = mVYdjvor6i4wZ8.replace('سيرفرات التحميل','src="/uploads/13721411411.png"  \n  src="/uploads/13721411411.png"  \n  typetype="download"  \n  ')
				mVYdjvor6i4wZ8 = mVYdjvor6i4wZ8.replace('روابط التحميل','src="/uploads/13721411411.png"  \n  src="/uploads/13721411411.png"  \n  typetype="download"  \n  ')
				mVYdjvor6i4wZ8 = mVYdjvor6i4wZ8.replace('سيرفرات المشاهد','src="/uploads/13721411411.png"  \n  src="/uploads/13721411411.png"  \n  typetype="watch"  \n  ')
				mVYdjvor6i4wZ8 = mVYdjvor6i4wZ8.replace('روابط المشاهد','src="/uploads/13721411411.png"  \n  src="/uploads/13721411411.png"  \n  typetype="watch"  \n  ')
				vQME3Kaw7f1LPuBH85 = ePhmG1jLD6.findall('(src="/uploads/13721411411.png".*?href="http://e5tsar.com/\d+".*?src="/uploads/13721411411.png")',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
				for NdvxrXw0qA2KnkzR6 in vQME3Kaw7f1LPuBH85:
					type = ePhmG1jLD6.findall(' typetype="(.*?)" ',NdvxrXw0qA2KnkzR6)
					if type:
						if type[0]!='both': type = '__'+type[0]
						else: type = qpFY4hAwolV3
					items = ePhmG1jLD6.findall('(?<!http://e5tsar.com/)(\w+[ \w]*</font>.*?|\w+[ \w]*<br />.*?)href="(http://e5tsar.com/.*?)"',NdvxrXw0qA2KnkzR6,ePhmG1jLD6.DOTALL)
					for fAElYZ6bhrzLiyCQj,MepIvHBYNArkUOdV37shtJ in items:
						title = ePhmG1jLD6.findall('(\w+[ \w]*)<',fAElYZ6bhrzLiyCQj)
						title = title[-1]
						MepIvHBYNArkUOdV37shtJ = MepIvHBYNArkUOdV37shtJ + '?named=' + title + type
						U7V0BQZPxXqMbyJnRw6f.append(MepIvHBYNArkUOdV37shtJ)
	hhpztscnBD1GP = WSQlG8mDhqsNe.replace(ddBxj51bhNtaK23lDyGMVw,WsvFbLApfU)
	cmWl9dOKHPIy41iaXuxrY = GMqfDK9V4F8eTPE1pNOAaiYUbhr(KOyPvpEztYLaZRdMQJWxfTNFHbkg,hhpztscnBD1GP,qpFY4hAwolV3,headers,qpFY4hAwolV3,'MOVIZLAND-PLAY-3rd')
	items = ePhmG1jLD6.findall('" href="(.*?)"',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	if items:
		eDupRE1rWsZvqiAPyCk8jtzo5 = items[-1]
		U7V0BQZPxXqMbyJnRw6f.append(eDupRE1rWsZvqiAPyCk8jtzo5+'?named=Mobile')
	import inVXFK46ET
	inVXFK46ET.q4qTJvuoQUzM3mZAtegy7IXdnb5wH(U7V0BQZPxXqMbyJnRw6f,Q8Q0IDc6PLZajJAdTntKUmSGXz,'video',url)
	return
def PPqUACSE3VcGLTvw05jHy9JrFNW(search):
	search,LBylNhMdH6OV1qGk0tWiXFg3,showDialogs = LLm3sBXHPcnTDxdE5gt6hz0Wkp(search)
	if search==qpFY4hAwolV3: search = jXgARlWMLVFUBnvmZwI2o5()
	if search==qpFY4hAwolV3: return
	search = search.replace(mIsDke0oK5x1zSiOWbF9thGcA,'+')
	cmWl9dOKHPIy41iaXuxrY = GMqfDK9V4F8eTPE1pNOAaiYUbhr(kUz8c7OqsxuPFIGfwg,ddBxj51bhNtaK23lDyGMVw,qpFY4hAwolV3,headers,qpFY4hAwolV3,'MOVIZLAND-SEARCH-1st')
	items = ePhmG1jLD6.findall('<option value="(.*?)">(.*?)</option>',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	ZZ1uiC5VHTNDsr = [ qpFY4hAwolV3 ]
	QF7wnlavktXqHAB5ijVb = [ 'الكل وبدون فلتر' ]
	for n1uwH0oJaGZ5WBd,title in items:
		ZZ1uiC5VHTNDsr.append(n1uwH0oJaGZ5WBd)
		QF7wnlavktXqHAB5ijVb.append(title)
	if n1uwH0oJaGZ5WBd:
		ndm6kKswPpgGHNEbtB = xVzqWbrFXJ('اختر الفلتر المناسب:', QF7wnlavktXqHAB5ijVb)
		if ndm6kKswPpgGHNEbtB == -1 : return
		n1uwH0oJaGZ5WBd = ZZ1uiC5VHTNDsr[ndm6kKswPpgGHNEbtB]
	else: n1uwH0oJaGZ5WBd = qpFY4hAwolV3
	url = ddBxj51bhNtaK23lDyGMVw + '/?s='+search+'&mcat='+n1uwH0oJaGZ5WBd
	c8U1BdtxOZS5FH(url)
	return