# -*- coding: utf-8 -*-
from pSfaryIjBo import *
Q8Q0IDc6PLZajJAdTntKUmSGXz = 'FAJERSHOW'
wwSFijdVJn1QgHW = '_FJS_'
ddBxj51bhNtaK23lDyGMVw = i4bFG3rKE6.SITESURLS[Q8Q0IDc6PLZajJAdTntKUmSGXz][0]
YEIA19ehBwpNfPVzK = ['التصنيفات','انشاء حساب','طلبات الزوّار']
def vTNE2Ck1sGnugJYW8y39aLcSH64U(mode,url,text):
	if   mode==390: MOTjA5H9XFs = nRVAZc4Dp8PSrGU3xBk()
	elif mode==391: MOTjA5H9XFs = c8U1BdtxOZS5FH(url,text)
	elif mode==392: MOTjA5H9XFs = mzcAeyplZV(url)
	elif mode==393: MOTjA5H9XFs = v1gmfxDcRrWKQ(url)
	elif mode==399: MOTjA5H9XFs = PPqUACSE3VcGLTvw05jHy9JrFNW(text)
	else: MOTjA5H9XFs = False
	return MOTjA5H9XFs
def nRVAZc4Dp8PSrGU3xBk():
	x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+'بحث في الموقع',qpFY4hAwolV3,399,qpFY4hAwolV3,qpFY4hAwolV3,'_REMEMBERRESULTS_')
	x3WSXnKyPhjqfHG2UrtQs('link',xupTj02bvy3O8R+' ===== ===== ===== '+fF4lt9zWYxXLKZVyAco82PgMj,qpFY4hAwolV3,9999)
	IAW0sh6So3NpqM = WWrExJZS3Bj4anOAkpv7(KOyPvpEztYLaZRdMQJWxfTNFHbkg,'GET',ddBxj51bhNtaK23lDyGMVw,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,'FAJERSHOW-MENU-1st')
	cmWl9dOKHPIy41iaXuxrY = IAW0sh6So3NpqM.content
	items = ePhmG1jLD6.findall('<header>.*?<h2>(.*?)<',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	for P71nY8vWLi4xBOr9tZVNRQzJUbSG6 in range(len(items)):
		title = items[P71nY8vWLi4xBOr9tZVNRQzJUbSG6]
		x3WSXnKyPhjqfHG2UrtQs('folder',Q8Q0IDc6PLZajJAdTntKUmSGXz+'_SCRIPT_'+wwSFijdVJn1QgHW+title,ddBxj51bhNtaK23lDyGMVw,391,qpFY4hAwolV3,qpFY4hAwolV3,'latest'+str(P71nY8vWLi4xBOr9tZVNRQzJUbSG6))
	x3WSXnKyPhjqfHG2UrtQs('folder',Q8Q0IDc6PLZajJAdTntKUmSGXz+'_SCRIPT_'+wwSFijdVJn1QgHW+'مختارات عشوائية',ddBxj51bhNtaK23lDyGMVw,391,qpFY4hAwolV3,qpFY4hAwolV3,'randoms')
	x3WSXnKyPhjqfHG2UrtQs('folder',Q8Q0IDc6PLZajJAdTntKUmSGXz+'_SCRIPT_'+wwSFijdVJn1QgHW+'أعلى الأفلام تقييماً',ddBxj51bhNtaK23lDyGMVw,391,qpFY4hAwolV3,qpFY4hAwolV3,'top_imdb_movies')
	x3WSXnKyPhjqfHG2UrtQs('folder',Q8Q0IDc6PLZajJAdTntKUmSGXz+'_SCRIPT_'+wwSFijdVJn1QgHW+'أعلى المسلسلات تقييماً',ddBxj51bhNtaK23lDyGMVw,391,qpFY4hAwolV3,qpFY4hAwolV3,'top_imdb_series')
	x3WSXnKyPhjqfHG2UrtQs('folder',Q8Q0IDc6PLZajJAdTntKUmSGXz+'_SCRIPT_'+wwSFijdVJn1QgHW+'أفلام مميزة',ddBxj51bhNtaK23lDyGMVw+'/movies',391,qpFY4hAwolV3,qpFY4hAwolV3,'featured_movies')
	x3WSXnKyPhjqfHG2UrtQs('folder',Q8Q0IDc6PLZajJAdTntKUmSGXz+'_SCRIPT_'+wwSFijdVJn1QgHW+'مسلسلات مميزة',ddBxj51bhNtaK23lDyGMVw+'/tvshows',391,qpFY4hAwolV3,qpFY4hAwolV3,'featured_tvshows')
	mVYdjvor6i4wZ8 = qpFY4hAwolV3
	pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('class="menu"(.*?)id="contenedor"',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	if pfRkcVlLmUxo561g0A8qSbO: mVYdjvor6i4wZ8 += pfRkcVlLmUxo561g0A8qSbO[0]
	pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('class="releases"(.*?)aside',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	if pfRkcVlLmUxo561g0A8qSbO: mVYdjvor6i4wZ8 += pfRkcVlLmUxo561g0A8qSbO[0]
	x3WSXnKyPhjqfHG2UrtQs('link',xupTj02bvy3O8R+' ===== ===== ===== '+fF4lt9zWYxXLKZVyAco82PgMj,qpFY4hAwolV3,9999)
	items = ePhmG1jLD6.findall('href="(.*?)">(.*?)<',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
	QrAXouklfYpzqd = True
	for MepIvHBYNArkUOdV37shtJ,title in items:
		title = j8PDV0pthfSTidZbsQxNIOmCYKWzH(title)
		if title=='الأعلى مشاهدة':
			if QrAXouklfYpzqd:
				title = 'الافلام '+title
				QrAXouklfYpzqd = False
			else: title = 'المسلسلات '+title
		if title not in YEIA19ehBwpNfPVzK:
			if title=='أفلام': x3WSXnKyPhjqfHG2UrtQs('folder',Q8Q0IDc6PLZajJAdTntKUmSGXz+'_SCRIPT_'+wwSFijdVJn1QgHW+title,ddBxj51bhNtaK23lDyGMVw+'/movies',391,qpFY4hAwolV3,qpFY4hAwolV3,'all_movies_tvshows')
			elif title=='مسلسلات': x3WSXnKyPhjqfHG2UrtQs('folder',Q8Q0IDc6PLZajJAdTntKUmSGXz+'_SCRIPT_'+wwSFijdVJn1QgHW+title,ddBxj51bhNtaK23lDyGMVw+'/tvshows',391,qpFY4hAwolV3,qpFY4hAwolV3,'all_movies_tvshows')
			else: x3WSXnKyPhjqfHG2UrtQs('folder',Q8Q0IDc6PLZajJAdTntKUmSGXz+'_SCRIPT_'+wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,391)
	return cmWl9dOKHPIy41iaXuxrY
def c8U1BdtxOZS5FH(url,type):
	mVYdjvor6i4wZ8,items = [],[]
	IAW0sh6So3NpqM = WWrExJZS3Bj4anOAkpv7(kUz8c7OqsxuPFIGfwg,'GET',url,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,'FAJERSHOW-TITLES-1st')
	cmWl9dOKHPIy41iaXuxrY = IAW0sh6So3NpqM.content
	if type in ['featured_movies','featured_tvshows']:
		pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('class="content"(.*?)id="archive-content"',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
		if pfRkcVlLmUxo561g0A8qSbO: mVYdjvor6i4wZ8 = pfRkcVlLmUxo561g0A8qSbO[0]
	elif type=='all_movies_tvshows':
		pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('id="archive-content"(.*?)class="pagination"',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
		if pfRkcVlLmUxo561g0A8qSbO: mVYdjvor6i4wZ8 = pfRkcVlLmUxo561g0A8qSbO[0]
	elif type=='top_imdb_movies':
		pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall("class='top-imdb-list tleft(.*?)class='top-imdb-list tright",cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
		if pfRkcVlLmUxo561g0A8qSbO:
			mVYdjvor6i4wZ8 = pfRkcVlLmUxo561g0A8qSbO[0]
			items = ePhmG1jLD6.findall("src='(.*?)'.*?href='(.*?)'>(.*?)<",mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
	elif type=='top_imdb_series':
		pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall("class='top-imdb-list tright(.*?)footer",cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
		if pfRkcVlLmUxo561g0A8qSbO:
			mVYdjvor6i4wZ8 = pfRkcVlLmUxo561g0A8qSbO[0]
			items = ePhmG1jLD6.findall("src='(.*?)'.*?href='(.*?)'>(.*?)<",mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
	elif type=='search':
		pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('class="search-page"(.*?)class="sidebar',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
		if pfRkcVlLmUxo561g0A8qSbO:
			mVYdjvor6i4wZ8 = pfRkcVlLmUxo561g0A8qSbO[0]
			items = ePhmG1jLD6.findall('src="(.*?)".*?href="(.*?)">(.*?)<',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
	elif type=='sider':
		pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('class="widget(.*?)class="widget',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
		mVYdjvor6i4wZ8 = pfRkcVlLmUxo561g0A8qSbO[0]
		G1EWNzkMOm35C = ePhmG1jLD6.findall('href="(.*?)".*?src="(.*?)".*?<h3>(.*?)<',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
		U7V0BQZPxXqMbyJnRw6f,vtznksEwXcaC83AKQRWYZd96oI1L,QQLqrElamjfneR8GoP9IpuZ = zip(*G1EWNzkMOm35C)
		items = zip(vtznksEwXcaC83AKQRWYZd96oI1L,U7V0BQZPxXqMbyJnRw6f,QQLqrElamjfneR8GoP9IpuZ)
	elif type=='randoms':
		pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('id="slider-movies-tvshows"(.*?)<header>',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
		mVYdjvor6i4wZ8 = pfRkcVlLmUxo561g0A8qSbO[0]
		items = ePhmG1jLD6.findall('src="(.*?)".*?href="(.*?)".*?"title">(.*?)<',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
	elif 'latest' in type:
		P71nY8vWLi4xBOr9tZVNRQzJUbSG6 = int(type[-1:])
		cmWl9dOKHPIy41iaXuxrY = cmWl9dOKHPIy41iaXuxrY.replace('<header>','<end><start>')
		cmWl9dOKHPIy41iaXuxrY = cmWl9dOKHPIy41iaXuxrY.replace('</div></div></div>','</div></div></div><end>')
		pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('<start>(.*?)<end>',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
		mVYdjvor6i4wZ8 = pfRkcVlLmUxo561g0A8qSbO[P71nY8vWLi4xBOr9tZVNRQzJUbSG6]
		if P71nY8vWLi4xBOr9tZVNRQzJUbSG6==6:
			G1EWNzkMOm35C = ePhmG1jLD6.findall('src="(.*?)" alt="(.*?)".*?href="(.*?)"',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
			vtznksEwXcaC83AKQRWYZd96oI1L,QQLqrElamjfneR8GoP9IpuZ,U7V0BQZPxXqMbyJnRw6f = zip(*G1EWNzkMOm35C)
			items = zip(vtznksEwXcaC83AKQRWYZd96oI1L,U7V0BQZPxXqMbyJnRw6f,QQLqrElamjfneR8GoP9IpuZ)
	else:
		pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('class="content"(.*?)class="(pagination|sidebar)',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
		if pfRkcVlLmUxo561g0A8qSbO:
			mVYdjvor6i4wZ8 = pfRkcVlLmUxo561g0A8qSbO[0][0]
			if '/collection/' in url:
				items = ePhmG1jLD6.findall('src="(.*?)".*?href="(.*?)">(.*?)<',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
			elif '/quality/' in url:
				items = ePhmG1jLD6.findall('src="(.*?)".*?href="(.*?)".*?"title">(.*?)<',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
	if not items and mVYdjvor6i4wZ8:
		items = ePhmG1jLD6.findall('src="(.*?)".*?href=.*?href="(.*?)">(.*?)</div>',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
	aaCNAJdtsguSRELh2I = []
	for Sj7rMNYRuQPTtkBvpHKeDW3h,MepIvHBYNArkUOdV37shtJ,title in items:
		if 'src=' in title: continue
		if 'serie' in title:
			title = ePhmG1jLD6.findall('^(.*?)<.*?serie">(.*?)<',title,ePhmG1jLD6.DOTALL)
			title = title[0][1]
			if title in aaCNAJdtsguSRELh2I: continue
			aaCNAJdtsguSRELh2I.append(title)
			title = '_MOD_'+title
		UdbGw48M6rCHDRmea5qP91nKI = ePhmG1jLD6.findall('^(.*?)<',title,ePhmG1jLD6.DOTALL)
		if UdbGw48M6rCHDRmea5qP91nKI: title = UdbGw48M6rCHDRmea5qP91nKI[0]
		title = j8PDV0pthfSTidZbsQxNIOmCYKWzH(title)
		if '/tvshows/' in MepIvHBYNArkUOdV37shtJ: x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,393,Sj7rMNYRuQPTtkBvpHKeDW3h)
		elif '/episodes/' in MepIvHBYNArkUOdV37shtJ: x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,393,Sj7rMNYRuQPTtkBvpHKeDW3h)
		elif '/seasons/' in MepIvHBYNArkUOdV37shtJ: x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,393,Sj7rMNYRuQPTtkBvpHKeDW3h)
		elif '/collection/' in MepIvHBYNArkUOdV37shtJ: x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,391,Sj7rMNYRuQPTtkBvpHKeDW3h)
		else: x3WSXnKyPhjqfHG2UrtQs('video',wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,392,Sj7rMNYRuQPTtkBvpHKeDW3h)
	if type not in ['featured_movies','featured_tvshows']:
		pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('"pagination"(.*?)</div>',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
		if pfRkcVlLmUxo561g0A8qSbO:
			mVYdjvor6i4wZ8 = pfRkcVlLmUxo561g0A8qSbO[0]
			items = ePhmG1jLD6.findall('href="(.*?)".*?>(.*?)<',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
			for MepIvHBYNArkUOdV37shtJ,title in items:
				x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+'صفحة '+title,MepIvHBYNArkUOdV37shtJ,391,qpFY4hAwolV3,qpFY4hAwolV3,type)
	return
def v1gmfxDcRrWKQ(url):
	XPNkVcWFUr = AWeJuo2LhZ5xiD8KNSqd9G0rtT74FE(url,'url')
	url = url.replace(XPNkVcWFUr,ddBxj51bhNtaK23lDyGMVw)
	IAW0sh6So3NpqM = WWrExJZS3Bj4anOAkpv7(kUz8c7OqsxuPFIGfwg,'GET',url,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,'FAJERSHOW-EPISODES-1st')
	cmWl9dOKHPIy41iaXuxrY = IAW0sh6So3NpqM.content
	GIE2XSj0vVJPZA6dgmOs9TMDy8UkQW = ePhmG1jLD6.findall('class="C rated".*?>(.*?)<',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	if GIE2XSj0vVJPZA6dgmOs9TMDy8UkQW and u0E18eO3HnCzr(Q8Q0IDc6PLZajJAdTntKUmSGXz,url,GIE2XSj0vVJPZA6dgmOs9TMDy8UkQW): return
	pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('''<ul class=["']episodios["']>(.*?)</ul></div></div></div>''',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	if pfRkcVlLmUxo561g0A8qSbO:
		mVYdjvor6i4wZ8 = pfRkcVlLmUxo561g0A8qSbO[0]
		items = ePhmG1jLD6.findall('''src=["'](.*?)["'].*?href=["'](.*?)["']>(.*?)</a>''',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
		for Sj7rMNYRuQPTtkBvpHKeDW3h,MepIvHBYNArkUOdV37shtJ,title in items:
			x3WSXnKyPhjqfHG2UrtQs('video',wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,392,Sj7rMNYRuQPTtkBvpHKeDW3h)
	return
def mzcAeyplZV(url):
	url = url.replace('//show.alfajertv.com/','//fajer.show/')
	IAW0sh6So3NpqM = WWrExJZS3Bj4anOAkpv7(kUz8c7OqsxuPFIGfwg,'GET',url,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,'FAJERSHOW-PLAY-1st')
	cmWl9dOKHPIy41iaXuxrY = IAW0sh6So3NpqM.content
	if DLod2Of8CkRrtzJynev:
		try: cmWl9dOKHPIy41iaXuxrY = cmWl9dOKHPIy41iaXuxrY.decode(nV3Tip6XsH1rJw79DPOU,'ignore')
		except: pass
	GIE2XSj0vVJPZA6dgmOs9TMDy8UkQW = ePhmG1jLD6.findall('class="C rated".*?>(.*?)<',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	if GIE2XSj0vVJPZA6dgmOs9TMDy8UkQW and u0E18eO3HnCzr(Q8Q0IDc6PLZajJAdTntKUmSGXz,url,GIE2XSj0vVJPZA6dgmOs9TMDy8UkQW): return
	U7V0BQZPxXqMbyJnRw6f = []
	pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('''id=["']player-option(.*?)class=["'](sheader|pag_episodes)["']''',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	if pfRkcVlLmUxo561g0A8qSbO:
		mVYdjvor6i4wZ8 = pfRkcVlLmUxo561g0A8qSbO[0][0]
		items = ePhmG1jLD6.findall('data-type="(.*?)" data-post="(.*?)" data-nume="(.*?)".*?class="vid_title">(.*?)<',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
		for type,xfBMzb7ZqP2k,auJqvdjYnp,title in items:
			MepIvHBYNArkUOdV37shtJ = ddBxj51bhNtaK23lDyGMVw+'/wp-admin/admin-ajax.php?action=doo_player_ajax&post='+xfBMzb7ZqP2k+'&nume='+auJqvdjYnp+'&type='+type
			MepIvHBYNArkUOdV37shtJ = MepIvHBYNArkUOdV37shtJ+'?named='+title+'__watch'
			U7V0BQZPxXqMbyJnRw6f.append(MepIvHBYNArkUOdV37shtJ)
	pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('''id=["']download["'] class(.*?)class=["']sbox["']''',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	if pfRkcVlLmUxo561g0A8qSbO:
		mVYdjvor6i4wZ8 = pfRkcVlLmUxo561g0A8qSbO[0]
		items = ePhmG1jLD6.findall('''img src=["'](.*?)["'].*?href=["'](.*?)["'].*?["']quality["']>(.*?)<.*?<td>(.*?)<''',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
		for Sj7rMNYRuQPTtkBvpHKeDW3h,MepIvHBYNArkUOdV37shtJ,Mrp5ZdGHFv9Xi6mkxfac3JDB,ccQMrN9ZB8 in items:
			if '=' in Sj7rMNYRuQPTtkBvpHKeDW3h:
				WtxGBsVSE42KHT63 = Sj7rMNYRuQPTtkBvpHKeDW3h.split('=')[1]
				title = AWeJuo2LhZ5xiD8KNSqd9G0rtT74FE(WtxGBsVSE42KHT63,'host')
			else: title = qpFY4hAwolV3
			title = ccQMrN9ZB8+mIsDke0oK5x1zSiOWbF9thGcA+title
			MepIvHBYNArkUOdV37shtJ = MepIvHBYNArkUOdV37shtJ+'?named='+title+'__download____'+Mrp5ZdGHFv9Xi6mkxfac3JDB
			U7V0BQZPxXqMbyJnRw6f.append(MepIvHBYNArkUOdV37shtJ)
	import inVXFK46ET
	inVXFK46ET.q4qTJvuoQUzM3mZAtegy7IXdnb5wH(U7V0BQZPxXqMbyJnRw6f,Q8Q0IDc6PLZajJAdTntKUmSGXz,'video',url)
	return
def PPqUACSE3VcGLTvw05jHy9JrFNW(search):
	search,LBylNhMdH6OV1qGk0tWiXFg3,showDialogs = LLm3sBXHPcnTDxdE5gt6hz0Wkp(search)
	if search==qpFY4hAwolV3: search = jXgARlWMLVFUBnvmZwI2o5()
	if search==qpFY4hAwolV3: return
	search = search.replace(mIsDke0oK5x1zSiOWbF9thGcA,'+')
	url = ddBxj51bhNtaK23lDyGMVw+'/?s='+search
	c8U1BdtxOZS5FH(url,'search')
	return