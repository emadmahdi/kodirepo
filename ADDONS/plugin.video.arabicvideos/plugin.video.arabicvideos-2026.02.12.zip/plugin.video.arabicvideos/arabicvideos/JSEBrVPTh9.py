# -*- coding: utf-8 -*-
from pSfaryIjBo import *
Q8Q0IDc6PLZajJAdTntKUmSGXz = 'GLOBALSEARCH'
wwSFijdVJn1QgHW = '_GLS_'
def vTNE2Ck1sGnugJYW8y39aLcSH64U(ZyiMa3BXVk2xWG0b,WWowRmHkj1ZAO2SUhtNvdrcKa9E6C,HY7yaJeI89xE56sbTjdBRZPDwQKFX,i02wfPp5EM):
	if   ZyiMa3BXVk2xWG0b==540: MOTjA5H9XFs = nRVAZc4Dp8PSrGU3xBk()
	elif ZyiMa3BXVk2xWG0b==541: MOTjA5H9XFs = ELR4V5Crpen2MljdZxJ7fvGykFs8W1(HY7yaJeI89xE56sbTjdBRZPDwQKFX)
	elif ZyiMa3BXVk2xWG0b==542: MOTjA5H9XFs = kiuNMmdRPsAjWntzVc5S1qhUKGb(HY7yaJeI89xE56sbTjdBRZPDwQKFX,WWowRmHkj1ZAO2SUhtNvdrcKa9E6C,i02wfPp5EM)
	elif ZyiMa3BXVk2xWG0b==543: MOTjA5H9XFs = aInVWv10KNmCO7Tk2ueBUPLqMxDwz()
	elif ZyiMa3BXVk2xWG0b==548: MOTjA5H9XFs = iYSdKM46W5GDUVnmesZBy7(WWowRmHkj1ZAO2SUhtNvdrcKa9E6C,HY7yaJeI89xE56sbTjdBRZPDwQKFX)
	elif ZyiMa3BXVk2xWG0b==549: MOTjA5H9XFs = PPqUACSE3VcGLTvw05jHy9JrFNW(HY7yaJeI89xE56sbTjdBRZPDwQKFX)
	else: MOTjA5H9XFs = False
	return MOTjA5H9XFs
def nRVAZc4Dp8PSrGU3xBk():
	x3WSXnKyPhjqfHG2UrtQs('folder','بحث جديد لجميع المواقع',qpFY4hAwolV3,549)
	x3WSXnKyPhjqfHG2UrtQs('link','كيف يعمل بحث جميع المواقع','',543)
	x3WSXnKyPhjqfHG2UrtQs('link',xupTj02bvy3O8R+'==== كلمات البحث المخزنة ===='+fF4lt9zWYxXLKZVyAco82PgMj,qpFY4hAwolV3,9999)
	QP6ZgYhxFIiUJ = XXyMBNAVJvKiq7jc20bEw6(WoFsvbmUlDZp7PzRfdGknCV,'dict','GLOBALSEARCH_SPLITTED_ALL')
	if QP6ZgYhxFIiUJ:
		QP6ZgYhxFIiUJ = QP6ZgYhxFIiUJ['__SEQUENCED_COLUMNS__']
		for v9hig4t8jT in reversed(QP6ZgYhxFIiUJ):
			x3WSXnKyPhjqfHG2UrtQs('folder',v9hig4t8jT,qpFY4hAwolV3,549,qpFY4hAwolV3,qpFY4hAwolV3,v9hig4t8jT)
	return
def PPqUACSE3VcGLTvw05jHy9JrFNW(v9hig4t8jT):
	if not v9hig4t8jT:
		v9hig4t8jT = jXgARlWMLVFUBnvmZwI2o5()
		if not v9hig4t8jT: return
		v9hig4t8jT = v9hig4t8jT.lower()
	BoVz38peOtwnXF9Dry6f15 = v9hig4t8jT.replace(wwSFijdVJn1QgHW,qpFY4hAwolV3)
	CCTcPio1Mj0ryqUz6avGYXng8NEf(BoVz38peOtwnXF9Dry6f15,'_ALL',True)
	x3WSXnKyPhjqfHG2UrtQs('link','بحث جماعي للمواقع - '+BoVz38peOtwnXF9Dry6f15,'search_sites_all',542,qpFY4hAwolV3,qpFY4hAwolV3,BoVz38peOtwnXF9Dry6f15)
	x3WSXnKyPhjqfHG2UrtQs('folder','بحث منفرد للمواقع - '+BoVz38peOtwnXF9Dry6f15,qpFY4hAwolV3,541,qpFY4hAwolV3,qpFY4hAwolV3,BoVz38peOtwnXF9Dry6f15)
	x3WSXnKyPhjqfHG2UrtQs('link',xupTj02bvy3O8R+'===== ===== ===== '+fF4lt9zWYxXLKZVyAco82PgMj,qpFY4hAwolV3,9999)
	x3WSXnKyPhjqfHG2UrtQs('folder','نتائج البحث مفصلة - '+BoVz38peOtwnXF9Dry6f15,'opened_sites_all',542,qpFY4hAwolV3,qpFY4hAwolV3,BoVz38peOtwnXF9Dry6f15)
	x3WSXnKyPhjqfHG2UrtQs('folder','نتائج البحث مقسمة - '+BoVz38peOtwnXF9Dry6f15,'listed_sites_all',542,qpFY4hAwolV3,qpFY4hAwolV3,BoVz38peOtwnXF9Dry6f15)
	return
def CCTcPio1Mj0ryqUz6avGYXng8NEf(rvwMmi9Olh4Wka8o0cnTqs,K7oYy9vsPHeL8RzgV4DrFxipfuC,YYNeByJoPm4Uui9f7):
	if K7oYy9vsPHeL8RzgV4DrFxipfuC=='_ALL': u4MSPs0rwoyRkx = '_GLS_'
	elif K7oYy9vsPHeL8RzgV4DrFxipfuC=='_GOOGLE': u4MSPs0rwoyRkx = '_GOS_'
	SURaVPO9Mgj0ru3GFZ = XXyMBNAVJvKiq7jc20bEw6(WoFsvbmUlDZp7PzRfdGknCV,'list','GLOBALSEARCH_SPLITTED'+K7oYy9vsPHeL8RzgV4DrFxipfuC,rvwMmi9Olh4Wka8o0cnTqs)
	xKTu7edZr0JCb6N8BtiyfYVAPs = XXyMBNAVJvKiq7jc20bEw6(WoFsvbmUlDZp7PzRfdGknCV,'list','GLOBALSEARCH_SPLITTED'+K7oYy9vsPHeL8RzgV4DrFxipfuC,u4MSPs0rwoyRkx+rvwMmi9Olh4Wka8o0cnTqs)
	mlykPoGXbJIjFnarp9KihxfN(WoFsvbmUlDZp7PzRfdGknCV,'GLOBALSEARCH_SPLITTED'+K7oYy9vsPHeL8RzgV4DrFxipfuC,rvwMmi9Olh4Wka8o0cnTqs)
	mlykPoGXbJIjFnarp9KihxfN(WoFsvbmUlDZp7PzRfdGknCV,'GLOBALSEARCH_SPLITTED'+K7oYy9vsPHeL8RzgV4DrFxipfuC,u4MSPs0rwoyRkx+rvwMmi9Olh4Wka8o0cnTqs)
	fp16SsjVHh0qLK2EU5TJ = SURaVPO9Mgj0ru3GFZ+xKTu7edZr0JCb6N8BtiyfYVAPs
	if fp16SsjVHh0qLK2EU5TJ and YYNeByJoPm4Uui9f7: rvwMmi9Olh4Wka8o0cnTqs = u4MSPs0rwoyRkx+rvwMmi9Olh4Wka8o0cnTqs
	zOYMaQ0NgdiRVwDJXh8e(WoFsvbmUlDZp7PzRfdGknCV,'GLOBALSEARCH_SPLITTED'+K7oYy9vsPHeL8RzgV4DrFxipfuC,rvwMmi9Olh4Wka8o0cnTqs,fp16SsjVHh0qLK2EU5TJ,IZVKS7o3q0)
	return
def yQsV9qYDJKotx(K7oYy9vsPHeL8RzgV4DrFxipfuC):
	o4oUxD3u18K59ghHIY = VVpbtSKYUGXrNMwAWFo9IOjZP(qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,GLTtERWbHnFuy4PCp,'هل تريد مسح جميع كلمات البحث المخزنة في البرنامج ؟!!')
	if o4oUxD3u18K59ghHIY!=1: return
	mlykPoGXbJIjFnarp9KihxfN(WoFsvbmUlDZp7PzRfdGknCV,'GLOBALSEARCH_SPLITTED'+K7oYy9vsPHeL8RzgV4DrFxipfuC)
	mlykPoGXbJIjFnarp9KihxfN(WoFsvbmUlDZp7PzRfdGknCV,'GLOBALSEARCH_DETAILED'+K7oYy9vsPHeL8RzgV4DrFxipfuC)
	mlykPoGXbJIjFnarp9KihxfN(WoFsvbmUlDZp7PzRfdGknCV,'GLOBALSEARCH_DIVIDED'+K7oYy9vsPHeL8RzgV4DrFxipfuC)
	if K7oYy9vsPHeL8RzgV4DrFxipfuC=='_GOOGLE': mlykPoGXbJIjFnarp9KihxfN(WoFsvbmUlDZp7PzRfdGknCV,'GOOGLESEARCH_RESULTS')
	iG7Rz2kmn0x1yLNMV3u8O(qpFY4hAwolV3,qpFY4hAwolV3,GLTtERWbHnFuy4PCp,'تم بنجاح مسح جميع كلمات البحث المخزنة في البرنامج')
	return
def kiuNMmdRPsAjWntzVc5S1qhUKGb(FPW2hRyDdw5ZHv91aOAiJEQr3,to89WjGVaPXupkEwvJmCMiexYU36,AEcd0qvVDG=qpFY4hAwolV3,OjJ9kzWMGHwKfuvbcsLqTgUBZ=cmEHgQpO5f1tDrx4CJdz,WGU85dQDXhnRgYj0aTPruM={}):
	tlZsShHQEjMN6n2i1qYIv,d295dLt7HerXCopPlNhKBGYIFWaVjD,OKzLvm15yTAHwbo,ByPTldqYNpfARW9C7Qh24,qqQ8sTZ5BaCOKxGPblkzvwcnEgfYe = [],{},{},{},{}
	if '_all' in to89WjGVaPXupkEwvJmCMiexYU36: K7oYy9vsPHeL8RzgV4DrFxipfuC,MtIBq23QjNrgDXvERnwhfa,u4MSPs0rwoyRkx = '_ALL','_all','_GLS_'
	elif '_google' in to89WjGVaPXupkEwvJmCMiexYU36: K7oYy9vsPHeL8RzgV4DrFxipfuC,MtIBq23QjNrgDXvERnwhfa,u4MSPs0rwoyRkx = '_GOOGLE','_google','_GOS_'
	if to89WjGVaPXupkEwvJmCMiexYU36 in ['listed_sites'+MtIBq23QjNrgDXvERnwhfa,'opened_sites'+MtIBq23QjNrgDXvERnwhfa,'closed_sites'+MtIBq23QjNrgDXvERnwhfa]:
		if to89WjGVaPXupkEwvJmCMiexYU36=='listed_sites'+MtIBq23QjNrgDXvERnwhfa: tlZsShHQEjMN6n2i1qYIv = XXyMBNAVJvKiq7jc20bEw6(WoFsvbmUlDZp7PzRfdGknCV,'list','GLOBALSEARCH_SPLITTED'+K7oYy9vsPHeL8RzgV4DrFxipfuC,u4MSPs0rwoyRkx+FPW2hRyDdw5ZHv91aOAiJEQr3)
		elif to89WjGVaPXupkEwvJmCMiexYU36=='opened_sites'+MtIBq23QjNrgDXvERnwhfa: tlZsShHQEjMN6n2i1qYIv = XXyMBNAVJvKiq7jc20bEw6(WoFsvbmUlDZp7PzRfdGknCV,'list','GLOBALSEARCH_DETAILED'+K7oYy9vsPHeL8RzgV4DrFxipfuC,FPW2hRyDdw5ZHv91aOAiJEQr3)
		elif to89WjGVaPXupkEwvJmCMiexYU36=='closed_sites'+MtIBq23QjNrgDXvERnwhfa: tlZsShHQEjMN6n2i1qYIv = XXyMBNAVJvKiq7jc20bEw6(WoFsvbmUlDZp7PzRfdGknCV,'list','GLOBALSEARCH_DIVIDED'+K7oYy9vsPHeL8RzgV4DrFxipfuC,(AEcd0qvVDG,FPW2hRyDdw5ZHv91aOAiJEQr3))
	if not tlZsShHQEjMN6n2i1qYIv:
		JQ0OTpbAGY8khnwf = 'هذا البحث غير موجود في كاش البرنامج \n\n\n'
		UJqj5NE0ZKm = 'هل تريد الآن البحث في جميع المواقع عن \n "'+IQ2KCmObsTGuiRdEzt931a40jLg+mIsDke0oK5x1zSiOWbF9thGcA+FPW2hRyDdw5ZHv91aOAiJEQr3+mIsDke0oK5x1zSiOWbF9thGcA+fF4lt9zWYxXLKZVyAco82PgMj+'" \n علما أن هذا البحث قد يحتاج بعض الوقت'
		if to89WjGVaPXupkEwvJmCMiexYU36=='search_sites'+MtIBq23QjNrgDXvERnwhfa: w0CZ6B3WDJknhEsdRYyH1XAM = UJqj5NE0ZKm
		else: w0CZ6B3WDJknhEsdRYyH1XAM = JQ0OTpbAGY8khnwf+UJqj5NE0ZKm
		o4oUxD3u18K59ghHIY = VVpbtSKYUGXrNMwAWFo9IOjZP(qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,GLTtERWbHnFuy4PCp,w0CZ6B3WDJknhEsdRYyH1XAM)
		if o4oUxD3u18K59ghHIY!=1: return
		nGRXot8mU9Qa2Dd(pESAKj92MT,pESAKj92MT,pESAKj92MT)
		LLvyStW429DEZKlA(k8kdUSxohLVljnrY,lTW9p1v7uPfOxB(Q8Q0IDc6PLZajJAdTntKUmSGXz)+'   Search For: [ '+FPW2hRyDdw5ZHv91aOAiJEQr3+' ]')
		RXyCOlWBw7Pzmq3uo9f8jFe = 1
		for j7HgbsXoUDfzcSkmniPu9w6 in OjJ9kzWMGHwKfuvbcsLqTgUBZ:
			a4SBs70ZYeKikMlPXm1byHg3nh = WGU85dQDXhnRgYj0aTPruM[j7HgbsXoUDfzcSkmniPu9w6] if WGU85dQDXhnRgYj0aTPruM else FPW2hRyDdw5ZHv91aOAiJEQr3
			try: qg4HsMCAcGWP7dZuv,bbieYx6KO2EHAmJj0G,TqMRtYCifVH46FuUgh = pPbuMH5hy6BSXzEaDGn(j7HgbsXoUDfzcSkmniPu9w6)
			except: continue
			d295dLt7HerXCopPlNhKBGYIFWaVjD[j7HgbsXoUDfzcSkmniPu9w6] = []
			ZZCk6FGHRa8 = '_NODIALOGS_'
			if '-' in j7HgbsXoUDfzcSkmniPu9w6: ZZCk6FGHRa8 = ZZCk6FGHRa8+'_REMEMBERRESULTS__'+j7HgbsXoUDfzcSkmniPu9w6+'_'
			if RXyCOlWBw7Pzmq3uo9f8jFe:
				s7FnXZYOgexlH2MPb8BJck1AKv9.sleep(0.75)
				qqQ8sTZ5BaCOKxGPblkzvwcnEgfYe[j7HgbsXoUDfzcSkmniPu9w6] = MqWf2atLi7QDnOF0YKuZhrE53gbv1(daemon=gBExoceumj4y8bFW9hY2aNMVSr,target=bbieYx6KO2EHAmJj0G,args=(a4SBs70ZYeKikMlPXm1byHg3nh+ZZCk6FGHRa8,))
				qqQ8sTZ5BaCOKxGPblkzvwcnEgfYe[j7HgbsXoUDfzcSkmniPu9w6].start()
			else: bbieYx6KO2EHAmJj0G(a4SBs70ZYeKikMlPXm1byHg3nh+ZZCk6FGHRa8)
			t8yiLuJp3cBA6d1QE9x7eZ4fa(nqTpa5zm20MfRNsVSIuG7A3biHZ6Fw(j7HgbsXoUDfzcSkmniPu9w6),qpFY4hAwolV3,s7FnXZYOgexlH2MPb8BJck1AKv9=1000)
		if RXyCOlWBw7Pzmq3uo9f8jFe:
			s7FnXZYOgexlH2MPb8BJck1AKv9.sleep(2)
			for j7HgbsXoUDfzcSkmniPu9w6 in OjJ9kzWMGHwKfuvbcsLqTgUBZ: qqQ8sTZ5BaCOKxGPblkzvwcnEgfYe[j7HgbsXoUDfzcSkmniPu9w6].join(10)
			s7FnXZYOgexlH2MPb8BJck1AKv9.sleep(2)
		for j7HgbsXoUDfzcSkmniPu9w6 in OjJ9kzWMGHwKfuvbcsLqTgUBZ:
			try: qg4HsMCAcGWP7dZuv,bbieYx6KO2EHAmJj0G,TqMRtYCifVH46FuUgh = pPbuMH5hy6BSXzEaDGn(j7HgbsXoUDfzcSkmniPu9w6)
			except: continue
			for XI502WMVdlkDUH in i4bFG3rKE6.menuItemsLIST:
				lQnA93TCSoqKwIMJNz8L,mMgEh8S9xkCA5atcIP4GWOJlpDdKQ,WWowRmHkj1ZAO2SUhtNvdrcKa9E6C,ZyiMa3BXVk2xWG0b,BvbuigUeoJLnTaN2qWxQ415AtYMK9I,i02wfPp5EM,HY7yaJeI89xE56sbTjdBRZPDwQKFX,AArDKw6baWehCSOz7,uu5WqOEaRZIibszwTc6t1nmLfAj = XI502WMVdlkDUH
				if TqMRtYCifVH46FuUgh in mMgEh8S9xkCA5atcIP4GWOJlpDdKQ:
					if 'IPTV-' in j7HgbsXoUDfzcSkmniPu9w6 and (239>=ZyiMa3BXVk2xWG0b>=230 or 289>=ZyiMa3BXVk2xWG0b>=280):
						if XI502WMVdlkDUH in d295dLt7HerXCopPlNhKBGYIFWaVjD['IPTV-LIVE']: continue
						if XI502WMVdlkDUH in d295dLt7HerXCopPlNhKBGYIFWaVjD['IPTV-MOVIES']: continue
						if XI502WMVdlkDUH in d295dLt7HerXCopPlNhKBGYIFWaVjD['IPTV-SERIES']: continue
						if 'صفحة' not in mMgEh8S9xkCA5atcIP4GWOJlpDdKQ:
							if   lQnA93TCSoqKwIMJNz8L=='live': j7HgbsXoUDfzcSkmniPu9w6 = 'IPTV-LIVE'
							elif lQnA93TCSoqKwIMJNz8L=='video': j7HgbsXoUDfzcSkmniPu9w6 = 'IPTV-MOVIES'
							elif lQnA93TCSoqKwIMJNz8L=='folder': j7HgbsXoUDfzcSkmniPu9w6 = 'IPTV-SERIES'
						else:
							if   'LIVE' in WWowRmHkj1ZAO2SUhtNvdrcKa9E6C: j7HgbsXoUDfzcSkmniPu9w6 = 'IPTV-LIVE'
							elif 'MOVIES' in WWowRmHkj1ZAO2SUhtNvdrcKa9E6C: j7HgbsXoUDfzcSkmniPu9w6 = 'IPTV-MOVIES'
							elif 'SERIES' in WWowRmHkj1ZAO2SUhtNvdrcKa9E6C: j7HgbsXoUDfzcSkmniPu9w6 = 'IPTV-SERIES'
					elif 'M3U-' in j7HgbsXoUDfzcSkmniPu9w6 and 729>=ZyiMa3BXVk2xWG0b>=710:
						if XI502WMVdlkDUH in d295dLt7HerXCopPlNhKBGYIFWaVjD['M3U-LIVE']: continue
						if XI502WMVdlkDUH in d295dLt7HerXCopPlNhKBGYIFWaVjD['M3U-MOVIES']: continue
						if XI502WMVdlkDUH in d295dLt7HerXCopPlNhKBGYIFWaVjD['M3U-SERIES']: continue
						if 'صفحة' not in mMgEh8S9xkCA5atcIP4GWOJlpDdKQ:
							if   lQnA93TCSoqKwIMJNz8L=='live': j7HgbsXoUDfzcSkmniPu9w6 = 'M3U-LIVE'
							elif lQnA93TCSoqKwIMJNz8L=='video': j7HgbsXoUDfzcSkmniPu9w6 = 'M3U-MOVIES'
							elif lQnA93TCSoqKwIMJNz8L=='folder': j7HgbsXoUDfzcSkmniPu9w6 = 'M3U-SERIES'
						else:
							if   'LIVE' in WWowRmHkj1ZAO2SUhtNvdrcKa9E6C: j7HgbsXoUDfzcSkmniPu9w6 = 'M3U-LIVE'
							elif 'MOVIES' in WWowRmHkj1ZAO2SUhtNvdrcKa9E6C: j7HgbsXoUDfzcSkmniPu9w6 = 'M3U-MOVIES'
							elif 'SERIES' in WWowRmHkj1ZAO2SUhtNvdrcKa9E6C: j7HgbsXoUDfzcSkmniPu9w6 = 'M3U-SERIES'
					elif 'YOUTUBE-' in j7HgbsXoUDfzcSkmniPu9w6 and 149>=ZyiMa3BXVk2xWG0b>=140:
						if XI502WMVdlkDUH in d295dLt7HerXCopPlNhKBGYIFWaVjD['YOUTUBE-CHANNELS']: continue
						if XI502WMVdlkDUH in d295dLt7HerXCopPlNhKBGYIFWaVjD['YOUTUBE-PLAYLISTS']: continue
						if XI502WMVdlkDUH in d295dLt7HerXCopPlNhKBGYIFWaVjD['YOUTUBE-VIDEOS']: continue
						if 'صفحة أخرى' in mMgEh8S9xkCA5atcIP4GWOJlpDdKQ or ':: ' in mMgEh8S9xkCA5atcIP4GWOJlpDdKQ:
							continue
						else:
							if   ZyiMa3BXVk2xWG0b==144 and 'USER' in mMgEh8S9xkCA5atcIP4GWOJlpDdKQ: j7HgbsXoUDfzcSkmniPu9w6 = 'YOUTUBE-CHANNELS'
							elif ZyiMa3BXVk2xWG0b==144 and 'CHNL' in mMgEh8S9xkCA5atcIP4GWOJlpDdKQ: j7HgbsXoUDfzcSkmniPu9w6 = 'YOUTUBE-CHANNELS'
							elif ZyiMa3BXVk2xWG0b==144 and 'LIST' in mMgEh8S9xkCA5atcIP4GWOJlpDdKQ: j7HgbsXoUDfzcSkmniPu9w6 = 'YOUTUBE-PLAYLISTS'
							elif ZyiMa3BXVk2xWG0b==143: j7HgbsXoUDfzcSkmniPu9w6 = 'YOUTUBE-VIDEOS'
							else: continue
					elif 'DAILYMOTION-' in j7HgbsXoUDfzcSkmniPu9w6 and 419>=ZyiMa3BXVk2xWG0b>=400:
						if XI502WMVdlkDUH in d295dLt7HerXCopPlNhKBGYIFWaVjD['DAILYMOTION-PLAYLISTS']: continue
						if XI502WMVdlkDUH in d295dLt7HerXCopPlNhKBGYIFWaVjD['DAILYMOTION-CHANNELS']: continue
						if XI502WMVdlkDUH in d295dLt7HerXCopPlNhKBGYIFWaVjD['DAILYMOTION-VIDEOS']: continue
						if XI502WMVdlkDUH in d295dLt7HerXCopPlNhKBGYIFWaVjD['DAILYMOTION-LIVES']: continue
						if XI502WMVdlkDUH in d295dLt7HerXCopPlNhKBGYIFWaVjD['DAILYMOTION-HASHTAGS']: continue
						if   ZyiMa3BXVk2xWG0b in [401,405]: j7HgbsXoUDfzcSkmniPu9w6 = 'DAILYMOTION-PLAYLISTS'
						elif ZyiMa3BXVk2xWG0b in [402,406]: j7HgbsXoUDfzcSkmniPu9w6 = 'DAILYMOTION-CHANNELS'
						elif ZyiMa3BXVk2xWG0b in [404]: j7HgbsXoUDfzcSkmniPu9w6 = 'DAILYMOTION-VIDEOS'
						elif ZyiMa3BXVk2xWG0b in [415]: j7HgbsXoUDfzcSkmniPu9w6 = 'DAILYMOTION-LIVES'
						elif ZyiMa3BXVk2xWG0b in [416]: j7HgbsXoUDfzcSkmniPu9w6 = 'DAILYMOTION-HASHTAGS'
					elif 'PANET-' in j7HgbsXoUDfzcSkmniPu9w6 and 39>=ZyiMa3BXVk2xWG0b>=30:
						if XI502WMVdlkDUH in d295dLt7HerXCopPlNhKBGYIFWaVjD['PANET-SERIES']: continue
						if XI502WMVdlkDUH in d295dLt7HerXCopPlNhKBGYIFWaVjD['PANET-MOVIES']: continue
						if   ZyiMa3BXVk2xWG0b in [32,39]: j7HgbsXoUDfzcSkmniPu9w6 = 'PANET-SERIES'
						elif ZyiMa3BXVk2xWG0b in [33,39]: j7HgbsXoUDfzcSkmniPu9w6 = 'PANET-MOVIES'
					elif 'IFILM-' in j7HgbsXoUDfzcSkmniPu9w6 and 29>=ZyiMa3BXVk2xWG0b>=20:
						if XI502WMVdlkDUH in d295dLt7HerXCopPlNhKBGYIFWaVjD['IFILM-ARABIC']: continue
						if XI502WMVdlkDUH in d295dLt7HerXCopPlNhKBGYIFWaVjD['IFILM-ENGLISH']: continue
						if   '/ar.' in WWowRmHkj1ZAO2SUhtNvdrcKa9E6C: j7HgbsXoUDfzcSkmniPu9w6 = 'IFILM-ARABIC'
						elif '/en.' in WWowRmHkj1ZAO2SUhtNvdrcKa9E6C: j7HgbsXoUDfzcSkmniPu9w6 = 'IFILM-ENGLISH'
					d295dLt7HerXCopPlNhKBGYIFWaVjD[j7HgbsXoUDfzcSkmniPu9w6].append(XI502WMVdlkDUH)
		for j7HgbsXoUDfzcSkmniPu9w6 in list(d295dLt7HerXCopPlNhKBGYIFWaVjD.keys()):
			OKzLvm15yTAHwbo[j7HgbsXoUDfzcSkmniPu9w6] = []
			ByPTldqYNpfARW9C7Qh24[j7HgbsXoUDfzcSkmniPu9w6] = []
			for lQnA93TCSoqKwIMJNz8L,mMgEh8S9xkCA5atcIP4GWOJlpDdKQ,WWowRmHkj1ZAO2SUhtNvdrcKa9E6C,ZyiMa3BXVk2xWG0b,BvbuigUeoJLnTaN2qWxQ415AtYMK9I,i02wfPp5EM,HY7yaJeI89xE56sbTjdBRZPDwQKFX,AArDKw6baWehCSOz7,uu5WqOEaRZIibszwTc6t1nmLfAj in d295dLt7HerXCopPlNhKBGYIFWaVjD[j7HgbsXoUDfzcSkmniPu9w6]:
				XI502WMVdlkDUH = (lQnA93TCSoqKwIMJNz8L,mMgEh8S9xkCA5atcIP4GWOJlpDdKQ,WWowRmHkj1ZAO2SUhtNvdrcKa9E6C,ZyiMa3BXVk2xWG0b,BvbuigUeoJLnTaN2qWxQ415AtYMK9I,i02wfPp5EM,HY7yaJeI89xE56sbTjdBRZPDwQKFX,AArDKw6baWehCSOz7,uu5WqOEaRZIibszwTc6t1nmLfAj)
				if 'صفحة' in mMgEh8S9xkCA5atcIP4GWOJlpDdKQ and lQnA93TCSoqKwIMJNz8L=='folder': ByPTldqYNpfARW9C7Qh24[j7HgbsXoUDfzcSkmniPu9w6].append(XI502WMVdlkDUH)
				else: OKzLvm15yTAHwbo[j7HgbsXoUDfzcSkmniPu9w6].append(XI502WMVdlkDUH)
		IIbJ9wGi4z8,rrAHICc8GsaRjz1tdKUnfkwSemZ = [],[]
		jdoGiRX6SpfJzVIPAueb8M5Ys = list(OKzLvm15yTAHwbo.keys())
		q30elgHcyPKrSVpbsiIn5G = uArTHUNiXlYWROV9DmgvoGFbL8M(jdoGiRX6SpfJzVIPAueb8M5Ys)
		lLGMSJOP5TI = []
		for j7HgbsXoUDfzcSkmniPu9w6 in q30elgHcyPKrSVpbsiIn5G:
			if isinstance(j7HgbsXoUDfzcSkmniPu9w6,tuple):
				lLGMSJOP5TI = [j7HgbsXoUDfzcSkmniPu9w6]
				continue
			if j7HgbsXoUDfzcSkmniPu9w6 not in OjJ9kzWMGHwKfuvbcsLqTgUBZ: continue
			if OKzLvm15yTAHwbo[j7HgbsXoUDfzcSkmniPu9w6]:
				KKUnqrXJhdtgGa9B06blOTfzMQLouA = nqTpa5zm20MfRNsVSIuG7A3biHZ6Fw(j7HgbsXoUDfzcSkmniPu9w6)
				PICeQ5j3f4qzAJamNDKVZtl = [('link',IQ2KCmObsTGuiRdEzt931a40jLg+'===== '+KKUnqrXJhdtgGa9B06blOTfzMQLouA+' ====='+fF4lt9zWYxXLKZVyAco82PgMj,qpFY4hAwolV3,9999,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3)]
				if 0: lGofQ1wvbcja5q0LOVS = FPW2hRyDdw5ZHv91aOAiJEQr3+' - '+'بحث'+mIsDke0oK5x1zSiOWbF9thGcA+KKUnqrXJhdtgGa9B06blOTfzMQLouA
				else: lGofQ1wvbcja5q0LOVS = 'بحث'+mIsDke0oK5x1zSiOWbF9thGcA+KKUnqrXJhdtgGa9B06blOTfzMQLouA+' - '+FPW2hRyDdw5ZHv91aOAiJEQr3
				if len(OKzLvm15yTAHwbo[j7HgbsXoUDfzcSkmniPu9w6])<8: B4UrWXv8wqAa = []
				else:
					rmOyzukfs816Tc3JvVlE2IR = xupTj02bvy3O8R+lGofQ1wvbcja5q0LOVS+fF4lt9zWYxXLKZVyAco82PgMj
					B4UrWXv8wqAa = [('folder',u4MSPs0rwoyRkx+rmOyzukfs816Tc3JvVlE2IR,'closed_sites'+MtIBq23QjNrgDXvERnwhfa,542,qpFY4hAwolV3,j7HgbsXoUDfzcSkmniPu9w6,FPW2hRyDdw5ZHv91aOAiJEQr3,qpFY4hAwolV3,qpFY4hAwolV3)]
				QQMq0nyiG9RwTEaombI = OKzLvm15yTAHwbo[j7HgbsXoUDfzcSkmniPu9w6]+ByPTldqYNpfARW9C7Qh24[j7HgbsXoUDfzcSkmniPu9w6]
				tGSKhpNk9zw = lLGMSJOP5TI+PICeQ5j3f4qzAJamNDKVZtl+QQMq0nyiG9RwTEaombI[:7]+B4UrWXv8wqAa
				IIbJ9wGi4z8 += tGSKhpNk9zw
				RrQXIwcaCYsd = [('folder',u4MSPs0rwoyRkx+lGofQ1wvbcja5q0LOVS,'closed_sites'+MtIBq23QjNrgDXvERnwhfa,542,qpFY4hAwolV3,j7HgbsXoUDfzcSkmniPu9w6,FPW2hRyDdw5ZHv91aOAiJEQr3,qpFY4hAwolV3,qpFY4hAwolV3)]
				cu9sUlKHevGXy8x7IPADEb = lLGMSJOP5TI+RrQXIwcaCYsd
				rrAHICc8GsaRjz1tdKUnfkwSemZ += cu9sUlKHevGXy8x7IPADEb
				zOYMaQ0NgdiRVwDJXh8e(WoFsvbmUlDZp7PzRfdGknCV,'GLOBALSEARCH_DIVIDED'+K7oYy9vsPHeL8RzgV4DrFxipfuC,(j7HgbsXoUDfzcSkmniPu9w6,FPW2hRyDdw5ZHv91aOAiJEQr3),QQMq0nyiG9RwTEaombI,IZVKS7o3q0)
				lLGMSJOP5TI = []
		zOYMaQ0NgdiRVwDJXh8e(WoFsvbmUlDZp7PzRfdGknCV,'GLOBALSEARCH_DETAILED'+K7oYy9vsPHeL8RzgV4DrFxipfuC,FPW2hRyDdw5ZHv91aOAiJEQr3,IIbJ9wGi4z8,IZVKS7o3q0)
		mlykPoGXbJIjFnarp9KihxfN(WoFsvbmUlDZp7PzRfdGknCV,'GLOBALSEARCH_SPLITTED'+K7oYy9vsPHeL8RzgV4DrFxipfuC,FPW2hRyDdw5ZHv91aOAiJEQr3)
		zOYMaQ0NgdiRVwDJXh8e(WoFsvbmUlDZp7PzRfdGknCV,'GLOBALSEARCH_SPLITTED'+K7oYy9vsPHeL8RzgV4DrFxipfuC,u4MSPs0rwoyRkx+FPW2hRyDdw5ZHv91aOAiJEQr3,rrAHICc8GsaRjz1tdKUnfkwSemZ,IZVKS7o3q0)
		iG7Rz2kmn0x1yLNMV3u8O(qpFY4hAwolV3,qpFY4hAwolV3,GLTtERWbHnFuy4PCp,'البحث الجماعي انتهى بنجاح \n\n تم تخزين النتائج في كاش البرنامج لمدة ثلاثين يوم حتى تستطيع العودة إليها بدون عمل بحث جديد')
		tlZsShHQEjMN6n2i1qYIv = rrAHICc8GsaRjz1tdKUnfkwSemZ if to89WjGVaPXupkEwvJmCMiexYU36=='listed_sites'+MtIBq23QjNrgDXvERnwhfa and rrAHICc8GsaRjz1tdKUnfkwSemZ else IIbJ9wGi4z8
	if to89WjGVaPXupkEwvJmCMiexYU36 in ['listed_sites'+MtIBq23QjNrgDXvERnwhfa,'opened_sites'+MtIBq23QjNrgDXvERnwhfa,'closed_sites'+MtIBq23QjNrgDXvERnwhfa]:
		for lQnA93TCSoqKwIMJNz8L,mMgEh8S9xkCA5atcIP4GWOJlpDdKQ,WWowRmHkj1ZAO2SUhtNvdrcKa9E6C,ZyiMa3BXVk2xWG0b,BvbuigUeoJLnTaN2qWxQ415AtYMK9I,i02wfPp5EM,HY7yaJeI89xE56sbTjdBRZPDwQKFX,AArDKw6baWehCSOz7,uu5WqOEaRZIibszwTc6t1nmLfAj in tlZsShHQEjMN6n2i1qYIv:
			if to89WjGVaPXupkEwvJmCMiexYU36 in ['listed_sites'+MtIBq23QjNrgDXvERnwhfa,'opened_sites'+MtIBq23QjNrgDXvERnwhfa] and 'صفحة' in mMgEh8S9xkCA5atcIP4GWOJlpDdKQ and lQnA93TCSoqKwIMJNz8L=='folder': continue
			x3WSXnKyPhjqfHG2UrtQs(lQnA93TCSoqKwIMJNz8L,mMgEh8S9xkCA5atcIP4GWOJlpDdKQ,WWowRmHkj1ZAO2SUhtNvdrcKa9E6C,ZyiMa3BXVk2xWG0b,BvbuigUeoJLnTaN2qWxQ415AtYMK9I,i02wfPp5EM,HY7yaJeI89xE56sbTjdBRZPDwQKFX,AArDKw6baWehCSOz7,uu5WqOEaRZIibszwTc6t1nmLfAj)
	nGRXot8mU9Qa2Dd(dND7uS6bknRj82EOIX0iyUxAscl,dND7uS6bknRj82EOIX0iyUxAscl,dND7uS6bknRj82EOIX0iyUxAscl)
	return
def ELR4V5Crpen2MljdZxJ7fvGykFs8W1(search):
	q30elgHcyPKrSVpbsiIn5G = uArTHUNiXlYWROV9DmgvoGFbL8M(OOaSbLh4fmdBoy95V)
	for j7HgbsXoUDfzcSkmniPu9w6 in q30elgHcyPKrSVpbsiIn5G:
		if '-' in j7HgbsXoUDfzcSkmniPu9w6: continue
		if isinstance(j7HgbsXoUDfzcSkmniPu9w6,tuple):
			i4bFG3rKE6.menuItemsLIST.append(j7HgbsXoUDfzcSkmniPu9w6)
			continue
		qg4HsMCAcGWP7dZuv,bbieYx6KO2EHAmJj0G,TqMRtYCifVH46FuUgh = pPbuMH5hy6BSXzEaDGn(j7HgbsXoUDfzcSkmniPu9w6)
		name = nqTpa5zm20MfRNsVSIuG7A3biHZ6Fw(j7HgbsXoUDfzcSkmniPu9w6)+' - '+search
		x3WSXnKyPhjqfHG2UrtQs('folder',TqMRtYCifVH46FuUgh+name,j7HgbsXoUDfzcSkmniPu9w6,548,'','',search)
	return
def iYSdKM46W5GDUVnmesZBy7(j7HgbsXoUDfzcSkmniPu9w6,search):
	qg4HsMCAcGWP7dZuv,bbieYx6KO2EHAmJj0G,TqMRtYCifVH46FuUgh = pPbuMH5hy6BSXzEaDGn(j7HgbsXoUDfzcSkmniPu9w6)
	bbieYx6KO2EHAmJj0G(search)
	return
def aInVWv10KNmCO7Tk2ueBUPLqMxDwz():
	iG7Rz2kmn0x1yLNMV3u8O('','',GLTtERWbHnFuy4PCp,'هذا البحث يستخدم محركات البحث الصغيرة الموجودة في كل موقع من مواقع البرنامج .. ونتائج هذا البحث تعتمد على دقة وفعالية وبرمجة كل موقع منها\n\nللأسف هذه المحركات الصغيرة لا تفهم جميع تفاصيل الفيديوهات ولا تفهم طريقة تفكير البشر ولا تستطيع إصلاح الأخطاء الإملائية .. ولهذا هي تحتاج دقة كبيرة جدا في اختيار وكتابة كلمات البحث المناسبة الصحيحة الدقيقة حتى تجد لك طلبك')
	return
def TGoRe1HgQ0Ln7IckFxAKE4XbapwPU(FPW2hRyDdw5ZHv91aOAiJEQr3=qpFY4hAwolV3):
	v9hig4t8jT,ZZCk6FGHRa8,showDialogs = LLm3sBXHPcnTDxdE5gt6hz0Wkp(FPW2hRyDdw5ZHv91aOAiJEQr3)
	if not v9hig4t8jT:
		v9hig4t8jT = jXgARlWMLVFUBnvmZwI2o5()
		if not v9hig4t8jT: return
		v9hig4t8jT = v9hig4t8jT.lower()
	LLvyStW429DEZKlA(k8kdUSxohLVljnrY,lTW9p1v7uPfOxB(Q8Q0IDc6PLZajJAdTntKUmSGXz)+'   Search For: [ '+v9hig4t8jT+' ]')
	K7m9Otk3h1VYIN8rcP6jp2 = v9hig4t8jT+ZZCk6FGHRa8
	if 0: H3CMwgRr9Bkf8qj1OTvVWp,BoVz38peOtwnXF9Dry6f15 = v9hig4t8jT+' - ',qpFY4hAwolV3
	else: H3CMwgRr9Bkf8qj1OTvVWp,BoVz38peOtwnXF9Dry6f15 = qpFY4hAwolV3,' - '+v9hig4t8jT
	x3WSXnKyPhjqfHG2UrtQs('link',xupTj02bvy3O8R+'مواقع سيرفرات خاصة - قليلة المشاكل'+fF4lt9zWYxXLKZVyAco82PgMj,qpFY4hAwolV3,157)
	x3WSXnKyPhjqfHG2UrtQs('folder','_M3U_'+H3CMwgRr9Bkf8qj1OTvVWp+'بحث M3U'+BoVz38peOtwnXF9Dry6f15,qpFY4hAwolV3,719,qpFY4hAwolV3,qpFY4hAwolV3,K7m9Otk3h1VYIN8rcP6jp2)
	x3WSXnKyPhjqfHG2UrtQs('folder','_IPT_'+H3CMwgRr9Bkf8qj1OTvVWp+'بحث IPTV'+BoVz38peOtwnXF9Dry6f15,qpFY4hAwolV3,239,qpFY4hAwolV3,qpFY4hAwolV3,K7m9Otk3h1VYIN8rcP6jp2)
	x3WSXnKyPhjqfHG2UrtQs('folder','_BKR_'+H3CMwgRr9Bkf8qj1OTvVWp+'بحث موقع بكرا'+BoVz38peOtwnXF9Dry6f15,qpFY4hAwolV3,379,qpFY4hAwolV3,qpFY4hAwolV3,K7m9Otk3h1VYIN8rcP6jp2)
	x3WSXnKyPhjqfHG2UrtQs('folder','_ART_'+H3CMwgRr9Bkf8qj1OTvVWp+'بحث موقع تونز عربية'+BoVz38peOtwnXF9Dry6f15,qpFY4hAwolV3,739,qpFY4hAwolV3,qpFY4hAwolV3,K7m9Otk3h1VYIN8rcP6jp2)
	x3WSXnKyPhjqfHG2UrtQs('folder','_KRB_'+H3CMwgRr9Bkf8qj1OTvVWp+'بحث موقع قناة كربلاء'+BoVz38peOtwnXF9Dry6f15,qpFY4hAwolV3,329,qpFY4hAwolV3,qpFY4hAwolV3,K7m9Otk3h1VYIN8rcP6jp2)
	x3WSXnKyPhjqfHG2UrtQs('folder','_FH2_'+H3CMwgRr9Bkf8qj1OTvVWp+'بحث موقع فاصل الثاني'+BoVz38peOtwnXF9Dry6f15,qpFY4hAwolV3,599,qpFY4hAwolV3,qpFY4hAwolV3,K7m9Otk3h1VYIN8rcP6jp2)
	x3WSXnKyPhjqfHG2UrtQs('folder','_KTV_'+H3CMwgRr9Bkf8qj1OTvVWp+'بحث موقع كتكوت تيفي'+BoVz38peOtwnXF9Dry6f15,qpFY4hAwolV3,819,qpFY4hAwolV3,qpFY4hAwolV3,K7m9Otk3h1VYIN8rcP6jp2)
	x3WSXnKyPhjqfHG2UrtQs('folder','_EB1_'+H3CMwgRr9Bkf8qj1OTvVWp+'بحث موقع ايجي بيست 1'+BoVz38peOtwnXF9Dry6f15,qpFY4hAwolV3,779,qpFY4hAwolV3,qpFY4hAwolV3,K7m9Otk3h1VYIN8rcP6jp2)
	x3WSXnKyPhjqfHG2UrtQs('folder','_EB2_'+H3CMwgRr9Bkf8qj1OTvVWp+'بحث موقع ايجي بيست 2'+BoVz38peOtwnXF9Dry6f15,qpFY4hAwolV3,789,qpFY4hAwolV3,qpFY4hAwolV3,K7m9Otk3h1VYIN8rcP6jp2)
	x3WSXnKyPhjqfHG2UrtQs('folder','_IFL_'+H3CMwgRr9Bkf8qj1OTvVWp+'  بحث موقع قناة آي فيلم'+BoVz38peOtwnXF9Dry6f15+r1roOXYi7UQw9FLThzPEdD0ZlvAnRc,qpFY4hAwolV3,29,qpFY4hAwolV3,qpFY4hAwolV3,K7m9Otk3h1VYIN8rcP6jp2)
	x3WSXnKyPhjqfHG2UrtQs('folder','_AKO_'+H3CMwgRr9Bkf8qj1OTvVWp+'بحث موقع أكوام القديم'+BoVz38peOtwnXF9Dry6f15,qpFY4hAwolV3,79,qpFY4hAwolV3,qpFY4hAwolV3,K7m9Otk3h1VYIN8rcP6jp2)
	x3WSXnKyPhjqfHG2UrtQs('folder','_AKW_'+H3CMwgRr9Bkf8qj1OTvVWp+'بحث موقع أكوام الجديد'+BoVz38peOtwnXF9Dry6f15,qpFY4hAwolV3,249,qpFY4hAwolV3,qpFY4hAwolV3,K7m9Otk3h1VYIN8rcP6jp2)
	x3WSXnKyPhjqfHG2UrtQs('folder','_MRF_'+H3CMwgRr9Bkf8qj1OTvVWp+'بحث موقع قناة المعارف'+BoVz38peOtwnXF9Dry6f15,qpFY4hAwolV3,49,qpFY4hAwolV3,qpFY4hAwolV3,K7m9Otk3h1VYIN8rcP6jp2)
	x3WSXnKyPhjqfHG2UrtQs('folder','_SHM_'+H3CMwgRr9Bkf8qj1OTvVWp+'بحث موقع شوف ماكس'+BoVz38peOtwnXF9Dry6f15,qpFY4hAwolV3,59,qpFY4hAwolV3,qpFY4hAwolV3,K7m9Otk3h1VYIN8rcP6jp2)
	x3WSXnKyPhjqfHG2UrtQs('link',xupTj02bvy3O8R+'مواقع سيرفرات خاصة وعامة - كثيرة المشاكل'+fF4lt9zWYxXLKZVyAco82PgMj,qpFY4hAwolV3,157)
	x3WSXnKyPhjqfHG2UrtQs('folder','_LRZ_'+H3CMwgRr9Bkf8qj1OTvVWp+'بحث موقع لاروزا'+BoVz38peOtwnXF9Dry6f15,qpFY4hAwolV3,709,qpFY4hAwolV3,qpFY4hAwolV3,K7m9Otk3h1VYIN8rcP6jp2)
	x3WSXnKyPhjqfHG2UrtQs('folder','_FJS_'+H3CMwgRr9Bkf8qj1OTvVWp+' بحث موقع فجر شو'+BoVz38peOtwnXF9Dry6f15+mIsDke0oK5x1zSiOWbF9thGcA,qpFY4hAwolV3,399,qpFY4hAwolV3,qpFY4hAwolV3,K7m9Otk3h1VYIN8rcP6jp2)
	x3WSXnKyPhjqfHG2UrtQs('folder','_TVF_'+H3CMwgRr9Bkf8qj1OTvVWp+'بحث موقع تيفي فان'+BoVz38peOtwnXF9Dry6f15,qpFY4hAwolV3,469,qpFY4hAwolV3,qpFY4hAwolV3,K7m9Otk3h1VYIN8rcP6jp2)
	x3WSXnKyPhjqfHG2UrtQs('folder','_LDN_'+H3CMwgRr9Bkf8qj1OTvVWp+'بحث موقع لودي نت'+BoVz38peOtwnXF9Dry6f15,qpFY4hAwolV3,459,qpFY4hAwolV3,qpFY4hAwolV3,K7m9Otk3h1VYIN8rcP6jp2)
	x3WSXnKyPhjqfHG2UrtQs('folder','_CMN_'+H3CMwgRr9Bkf8qj1OTvVWp+'بحث موقع سيما ناو'+BoVz38peOtwnXF9Dry6f15,qpFY4hAwolV3,309,qpFY4hAwolV3,qpFY4hAwolV3,K7m9Otk3h1VYIN8rcP6jp2)
	x3WSXnKyPhjqfHG2UrtQs('folder','_SHN_'+H3CMwgRr9Bkf8qj1OTvVWp+'بحث موقع شاهد نيوز'+BoVz38peOtwnXF9Dry6f15,qpFY4hAwolV3,589,qpFY4hAwolV3,qpFY4hAwolV3,K7m9Otk3h1VYIN8rcP6jp2+'_NODIALOGS_')
	x3WSXnKyPhjqfHG2UrtQs('folder','_ARS_'+H3CMwgRr9Bkf8qj1OTvVWp+'بحث موقع عرب سييد'+BoVz38peOtwnXF9Dry6f15,qpFY4hAwolV3,259,qpFY4hAwolV3,qpFY4hAwolV3,K7m9Otk3h1VYIN8rcP6jp2)
	x3WSXnKyPhjqfHG2UrtQs('folder','_CCB_'+H3CMwgRr9Bkf8qj1OTvVWp+'بحث موقع سيما كلوب'+BoVz38peOtwnXF9Dry6f15,qpFY4hAwolV3,829,qpFY4hAwolV3,qpFY4hAwolV3,K7m9Otk3h1VYIN8rcP6jp2)
	x3WSXnKyPhjqfHG2UrtQs('folder','_SH4_'+H3CMwgRr9Bkf8qj1OTvVWp+'بحث موقع شاهد فوريو'+BoVz38peOtwnXF9Dry6f15,qpFY4hAwolV3,119,qpFY4hAwolV3,qpFY4hAwolV3,K7m9Otk3h1VYIN8rcP6jp2+'_NODIALOGS_')
	x3WSXnKyPhjqfHG2UrtQs('folder','_SHT_'+H3CMwgRr9Bkf8qj1OTvVWp+'بحث موقع شوفها تيفي'+BoVz38peOtwnXF9Dry6f15,qpFY4hAwolV3,649,qpFY4hAwolV3,qpFY4hAwolV3,K7m9Otk3h1VYIN8rcP6jp2)
	x3WSXnKyPhjqfHG2UrtQs('folder','_WC1_'+H3CMwgRr9Bkf8qj1OTvVWp+'بحث موقع وي سيما 1'+BoVz38peOtwnXF9Dry6f15,qpFY4hAwolV3,569,qpFY4hAwolV3,qpFY4hAwolV3,K7m9Otk3h1VYIN8rcP6jp2)
	x3WSXnKyPhjqfHG2UrtQs('folder','_WC2_'+H3CMwgRr9Bkf8qj1OTvVWp+'بحث موقع وي سيما 2'+BoVz38peOtwnXF9Dry6f15,qpFY4hAwolV3,1009,qpFY4hAwolV3,qpFY4hAwolV3,K7m9Otk3h1VYIN8rcP6jp2)
	x3WSXnKyPhjqfHG2UrtQs('link',xupTj02bvy3O8R+'مواقع سيرفرات عامة - كثيرة المشاكل'+fF4lt9zWYxXLKZVyAco82PgMj,qpFY4hAwolV3,157)
	x3WSXnKyPhjqfHG2UrtQs('folder','_TKT_'+H3CMwgRr9Bkf8qj1OTvVWp+'بحث موقع تكات'+BoVz38peOtwnXF9Dry6f15,qpFY4hAwolV3,949,qpFY4hAwolV3,qpFY4hAwolV3,K7m9Otk3h1VYIN8rcP6jp2)
	x3WSXnKyPhjqfHG2UrtQs('folder','_FST_'+H3CMwgRr9Bkf8qj1OTvVWp+'بحث موقع فوستا'+BoVz38peOtwnXF9Dry6f15,qpFY4hAwolV3,609,qpFY4hAwolV3,qpFY4hAwolV3,K7m9Otk3h1VYIN8rcP6jp2)
	x3WSXnKyPhjqfHG2UrtQs('folder','_FBK_'+H3CMwgRr9Bkf8qj1OTvVWp+'بحث موقع فبركة'+BoVz38peOtwnXF9Dry6f15,qpFY4hAwolV3,629,qpFY4hAwolV3,qpFY4hAwolV3,K7m9Otk3h1VYIN8rcP6jp2)
	x3WSXnKyPhjqfHG2UrtQs('folder','_YQT_'+H3CMwgRr9Bkf8qj1OTvVWp+'بحث موقع ياقوت'+BoVz38peOtwnXF9Dry6f15,qpFY4hAwolV3,669,qpFY4hAwolV3,qpFY4hAwolV3,K7m9Otk3h1VYIN8rcP6jp2)
	x3WSXnKyPhjqfHG2UrtQs('folder','_SHB_'+H3CMwgRr9Bkf8qj1OTvVWp+'بحث موقع شبكتي'+BoVz38peOtwnXF9Dry6f15,qpFY4hAwolV3,969,qpFY4hAwolV3,qpFY4hAwolV3,K7m9Otk3h1VYIN8rcP6jp2)
	x3WSXnKyPhjqfHG2UrtQs('folder','_VRB_'+H3CMwgRr9Bkf8qj1OTvVWp+'بحث موقع فاربون'+BoVz38peOtwnXF9Dry6f15,qpFY4hAwolV3,879,qpFY4hAwolV3,qpFY4hAwolV3,K7m9Otk3h1VYIN8rcP6jp2)
	x3WSXnKyPhjqfHG2UrtQs('folder','_BRS_'+H3CMwgRr9Bkf8qj1OTvVWp+'بحث موقع برستيج'+BoVz38peOtwnXF9Dry6f15,qpFY4hAwolV3,659,qpFY4hAwolV3,qpFY4hAwolV3,K7m9Otk3h1VYIN8rcP6jp2)
	x3WSXnKyPhjqfHG2UrtQs('folder','_KRM_'+H3CMwgRr9Bkf8qj1OTvVWp+'بحث موقع كرمالك'+BoVz38peOtwnXF9Dry6f15,qpFY4hAwolV3,929,qpFY4hAwolV3,qpFY4hAwolV3,K7m9Otk3h1VYIN8rcP6jp2)
	x3WSXnKyPhjqfHG2UrtQs('folder','_ANZ_'+H3CMwgRr9Bkf8qj1OTvVWp+'بحث موقع انمي زد'+BoVz38peOtwnXF9Dry6f15,qpFY4hAwolV3,979,qpFY4hAwolV3,qpFY4hAwolV3,K7m9Otk3h1VYIN8rcP6jp2)
	x3WSXnKyPhjqfHG2UrtQs('folder','_FSK_'+H3CMwgRr9Bkf8qj1OTvVWp+'بحث موقع فارسكو'+BoVz38peOtwnXF9Dry6f15,qpFY4hAwolV3,999,qpFY4hAwolV3,qpFY4hAwolV3,K7m9Otk3h1VYIN8rcP6jp2)
	x3WSXnKyPhjqfHG2UrtQs('folder','_HLC_'+H3CMwgRr9Bkf8qj1OTvVWp+'بحث موقع هلا سيما'+BoVz38peOtwnXF9Dry6f15,qpFY4hAwolV3,89,qpFY4hAwolV3,qpFY4hAwolV3,K7m9Otk3h1VYIN8rcP6jp2)
	x3WSXnKyPhjqfHG2UrtQs('folder','_MST_'+H3CMwgRr9Bkf8qj1OTvVWp+'بحث موقع المصطبة'+BoVz38peOtwnXF9Dry6f15,qpFY4hAwolV3,869,qpFY4hAwolV3,qpFY4hAwolV3,K7m9Otk3h1VYIN8rcP6jp2)
	x3WSXnKyPhjqfHG2UrtQs('folder','_SNT_'+H3CMwgRr9Bkf8qj1OTvVWp+'بحث موقع شوف نت'+BoVz38peOtwnXF9Dry6f15,qpFY4hAwolV3,849,qpFY4hAwolV3,qpFY4hAwolV3,K7m9Otk3h1VYIN8rcP6jp2)
	x3WSXnKyPhjqfHG2UrtQs('folder','_DR7_'+H3CMwgRr9Bkf8qj1OTvVWp+'بحث موقع دراما صح'+BoVz38peOtwnXF9Dry6f15,qpFY4hAwolV3,689,qpFY4hAwolV3,qpFY4hAwolV3,K7m9Otk3h1VYIN8rcP6jp2)
	x3WSXnKyPhjqfHG2UrtQs('folder','_CFR_'+H3CMwgRr9Bkf8qj1OTvVWp+'بحث موقع سيما فري'+BoVz38peOtwnXF9Dry6f15,qpFY4hAwolV3,839,qpFY4hAwolV3,qpFY4hAwolV3,K7m9Otk3h1VYIN8rcP6jp2)
	x3WSXnKyPhjqfHG2UrtQs('folder','_CMF_'+H3CMwgRr9Bkf8qj1OTvVWp+'بحث موقع سيما فانز'+BoVz38peOtwnXF9Dry6f15,qpFY4hAwolV3,99,qpFY4hAwolV3,qpFY4hAwolV3,K7m9Otk3h1VYIN8rcP6jp2)
	x3WSXnKyPhjqfHG2UrtQs('folder','_CML_'+H3CMwgRr9Bkf8qj1OTvVWp+'بحث موقع سيما لايت'+BoVz38peOtwnXF9Dry6f15,qpFY4hAwolV3,479,qpFY4hAwolV3,qpFY4hAwolV3,K7m9Otk3h1VYIN8rcP6jp2)
	x3WSXnKyPhjqfHG2UrtQs('folder','_C4H_'+H3CMwgRr9Bkf8qj1OTvVWp+'بحث موقع سيما 400'+BoVz38peOtwnXF9Dry6f15,qpFY4hAwolV3,699,qpFY4hAwolV3,qpFY4hAwolV3,K7m9Otk3h1VYIN8rcP6jp2)
	x3WSXnKyPhjqfHG2UrtQs('folder','_ABD_'+H3CMwgRr9Bkf8qj1OTvVWp+'بحث موقع سيما عبدو'+BoVz38peOtwnXF9Dry6f15,qpFY4hAwolV3,559,qpFY4hAwolV3,qpFY4hAwolV3,K7m9Otk3h1VYIN8rcP6jp2)
	x3WSXnKyPhjqfHG2UrtQs('folder','_AKT_'+H3CMwgRr9Bkf8qj1OTvVWp+'بحث موقع اكوام تيوب'+BoVz38peOtwnXF9Dry6f15,qpFY4hAwolV3,859,qpFY4hAwolV3,qpFY4hAwolV3,K7m9Otk3h1VYIN8rcP6jp2)
	x3WSXnKyPhjqfHG2UrtQs('folder','_DCF_'+H3CMwgRr9Bkf8qj1OTvVWp+'بحث موقع دراما كافيه'+BoVz38peOtwnXF9Dry6f15,qpFY4hAwolV3,939,qpFY4hAwolV3,qpFY4hAwolV3,K7m9Otk3h1VYIN8rcP6jp2)
	x3WSXnKyPhjqfHG2UrtQs('folder','_FTV_'+H3CMwgRr9Bkf8qj1OTvVWp+'بحث موقع فوشار تيفي'+BoVz38peOtwnXF9Dry6f15,qpFY4hAwolV3,919,qpFY4hAwolV3,qpFY4hAwolV3,K7m9Otk3h1VYIN8rcP6jp2)
	x3WSXnKyPhjqfHG2UrtQs('folder','_CWB_'+H3CMwgRr9Bkf8qj1OTvVWp+'بحث موقع سيما وبس'+BoVz38peOtwnXF9Dry6f15,qpFY4hAwolV3,989,qpFY4hAwolV3,qpFY4hAwolV3,K7m9Otk3h1VYIN8rcP6jp2)
	x3WSXnKyPhjqfHG2UrtQs('folder','_AHK_'+H3CMwgRr9Bkf8qj1OTvVWp+'بحث موقع أهواك تيفي'+BoVz38peOtwnXF9Dry6f15,qpFY4hAwolV3,619,qpFY4hAwolV3,qpFY4hAwolV3,K7m9Otk3h1VYIN8rcP6jp2)
	x3WSXnKyPhjqfHG2UrtQs('folder','_SRT_'+H3CMwgRr9Bkf8qj1OTvVWp+'بحث موقع سيريس تايم'+BoVz38peOtwnXF9Dry6f15,qpFY4hAwolV3,899,qpFY4hAwolV3,qpFY4hAwolV3,K7m9Otk3h1VYIN8rcP6jp2)
	x3WSXnKyPhjqfHG2UrtQs('folder','_FVD_'+H3CMwgRr9Bkf8qj1OTvVWp+'بحث موقع فوشار فيديو'+BoVz38peOtwnXF9Dry6f15,qpFY4hAwolV3,909,qpFY4hAwolV3,qpFY4hAwolV3,K7m9Otk3h1VYIN8rcP6jp2)
	x3WSXnKyPhjqfHG2UrtQs('folder','_C4P_'+H3CMwgRr9Bkf8qj1OTvVWp+'بحث موقع سيما فور بي'+BoVz38peOtwnXF9Dry6f15,qpFY4hAwolV3,889,qpFY4hAwolV3,qpFY4hAwolV3,K7m9Otk3h1VYIN8rcP6jp2)
	x3WSXnKyPhjqfHG2UrtQs('folder','_EB4_'+H3CMwgRr9Bkf8qj1OTvVWp+'بحث موقع ايجي بيست 4'+BoVz38peOtwnXF9Dry6f15,qpFY4hAwolV3,809,qpFY4hAwolV3,qpFY4hAwolV3,K7m9Otk3h1VYIN8rcP6jp2)
	x3WSXnKyPhjqfHG2UrtQs('link',xupTj02bvy3O8R+'مواقع سيرفرات خاصة - قليلة المشاكل'+fF4lt9zWYxXLKZVyAco82PgMj,qpFY4hAwolV3,157)
	x3WSXnKyPhjqfHG2UrtQs('folder','_YUT_'+H3CMwgRr9Bkf8qj1OTvVWp+'بحث موقع يوتيوب'+BoVz38peOtwnXF9Dry6f15,qpFY4hAwolV3,149,qpFY4hAwolV3,qpFY4hAwolV3,K7m9Otk3h1VYIN8rcP6jp2)
	x3WSXnKyPhjqfHG2UrtQs('folder','_DLM_'+H3CMwgRr9Bkf8qj1OTvVWp+'بحث موقع دايلي موشن'+BoVz38peOtwnXF9Dry6f15,qpFY4hAwolV3,409,qpFY4hAwolV3,qpFY4hAwolV3,K7m9Otk3h1VYIN8rcP6jp2)
	return