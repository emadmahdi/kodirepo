# -*- coding: utf-8 -*-
import sys as TSRUP0dExYGQg
mgNMJhrjcq1xb = TSRUP0dExYGQg.version_info [0] == 2
lQJvf8UXo2de9gjCatY4yH = 2048
YuTB2OjotvlR = 7
def kk0DKyarxq9eS1zwGLMFQTZN35dj (neqP2if8IOJ50aNKcCBLrXdZk):
	global sWerUpk6nQwT7zY43
	vxdNQUujz7ZFV4rtOSK2 = ord (neqP2if8IOJ50aNKcCBLrXdZk [-1])
	yyshZX35KO7JodYjD9qVib6 = neqP2if8IOJ50aNKcCBLrXdZk [:-1]
	fuKReXJ3HPIAU7c = vxdNQUujz7ZFV4rtOSK2 % len (yyshZX35KO7JodYjD9qVib6)
	EEFQdvXog7LPC4Sie0jDkUKxn6M = yyshZX35KO7JodYjD9qVib6 [:fuKReXJ3HPIAU7c] + yyshZX35KO7JodYjD9qVib6 [fuKReXJ3HPIAU7c:]
	if mgNMJhrjcq1xb:
		Clh5YS0XPue68EgT4Uq17GL = unicode () .join ([unichr (ord (AsGVDZFgmuH06jviYrWXTz) - lQJvf8UXo2de9gjCatY4yH - (XvhDIL4ZpzaPs91WkoGnedCEA2rt + vxdNQUujz7ZFV4rtOSK2) % YuTB2OjotvlR) for XvhDIL4ZpzaPs91WkoGnedCEA2rt, AsGVDZFgmuH06jviYrWXTz in enumerate (EEFQdvXog7LPC4Sie0jDkUKxn6M)])
	else:
		Clh5YS0XPue68EgT4Uq17GL = str () .join ([chr (ord (AsGVDZFgmuH06jviYrWXTz) - lQJvf8UXo2de9gjCatY4yH - (XvhDIL4ZpzaPs91WkoGnedCEA2rt + vxdNQUujz7ZFV4rtOSK2) % YuTB2OjotvlR) for XvhDIL4ZpzaPs91WkoGnedCEA2rt, AsGVDZFgmuH06jviYrWXTz in enumerate (EEFQdvXog7LPC4Sie0jDkUKxn6M)])
	return eval (Clh5YS0XPue68EgT4Uq17GL)
qoBMmfAWpFlK70xw8ZRh4naJ,lljaEqwTVtmKsQcOrbXxS5hgNH,aXqWLoTdVgME=kk0DKyarxq9eS1zwGLMFQTZN35dj,kk0DKyarxq9eS1zwGLMFQTZN35dj,kk0DKyarxq9eS1zwGLMFQTZN35dj
UVa3fJw7k6KM,fWoVd0Bmtkx,tQMjXKCA5dN4xq3beVIzaEoWkFLg=aXqWLoTdVgME,lljaEqwTVtmKsQcOrbXxS5hgNH,qoBMmfAWpFlK70xw8ZRh4naJ
viRJWOC5jsYe84,Ie5s2cBtSfdHjzQ4rA9kYlo6D18,sjtU6GZQg5XC2pH4=tQMjXKCA5dN4xq3beVIzaEoWkFLg,fWoVd0Bmtkx,UVa3fJw7k6KM
LZWMikPEB81KSGyxfJtUsCA,rNdBKI74fAklnoCZ6,BRWqdruz2A0=sjtU6GZQg5XC2pH4,Ie5s2cBtSfdHjzQ4rA9kYlo6D18,viRJWOC5jsYe84
CC1eY6yWZUwf2TkRvnp7EJ0AimjHBX,qqzwE6imYG4c2xojI,N3flV6EJsD5CzS=BRWqdruz2A0,rNdBKI74fAklnoCZ6,LZWMikPEB81KSGyxfJtUsCA
UUDAiytEL76RTmMYsuIz5evXB,IaBhDMJc17302LgSvyxd,ddiCzu6yahj5RtTISMJ48sNnZBU=N3flV6EJsD5CzS,qqzwE6imYG4c2xojI,CC1eY6yWZUwf2TkRvnp7EJ0AimjHBX
dJHDqiKf12TXlIzSLkGUuxg4MBs3A,l1DZAt9XNQjqE7YOdrz,l32dnTEOU1skGKqeBtI9hmo=ddiCzu6yahj5RtTISMJ48sNnZBU,IaBhDMJc17302LgSvyxd,UUDAiytEL76RTmMYsuIz5evXB
zYvEaigKWjoq50pXBLDbGJkFc,iNc3KxwErnQ,V3VlkhgjEF4n1erPXHcC0NOsfwyAJ=l32dnTEOU1skGKqeBtI9hmo,l1DZAt9XNQjqE7YOdrz,dJHDqiKf12TXlIzSLkGUuxg4MBs3A
tR1krDGPpO025fghMT3a7UnYj,c2RKu0xG1eC8MiohyE,RlOvin8YIGC2KZXJPk9m0acrMobUex=V3VlkhgjEF4n1erPXHcC0NOsfwyAJ,iNc3KxwErnQ,zYvEaigKWjoq50pXBLDbGJkFc
YY8UDX3MJhb91AHw7fg,ee86G9ladLHVbh5mikzCo,mmV2nucZ5Lpl6FO1JMPEqGoQKW=RlOvin8YIGC2KZXJPk9m0acrMobUex,c2RKu0xG1eC8MiohyE,tR1krDGPpO025fghMT3a7UnYj
DaFZHsThGmd0zv6e,kYDaz79TFlXoR,DiJ8CMuYH1daWyjehfN0L=mmV2nucZ5Lpl6FO1JMPEqGoQKW,ee86G9ladLHVbh5mikzCo,YY8UDX3MJhb91AHw7fg
from pSfaryIjBo import *
Q8Q0IDc6PLZajJAdTntKUmSGXz = lljaEqwTVtmKsQcOrbXxS5hgNH(u"ࠬࡘࡁࡏࡆࡒࡑࡘ࠭Ჭ")
wwSFijdVJn1QgHW = LZWMikPEB81KSGyxfJtUsCA(u"࠭࡟ࡍࡕࡗࡣࠬᲮ")
a3Rx5WAGMmZs9wcKf0bklr47XUNSD = wn4bG51vUENfaS0Zg
XSHMu4ZvifchKFP0LWBNr = qoBMmfAWpFlK70xw8ZRh4naJ(u"࠳࠳Ἑ")
def vTNE2Ck1sGnugJYW8y39aLcSH64U(ZyiMa3BXVk2xWG0b,url,HY7yaJeI89xE56sbTjdBRZPDwQKFX,i02wfPp5EM,uu5WqOEaRZIibszwTc6t1nmLfAj):
	try: LLcgQ6E12OZezYbh4CVdIa = str(uu5WqOEaRZIibszwTc6t1nmLfAj[rNdBKI74fAklnoCZ6(u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᲯ")])
	except: LLcgQ6E12OZezYbh4CVdIa = qpFY4hAwolV3
	if   ZyiMa3BXVk2xWG0b==rNdBKI74fAklnoCZ6(u"࠴࠺࠵Ἒ"): MOTjA5H9XFs = nRVAZc4Dp8PSrGU3xBk()
	elif ZyiMa3BXVk2xWG0b==IaBhDMJc17302LgSvyxd(u"࠵࠻࠷Ἓ"): MOTjA5H9XFs = uxrJZyKhizVD9w2qg(HY7yaJeI89xE56sbTjdBRZPDwQKFX)
	elif ZyiMa3BXVk2xWG0b==kYDaz79TFlXoR(u"࠶࠼࠲Ἔ"): MOTjA5H9XFs = KKRwGChAWfu3r5ljDa6X9(HY7yaJeI89xE56sbTjdBRZPDwQKFX,kYDaz79TFlXoR(u"࠶࠼࠲Ἔ"))
	elif ZyiMa3BXVk2xWG0b==RlOvin8YIGC2KZXJPk9m0acrMobUex(u"࠷࠶࠴Ἕ"): MOTjA5H9XFs = KKRwGChAWfu3r5ljDa6X9(HY7yaJeI89xE56sbTjdBRZPDwQKFX,RlOvin8YIGC2KZXJPk9m0acrMobUex(u"࠷࠶࠴Ἕ"))
	elif ZyiMa3BXVk2xWG0b==c2RKu0xG1eC8MiohyE(u"࠱࠷࠶἞"): MOTjA5H9XFs = MUaXV0oCuIH9Jp(HY7yaJeI89xE56sbTjdBRZPDwQKFX)
	elif ZyiMa3BXVk2xWG0b==BRWqdruz2A0(u"࠲࠸࠸἟"): MOTjA5H9XFs = aaZ5XPxOGs(url,HY7yaJeI89xE56sbTjdBRZPDwQKFX)
	elif ZyiMa3BXVk2xWG0b==fWoVd0Bmtkx(u"࠳࠹࠺ἠ"): MOTjA5H9XFs = lgo31uFExNRL9TykZ7zq(url,HY7yaJeI89xE56sbTjdBRZPDwQKFX)
	elif ZyiMa3BXVk2xWG0b==kYDaz79TFlXoR(u"࠴࠺࠼ἡ"): MOTjA5H9XFs = v2mnC8TQ95FJw(url,HY7yaJeI89xE56sbTjdBRZPDwQKFX)
	elif ZyiMa3BXVk2xWG0b==UVa3fJw7k6KM(u"࠵࠻࠾ἢ"): MOTjA5H9XFs = ZGR7nk61buVNB4XFgsELMc5aTiJm(url,HY7yaJeI89xE56sbTjdBRZPDwQKFX)
	elif ZyiMa3BXVk2xWG0b==viRJWOC5jsYe84(u"࠼࠼࠱ἣ"): MOTjA5H9XFs = BS48pV7GQ1It3yXDmTKbO6z9AeJk()
	elif ZyiMa3BXVk2xWG0b==CC1eY6yWZUwf2TkRvnp7EJ0AimjHBX(u"࠽࠶࠳ἤ"): MOTjA5H9XFs = ZZaTmKAQuS43L()
	elif ZyiMa3BXVk2xWG0b==ee86G9ladLHVbh5mikzCo(u"࠷࠷࠵ἥ"): MOTjA5H9XFs = gZPkjUz7NBJDtSvmMYof(LLcgQ6E12OZezYbh4CVdIa,HY7yaJeI89xE56sbTjdBRZPDwQKFX,i02wfPp5EM)
	elif ZyiMa3BXVk2xWG0b==qqzwE6imYG4c2xojI(u"࠸࠸࠷ἦ"): MOTjA5H9XFs = tO3K2vSfWHBRodCFlhDuVQ5JeI(LLcgQ6E12OZezYbh4CVdIa,HY7yaJeI89xE56sbTjdBRZPDwQKFX)
	elif ZyiMa3BXVk2xWG0b==N3flV6EJsD5CzS(u"࠹࠹࠹ἧ"): MOTjA5H9XFs = EgBG4hd8PjUtXrVzpybcSA5fuvlZk(LLcgQ6E12OZezYbh4CVdIa,HY7yaJeI89xE56sbTjdBRZPDwQKFX)
	else: MOTjA5H9XFs = ag8rjZo1Vz4IPdcOT
	return MOTjA5H9XFs
def nRVAZc4Dp8PSrGU3xBk():
	x3WSXnKyPhjqfHG2UrtQs(kYDaz79TFlXoR(u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᲰ"),tR1krDGPpO025fghMT3a7UnYj(u"ࠩๅ๊ํอสࠡฬ็ๅื๐่็ࠢ฼ุํอฦ๋หࠪᲱ"),qpFY4hAwolV3,V3VlkhgjEF4n1erPXHcC0NOsfwyAJ(u"࠴࠺࠶Ἠ"),qpFY4hAwolV3,qpFY4hAwolV3,IaBhDMJc17302LgSvyxd(u"ࠪࡣࡑࡏࡖࡆࡖ࡙ࡣࡤࡘࡁࡏࡆࡒࡑࡤࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩᲲ"))
	x3WSXnKyPhjqfHG2UrtQs(LZWMikPEB81KSGyxfJtUsCA(u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᲳ"),RlOvin8YIGC2KZXJPk9m0acrMobUex(u"่ࠬำๆࠢ฼ุํอฦ๋ࠩᲴ"),qpFY4hAwolV3,UVa3fJw7k6KM(u"࠵࠻࠸Ἡ"),qpFY4hAwolV3,qpFY4hAwolV3,qoBMmfAWpFlK70xw8ZRh4naJ(u"࠭࡟ࡔࡋࡗࡉࡘࡥ࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪᲵ"))
	x3WSXnKyPhjqfHG2UrtQs(dJHDqiKf12TXlIzSLkGUuxg4MBs3A(u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᲶ"),tR1krDGPpO025fghMT3a7UnYj(u"ࠨใํำ๏๎็ศฬࠣ฽ู๎วว์ฬࠫᲷ"),qpFY4hAwolV3,qqzwE6imYG4c2xojI(u"࠶࠼࠳Ἢ"),qpFY4hAwolV3,qpFY4hAwolV3,ee86G9ladLHVbh5mikzCo(u"ࠩࡢࡗࡎ࡚ࡅࡔࡡࡢࡖࡆࡔࡄࡐࡏࡢࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧᲸ"))
	x3WSXnKyPhjqfHG2UrtQs(kYDaz79TFlXoR(u"ࠪࡪࡴࡲࡤࡦࡴࠪᲹ"),Ie5s2cBtSfdHjzQ4rA9kYlo6D18(u"ࠫๆ๐ฯ๋๊๊หฯࠦศฮอࠣ฽ู๎วว์ࠪᲺ"),qpFY4hAwolV3,YY8UDX3MJhb91AHw7fg(u"࠷࠶࠵Ἣ"),qpFY4hAwolV3,qpFY4hAwolV3,sjtU6GZQg5XC2pH4(u"ࠬࡥࡓࡊࡖࡈࡗࡤࡥࡒࡂࡐࡇࡓࡒࡥ࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ᲻"))
	x3WSXnKyPhjqfHG2UrtQs(DaFZHsThGmd0zv6e(u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭᲼"),qqzwE6imYG4c2xojI(u"ࠧโ์า๎ํํวหࠢ฼ุํอฦ๋ห้๋ࠣࠦโิ็ࠪᲽ"),qpFY4hAwolV3,CC1eY6yWZUwf2TkRvnp7EJ0AimjHBX(u"࠷࠷࠵Ἤ"),qpFY4hAwolV3,qpFY4hAwolV3,fWoVd0Bmtkx(u"ࠨࡡࡖࡍ࡙ࡋࡓࡠࡡࡕࡅࡓࡊࡏࡎࡡࠪᲾ"))
	x3WSXnKyPhjqfHG2UrtQs(aXqWLoTdVgME(u"ࠩ࡯࡭ࡳࡱࠧᲿ"),xupTj02bvy3O8R+l1DZAt9XNQjqE7YOdrz(u"ࠪࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡࠩ᳀")+fF4lt9zWYxXLKZVyAco82PgMj,qpFY4hAwolV3,qoBMmfAWpFlK70xw8ZRh4naJ(u"࠺࠻࠼࠽Ἥ"))
	x3WSXnKyPhjqfHG2UrtQs(CC1eY6yWZUwf2TkRvnp7EJ0AimjHBX(u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ᳁"),DaFZHsThGmd0zv6e(u"่ࠬๆ้ษอࠤࡒ࠹ࡕࠡ฻ื์ฬฬ๊สࠩ᳂"),qpFY4hAwolV3,tQMjXKCA5dN4xq3beVIzaEoWkFLg(u"࠳࠹࠷Ἦ"),qpFY4hAwolV3,qpFY4hAwolV3,kYDaz79TFlXoR(u"࠭࡟ࡎ࠵ࡘࡣࡤࡒࡉࡗࡇࡢࡣࡗࡇࡎࡅࡑࡐࡣࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ᳃"))
	x3WSXnKyPhjqfHG2UrtQs(IaBhDMJc17302LgSvyxd(u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ᳄"),IaBhDMJc17302LgSvyxd(u"ࠨใํำ๏๎็ศฬࠣࡑ࠸ฺ࡛ࠠึ๋หห๐ษࠨ᳅"),qpFY4hAwolV3,ddiCzu6yahj5RtTISMJ48sNnZBU(u"࠴࠺࠸Ἧ"),qpFY4hAwolV3,qpFY4hAwolV3,l32dnTEOU1skGKqeBtI9hmo(u"ࠩࡢࡑ࠸࡛࡟ࡠࡘࡒࡈࡤࡥࡒࡂࡐࡇࡓࡒࡥ࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ᳆"))
	x3WSXnKyPhjqfHG2UrtQs(kYDaz79TFlXoR(u"ࠪࡪࡴࡲࡤࡦࡴࠪ᳇"),dJHDqiKf12TXlIzSLkGUuxg4MBs3A(u"ࠫ็ูๅࠡไ้์ฬะࠠࡎ࠵ࡘࠤ฾ฺ่ศศํࠫ᳈"),qpFY4hAwolV3,DaFZHsThGmd0zv6e(u"࠵࠻࠸ἰ"),qpFY4hAwolV3,qpFY4hAwolV3,UVa3fJw7k6KM(u"ࠬࡥࡍ࠴ࡗࡢࡣࡑࡏࡖࡆࡡࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭᳉"))
	x3WSXnKyPhjqfHG2UrtQs(fWoVd0Bmtkx(u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭᳊"),fWoVd0Bmtkx(u"ࠧใี่ࠤๆ๐ฯ๋๊ࠣࡑ࠸ฺ࡛ࠠึ๋หห๐ࠧ᳋"),qpFY4hAwolV3,UVa3fJw7k6KM(u"࠶࠼࠲ἱ"),qpFY4hAwolV3,qpFY4hAwolV3,c2RKu0xG1eC8MiohyE(u"ࠨࡡࡐ࠷࡚ࡥ࡟ࡗࡑࡇࡣࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ᳌"))
	x3WSXnKyPhjqfHG2UrtQs(kYDaz79TFlXoR(u"ࠩࡩࡳࡱࡪࡥࡳࠩ᳍"),iNc3KxwErnQ(u"ࠪๅ๏ี๊้้สฮࠥࡓ࠳ࡖࠢหัะูࠦี๊สส๏࠭᳎"),qpFY4hAwolV3,UVa3fJw7k6KM(u"࠷࠶࠵ἲ"),qpFY4hAwolV3,qpFY4hAwolV3,kYDaz79TFlXoR(u"ࠫࡤࡓ࠳ࡖࡡࡢࡖࡆࡔࡄࡐࡏࡢࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ᳏"))
	x3WSXnKyPhjqfHG2UrtQs(mmV2nucZ5Lpl6FO1JMPEqGoQKW(u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ᳐"),BRWqdruz2A0(u"࠭แ๋ัํ์์อสࠡࡏ࠶࡙ࠥ฿ิ้ษษ๎ฮࠦๅ็ࠢๅื๊࠭᳑"),qpFY4hAwolV3,l1DZAt9XNQjqE7YOdrz(u"࠷࠷࠷ἳ"),qpFY4hAwolV3,qpFY4hAwolV3,l1DZAt9XNQjqE7YOdrz(u"ࠧࡠࡏ࠶࡙ࡤࡥࡒࡂࡐࡇࡓࡒࡥ࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ᳒"))
	x3WSXnKyPhjqfHG2UrtQs(iNc3KxwErnQ(u"ࠨ࡮࡬ࡲࡰ࠭᳓"),xupTj02bvy3O8R+RlOvin8YIGC2KZXJPk9m0acrMobUex(u"ࠩࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠࠨ᳔")+fF4lt9zWYxXLKZVyAco82PgMj,qpFY4hAwolV3,N3flV6EJsD5CzS(u"࠺࠻࠼࠽ἴ"))
	x3WSXnKyPhjqfHG2UrtQs(fWoVd0Bmtkx(u"ࠪࡪࡴࡲࡤࡦࡴ᳕ࠪ"),zYvEaigKWjoq50pXBLDbGJkFc(u"ࠫ็์่ศฬࠣࡍࡕ࡚ࡖࠡ฻ื์ฬฬ๊ส᳖ࠩ"),qpFY4hAwolV3,mmV2nucZ5Lpl6FO1JMPEqGoQKW(u"࠳࠹࠷ἵ"),qpFY4hAwolV3,qpFY4hAwolV3,ddiCzu6yahj5RtTISMJ48sNnZBU(u"ࠬࡥࡉࡑࡖ࡙ࡣࡤࡒࡉࡗࡇࡢࡣࡗࡇࡎࡅࡑࡐࡣࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ᳗"))
	x3WSXnKyPhjqfHG2UrtQs(iNc3KxwErnQ(u"࠭ࡦࡰ࡮ࡧࡩࡷ᳘࠭"),mmV2nucZ5Lpl6FO1JMPEqGoQKW(u"ࠧโ์า๎ํํวหࠢࡌࡔ࡙࡜ฺࠠึ๋หห๐ษࠨ᳙"),qpFY4hAwolV3,tQMjXKCA5dN4xq3beVIzaEoWkFLg(u"࠴࠺࠸ἶ"),qpFY4hAwolV3,qpFY4hAwolV3,CC1eY6yWZUwf2TkRvnp7EJ0AimjHBX(u"ࠨࡡࡌࡔ࡙࡜࡟ࡠࡘࡒࡈࡤࡥࡒࡂࡐࡇࡓࡒࡥ࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ᳚"))
	x3WSXnKyPhjqfHG2UrtQs(c2RKu0xG1eC8MiohyE(u"ࠩࡩࡳࡱࡪࡥࡳࠩ᳛"),DaFZHsThGmd0zv6e(u"ࠪๆุ๋ࠠใ่๋หฯࠦࡉࡑࡖ࡙ࠤ฾ฺ่ศศํ᳜ࠫ"),qpFY4hAwolV3,UUDAiytEL76RTmMYsuIz5evXB(u"࠵࠻࠸ἷ"),qpFY4hAwolV3,qpFY4hAwolV3,mmV2nucZ5Lpl6FO1JMPEqGoQKW(u"ࠫࡤࡏࡐࡕࡘࡢࡣࡑࡏࡖࡆࡡࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ᳝࠭"))
	x3WSXnKyPhjqfHG2UrtQs(Ie5s2cBtSfdHjzQ4rA9kYlo6D18(u"ࠬ࡬࡯࡭ࡦࡨࡶ᳞ࠬ"),kYDaz79TFlXoR(u"࠭โิ็ࠣๅ๏ี๊้ࠢࡌࡔ࡙࡜ฺࠠึ๋หห๐᳟ࠧ"),qpFY4hAwolV3,dJHDqiKf12TXlIzSLkGUuxg4MBs3A(u"࠶࠼࠲Ἰ"),qpFY4hAwolV3,qpFY4hAwolV3,mmV2nucZ5Lpl6FO1JMPEqGoQKW(u"ࠧࡠࡋࡓࡘ࡛ࡥ࡟ࡗࡑࡇࡣࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ᳠"))
	x3WSXnKyPhjqfHG2UrtQs(fWoVd0Bmtkx(u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ᳡"),tQMjXKCA5dN4xq3beVIzaEoWkFLg(u"ࠩไ๎ิ๐่่ษอࠤࡎࡖࡔࡗࠢหัะูࠦี๊สส๏᳢࠭"),qpFY4hAwolV3,sjtU6GZQg5XC2pH4(u"࠷࠶࠵Ἱ"),qpFY4hAwolV3,qpFY4hAwolV3,Ie5s2cBtSfdHjzQ4rA9kYlo6D18(u"ࠪࡣࡎࡖࡔࡗࡡࡢࡖࡆࡔࡄࡐࡏࡢࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥ᳣ࠧ"))
	x3WSXnKyPhjqfHG2UrtQs(IaBhDMJc17302LgSvyxd(u"ࠫ࡫ࡵ࡬ࡥࡧࡵ᳤ࠫ"),UVa3fJw7k6KM(u"ࠬ็๊ะ์๋๋ฬะࠠࡊࡒࡗ࡚ࠥ฿ิ้ษษ๎ฮࠦๅ็ࠢๅื᳥๊࠭"),qpFY4hAwolV3,tR1krDGPpO025fghMT3a7UnYj(u"࠷࠷࠶Ἲ"),qpFY4hAwolV3,qpFY4hAwolV3,CC1eY6yWZUwf2TkRvnp7EJ0AimjHBX(u"࠭࡟ࡊࡒࡗ࡚ࡤࡥࡒࡂࡐࡇࡓࡒࡥ࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡ᳦ࠪ"))
	return
def BS48pV7GQ1It3yXDmTKbO6z9AeJk():
	x3WSXnKyPhjqfHG2UrtQs(YY8UDX3MJhb91AHw7fg(u"ࠧࡧࡱ࡯ࡨࡪࡸ᳧ࠧ"),iNc3KxwErnQ(u"ࠨࡡࡌࡔ࡙ࡥ᳨ࠧ")+RlOvin8YIGC2KZXJPk9m0acrMobUex(u"ࠩไ๎ิ๐่่ษอࠤัฺ๋๊ࠢࡌࡔ࡙࡜ࠧᳩ"),qpFY4hAwolV3,lljaEqwTVtmKsQcOrbXxS5hgNH(u"࠸࠸࠷Ἳ"))
	x3WSXnKyPhjqfHG2UrtQs(rNdBKI74fAklnoCZ6(u"ࠪࡰ࡮ࡴ࡫ࠨᳪ"),xupTj02bvy3O8R+DiJ8CMuYH1daWyjehfN0L(u"ࠫࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡࠩᳫ")+fF4lt9zWYxXLKZVyAco82PgMj,qpFY4hAwolV3,BRWqdruz2A0(u"࠻࠼࠽࠾Ἴ"))
	for LLcgQ6E12OZezYbh4CVdIa in range(mZi0S72jGoHpLO,v2ir6R7FZASfMOl4wqTLKBNupX5E+mZi0S72jGoHpLO):
		wwSFijdVJn1QgHW = kYDaz79TFlXoR(u"ࠬࡥࡉࡑࠩᳬ")+str(LLcgQ6E12OZezYbh4CVdIa)+aXqWLoTdVgME(u"࠭࡟ࠨ᳭")
		x3WSXnKyPhjqfHG2UrtQs(IaBhDMJc17302LgSvyxd(u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᳮ"),wwSFijdVJn1QgHW+UVa3fJw7k6KM(u"ࠨࠢไ๎ิ๐่่ษอࠤ๊าไะࠢࠪᳯ")+ppn5vq8QdBsEhckl[LLcgQ6E12OZezYbh4CVdIa],qpFY4hAwolV3,ddiCzu6yahj5RtTISMJ48sNnZBU(u"࠺࠺࠹Ἵ"),qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,{qqzwE6imYG4c2xojI(u"ࠩࡩࡳࡱࡪࡥࡳࠩᳰ"):LLcgQ6E12OZezYbh4CVdIa})
	return
def ZZaTmKAQuS43L():
	x3WSXnKyPhjqfHG2UrtQs(UVa3fJw7k6KM(u"ࠪࡪࡴࡲࡤࡦࡴࠪᳱ"),DiJ8CMuYH1daWyjehfN0L(u"ࠫࡤࡓ࠳ࡖࡡࠪᳲ")+UVa3fJw7k6KM(u"ࠬ็๊ะ์๋๋ฬะࠠอ็ํ฽ࠥࡓ࠳ࡖࠩᳳ"),qpFY4hAwolV3,DaFZHsThGmd0zv6e(u"࠻࠻࠻Ἶ"))
	x3WSXnKyPhjqfHG2UrtQs(N3flV6EJsD5CzS(u"࠭࡬ࡪࡰ࡮ࠫ᳴"),xupTj02bvy3O8R+ee86G9ladLHVbh5mikzCo(u"ࠧ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࠬᳵ")+fF4lt9zWYxXLKZVyAco82PgMj,qpFY4hAwolV3,aXqWLoTdVgME(u"࠾࠿࠹࠺Ἷ"))
	for LLcgQ6E12OZezYbh4CVdIa in range(mZi0S72jGoHpLO,v2ir6R7FZASfMOl4wqTLKBNupX5E+mZi0S72jGoHpLO):
		wwSFijdVJn1QgHW = Ie5s2cBtSfdHjzQ4rA9kYlo6D18(u"ࠨࡡࡐ࡙ࠬᳶ")+str(LLcgQ6E12OZezYbh4CVdIa)+N3flV6EJsD5CzS(u"ࠩࡢࠫ᳷")
		x3WSXnKyPhjqfHG2UrtQs(DaFZHsThGmd0zv6e(u"ࠪࡪࡴࡲࡤࡦࡴࠪ᳸"),wwSFijdVJn1QgHW+rNdBKI74fAklnoCZ6(u"ࠫࠥ็๊ะ์๋๋ฬะࠠๆฮ็ำࠥ࠭᳹")+ppn5vq8QdBsEhckl[LLcgQ6E12OZezYbh4CVdIa],qpFY4hAwolV3,IaBhDMJc17302LgSvyxd(u"࠽࠶࠶ὀ"),qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,{sjtU6GZQg5XC2pH4(u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᳺ"):LLcgQ6E12OZezYbh4CVdIa})
	return
def sWIku5vdn6fhyDHcJLUNt1XzF(j7HgbsXoUDfzcSkmniPu9w6):
	global wlMAxqL7iZskWPJyaXfGhYzHg1T,jCGX4F5PMkgeAwTZnW
	qg4HsMCAcGWP7dZuv,bbieYx6KO2EHAmJj0G,TqMRtYCifVH46FuUgh = pPbuMH5hy6BSXzEaDGn(j7HgbsXoUDfzcSkmniPu9w6)
	try:
		if dJHDqiKf12TXlIzSLkGUuxg4MBs3A(u"࠭ࡉࡇࡋࡏࡑࠬ᳻") in j7HgbsXoUDfzcSkmniPu9w6: qg4HsMCAcGWP7dZuv(j7HgbsXoUDfzcSkmniPu9w6)
		else: qg4HsMCAcGWP7dZuv()
		fT84mlnYzEVbcPWBy2txS6uHIQhDC = ag8rjZo1Vz4IPdcOT
	except:
		XJwGq95IRv1CoWAx()
		fT84mlnYzEVbcPWBy2txS6uHIQhDC = gBExoceumj4y8bFW9hY2aNMVSr
	j7HgbsXoUDfzcSkmniPu9w6 = nqTpa5zm20MfRNsVSIuG7A3biHZ6Fw(j7HgbsXoUDfzcSkmniPu9w6)
	if fT84mlnYzEVbcPWBy2txS6uHIQhDC:
		t8yiLuJp3cBA6d1QE9x7eZ4fa(j7HgbsXoUDfzcSkmniPu9w6,fWoVd0Bmtkx(u"ࠧโึ็ࠤ้๊ริใࠪ᳼"),s7FnXZYOgexlH2MPb8BJck1AKv9=mmV2nucZ5Lpl6FO1JMPEqGoQKW(u"࠲࠱࠲࠳ὁ"))
		wlMAxqL7iZskWPJyaXfGhYzHg1T += mZi0S72jGoHpLO
		jCGX4F5PMkgeAwTZnW += Ie5s2cBtSfdHjzQ4rA9kYlo6D18(u"ࠨࠢ࠱ࠤࠬ᳽")+j7HgbsXoUDfzcSkmniPu9w6
	else: t8yiLuJp3cBA6d1QE9x7eZ4fa(j7HgbsXoUDfzcSkmniPu9w6,qpFY4hAwolV3,s7FnXZYOgexlH2MPb8BJck1AKv9=l1DZAt9XNQjqE7YOdrz(u"࠲࠲࠳࠴ὂ"))
	return
myZKBn3kcqflCX1EOM69jUW = {}
def l1wzdrL86Vj3mYXnsUJD9(rxJNDdc3zRYi96gsoQZwV7K=gBExoceumj4y8bFW9hY2aNMVSr):
	global wlMAxqL7iZskWPJyaXfGhYzHg1T,jCGX4F5PMkgeAwTZnW,myZKBn3kcqflCX1EOM69jUW
	if not rxJNDdc3zRYi96gsoQZwV7K:
		myZKBn3kcqflCX1EOM69jUW = XXyMBNAVJvKiq7jc20bEw6(WoFsvbmUlDZp7PzRfdGknCV,aXqWLoTdVgME(u"ࠩࡧ࡭ࡨࡺࠧ᳾"),mmV2nucZ5Lpl6FO1JMPEqGoQKW(u"ࠪࡗࡊࡉࡔࡊࡑࡑࡗࡤ࡙ࡉࡕࡇࡖࠫ᳿"),iNc3KxwErnQ(u"ࠫࡘࡋࡃࡕࡋࡒࡒࡘࡥࡓࡊࡖࡈࡗࡤࡇࡌࡍࠩᴀ"))
		if myZKBn3kcqflCX1EOM69jUW: return
	o4oUxD3u18K59ghHIY = VVpbtSKYUGXrNMwAWFo9IOjZP(UVa3fJw7k6KM(u"ࠬࡩࡥ࡯ࡶࡨࡶࠬᴁ"),qpFY4hAwolV3,qpFY4hAwolV3,GLTtERWbHnFuy4PCp,IaBhDMJc17302LgSvyxd(u"࠭อห๋ࠣฮ๊๊ฦ้ࠡำ๋ࠥอไใษษ้ฮࠦ࠮࠯ࠢึ๎ๆำีࠡษ็ฬึ์วๆฮࠣะ๊๐ูࠡ็๋ห็฿ࠠศๆไ๎ิ๐่ࠡษ็ฮ๏ࠦแ๋ࠢส่อืๆศ็ฯࠤาะ้ࠡ์ึฮำืฬࠡ็้๋ฬࠦแใูࠣห้ษโิษ่ࠤฬ๊ัว์ึ๎ฮࠦ࠮࠯ࠢฮ้ࠥ๐โ้็ࠣห้ฮั็ษ่ะࠥฮฮำ่๋ࠣีํࠠศๆฦๆุอๅࠡฯอํ๊ࠥวࠡฬะฮฬาࠠฤ่ࠣฮ๊๊ฦ่ษ้ࠣึฯࠠฤะิํࠥ࠴࠮้ࠡำ๋ࠥอไฺ็็๎ฮࠦสฮฬสะࠥ฿วะหࠣว็๊ࠠๆ่ࠣ࠷ࠥีโศศๅࠤࡡࡴ࡜࡯ࠩᴂ")+xupTj02bvy3O8R+DiJ8CMuYH1daWyjehfN0L(u"่ࠧๆࠣฮึ๐ฯࠡล้ࠤฯาๅฺࠢๅหห๋ษࠡษ็ว็ูวๆࠢส่ว์ࠠภࠩᴃ")+fF4lt9zWYxXLKZVyAco82PgMj)
	if o4oUxD3u18K59ghHIY!=mZi0S72jGoHpLO: return
	nGRXot8mU9Qa2Dd(pESAKj92MT,pESAKj92MT,pESAKj92MT)
	zgP2V3yYCJMDrmhnILtujq1aA = i4bFG3rKE6.menuItemsLIST
	wlMAxqL7iZskWPJyaXfGhYzHg1T,jCGX4F5PMkgeAwTZnW,QkKFex9lmoO2C = vvXoMLlg513,qpFY4hAwolV3,{}
	for j7HgbsXoUDfzcSkmniPu9w6 in z7mEAQFSD5datXURwNgOkIiG1:
		s7FnXZYOgexlH2MPb8BJck1AKv9.sleep(mZi0S72jGoHpLO)
		QkKFex9lmoO2C[j7HgbsXoUDfzcSkmniPu9w6] = MqWf2atLi7QDnOF0YKuZhrE53gbv1(daemon=gBExoceumj4y8bFW9hY2aNMVSr,target=sWIku5vdn6fhyDHcJLUNt1XzF,args=(j7HgbsXoUDfzcSkmniPu9w6,))
		QkKFex9lmoO2C[j7HgbsXoUDfzcSkmniPu9w6].start()
	else:
		for j7HgbsXoUDfzcSkmniPu9w6 in list(QkKFex9lmoO2C.keys()): QkKFex9lmoO2C[j7HgbsXoUDfzcSkmniPu9w6].join()
	i4bFG3rKE6.menuItemsLIST[:] = zgP2V3yYCJMDrmhnILtujq1aA
	myZKBn3kcqflCX1EOM69jUW = {}
	for j7HgbsXoUDfzcSkmniPu9w6 in list(QkKFex9lmoO2C.keys()):
		try: cbmIL6TNZfRF8GeYlH1X = i4bFG3rKE6.menuItemsDICT[j7HgbsXoUDfzcSkmniPu9w6]
		except: continue
		j7HgbsXoUDfzcSkmniPu9w6 = iNc3KxwErnQ(u"ࠨࡡࡏࡗ࡙ࡥࠧᴄ")+nqTpa5zm20MfRNsVSIuG7A3biHZ6Fw(j7HgbsXoUDfzcSkmniPu9w6)
		for lQnA93TCSoqKwIMJNz8L,mMgEh8S9xkCA5atcIP4GWOJlpDdKQ,WWowRmHkj1ZAO2SUhtNvdrcKa9E6C,ZyiMa3BXVk2xWG0b,xCei3u0k2rAVK9o7zQcdZaGXT,aazJgfh6MTFGtP8SRoCDW9UZq,HY7yaJeI89xE56sbTjdBRZPDwQKFX,fdD0wQgTuni,mDgvl5LzhR26eNVM3UaIuHtpif in cbmIL6TNZfRF8GeYlH1X:
			if not mMgEh8S9xkCA5atcIP4GWOJlpDdKQ: mMgEh8S9xkCA5atcIP4GWOJlpDdKQ = l1DZAt9XNQjqE7YOdrz(u"ࠩ࠱࠲࠳࠴ࠧᴅ")
			else:
				if mMgEh8S9xkCA5atcIP4GWOJlpDdKQ.count(CC1eY6yWZUwf2TkRvnp7EJ0AimjHBX(u"ࠪࡣࠬᴆ"))>mZi0S72jGoHpLO: mMgEh8S9xkCA5atcIP4GWOJlpDdKQ = mMgEh8S9xkCA5atcIP4GWOJlpDdKQ.split(YY8UDX3MJhb91AHw7fg(u"ࠫࡤ࠭ᴇ"),Zwqio2AIWlD5etFa)[Zwqio2AIWlD5etFa]
				mMgEh8S9xkCA5atcIP4GWOJlpDdKQ = mMgEh8S9xkCA5atcIP4GWOJlpDdKQ.replace(aXqWLoTdVgME(u"ࠬࢦࠧᴈ"),qpFY4hAwolV3).replace(rNdBKI74fAklnoCZ6(u"࠭ࠠࡉࡆࠪᴉ"),qpFY4hAwolV3).replace(YY8UDX3MJhb91AHw7fg(u"ࠧࡉࡆࠣࠫᴊ"),qpFY4hAwolV3)
				mMgEh8S9xkCA5atcIP4GWOJlpDdKQ = mMgEh8S9xkCA5atcIP4GWOJlpDdKQ.replace(fWoVd0Bmtkx(u"ࠨโࠪᴋ"),qpFY4hAwolV3).replace(UVa3fJw7k6KM(u"ࠩฬࠫᴌ"),kYDaz79TFlXoR(u"๋ࠪࠬᴍ")).replace(ddiCzu6yahj5RtTISMJ48sNnZBU(u"ࠫษ࠭ᴎ"),sjtU6GZQg5XC2pH4(u"ࠬ๎ࠧᴏ"))
				mMgEh8S9xkCA5atcIP4GWOJlpDdKQ = mMgEh8S9xkCA5atcIP4GWOJlpDdKQ.replace(ddiCzu6yahj5RtTISMJ48sNnZBU(u"࠭รࠨᴐ"),IaBhDMJc17302LgSvyxd(u"ࠧศࠩᴑ")).replace(RlOvin8YIGC2KZXJPk9m0acrMobUex(u"ࠨวࠪᴒ"),DiJ8CMuYH1daWyjehfN0L(u"ࠩสࠫᴓ")).replace(sjtU6GZQg5XC2pH4(u"ࠪฦࠬᴔ"),iNc3KxwErnQ(u"ࠫฬ࠭ᴕ"))
				mMgEh8S9xkCA5atcIP4GWOJlpDdKQ = mMgEh8S9xkCA5atcIP4GWOJlpDdKQ.replace(fWoVd0Bmtkx(u"๊ࠬรࠨᴖ"),tQMjXKCA5dN4xq3beVIzaEoWkFLg(u"࠭ไศࠩᴗ")).replace(CC1eY6yWZUwf2TkRvnp7EJ0AimjHBX(u"ࠧๅวࠪᴘ"),qqzwE6imYG4c2xojI(u"ࠨๆสࠫᴙ")).replace(BRWqdruz2A0(u"ࠩ็ฦࠬᴚ"),rNdBKI74fAklnoCZ6(u"่ࠪฬ࠭ᴛ"))
				mMgEh8S9xkCA5atcIP4GWOJlpDdKQ = mMgEh8S9xkCA5atcIP4GWOJlpDdKQ.replace(qoBMmfAWpFlK70xw8ZRh4naJ(u"ࠫ๓࠭ᴜ"),qpFY4hAwolV3).replace(DaFZHsThGmd0zv6e(u"ࠬ๑ࠧᴝ"),qpFY4hAwolV3).replace(V3VlkhgjEF4n1erPXHcC0NOsfwyAJ(u"࠭๏ࠨᴞ"),qpFY4hAwolV3).replace(LZWMikPEB81KSGyxfJtUsCA(u"ࠧํࠩᴟ"),qpFY4hAwolV3)
				mMgEh8S9xkCA5atcIP4GWOJlpDdKQ = mMgEh8S9xkCA5atcIP4GWOJlpDdKQ.replace(N3flV6EJsD5CzS(u"ࠨ๒ࠪᴠ"),qpFY4hAwolV3).replace(ddiCzu6yahj5RtTISMJ48sNnZBU(u"ࠩ๐ࠫᴡ"),qpFY4hAwolV3).replace(LZWMikPEB81KSGyxfJtUsCA(u"ࠪ๖ࠬᴢ"),qpFY4hAwolV3).replace(ee86G9ladLHVbh5mikzCo(u"ࠫ๖࠭ᴣ"),qpFY4hAwolV3)
				mMgEh8S9xkCA5atcIP4GWOJlpDdKQ = mMgEh8S9xkCA5atcIP4GWOJlpDdKQ.replace(qqzwE6imYG4c2xojI(u"ࠬࢂࠧᴤ"),qpFY4hAwolV3).replace(UUDAiytEL76RTmMYsuIz5evXB(u"࠭ࡾࠨᴥ"),qpFY4hAwolV3)
				mMgEh8S9xkCA5atcIP4GWOJlpDdKQ = mMgEh8S9xkCA5atcIP4GWOJlpDdKQ.replace(IaBhDMJc17302LgSvyxd(u"ࠧศ๊้ࠤ้อ๊็ࠩᴦ"),qpFY4hAwolV3).replace(mmV2nucZ5Lpl6FO1JMPEqGoQKW(u"ࠨีํ้ฬࠦไศ์อࠫᴧ"),qpFY4hAwolV3)
				b6pP4vGB1U8q9nTyMO2VL5m = [viRJWOC5jsYe84(u"ࠩส่฾อศࠨᴨ"),fWoVd0Bmtkx(u"ࠪา๏อไࠨᴩ"),DaFZHsThGmd0zv6e(u"ࠫฬ๊ศ้็ࠪᴪ"),iNc3KxwErnQ(u"ࠬอไศ่ࠪᴫ"),qoBMmfAWpFlK70xw8ZRh4naJ(u"࠭วุใส่ࠬᴬ"),UVa3fJw7k6KM(u"ࠧฮษ็๎์࠭ᴭ"),UUDAiytEL76RTmMYsuIz5evXB(u"ࠨษ็฾ฬุࠧᴮ"),sjtU6GZQg5XC2pH4(u"ุࠩห้ำࠧᴯ"),zYvEaigKWjoq50pXBLDbGJkFc(u"ࠪห้ี๊็ࠩᴰ"),tR1krDGPpO025fghMT3a7UnYj(u"๊ࠫ๎วๅ์าࠫᴱ"),UVa3fJw7k6KM(u"ࠬอไฺษ็้ࠬᴲ"),YY8UDX3MJhb91AHw7fg(u"࠭วฺ็ส่ࠬᴳ")]
				if not any(Y9fDWnXar1c7bdThim0AKJx8jF64L5 in mMgEh8S9xkCA5atcIP4GWOJlpDdKQ for Y9fDWnXar1c7bdThim0AKJx8jF64L5 in b6pP4vGB1U8q9nTyMO2VL5m): mMgEh8S9xkCA5atcIP4GWOJlpDdKQ = mMgEh8S9xkCA5atcIP4GWOJlpDdKQ.replace(DiJ8CMuYH1daWyjehfN0L(u"ࠧศๆࠪᴴ"),qpFY4hAwolV3)
				mMgEh8S9xkCA5atcIP4GWOJlpDdKQ = mMgEh8S9xkCA5atcIP4GWOJlpDdKQ.replace(IaBhDMJc17302LgSvyxd(u"ࠨษัี๏࠭ᴵ"),kYDaz79TFlXoR(u"ࠩสาึ๏ࠧᴶ")).replace(l32dnTEOU1skGKqeBtI9hmo(u"ࠪหั์ศ๊ࠩᴷ"),kYDaz79TFlXoR(u"ࠫฬาๆษ์ࠪᴸ")).replace(tQMjXKCA5dN4xq3beVIzaEoWkFLg(u"ࠬ฿ววๆํ๋ࠬᴹ"),l32dnTEOU1skGKqeBtI9hmo(u"ู࠭ศศ็๎ࠬᴺ"))
				mMgEh8S9xkCA5atcIP4GWOJlpDdKQ = mMgEh8S9xkCA5atcIP4GWOJlpDdKQ.replace(dJHDqiKf12TXlIzSLkGUuxg4MBs3A(u"ࠧศฮ้ฬ๏ํࠧᴻ"),N3flV6EJsD5CzS(u"ࠨษฯ๊อ๐ࠧᴼ")).replace(sjtU6GZQg5XC2pH4(u"ࠩ฼ีอ๐็ࠨᴽ"),V3VlkhgjEF4n1erPXHcC0NOsfwyAJ(u"ࠪ฽ึฮ๊ࠨᴾ")).replace(UVa3fJw7k6KM(u"ࠫึ๎ๅศ่ึ๎์࠭ᴿ"),qqzwE6imYG4c2xojI(u"ࠬื่ๆษ้ื๏࠭ᵀ"))
				mMgEh8S9xkCA5atcIP4GWOJlpDdKQ = mMgEh8S9xkCA5atcIP4GWOJlpDdKQ.replace(sjtU6GZQg5XC2pH4(u"ฺ࠭าสํ๋ࠬᵁ"),zYvEaigKWjoq50pXBLDbGJkFc(u"ࠧ฻ำห๎ࠬᵂ")).replace(viRJWOC5jsYe84(u"ࠨุ๊้๊ࠣำๅษอࠫᵃ"),l32dnTEOU1skGKqeBtI9hmo(u"่ࠩืู้ไศฬࠪᵄ")).replace(DaFZHsThGmd0zv6e(u"ࠪห฿อๆ๊ࠩᵅ"),Ie5s2cBtSfdHjzQ4rA9kYlo6D18(u"ࠫฬเว็์ࠪᵆ"))
				mMgEh8S9xkCA5atcIP4GWOJlpDdKQ = mMgEh8S9xkCA5atcIP4GWOJlpDdKQ.replace(dJHDqiKf12TXlIzSLkGUuxg4MBs3A(u"ࠬะวา์ั๎ࠬᵇ"),l1DZAt9XNQjqE7YOdrz(u"࠭สศำําࠬᵈ")).replace(fWoVd0Bmtkx(u"ࠧฯ์ส่ࠥ฿ไๆ์ࠪᵉ"),tR1krDGPpO025fghMT3a7UnYj(u"ࠨะํห้࠭ᵊ")).replace(DaFZHsThGmd0zv6e(u"่ࠩ์ุ๐โ๋้ࠪᵋ"),l32dnTEOU1skGKqeBtI9hmo(u"้ࠪํู๊ใ๋ࠪᵌ"))
				mMgEh8S9xkCA5atcIP4GWOJlpDdKQ = mMgEh8S9xkCA5atcIP4GWOJlpDdKQ.replace(l1DZAt9XNQjqE7YOdrz(u"ࠫ์์ฯ๊ࠩᵍ"),kYDaz79TFlXoR(u"ࠬํๆะ์ࠪᵎ")).replace(l32dnTEOU1skGKqeBtI9hmo(u"࠭็็ัํ๋ࠬᵏ"),aXqWLoTdVgME(u"่่ࠧา๎ࠬᵐ")).replace(DaFZHsThGmd0zv6e(u"ࠨ๊ฮหห่๊่ࠩᵑ"),iNc3KxwErnQ(u"๋ࠩฯฬฬโ๋ࠩᵒ"))
				mMgEh8S9xkCA5atcIP4GWOJlpDdKQ = mMgEh8S9xkCA5atcIP4GWOJlpDdKQ.replace(aXqWLoTdVgME(u"ࠪฮ้๐แำ์๋๊๏ํࠧᵓ"),aXqWLoTdVgME(u"ࠫฯ๊แำ์๋๊ࠬᵔ")).replace(ddiCzu6yahj5RtTISMJ48sNnZBU(u"ࠬะไโิํ์๋๐็ࠨᵕ"),iNc3KxwErnQ(u"࠭สๅใี๎ํ์ࠧᵖ")).replace(ddiCzu6yahj5RtTISMJ48sNnZBU(u"้ࠧࠢๆีฯ๎ๆࠨᵗ"),DaFZHsThGmd0zv6e(u"ࠨ๊ๆีฯ๎ๆࠨᵘ"))
				mMgEh8S9xkCA5atcIP4GWOJlpDdKQ = mMgEh8S9xkCA5atcIP4GWOJlpDdKQ.replace(qqzwE6imYG4c2xojI(u"ࠩส่าอไ๋้ࠪᵙ"),iNc3KxwErnQ(u"ࠪัฬ๊๊่ࠩᵚ")).replace(IaBhDMJc17302LgSvyxd(u"๊ࠫ๎ำໍไํࠫᵛ"),RlOvin8YIGC2KZXJPk9m0acrMobUex(u"๋่ࠬิ์ๅํࠬᵜ")).replace(dJHDqiKf12TXlIzSLkGUuxg4MBs3A(u"࠭วๅษ้้๏࠭ᵝ"),Ie5s2cBtSfdHjzQ4rA9kYlo6D18(u"ࠧศ่่๎ࠬᵞ"))
				mMgEh8S9xkCA5atcIP4GWOJlpDdKQ = mMgEh8S9xkCA5atcIP4GWOJlpDdKQ.replace(mmV2nucZ5Lpl6FO1JMPEqGoQKW(u"ࠨษ็ุ้๊ำๅษอࠫᵟ"),rNdBKI74fAklnoCZ6(u"่ࠩืู้ไศฬࠪᵠ")).replace(qoBMmfAWpFlK70xw8ZRh4naJ(u"ࠪห้ฮัศ็ฯࠫᵡ"),RlOvin8YIGC2KZXJPk9m0acrMobUex(u"ࠫอืวๆฮࠪᵢ")).replace(mmV2nucZ5Lpl6FO1JMPEqGoQKW(u"้ࠬวาฬ๋๊ࠬᵣ"),UVa3fJw7k6KM(u"࠭ใาฬ๋๊ࠬᵤ"))
				mMgEh8S9xkCA5atcIP4GWOJlpDdKQ = mMgEh8S9xkCA5atcIP4GWOJlpDdKQ.replace(N3flV6EJsD5CzS(u"ࠧฮำ๋ฬࠬᵥ"),zYvEaigKWjoq50pXBLDbGJkFc(u"ࠨฯิฬࠬᵦ")).replace(aXqWLoTdVgME(u"ࠩส่ฬ์วี์าࠫᵧ"),ee86G9ladLHVbh5mikzCo(u"ࠪห๋อิ๋ัࠪᵨ")).replace(BRWqdruz2A0(u"ࠫฬู๊้์๊ࠫᵩ"),zYvEaigKWjoq50pXBLDbGJkFc(u"ࠬอำ๋๊ํࠫᵪ"))
				mMgEh8S9xkCA5atcIP4GWOJlpDdKQ = mMgEh8S9xkCA5atcIP4GWOJlpDdKQ.replace(lljaEqwTVtmKsQcOrbXxS5hgNH(u"ู࠭าส์ࠫᵫ"),YY8UDX3MJhb91AHw7fg(u"ฺࠧำห๎ࠬᵬ")).replace(iNc3KxwErnQ(u"ࠨฬิ็๎࠭ᵭ"),CC1eY6yWZUwf2TkRvnp7EJ0AimjHBX(u"ࠩอี่๐ࠧᵮ")).replace(CC1eY6yWZUwf2TkRvnp7EJ0AimjHBX(u"ࠪฮึ้๊่ࠩᵯ"),tR1krDGPpO025fghMT3a7UnYj(u"ࠫฯืใ๋ࠩᵰ")).replace(UUDAiytEL76RTmMYsuIz5evXB(u"ࠬอไๆุสๅࠬᵱ"),Ie5s2cBtSfdHjzQ4rA9kYlo6D18(u"࠭ๅืษไࠫᵲ"))
				mMgEh8S9xkCA5atcIP4GWOJlpDdKQ = mMgEh8S9xkCA5atcIP4GWOJlpDdKQ.replace(N3flV6EJsD5CzS(u"ࠧา์สฺ๏࠭ᵳ"),UVa3fJw7k6KM(u"ࠨำํห฻ฯࠧᵴ")).replace(Ie5s2cBtSfdHjzQ4rA9kYlo6D18(u"ࠩิ๎ฬ฼็ࠨᵵ"),LZWMikPEB81KSGyxfJtUsCA(u"ࠪี๏อึสࠩᵶ")).replace(N3flV6EJsD5CzS(u"ࠫฬู๊้์๊ࠫᵷ"),qqzwE6imYG4c2xojI(u"ࠬอำ๋๊ํࠫᵸ"))
				mMgEh8S9xkCA5atcIP4GWOJlpDdKQ = mMgEh8S9xkCA5atcIP4GWOJlpDdKQ.replace(dJHDqiKf12TXlIzSLkGUuxg4MBs3A(u"࠭ใ้็ํำ๎࠭ᵹ"),zYvEaigKWjoq50pXBLDbGJkFc(u"ࠧไ๊่๎ิ๐ࠧᵺ")).replace(tQMjXKCA5dN4xq3beVIzaEoWkFLg(u"ࠨๅ๋้๏ี๊่ࠩᵻ"),qqzwE6imYG4c2xojI(u"ࠩๆ์๊๐ฯ๋ࠩᵼ")).replace(DaFZHsThGmd0zv6e(u"ࠪห๋๐ๅ๋ࠩᵽ"),N3flV6EJsD5CzS(u"ࠫฬ์ๅ๋ࠩᵾ"))
				mMgEh8S9xkCA5atcIP4GWOJlpDdKQ = mMgEh8S9xkCA5atcIP4GWOJlpDdKQ.replace(qqzwE6imYG4c2xojI(u"ࠬอๆ๋็ํุ๋࠭ᵿ"),zYvEaigKWjoq50pXBLDbGJkFc(u"࠭ว็็ํุ๋࠭ᶀ")).replace(lljaEqwTVtmKsQcOrbXxS5hgNH(u"ࠧศ่่ํࠬᶁ"),iNc3KxwErnQ(u"ࠨษ้้๏ฺๆࠨᶂ")).replace(zYvEaigKWjoq50pXBLDbGJkFc(u"ࠩส๊๊๐ࠧᶃ"),UVa3fJw7k6KM(u"ࠪห๋๋๊ี่ࠪᶄ"))
				mMgEh8S9xkCA5atcIP4GWOJlpDdKQ = mMgEh8S9xkCA5atcIP4GWOJlpDdKQ.replace(tQMjXKCA5dN4xq3beVIzaEoWkFLg(u"ࠫฬ์ๅ๋ึุ้๋࠭ᶅ"),ddiCzu6yahj5RtTISMJ48sNnZBU(u"ࠬอๆๆ์ื๊ࠬᶆ")).replace(CC1eY6yWZUwf2TkRvnp7EJ0AimjHBX(u"࠭วๅษ้้๏ฺๆࠨᶇ"),aXqWLoTdVgME(u"ࠧศ่่๎ู์ࠧᶈ")).replace(CC1eY6yWZUwf2TkRvnp7EJ0AimjHBX(u"ࠨษไ่ฬ๋ࠠๆี็ื้อสࠨᶉ"),Ie5s2cBtSfdHjzQ4rA9kYlo6D18(u"ࠩสๅ้อๅ๊่ࠡืู้ไศฬࠪᶊ"))
				mMgEh8S9xkCA5atcIP4GWOJlpDdKQ = mMgEh8S9xkCA5atcIP4GWOJlpDdKQ.replace(r1roOXYi7UQw9FLThzPEdD0ZlvAnRc,mIsDke0oK5x1zSiOWbF9thGcA).strip(CC1eY6yWZUwf2TkRvnp7EJ0AimjHBX(u"ࠪ࠱ࠬᶋ")).strip(mIsDke0oK5x1zSiOWbF9thGcA)
			if mMgEh8S9xkCA5atcIP4GWOJlpDdKQ not in list(myZKBn3kcqflCX1EOM69jUW.keys()): myZKBn3kcqflCX1EOM69jUW[mMgEh8S9xkCA5atcIP4GWOJlpDdKQ] = {}
			myZKBn3kcqflCX1EOM69jUW[mMgEh8S9xkCA5atcIP4GWOJlpDdKQ][j7HgbsXoUDfzcSkmniPu9w6] = [lQnA93TCSoqKwIMJNz8L,mMgEh8S9xkCA5atcIP4GWOJlpDdKQ,WWowRmHkj1ZAO2SUhtNvdrcKa9E6C,ZyiMa3BXVk2xWG0b,xCei3u0k2rAVK9o7zQcdZaGXT,aazJgfh6MTFGtP8SRoCDW9UZq,HY7yaJeI89xE56sbTjdBRZPDwQKFX,fdD0wQgTuni,mDgvl5LzhR26eNVM3UaIuHtpif]
	zOYMaQ0NgdiRVwDJXh8e(WoFsvbmUlDZp7PzRfdGknCV,zYvEaigKWjoq50pXBLDbGJkFc(u"ࠫࡘࡋࡃࡕࡋࡒࡒࡘࡥࡓࡊࡖࡈࡗࠬᶌ"),ddiCzu6yahj5RtTISMJ48sNnZBU(u"࡙ࠬࡅࡄࡖࡌࡓࡓ࡙࡟ࡔࡋࡗࡉࡘࡥࡁࡍࡎࠪᶍ"),myZKBn3kcqflCX1EOM69jUW,ivLg9zRnGF83u)
	if wlMAxqL7iZskWPJyaXfGhYzHg1T>=XSHMu4ZvifchKFP0LWBNr: iG7Rz2kmn0x1yLNMV3u8O(qpFY4hAwolV3,qpFY4hAwolV3,GLTtERWbHnFuy4PCp,zYvEaigKWjoq50pXBLDbGJkFc(u"࠭ไะ์ๆࠤฺ๊ใๅหࠣๅ๏ࠦࠧᶎ")+str(wlMAxqL7iZskWPJyaXfGhYzHg1T)+V3VlkhgjEF4n1erPXHcC0NOsfwyAJ(u"ࠧࠡ็๋ๆ฾ࠦๅ็่ࠢ์ฬู่ࠡษ็ฬึ์วๆฮࠣ࠲࠳࠴้้ࠠๆิฬࠦๅีๅ็อูࠥศษ้สࠤ฾อฯส่๊ࠢࠥอไฦ่อี๋๐สࠡ฻้ำ่่ࠦศๆ่์ฬู่้ࠡํ࠾ࠬᶏ")+jCGX4F5PMkgeAwTZnW)
	iG7Rz2kmn0x1yLNMV3u8O(qpFY4hAwolV3,qpFY4hAwolV3,GLTtERWbHnFuy4PCp,DaFZHsThGmd0zv6e(u"ࠨฬ่ࠤั๊ศࠡฮ่๎฾ࠦวๅลๅืฬ๋ࠠศๆ่ฮํ็ัสࠢไ๎ࠥอไษำ้ห๊าࠧᶐ"))
	nGRXot8mU9Qa2Dd(dND7uS6bknRj82EOIX0iyUxAscl,dND7uS6bknRj82EOIX0iyUxAscl,dND7uS6bknRj82EOIX0iyUxAscl)
	xtm9pSeMInWo60()
	return
def bSynDjcN6L815tfkIOH9eJ4sxXqor(LLcgQ6E12OZezYbh4CVdIa,ZZCk6FGHRa8):
	FAHCtdm48uIsx = ag8rjZo1Vz4IPdcOT
	CG2OMgKsb50WzVEkQtZarvcm1 = i4bFG3rKE6.menuItemsLIST
	i4bFG3rKE6.menuItemsLIST[:] = []
	if FAHCtdm48uIsx and IaBhDMJc17302LgSvyxd(u"ࠩࡢࡇࡗࡋࡁࡕࡇࡑࡉ࡜ࡥࠧᶑ") not in ZZCk6FGHRa8:
		MOTjA5H9XFs = XXyMBNAVJvKiq7jc20bEw6(WoFsvbmUlDZp7PzRfdGknCV,UUDAiytEL76RTmMYsuIz5evXB(u"ࠪࡰ࡮ࡹࡴࠨᶒ"),BRWqdruz2A0(u"ࠫࡘࡋࡃࡕࡋࡒࡒࡘࡥࡉࡑࡖ࡙ࠫᶓ"),ee86G9ladLHVbh5mikzCo(u"࡙ࠬࡅࡄࡖࡌࡓࡓ࡙࡟ࡊࡒࡗ࡚ࡤ࠭ᶔ")+LLcgQ6E12OZezYbh4CVdIa)
	elif mmV2nucZ5Lpl6FO1JMPEqGoQKW(u"࠭࡟ࡍࡋ࡙ࡉࡤ࠭ᶕ") not in ZZCk6FGHRa8 or fWoVd0Bmtkx(u"ࠧࡠࡘࡒࡈࡤ࠭ᶖ") not in ZZCk6FGHRa8:
		import kuHhyElsXe
		w0CZ6B3WDJknhEsdRYyH1XAM = tR1krDGPpO025fghMT3a7UnYj(u"ࠨๆ็วุ็ࠠๅัํ็๋ࠥิไๆฬࠤๆ๐่ࠠาสࠤฬ๊ๅ้ไ฼ࠤ࠳่ࠦาีส่ฮࠦวๅะฺว้ࠥว็ࠢไ๎์อࠠหใสู๏๊ࠠศๆุ่่๊ษࠡ࠰ࠣวีอࠠศๆุ่่๊ษࠡๆํืฯࠦออสࠣๅัืศࠡวิืฬ๊่ࠠา๊ࠤฬ๊ๅีๅ็อࠥหไ๊ࠢส่๊ฮัๆฮ้๋ࠣࠦโศศ่อࠥืำศศ็ࠤฬ๊ศา่ส้ั࠭ᶗ")
		if DaFZHsThGmd0zv6e(u"ࠩࡢࡐࡎ࡜ࡅࡠࠩᶘ") not in ZZCk6FGHRa8:
			try: kuHhyElsXe.xxHg8EI03NwfKGpYtjrs7WDinR(LLcgQ6E12OZezYbh4CVdIa,zYvEaigKWjoq50pXBLDbGJkFc(u"࡚ࠪࡔࡊ࡟ࡖࡐࡎࡒࡔ࡝ࡎࡠࡉࡕࡓ࡚ࡖࡅࡅࡡࡖࡓࡗ࡚ࡅࡅࠩᶙ"),qpFY4hAwolV3,qpFY4hAwolV3,ZZCk6FGHRa8+CC1eY6yWZUwf2TkRvnp7EJ0AimjHBX(u"ࠫࡤࡌࡏࡓࡉࡈࡘࡗࡋࡓࡖࡎࡗࡗࡤࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩᶚ"),ag8rjZo1Vz4IPdcOT)
			except: iG7Rz2kmn0x1yLNMV3u8O(qpFY4hAwolV3,qpFY4hAwolV3,BRWqdruz2A0(u"๋่ࠬใ฻ࠣไࡎࡖࡔࡗࠢ็่ๆ๐ฯ๋๊๊หฯ࠭ᶛ"),w0CZ6B3WDJknhEsdRYyH1XAM)
			try: kuHhyElsXe.xxHg8EI03NwfKGpYtjrs7WDinR(LLcgQ6E12OZezYbh4CVdIa,LZWMikPEB81KSGyxfJtUsCA(u"࠭ࡖࡐࡆࡢࡑࡔ࡜ࡉࡆࡕࡢࡋࡗࡕࡕࡑࡇࡇࡣࡘࡕࡒࡕࡇࡇࠫᶜ"),qpFY4hAwolV3,qpFY4hAwolV3,ZZCk6FGHRa8+Ie5s2cBtSfdHjzQ4rA9kYlo6D18(u"ࠧࡠࡈࡒࡖࡌࡋࡔࡓࡇࡖ࡙ࡑ࡚ࡓࡠࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬᶝ"),ag8rjZo1Vz4IPdcOT)
			except: iG7Rz2kmn0x1yLNMV3u8O(qpFY4hAwolV3,qpFY4hAwolV3,CC1eY6yWZUwf2TkRvnp7EJ0AimjHBX(u"ࠨ็๋ๆ฾ࠦเࡊࡒࡗ๊࡚ࠥไโ์า๎ํํวหࠩᶞ"),w0CZ6B3WDJknhEsdRYyH1XAM)
			try: kuHhyElsXe.xxHg8EI03NwfKGpYtjrs7WDinR(LLcgQ6E12OZezYbh4CVdIa,qqzwE6imYG4c2xojI(u"࡙ࠩࡓࡉࡥࡓࡆࡔࡌࡉࡘࡥࡇࡓࡑࡘࡔࡊࡊ࡟ࡔࡑࡕࡘࡊࡊࠧᶟ"),qpFY4hAwolV3,qpFY4hAwolV3,ZZCk6FGHRa8+rNdBKI74fAklnoCZ6(u"ࠪࡣࡋࡕࡒࡈࡇࡗࡖࡊ࡙ࡕࡍࡖࡖࡣࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨᶠ"),ag8rjZo1Vz4IPdcOT)
			except: iG7Rz2kmn0x1yLNMV3u8O(qpFY4hAwolV3,qpFY4hAwolV3,BRWqdruz2A0(u"๊ࠫ๎โฺࠢใࡍࡕ࡚ࡖࠡๆ็ๅ๏ี๊้้สฮࠬᶡ"),w0CZ6B3WDJknhEsdRYyH1XAM)
		if qoBMmfAWpFlK70xw8ZRh4naJ(u"ࠬࡥࡖࡐࡆࡢࠫᶢ") not in ZZCk6FGHRa8:
			try: kuHhyElsXe.xxHg8EI03NwfKGpYtjrs7WDinR(LLcgQ6E12OZezYbh4CVdIa,qqzwE6imYG4c2xojI(u"࠭ࡌࡊࡘࡈࡣ࡚ࡔࡋࡏࡑ࡚ࡒࡤࡍࡒࡐࡗࡓࡉࡉࡥࡓࡐࡔࡗࡉࡉ࠭ᶣ"),qpFY4hAwolV3,qpFY4hAwolV3,ZZCk6FGHRa8+sjtU6GZQg5XC2pH4(u"ࠧࡠࡈࡒࡖࡌࡋࡔࡓࡇࡖ࡙ࡑ࡚ࡓࡠࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬᶤ"),ag8rjZo1Vz4IPdcOT)
			except: iG7Rz2kmn0x1yLNMV3u8O(qpFY4hAwolV3,qpFY4hAwolV3,iNc3KxwErnQ(u"ࠨ็๋ๆ฾ࠦเࡊࡒࡗ๊࡚ࠥไใ่๋หฯ࠭ᶥ"),w0CZ6B3WDJknhEsdRYyH1XAM)
			try: kuHhyElsXe.xxHg8EI03NwfKGpYtjrs7WDinR(LLcgQ6E12OZezYbh4CVdIa,BRWqdruz2A0(u"ࠩࡏࡍ࡛ࡋ࡟ࡈࡔࡒ࡙ࡕࡋࡄࡠࡕࡒࡖ࡙ࡋࡄࠨᶦ"),qpFY4hAwolV3,qpFY4hAwolV3,ZZCk6FGHRa8+UUDAiytEL76RTmMYsuIz5evXB(u"ࠪࡣࡋࡕࡒࡈࡇࡗࡖࡊ࡙ࡕࡍࡖࡖࡣࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨᶧ"),ag8rjZo1Vz4IPdcOT)
			except: iG7Rz2kmn0x1yLNMV3u8O(qpFY4hAwolV3,qpFY4hAwolV3,YY8UDX3MJhb91AHw7fg(u"๊ࠫ๎โฺࠢใࡍࡕ࡚ࡖࠡๆ็ๆ๋๎วหࠩᶨ"),w0CZ6B3WDJknhEsdRYyH1XAM)
		MOTjA5H9XFs = i4bFG3rKE6.menuItemsLIST
		if FAHCtdm48uIsx: zOYMaQ0NgdiRVwDJXh8e(WoFsvbmUlDZp7PzRfdGknCV,lljaEqwTVtmKsQcOrbXxS5hgNH(u"࡙ࠬࡅࡄࡖࡌࡓࡓ࡙࡟ࡊࡒࡗ࡚ࠬᶩ"),UVa3fJw7k6KM(u"࠭ࡓࡆࡅࡗࡍࡔࡔࡓࡠࡋࡓࡘ࡛ࡥࠧᶪ")+LLcgQ6E12OZezYbh4CVdIa,MOTjA5H9XFs,ivLg9zRnGF83u)
	i4bFG3rKE6.menuItemsLIST[:] = CG2OMgKsb50WzVEkQtZarvcm1
	return MOTjA5H9XFs
def lpi3gjNW6T0zR8MPuc(LLcgQ6E12OZezYbh4CVdIa,ZZCk6FGHRa8):
	FAHCtdm48uIsx = ag8rjZo1Vz4IPdcOT
	CG2OMgKsb50WzVEkQtZarvcm1 = i4bFG3rKE6.menuItemsLIST
	i4bFG3rKE6.menuItemsLIST[:] = []
	if FAHCtdm48uIsx and rNdBKI74fAklnoCZ6(u"ࠧࡠࡅࡕࡉࡆ࡚ࡅࡏࡇ࡚ࡣࠬᶫ") not in ZZCk6FGHRa8:
		MOTjA5H9XFs = XXyMBNAVJvKiq7jc20bEw6(WoFsvbmUlDZp7PzRfdGknCV,l1DZAt9XNQjqE7YOdrz(u"ࠨ࡮࡬ࡷࡹ࠭ᶬ"),iNc3KxwErnQ(u"ࠩࡖࡉࡈ࡚ࡉࡐࡐࡖࡣࡒ࠹ࡕࠨᶭ"),DiJ8CMuYH1daWyjehfN0L(u"ࠪࡗࡊࡉࡔࡊࡑࡑࡗࡤࡓ࠳ࡖࡡࠪᶮ")+LLcgQ6E12OZezYbh4CVdIa)
	elif iNc3KxwErnQ(u"ࠫࡤࡒࡉࡗࡇࡢࠫᶯ") not in ZZCk6FGHRa8 or UVa3fJw7k6KM(u"ࠬࡥࡖࡐࡆࡢࠫᶰ") not in ZZCk6FGHRa8:
		import jV4SY0Trl2
		w0CZ6B3WDJknhEsdRYyH1XAM = fWoVd0Bmtkx(u"࠭ไๅลึๅ๊ࠥฯ๋ๅู้้ࠣไสࠢไ๎ࠥํะศࠢส่๊๎โฺࠢ࠱ࠤํืำศๆฬࠤฬ๊ฮุลࠣ็ฬ์ࠠโ์๊หࠥะแศืํ่ࠥอไๆึๆ่ฮࠦ࠮ࠡลำหࠥอไๆึๆ่ฮࠦไ๋ีอࠤาาศࠡใฯีอࠦลาีส่ࠥํะ่ࠢสฺ่๊ใๅหࠣษ้๏ࠠศๆ่ฬึ๋ฬࠡ็้ࠤ็อฦๆหࠣีุอฦๅࠢส่อืๆศ็ฯࠫᶱ")
		if RlOvin8YIGC2KZXJPk9m0acrMobUex(u"ࠧࡠࡎࡌ࡚ࡊࡥࠧᶲ") not in ZZCk6FGHRa8:
			try: jV4SY0Trl2.xxHg8EI03NwfKGpYtjrs7WDinR(LLcgQ6E12OZezYbh4CVdIa,lljaEqwTVtmKsQcOrbXxS5hgNH(u"ࠨࡘࡒࡈࡤ࡛ࡎࡌࡐࡒ࡛ࡓࡥࡇࡓࡑࡘࡔࡊࡊ࡟ࡔࡑࡕࡘࡊࡊࠧᶳ"),qpFY4hAwolV3,qpFY4hAwolV3,ZZCk6FGHRa8+YY8UDX3MJhb91AHw7fg(u"ࠩࡢࡊࡔࡘࡇࡆࡖࡕࡉࡘ࡛ࡌࡕࡕࡢࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧᶴ"),ag8rjZo1Vz4IPdcOT)
			except: iG7Rz2kmn0x1yLNMV3u8O(qpFY4hAwolV3,qpFY4hAwolV3,kYDaz79TFlXoR(u"้ࠪํู่ࠡโࡐ࠷࡚ࠦไๅใํำ๏๎็ศฬࠪᶵ"),w0CZ6B3WDJknhEsdRYyH1XAM)
			try: jV4SY0Trl2.xxHg8EI03NwfKGpYtjrs7WDinR(LLcgQ6E12OZezYbh4CVdIa,l1DZAt9XNQjqE7YOdrz(u"࡛ࠫࡕࡄࡠࡏࡒ࡚ࡎࡋࡓࡠࡉࡕࡓ࡚ࡖࡅࡅࡡࡖࡓࡗ࡚ࡅࡅࠩᶶ"),qpFY4hAwolV3,qpFY4hAwolV3,ZZCk6FGHRa8+DaFZHsThGmd0zv6e(u"ࠬࡥࡆࡐࡔࡊࡉ࡙ࡘࡅࡔࡗࡏࡘࡘࡥ࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪᶷ"),ag8rjZo1Vz4IPdcOT)
			except: iG7Rz2kmn0x1yLNMV3u8O(qpFY4hAwolV3,qpFY4hAwolV3,iNc3KxwErnQ(u"࠭ๅ้ไ฼ࠤๅࡓ࠳ࡖࠢ็่ๆ๐ฯ๋๊๊หฯ࠭ᶸ"),w0CZ6B3WDJknhEsdRYyH1XAM)
			try: jV4SY0Trl2.xxHg8EI03NwfKGpYtjrs7WDinR(LLcgQ6E12OZezYbh4CVdIa,viRJWOC5jsYe84(u"ࠧࡗࡑࡇࡣࡘࡋࡒࡊࡇࡖࡣࡌࡘࡏࡖࡒࡈࡈࡤ࡙ࡏࡓࡖࡈࡈࠬᶹ"),qpFY4hAwolV3,qpFY4hAwolV3,ZZCk6FGHRa8+rNdBKI74fAklnoCZ6(u"ࠨࡡࡉࡓࡗࡍࡅࡕࡔࡈࡗ࡚ࡒࡔࡔࡡࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭ᶺ"),ag8rjZo1Vz4IPdcOT)
			except: iG7Rz2kmn0x1yLNMV3u8O(qpFY4hAwolV3,qpFY4hAwolV3,sjtU6GZQg5XC2pH4(u"่ࠩ์็฿ࠠแࡏ࠶๊࡙ࠥไโ์า๎ํํวหࠩᶻ"),w0CZ6B3WDJknhEsdRYyH1XAM)
		if aXqWLoTdVgME(u"ࠪࡣ࡛ࡕࡄࡠࠩᶼ") not in ZZCk6FGHRa8:
			try: jV4SY0Trl2.xxHg8EI03NwfKGpYtjrs7WDinR(LLcgQ6E12OZezYbh4CVdIa,DaFZHsThGmd0zv6e(u"ࠫࡑࡏࡖࡆࡡࡘࡒࡐࡔࡏࡘࡐࡢࡋࡗࡕࡕࡑࡇࡇࡣࡘࡕࡒࡕࡇࡇࠫᶽ"),qpFY4hAwolV3,qpFY4hAwolV3,ZZCk6FGHRa8+l1DZAt9XNQjqE7YOdrz(u"ࠬࡥࡆࡐࡔࡊࡉ࡙ࡘࡅࡔࡗࡏࡘࡘࡥ࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪᶾ"),ag8rjZo1Vz4IPdcOT)
			except: iG7Rz2kmn0x1yLNMV3u8O(qpFY4hAwolV3,qpFY4hAwolV3,BRWqdruz2A0(u"࠭ๅ้ไ฼ࠤๅࡓ࠳ࡖࠢ็่็์่ศฬࠪᶿ"),w0CZ6B3WDJknhEsdRYyH1XAM)
			try: jV4SY0Trl2.xxHg8EI03NwfKGpYtjrs7WDinR(LLcgQ6E12OZezYbh4CVdIa,CC1eY6yWZUwf2TkRvnp7EJ0AimjHBX(u"ࠧࡍࡋ࡙ࡉࡤࡍࡒࡐࡗࡓࡉࡉࡥࡓࡐࡔࡗࡉࡉ࠭᷀"),qpFY4hAwolV3,qpFY4hAwolV3,ZZCk6FGHRa8+V3VlkhgjEF4n1erPXHcC0NOsfwyAJ(u"ࠨࡡࡉࡓࡗࡍࡅࡕࡔࡈࡗ࡚ࡒࡔࡔࡡࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭᷁"),ag8rjZo1Vz4IPdcOT)
			except: iG7Rz2kmn0x1yLNMV3u8O(qpFY4hAwolV3,qpFY4hAwolV3,ddiCzu6yahj5RtTISMJ48sNnZBU(u"่ࠩ์็฿ࠠแࡏ࠶๊࡙ࠥไใ่๋หฯ᷂࠭"),w0CZ6B3WDJknhEsdRYyH1XAM)
		MOTjA5H9XFs = i4bFG3rKE6.menuItemsLIST
		if FAHCtdm48uIsx: zOYMaQ0NgdiRVwDJXh8e(WoFsvbmUlDZp7PzRfdGknCV,l1DZAt9XNQjqE7YOdrz(u"ࠪࡗࡊࡉࡔࡊࡑࡑࡗࡤࡓ࠳ࡖࠩ᷃"),V3VlkhgjEF4n1erPXHcC0NOsfwyAJ(u"ࠫࡘࡋࡃࡕࡋࡒࡒࡘࡥࡍ࠴ࡗࡢࠫ᷄")+LLcgQ6E12OZezYbh4CVdIa,MOTjA5H9XFs,ivLg9zRnGF83u)
	i4bFG3rKE6.menuItemsLIST[:] = CG2OMgKsb50WzVEkQtZarvcm1
	return MOTjA5H9XFs
def gZPkjUz7NBJDtSvmMYof(LLcgQ6E12OZezYbh4CVdIa,ZZCk6FGHRa8,tq5rxw1jPpSgFeYflzX9CO0aR6H):
	nGRXot8mU9Qa2Dd(z5wEtWrCxRZiQ,z5wEtWrCxRZiQ,pESAKj92MT)
	if tq5rxw1jPpSgFeYflzX9CO0aR6H: l1wzdrL86Vj3mYXnsUJD9(ag8rjZo1Vz4IPdcOT)
	elif zYvEaigKWjoq50pXBLDbGJkFc(u"ࠬࡥࡃࡓࡇࡄࡘࡊࡔࡅࡘࡡࠪ᷅") in ZZCk6FGHRa8 and not tq5rxw1jPpSgFeYflzX9CO0aR6H: l1wzdrL86Vj3mYXnsUJD9(gBExoceumj4y8bFW9hY2aNMVSr)
	oJEqm9eVfsYdkcQ = ZZCk6FGHRa8.replace(mmV2nucZ5Lpl6FO1JMPEqGoQKW(u"࠭࡟ࡄࡔࡈࡅ࡙ࡋࡎࡆ࡙ࡢࠫ᷆"),qpFY4hAwolV3).replace(zYvEaigKWjoq50pXBLDbGJkFc(u"ࠧࡠࡈࡒࡖࡌࡋࡔࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ᷇"),qpFY4hAwolV3).replace(UVa3fJw7k6KM(u"ࠨࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ᷈"),qpFY4hAwolV3)
	if not tq5rxw1jPpSgFeYflzX9CO0aR6H:
		x3WSXnKyPhjqfHG2UrtQs(sjtU6GZQg5XC2pH4(u"ࠩ࡯࡭ࡳࡱࠧ᷉"),DiJ8CMuYH1daWyjehfN0L(u"ࠪฮาี๊ฬࠢๅหห๋ษࠡษ็ว็ูวๆ᷊ࠩ"),qpFY4hAwolV3,qqzwE6imYG4c2xojI(u"࠹࠹࠷ὃ"),qpFY4hAwolV3,qpFY4hAwolV3,iNc3KxwErnQ(u"ࠫࡤࡉࡒࡆࡃࡗࡉࡓࡋࡗࡠࠩ᷋")+oJEqm9eVfsYdkcQ,qpFY4hAwolV3,{ddiCzu6yahj5RtTISMJ48sNnZBU(u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ᷌"):LLcgQ6E12OZezYbh4CVdIa})
		x3WSXnKyPhjqfHG2UrtQs(aXqWLoTdVgME(u"࠭࡬ࡪࡰ࡮ࠫ᷍"),xupTj02bvy3O8R+l1DZAt9XNQjqE7YOdrz(u"ࠧ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤ᷎ࠬ")+fF4lt9zWYxXLKZVyAco82PgMj,qpFY4hAwolV3,zYvEaigKWjoq50pXBLDbGJkFc(u"࠼࠽࠾࠿ὄ"))
		VVn8DUgwNTFzEchAd6fi3 = [UVa3fJw7k6KM(u"ࠨลไ่ฬ๋᷏ࠧ"),aXqWLoTdVgME(u"่ࠩืู้ไศฬ᷐ࠪ"),N3flV6EJsD5CzS(u"ุ้ࠪือ๋ษอࠫ᷑"),DaFZHsThGmd0zv6e(u"ࠫอืวๆฮࠪ᷒"),UUDAiytEL76RTmMYsuIz5evXB(u"ࠬษืโษ็ࠤํ้ัห๊้ࠫᷓ"),Ie5s2cBtSfdHjzQ4rA9kYlo6D18(u"࠭ัๆุส๊ࠬᷔ"),DaFZHsThGmd0zv6e(u"ࠧฤฯาฯ࠲ษฮาࠩᷕ"),CC1eY6yWZUwf2TkRvnp7EJ0AimjHBX(u"ࠨี็หุ๊ࠧᷖ"),RlOvin8YIGC2KZXJPk9m0acrMobUex(u"่ࠩ์ุ๐โ๊ࠩᷗ"),UVa3fJw7k6KM(u"ࠪวูํั࠮ลๆฯึ࠭ᷘ"),IaBhDMJc17302LgSvyxd(u"ࠫฬ๊ย็ࠩᷙ"),DaFZHsThGmd0zv6e(u"ࠬ฼อไࠩᷚ"),aXqWLoTdVgME(u"࠭ั๋ษูอࠬᷛ"),CC1eY6yWZUwf2TkRvnp7EJ0AimjHBX(u"ࠧ็์อๅ้้ำࠨᷜ"),qoBMmfAWpFlK70xw8ZRh4naJ(u"ࠨ็่ฯ้๐ๆࠨᷝ"),V3VlkhgjEF4n1erPXHcC0NOsfwyAJ(u"ࠩหฯࠥำ๊ࠨᷞ"),CC1eY6yWZUwf2TkRvnp7EJ0AimjHBX(u"ࠪำ๏์๊สࠩᷟ"),zYvEaigKWjoq50pXBLDbGJkFc(u"ุࠫ์่ศฬࠪᷠ"),UUDAiytEL76RTmMYsuIz5evXB(u"ࠬษฮา๋ࠪᷡ")]
		tq5rxw1jPpSgFeYflzX9CO0aR6H = vvXoMLlg513
		for RZPKlU5B0cj in VVn8DUgwNTFzEchAd6fi3:
			tq5rxw1jPpSgFeYflzX9CO0aR6H += mZi0S72jGoHpLO
			x3WSXnKyPhjqfHG2UrtQs(lljaEqwTVtmKsQcOrbXxS5hgNH(u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ᷢ"),wwSFijdVJn1QgHW+RZPKlU5B0cj,qpFY4hAwolV3,viRJWOC5jsYe84(u"࠻࠻࠹ὅ"),qpFY4hAwolV3,str(tq5rxw1jPpSgFeYflzX9CO0aR6H),oJEqm9eVfsYdkcQ,qpFY4hAwolV3,{V3VlkhgjEF4n1erPXHcC0NOsfwyAJ(u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᷣ"):LLcgQ6E12OZezYbh4CVdIa})
	else:
		mmTqzVCksDBKGrZYMlwNcRxUWHLJ = [aXqWLoTdVgME(u"ࠨษไ่ฬ๋ࠧᷤ"),sjtU6GZQg5XC2pH4(u"ࠩࡰࡳࡻ࡯ࡥࠨᷥ"),c2RKu0xG1eC8MiohyE(u"ࠪๅ๏๊ๅࠨᷦ"),fWoVd0Bmtkx(u"ࠫๆ๊ๅࠨᷧ")]
		A8s6orYkjplw = [qoBMmfAWpFlK70xw8ZRh4naJ(u"๋ࠬำๅี็ࠫᷨ"),CC1eY6yWZUwf2TkRvnp7EJ0AimjHBX(u"࠭ࡳࡦࡴ࡬ࡩࡸ࠭ᷩ")]
		smwnp0QEGkjd6v = [LZWMikPEB81KSGyxfJtUsCA(u"ࠧๆีสีา࠭ᷪ"),DiJ8CMuYH1daWyjehfN0L(u"ࠨ็ึีา๐วหࠩᷫ")]
		TtF53EqRDWkbw90QCV = [ee86G9ladLHVbh5mikzCo(u"ࠩหีฬ๋ฬࠨᷬ"),aXqWLoTdVgME(u"ࠪࡷ࡭ࡵࡷࠨᷭ"),RlOvin8YIGC2KZXJPk9m0acrMobUex(u"ࠫฯ๊แำ์๋๊ࠬᷮ"),V3VlkhgjEF4n1erPXHcC0NOsfwyAJ(u"ࠬะไ๋ใี๎ํ์ࠧᷯ")]
		xZSFJ80V1X6RLb3GBIUjpq = [tR1krDGPpO025fghMT3a7UnYj(u"࠭ว็็ํࠫᷰ"),tR1krDGPpO025fghMT3a7UnYj(u"ࠧไำอ์๋࠭ᷱ"),c2RKu0xG1eC8MiohyE(u"ࠨๅสีฯ๎ๆࠨᷲ"),iNc3KxwErnQ(u"ࠩ࡮࡭ࡩࡹࠧᷳ"),LZWMikPEB81KSGyxfJtUsCA(u"ࠪ฻ๆ๊ࠧᷴ"),rNdBKI74fAklnoCZ6(u"ࠫฬ฽แศๆࠪ᷵")]
		lBIkOei1Rv9P6pEg = [DaFZHsThGmd0zv6e(u"ࠬืๅืษ้ࠫ᷶")]
		wwmvODMWlVSc = [fWoVd0Bmtkx(u"࠭วฮัฮ᷷ࠫ"),IaBhDMJc17302LgSvyxd(u"ࠧศะิ᷸ࠫ"),qoBMmfAWpFlK70xw8ZRh4naJ(u"ࠨ็๋าึ᷹࠭"),fWoVd0Bmtkx(u"ࠩฯำ๏ี᷺ࠧ"),l32dnTEOU1skGKqeBtI9hmo(u"้ࠪ฻อแࠨ᷻"),kYDaz79TFlXoR(u"ࠫาี๊ฬࠩ᷼")]
		fIs6b8dSH9Ttig2AG = [ddiCzu6yahj5RtTISMJ48sNnZBU(u"ูࠬไศี็᷽ࠫ"),tQMjXKCA5dN4xq3beVIzaEoWkFLg(u"࠭ำๅี็๋ࠬ᷾")]
		qyuATWg1LsSDJH7zk5YNxl6wcKh = [ddiCzu6yahj5RtTISMJ48sNnZBU(u"ࠧศ฼ส๊๏᷿࠭"),rNdBKI74fAklnoCZ6(u"ࠨ็๋ื๏่้ࠨḀ"),rNdBKI74fAklnoCZ6(u"ࠩๆ่๏ฮࠧḁ"),qqzwE6imYG4c2xojI(u"ࠪัๆ๊ࠧḂ"),dJHDqiKf12TXlIzSLkGUuxg4MBs3A(u"ࠫࡲࡻࡳࡪࡥࠪḃ")]
		DZVXoSzp8PexHucRJdfFnG1tv = [aXqWLoTdVgME(u"ࠬอใฬำࠪḄ"),V3VlkhgjEF4n1erPXHcC0NOsfwyAJ(u"࠭วี้ิࠫḅ"),CC1eY6yWZUwf2TkRvnp7EJ0AimjHBX(u"ࠧๆ็ํึ์࠭Ḇ"),RlOvin8YIGC2KZXJPk9m0acrMobUex(u"ࠨษ฼่๎࠭ḇ"),c2RKu0xG1eC8MiohyE(u"่ࠩาฯอั่ࠩḈ"),V3VlkhgjEF4n1erPXHcC0NOsfwyAJ(u"้ࠪำะวาษอࠫḉ"),l32dnTEOU1skGKqeBtI9hmo(u"ࠫฬ่่๊ࠩḊ")]
		zU9snNBkFQK5eAyVoD8uJOPL32XhZS = [mmV2nucZ5Lpl6FO1JMPEqGoQKW(u"ࠬอไศ่ࠪḋ"),sjtU6GZQg5XC2pH4(u"࠭อศๆํࠫḌ"),IaBhDMJc17302LgSvyxd(u"ࠧๆอหฮࠬḍ"),CC1eY6yWZUwf2TkRvnp7EJ0AimjHBX(u"ࠨำสสั࠭Ḏ")]
		mjsw0igXVhO6 = [mmV2nucZ5Lpl6FO1JMPEqGoQKW(u"ูࠩั่࠭ḏ"),N3flV6EJsD5CzS(u"ࠪ็ํ๋๊ะ์ࠪḐ")]
		xxnZGorjK243sPFc7 = [Ie5s2cBtSfdHjzQ4rA9kYlo6D18(u"ࠫึ๐วื้ࠪḑ"),ee86G9ladLHVbh5mikzCo(u"้่ࠬา้ࠪḒ"),IaBhDMJc17302LgSvyxd(u"࠭ๅึษิ฽์࠭ḓ"),RlOvin8YIGC2KZXJPk9m0acrMobUex(u"ࠧี๊อࠫḔ"),V3VlkhgjEF4n1erPXHcC0NOsfwyAJ(u"ࠨำํห฻ฯࠧḕ")]
		NXkTLZjuasB0EVChYFJxA6MoOi = [ee86G9ladLHVbh5mikzCo(u"้ࠩ๎ฯ็ไไีࠪḖ"),l1DZAt9XNQjqE7YOdrz(u"ࠪࡲࡪࡺࡦ࡭࡫ࡻࠫḗ"),ddiCzu6yahj5RtTISMJ48sNnZBU(u"๋ࠫ๐สโๆํ็ุ࠭Ḙ")]
		x17YborZsACOeBi4GRSWVypD0uNfL = [BRWqdruz2A0(u"๋ࠬๅฬๆํ๊ࠬḙ"),fWoVd0Bmtkx(u"࠭วีะสูࠬḚ"),kYDaz79TFlXoR(u"ࠧ็ฮ๋้ࠬḛ")]
		A2ajuOxflTL3GQpZhdgi = [tR1krDGPpO025fghMT3a7UnYj(u"ࠨสฮࠤา๐ࠧḜ"),iNc3KxwErnQ(u"ࠩ࡯࡭ࡻ࡫ࠧḝ"),tQMjXKCA5dN4xq3beVIzaEoWkFLg(u"ࠪๆ๋อ็ࠨḞ"),aXqWLoTdVgME(u"ࠫ็์่ศฬࠪḟ")]
		BXMiApmosU1OyLEqfj2xWDhHK6g = [YY8UDX3MJhb91AHw7fg(u"ࠬี๊็ࠩḠ"),UUDAiytEL76RTmMYsuIz5evXB(u"࠭วะ฻ํ๋ࠬḡ"),aXqWLoTdVgME(u"ࠧำ์สีฬะࠧḢ"),RlOvin8YIGC2KZXJPk9m0acrMobUex(u"ࠨๆฺ้๏อสࠨḣ"),zYvEaigKWjoq50pXBLDbGJkFc(u"ࠩา฽ฬวࠧḤ"),IaBhDMJc17302LgSvyxd(u"ࠪๆึอๆࠨḥ"),qoBMmfAWpFlK70xw8ZRh4naJ(u"ࠫ็฻ววัࠪḦ"),Ie5s2cBtSfdHjzQ4rA9kYlo6D18(u"ࠬืหศรࠪḧ"),mmV2nucZ5Lpl6FO1JMPEqGoQKW(u"࠭ๅาฮ฼๎์࠭Ḩ"),tR1krDGPpO025fghMT3a7UnYj(u"ࠧศาส๊ࠬḩ"),DaFZHsThGmd0zv6e(u"ࠨษึ่ฬ๋ࠧḪ"),ddiCzu6yahj5RtTISMJ48sNnZBU(u"ࠩอ์ฬฺ๊ฮࠩḫ"),DaFZHsThGmd0zv6e(u"ࠪา฼ฮࠧḬ"),viRJWOC5jsYe84(u"ࠫา๎า้์ࠪḭ"),sjtU6GZQg5XC2pH4(u"ࠬ฿สษษอࠫḮ"),CC1eY6yWZUwf2TkRvnp7EJ0AimjHBX(u"࠭ๅ้ษ็๎ิ࠭ḯ"),YY8UDX3MJhb91AHw7fg(u"ࠧ็๊ส฽๏࠭Ḱ"),RlOvin8YIGC2KZXJPk9m0acrMobUex(u"ࠨ฻ๅหหีࠧḱ"),RlOvin8YIGC2KZXJPk9m0acrMobUex(u"ࠩส๊ฬฺ๊ะࠩḲ")]
		Ntd3hKZ7fQluIzx8L = [zYvEaigKWjoq50pXBLDbGJkFc(u"ࠪ࠶࠵࠷࠰ࠨḳ"),sjtU6GZQg5XC2pH4(u"ࠫ࠷࠶࠱࠲ࠩḴ"),ddiCzu6yahj5RtTISMJ48sNnZBU(u"ࠬ࠸࠰࠲࠴ࠪḵ"),IaBhDMJc17302LgSvyxd(u"࠭࠲࠱࠳࠶ࠫḶ"),Ie5s2cBtSfdHjzQ4rA9kYlo6D18(u"ࠧ࠳࠲࠴࠸ࠬḷ"),V3VlkhgjEF4n1erPXHcC0NOsfwyAJ(u"ࠨ࠴࠳࠵࠺࠭Ḹ"),ddiCzu6yahj5RtTISMJ48sNnZBU(u"ࠩ࠵࠴࠶࠼ࠧḹ"),c2RKu0xG1eC8MiohyE(u"ࠪ࠶࠵࠷࠷ࠨḺ"),viRJWOC5jsYe84(u"ࠫ࠷࠶࠱࠹ࠩḻ"),UVa3fJw7k6KM(u"ࠬ࠸࠰࠲࠻ࠪḼ"),fWoVd0Bmtkx(u"࠭࠲࠱࠴࠳ࠫḽ"),YY8UDX3MJhb91AHw7fg(u"ࠧ࠳࠲࠵࠵ࠬḾ"),iNc3KxwErnQ(u"ࠨ࠴࠳࠶࠷࠭ḿ"),aXqWLoTdVgME(u"ࠩ࠵࠴࠷࠹ࠧṀ"),IaBhDMJc17302LgSvyxd(u"ࠪ࠶࠵࠸࠴ࠨṁ"),aXqWLoTdVgME(u"ࠫ࠷࠶࠲࠶ࠩṂ"),mmV2nucZ5Lpl6FO1JMPEqGoQKW(u"ࠬ࠸࠰࠳࠸ࠪṃ"),DaFZHsThGmd0zv6e(u"࠭࠲࠱࠴࠺ࠫṄ"),sjtU6GZQg5XC2pH4(u"ࠧ࠳࠲࠵࠼ࠬṅ")]
		for mMgEh8S9xkCA5atcIP4GWOJlpDdKQ in sorted(list(myZKBn3kcqflCX1EOM69jUW.keys())):
			YblzdQaeVqgF = mMgEh8S9xkCA5atcIP4GWOJlpDdKQ.lower()
			n1uwH0oJaGZ5WBd = []
			if any(value in YblzdQaeVqgF for value in mmTqzVCksDBKGrZYMlwNcRxUWHLJ): n1uwH0oJaGZ5WBd.append(mZi0S72jGoHpLO)
			if any(value in YblzdQaeVqgF for value in A8s6orYkjplw): n1uwH0oJaGZ5WBd.append(Zwqio2AIWlD5etFa)
			if any(value in YblzdQaeVqgF for value in smwnp0QEGkjd6v): n1uwH0oJaGZ5WBd.append(DAE6vkyhXGx1wBdHmcFfTVQpL0l)
			if any(value in YblzdQaeVqgF for value in TtF53EqRDWkbw90QCV): n1uwH0oJaGZ5WBd.append(wn4bG51vUENfaS0Zg)
			if any(value in YblzdQaeVqgF for value in xZSFJ80V1X6RLb3GBIUjpq): n1uwH0oJaGZ5WBd.append(Y719atFWlPpbO6uTULjZf5VGD2o0)
			if any(value in YblzdQaeVqgF for value in lBIkOei1Rv9P6pEg): n1uwH0oJaGZ5WBd.append(LZWMikPEB81KSGyxfJtUsCA(u"࠻὆"))
			if any(value in YblzdQaeVqgF for value in wwmvODMWlVSc) and YblzdQaeVqgF not in [c2RKu0xG1eC8MiohyE(u"ࠨษัี๎࠭Ṇ")]: n1uwH0oJaGZ5WBd.append(iNc3KxwErnQ(u"࠽὇"))
			if any(value in YblzdQaeVqgF for value in fIs6b8dSH9Ttig2AG): n1uwH0oJaGZ5WBd.append(ddiCzu6yahj5RtTISMJ48sNnZBU(u"࠸Ὀ"))
			if any(value in YblzdQaeVqgF for value in qyuATWg1LsSDJH7zk5YNxl6wcKh): n1uwH0oJaGZ5WBd.append(ddiCzu6yahj5RtTISMJ48sNnZBU(u"࠺Ὁ"))
			if any(value in YblzdQaeVqgF for value in DZVXoSzp8PexHucRJdfFnG1tv): n1uwH0oJaGZ5WBd.append(tR1krDGPpO025fghMT3a7UnYj(u"࠳࠳Ὂ"))
			if any(value in YblzdQaeVqgF for value in zU9snNBkFQK5eAyVoD8uJOPL32XhZS): n1uwH0oJaGZ5WBd.append(UVa3fJw7k6KM(u"࠴࠵Ὃ"))
			if any(value in YblzdQaeVqgF for value in mjsw0igXVhO6): n1uwH0oJaGZ5WBd.append(IaBhDMJc17302LgSvyxd(u"࠵࠷Ὄ"))
			if any(value in YblzdQaeVqgF for value in xxnZGorjK243sPFc7): n1uwH0oJaGZ5WBd.append(ddiCzu6yahj5RtTISMJ48sNnZBU(u"࠶࠹Ὅ"))
			if any(value in YblzdQaeVqgF for value in NXkTLZjuasB0EVChYFJxA6MoOi): n1uwH0oJaGZ5WBd.append(BRWqdruz2A0(u"࠷࠴὎"))
			if any(value in YblzdQaeVqgF for value in x17YborZsACOeBi4GRSWVypD0uNfL): n1uwH0oJaGZ5WBd.append(UUDAiytEL76RTmMYsuIz5evXB(u"࠱࠶὏"))
			if any(value in YblzdQaeVqgF for value in A2ajuOxflTL3GQpZhdgi): n1uwH0oJaGZ5WBd.append(aXqWLoTdVgME(u"࠲࠸ὐ"))
			if any(value in YblzdQaeVqgF for value in BXMiApmosU1OyLEqfj2xWDhHK6g): n1uwH0oJaGZ5WBd.append(l32dnTEOU1skGKqeBtI9hmo(u"࠳࠺ὑ"))
			if any(value in YblzdQaeVqgF for value in Ntd3hKZ7fQluIzx8L): n1uwH0oJaGZ5WBd.append(sjtU6GZQg5XC2pH4(u"࠴࠼ὒ"))
			if not n1uwH0oJaGZ5WBd: n1uwH0oJaGZ5WBd = [l32dnTEOU1skGKqeBtI9hmo(u"࠵࠾ὓ")]
			for wAiu7RQK1rboNnLS0vMEI in n1uwH0oJaGZ5WBd:
				if str(wAiu7RQK1rboNnLS0vMEI)==tq5rxw1jPpSgFeYflzX9CO0aR6H:
					x3WSXnKyPhjqfHG2UrtQs(zYvEaigKWjoq50pXBLDbGJkFc(u"ࠩࡩࡳࡱࡪࡥࡳࠩṇ"),wwSFijdVJn1QgHW+mMgEh8S9xkCA5atcIP4GWOJlpDdKQ,mMgEh8S9xkCA5atcIP4GWOJlpDdKQ,UUDAiytEL76RTmMYsuIz5evXB(u"࠶࠼࠶ὔ"),qpFY4hAwolV3,qpFY4hAwolV3,oJEqm9eVfsYdkcQ+ddiCzu6yahj5RtTISMJ48sNnZBU(u"ࠪࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧṈ"))
	nGRXot8mU9Qa2Dd(z5wEtWrCxRZiQ,z5wEtWrCxRZiQ,dND7uS6bknRj82EOIX0iyUxAscl)
	return
def tO3K2vSfWHBRodCFlhDuVQ5JeI(LLcgQ6E12OZezYbh4CVdIa,ZZCk6FGHRa8):
	FAHCtdm48uIsx = ag8rjZo1Vz4IPdcOT
	if FAHCtdm48uIsx:
		x3WSXnKyPhjqfHG2UrtQs(RlOvin8YIGC2KZXJPk9m0acrMobUex(u"ࠫࡱ࡯࡮࡬ࠩṉ"),Ie5s2cBtSfdHjzQ4rA9kYlo6D18(u"ࠬะอะ์ฮࠤ็อฦๆหࠣว็ูวๆࠢࡌࡔ࡙࡜ࠧṊ"),qpFY4hAwolV3,IaBhDMJc17302LgSvyxd(u"࠽࠶࠵ὕ"),qpFY4hAwolV3,qpFY4hAwolV3,IaBhDMJc17302LgSvyxd(u"࠭࡟ࡄࡔࡈࡅ࡙ࡋࡎࡆ࡙ࡢࠫṋ"),qpFY4hAwolV3,{qoBMmfAWpFlK70xw8ZRh4naJ(u"ࠧࡧࡱ࡯ࡨࡪࡸࠧṌ"):LLcgQ6E12OZezYbh4CVdIa})
		x3WSXnKyPhjqfHG2UrtQs(BRWqdruz2A0(u"ࠨ࡮࡬ࡲࡰ࠭ṍ"),xupTj02bvy3O8R+tQMjXKCA5dN4xq3beVIzaEoWkFLg(u"ࠩࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦࠧṎ")+fF4lt9zWYxXLKZVyAco82PgMj,qpFY4hAwolV3,V3VlkhgjEF4n1erPXHcC0NOsfwyAJ(u"࠹࠺࠻࠼ὖ"))
	CG2OMgKsb50WzVEkQtZarvcm1 = i4bFG3rKE6.menuItemsLIST[:]
	import kuHhyElsXe
	if LLcgQ6E12OZezYbh4CVdIa:
		if not kuHhyElsXe.N4mtgDP83waX9(LLcgQ6E12OZezYbh4CVdIa,gBExoceumj4y8bFW9hY2aNMVSr): return
		UURqDJpi8ZH7m0C9wP1Mh = bSynDjcN6L815tfkIOH9eJ4sxXqor(LLcgQ6E12OZezYbh4CVdIa,ZZCk6FGHRa8)
		SoixgtW3VRZj = sorted(UURqDJpi8ZH7m0C9wP1Mh,reverse=ag8rjZo1Vz4IPdcOT,key=lambda key: key[mZi0S72jGoHpLO].lower())
	else:
		if not kuHhyElsXe.N4mtgDP83waX9(qpFY4hAwolV3,gBExoceumj4y8bFW9hY2aNMVSr): return
		if FAHCtdm48uIsx and aXqWLoTdVgME(u"ࠪࡣࡈࡘࡅࡂࡖࡈࡒࡊ࡝࡟ࠨṏ") not in ZZCk6FGHRa8:
			SoixgtW3VRZj = XXyMBNAVJvKiq7jc20bEw6(WoFsvbmUlDZp7PzRfdGknCV,UUDAiytEL76RTmMYsuIz5evXB(u"ࠫࡱ࡯ࡳࡵࠩṐ"),sjtU6GZQg5XC2pH4(u"࡙ࠬࡅࡄࡖࡌࡓࡓ࡙࡟ࡊࡒࡗ࡚ࠬṑ"),zYvEaigKWjoq50pXBLDbGJkFc(u"࠭ࡓࡆࡅࡗࡍࡔࡔࡓࡠࡋࡓࡘ࡛ࡥࡁࡍࡎࠪṒ"))
		else:
			bhsxWeykBuGFt8KfMc,SoixgtW3VRZj,UURqDJpi8ZH7m0C9wP1Mh = [],[],[]
			for M9R2JOlWnk0CEifX43rFBhG in range(mZi0S72jGoHpLO,v2ir6R7FZASfMOl4wqTLKBNupX5E+mZi0S72jGoHpLO):
				SoixgtW3VRZj += bSynDjcN6L815tfkIOH9eJ4sxXqor(str(M9R2JOlWnk0CEifX43rFBhG),ZZCk6FGHRa8)
			for type,mMgEh8S9xkCA5atcIP4GWOJlpDdKQ,url,ZyiMa3BXVk2xWG0b,BvbuigUeoJLnTaN2qWxQ415AtYMK9I,i02wfPp5EM,HY7yaJeI89xE56sbTjdBRZPDwQKFX,AArDKw6baWehCSOz7,uu5WqOEaRZIibszwTc6t1nmLfAj in SoixgtW3VRZj:
				if HY7yaJeI89xE56sbTjdBRZPDwQKFX not in bhsxWeykBuGFt8KfMc:
					bhsxWeykBuGFt8KfMc.append(HY7yaJeI89xE56sbTjdBRZPDwQKFX)
					sSfz8g4OvqX = type,mMgEh8S9xkCA5atcIP4GWOJlpDdKQ,HY7yaJeI89xE56sbTjdBRZPDwQKFX,qqzwE6imYG4c2xojI(u"࠲࠸࠸ὗ"),BvbuigUeoJLnTaN2qWxQ415AtYMK9I,i02wfPp5EM,ZZCk6FGHRa8,AArDKw6baWehCSOz7,uu5WqOEaRZIibszwTc6t1nmLfAj
					UURqDJpi8ZH7m0C9wP1Mh.append(sSfz8g4OvqX)
			SoixgtW3VRZj = sorted(UURqDJpi8ZH7m0C9wP1Mh,reverse=ag8rjZo1Vz4IPdcOT,key=lambda key: key[mZi0S72jGoHpLO].lower())
			if FAHCtdm48uIsx: zOYMaQ0NgdiRVwDJXh8e(WoFsvbmUlDZp7PzRfdGknCV,DaFZHsThGmd0zv6e(u"ࠧࡔࡇࡆࡘࡎࡕࡎࡔࡡࡌࡔ࡙࡜ࠧṓ"),rNdBKI74fAklnoCZ6(u"ࠨࡕࡈࡇ࡙ࡏࡏࡏࡕࡢࡍࡕ࡚ࡖࡠࡃࡏࡐࠬṔ"),SoixgtW3VRZj,ivLg9zRnGF83u)
	i4bFG3rKE6.menuItemsLIST[:] = CG2OMgKsb50WzVEkQtZarvcm1+SoixgtW3VRZj
	E2E18vJ4hLaZpuWSfoMlY9yBzj6b(ag8rjZo1Vz4IPdcOT)
	return
def EgBG4hd8PjUtXrVzpybcSA5fuvlZk(LLcgQ6E12OZezYbh4CVdIa,ZZCk6FGHRa8):
	FAHCtdm48uIsx = ag8rjZo1Vz4IPdcOT
	if FAHCtdm48uIsx:
		x3WSXnKyPhjqfHG2UrtQs(BRWqdruz2A0(u"ࠩ࡯࡭ࡳࡱࠧṕ"),tQMjXKCA5dN4xq3beVIzaEoWkFLg(u"ࠪฮาี๊ฬࠢๅหห๋ษࠡลๅืฬ๋ࠠࡎ࠵ࡘࠫṖ"),qpFY4hAwolV3,aXqWLoTdVgME(u"࠹࠹࠹὘"),qpFY4hAwolV3,qpFY4hAwolV3,tR1krDGPpO025fghMT3a7UnYj(u"ࠫࡤࡉࡒࡆࡃࡗࡉࡓࡋࡗࡠࠩṗ"),qpFY4hAwolV3,{UUDAiytEL76RTmMYsuIz5evXB(u"ࠬ࡬࡯࡭ࡦࡨࡶࠬṘ"):LLcgQ6E12OZezYbh4CVdIa})
		x3WSXnKyPhjqfHG2UrtQs(l32dnTEOU1skGKqeBtI9hmo(u"࠭࡬ࡪࡰ࡮ࠫṙ"),xupTj02bvy3O8R+ee86G9ladLHVbh5mikzCo(u"ࠧ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࠬṚ")+fF4lt9zWYxXLKZVyAco82PgMj,qpFY4hAwolV3,dJHDqiKf12TXlIzSLkGUuxg4MBs3A(u"࠼࠽࠾࠿Ὑ"))
	CG2OMgKsb50WzVEkQtZarvcm1 = i4bFG3rKE6.menuItemsLIST[:]
	import jV4SY0Trl2
	if LLcgQ6E12OZezYbh4CVdIa:
		if not jV4SY0Trl2.N4mtgDP83waX9(LLcgQ6E12OZezYbh4CVdIa,gBExoceumj4y8bFW9hY2aNMVSr): return
		UURqDJpi8ZH7m0C9wP1Mh = lpi3gjNW6T0zR8MPuc(LLcgQ6E12OZezYbh4CVdIa,ZZCk6FGHRa8)
		SoixgtW3VRZj = sorted(UURqDJpi8ZH7m0C9wP1Mh,reverse=ag8rjZo1Vz4IPdcOT,key=lambda key: key[mZi0S72jGoHpLO].lower())
	else:
		if not jV4SY0Trl2.N4mtgDP83waX9(qpFY4hAwolV3,gBExoceumj4y8bFW9hY2aNMVSr): return
		if FAHCtdm48uIsx and ddiCzu6yahj5RtTISMJ48sNnZBU(u"ࠨࡡࡆࡖࡊࡇࡔࡆࡐࡈ࡛ࡤ࠭ṛ") not in ZZCk6FGHRa8:
			SoixgtW3VRZj = XXyMBNAVJvKiq7jc20bEw6(WoFsvbmUlDZp7PzRfdGknCV,RlOvin8YIGC2KZXJPk9m0acrMobUex(u"ࠩ࡯࡭ࡸࡺࠧṜ"),rNdBKI74fAklnoCZ6(u"ࠪࡗࡊࡉࡔࡊࡑࡑࡗࡤࡓ࠳ࡖࠩṝ"),kYDaz79TFlXoR(u"ࠫࡘࡋࡃࡕࡋࡒࡒࡘࡥࡍ࠴ࡗࡢࡅࡑࡒࠧṞ"))
		else:
			bhsxWeykBuGFt8KfMc,SoixgtW3VRZj,UURqDJpi8ZH7m0C9wP1Mh = [],[],[]
			for M9R2JOlWnk0CEifX43rFBhG in range(mZi0S72jGoHpLO,v2ir6R7FZASfMOl4wqTLKBNupX5E+mZi0S72jGoHpLO):
				SoixgtW3VRZj += lpi3gjNW6T0zR8MPuc(str(M9R2JOlWnk0CEifX43rFBhG),ZZCk6FGHRa8)
			for type,mMgEh8S9xkCA5atcIP4GWOJlpDdKQ,url,ZyiMa3BXVk2xWG0b,BvbuigUeoJLnTaN2qWxQ415AtYMK9I,i02wfPp5EM,HY7yaJeI89xE56sbTjdBRZPDwQKFX,AArDKw6baWehCSOz7,uu5WqOEaRZIibszwTc6t1nmLfAj in SoixgtW3VRZj:
				if HY7yaJeI89xE56sbTjdBRZPDwQKFX not in bhsxWeykBuGFt8KfMc:
					bhsxWeykBuGFt8KfMc.append(HY7yaJeI89xE56sbTjdBRZPDwQKFX)
					sSfz8g4OvqX = type,mMgEh8S9xkCA5atcIP4GWOJlpDdKQ,HY7yaJeI89xE56sbTjdBRZPDwQKFX,sjtU6GZQg5XC2pH4(u"࠵࠻࠻὚"),BvbuigUeoJLnTaN2qWxQ415AtYMK9I,i02wfPp5EM,ZZCk6FGHRa8,AArDKw6baWehCSOz7,uu5WqOEaRZIibszwTc6t1nmLfAj
					UURqDJpi8ZH7m0C9wP1Mh.append(sSfz8g4OvqX)
			SoixgtW3VRZj = sorted(UURqDJpi8ZH7m0C9wP1Mh,reverse=ag8rjZo1Vz4IPdcOT,key=lambda key: key[mZi0S72jGoHpLO].lower())
			if FAHCtdm48uIsx: zOYMaQ0NgdiRVwDJXh8e(WoFsvbmUlDZp7PzRfdGknCV,rNdBKI74fAklnoCZ6(u"࡙ࠬࡅࡄࡖࡌࡓࡓ࡙࡟ࡎ࠵ࡘࠫṟ"),sjtU6GZQg5XC2pH4(u"࠭ࡓࡆࡅࡗࡍࡔࡔࡓࡠࡏ࠶࡙ࡤࡇࡌࡍࠩṠ"),SoixgtW3VRZj,ivLg9zRnGF83u)
	i4bFG3rKE6.menuItemsLIST[:] = CG2OMgKsb50WzVEkQtZarvcm1+SoixgtW3VRZj
	E2E18vJ4hLaZpuWSfoMlY9yBzj6b(ag8rjZo1Vz4IPdcOT)
	return
def aaZ5XPxOGs(group,ZZCk6FGHRa8):
	FAHCtdm48uIsx = ag8rjZo1Vz4IPdcOT
	MOTjA5H9XFs = []
	SAGmVil6Eb = UVa3fJw7k6KM(u"ࠧࡠࡋࡓࡘ࡛ࡥࠧṡ") if tQMjXKCA5dN4xq3beVIzaEoWkFLg(u"ࠨࡋࡓࡘ࡛࠭Ṣ") in ZZCk6FGHRa8 else lljaEqwTVtmKsQcOrbXxS5hgNH(u"ࠩࡢࡑ࠸࡛࡟ࠨṣ")
	if FAHCtdm48uIsx: MOTjA5H9XFs = XXyMBNAVJvKiq7jc20bEw6(WoFsvbmUlDZp7PzRfdGknCV,UUDAiytEL76RTmMYsuIz5evXB(u"ࠪࡰ࡮ࡹࡴࠨṤ"),c2RKu0xG1eC8MiohyE(u"ࠫࡘࡋࡃࡕࡋࡒࡒࡘ࠭ṥ")+SAGmVil6Eb[:-mZi0S72jGoHpLO],group)
	if not MOTjA5H9XFs:
		for LLcgQ6E12OZezYbh4CVdIa in range(mZi0S72jGoHpLO,v2ir6R7FZASfMOl4wqTLKBNupX5E+mZi0S72jGoHpLO):
			if FAHCtdm48uIsx: MOTjA5H9XFs += XXyMBNAVJvKiq7jc20bEw6(WoFsvbmUlDZp7PzRfdGknCV,kYDaz79TFlXoR(u"ࠬࡲࡩࡴࡶࠪṦ"),ee86G9ladLHVbh5mikzCo(u"࠭ࡓࡆࡅࡗࡍࡔࡔࡓࠨṧ")+SAGmVil6Eb[:-mZi0S72jGoHpLO],UVa3fJw7k6KM(u"ࠧࡔࡇࡆࡘࡎࡕࡎࡔࠩṨ")+SAGmVil6Eb+str(LLcgQ6E12OZezYbh4CVdIa))
			elif SAGmVil6Eb==LZWMikPEB81KSGyxfJtUsCA(u"ࠨࡡࡌࡔ࡙࡜࡟ࠨṩ"): MOTjA5H9XFs += bSynDjcN6L815tfkIOH9eJ4sxXqor(str(LLcgQ6E12OZezYbh4CVdIa),CC1eY6yWZUwf2TkRvnp7EJ0AimjHBX(u"ࠩࡢࡇࡗࡋࡁࡕࡇࡑࡉ࡜ࡥࠧṪ"))
			elif SAGmVil6Eb==Ie5s2cBtSfdHjzQ4rA9kYlo6D18(u"ࠪࡣࡒ࠹ࡕࡠࠩṫ"): MOTjA5H9XFs += lpi3gjNW6T0zR8MPuc(str(LLcgQ6E12OZezYbh4CVdIa),tQMjXKCA5dN4xq3beVIzaEoWkFLg(u"ࠫࡤࡉࡒࡆࡃࡗࡉࡓࡋࡗࡠࠩṬ"))
		for type,mMgEh8S9xkCA5atcIP4GWOJlpDdKQ,url,ZyiMa3BXVk2xWG0b,BvbuigUeoJLnTaN2qWxQ415AtYMK9I,i02wfPp5EM,HY7yaJeI89xE56sbTjdBRZPDwQKFX,AArDKw6baWehCSOz7,uu5WqOEaRZIibszwTc6t1nmLfAj in MOTjA5H9XFs:
			if HY7yaJeI89xE56sbTjdBRZPDwQKFX==group: PLd4s0tr67GpoK(type,mMgEh8S9xkCA5atcIP4GWOJlpDdKQ,url,ZyiMa3BXVk2xWG0b,BvbuigUeoJLnTaN2qWxQ415AtYMK9I,i02wfPp5EM,HY7yaJeI89xE56sbTjdBRZPDwQKFX,AArDKw6baWehCSOz7,uu5WqOEaRZIibszwTc6t1nmLfAj)
		items,eKEo1iY0x8kAcU76ChWaypzHIwlRMq = [],[]
		for type,mMgEh8S9xkCA5atcIP4GWOJlpDdKQ,url,ZyiMa3BXVk2xWG0b,BvbuigUeoJLnTaN2qWxQ415AtYMK9I,i02wfPp5EM,HY7yaJeI89xE56sbTjdBRZPDwQKFX,AArDKw6baWehCSOz7,uu5WqOEaRZIibszwTc6t1nmLfAj in i4bFG3rKE6.menuItemsLIST:
			aal45yKQLnjZHGASzJ82k = type,mMgEh8S9xkCA5atcIP4GWOJlpDdKQ[wn4bG51vUENfaS0Zg:],url,ZyiMa3BXVk2xWG0b,BvbuigUeoJLnTaN2qWxQ415AtYMK9I,i02wfPp5EM,HY7yaJeI89xE56sbTjdBRZPDwQKFX,AArDKw6baWehCSOz7,qpFY4hAwolV3
			if aal45yKQLnjZHGASzJ82k not in eKEo1iY0x8kAcU76ChWaypzHIwlRMq:
				eKEo1iY0x8kAcU76ChWaypzHIwlRMq.append(aal45yKQLnjZHGASzJ82k)
				lkd2oKvZF03qmgMbIfQ6cD = type,mMgEh8S9xkCA5atcIP4GWOJlpDdKQ,url,ZyiMa3BXVk2xWG0b,BvbuigUeoJLnTaN2qWxQ415AtYMK9I,i02wfPp5EM,HY7yaJeI89xE56sbTjdBRZPDwQKFX,AArDKw6baWehCSOz7,uu5WqOEaRZIibszwTc6t1nmLfAj
				items.append(lkd2oKvZF03qmgMbIfQ6cD)
		MOTjA5H9XFs = sorted(items,reverse=ag8rjZo1Vz4IPdcOT,key=lambda key: key[mZi0S72jGoHpLO].lower()[viRJWOC5jsYe84(u"࠺Ὓ"):])
		if FAHCtdm48uIsx: zOYMaQ0NgdiRVwDJXh8e(WoFsvbmUlDZp7PzRfdGknCV,UUDAiytEL76RTmMYsuIz5evXB(u"࡙ࠬࡅࡄࡖࡌࡓࡓ࡙ࠧṭ")+SAGmVil6Eb[:-mZi0S72jGoHpLO],group,MOTjA5H9XFs,ivLg9zRnGF83u)
	if V3VlkhgjEF4n1erPXHcC0NOsfwyAJ(u"࠭࡟ࡓࡃࡑࡈࡔࡓ࡟ࠨṮ") in ZZCk6FGHRa8 and len(MOTjA5H9XFs)>a3Rx5WAGMmZs9wcKf0bklr47XUNSD:
		i4bFG3rKE6.menuItemsLIST[:] = []
		x3WSXnKyPhjqfHG2UrtQs(l32dnTEOU1skGKqeBtI9hmo(u"ࠧࡧࡱ࡯ࡨࡪࡸࠧṯ"),DiJ8CMuYH1daWyjehfN0L(u"ࠨ࡝ࠪṰ")+xupTj02bvy3O8R+group+fF4lt9zWYxXLKZVyAco82PgMj+kYDaz79TFlXoR(u"ࠩࠣ࠾ฬ๊โิ็ࡠࠫṱ"),group,V3VlkhgjEF4n1erPXHcC0NOsfwyAJ(u"࠷࠶࠶὜"),qpFY4hAwolV3,qpFY4hAwolV3,SAGmVil6Eb+ee86G9ladLHVbh5mikzCo(u"ࠪࡣࡗࡇࡎࡅࡑࡐࡣࡤࡌࡏࡓࡉࡈࡘࡗࡋࡓࡖࡎࡗࡗࡤࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩṲ"))
		x3WSXnKyPhjqfHG2UrtQs(YY8UDX3MJhb91AHw7fg(u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫṳ"),N3flV6EJsD5CzS(u"ࠬหูศัฬࠤฬ๊ืๅสࠣห้฿ิ้ษษ๎๋ࠥๆ่ࠡไืࠥอไใี่ࠫṴ"),group,qoBMmfAWpFlK70xw8ZRh4naJ(u"࠱࠷࠷Ὕ"),qpFY4hAwolV3,qpFY4hAwolV3,SAGmVil6Eb+zYvEaigKWjoq50pXBLDbGJkFc(u"࠭࡟ࡓࡃࡑࡈࡔࡓ࡟ࡠࡈࡒࡖࡌࡋࡔࡓࡇࡖ࡙ࡑ࡚ࡓࡠࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬṵ"))
		x3WSXnKyPhjqfHG2UrtQs(l1DZAt9XNQjqE7YOdrz(u"ࠧ࡭࡫ࡱ࡯ࠬṶ"),xupTj02bvy3O8R+c2RKu0xG1eC8MiohyE(u"ࠨ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥ࠭ṷ")+fF4lt9zWYxXLKZVyAco82PgMj,qpFY4hAwolV3,dJHDqiKf12TXlIzSLkGUuxg4MBs3A(u"࠺࠻࠼࠽὞"))
		MOTjA5H9XFs = i4bFG3rKE6.menuItemsLIST+P9Kfwdgna8erGcAWyQMOtFbq6Rk.sample(MOTjA5H9XFs,a3Rx5WAGMmZs9wcKf0bklr47XUNSD)
	i4bFG3rKE6.menuItemsLIST[:] = MOTjA5H9XFs
	E2E18vJ4hLaZpuWSfoMlY9yBzj6b(ag8rjZo1Vz4IPdcOT)
	return
def uxrJZyKhizVD9w2qg(ZZCk6FGHRa8):
	x3WSXnKyPhjqfHG2UrtQs(aXqWLoTdVgME(u"ࠩࡩࡳࡱࡪࡥࡳࠩṸ"),CC1eY6yWZUwf2TkRvnp7EJ0AimjHBX(u"ࠪษ฾อฯสฺ่ࠢอࠦโ็๊สฮࠥ฿ิ้ษษ๎ฮ࠭ṹ"),qpFY4hAwolV3,aXqWLoTdVgME(u"࠳࠹࠵Ὗ"),qpFY4hAwolV3,qpFY4hAwolV3,Ie5s2cBtSfdHjzQ4rA9kYlo6D18(u"ࠫࡤࡌࡏࡓࡉࡈࡘࡗࡋࡓࡖࡎࡗࡗࡤࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࡡࡏࡍ࡛ࡋࡔࡗࡡࡢࡖࡆࡔࡄࡐࡏࡢࠫṺ"))
	x3WSXnKyPhjqfHG2UrtQs(RlOvin8YIGC2KZXJPk9m0acrMobUex(u"ࠬࡲࡩ࡯࡭ࠪṻ"),xupTj02bvy3O8R+mmV2nucZ5Lpl6FO1JMPEqGoQKW(u"࠭࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࠫṼ")+fF4lt9zWYxXLKZVyAco82PgMj,qpFY4hAwolV3,rNdBKI74fAklnoCZ6(u"࠼࠽࠾࠿ὠ"))
	jj8lJSUNoRwWznsikeGmVyfxD6r = i4bFG3rKE6.menuItemsLIST[:]
	i4bFG3rKE6.menuItemsLIST[:] = []
	import c7lwdo4vsi
	c7lwdo4vsi.I19sHuzZ8RryYXSwgV7mQ3Dh(RlOvin8YIGC2KZXJPk9m0acrMobUex(u"ࠧ࠱ࠩṽ"),ag8rjZo1Vz4IPdcOT)
	c7lwdo4vsi.I19sHuzZ8RryYXSwgV7mQ3Dh(l1DZAt9XNQjqE7YOdrz(u"ࠨ࠳ࠪṾ"),ag8rjZo1Vz4IPdcOT)
	c7lwdo4vsi.I19sHuzZ8RryYXSwgV7mQ3Dh(DaFZHsThGmd0zv6e(u"ࠩ࠵ࠫṿ"),ag8rjZo1Vz4IPdcOT)
	if rNdBKI74fAklnoCZ6(u"ࠪࡣࡗࡇࡎࡅࡑࡐࡣࠬẀ") in ZZCk6FGHRa8:
		i4bFG3rKE6.menuItemsLIST[:] = oLZlMFBRHaeEtGkYN(i4bFG3rKE6.menuItemsLIST)
		if len(i4bFG3rKE6.menuItemsLIST)>a3Rx5WAGMmZs9wcKf0bklr47XUNSD: i4bFG3rKE6.menuItemsLIST[:] = P9Kfwdgna8erGcAWyQMOtFbq6Rk.sample(i4bFG3rKE6.menuItemsLIST,a3Rx5WAGMmZs9wcKf0bklr47XUNSD)
	i4bFG3rKE6.menuItemsLIST[:] = jj8lJSUNoRwWznsikeGmVyfxD6r+i4bFG3rKE6.menuItemsLIST
	return
def MUaXV0oCuIH9Jp(ZZCk6FGHRa8):
	ZZCk6FGHRa8 = ZZCk6FGHRa8.replace(IaBhDMJc17302LgSvyxd(u"ࠫࡤࡌࡏࡓࡉࡈࡘࡗࡋࡓࡖࡎࡗࡗࡤ࠭ẁ"),qpFY4hAwolV3).replace(kYDaz79TFlXoR(u"ࠬࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩẂ"),qpFY4hAwolV3)
	headers = { UUDAiytEL76RTmMYsuIz5evXB(u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪẃ") : qpFY4hAwolV3 }
	url = rNdBKI74fAklnoCZ6(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡹࡺࡻ࠳ࡨࡥࡴࡶࡵࡥࡳࡪ࡯࡮ࡵ࠱ࡧࡴࡳ࠯ࡳࡣࡱࡨࡴࡳ࠭ࡢࡴࡤࡦ࡮ࡩ࠭ࡸࡱࡵࡨࡸ࠭Ẅ")
	data = {IaBhDMJc17302LgSvyxd(u"ࠨࡳࡸࡥࡳࡺࡩࡵࡻࠪẅ"):dJHDqiKf12TXlIzSLkGUuxg4MBs3A(u"ࠩ࠸࠴ࠬẆ")}
	data = AfCyLXU4p8uE6H39Z7D(data)
	IAW0sh6So3NpqM = WWrExJZS3Bj4anOAkpv7(K6imQHZDCI9pewE,qoBMmfAWpFlK70xw8ZRh4naJ(u"ࠪࡋࡊ࡚ࠧẇ"),url,data,headers,qpFY4hAwolV3,qpFY4hAwolV3,fWoVd0Bmtkx(u"ࠫࡗࡇࡎࡅࡑࡐࡗ࠲ࡘࡁࡏࡆࡒࡑࡤ࡜ࡉࡅࡇࡒࡗࡤࡌࡒࡐࡏࡢ࡛ࡔࡘࡄࡔ࠯࠴ࡷࡹ࠭Ẉ"))
	cmWl9dOKHPIy41iaXuxrY = IAW0sh6So3NpqM.content
	pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall(IaBhDMJc17302LgSvyxd(u"ࠬࡩ࡬ࡢࡵࡶࡁࠧࡩ࡯࡯ࡶࡨࡲࡹࠨࠨ࠯ࠬࡂ࠭ࡨࡲࡡࡴࡵࡀࠦࡨࡲࡥࡢࡴࡩ࡭ࡽࠨࠧẉ"),cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	mVYdjvor6i4wZ8 = pfRkcVlLmUxo561g0A8qSbO[vvXoMLlg513]
	items = ePhmG1jLD6.findall(V3VlkhgjEF4n1erPXHcC0NOsfwyAJ(u"࠭࠼ࡴࡲࡤࡲࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡹࡰࡢࡰࡁ࠲࠯ࡅ࠼ࡴࡲࡤࡲࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡹࡰࡢࡰࡁࠫẊ"),mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
	WzckNtSHeKARG0hOTnxZqbi5D3,xaKI2cnoLbuDO8gQFy5N0f34 = list(zip(*items))
	Gl7QWfo341i6BYpCMbsjvTm = []
	UXHPvYf7W1l9g = [mIsDke0oK5x1zSiOWbF9thGcA,ddiCzu6yahj5RtTISMJ48sNnZBU(u"ࠧࠣࠩẋ"),DiJ8CMuYH1daWyjehfN0L(u"ࠨࡢࠪẌ"),tQMjXKCA5dN4xq3beVIzaEoWkFLg(u"ࠩ࠯ࠫẍ"),lljaEqwTVtmKsQcOrbXxS5hgNH(u"ࠪ࠲ࠬẎ"),c2RKu0xG1eC8MiohyE(u"ࠫ࠿࠭ẏ"),ddiCzu6yahj5RtTISMJ48sNnZBU(u"ࠬࡁࠧẐ"),dJHDqiKf12TXlIzSLkGUuxg4MBs3A(u"ࠨࠧࠣẑ"),viRJWOC5jsYe84(u"ࠧ࠮ࠩẒ")]
	m6m9greVpvLt8QIP3alo7bs = xaKI2cnoLbuDO8gQFy5N0f34+WzckNtSHeKARG0hOTnxZqbi5D3
	for g6VusYjv27zkt3S80aLmb5 in m6m9greVpvLt8QIP3alo7bs:
		if g6VusYjv27zkt3S80aLmb5 in xaKI2cnoLbuDO8gQFy5N0f34: CHs5f83wnUGRaNc1YrmD9 = Zwqio2AIWlD5etFa
		if g6VusYjv27zkt3S80aLmb5 in WzckNtSHeKARG0hOTnxZqbi5D3: CHs5f83wnUGRaNc1YrmD9 = wn4bG51vUENfaS0Zg
		BUTQ4syLb3S = [a2jQ83ZCfcM5 in g6VusYjv27zkt3S80aLmb5 for a2jQ83ZCfcM5 in UXHPvYf7W1l9g]
		if any(BUTQ4syLb3S):
			P9gc0wx41l3y26iufIkWtaUGnMZ = BUTQ4syLb3S.index(gBExoceumj4y8bFW9hY2aNMVSr)
			kkdCNmZhyAwQ = UXHPvYf7W1l9g[P9gc0wx41l3y26iufIkWtaUGnMZ]
			zkmFBX6GeQMscnY = qpFY4hAwolV3
			if g6VusYjv27zkt3S80aLmb5.count(kkdCNmZhyAwQ)>mZi0S72jGoHpLO: ex1cHT34J7CrIf0UWOZ5KubX6h8v,gskH4mqpLAiB1wFNPtaYZG5yed,zkmFBX6GeQMscnY = g6VusYjv27zkt3S80aLmb5.split(kkdCNmZhyAwQ,Zwqio2AIWlD5etFa)
			else: ex1cHT34J7CrIf0UWOZ5KubX6h8v,gskH4mqpLAiB1wFNPtaYZG5yed = g6VusYjv27zkt3S80aLmb5.split(kkdCNmZhyAwQ,mZi0S72jGoHpLO)
			if len(ex1cHT34J7CrIf0UWOZ5KubX6h8v)>CHs5f83wnUGRaNc1YrmD9: Gl7QWfo341i6BYpCMbsjvTm.append(ex1cHT34J7CrIf0UWOZ5KubX6h8v.lower())
			if len(gskH4mqpLAiB1wFNPtaYZG5yed)>CHs5f83wnUGRaNc1YrmD9: Gl7QWfo341i6BYpCMbsjvTm.append(gskH4mqpLAiB1wFNPtaYZG5yed.lower())
			if len(zkmFBX6GeQMscnY)>CHs5f83wnUGRaNc1YrmD9: Gl7QWfo341i6BYpCMbsjvTm.append(zkmFBX6GeQMscnY.lower())
		elif len(g6VusYjv27zkt3S80aLmb5)>CHs5f83wnUGRaNc1YrmD9: Gl7QWfo341i6BYpCMbsjvTm.append(g6VusYjv27zkt3S80aLmb5.lower())
	for a2jQ83ZCfcM5 in range(sjtU6GZQg5XC2pH4(u"࠽ὡ")): P9Kfwdgna8erGcAWyQMOtFbq6Rk.shuffle(Gl7QWfo341i6BYpCMbsjvTm)
	if lljaEqwTVtmKsQcOrbXxS5hgNH(u"ࠨࡡࡖࡍ࡙ࡋࡓࡠࠩẓ") in ZZCk6FGHRa8:
		ZcKV7QRoJzeY = OOaSbLh4fmdBoy95V
	elif kYDaz79TFlXoR(u"ࠩࡢࡍࡕ࡚ࡖࡠࠩẔ") in ZZCk6FGHRa8:
		ZcKV7QRoJzeY = [kYDaz79TFlXoR(u"ࠪࡍࡕ࡚ࡖࠨẕ")]
		import kuHhyElsXe
		if not kuHhyElsXe.N4mtgDP83waX9(qpFY4hAwolV3,gBExoceumj4y8bFW9hY2aNMVSr): return
	elif qqzwE6imYG4c2xojI(u"ࠫࡤࡓ࠳ࡖࡡࠪẖ") in ZZCk6FGHRa8:
		ZcKV7QRoJzeY = [l1DZAt9XNQjqE7YOdrz(u"ࠬࡓ࠳ࡖࠩẗ")]
		import jV4SY0Trl2
		if not jV4SY0Trl2.N4mtgDP83waX9(qpFY4hAwolV3,gBExoceumj4y8bFW9hY2aNMVSr): return
	count,FX2L0GDWV3tnZaYPl = vvXoMLlg513,vvXoMLlg513
	x3WSXnKyPhjqfHG2UrtQs(sjtU6GZQg5XC2pH4(u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ẘ"),CC1eY6yWZUwf2TkRvnp7EJ0AimjHBX(u"ࠧ࡜ࠢࠣࡡࠥࡀวๅสะฯࠥ฿ๆࠨẙ"),qpFY4hAwolV3,tQMjXKCA5dN4xq3beVIzaEoWkFLg(u"࠶࠼࠴ὢ"),qpFY4hAwolV3,qpFY4hAwolV3,ee86G9ladLHVbh5mikzCo(u"ࠨࡡࡉࡓࡗࡍࡅࡕࡔࡈࡗ࡚ࡒࡔࡔࡡࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭ẚ")+ZZCk6FGHRa8)
	x3WSXnKyPhjqfHG2UrtQs(zYvEaigKWjoq50pXBLDbGJkFc(u"ࠩࡩࡳࡱࡪࡥࡳࠩẛ"),N3flV6EJsD5CzS(u"ࠪษ฾อฯสࠢส่อำหࠡษ็฽ู๎วว์ࠪẜ"),qpFY4hAwolV3,l1DZAt9XNQjqE7YOdrz(u"࠷࠶࠵ὣ"),qpFY4hAwolV3,qpFY4hAwolV3,ee86G9ladLHVbh5mikzCo(u"ࠫࡤࡌࡏࡓࡉࡈࡘࡗࡋࡓࡖࡎࡗࡗࡤࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩẝ")+ZZCk6FGHRa8)
	x3WSXnKyPhjqfHG2UrtQs(lljaEqwTVtmKsQcOrbXxS5hgNH(u"ࠬࡲࡩ࡯࡭ࠪẞ"),xupTj02bvy3O8R+qoBMmfAWpFlK70xw8ZRh4naJ(u"࠭࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࠫẟ")+fF4lt9zWYxXLKZVyAco82PgMj,qpFY4hAwolV3,V3VlkhgjEF4n1erPXHcC0NOsfwyAJ(u"࠹࠺࠻࠼ὤ"))
	tZUMHFkOE1AocgKw75iRd = i4bFG3rKE6.menuItemsLIST[:]
	i4bFG3rKE6.menuItemsLIST[:] = []
	VAh4vaP2LxG9m5DgTi = []
	for g6VusYjv27zkt3S80aLmb5 in Gl7QWfo341i6BYpCMbsjvTm:
		gskH4mqpLAiB1wFNPtaYZG5yed = ePhmG1jLD6.findall(kYDaz79TFlXoR(u"ࠧ࡜ࠢ࡟࠰ࡡࡁ࡜࠻࡞࠰ࡠ࠰ࡢ࠽࡝ࠤ࡟ࠫࡡࡡ࡜࡞࡞ࠫࡠ࠮ࡢࡻ࡝ࡿ࡟ࠥࡡࡆࠧẠ")+tR1krDGPpO025fghMT3a7UnYj(u"ࠨࠥࠪạ")+IaBhDMJc17302LgSvyxd(u"ࠩ࡟ࠨࡡࠫ࡜࡟࡞ࠩࡠ࠯ࡢ࡟࡝࠾࡟ࡂࡢ࠭Ả"),g6VusYjv27zkt3S80aLmb5,ePhmG1jLD6.DOTALL)
		if gskH4mqpLAiB1wFNPtaYZG5yed: g6VusYjv27zkt3S80aLmb5 = g6VusYjv27zkt3S80aLmb5.split(gskH4mqpLAiB1wFNPtaYZG5yed[vvXoMLlg513],mZi0S72jGoHpLO)[vvXoMLlg513]
		hStIoilcrVP6GadFxBW3vQsbOU9 = g6VusYjv27zkt3S80aLmb5.replace(DaFZHsThGmd0zv6e(u"ࠪ๕ࠬả"),qpFY4hAwolV3).replace(LZWMikPEB81KSGyxfJtUsCA(u"ࠫ๓࠭Ấ"),qpFY4hAwolV3).replace(UUDAiytEL76RTmMYsuIz5evXB(u"ࠬ๑ࠧấ"),qpFY4hAwolV3).replace(BRWqdruz2A0(u"࠭๏ࠨẦ"),qpFY4hAwolV3).replace(lljaEqwTVtmKsQcOrbXxS5hgNH(u"ࠧํࠩầ"),qpFY4hAwolV3)
		hStIoilcrVP6GadFxBW3vQsbOU9 = hStIoilcrVP6GadFxBW3vQsbOU9.replace(IaBhDMJc17302LgSvyxd(u"ࠨ๒ࠪẨ"),qpFY4hAwolV3).replace(LZWMikPEB81KSGyxfJtUsCA(u"ࠩ๐ࠫẩ"),qpFY4hAwolV3).replace(lljaEqwTVtmKsQcOrbXxS5hgNH(u"ࠪ๖ࠬẪ"),qpFY4hAwolV3).replace(IaBhDMJc17302LgSvyxd(u"ࠫฑ࠭ẫ"),qpFY4hAwolV3).replace(qoBMmfAWpFlK70xw8ZRh4naJ(u"ࠬๆࠧẬ"),qpFY4hAwolV3)
		if hStIoilcrVP6GadFxBW3vQsbOU9: VAh4vaP2LxG9m5DgTi.append(hStIoilcrVP6GadFxBW3vQsbOU9)
	dZ61x7tFuzCRJYgnQSUMpw2k0Xy = []
	for nnZ13Rr6tYXio0DyfLVvSxBec in range(vvXoMLlg513,l32dnTEOU1skGKqeBtI9hmo(u"࠳࠲ὥ")):
		search = P9Kfwdgna8erGcAWyQMOtFbq6Rk.sample(VAh4vaP2LxG9m5DgTi,mZi0S72jGoHpLO)[vvXoMLlg513]
		if search in dZ61x7tFuzCRJYgnQSUMpw2k0Xy: continue
		dZ61x7tFuzCRJYgnQSUMpw2k0Xy.append(search)
		j7HgbsXoUDfzcSkmniPu9w6 = P9Kfwdgna8erGcAWyQMOtFbq6Rk.sample(ZcKV7QRoJzeY,mZi0S72jGoHpLO)[vvXoMLlg513]
		LLvyStW429DEZKlA(k8kdUSxohLVljnrY,lTW9p1v7uPfOxB(Q8Q0IDc6PLZajJAdTntKUmSGXz)+YY8UDX3MJhb91AHw7fg(u"࠭ࠠࠡࠢࡕࡥࡳࡪ࡯࡮࡙ࠢ࡭ࡩ࡫࡯ࠡࡕࡨࡥࡷࡩࡨࠡࠢࠣࡷ࡮ࡺࡥ࠻ࠩậ")+str(j7HgbsXoUDfzcSkmniPu9w6)+qoBMmfAWpFlK70xw8ZRh4naJ(u"ࠧࠡࠢࡶࡩࡦࡸࡣࡩ࠼ࠪẮ")+search)
		qg4HsMCAcGWP7dZuv,bbieYx6KO2EHAmJj0G,TqMRtYCifVH46FuUgh = pPbuMH5hy6BSXzEaDGn(j7HgbsXoUDfzcSkmniPu9w6)
		bbieYx6KO2EHAmJj0G(search+UVa3fJw7k6KM(u"ࠨࡡࡑࡓࡉࡏࡁࡍࡑࡊࡗࡤ࠭ắ"))
		if len(i4bFG3rKE6.menuItemsLIST)>vvXoMLlg513: break
	search = search.replace(UUDAiytEL76RTmMYsuIz5evXB(u"ࠩࡢࡑࡔࡊ࡟ࠨẰ"),qpFY4hAwolV3)
	tZUMHFkOE1AocgKw75iRd[vvXoMLlg513][mZi0S72jGoHpLO] = iNc3KxwErnQ(u"ࠪ࡟ࠬằ")+xupTj02bvy3O8R+search+fF4lt9zWYxXLKZVyAco82PgMj+sjtU6GZQg5XC2pH4(u"ࠫࠥࡀศฮอࠣ฽๋ࡣࠧẲ")
	i4bFG3rKE6.menuItemsLIST[:] = oLZlMFBRHaeEtGkYN(i4bFG3rKE6.menuItemsLIST)
	if len(i4bFG3rKE6.menuItemsLIST)>a3Rx5WAGMmZs9wcKf0bklr47XUNSD: i4bFG3rKE6.menuItemsLIST[:] = P9Kfwdgna8erGcAWyQMOtFbq6Rk.sample(i4bFG3rKE6.menuItemsLIST,a3Rx5WAGMmZs9wcKf0bklr47XUNSD)
	i4bFG3rKE6.menuItemsLIST[:] = tZUMHFkOE1AocgKw75iRd+i4bFG3rKE6.menuItemsLIST
	return
def lgo31uFExNRL9TykZ7zq(FFMBG0mudkKNSnRxcHrCJjf74,ZZCk6FGHRa8):
	FFMBG0mudkKNSnRxcHrCJjf74 = FFMBG0mudkKNSnRxcHrCJjf74.replace(tR1krDGPpO025fghMT3a7UnYj(u"ࠬࡥࡍࡐࡆࡢࠫẳ"),qpFY4hAwolV3)
	ZZCk6FGHRa8 = ZZCk6FGHRa8.replace(ee86G9ladLHVbh5mikzCo(u"࠭࡟ࡇࡑࡕࡋࡊ࡚ࡒࡆࡕࡘࡐ࡙࡙࡟ࠨẴ"),qpFY4hAwolV3).replace(mmV2nucZ5Lpl6FO1JMPEqGoQKW(u"ࠧࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫẵ"),qpFY4hAwolV3)
	l1wzdrL86Vj3mYXnsUJD9(ag8rjZo1Vz4IPdcOT)
	if not myZKBn3kcqflCX1EOM69jUW: return
	if sjtU6GZQg5XC2pH4(u"ࠨࡡࡕࡅࡓࡊࡏࡎࡡࠪẶ") in ZZCk6FGHRa8:
		x3WSXnKyPhjqfHG2UrtQs(CC1eY6yWZUwf2TkRvnp7EJ0AimjHBX(u"ࠩࡩࡳࡱࡪࡥࡳࠩặ"),Ie5s2cBtSfdHjzQ4rA9kYlo6D18(u"ࠪ࡟ࠬẸ")+xupTj02bvy3O8R+FFMBG0mudkKNSnRxcHrCJjf74+fF4lt9zWYxXLKZVyAco82PgMj+BRWqdruz2A0(u"ࠫࠥࡀวๅไึ้ࡢ࠭ẹ"),FFMBG0mudkKNSnRxcHrCJjf74,qoBMmfAWpFlK70xw8ZRh4naJ(u"࠳࠹࠺ὦ"),qpFY4hAwolV3,qpFY4hAwolV3,Ie5s2cBtSfdHjzQ4rA9kYlo6D18(u"ࠬࡥࡆࡐࡔࡊࡉ࡙ࡘࡅࡔࡗࡏࡘࡘࡥ࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪẺ")+ZZCk6FGHRa8)
		x3WSXnKyPhjqfHG2UrtQs(YY8UDX3MJhb91AHw7fg(u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ẻ"),l32dnTEOU1skGKqeBtI9hmo(u"ࠧฦ฻สำฮࠦวๅู็ฬࠥอไฺึ๋หห๐ࠠๆ่๊ࠣๆูࠠศๆๅื๊࠭Ẽ"),FFMBG0mudkKNSnRxcHrCJjf74,YY8UDX3MJhb91AHw7fg(u"࠴࠺࠻ὧ"),qpFY4hAwolV3,qpFY4hAwolV3,viRJWOC5jsYe84(u"ࠨࡡࡉࡓࡗࡍࡅࡕࡔࡈࡗ࡚ࡒࡔࡔࡡࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭ẽ")+ZZCk6FGHRa8)
		x3WSXnKyPhjqfHG2UrtQs(sjtU6GZQg5XC2pH4(u"ࠩ࡯࡭ࡳࡱࠧẾ"),xupTj02bvy3O8R+fWoVd0Bmtkx(u"ࠪࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠࠨế")+fF4lt9zWYxXLKZVyAco82PgMj,qpFY4hAwolV3,BRWqdruz2A0(u"࠽࠾࠿࠹Ὠ"))
	for website in sorted(list(myZKBn3kcqflCX1EOM69jUW[FFMBG0mudkKNSnRxcHrCJjf74].keys())):
		lQnA93TCSoqKwIMJNz8L,mMgEh8S9xkCA5atcIP4GWOJlpDdKQ,url,vfhwRtW4Tsl1g28nk9dPFo5AKZE,BvbuigUeoJLnTaN2qWxQ415AtYMK9I,i02wfPp5EM,HY7yaJeI89xE56sbTjdBRZPDwQKFX,AArDKw6baWehCSOz7,uu5WqOEaRZIibszwTc6t1nmLfAj = myZKBn3kcqflCX1EOM69jUW[FFMBG0mudkKNSnRxcHrCJjf74][website]
		if IaBhDMJc17302LgSvyxd(u"ࠫࡤࡘࡁࡏࡆࡒࡑࡤ࠭Ề") in ZZCk6FGHRa8 or len(myZKBn3kcqflCX1EOM69jUW[FFMBG0mudkKNSnRxcHrCJjf74])==mZi0S72jGoHpLO:
			PLd4s0tr67GpoK(lQnA93TCSoqKwIMJNz8L,qpFY4hAwolV3,url,vfhwRtW4Tsl1g28nk9dPFo5AKZE,qpFY4hAwolV3,i02wfPp5EM,HY7yaJeI89xE56sbTjdBRZPDwQKFX,qpFY4hAwolV3,qpFY4hAwolV3)
			i4bFG3rKE6.menuItemsLIST[:] = oLZlMFBRHaeEtGkYN(i4bFG3rKE6.menuItemsLIST)
			CG2OMgKsb50WzVEkQtZarvcm1,SoixgtW3VRZj = i4bFG3rKE6.menuItemsLIST[:DAE6vkyhXGx1wBdHmcFfTVQpL0l],i4bFG3rKE6.menuItemsLIST[DAE6vkyhXGx1wBdHmcFfTVQpL0l:]
			if aXqWLoTdVgME(u"ࠬࡥࡒࡂࡐࡇࡓࡒࡥࠧề") in ZZCk6FGHRa8:
				for a2jQ83ZCfcM5 in range(ddiCzu6yahj5RtTISMJ48sNnZBU(u"࠾Ὡ")): P9Kfwdgna8erGcAWyQMOtFbq6Rk.shuffle(SoixgtW3VRZj)
				i4bFG3rKE6.menuItemsLIST[:] = CG2OMgKsb50WzVEkQtZarvcm1+SoixgtW3VRZj[:a3Rx5WAGMmZs9wcKf0bklr47XUNSD]
			else: i4bFG3rKE6.menuItemsLIST[:] = CG2OMgKsb50WzVEkQtZarvcm1+SoixgtW3VRZj
		elif viRJWOC5jsYe84(u"࠭࡟ࡔࡋࡗࡉࡘࡥࠧỂ") in ZZCk6FGHRa8: x3WSXnKyPhjqfHG2UrtQs(IaBhDMJc17302LgSvyxd(u"ࠧࡧࡱ࡯ࡨࡪࡸࠧể"),website,url,vfhwRtW4Tsl1g28nk9dPFo5AKZE,BvbuigUeoJLnTaN2qWxQ415AtYMK9I,i02wfPp5EM,HY7yaJeI89xE56sbTjdBRZPDwQKFX,AArDKw6baWehCSOz7,uu5WqOEaRZIibszwTc6t1nmLfAj)
	return
def KKRwGChAWfu3r5ljDa6X9(ZZCk6FGHRa8,ZyiMa3BXVk2xWG0b):
	ZZCk6FGHRa8 = ZZCk6FGHRa8.replace(aXqWLoTdVgME(u"ࠨࡡࡉࡓࡗࡍࡅࡕࡔࡈࡗ࡚ࡒࡔࡔࡡࠪỄ"),qpFY4hAwolV3).replace(UUDAiytEL76RTmMYsuIz5evXB(u"ࠩࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭ễ"),qpFY4hAwolV3)
	mMgEh8S9xkCA5atcIP4GWOJlpDdKQ,SoixgtW3VRZj = qpFY4hAwolV3,[]
	x3WSXnKyPhjqfHG2UrtQs(UUDAiytEL76RTmMYsuIz5evXB(u"ࠪࡪࡴࡲࡤࡦࡴࠪỆ"),IaBhDMJc17302LgSvyxd(u"ࠫࡠ࠭ệ")+xupTj02bvy3O8R+mMgEh8S9xkCA5atcIP4GWOJlpDdKQ+fF4lt9zWYxXLKZVyAco82PgMj+fWoVd0Bmtkx(u"ࠬࠦ࠺ศๆๅื๊ࡣࠧỈ"),qpFY4hAwolV3,ZyiMa3BXVk2xWG0b,qpFY4hAwolV3,qpFY4hAwolV3,DiJ8CMuYH1daWyjehfN0L(u"࠭࡟ࡇࡑࡕࡋࡊ࡚ࡒࡆࡕࡘࡐ࡙࡙࡟ࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫỉ")+ZZCk6FGHRa8)
	x3WSXnKyPhjqfHG2UrtQs(lljaEqwTVtmKsQcOrbXxS5hgNH(u"ࠧࡧࡱ࡯ࡨࡪࡸࠧỊ"),rNdBKI74fAklnoCZ6(u"ࠨว฼หิฯุࠠๆหࠤ็ูๅࠡ฻ื์ฬฬ๊ࠨị"),qpFY4hAwolV3,ZyiMa3BXVk2xWG0b,qpFY4hAwolV3,qpFY4hAwolV3,zYvEaigKWjoq50pXBLDbGJkFc(u"ࠩࡢࡊࡔࡘࡇࡆࡖࡕࡉࡘ࡛ࡌࡕࡕࡢࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧỌ")+ZZCk6FGHRa8)
	x3WSXnKyPhjqfHG2UrtQs(kYDaz79TFlXoR(u"ࠪࡰ࡮ࡴ࡫ࠨọ"),xupTj02bvy3O8R+fWoVd0Bmtkx(u"ࠫࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡࠩỎ")+fF4lt9zWYxXLKZVyAco82PgMj,qpFY4hAwolV3,aXqWLoTdVgME(u"࠿࠹࠺࠻Ὢ"))
	CG2OMgKsb50WzVEkQtZarvcm1 = i4bFG3rKE6.menuItemsLIST[:]
	i4bFG3rKE6.menuItemsLIST[:] = []
	MOTjA5H9XFs = []
	if lljaEqwTVtmKsQcOrbXxS5hgNH(u"ࠬࡥࡓࡊࡖࡈࡗࡤ࠭ỏ") in ZZCk6FGHRa8:
		l1wzdrL86Vj3mYXnsUJD9(ag8rjZo1Vz4IPdcOT)
		if not myZKBn3kcqflCX1EOM69jUW: return
		C1YT0NIQs49SFeXZgEaV3v = list(myZKBn3kcqflCX1EOM69jUW.keys())
		FFMBG0mudkKNSnRxcHrCJjf74 = P9Kfwdgna8erGcAWyQMOtFbq6Rk.sample(C1YT0NIQs49SFeXZgEaV3v,mZi0S72jGoHpLO)[vvXoMLlg513]
		Gl7QWfo341i6BYpCMbsjvTm = list(myZKBn3kcqflCX1EOM69jUW[FFMBG0mudkKNSnRxcHrCJjf74].keys())
		website = P9Kfwdgna8erGcAWyQMOtFbq6Rk.sample(Gl7QWfo341i6BYpCMbsjvTm,mZi0S72jGoHpLO)[vvXoMLlg513]
		lQnA93TCSoqKwIMJNz8L,mMgEh8S9xkCA5atcIP4GWOJlpDdKQ,url,vfhwRtW4Tsl1g28nk9dPFo5AKZE,BvbuigUeoJLnTaN2qWxQ415AtYMK9I,i02wfPp5EM,HY7yaJeI89xE56sbTjdBRZPDwQKFX,AArDKw6baWehCSOz7,uu5WqOEaRZIibszwTc6t1nmLfAj = myZKBn3kcqflCX1EOM69jUW[FFMBG0mudkKNSnRxcHrCJjf74][website]
		LLvyStW429DEZKlA(k8kdUSxohLVljnrY,lTW9p1v7uPfOxB(Q8Q0IDc6PLZajJAdTntKUmSGXz)+YY8UDX3MJhb91AHw7fg(u"࠭ࠠࠡࠢࡕࡥࡳࡪ࡯࡮ࠢࡆࡥࡹ࡫ࡧࡰࡴࡼࠤࠥࠦࡷࡦࡤࡶ࡭ࡹ࡫࠺ࠡࠩỐ")+website+IaBhDMJc17302LgSvyxd(u"ࠧࠡࠢࠣࡲࡦࡳࡥ࠻ࠢࠪố")+mMgEh8S9xkCA5atcIP4GWOJlpDdKQ+CC1eY6yWZUwf2TkRvnp7EJ0AimjHBX(u"ࠨࠢࠣࠤࡺࡸ࡬࠻ࠢࠪỒ")+url+aXqWLoTdVgME(u"ࠩࠣࠤࠥࡳ࡯ࡥࡧ࠽ࠤࠬồ")+str(vfhwRtW4Tsl1g28nk9dPFo5AKZE))
	elif l32dnTEOU1skGKqeBtI9hmo(u"ࠪࡣࡎࡖࡔࡗࡡࠪỔ") in ZZCk6FGHRa8:
		import kuHhyElsXe
		if not kuHhyElsXe.N4mtgDP83waX9(qpFY4hAwolV3,gBExoceumj4y8bFW9hY2aNMVSr): return
		for LLcgQ6E12OZezYbh4CVdIa in range(mZi0S72jGoHpLO,v2ir6R7FZASfMOl4wqTLKBNupX5E+mZi0S72jGoHpLO):
			MOTjA5H9XFs += bSynDjcN6L815tfkIOH9eJ4sxXqor(str(LLcgQ6E12OZezYbh4CVdIa),ZZCk6FGHRa8)
		if not MOTjA5H9XFs: return
		lQnA93TCSoqKwIMJNz8L,mMgEh8S9xkCA5atcIP4GWOJlpDdKQ,url,vfhwRtW4Tsl1g28nk9dPFo5AKZE,BvbuigUeoJLnTaN2qWxQ415AtYMK9I,i02wfPp5EM,HY7yaJeI89xE56sbTjdBRZPDwQKFX,AArDKw6baWehCSOz7,uu5WqOEaRZIibszwTc6t1nmLfAj = P9Kfwdgna8erGcAWyQMOtFbq6Rk.sample(MOTjA5H9XFs,mZi0S72jGoHpLO)[vvXoMLlg513]
		LLvyStW429DEZKlA(k8kdUSxohLVljnrY,lTW9p1v7uPfOxB(Q8Q0IDc6PLZajJAdTntKUmSGXz)+l1DZAt9XNQjqE7YOdrz(u"ࠫࠥࠦࠠࡓࡣࡱࡨࡴࡳࠠࡄࡣࡷࡩ࡬ࡵࡲࡺࠢࠣࠤࡳࡧ࡭ࡦ࠼ࠣࠫổ")+mMgEh8S9xkCA5atcIP4GWOJlpDdKQ+DiJ8CMuYH1daWyjehfN0L(u"ࠬࠦࠠࠡࡷࡵࡰ࠿ࠦࠧỖ")+url+tR1krDGPpO025fghMT3a7UnYj(u"࠭ࠠࠡࠢࡰࡳࡩ࡫࠺ࠡࠩỗ")+str(vfhwRtW4Tsl1g28nk9dPFo5AKZE))
	elif DaFZHsThGmd0zv6e(u"ࠧࡠࡏ࠶࡙ࡤ࠭Ộ") in ZZCk6FGHRa8:
		import jV4SY0Trl2
		if not jV4SY0Trl2.N4mtgDP83waX9(qpFY4hAwolV3,gBExoceumj4y8bFW9hY2aNMVSr): return
		for LLcgQ6E12OZezYbh4CVdIa in range(mZi0S72jGoHpLO,v2ir6R7FZASfMOl4wqTLKBNupX5E+mZi0S72jGoHpLO):
			MOTjA5H9XFs += lpi3gjNW6T0zR8MPuc(str(LLcgQ6E12OZezYbh4CVdIa),ZZCk6FGHRa8)
		if not MOTjA5H9XFs: return
		lQnA93TCSoqKwIMJNz8L,mMgEh8S9xkCA5atcIP4GWOJlpDdKQ,url,vfhwRtW4Tsl1g28nk9dPFo5AKZE,BvbuigUeoJLnTaN2qWxQ415AtYMK9I,i02wfPp5EM,HY7yaJeI89xE56sbTjdBRZPDwQKFX,AArDKw6baWehCSOz7,uu5WqOEaRZIibszwTc6t1nmLfAj = P9Kfwdgna8erGcAWyQMOtFbq6Rk.sample(MOTjA5H9XFs,mZi0S72jGoHpLO)[vvXoMLlg513]
		LLvyStW429DEZKlA(k8kdUSxohLVljnrY,lTW9p1v7uPfOxB(Q8Q0IDc6PLZajJAdTntKUmSGXz)+sjtU6GZQg5XC2pH4(u"ࠨࠢࠣࠤࡗࡧ࡮ࡥࡱࡰࠤࡈࡧࡴࡦࡩࡲࡶࡾࠦࠠࠡࡰࡤࡱࡪࡀࠠࠨộ")+mMgEh8S9xkCA5atcIP4GWOJlpDdKQ+ee86G9ladLHVbh5mikzCo(u"ࠩࠣࠤࠥࡻࡲ࡭࠼ࠣࠫỚ")+url+fWoVd0Bmtkx(u"ࠪࠤࠥࠦ࡭ࡰࡦࡨ࠾ࠥ࠭ớ")+str(vfhwRtW4Tsl1g28nk9dPFo5AKZE))
	jcnLQ23Ey6gBsaR4iW = mMgEh8S9xkCA5atcIP4GWOJlpDdKQ
	aSEQh0e6OFWxsr = []
	for a2jQ83ZCfcM5 in range(vvXoMLlg513,qoBMmfAWpFlK70xw8ZRh4naJ(u"࠱࠱Ὣ")):
		if a2jQ83ZCfcM5>vvXoMLlg513: LLvyStW429DEZKlA(k8kdUSxohLVljnrY,lTW9p1v7uPfOxB(Q8Q0IDc6PLZajJAdTntKUmSGXz)+lljaEqwTVtmKsQcOrbXxS5hgNH(u"ࠫࠥࠦࠠࡓࡣࡱࡨࡴࡳࠠࡄࡣࡷࡩ࡬ࡵࡲࡺࠢࠣࠤࡳࡧ࡭ࡦ࠼ࠣࠫỜ")+mMgEh8S9xkCA5atcIP4GWOJlpDdKQ+qqzwE6imYG4c2xojI(u"ࠬࠦࠠࠡࡷࡵࡰ࠿ࠦࠧờ")+url+lljaEqwTVtmKsQcOrbXxS5hgNH(u"࠭ࠠࠡࠢࡰࡳࡩ࡫࠺ࠡࠩỞ")+str(vfhwRtW4Tsl1g28nk9dPFo5AKZE))
		i4bFG3rKE6.menuItemsLIST[:] = []
		if vfhwRtW4Tsl1g28nk9dPFo5AKZE==c2RKu0xG1eC8MiohyE(u"࠳࠵࠷Ὤ") and rNdBKI74fAklnoCZ6(u"ࠧࡠࡡࡌࡔ࡙࡜ࡓࡦࡴ࡬ࡩࡸࡥ࡟ࠨở") in HY7yaJeI89xE56sbTjdBRZPDwQKFX: vfhwRtW4Tsl1g28nk9dPFo5AKZE = RlOvin8YIGC2KZXJPk9m0acrMobUex(u"࠴࠶࠷Ὥ")
		if vfhwRtW4Tsl1g28nk9dPFo5AKZE==c2RKu0xG1eC8MiohyE(u"࠺࠵࠹Ὦ") and ee86G9ladLHVbh5mikzCo(u"ࠨࡡࡢࡑ࠸࡛ࡓࡦࡴ࡬ࡩࡸࡥ࡟ࠨỠ") in HY7yaJeI89xE56sbTjdBRZPDwQKFX: vfhwRtW4Tsl1g28nk9dPFo5AKZE = fWoVd0Bmtkx(u"࠻࠶࠹Ὧ")
		if vfhwRtW4Tsl1g28nk9dPFo5AKZE==tR1krDGPpO025fghMT3a7UnYj(u"࠶࠺࠴ὰ"): vfhwRtW4Tsl1g28nk9dPFo5AKZE = YY8UDX3MJhb91AHw7fg(u"࠸࠹࠲ά")
		oF67yxKdB8nY3TiH9gAMvlOhaPSws0 = PLd4s0tr67GpoK(lQnA93TCSoqKwIMJNz8L,mMgEh8S9xkCA5atcIP4GWOJlpDdKQ,url,vfhwRtW4Tsl1g28nk9dPFo5AKZE,BvbuigUeoJLnTaN2qWxQ415AtYMK9I,i02wfPp5EM,HY7yaJeI89xE56sbTjdBRZPDwQKFX,AArDKw6baWehCSOz7,uu5WqOEaRZIibszwTc6t1nmLfAj)
		if aXqWLoTdVgME(u"ࠩࡢࡍࡕ࡚ࡖࡠࠩỡ") in ZZCk6FGHRa8 and vfhwRtW4Tsl1g28nk9dPFo5AKZE==tR1krDGPpO025fghMT3a7UnYj(u"࠱࠷࠹ὲ"): del i4bFG3rKE6.menuItemsLIST[:DAE6vkyhXGx1wBdHmcFfTVQpL0l]
		if LZWMikPEB81KSGyxfJtUsCA(u"ࠪࡣࡒ࠹ࡕࡠࠩỢ") in ZZCk6FGHRa8 and vfhwRtW4Tsl1g28nk9dPFo5AKZE==IaBhDMJc17302LgSvyxd(u"࠲࠸࠻έ"): del i4bFG3rKE6.menuItemsLIST[:DAE6vkyhXGx1wBdHmcFfTVQpL0l]
		SoixgtW3VRZj[:] = oLZlMFBRHaeEtGkYN(i4bFG3rKE6.menuItemsLIST)
		if aSEQh0e6OFWxsr and AACymb8gWpiZPTSjE5RxheqzHN(iNc3KxwErnQ(u"ࡹࠬำไใหࠪợ")) in str(SoixgtW3VRZj) or AACymb8gWpiZPTSjE5RxheqzHN(lljaEqwTVtmKsQcOrbXxS5hgNH(u"ࡺ࠭อๅไ๊ࠫỤ")) in str(SoixgtW3VRZj):
			mMgEh8S9xkCA5atcIP4GWOJlpDdKQ = jcnLQ23Ey6gBsaR4iW
			SoixgtW3VRZj[:] = aSEQh0e6OFWxsr
			break
		jcnLQ23Ey6gBsaR4iW = mMgEh8S9xkCA5atcIP4GWOJlpDdKQ
		aSEQh0e6OFWxsr = SoixgtW3VRZj
		if str(SoixgtW3VRZj).count(DiJ8CMuYH1daWyjehfN0L(u"࠭ࡶࡪࡦࡨࡳࠬụ"))>vvXoMLlg513: break
		if str(SoixgtW3VRZj).count(zYvEaigKWjoq50pXBLDbGJkFc(u"ࠧ࡭࡫ࡹࡩࠬỦ"))>vvXoMLlg513: break
		if vfhwRtW4Tsl1g28nk9dPFo5AKZE==LZWMikPEB81KSGyxfJtUsCA(u"࠴࠶࠷ὴ"): break
		if vfhwRtW4Tsl1g28nk9dPFo5AKZE==dJHDqiKf12TXlIzSLkGUuxg4MBs3A(u"࠺࠵࠸ή"): break
		if vfhwRtW4Tsl1g28nk9dPFo5AKZE==LZWMikPEB81KSGyxfJtUsCA(u"࠶࠾࠷ὶ"): break
		if l32dnTEOU1skGKqeBtI9hmo(u"ࠨࡡࡕࡅࡓࡊࡏࡎࡡࠪủ") in ZZCk6FGHRa8 and SoixgtW3VRZj: lQnA93TCSoqKwIMJNz8L,mMgEh8S9xkCA5atcIP4GWOJlpDdKQ,url,vfhwRtW4Tsl1g28nk9dPFo5AKZE,BvbuigUeoJLnTaN2qWxQ415AtYMK9I,i02wfPp5EM,HY7yaJeI89xE56sbTjdBRZPDwQKFX,AArDKw6baWehCSOz7,uu5WqOEaRZIibszwTc6t1nmLfAj = P9Kfwdgna8erGcAWyQMOtFbq6Rk.sample(SoixgtW3VRZj,mZi0S72jGoHpLO)[vvXoMLlg513]
	if not mMgEh8S9xkCA5atcIP4GWOJlpDdKQ: mMgEh8S9xkCA5atcIP4GWOJlpDdKQ = CC1eY6yWZUwf2TkRvnp7EJ0AimjHBX(u"ࠩ࠱࠲࠳࠴ࠧỨ")
	elif mMgEh8S9xkCA5atcIP4GWOJlpDdKQ.count(UUDAiytEL76RTmMYsuIz5evXB(u"ࠪࡣࠬứ"))>mZi0S72jGoHpLO: mMgEh8S9xkCA5atcIP4GWOJlpDdKQ = mMgEh8S9xkCA5atcIP4GWOJlpDdKQ.split(N3flV6EJsD5CzS(u"ࠫࡤ࠭Ừ"),Zwqio2AIWlD5etFa)[Zwqio2AIWlD5etFa]
	mMgEh8S9xkCA5atcIP4GWOJlpDdKQ = mMgEh8S9xkCA5atcIP4GWOJlpDdKQ.replace(CC1eY6yWZUwf2TkRvnp7EJ0AimjHBX(u"࡛ࠬࡎࡌࡐࡒ࡛ࡓࡀࠠࠨừ"),qpFY4hAwolV3)
	mMgEh8S9xkCA5atcIP4GWOJlpDdKQ = mMgEh8S9xkCA5atcIP4GWOJlpDdKQ.replace(lljaEqwTVtmKsQcOrbXxS5hgNH(u"࠭࡟ࡎࡑࡇࡣࠬỬ"),qpFY4hAwolV3)
	CG2OMgKsb50WzVEkQtZarvcm1[vvXoMLlg513][mZi0S72jGoHpLO] = tR1krDGPpO025fghMT3a7UnYj(u"ࠧ࡜ࠩử")+xupTj02bvy3O8R+mMgEh8S9xkCA5atcIP4GWOJlpDdKQ+fF4lt9zWYxXLKZVyAco82PgMj+mmV2nucZ5Lpl6FO1JMPEqGoQKW(u"ࠨࠢ࠽ห้่ำๆ࡟ࠪỮ")
	if Ie5s2cBtSfdHjzQ4rA9kYlo6D18(u"ࠩࡢࡖࡆࡔࡄࡐࡏࡢࠫữ") in ZZCk6FGHRa8:
		for a2jQ83ZCfcM5 in range(DaFZHsThGmd0zv6e(u"࠾ί")): P9Kfwdgna8erGcAWyQMOtFbq6Rk.shuffle(SoixgtW3VRZj)
		i4bFG3rKE6.menuItemsLIST[:] = CG2OMgKsb50WzVEkQtZarvcm1+SoixgtW3VRZj[:a3Rx5WAGMmZs9wcKf0bklr47XUNSD]
	else: i4bFG3rKE6.menuItemsLIST[:] = CG2OMgKsb50WzVEkQtZarvcm1+SoixgtW3VRZj
	return
def v2mnC8TQ95FJw(ZgvtNlsMUHFykQb8hBu,suL3Jrg9yfWmiaYpoQl1BR2Z7zUEKb):
	suL3Jrg9yfWmiaYpoQl1BR2Z7zUEKb = suL3Jrg9yfWmiaYpoQl1BR2Z7zUEKb.replace(N3flV6EJsD5CzS(u"ࠪࡣࡋࡕࡒࡈࡇࡗࡖࡊ࡙ࡕࡍࡖࡖࡣࠬỰ"),qpFY4hAwolV3).replace(UUDAiytEL76RTmMYsuIz5evXB(u"ࠫࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨự"),qpFY4hAwolV3)
	kC65dR1hq4mazAI9b2vF8sL = suL3Jrg9yfWmiaYpoQl1BR2Z7zUEKb
	if l32dnTEOU1skGKqeBtI9hmo(u"ࠬࡥ࡟ࡊࡒࡗ࡚ࡘ࡫ࡲࡪࡧࡶࡣࡤ࠭Ỳ") in suL3Jrg9yfWmiaYpoQl1BR2Z7zUEKb:
		kC65dR1hq4mazAI9b2vF8sL = suL3Jrg9yfWmiaYpoQl1BR2Z7zUEKb.split(DiJ8CMuYH1daWyjehfN0L(u"࠭࡟ࡠࡋࡓࡘ࡛࡙ࡥࡳ࡫ࡨࡷࡤࡥࠧỳ"))[vvXoMLlg513]
		type = N3flV6EJsD5CzS(u"ࠧ࠭ࡕࡈࡖࡎࡋࡓ࠻ࠢࠪỴ")
	elif l32dnTEOU1skGKqeBtI9hmo(u"ࠨࡘࡒࡈࠬỵ") in ZgvtNlsMUHFykQb8hBu: type = Ie5s2cBtSfdHjzQ4rA9kYlo6D18(u"ࠩ࠯࡚ࡎࡊࡅࡐࡕ࠽ࠤࠬỶ")
	elif kYDaz79TFlXoR(u"ࠪࡐࡎ࡜ࡅࠨỷ") in ZgvtNlsMUHFykQb8hBu: type = IaBhDMJc17302LgSvyxd(u"ࠫ࠱ࡒࡉࡗࡇ࠽ࠤࠬỸ")
	x3WSXnKyPhjqfHG2UrtQs(qoBMmfAWpFlK70xw8ZRh4naJ(u"ࠬ࡬࡯࡭ࡦࡨࡶࠬỹ"),CC1eY6yWZUwf2TkRvnp7EJ0AimjHBX(u"࡛࠭ࠨỺ")+xupTj02bvy3O8R+type+kC65dR1hq4mazAI9b2vF8sL+fF4lt9zWYxXLKZVyAco82PgMj+qoBMmfAWpFlK70xw8ZRh4naJ(u"ࠧࠡ࠼ส่็ูๅ࡞ࠩỻ"),ZgvtNlsMUHFykQb8hBu,UVa3fJw7k6KM(u"࠷࠶࠸ὸ"),qpFY4hAwolV3,qpFY4hAwolV3,kYDaz79TFlXoR(u"ࠨࡡࡉࡓࡗࡍࡅࡕࡔࡈࡗ࡚ࡒࡔࡔࡡࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭Ỽ")+suL3Jrg9yfWmiaYpoQl1BR2Z7zUEKb)
	x3WSXnKyPhjqfHG2UrtQs(sjtU6GZQg5XC2pH4(u"ࠩࡩࡳࡱࡪࡥࡳࠩỽ"),lljaEqwTVtmKsQcOrbXxS5hgNH(u"ࠪษ฾อฯสࠢส่฼๊ศࠡษ็฽ู๎วว์้๋ࠣࠦๆโีࠣห้่ำๆࠩỾ"),ZgvtNlsMUHFykQb8hBu,l32dnTEOU1skGKqeBtI9hmo(u"࠱࠷࠹ό"),qpFY4hAwolV3,qpFY4hAwolV3,YY8UDX3MJhb91AHw7fg(u"ࠫࡤࡌࡏࡓࡉࡈࡘࡗࡋࡓࡖࡎࡗࡗࡤࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩỿ")+suL3Jrg9yfWmiaYpoQl1BR2Z7zUEKb)
	x3WSXnKyPhjqfHG2UrtQs(viRJWOC5jsYe84(u"ࠬࡲࡩ࡯࡭ࠪἀ"),xupTj02bvy3O8R+rNdBKI74fAklnoCZ6(u"࠭࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࠫἁ")+fF4lt9zWYxXLKZVyAco82PgMj,qpFY4hAwolV3,tQMjXKCA5dN4xq3beVIzaEoWkFLg(u"࠺࠻࠼࠽ὺ"))
	import kuHhyElsXe
	for LLcgQ6E12OZezYbh4CVdIa in range(mZi0S72jGoHpLO,v2ir6R7FZASfMOl4wqTLKBNupX5E+mZi0S72jGoHpLO):
		if DaFZHsThGmd0zv6e(u"ࠧࡠࡡࡌࡔ࡙࡜ࡓࡦࡴ࡬ࡩࡸࡥ࡟ࠨἂ") in suL3Jrg9yfWmiaYpoQl1BR2Z7zUEKb: kuHhyElsXe.xxHg8EI03NwfKGpYtjrs7WDinR(str(LLcgQ6E12OZezYbh4CVdIa),ZgvtNlsMUHFykQb8hBu,suL3Jrg9yfWmiaYpoQl1BR2Z7zUEKb,qpFY4hAwolV3,ag8rjZo1Vz4IPdcOT)
		else: kuHhyElsXe.I19sHuzZ8RryYXSwgV7mQ3Dh(str(LLcgQ6E12OZezYbh4CVdIa),ZgvtNlsMUHFykQb8hBu,suL3Jrg9yfWmiaYpoQl1BR2Z7zUEKb,qpFY4hAwolV3,ag8rjZo1Vz4IPdcOT)
	i4bFG3rKE6.menuItemsLIST[:] = oLZlMFBRHaeEtGkYN(i4bFG3rKE6.menuItemsLIST)
	if len(i4bFG3rKE6.menuItemsLIST)>(a3Rx5WAGMmZs9wcKf0bklr47XUNSD+DAE6vkyhXGx1wBdHmcFfTVQpL0l): i4bFG3rKE6.menuItemsLIST[:] = i4bFG3rKE6.menuItemsLIST[:DAE6vkyhXGx1wBdHmcFfTVQpL0l]+P9Kfwdgna8erGcAWyQMOtFbq6Rk.sample(i4bFG3rKE6.menuItemsLIST[DAE6vkyhXGx1wBdHmcFfTVQpL0l:],a3Rx5WAGMmZs9wcKf0bklr47XUNSD)
	return
def ZGR7nk61buVNB4XFgsELMc5aTiJm(ZgvtNlsMUHFykQb8hBu,suL3Jrg9yfWmiaYpoQl1BR2Z7zUEKb):
	suL3Jrg9yfWmiaYpoQl1BR2Z7zUEKb = suL3Jrg9yfWmiaYpoQl1BR2Z7zUEKb.replace(viRJWOC5jsYe84(u"ࠨࡡࡉࡓࡗࡍࡅࡕࡔࡈࡗ࡚ࡒࡔࡔࡡࠪἃ"),qpFY4hAwolV3).replace(RlOvin8YIGC2KZXJPk9m0acrMobUex(u"ࠩࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭ἄ"),qpFY4hAwolV3)
	kC65dR1hq4mazAI9b2vF8sL = suL3Jrg9yfWmiaYpoQl1BR2Z7zUEKb
	if YY8UDX3MJhb91AHw7fg(u"ࠪࡣࡤࡓ࠳ࡖࡕࡨࡶ࡮࡫ࡳࡠࡡࠪἅ") in suL3Jrg9yfWmiaYpoQl1BR2Z7zUEKb:
		kC65dR1hq4mazAI9b2vF8sL = suL3Jrg9yfWmiaYpoQl1BR2Z7zUEKb.split(sjtU6GZQg5XC2pH4(u"ࠫࡤࡥࡍ࠴ࡗࡖࡩࡷ࡯ࡥࡴࡡࡢࠫἆ"))[vvXoMLlg513]
		type = sjtU6GZQg5XC2pH4(u"ࠬ࠲ࡓࡆࡔࡌࡉࡘࡀࠠࠨἇ")
	elif tR1krDGPpO025fghMT3a7UnYj(u"࠭ࡖࡐࡆࠪἈ") in ZgvtNlsMUHFykQb8hBu: type = fWoVd0Bmtkx(u"ࠧ࠭ࡘࡌࡈࡊࡕࡓ࠻ࠢࠪἉ")
	elif V3VlkhgjEF4n1erPXHcC0NOsfwyAJ(u"ࠨࡎࡌ࡚ࡊ࠭Ἂ") in ZgvtNlsMUHFykQb8hBu: type = V3VlkhgjEF4n1erPXHcC0NOsfwyAJ(u"ࠩ࠯ࡐࡎ࡜ࡅ࠻ࠢࠪἋ")
	x3WSXnKyPhjqfHG2UrtQs(V3VlkhgjEF4n1erPXHcC0NOsfwyAJ(u"ࠪࡪࡴࡲࡤࡦࡴࠪἌ"),qoBMmfAWpFlK70xw8ZRh4naJ(u"ࠫࡠ࠭Ἅ")+xupTj02bvy3O8R+type+kC65dR1hq4mazAI9b2vF8sL+fF4lt9zWYxXLKZVyAco82PgMj+DiJ8CMuYH1daWyjehfN0L(u"ࠬࠦ࠺ศๆๅื๊ࡣࠧἎ"),ZgvtNlsMUHFykQb8hBu,UUDAiytEL76RTmMYsuIz5evXB(u"࠳࠹࠼ύ"),qpFY4hAwolV3,qpFY4hAwolV3,iNc3KxwErnQ(u"࠭࡟ࡇࡑࡕࡋࡊ࡚ࡒࡆࡕࡘࡐ࡙࡙࡟ࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫἏ")+suL3Jrg9yfWmiaYpoQl1BR2Z7zUEKb)
	x3WSXnKyPhjqfHG2UrtQs(zYvEaigKWjoq50pXBLDbGJkFc(u"ࠧࡧࡱ࡯ࡨࡪࡸࠧἐ"),tR1krDGPpO025fghMT3a7UnYj(u"ࠨว฼หิฯࠠศๆฺ่อࠦวๅ฻ื์ฬฬ๊ࠡ็้ࠤ๋็ำࠡษ็ๆุ๋ࠧἑ"),ZgvtNlsMUHFykQb8hBu,ee86G9ladLHVbh5mikzCo(u"࠴࠺࠽ὼ"),qpFY4hAwolV3,qpFY4hAwolV3,tR1krDGPpO025fghMT3a7UnYj(u"ࠩࡢࡊࡔࡘࡇࡆࡖࡕࡉࡘ࡛ࡌࡕࡕࡢࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧἒ")+suL3Jrg9yfWmiaYpoQl1BR2Z7zUEKb)
	x3WSXnKyPhjqfHG2UrtQs(V3VlkhgjEF4n1erPXHcC0NOsfwyAJ(u"ࠪࡰ࡮ࡴ࡫ࠨἓ"),xupTj02bvy3O8R+dJHDqiKf12TXlIzSLkGUuxg4MBs3A(u"ࠫࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡࠩἔ")+fF4lt9zWYxXLKZVyAco82PgMj,qpFY4hAwolV3,iNc3KxwErnQ(u"࠽࠾࠿࠹ώ"))
	import jV4SY0Trl2
	for LLcgQ6E12OZezYbh4CVdIa in range(mZi0S72jGoHpLO,v2ir6R7FZASfMOl4wqTLKBNupX5E+mZi0S72jGoHpLO):
		if dJHDqiKf12TXlIzSLkGUuxg4MBs3A(u"ࠬࡥ࡟ࡎ࠵ࡘࡗࡪࡸࡩࡦࡵࡢࡣࠬἕ") in suL3Jrg9yfWmiaYpoQl1BR2Z7zUEKb: jV4SY0Trl2.xxHg8EI03NwfKGpYtjrs7WDinR(str(LLcgQ6E12OZezYbh4CVdIa),ZgvtNlsMUHFykQb8hBu,suL3Jrg9yfWmiaYpoQl1BR2Z7zUEKb,qpFY4hAwolV3,ag8rjZo1Vz4IPdcOT)
		else: jV4SY0Trl2.I19sHuzZ8RryYXSwgV7mQ3Dh(str(LLcgQ6E12OZezYbh4CVdIa),ZgvtNlsMUHFykQb8hBu,suL3Jrg9yfWmiaYpoQl1BR2Z7zUEKb,qpFY4hAwolV3,ag8rjZo1Vz4IPdcOT)
	i4bFG3rKE6.menuItemsLIST[:] = oLZlMFBRHaeEtGkYN(i4bFG3rKE6.menuItemsLIST)
	if len(i4bFG3rKE6.menuItemsLIST)>(a3Rx5WAGMmZs9wcKf0bklr47XUNSD+DAE6vkyhXGx1wBdHmcFfTVQpL0l): i4bFG3rKE6.menuItemsLIST[:] = i4bFG3rKE6.menuItemsLIST[:DAE6vkyhXGx1wBdHmcFfTVQpL0l]+P9Kfwdgna8erGcAWyQMOtFbq6Rk.sample(i4bFG3rKE6.menuItemsLIST[DAE6vkyhXGx1wBdHmcFfTVQpL0l:],a3Rx5WAGMmZs9wcKf0bklr47XUNSD)
	return
def oLZlMFBRHaeEtGkYN(GnwyN9C8KbfFcQxpgL6itZDAHqeT):
	igoDdqarYE1pC = []
	for type,mMgEh8S9xkCA5atcIP4GWOJlpDdKQ,url,ZyiMa3BXVk2xWG0b,BvbuigUeoJLnTaN2qWxQ415AtYMK9I,i02wfPp5EM,HY7yaJeI89xE56sbTjdBRZPDwQKFX,AArDKw6baWehCSOz7,uu5WqOEaRZIibszwTc6t1nmLfAj in GnwyN9C8KbfFcQxpgL6itZDAHqeT:
		if rNdBKI74fAklnoCZ6(u"࠭ีโฯฬࠫ἖") in mMgEh8S9xkCA5atcIP4GWOJlpDdKQ or sjtU6GZQg5XC2pH4(u"ࠧึใะ๋ࠬ἗") in mMgEh8S9xkCA5atcIP4GWOJlpDdKQ or dJHDqiKf12TXlIzSLkGUuxg4MBs3A(u"ࠨࡲࡤ࡫ࡪ࠭Ἐ") in mMgEh8S9xkCA5atcIP4GWOJlpDdKQ.lower(): continue
		igoDdqarYE1pC.append([type,mMgEh8S9xkCA5atcIP4GWOJlpDdKQ,url,ZyiMa3BXVk2xWG0b,BvbuigUeoJLnTaN2qWxQ415AtYMK9I,i02wfPp5EM,HY7yaJeI89xE56sbTjdBRZPDwQKFX,AArDKw6baWehCSOz7,uu5WqOEaRZIibszwTc6t1nmLfAj])
	return igoDdqarYE1pC