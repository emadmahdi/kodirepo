# -*- coding: utf-8 -*-
from pSfaryIjBo import *
Q8Q0IDc6PLZajJAdTntKUmSGXz = 'TVFUN'
wwSFijdVJn1QgHW = '_TVF_'
ddBxj51bhNtaK23lDyGMVw = i4bFG3rKE6.SITESURLS[Q8Q0IDc6PLZajJAdTntKUmSGXz][0]
YEIA19ehBwpNfPVzK = ['بث مباشر']
def vTNE2Ck1sGnugJYW8y39aLcSH64U(mode,url,text):
	if   mode==460: MOTjA5H9XFs = nRVAZc4Dp8PSrGU3xBk()
	elif mode==461: MOTjA5H9XFs = c8U1BdtxOZS5FH(url,text)
	elif mode==462: MOTjA5H9XFs = mzcAeyplZV(url)
	elif mode==463: MOTjA5H9XFs = v1gmfxDcRrWKQ(url)
	elif mode==469: MOTjA5H9XFs = PPqUACSE3VcGLTvw05jHy9JrFNW(text)
	else: MOTjA5H9XFs = False
	return MOTjA5H9XFs
def nRVAZc4Dp8PSrGU3xBk():
	IAW0sh6So3NpqM = WWrExJZS3Bj4anOAkpv7(kUz8c7OqsxuPFIGfwg,'GET',ddBxj51bhNtaK23lDyGMVw,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,'TVFUN-MENU-1st')
	cmWl9dOKHPIy41iaXuxrY = IAW0sh6So3NpqM.content
	x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+'بحث في الموقع',qpFY4hAwolV3,469,qpFY4hAwolV3,qpFY4hAwolV3,'_REMEMBERRESULTS_')
	x3WSXnKyPhjqfHG2UrtQs('link',xupTj02bvy3O8R+' ===== ===== ===== '+fF4lt9zWYxXLKZVyAco82PgMj,qpFY4hAwolV3,9999)
	pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('"menu-btn"(.*?)</ul>',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	if pfRkcVlLmUxo561g0A8qSbO:
		mVYdjvor6i4wZ8 = pfRkcVlLmUxo561g0A8qSbO[0]
		items = ePhmG1jLD6.findall('href="(.*?)".*?<span>(.*?)</span>',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
		for MepIvHBYNArkUOdV37shtJ,title in items:
			if 'http' not in MepIvHBYNArkUOdV37shtJ: MepIvHBYNArkUOdV37shtJ = ddBxj51bhNtaK23lDyGMVw+MepIvHBYNArkUOdV37shtJ
			if title=='الرئيسية': title = 'جديد حلقات تيفي فان'
			if title in YEIA19ehBwpNfPVzK: continue
			x3WSXnKyPhjqfHG2UrtQs('folder',Q8Q0IDc6PLZajJAdTntKUmSGXz+'_SCRIPT_'+wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,461)
	return
def c8U1BdtxOZS5FH(url,emb0iauxpw6ZAKNyoLHfc1qRnB9UME=qpFY4hAwolV3):
	items = []
	IAW0sh6So3NpqM = WWrExJZS3Bj4anOAkpv7(kUz8c7OqsxuPFIGfwg,'GET',url,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,'TVFUN-TITLES-1st')
	cmWl9dOKHPIy41iaXuxrY = IAW0sh6So3NpqM.content
	pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('class="head-title"(.*?)id="footer"',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	if pfRkcVlLmUxo561g0A8qSbO:
		mVYdjvor6i4wZ8 = pfRkcVlLmUxo561g0A8qSbO[0]
		items = ePhmG1jLD6.findall('class="thumb.*?href="(.*?)".*?src="(.*?)" alt="(.*?)"',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
		aaCNAJdtsguSRELh2I = []
		WGid3I2kFU = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم']
		for MepIvHBYNArkUOdV37shtJ,Sj7rMNYRuQPTtkBvpHKeDW3h,title in items:
			title = '_MOD_'+title.replace('<br>',mIsDke0oK5x1zSiOWbF9thGcA).replace(r1roOXYi7UQw9FLThzPEdD0ZlvAnRc,mIsDke0oK5x1zSiOWbF9thGcA).strip(mIsDke0oK5x1zSiOWbF9thGcA)
			if 'http' not in MepIvHBYNArkUOdV37shtJ: MepIvHBYNArkUOdV37shtJ = ddBxj51bhNtaK23lDyGMVw+MepIvHBYNArkUOdV37shtJ
			MepIvHBYNArkUOdV37shtJ = cTt4u6reEMKZqVLplmkNW7(MepIvHBYNArkUOdV37shtJ)
			ZDTxRSMbW7PNz = ePhmG1jLD6.findall('(.*?) الحلقة \d+',title,ePhmG1jLD6.DOTALL)
			if any(value in title for value in WGid3I2kFU):
				x3WSXnKyPhjqfHG2UrtQs('video',wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,462,Sj7rMNYRuQPTtkBvpHKeDW3h)
			elif ZDTxRSMbW7PNz and 'الحلقة' in title:
				title = '_MOD_' + ZDTxRSMbW7PNz[0]
				if title not in aaCNAJdtsguSRELh2I:
					x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,463,Sj7rMNYRuQPTtkBvpHKeDW3h)
					aaCNAJdtsguSRELh2I.append(title)
			else: x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,463,Sj7rMNYRuQPTtkBvpHKeDW3h)
	if emb0iauxpw6ZAKNyoLHfc1qRnB9UME!='latest':
		pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('"pagination"(.*?)</ul>',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
		if pfRkcVlLmUxo561g0A8qSbO:
			mVYdjvor6i4wZ8 = pfRkcVlLmUxo561g0A8qSbO[0]
			items = ePhmG1jLD6.findall('<a href="(.*?)".*?>(.*?)<',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
			for MepIvHBYNArkUOdV37shtJ,title in items:
				MepIvHBYNArkUOdV37shtJ = MepIvHBYNArkUOdV37shtJ.strip(mIsDke0oK5x1zSiOWbF9thGcA)
				if MepIvHBYNArkUOdV37shtJ=="": continue
				if 'http' not in MepIvHBYNArkUOdV37shtJ: MepIvHBYNArkUOdV37shtJ = ddBxj51bhNtaK23lDyGMVw+MepIvHBYNArkUOdV37shtJ
				if title!=qpFY4hAwolV3: x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+'صفحة '+title,MepIvHBYNArkUOdV37shtJ,461)
	return
def v1gmfxDcRrWKQ(url):
	IAW0sh6So3NpqM = WWrExJZS3Bj4anOAkpv7(kUz8c7OqsxuPFIGfwg,'GET',url,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,'TVFUN-EPISODES-1st')
	cmWl9dOKHPIy41iaXuxrY = IAW0sh6So3NpqM.content
	pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('class="head-title"(.*?)id="footer"',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	if pfRkcVlLmUxo561g0A8qSbO:
		mVYdjvor6i4wZ8 = pfRkcVlLmUxo561g0A8qSbO[0]
		items = ePhmG1jLD6.findall('class="thumb.*?href="(.*?)".*?src="(.*?)" alt="(.*?)"',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
		if items:
			for MepIvHBYNArkUOdV37shtJ,Sj7rMNYRuQPTtkBvpHKeDW3h,title in items:
				title = '_MOD_'+title.replace('<br>',mIsDke0oK5x1zSiOWbF9thGcA).replace(r1roOXYi7UQw9FLThzPEdD0ZlvAnRc,mIsDke0oK5x1zSiOWbF9thGcA).strip(mIsDke0oK5x1zSiOWbF9thGcA)
				if 'http' not in MepIvHBYNArkUOdV37shtJ: MepIvHBYNArkUOdV37shtJ = ddBxj51bhNtaK23lDyGMVw+MepIvHBYNArkUOdV37shtJ
				x3WSXnKyPhjqfHG2UrtQs('video',wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,462,Sj7rMNYRuQPTtkBvpHKeDW3h)
		else:
			items = ePhmG1jLD6.findall('class="episode.*?href="(.*?)" title="(.*?)"',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
			for MepIvHBYNArkUOdV37shtJ,title in items:
				if 'http' not in MepIvHBYNArkUOdV37shtJ: MepIvHBYNArkUOdV37shtJ = ddBxj51bhNtaK23lDyGMVw+MepIvHBYNArkUOdV37shtJ
				x3WSXnKyPhjqfHG2UrtQs('video',wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,462)
	pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('"pagination"(.*?)</ul>',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	if pfRkcVlLmUxo561g0A8qSbO:
		mVYdjvor6i4wZ8 = pfRkcVlLmUxo561g0A8qSbO[0]
		items = ePhmG1jLD6.findall('href="(.*?)".*?>(.*?)<',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
		for MepIvHBYNArkUOdV37shtJ,title in items:
			MepIvHBYNArkUOdV37shtJ = MepIvHBYNArkUOdV37shtJ.strip(mIsDke0oK5x1zSiOWbF9thGcA)
			if MepIvHBYNArkUOdV37shtJ=="": continue
			if 'http' not in MepIvHBYNArkUOdV37shtJ: MepIvHBYNArkUOdV37shtJ = ddBxj51bhNtaK23lDyGMVw+MepIvHBYNArkUOdV37shtJ
			if title!=qpFY4hAwolV3: x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+'صفحة '+title,MepIvHBYNArkUOdV37shtJ,463)
	return
def mzcAeyplZV(url):
	U7V0BQZPxXqMbyJnRw6f = []
	WSQlG8mDhqsNe = url.replace('/video/','/watch/')
	IAW0sh6So3NpqM = WWrExJZS3Bj4anOAkpv7(kUz8c7OqsxuPFIGfwg,'GET',WSQlG8mDhqsNe,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,'TVFUN-PLAY-2nd')
	cmWl9dOKHPIy41iaXuxrY = IAW0sh6So3NpqM.content
	pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('VideoServers"(.*?)</div>',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	if pfRkcVlLmUxo561g0A8qSbO:
		mVYdjvor6i4wZ8 = pfRkcVlLmUxo561g0A8qSbO[0]
		CFevtSjzbpn = ePhmG1jLD6.findall('''setVideo\('(.*?)'\).*?">(.*?)<''',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
		for KwQDBERWd0aVTbfO,name in CFevtSjzbpn:
			KwQDBERWd0aVTbfO = KwQDBERWd0aVTbfO[2:]
			if NJwViHDTMdmO0xnALqQ9voPalC3Ip: KwQDBERWd0aVTbfO = KwQDBERWd0aVTbfO.decode(nV3Tip6XsH1rJw79DPOU)
			KwQDBERWd0aVTbfO = PP0Gxazjw86.b64decode(KwQDBERWd0aVTbfO)
			if DLod2Of8CkRrtzJynev: KwQDBERWd0aVTbfO = KwQDBERWd0aVTbfO.decode(nV3Tip6XsH1rJw79DPOU)
			MepIvHBYNArkUOdV37shtJ = ePhmG1jLD6.findall('src="(.*?)"',KwQDBERWd0aVTbfO,ePhmG1jLD6.DOTALL)
			MepIvHBYNArkUOdV37shtJ = MepIvHBYNArkUOdV37shtJ[0]
			if 'http' not in MepIvHBYNArkUOdV37shtJ:
				if ttrDbyV5cSO2FjgTzew6qM in MepIvHBYNArkUOdV37shtJ: MepIvHBYNArkUOdV37shtJ = 'http:'+MepIvHBYNArkUOdV37shtJ
				else: MepIvHBYNArkUOdV37shtJ = ddBxj51bhNtaK23lDyGMVw+MepIvHBYNArkUOdV37shtJ
			if MepIvHBYNArkUOdV37shtJ not in U7V0BQZPxXqMbyJnRw6f:
				MepIvHBYNArkUOdV37shtJ = MepIvHBYNArkUOdV37shtJ+'?named='+name+'__watch'
				U7V0BQZPxXqMbyJnRw6f.append(MepIvHBYNArkUOdV37shtJ)
	import inVXFK46ET
	inVXFK46ET.q4qTJvuoQUzM3mZAtegy7IXdnb5wH(U7V0BQZPxXqMbyJnRw6f,Q8Q0IDc6PLZajJAdTntKUmSGXz,'video',url)
	return
def PPqUACSE3VcGLTvw05jHy9JrFNW(search):
	search,LBylNhMdH6OV1qGk0tWiXFg3,showDialogs = LLm3sBXHPcnTDxdE5gt6hz0Wkp(search)
	if not search:
		search = jXgARlWMLVFUBnvmZwI2o5()
		if not search: return
	if mIsDke0oK5x1zSiOWbF9thGcA in search:
		if showDialogs: iG7Rz2kmn0x1yLNMV3u8O(qpFY4hAwolV3,qpFY4hAwolV3,'TVFUN موقع تيفي فان','للأسف البحث في هذا الموقع لا يعمل عند طلب أكثر من كلمة واحدة ... يرجى البحث عن كلمة واحدة فقط')
		return
	url = ddBxj51bhNtaK23lDyGMVw+'/q/'+search+ShynO8pN9idCE3
	c8U1BdtxOZS5FH(url)
	return