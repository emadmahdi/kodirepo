# -*- coding: utf-8 -*-
from pSfaryIjBo import *
Q8Q0IDc6PLZajJAdTntKUmSGXz = 'SHIAVOICE'
wwSFijdVJn1QgHW = '_SHV_'
ddBxj51bhNtaK23lDyGMVw = i4bFG3rKE6.SITESURLS[Q8Q0IDc6PLZajJAdTntKUmSGXz][0]
headers = {'User-Agent':None}
def vTNE2Ck1sGnugJYW8y39aLcSH64U(mode,url,text):
	if   mode==310: MOTjA5H9XFs = nRVAZc4Dp8PSrGU3xBk()
	elif mode==311: MOTjA5H9XFs = c8U1BdtxOZS5FH(url)
	elif mode==312: MOTjA5H9XFs = mzcAeyplZV(url)
	elif mode==313: MOTjA5H9XFs = Q9QkZcTtYUreInafdgoXWqNi(url)
	elif mode==314: MOTjA5H9XFs = wwmvODMWlVSc(text)
	elif mode==319: MOTjA5H9XFs = PPqUACSE3VcGLTvw05jHy9JrFNW(text)
	else: MOTjA5H9XFs = False
	return MOTjA5H9XFs
def nRVAZc4Dp8PSrGU3xBk():
	x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+'بحث في الموقع',qpFY4hAwolV3,319,qpFY4hAwolV3,qpFY4hAwolV3,'_REMEMBERRESULTS_')
	IAW0sh6So3NpqM = WWrExJZS3Bj4anOAkpv7(KOyPvpEztYLaZRdMQJWxfTNFHbkg,'GET',ddBxj51bhNtaK23lDyGMVw,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,'SHIAVOICE-MENU-1st')
	cmWl9dOKHPIy41iaXuxrY = IAW0sh6So3NpqM.content
	pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('id="menulinks"(.*?)</ul>',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	mVYdjvor6i4wZ8 = pfRkcVlLmUxo561g0A8qSbO[0]
	x3WSXnKyPhjqfHG2UrtQs('link',xupTj02bvy3O8R+' ===== ===== ===== '+fF4lt9zWYxXLKZVyAco82PgMj,qpFY4hAwolV3,9999)
	items = ePhmG1jLD6.findall('<h5>(.*?)</h5>',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL|ePhmG1jLD6.IGNORECASE)
	for P71nY8vWLi4xBOr9tZVNRQzJUbSG6 in range(len(items)):
		title = items[P71nY8vWLi4xBOr9tZVNRQzJUbSG6].strip(mIsDke0oK5x1zSiOWbF9thGcA)
		x3WSXnKyPhjqfHG2UrtQs('folder',Q8Q0IDc6PLZajJAdTntKUmSGXz+'_SCRIPT_'+wwSFijdVJn1QgHW+title,ddBxj51bhNtaK23lDyGMVw,314,qpFY4hAwolV3,qpFY4hAwolV3,str(P71nY8vWLi4xBOr9tZVNRQzJUbSG6+1))
	x3WSXnKyPhjqfHG2UrtQs('folder',Q8Q0IDc6PLZajJAdTntKUmSGXz+'_SCRIPT_'+wwSFijdVJn1QgHW+'مقاطع شهر',ddBxj51bhNtaK23lDyGMVw,314,qpFY4hAwolV3,qpFY4hAwolV3,'0')
	x3WSXnKyPhjqfHG2UrtQs('link',xupTj02bvy3O8R+' ===== ===== ===== '+fF4lt9zWYxXLKZVyAco82PgMj,qpFY4hAwolV3,9999)
	items = ePhmG1jLD6.findall('href="(.*?)".*?<B>(.*?)</B>',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
	for MepIvHBYNArkUOdV37shtJ,title in items:
		MepIvHBYNArkUOdV37shtJ = ddBxj51bhNtaK23lDyGMVw+ShynO8pN9idCE3+MepIvHBYNArkUOdV37shtJ
		x3WSXnKyPhjqfHG2UrtQs('folder',Q8Q0IDc6PLZajJAdTntKUmSGXz+'_SCRIPT_'+wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,311)
	return cmWl9dOKHPIy41iaXuxrY
def wwmvODMWlVSc(P71nY8vWLi4xBOr9tZVNRQzJUbSG6):
	IAW0sh6So3NpqM = WWrExJZS3Bj4anOAkpv7(rGY36xBwT1bLZAngSfcWEIeXdQVNij,'GET',ddBxj51bhNtaK23lDyGMVw,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,'SHIAVOICE-LATEST-1st')
	cmWl9dOKHPIy41iaXuxrY = IAW0sh6So3NpqM.content
	if P71nY8vWLi4xBOr9tZVNRQzJUbSG6=='0':
		pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('class="tab-content"(.*?)</table>',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
		mVYdjvor6i4wZ8 = pfRkcVlLmUxo561g0A8qSbO[0]
		items = ePhmG1jLD6.findall('href="(.*?)".*?title="(.*?)".*?</i>(.*?)<',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
		for MepIvHBYNArkUOdV37shtJ,name,title in items:
			MepIvHBYNArkUOdV37shtJ = ddBxj51bhNtaK23lDyGMVw+ShynO8pN9idCE3+MepIvHBYNArkUOdV37shtJ
			title = title.strip(mIsDke0oK5x1zSiOWbF9thGcA)
			name = name.strip(mIsDke0oK5x1zSiOWbF9thGcA)
			title = title+' ('+name+')'
			x3WSXnKyPhjqfHG2UrtQs('video',wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,312)
	elif P71nY8vWLi4xBOr9tZVNRQzJUbSG6 in ['1','2','3']:
		pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('(<h5>.*?)<div class="col-lg',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
		WyD7kHsowIun2PmelUtaGAxb = int(P71nY8vWLi4xBOr9tZVNRQzJUbSG6)-1
		mVYdjvor6i4wZ8 = pfRkcVlLmUxo561g0A8qSbO[WyD7kHsowIun2PmelUtaGAxb]
		if P71nY8vWLi4xBOr9tZVNRQzJUbSG6=='1': items = ePhmG1jLD6.findall('href="(.*?)".*?src="(.*?)".*?<strong>(.*?)<.*?</i>(.*?)<',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
		else: items = ePhmG1jLD6.findall('href="(.*?)".*?src="(.*?)".*?<strong>(.*?)<.*?href=".*?">(.*?)<',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
		for MepIvHBYNArkUOdV37shtJ,Sj7rMNYRuQPTtkBvpHKeDW3h,title,name in items:
			Sj7rMNYRuQPTtkBvpHKeDW3h = ddBxj51bhNtaK23lDyGMVw+ShynO8pN9idCE3+Sj7rMNYRuQPTtkBvpHKeDW3h
			MepIvHBYNArkUOdV37shtJ = ddBxj51bhNtaK23lDyGMVw+ShynO8pN9idCE3+MepIvHBYNArkUOdV37shtJ
			title = title.strip(mIsDke0oK5x1zSiOWbF9thGcA)
			name = name.strip(mIsDke0oK5x1zSiOWbF9thGcA)
			title = title+' ('+name+')'
			x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,311,Sj7rMNYRuQPTtkBvpHKeDW3h)
	elif P71nY8vWLi4xBOr9tZVNRQzJUbSG6 in ['4','5','6']:
		pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('(<h5>.*?)</table>',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
		P71nY8vWLi4xBOr9tZVNRQzJUbSG6 = int(P71nY8vWLi4xBOr9tZVNRQzJUbSG6)-4
		mVYdjvor6i4wZ8 = pfRkcVlLmUxo561g0A8qSbO[P71nY8vWLi4xBOr9tZVNRQzJUbSG6]
		items = ePhmG1jLD6.findall('src="(.*?)".*?href="(.*?)".*?title="(.*?)".*?<strong.*?>(.*?)</strong>.*?-cell">(.*?)<',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
		for Sj7rMNYRuQPTtkBvpHKeDW3h,MepIvHBYNArkUOdV37shtJ,aTKNPrW6ie1msSX9HBg,title,YblzdQaeVqgF in items:
			Sj7rMNYRuQPTtkBvpHKeDW3h = ddBxj51bhNtaK23lDyGMVw+ShynO8pN9idCE3+Sj7rMNYRuQPTtkBvpHKeDW3h
			MepIvHBYNArkUOdV37shtJ = ddBxj51bhNtaK23lDyGMVw+ShynO8pN9idCE3+MepIvHBYNArkUOdV37shtJ
			title = title.strip(mIsDke0oK5x1zSiOWbF9thGcA)
			aTKNPrW6ie1msSX9HBg = aTKNPrW6ie1msSX9HBg.strip(mIsDke0oK5x1zSiOWbF9thGcA)
			YblzdQaeVqgF = YblzdQaeVqgF.strip(mIsDke0oK5x1zSiOWbF9thGcA)
			if aTKNPrW6ie1msSX9HBg: name = aTKNPrW6ie1msSX9HBg
			else: name = YblzdQaeVqgF
			title = title+' ('+name+')'
			x3WSXnKyPhjqfHG2UrtQs('video',wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,312,Sj7rMNYRuQPTtkBvpHKeDW3h)
	return
def c8U1BdtxOZS5FH(url):
	IAW0sh6So3NpqM = WWrExJZS3Bj4anOAkpv7(kUz8c7OqsxuPFIGfwg,'GET',url,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,'SHIAVOICE-TITLES-1st')
	cmWl9dOKHPIy41iaXuxrY = IAW0sh6So3NpqM.content
	pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('ibox-heading"(.*?)class="float-right',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	mVYdjvor6i4wZ8 = pfRkcVlLmUxo561g0A8qSbO[0]
	if 'catsum-mobile' in mVYdjvor6i4wZ8:
		items = ePhmG1jLD6.findall('src="(.*?)".*?href="(.*?)".*?<strong>(.*?)</strong>.*?catsum-mobile">(.*?)<',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
		if items:
			for Sj7rMNYRuQPTtkBvpHKeDW3h,MepIvHBYNArkUOdV37shtJ,title,count in items:
				Sj7rMNYRuQPTtkBvpHKeDW3h = ddBxj51bhNtaK23lDyGMVw+ShynO8pN9idCE3+Sj7rMNYRuQPTtkBvpHKeDW3h
				MepIvHBYNArkUOdV37shtJ = ddBxj51bhNtaK23lDyGMVw+ShynO8pN9idCE3+MepIvHBYNArkUOdV37shtJ
				count = count.replace(' الصوتية: ',':')
				title = title.strip(mIsDke0oK5x1zSiOWbF9thGcA)
				title = title+' ('+count+')'
				x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,311,Sj7rMNYRuQPTtkBvpHKeDW3h)
	else:
		items = ePhmG1jLD6.findall('" href="(.*?)".*?</i>(.*?)</a>.*?">(.*?)<.*?<span.*?<span.*?<span.*?">(.*?)<',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
		for MepIvHBYNArkUOdV37shtJ,title,l7r1cWCgb8HtBKAFdmsZXGu,dq0kBrGuKXiP in items:
			if title==qpFY4hAwolV3 or l7r1cWCgb8HtBKAFdmsZXGu==qpFY4hAwolV3: continue
			MepIvHBYNArkUOdV37shtJ = ddBxj51bhNtaK23lDyGMVw+ShynO8pN9idCE3+MepIvHBYNArkUOdV37shtJ
			title = title+' ('+dq0kBrGuKXiP+')'
			x3WSXnKyPhjqfHG2UrtQs('video',wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,312)
	if not items: v1gmfxDcRrWKQ(cmWl9dOKHPIy41iaXuxrY)
	return
def v1gmfxDcRrWKQ(cmWl9dOKHPIy41iaXuxrY):
	pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('class="ibox-content"(.*?)class="pagination',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	mVYdjvor6i4wZ8 = pfRkcVlLmUxo561g0A8qSbO[0]
	items = ePhmG1jLD6.findall('href="(http.*?)".*?</i>(.*?)<.*?cell">(.*?)<.*?cell">(.*?)<.*?cell">(.*?)<',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
	for MepIvHBYNArkUOdV37shtJ,title,name,count,dq0kBrGuKXiP in items:
		MepIvHBYNArkUOdV37shtJ = ddBxj51bhNtaK23lDyGMVw+ShynO8pN9idCE3+MepIvHBYNArkUOdV37shtJ
		title = title.strip(mIsDke0oK5x1zSiOWbF9thGcA)
		name = name.strip(mIsDke0oK5x1zSiOWbF9thGcA)
		title = title+' ('+name+')'
		x3WSXnKyPhjqfHG2UrtQs('video',wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,312,qpFY4hAwolV3,dq0kBrGuKXiP)
	return
def Q9QkZcTtYUreInafdgoXWqNi(url):
	IAW0sh6So3NpqM = WWrExJZS3Bj4anOAkpv7(kUz8c7OqsxuPFIGfwg,'GET',url,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,'SHIAVOICE-SEARCH_ITEMS-1st')
	cmWl9dOKHPIy41iaXuxrY = IAW0sh6So3NpqM.content
	pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('class="ibox-content p-1"(.*?)class="ibox-content"',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	if not pfRkcVlLmUxo561g0A8qSbO:
		c8U1BdtxOZS5FH(url)
		return
	mVYdjvor6i4wZ8 = pfRkcVlLmUxo561g0A8qSbO[0]
	items = ePhmG1jLD6.findall('href="(.*?)".*?<strong>(.*?)<',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
	for MepIvHBYNArkUOdV37shtJ,title in items:
		MepIvHBYNArkUOdV37shtJ = ddBxj51bhNtaK23lDyGMVw+ShynO8pN9idCE3+MepIvHBYNArkUOdV37shtJ
		title = title.strip(mIsDke0oK5x1zSiOWbF9thGcA)
		if '/play-' in MepIvHBYNArkUOdV37shtJ: x3WSXnKyPhjqfHG2UrtQs('video',wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,312)
		else: x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,311)
	return
def mzcAeyplZV(url):
	IAW0sh6So3NpqM = WWrExJZS3Bj4anOAkpv7(rGY36xBwT1bLZAngSfcWEIeXdQVNij,'GET',url,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,'SHIAVOICE-PLAY-1st')
	cmWl9dOKHPIy41iaXuxrY = IAW0sh6So3NpqM.content
	MepIvHBYNArkUOdV37shtJ = ePhmG1jLD6.findall('<audio.*?src="(.*?)"',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	if not MepIvHBYNArkUOdV37shtJ: MepIvHBYNArkUOdV37shtJ = ePhmG1jLD6.findall('<video.*?src="(.*?)"',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	MepIvHBYNArkUOdV37shtJ = ddBxj51bhNtaK23lDyGMVw+MepIvHBYNArkUOdV37shtJ[0]
	dORtnXbEgi5A8m0CH(MepIvHBYNArkUOdV37shtJ,Q8Q0IDc6PLZajJAdTntKUmSGXz,'video')
	return
def PPqUACSE3VcGLTvw05jHy9JrFNW(search):
	search,LBylNhMdH6OV1qGk0tWiXFg3,showDialogs = LLm3sBXHPcnTDxdE5gt6hz0Wkp(search)
	if search==qpFY4hAwolV3: search = jXgARlWMLVFUBnvmZwI2o5()
	if search==qpFY4hAwolV3: return
	search = search.replace(mIsDke0oK5x1zSiOWbF9thGcA,'+')
	NNun75baF2JVo = ['&t=a','&t=c','&t=s']
	if showDialogs:
		GBbsh1DTkV3YAdUmPrXgi7lREn25K = ['قارئ','إصدار / مجلد','مقطع الصوتي']
		ndm6kKswPpgGHNEbtB = xVzqWbrFXJ('موقع صوت الشيعة - أختر البحث', GBbsh1DTkV3YAdUmPrXgi7lREn25K)
		if ndm6kKswPpgGHNEbtB == -1: return
	elif '_SHIAVOICE-PERSONS_' in LBylNhMdH6OV1qGk0tWiXFg3: ndm6kKswPpgGHNEbtB = 0
	elif '_SHIAVOICE-ALBUMS_' in LBylNhMdH6OV1qGk0tWiXFg3: ndm6kKswPpgGHNEbtB = 1
	elif '_SHIAVOICE-AUDIOS_' in LBylNhMdH6OV1qGk0tWiXFg3: ndm6kKswPpgGHNEbtB = 2
	else: return
	type = NNun75baF2JVo[ndm6kKswPpgGHNEbtB]
	url = ddBxj51bhNtaK23lDyGMVw+'/search.php?q='+search+type
	IAW0sh6So3NpqM = WWrExJZS3Bj4anOAkpv7(kUz8c7OqsxuPFIGfwg,'GET',url,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,'SHIAVOICE-SEARCH-1st')
	cmWl9dOKHPIy41iaXuxrY = IAW0sh6So3NpqM.content
	pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('class="ibox-content"(.*?)class="ibox-content"',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	if pfRkcVlLmUxo561g0A8qSbO:
		mVYdjvor6i4wZ8 = pfRkcVlLmUxo561g0A8qSbO[0]
		if ndm6kKswPpgGHNEbtB in [0,1]:
			items = ePhmG1jLD6.findall('href="(.*?)".*?src="(.*?)".*?href=".*?">(.*?)<.*?">(.*?)<',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
			for MepIvHBYNArkUOdV37shtJ,Sj7rMNYRuQPTtkBvpHKeDW3h,title,name in items:
				title = title.strip(mIsDke0oK5x1zSiOWbF9thGcA)
				name = name.strip(mIsDke0oK5x1zSiOWbF9thGcA)
				title = title+' ('+name+')'
				x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,313,Sj7rMNYRuQPTtkBvpHKeDW3h)
		elif ndm6kKswPpgGHNEbtB==2:
			items = ePhmG1jLD6.findall('href="(http.*?)".*?</i>(.*?)</a></td><td>(.*?)<',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
			for MepIvHBYNArkUOdV37shtJ,title,name in items:
				title = title.strip(mIsDke0oK5x1zSiOWbF9thGcA)
				name = name.strip(mIsDke0oK5x1zSiOWbF9thGcA)
				title = title+' ('+name+')'
				x3WSXnKyPhjqfHG2UrtQs('video',wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,312)
	return