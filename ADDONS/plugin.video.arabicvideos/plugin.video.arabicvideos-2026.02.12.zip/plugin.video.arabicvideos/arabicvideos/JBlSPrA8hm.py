# -*- coding: utf-8 -*-
from pSfaryIjBo import *
Q8Q0IDc6PLZajJAdTntKUmSGXz = 'SERIES4WATCH'
headers = { 'User-Agent' : qpFY4hAwolV3 }
wwSFijdVJn1QgHW = '_SFW_'
ddBxj51bhNtaK23lDyGMVw = i4bFG3rKE6.SITESURLS[Q8Q0IDc6PLZajJAdTntKUmSGXz][0]
def vTNE2Ck1sGnugJYW8y39aLcSH64U(mode,url,text):
	if   mode==210: MOTjA5H9XFs = nRVAZc4Dp8PSrGU3xBk()
	elif mode==211: MOTjA5H9XFs = c8U1BdtxOZS5FH(url)
	elif mode==212: MOTjA5H9XFs = mzcAeyplZV(url)
	elif mode==213: MOTjA5H9XFs = v1gmfxDcRrWKQ(url)
	elif mode==214: MOTjA5H9XFs = rFUDp0Gx2my4KhNq(url)
	elif mode==215: MOTjA5H9XFs = zd0LaZ9GvNhjtsc7(url)
	elif mode==218: MOTjA5H9XFs = iiYEWDK1NLFGdlTrgcewfa2nks()
	elif mode==219: MOTjA5H9XFs = PPqUACSE3VcGLTvw05jHy9JrFNW(text)
	else: MOTjA5H9XFs = False
	return MOTjA5H9XFs
def iiYEWDK1NLFGdlTrgcewfa2nks():
	message = 'هذا الموقع تغير بالكامل ... وبحاجة الى اعادة برمجة من الصفر ... والمبرمج حاليا مشغول ويعاني من وعكة صحية ... ولهذا سوف يبقى الموقع مغلق الى ما شاء الله'
	iG7Rz2kmn0x1yLNMV3u8O(qpFY4hAwolV3,qpFY4hAwolV3,GLTtERWbHnFuy4PCp,'الموقع تغير بالكامل',message)
	return
def nRVAZc4Dp8PSrGU3xBk():
	x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+'بحث في الموقع',qpFY4hAwolV3,219,qpFY4hAwolV3,qpFY4hAwolV3,'_REMEMBERRESULTS_')
	url = ddBxj51bhNtaK23lDyGMVw+'/getpostsPin?type=one&data=pin&limit=25'
	x3WSXnKyPhjqfHG2UrtQs('folder',Q8Q0IDc6PLZajJAdTntKUmSGXz+'_SCRIPT_'+wwSFijdVJn1QgHW+'المميزة',url,211)
	cmWl9dOKHPIy41iaXuxrY = GMqfDK9V4F8eTPE1pNOAaiYUbhr(KOyPvpEztYLaZRdMQJWxfTNFHbkg,ddBxj51bhNtaK23lDyGMVw,qpFY4hAwolV3,headers,qpFY4hAwolV3,'SERIES4WATCH-MENU-1st')
	pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('FiltersButtons(.*?)</div>',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	mVYdjvor6i4wZ8 = pfRkcVlLmUxo561g0A8qSbO[0]
	items = ePhmG1jLD6.findall('data-get="(.*?)".*?</i>(.*?)<',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
	for MepIvHBYNArkUOdV37shtJ,title in items:
		url = ddBxj51bhNtaK23lDyGMVw+'/getposts?type=one&data='+MepIvHBYNArkUOdV37shtJ
		x3WSXnKyPhjqfHG2UrtQs('folder',Q8Q0IDc6PLZajJAdTntKUmSGXz+'_SCRIPT_'+wwSFijdVJn1QgHW+title,url,211)
	pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('navigation-menu(.*?)</div>',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	mVYdjvor6i4wZ8 = pfRkcVlLmUxo561g0A8qSbO[0]
	items = ePhmG1jLD6.findall('href="(http.*?)">(.*?)<',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
	YEIA19ehBwpNfPVzK = ['مسلسلات انمي','الرئيسية']
	for MepIvHBYNArkUOdV37shtJ,title in items:
		title = title.strip(mIsDke0oK5x1zSiOWbF9thGcA)
		if not any(value in title for value in YEIA19ehBwpNfPVzK):
			x3WSXnKyPhjqfHG2UrtQs('folder',Q8Q0IDc6PLZajJAdTntKUmSGXz+'_SCRIPT_'+wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,211)
	return cmWl9dOKHPIy41iaXuxrY
def c8U1BdtxOZS5FH(url):
	cmWl9dOKHPIy41iaXuxrY = GMqfDK9V4F8eTPE1pNOAaiYUbhr(kUz8c7OqsxuPFIGfwg,url,qpFY4hAwolV3,headers,qpFY4hAwolV3,'SERIES4WATCH-TITLES-1st')
	if 'getposts' in url or '/search?s=' in url: mVYdjvor6i4wZ8 = cmWl9dOKHPIy41iaXuxrY
	else:
		pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('MediaGrid"(.*?)class="pagination"',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
		if pfRkcVlLmUxo561g0A8qSbO: mVYdjvor6i4wZ8 = pfRkcVlLmUxo561g0A8qSbO[0]
		else: return
	items = ePhmG1jLD6.findall('src="(.*?)".*?href="(.*?)".*?<h3>(.*?)<',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
	aaCNAJdtsguSRELh2I = []
	ajJz5tpLxbnIiH3ewKcrM2UskVqAh = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم']
	for Sj7rMNYRuQPTtkBvpHKeDW3h,MepIvHBYNArkUOdV37shtJ,title in items:
		if '/series/' in MepIvHBYNArkUOdV37shtJ: continue
		MepIvHBYNArkUOdV37shtJ = cTt4u6reEMKZqVLplmkNW7(MepIvHBYNArkUOdV37shtJ).strip(ShynO8pN9idCE3)
		title = j8PDV0pthfSTidZbsQxNIOmCYKWzH(title)
		title = title.strip(mIsDke0oK5x1zSiOWbF9thGcA)
		if '/film/' in MepIvHBYNArkUOdV37shtJ or any(value in title for value in ajJz5tpLxbnIiH3ewKcrM2UskVqAh):
			x3WSXnKyPhjqfHG2UrtQs('video',wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,212,Sj7rMNYRuQPTtkBvpHKeDW3h)
		elif '/episode/' in MepIvHBYNArkUOdV37shtJ and 'الحلقة' in title:
			ZDTxRSMbW7PNz = ePhmG1jLD6.findall('(.*?) الحلقة \d+',title,ePhmG1jLD6.DOTALL)
			if ZDTxRSMbW7PNz:
				title = '_MOD_' + ZDTxRSMbW7PNz[0]
				if title not in aaCNAJdtsguSRELh2I:
					x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,213,Sj7rMNYRuQPTtkBvpHKeDW3h)
					aaCNAJdtsguSRELh2I.append(title)
		else: x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,213,Sj7rMNYRuQPTtkBvpHKeDW3h)
	pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('class="pagination(.*?)</div>',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	if pfRkcVlLmUxo561g0A8qSbO:
		mVYdjvor6i4wZ8 = pfRkcVlLmUxo561g0A8qSbO[0]
		items = ePhmG1jLD6.findall('<a href=["\'](http.*?)["\'].*?>(.*?)<',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
		for MepIvHBYNArkUOdV37shtJ,title in items:
			MepIvHBYNArkUOdV37shtJ = j8PDV0pthfSTidZbsQxNIOmCYKWzH(MepIvHBYNArkUOdV37shtJ)
			title = j8PDV0pthfSTidZbsQxNIOmCYKWzH(title)
			title = title.replace('الصفحة ',qpFY4hAwolV3)
			if title!=qpFY4hAwolV3: x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+'صفحة '+title,MepIvHBYNArkUOdV37shtJ,211)
	return
def v1gmfxDcRrWKQ(url):
	HGW7K4pef3daVmInL8hyo,items,OQGDVkNEqh7ogv2I1STC = -1,[],[]
	cmWl9dOKHPIy41iaXuxrY = GMqfDK9V4F8eTPE1pNOAaiYUbhr(kUz8c7OqsxuPFIGfwg,url,qpFY4hAwolV3,headers,qpFY4hAwolV3,'SERIES4WATCH-EPISODES-1st')
	pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('ti-list-numbered(.*?)</div>',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	if pfRkcVlLmUxo561g0A8qSbO:
		HLVwBWJ6mFa3ApoNlq178nuXgI = qpFY4hAwolV3.join(pfRkcVlLmUxo561g0A8qSbO)
		items = ePhmG1jLD6.findall('href="(.*?)"',HLVwBWJ6mFa3ApoNlq178nuXgI,ePhmG1jLD6.DOTALL)
	items.append(url)
	items = set(items)
	for MepIvHBYNArkUOdV37shtJ in items:
		MepIvHBYNArkUOdV37shtJ = MepIvHBYNArkUOdV37shtJ.strip(ShynO8pN9idCE3)
		title = '_MOD_' + MepIvHBYNArkUOdV37shtJ.split(ShynO8pN9idCE3)[-1].replace('-',mIsDke0oK5x1zSiOWbF9thGcA)
		cgwB6jCZf0dy3zvNFuRn5qo = ePhmG1jLD6.findall('الحلقة-(\d+)',MepIvHBYNArkUOdV37shtJ.split(ShynO8pN9idCE3)[-1],ePhmG1jLD6.DOTALL)
		if cgwB6jCZf0dy3zvNFuRn5qo: cgwB6jCZf0dy3zvNFuRn5qo = cgwB6jCZf0dy3zvNFuRn5qo[0]
		else: cgwB6jCZf0dy3zvNFuRn5qo = '0'
		OQGDVkNEqh7ogv2I1STC.append([MepIvHBYNArkUOdV37shtJ,title,cgwB6jCZf0dy3zvNFuRn5qo])
	items = sorted(OQGDVkNEqh7ogv2I1STC, reverse=False, key=lambda key: int(key[2]))
	FFMeKhsZAnVkHD = str(items).count('/season/')
	HGW7K4pef3daVmInL8hyo = str(items).count('/episode/')
	if FFMeKhsZAnVkHD>1 and HGW7K4pef3daVmInL8hyo>0 and '/season/' not in url:
		for MepIvHBYNArkUOdV37shtJ,title,cgwB6jCZf0dy3zvNFuRn5qo in items:
			if '/season/' in MepIvHBYNArkUOdV37shtJ: x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,213)
	else:
		for MepIvHBYNArkUOdV37shtJ,title,cgwB6jCZf0dy3zvNFuRn5qo in items:
			if '/season/' not in MepIvHBYNArkUOdV37shtJ: x3WSXnKyPhjqfHG2UrtQs('video',wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,212)
	return
def mzcAeyplZV(url):
	U7V0BQZPxXqMbyJnRw6f = []
	ooc63dKJAxDM = url.split(ShynO8pN9idCE3)
	cmWl9dOKHPIy41iaXuxrY = GMqfDK9V4F8eTPE1pNOAaiYUbhr(KOyPvpEztYLaZRdMQJWxfTNFHbkg,url,qpFY4hAwolV3,headers,qpFY4hAwolV3,'SERIES4WATCH-PLAY-1st')
	if '/watch/' in cmWl9dOKHPIy41iaXuxrY:
		WSQlG8mDhqsNe = url.replace(ooc63dKJAxDM[3],'watch')
		CC8IKXmYeo = GMqfDK9V4F8eTPE1pNOAaiYUbhr(KOyPvpEztYLaZRdMQJWxfTNFHbkg,WSQlG8mDhqsNe,qpFY4hAwolV3,headers,qpFY4hAwolV3,'SERIES4WATCH-PLAY-2nd')
		pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('class="servers-list(.*?)</div>',CC8IKXmYeo,ePhmG1jLD6.DOTALL)
		if pfRkcVlLmUxo561g0A8qSbO:
			mVYdjvor6i4wZ8 = pfRkcVlLmUxo561g0A8qSbO[0]
			items = ePhmG1jLD6.findall('data-embedd="(.*?)".*?server_image">\n(.*?)\n',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
			if items:
				id = ePhmG1jLD6.findall('post_id=(.*?)"',CC8IKXmYeo,ePhmG1jLD6.DOTALL)
				if id:
					KpzHWlsYVwvhfdN0A8Lk2n6M = id[0]
					for MepIvHBYNArkUOdV37shtJ,title in items:
						MepIvHBYNArkUOdV37shtJ = ddBxj51bhNtaK23lDyGMVw+'/?postid='+KpzHWlsYVwvhfdN0A8Lk2n6M+'&serverid='+MepIvHBYNArkUOdV37shtJ+'?named='+title+'__watch'
						U7V0BQZPxXqMbyJnRw6f.append(MepIvHBYNArkUOdV37shtJ)
			else:
				items = ePhmG1jLD6.findall('data-embedd=".*?(http.*?)("|&quot;)',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
				for MepIvHBYNArkUOdV37shtJ,oF67yxKdB8nY3TiH9gAMvlOhaPSws0 in items:
					U7V0BQZPxXqMbyJnRw6f.append(MepIvHBYNArkUOdV37shtJ)
	if '/download/' in cmWl9dOKHPIy41iaXuxrY:
		WSQlG8mDhqsNe = url.replace(ooc63dKJAxDM[3],'download')
		CC8IKXmYeo = GMqfDK9V4F8eTPE1pNOAaiYUbhr(KOyPvpEztYLaZRdMQJWxfTNFHbkg,WSQlG8mDhqsNe,qpFY4hAwolV3,headers,qpFY4hAwolV3,'SERIES4WATCH-PLAY-3rd')
		id = ePhmG1jLD6.findall('postId:"(.*?)"',CC8IKXmYeo,ePhmG1jLD6.DOTALL)
		if id:
			KpzHWlsYVwvhfdN0A8Lk2n6M = id[0]
			skD7g3FxW4wCa5BR = { 'User-Agent':qpFY4hAwolV3 , 'X-Requested-With':'XMLHttpRequest' }
			WSQlG8mDhqsNe = ddBxj51bhNtaK23lDyGMVw + '/ajaxCenter?_action=getdownloadlinks&postId='+KpzHWlsYVwvhfdN0A8Lk2n6M
			CC8IKXmYeo = GMqfDK9V4F8eTPE1pNOAaiYUbhr(KOyPvpEztYLaZRdMQJWxfTNFHbkg,WSQlG8mDhqsNe,qpFY4hAwolV3,skD7g3FxW4wCa5BR,qpFY4hAwolV3,'SERIES4WATCH-PLAY-4th')
			pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('<h3.*?(\d+)(.*?)</div>',CC8IKXmYeo,ePhmG1jLD6.DOTALL)
			if pfRkcVlLmUxo561g0A8qSbO:
				for Sd0QufrOLUXHAtZTie8,mVYdjvor6i4wZ8 in pfRkcVlLmUxo561g0A8qSbO:
					items = ePhmG1jLD6.findall('<td>(.*?)<.*?href="(.*?)"',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
					for name,MepIvHBYNArkUOdV37shtJ in items:
						U7V0BQZPxXqMbyJnRw6f.append(MepIvHBYNArkUOdV37shtJ+'?named='+name+'__download'+'____'+Sd0QufrOLUXHAtZTie8)
			else:
				pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('<h6(.*?)</table>',CC8IKXmYeo,ePhmG1jLD6.DOTALL)
				if not pfRkcVlLmUxo561g0A8qSbO: pfRkcVlLmUxo561g0A8qSbO = [CC8IKXmYeo]
				for mVYdjvor6i4wZ8 in pfRkcVlLmUxo561g0A8qSbO:
					name = qpFY4hAwolV3
					items = ePhmG1jLD6.findall('href="(http.*?)"',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
					for MepIvHBYNArkUOdV37shtJ in items:
						XPNkVcWFUr = '&&' + MepIvHBYNArkUOdV37shtJ.split(ShynO8pN9idCE3)[2].lower() + '&&'
						XPNkVcWFUr = XPNkVcWFUr.replace('.com&&',qpFY4hAwolV3).replace('.co&&',qpFY4hAwolV3)
						XPNkVcWFUr = XPNkVcWFUr.replace('.net&&',qpFY4hAwolV3).replace('.org&&',qpFY4hAwolV3)
						XPNkVcWFUr = XPNkVcWFUr.replace('.live&&',qpFY4hAwolV3).replace('.online&&',qpFY4hAwolV3)
						XPNkVcWFUr = XPNkVcWFUr.replace('&&hd.',qpFY4hAwolV3).replace('&&www.',qpFY4hAwolV3)
						XPNkVcWFUr = XPNkVcWFUr.replace('&&',qpFY4hAwolV3)
						MepIvHBYNArkUOdV37shtJ = MepIvHBYNArkUOdV37shtJ + '?named=' + name + XPNkVcWFUr + '__download'
						U7V0BQZPxXqMbyJnRw6f.append(MepIvHBYNArkUOdV37shtJ)
	import inVXFK46ET
	inVXFK46ET.q4qTJvuoQUzM3mZAtegy7IXdnb5wH(U7V0BQZPxXqMbyJnRw6f,Q8Q0IDc6PLZajJAdTntKUmSGXz,'video',url)
	return
def PPqUACSE3VcGLTvw05jHy9JrFNW(search):
	search,LBylNhMdH6OV1qGk0tWiXFg3,showDialogs = LLm3sBXHPcnTDxdE5gt6hz0Wkp(search)
	if search==qpFY4hAwolV3: search = jXgARlWMLVFUBnvmZwI2o5()
	if search==qpFY4hAwolV3: return
	search = search.replace(mIsDke0oK5x1zSiOWbF9thGcA,'+')
	url = ddBxj51bhNtaK23lDyGMVw + '/search?s='+search
	c8U1BdtxOZS5FH(url)
	return