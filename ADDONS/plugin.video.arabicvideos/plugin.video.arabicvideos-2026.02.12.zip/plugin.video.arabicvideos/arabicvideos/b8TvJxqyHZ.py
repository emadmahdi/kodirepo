# -*- coding: utf-8 -*-
from pSfaryIjBo import *
Q8Q0IDc6PLZajJAdTntKUmSGXz = 'SHOOFMAX'
wwSFijdVJn1QgHW = '_SHM_'
ddBxj51bhNtaK23lDyGMVw = i4bFG3rKE6.SITESURLS[Q8Q0IDc6PLZajJAdTntKUmSGXz][0]
WsvFbLApfU = i4bFG3rKE6.SITESURLS[Q8Q0IDc6PLZajJAdTntKUmSGXz][1]
ecyzJ5qXfBnOiMHRLShmw = i4bFG3rKE6.SITESURLS[Q8Q0IDc6PLZajJAdTntKUmSGXz][2]
def vTNE2Ck1sGnugJYW8y39aLcSH64U(mode,url,text):
	if   mode==50: MOTjA5H9XFs = nRVAZc4Dp8PSrGU3xBk()
	elif mode==51: MOTjA5H9XFs = c8U1BdtxOZS5FH(url)
	elif mode==52: MOTjA5H9XFs = v1gmfxDcRrWKQ(url)
	elif mode==53: MOTjA5H9XFs = mzcAeyplZV(url)
	elif mode==55: MOTjA5H9XFs = Om9WNYruFBMzw()
	elif mode==56: MOTjA5H9XFs = E6m04olUNz()
	elif mode==57: MOTjA5H9XFs = nIDfHyeBjxrkwYO8v2dAPNTuqUK(url,1)
	elif mode==58: MOTjA5H9XFs = nIDfHyeBjxrkwYO8v2dAPNTuqUK(url,2)
	elif mode==59: MOTjA5H9XFs = PPqUACSE3VcGLTvw05jHy9JrFNW(text)
	else: MOTjA5H9XFs = False
	return MOTjA5H9XFs
def nRVAZc4Dp8PSrGU3xBk():
	x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+'بحث في الموقع',qpFY4hAwolV3,59,qpFY4hAwolV3,qpFY4hAwolV3,'_REMEMBERRESULTS_')
	x3WSXnKyPhjqfHG2UrtQs('link',xupTj02bvy3O8R+' ===== ===== ===== '+fF4lt9zWYxXLKZVyAco82PgMj,qpFY4hAwolV3,9999)
	x3WSXnKyPhjqfHG2UrtQs('folder',Q8Q0IDc6PLZajJAdTntKUmSGXz+'_SCRIPT_'+wwSFijdVJn1QgHW+'المسلسلات',qpFY4hAwolV3,56)
	x3WSXnKyPhjqfHG2UrtQs('folder',Q8Q0IDc6PLZajJAdTntKUmSGXz+'_SCRIPT_'+wwSFijdVJn1QgHW+'الافلام',qpFY4hAwolV3,55)
	return qpFY4hAwolV3
def Om9WNYruFBMzw():
	x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+'أفلام مرتبة بسنة الإنتاج',ddBxj51bhNtaK23lDyGMVw+'/movie/1/yop',57)
	x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+'أفلام مرتبة بالأفضل تقييم',ddBxj51bhNtaK23lDyGMVw+'/movie/1/review',57)
	x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+'أفلام مرتبة بالأكثر مشاهدة',ddBxj51bhNtaK23lDyGMVw+'/movie/1/views',57)
	return
def E6m04olUNz():
	x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+'مسلسلات مرتبة بسنة الإنتاج',ddBxj51bhNtaK23lDyGMVw+'/series/1/yop',57)
	x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+'مسلسلات مرتبة بالأفضل تقييم',ddBxj51bhNtaK23lDyGMVw+'/series/1/review',57)
	x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+'مسلسلات مرتبة بالأكثر مشاهدة',ddBxj51bhNtaK23lDyGMVw+'/series/1/views',57)
	return
def c8U1BdtxOZS5FH(url):
	if '?' in url:
		ooc63dKJAxDM = url.split('?')
		url = ooc63dKJAxDM[0]
		filter = '?' + BUKlErdIu7Ggqcz3jYpf09wMePF4V(ooc63dKJAxDM[1],'=&:/%')
	else: filter = qpFY4hAwolV3
	type,i02wfPp5EM,sort = url.split(ShynO8pN9idCE3)[-3:]
	if sort in ['yop','review','views']:
		if type=='movie': CNu3MSi9Yz4B='فيلم'
		elif type=='series': CNu3MSi9Yz4B='مسلسل'
		url = ddBxj51bhNtaK23lDyGMVw + '/genre/filter/' + BUKlErdIu7Ggqcz3jYpf09wMePF4V(CNu3MSi9Yz4B) + ShynO8pN9idCE3 + i02wfPp5EM + ShynO8pN9idCE3 + sort + filter
		cmWl9dOKHPIy41iaXuxrY = GMqfDK9V4F8eTPE1pNOAaiYUbhr(kUz8c7OqsxuPFIGfwg,url,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,'SHOOFMAX-TITLES-1st')
		items = ePhmG1jLD6.findall('"pid":(.*?),.*?"ptitle":"(.*?)".+?"pepisodes":(.*?),"presbase":"(.*?)"',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
		QvAKZkJeOsMwX34xtTa=0
		for id,title,erjGKBcOpzAZI5,Sj7rMNYRuQPTtkBvpHKeDW3h in items:
			QvAKZkJeOsMwX34xtTa += 1
			Sj7rMNYRuQPTtkBvpHKeDW3h = ecyzJ5qXfBnOiMHRLShmw + '/v2/img/program/main/' + Sj7rMNYRuQPTtkBvpHKeDW3h + '-2.jpg'
			MepIvHBYNArkUOdV37shtJ = ddBxj51bhNtaK23lDyGMVw + '/program/' + id
			if type=='movie': x3WSXnKyPhjqfHG2UrtQs('video',wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,53,Sj7rMNYRuQPTtkBvpHKeDW3h)
			if type=='series': x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+'مسلسل '+title,MepIvHBYNArkUOdV37shtJ+'?ep='+erjGKBcOpzAZI5+'='+title+'='+Sj7rMNYRuQPTtkBvpHKeDW3h,52,Sj7rMNYRuQPTtkBvpHKeDW3h)
	else:
		if type=='movie': CNu3MSi9Yz4B='movies'
		elif type=='series': CNu3MSi9Yz4B='series'
		url = WsvFbLApfU + '/json/selected/' + sort + '-' + CNu3MSi9Yz4B + '-WW.json'
		cmWl9dOKHPIy41iaXuxrY = GMqfDK9V4F8eTPE1pNOAaiYUbhr(kUz8c7OqsxuPFIGfwg,url,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,'SHOOFMAX-TITLES-2nd')
		items = ePhmG1jLD6.findall('"ref":(.*?),"ep":(.*?),"base":"(.*?)","title":"(.*?)"',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
		QvAKZkJeOsMwX34xtTa=0
		for id,erjGKBcOpzAZI5,Sj7rMNYRuQPTtkBvpHKeDW3h,title in items:
			QvAKZkJeOsMwX34xtTa += 1
			Sj7rMNYRuQPTtkBvpHKeDW3h = WsvFbLApfU + '/img/program/' + Sj7rMNYRuQPTtkBvpHKeDW3h + '-2.jpg'
			MepIvHBYNArkUOdV37shtJ = ddBxj51bhNtaK23lDyGMVw + '/program/' + id
			if type=='movie': x3WSXnKyPhjqfHG2UrtQs('video',wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,53,Sj7rMNYRuQPTtkBvpHKeDW3h)
			elif type=='series': x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+'مسلسل '+title,MepIvHBYNArkUOdV37shtJ+'?ep='+erjGKBcOpzAZI5+'='+title+'='+Sj7rMNYRuQPTtkBvpHKeDW3h,52,Sj7rMNYRuQPTtkBvpHKeDW3h)
	title='صفحة '
	if QvAKZkJeOsMwX34xtTa==16:
		for rOYTHxI0fJMs in range(1,13) :
			if not i02wfPp5EM==str(rOYTHxI0fJMs):
				url = ddBxj51bhNtaK23lDyGMVw+'/genre/filter/'+type+ShynO8pN9idCE3+str(rOYTHxI0fJMs)+ShynO8pN9idCE3+sort+filter
				x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+title+str(rOYTHxI0fJMs),url,51)
	return
def v1gmfxDcRrWKQ(url):
	ooc63dKJAxDM = url.split('=')
	erjGKBcOpzAZI5 = int(ooc63dKJAxDM[1])
	name = cTt4u6reEMKZqVLplmkNW7(ooc63dKJAxDM[2])
	name = name.replace('_MOD_مسلسل ',qpFY4hAwolV3)
	Sj7rMNYRuQPTtkBvpHKeDW3h = ooc63dKJAxDM[3]
	url = url.split('?')[0]
	if erjGKBcOpzAZI5==0:
		cmWl9dOKHPIy41iaXuxrY = GMqfDK9V4F8eTPE1pNOAaiYUbhr(kUz8c7OqsxuPFIGfwg,url,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,'SHOOFMAX-EPISODES-1st')
		pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('<select(.*?)</select>',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
		mVYdjvor6i4wZ8 = pfRkcVlLmUxo561g0A8qSbO[0]
		items = ePhmG1jLD6.findall('option value="(.*?)"',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
		erjGKBcOpzAZI5 = int(items[-1])
	for ZDTxRSMbW7PNz in range(erjGKBcOpzAZI5,0,-1):
		MepIvHBYNArkUOdV37shtJ = url + '?ep=' + str(ZDTxRSMbW7PNz)
		title = '_MOD_مسلسل '+name+' - الحلقة '+str(ZDTxRSMbW7PNz)
		x3WSXnKyPhjqfHG2UrtQs('video',wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,53,Sj7rMNYRuQPTtkBvpHKeDW3h)
	return
def mzcAeyplZV(url):
	cmWl9dOKHPIy41iaXuxrY = GMqfDK9V4F8eTPE1pNOAaiYUbhr(KOyPvpEztYLaZRdMQJWxfTNFHbkg,url,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,'SHOOFMAX-PLAY-1st')
	k5iYvruAcW3SfzasVpmCJGoMdw4bZL = ePhmG1jLD6.findall('متوفر على شوف ماكس بعد.*?moment\("(.*?)"',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	if k5iYvruAcW3SfzasVpmCJGoMdw4bZL:
		s7FnXZYOgexlH2MPb8BJck1AKv9 = k5iYvruAcW3SfzasVpmCJGoMdw4bZL[1].replace('T',M04Bcjvt8SFaeQEK)
		iG7Rz2kmn0x1yLNMV3u8O(qpFY4hAwolV3,qpFY4hAwolV3,'رسالة من الموقع الأصلي','هذا الفيديو سيكون متوفر على شوف ماكس بعد هذا الوقت'+ZLwoRpfnCWI7FgEHsz6te39lMVh+s7FnXZYOgexlH2MPb8BJck1AKv9)
		return
	G4YvsZ7mHECerA9fQLXoMSBK2uTlRh,M1iFwU0yudzveJc74SK = [],[]
	ziLdwGHnElT87Xj35 = ePhmG1jLD6.findall('var origin_link = "(.*?)"',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)[0]
	el3gRHuWF86wskmy = ePhmG1jLD6.findall('var backup_origin_link = "(.*?)"',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)[0]
	CFevtSjzbpn = ePhmG1jLD6.findall('hls: (.*?)_link\+"(.*?)"',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	for XPNkVcWFUr,MepIvHBYNArkUOdV37shtJ in CFevtSjzbpn:
		if 'backup' in XPNkVcWFUr:
			XPNkVcWFUr = 'backup server'
			url = el3gRHuWF86wskmy + MepIvHBYNArkUOdV37shtJ
		else:
			XPNkVcWFUr = 'main server'
			url = ziLdwGHnElT87Xj35 + MepIvHBYNArkUOdV37shtJ
		if '.m3u8' in url:
			G4YvsZ7mHECerA9fQLXoMSBK2uTlRh.append(url)
			M1iFwU0yudzveJc74SK.append('m3u8  '+XPNkVcWFUr)
	CFevtSjzbpn = ePhmG1jLD6.findall('mp4:.*?_link.*?\t(.*?)_link\+"(.*?)"',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	CFevtSjzbpn += ePhmG1jLD6.findall('mp4:.*?\t(.*?)_link\+"(.*?)"',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	for XPNkVcWFUr,MepIvHBYNArkUOdV37shtJ in CFevtSjzbpn:
		filename = MepIvHBYNArkUOdV37shtJ.split(ShynO8pN9idCE3)[-1]
		filename = filename.replace('fallback',qpFY4hAwolV3)
		filename = filename.replace('.mp4',qpFY4hAwolV3)
		filename = filename.replace('-',qpFY4hAwolV3)
		if 'backup' in XPNkVcWFUr:
			XPNkVcWFUr = 'backup server'
			url = el3gRHuWF86wskmy + MepIvHBYNArkUOdV37shtJ
		else:
			XPNkVcWFUr = 'main server'
			url = ziLdwGHnElT87Xj35 + MepIvHBYNArkUOdV37shtJ
		G4YvsZ7mHECerA9fQLXoMSBK2uTlRh.append(url)
		M1iFwU0yudzveJc74SK.append('mp4  '+XPNkVcWFUr+r1roOXYi7UQw9FLThzPEdD0ZlvAnRc+filename)
	ndm6kKswPpgGHNEbtB = xVzqWbrFXJ('Select Video Quality:', M1iFwU0yudzveJc74SK)
	if ndm6kKswPpgGHNEbtB == -1 : return
	url = G4YvsZ7mHECerA9fQLXoMSBK2uTlRh[ndm6kKswPpgGHNEbtB]
	dORtnXbEgi5A8m0CH(url,Q8Q0IDc6PLZajJAdTntKUmSGXz,'video')
	return
def nIDfHyeBjxrkwYO8v2dAPNTuqUK(url,type):
	if 'series' in url: WSQlG8mDhqsNe = ddBxj51bhNtaK23lDyGMVw + '/genre/مسلسل'
	else: WSQlG8mDhqsNe = ddBxj51bhNtaK23lDyGMVw + '/genre/فيلم'
	WSQlG8mDhqsNe = BUKlErdIu7Ggqcz3jYpf09wMePF4V(WSQlG8mDhqsNe)
	cmWl9dOKHPIy41iaXuxrY = GMqfDK9V4F8eTPE1pNOAaiYUbhr(KOyPvpEztYLaZRdMQJWxfTNFHbkg,WSQlG8mDhqsNe,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,'SHOOFMAX-FILTERS-1st')
	if type==1: pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('subgenre(.*?)div',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	elif type==2: pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('country(.*?)div',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	mVYdjvor6i4wZ8 = pfRkcVlLmUxo561g0A8qSbO[0]
	items = ePhmG1jLD6.findall('option value="(.*?)">(.*?)</option',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
	if type==1:
		for Ktg17QVeWfShrYxnA02qDZc89vw,title in items:
			x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+title,url+'?subgenre='+Ktg17QVeWfShrYxnA02qDZc89vw,58)
	elif type==2:
		url,Ktg17QVeWfShrYxnA02qDZc89vw = url.split('?')
		for F1KMGjNvHegbIJEs3fcOtwq,title in items:
			x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+title,url+'?country='+F1KMGjNvHegbIJEs3fcOtwq+'&'+Ktg17QVeWfShrYxnA02qDZc89vw,51)
	return
def PPqUACSE3VcGLTvw05jHy9JrFNW(search):
	search,LBylNhMdH6OV1qGk0tWiXFg3,showDialogs = LLm3sBXHPcnTDxdE5gt6hz0Wkp(search)
	if not search: search = jXgARlWMLVFUBnvmZwI2o5()
	if not search: return
	K7m9Otk3h1VYIN8rcP6jp2 = search.replace(mIsDke0oK5x1zSiOWbF9thGcA,'%20')
	url = ddBxj51bhNtaK23lDyGMVw+'/search?q='+K7m9Otk3h1VYIN8rcP6jp2
	IAW0sh6So3NpqM = WWrExJZS3Bj4anOAkpv7(kUz8c7OqsxuPFIGfwg,'GET',url,qpFY4hAwolV3,qpFY4hAwolV3,True,qpFY4hAwolV3,'SHOOFMAX-SEARCH-2nd')
	cmWl9dOKHPIy41iaXuxrY = IAW0sh6So3NpqM.content
	pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('general-body(.*?)search-bottom-padding',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	mVYdjvor6i4wZ8 = pfRkcVlLmUxo561g0A8qSbO[0]
	items = ePhmG1jLD6.findall('href="(.*?)".*?background-image: url\((.*?)\).*?<span>(.*?)</span>',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
	if items:
		for MepIvHBYNArkUOdV37shtJ,Sj7rMNYRuQPTtkBvpHKeDW3h,title in items:
			url = ddBxj51bhNtaK23lDyGMVw + MepIvHBYNArkUOdV37shtJ
			if '/program/' in url:
				if '?ep=' in url:
					title = '_MOD_مسلسل '+title
					url = url.replace('?ep=1','?ep=0')
					url = url+'='+BUKlErdIu7Ggqcz3jYpf09wMePF4V(title)+'='+Sj7rMNYRuQPTtkBvpHKeDW3h
					x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+title,url,52,Sj7rMNYRuQPTtkBvpHKeDW3h)
				else:
					title = '_MOD_فيلم '+title
					x3WSXnKyPhjqfHG2UrtQs('video',wwSFijdVJn1QgHW+title,url,53,Sj7rMNYRuQPTtkBvpHKeDW3h)
	return