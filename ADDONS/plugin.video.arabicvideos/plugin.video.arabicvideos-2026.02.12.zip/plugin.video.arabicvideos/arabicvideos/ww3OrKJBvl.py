# -*- coding: utf-8 -*-
import sys as TSRUP0dExYGQg
mgNMJhrjcq1xb = TSRUP0dExYGQg.version_info [0] == 2
lQJvf8UXo2de9gjCatY4yH = 2048
YuTB2OjotvlR = 7
def kk0DKyarxq9eS1zwGLMFQTZN35dj (neqP2if8IOJ50aNKcCBLrXdZk):
	global sWerUpk6nQwT7zY43
	vxdNQUujz7ZFV4rtOSK2 = ord (neqP2if8IOJ50aNKcCBLrXdZk [-1])
	yyshZX35KO7JodYjD9qVib6 = neqP2if8IOJ50aNKcCBLrXdZk [:-1]
	fuKReXJ3HPIAU7c = vxdNQUujz7ZFV4rtOSK2 % len (yyshZX35KO7JodYjD9qVib6)
	EEFQdvXog7LPC4Sie0jDkUKxn6M = yyshZX35KO7JodYjD9qVib6 [:fuKReXJ3HPIAU7c] + yyshZX35KO7JodYjD9qVib6 [fuKReXJ3HPIAU7c:]
	if mgNMJhrjcq1xb:
		Clh5YS0XPue68EgT4Uq17GL = unicode () .join ([unichr (ord (AsGVDZFgmuH06jviYrWXTz) - lQJvf8UXo2de9gjCatY4yH - (XvhDIL4ZpzaPs91WkoGnedCEA2rt + vxdNQUujz7ZFV4rtOSK2) % YuTB2OjotvlR) for XvhDIL4ZpzaPs91WkoGnedCEA2rt, AsGVDZFgmuH06jviYrWXTz in enumerate (EEFQdvXog7LPC4Sie0jDkUKxn6M)])
	else:
		Clh5YS0XPue68EgT4Uq17GL = str () .join ([chr (ord (AsGVDZFgmuH06jviYrWXTz) - lQJvf8UXo2de9gjCatY4yH - (XvhDIL4ZpzaPs91WkoGnedCEA2rt + vxdNQUujz7ZFV4rtOSK2) % YuTB2OjotvlR) for XvhDIL4ZpzaPs91WkoGnedCEA2rt, AsGVDZFgmuH06jviYrWXTz in enumerate (EEFQdvXog7LPC4Sie0jDkUKxn6M)])
	return eval (Clh5YS0XPue68EgT4Uq17GL)
qoBMmfAWpFlK70xw8ZRh4naJ,lljaEqwTVtmKsQcOrbXxS5hgNH,aXqWLoTdVgME=kk0DKyarxq9eS1zwGLMFQTZN35dj,kk0DKyarxq9eS1zwGLMFQTZN35dj,kk0DKyarxq9eS1zwGLMFQTZN35dj
UVa3fJw7k6KM,fWoVd0Bmtkx,tQMjXKCA5dN4xq3beVIzaEoWkFLg=aXqWLoTdVgME,lljaEqwTVtmKsQcOrbXxS5hgNH,qoBMmfAWpFlK70xw8ZRh4naJ
viRJWOC5jsYe84,Ie5s2cBtSfdHjzQ4rA9kYlo6D18,sjtU6GZQg5XC2pH4=tQMjXKCA5dN4xq3beVIzaEoWkFLg,fWoVd0Bmtkx,UVa3fJw7k6KM
LZWMikPEB81KSGyxfJtUsCA,rNdBKI74fAklnoCZ6,BRWqdruz2A0=sjtU6GZQg5XC2pH4,Ie5s2cBtSfdHjzQ4rA9kYlo6D18,viRJWOC5jsYe84
CC1eY6yWZUwf2TkRvnp7EJ0AimjHBX,qqzwE6imYG4c2xojI,N3flV6EJsD5CzS=BRWqdruz2A0,rNdBKI74fAklnoCZ6,LZWMikPEB81KSGyxfJtUsCA
UUDAiytEL76RTmMYsuIz5evXB,IaBhDMJc17302LgSvyxd,ddiCzu6yahj5RtTISMJ48sNnZBU=N3flV6EJsD5CzS,qqzwE6imYG4c2xojI,CC1eY6yWZUwf2TkRvnp7EJ0AimjHBX
dJHDqiKf12TXlIzSLkGUuxg4MBs3A,l1DZAt9XNQjqE7YOdrz,l32dnTEOU1skGKqeBtI9hmo=ddiCzu6yahj5RtTISMJ48sNnZBU,IaBhDMJc17302LgSvyxd,UUDAiytEL76RTmMYsuIz5evXB
zYvEaigKWjoq50pXBLDbGJkFc,iNc3KxwErnQ,V3VlkhgjEF4n1erPXHcC0NOsfwyAJ=l32dnTEOU1skGKqeBtI9hmo,l1DZAt9XNQjqE7YOdrz,dJHDqiKf12TXlIzSLkGUuxg4MBs3A
tR1krDGPpO025fghMT3a7UnYj,c2RKu0xG1eC8MiohyE,RlOvin8YIGC2KZXJPk9m0acrMobUex=V3VlkhgjEF4n1erPXHcC0NOsfwyAJ,iNc3KxwErnQ,zYvEaigKWjoq50pXBLDbGJkFc
YY8UDX3MJhb91AHw7fg,ee86G9ladLHVbh5mikzCo,mmV2nucZ5Lpl6FO1JMPEqGoQKW=RlOvin8YIGC2KZXJPk9m0acrMobUex,c2RKu0xG1eC8MiohyE,tR1krDGPpO025fghMT3a7UnYj
DaFZHsThGmd0zv6e,kYDaz79TFlXoR,DiJ8CMuYH1daWyjehfN0L=mmV2nucZ5Lpl6FO1JMPEqGoQKW,ee86G9ladLHVbh5mikzCo,YY8UDX3MJhb91AHw7fg
from NKn4FXivsk import *
class GiTBNZQIou29VR1vPx0myMg(OJNCZ1gTvjdS8xQt):
	def __init__(LVT1cNq8QJpdKA94bGf53vPStyg,*aargs,**kkwargs):
		LVT1cNq8QJpdKA94bGf53vPStyg.choiceID = -mZi0S72jGoHpLO
	def onClick(LVT1cNq8QJpdKA94bGf53vPStyg,BzfuF2k3gRQ0eO):
		if BzfuF2k3gRQ0eO>=UVa3fJw7k6KM(u"࠺࠲࠴࠴஄"): LVT1cNq8QJpdKA94bGf53vPStyg.choiceID = BzfuF2k3gRQ0eO-UVa3fJw7k6KM(u"࠺࠲࠴࠴஄")
		LVT1cNq8QJpdKA94bGf53vPStyg.dShvBTVoFGkatzJj()
	def mxUlpDMvro5Akgs4WduwK(LVT1cNq8QJpdKA94bGf53vPStyg,*aargs):
		LVT1cNq8QJpdKA94bGf53vPStyg.button0,LVT1cNq8QJpdKA94bGf53vPStyg.button1,LVT1cNq8QJpdKA94bGf53vPStyg.button2 = aargs[vvXoMLlg513],aargs[mZi0S72jGoHpLO],aargs[Zwqio2AIWlD5etFa]
		LVT1cNq8QJpdKA94bGf53vPStyg.header,LVT1cNq8QJpdKA94bGf53vPStyg.text = aargs[DAE6vkyhXGx1wBdHmcFfTVQpL0l],aargs[wn4bG51vUENfaS0Zg]
		LVT1cNq8QJpdKA94bGf53vPStyg.profile,LVT1cNq8QJpdKA94bGf53vPStyg.direction = aargs[kYDaz79TFlXoR(u"࠷அ")],aargs[lljaEqwTVtmKsQcOrbXxS5hgNH(u"࠹ஆ")]
		LVT1cNq8QJpdKA94bGf53vPStyg.buttonstimeout,LVT1cNq8QJpdKA94bGf53vPStyg.closetimeout = aargs[c2RKu0xG1eC8MiohyE(u"࠼ஈ")],aargs[Ie5s2cBtSfdHjzQ4rA9kYlo6D18(u"࠼இ")]
		if LVT1cNq8QJpdKA94bGf53vPStyg.buttonstimeout>vvXoMLlg513 or LVT1cNq8QJpdKA94bGf53vPStyg.closetimeout>UVa3fJw7k6KM(u"࠶உ"): LVT1cNq8QJpdKA94bGf53vPStyg.enable_progressbar = gBExoceumj4y8bFW9hY2aNMVSr
		else: LVT1cNq8QJpdKA94bGf53vPStyg.enable_progressbar = ag8rjZo1Vz4IPdcOT
		LVT1cNq8QJpdKA94bGf53vPStyg.image_filename = GGyUh9CxSiHDrcMJ5d.replace(lljaEqwTVtmKsQcOrbXxS5hgNH(u"ࠩࡢ࠴࠵࠶࠰ࡠࠩ૲"),UVa3fJw7k6KM(u"ࠪࡣࠬ૳")+str(s7FnXZYOgexlH2MPb8BJck1AKv9.time())+qqzwE6imYG4c2xojI(u"ࠫࡤ࠭૴"))
		LVT1cNq8QJpdKA94bGf53vPStyg.image_filename = LVT1cNq8QJpdKA94bGf53vPStyg.image_filename.replace(RlOvin8YIGC2KZXJPk9m0acrMobUex(u"ࠬࡢ࡜ࠨ૵"),tQMjXKCA5dN4xq3beVIzaEoWkFLg(u"࠭࡜࡝࡞࡟ࠫ૶")).replace(ttrDbyV5cSO2FjgTzew6qM,rNdBKI74fAklnoCZ6(u"ࠧ࠰࠱࠲࠳ࠬ૷"))
		LVT1cNq8QJpdKA94bGf53vPStyg.image_height = gKlm29ifcJNFzvIujqbZtBG(LVT1cNq8QJpdKA94bGf53vPStyg.button0,LVT1cNq8QJpdKA94bGf53vPStyg.button1,LVT1cNq8QJpdKA94bGf53vPStyg.button2,LVT1cNq8QJpdKA94bGf53vPStyg.header,LVT1cNq8QJpdKA94bGf53vPStyg.text,LVT1cNq8QJpdKA94bGf53vPStyg.profile,LVT1cNq8QJpdKA94bGf53vPStyg.direction,LVT1cNq8QJpdKA94bGf53vPStyg.enable_progressbar,LVT1cNq8QJpdKA94bGf53vPStyg.image_filename)
		LVT1cNq8QJpdKA94bGf53vPStyg.show()
		LVT1cNq8QJpdKA94bGf53vPStyg.getControl(N3flV6EJsD5CzS(u"࠹࠱࠷࠳ஊ")).setImage(LVT1cNq8QJpdKA94bGf53vPStyg.image_filename)
		LVT1cNq8QJpdKA94bGf53vPStyg.getControl(Ie5s2cBtSfdHjzQ4rA9kYlo6D18(u"࠺࠲࠸࠴஋")).setHeight(LVT1cNq8QJpdKA94bGf53vPStyg.image_height)
		if not LVT1cNq8QJpdKA94bGf53vPStyg.button1 and LVT1cNq8QJpdKA94bGf53vPStyg.button0 and LVT1cNq8QJpdKA94bGf53vPStyg.button2: LVT1cNq8QJpdKA94bGf53vPStyg.getControl(IaBhDMJc17302LgSvyxd(u"࠼࠴࠶࠸஍")).setPosition(-DaFZHsThGmd0zv6e(u"࠶࠷࠶எ"),qqzwE6imYG4c2xojI(u"࠲஌"))
		return LVT1cNq8QJpdKA94bGf53vPStyg.image_filename,LVT1cNq8QJpdKA94bGf53vPStyg.image_height
	def SSWxPJVK1Hg5sMEy(LVT1cNq8QJpdKA94bGf53vPStyg):
		if LVT1cNq8QJpdKA94bGf53vPStyg.buttonstimeout:
			LVT1cNq8QJpdKA94bGf53vPStyg.th1 = MqWf2atLi7QDnOF0YKuZhrE53gbv1(daemon=gBExoceumj4y8bFW9hY2aNMVSr,target=LVT1cNq8QJpdKA94bGf53vPStyg.xjrMovCaz5KEsciUQR9tOgA3)
			LVT1cNq8QJpdKA94bGf53vPStyg.th1.start()
		else: LVT1cNq8QJpdKA94bGf53vPStyg.n53M0ubimCco2xhpNWRDSHj8g()
	def xjrMovCaz5KEsciUQR9tOgA3(LVT1cNq8QJpdKA94bGf53vPStyg):
		LVT1cNq8QJpdKA94bGf53vPStyg.getControl(qqzwE6imYG4c2xojI(u"࠾࠶࠲࠱ஏ")).setEnabled(gBExoceumj4y8bFW9hY2aNMVSr)
		for nnZ13Rr6tYXio0DyfLVvSxBec in range(mZi0S72jGoHpLO,LVT1cNq8QJpdKA94bGf53vPStyg.buttonstimeout+mZi0S72jGoHpLO):
			s7FnXZYOgexlH2MPb8BJck1AKv9.sleep(mZi0S72jGoHpLO)
			ZhX7Bd3V2DvpfcPIqRewumO5AGJ = int(l1DZAt9XNQjqE7YOdrz(u"࠷࠰࠱ஐ")*nnZ13Rr6tYXio0DyfLVvSxBec/LVT1cNq8QJpdKA94bGf53vPStyg.buttonstimeout)
			LVT1cNq8QJpdKA94bGf53vPStyg.MLd5Fh4S3AKqYyUu(ZhX7Bd3V2DvpfcPIqRewumO5AGJ)
			if LVT1cNq8QJpdKA94bGf53vPStyg.choiceID>iNc3KxwErnQ(u"࠰஑"): break
		LVT1cNq8QJpdKA94bGf53vPStyg.n53M0ubimCco2xhpNWRDSHj8g()
	def PzfQ35O8Ce9v0bI(LVT1cNq8QJpdKA94bGf53vPStyg):
		if LVT1cNq8QJpdKA94bGf53vPStyg.closetimeout:
			LVT1cNq8QJpdKA94bGf53vPStyg.th2 = MqWf2atLi7QDnOF0YKuZhrE53gbv1(daemon=gBExoceumj4y8bFW9hY2aNMVSr,target=LVT1cNq8QJpdKA94bGf53vPStyg.GGTnF52ftOe8yQ90MDC)
			LVT1cNq8QJpdKA94bGf53vPStyg.th2.start()
		else: LVT1cNq8QJpdKA94bGf53vPStyg.n53M0ubimCco2xhpNWRDSHj8g()
	def GGTnF52ftOe8yQ90MDC(LVT1cNq8QJpdKA94bGf53vPStyg):
		LVT1cNq8QJpdKA94bGf53vPStyg.getControl(zYvEaigKWjoq50pXBLDbGJkFc(u"࠺࠲࠵࠴ஒ")).setEnabled(gBExoceumj4y8bFW9hY2aNMVSr)
		s7FnXZYOgexlH2MPb8BJck1AKv9.sleep(LVT1cNq8QJpdKA94bGf53vPStyg.buttonstimeout)
		for nnZ13Rr6tYXio0DyfLVvSxBec in range(LVT1cNq8QJpdKA94bGf53vPStyg.closetimeout-mZi0S72jGoHpLO,-mZi0S72jGoHpLO,-mZi0S72jGoHpLO):
			s7FnXZYOgexlH2MPb8BJck1AKv9.sleep(mZi0S72jGoHpLO)
			ZhX7Bd3V2DvpfcPIqRewumO5AGJ = int(mmV2nucZ5Lpl6FO1JMPEqGoQKW(u"࠳࠳࠴ஓ")*nnZ13Rr6tYXio0DyfLVvSxBec/LVT1cNq8QJpdKA94bGf53vPStyg.closetimeout)
			LVT1cNq8QJpdKA94bGf53vPStyg.MLd5Fh4S3AKqYyUu(ZhX7Bd3V2DvpfcPIqRewumO5AGJ)
			if LVT1cNq8QJpdKA94bGf53vPStyg.choiceID>vvXoMLlg513: break
		if LVT1cNq8QJpdKA94bGf53vPStyg.closetimeout>vvXoMLlg513: LVT1cNq8QJpdKA94bGf53vPStyg.choiceID = BRWqdruz2A0(u"࠴࠴ஔ")
		LVT1cNq8QJpdKA94bGf53vPStyg.dShvBTVoFGkatzJj()
	def MLd5Fh4S3AKqYyUu(LVT1cNq8QJpdKA94bGf53vPStyg,ZhX7Bd3V2DvpfcPIqRewumO5AGJ):
		LVT1cNq8QJpdKA94bGf53vPStyg.precent = ZhX7Bd3V2DvpfcPIqRewumO5AGJ
		LVT1cNq8QJpdKA94bGf53vPStyg.getControl(viRJWOC5jsYe84(u"࠽࠵࠸࠰க")).setPercent(LVT1cNq8QJpdKA94bGf53vPStyg.precent)
	def n53M0ubimCco2xhpNWRDSHj8g(LVT1cNq8QJpdKA94bGf53vPStyg):
		if LVT1cNq8QJpdKA94bGf53vPStyg.button0: LVT1cNq8QJpdKA94bGf53vPStyg.getControl(IaBhDMJc17302LgSvyxd(u"࠾࠶࠱࠱஖")).setEnabled(gBExoceumj4y8bFW9hY2aNMVSr)
		if LVT1cNq8QJpdKA94bGf53vPStyg.button1: LVT1cNq8QJpdKA94bGf53vPStyg.getControl(mmV2nucZ5Lpl6FO1JMPEqGoQKW(u"࠿࠰࠲࠳஗")).setEnabled(gBExoceumj4y8bFW9hY2aNMVSr)
		if LVT1cNq8QJpdKA94bGf53vPStyg.button2: LVT1cNq8QJpdKA94bGf53vPStyg.getControl(sjtU6GZQg5XC2pH4(u"࠹࠱࠳࠵஘")).setEnabled(gBExoceumj4y8bFW9hY2aNMVSr)
	def dShvBTVoFGkatzJj(LVT1cNq8QJpdKA94bGf53vPStyg):
		LVT1cNq8QJpdKA94bGf53vPStyg.close()
		try: RPbaxsNFVTwek5Kfv21DiJuzCnjMZp.remove(LVT1cNq8QJpdKA94bGf53vPStyg.image_filename)
		except: pass
def iG7Rz2kmn0x1yLNMV3u8O(*aargs,**kkwargs):
	if aargs:
		direction = aargs[vvXoMLlg513]
		WWY8eD3uCfLFNyR0wJXpZUT6S7 = aargs[mZi0S72jGoHpLO]
		if not direction: direction = c2RKu0xG1eC8MiohyE(u"ࠨࡥࡨࡲࡹ࡫ࡲࠨ૸")
		if not WWY8eD3uCfLFNyR0wJXpZUT6S7: WWY8eD3uCfLFNyR0wJXpZUT6S7 = fWoVd0Bmtkx(u"ࠩสืฯ๋ัศำࠪૹ")
		lowSfvhZIUHz = aargs[Zwqio2AIWlD5etFa]
		Z4vQNwLcAiPVufj9sOgCMU6ezEWG = ZLwoRpfnCWI7FgEHsz6te39lMVh.join(aargs[Ie5s2cBtSfdHjzQ4rA9kYlo6D18(u"࠴ங"):])
	else: direction,WWY8eD3uCfLFNyR0wJXpZUT6S7,lowSfvhZIUHz,Z4vQNwLcAiPVufj9sOgCMU6ezEWG = qpFY4hAwolV3,N3flV6EJsD5CzS(u"ࠪࡓࡐ࠭ૺ"),qpFY4hAwolV3,qpFY4hAwolV3
	eVLmAIGFiwpr94UK6MRP5(direction,qpFY4hAwolV3,WWY8eD3uCfLFNyR0wJXpZUT6S7,qpFY4hAwolV3,lowSfvhZIUHz,Z4vQNwLcAiPVufj9sOgCMU6ezEWG,**kkwargs)
	return
def VVpbtSKYUGXrNMwAWFo9IOjZP(*aargs,**kkwargs):
	direction = aargs[vvXoMLlg513]
	ir7tcdom69TaX2CUjAz5GEbpuxV = aargs[mZi0S72jGoHpLO]
	xRYGdtij60sXwElZaS = aargs[Zwqio2AIWlD5etFa]
	if xRYGdtij60sXwElZaS or ir7tcdom69TaX2CUjAz5GEbpuxV: GG6hjY3ISg7WUC1qVEa8dO = gBExoceumj4y8bFW9hY2aNMVSr
	else: GG6hjY3ISg7WUC1qVEa8dO = ag8rjZo1Vz4IPdcOT
	lowSfvhZIUHz = aargs[DAE6vkyhXGx1wBdHmcFfTVQpL0l]
	Z4vQNwLcAiPVufj9sOgCMU6ezEWG = aargs[wn4bG51vUENfaS0Zg]
	if not direction: direction = mmV2nucZ5Lpl6FO1JMPEqGoQKW(u"ࠫࡨ࡫࡮ࡵࡧࡵࠫૻ")
	if not ir7tcdom69TaX2CUjAz5GEbpuxV: ir7tcdom69TaX2CUjAz5GEbpuxV = tQMjXKCA5dN4xq3beVIzaEoWkFLg(u"้ࠬไศࠢࠣࡒࡴ࠭ૼ")
	if not xRYGdtij60sXwElZaS: xRYGdtij60sXwElZaS = qoBMmfAWpFlK70xw8ZRh4naJ(u"࠭ๆฺ็ࠣࠤ࡞࡫ࡳࠨ૽")
	if len(aargs)>=tR1krDGPpO025fghMT3a7UnYj(u"࠹஛"): Z4vQNwLcAiPVufj9sOgCMU6ezEWG += ZLwoRpfnCWI7FgEHsz6te39lMVh+aargs[rNdBKI74fAklnoCZ6(u"࠷ச")]
	if len(aargs)>=LZWMikPEB81KSGyxfJtUsCA(u"࠻ஜ"): Z4vQNwLcAiPVufj9sOgCMU6ezEWG += ZLwoRpfnCWI7FgEHsz6te39lMVh+aargs[qoBMmfAWpFlK70xw8ZRh4naJ(u"࠻஝")]
	muaCBROQ72TixfPh683Y59qH = eVLmAIGFiwpr94UK6MRP5(direction,ir7tcdom69TaX2CUjAz5GEbpuxV,qpFY4hAwolV3,xRYGdtij60sXwElZaS,lowSfvhZIUHz,Z4vQNwLcAiPVufj9sOgCMU6ezEWG,**kkwargs)
	if muaCBROQ72TixfPh683Y59qH==-fWoVd0Bmtkx(u"࠷ஞ") and GG6hjY3ISg7WUC1qVEa8dO: muaCBROQ72TixfPh683Y59qH = -mZi0S72jGoHpLO
	elif muaCBROQ72TixfPh683Y59qH==-mZi0S72jGoHpLO and not GG6hjY3ISg7WUC1qVEa8dO: muaCBROQ72TixfPh683Y59qH = ag8rjZo1Vz4IPdcOT
	elif muaCBROQ72TixfPh683Y59qH==vvXoMLlg513: muaCBROQ72TixfPh683Y59qH = ag8rjZo1Vz4IPdcOT
	elif muaCBROQ72TixfPh683Y59qH==Zwqio2AIWlD5etFa: muaCBROQ72TixfPh683Y59qH = gBExoceumj4y8bFW9hY2aNMVSr
	return muaCBROQ72TixfPh683Y59qH
def xVzqWbrFXJ(*aargs,**kkwargs):
	return q5Kah0DftjNzV.Dialog().select(*aargs,**kkwargs)
def t8yiLuJp3cBA6d1QE9x7eZ4fa(*args,**kwargs):
	lowSfvhZIUHz = args[vvXoMLlg513]
	Z4vQNwLcAiPVufj9sOgCMU6ezEWG = args[mZi0S72jGoHpLO]
	if len(args) > Zwqio2AIWlD5etFa and iNc3KxwErnQ(u"ࠧࡵ࡫ࡰࡩࠬ૾") not in str(args[tR1krDGPpO025fghMT3a7UnYj(u"࠲ட")]):
		fuoGWX5ITb0pkiEqaUrtcMg6xvwsLO = args[Zwqio2AIWlD5etFa]
		thr9qLTiZXcbAdY3yMkFJlSK1RuDzf = kwargs.get(UUDAiytEL76RTmMYsuIz5evXB(u"ࠨࡶ࡬ࡱࡪ࠭૿"), dJHDqiKf12TXlIzSLkGUuxg4MBs3A(u"࠲࠲࠳࠴஠"))
	else:
		fuoGWX5ITb0pkiEqaUrtcMg6xvwsLO = ddiCzu6yahj5RtTISMJ48sNnZBU(u"ࠩࡱࡳࡹ࡯ࡦࡪࡥࡤࡸ࡮ࡵ࡮ࡠࡴࡨ࡫ࡺࡲࡡࡳࠩ଀")
		thr9qLTiZXcbAdY3yMkFJlSK1RuDzf = args[Zwqio2AIWlD5etFa] if len(args) > Zwqio2AIWlD5etFa else kwargs.get(fWoVd0Bmtkx(u"ࠪࡸ࡮ࡳࡥࠨଁ"), tR1krDGPpO025fghMT3a7UnYj(u"࠳࠳࠴࠵஡"))
	le9F2xYip3HbnC86AQ7WDZovJEhU = MqWf2atLi7QDnOF0YKuZhrE53gbv1(daemon=gBExoceumj4y8bFW9hY2aNMVSr,target=SALlZgVi1yI7QD20JeK4vMTW,args=(lowSfvhZIUHz,Z4vQNwLcAiPVufj9sOgCMU6ezEWG,fuoGWX5ITb0pkiEqaUrtcMg6xvwsLO,thr9qLTiZXcbAdY3yMkFJlSK1RuDzf))
	le9F2xYip3HbnC86AQ7WDZovJEhU.start()
	return
def SALlZgVi1yI7QD20JeK4vMTW(lowSfvhZIUHz,Z4vQNwLcAiPVufj9sOgCMU6ezEWG,fuoGWX5ITb0pkiEqaUrtcMg6xvwsLO,thr9qLTiZXcbAdY3yMkFJlSK1RuDzf):
	WXqcLE042zfIB7xma8O = fuoGWX5ITb0pkiEqaUrtcMg6xvwsLO.replace(RlOvin8YIGC2KZXJPk9m0acrMobUex(u"ࠫࡳࡵࡴࡪࡨ࡬ࡧࡦࡺࡩࡰࡰࡢࠫଂ"),qpFY4hAwolV3)
	import XU4bsNc16i
	name = XU4bsNc16i.iyEOYZTQV32LshS1(gBExoceumj4y8bFW9hY2aNMVSr,WXqcLE042zfIB7xma8O+sjtU6GZQg5XC2pH4(u"ࠬࠦ࠭ࠡࠩଃ")+lowSfvhZIUHz+ddiCzu6yahj5RtTISMJ48sNnZBU(u"࠭ࠠ࠮ࠢࠪ଄")+Z4vQNwLcAiPVufj9sOgCMU6ezEWG)
	name = XU4bsNc16i.GmlDbno5psqtUL9XrS(name)
	image_filename = RPbaxsNFVTwek5Kfv21DiJuzCnjMZp.path.join(Zu3GVXgayRFDmHOoQqv6h9dtEY0eAN,name+BRWqdruz2A0(u"ࠧ࠯ࡲࡱ࡫ࠬଅ"))
	if RPbaxsNFVTwek5Kfv21DiJuzCnjMZp.path.exists(image_filename):
		if fuoGWX5ITb0pkiEqaUrtcMg6xvwsLO==lljaEqwTVtmKsQcOrbXxS5hgNH(u"ࠨࡰࡲࡸ࡮࡬ࡩࡤࡣࡷ࡭ࡴࡴ࡟ࡳࡧࡪࡹࡱࡧࡲࠨଆ"): image_height = YY8UDX3MJhb91AHw7fg(u"࠴࠵࠼஢")
		elif fuoGWX5ITb0pkiEqaUrtcMg6xvwsLO==YY8UDX3MJhb91AHw7fg(u"ࠩࡱࡳࡹ࡯ࡦࡪࡥࡤࡸ࡮ࡵ࡮ࡠࡣࡸࡸࡴ࠭ଇ"): image_height = CC1eY6yWZUwf2TkRvnp7EJ0AimjHBX(u"࠶࠶࠶ண")
	else: image_height = gKlm29ifcJNFzvIujqbZtBG(qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,lowSfvhZIUHz,Z4vQNwLcAiPVufj9sOgCMU6ezEWG,fuoGWX5ITb0pkiEqaUrtcMg6xvwsLO,l1DZAt9XNQjqE7YOdrz(u"ࠪࡰࡪ࡬ࡴࠨଈ"),ag8rjZo1Vz4IPdcOT,image_filename)
	JJ1KCFbIDXyq7Rv6YzalGMcem = OJNCZ1gTvjdS8xQt(DiJ8CMuYH1daWyjehfN0L(u"ࠫࡉ࡯ࡡ࡭ࡱࡪࡒࡴࡺࡩࡧ࡫ࡦࡥࡹ࡯࡯࡯ࡋࡰࡥ࡬࡫࠮ࡹ࡯࡯ࠫଉ"),mFGa34JHCw9LWlB0,qoBMmfAWpFlK70xw8ZRh4naJ(u"ࠬࡊࡥࡧࡣࡸࡰࡹ࠭ଊ"),dJHDqiKf12TXlIzSLkGUuxg4MBs3A(u"࠭࠷࠳࠲ࡳࠫଋ"))
	JJ1KCFbIDXyq7Rv6YzalGMcem.show()
	if fuoGWX5ITb0pkiEqaUrtcMg6xvwsLO==qoBMmfAWpFlK70xw8ZRh4naJ(u"ࠧ࡯ࡱࡷ࡭࡫࡯ࡣࡢࡶ࡬ࡳࡳࡥࡡࡶࡶࡲࠫଌ"):
		JJ1KCFbIDXyq7Rv6YzalGMcem.getControl(CC1eY6yWZUwf2TkRvnp7EJ0AimjHBX(u"࠿࠰࠵࠲஥")).setHeight(YY8UDX3MJhb91AHw7fg(u"࠷࠷࠵த"))
		JJ1KCFbIDXyq7Rv6YzalGMcem.getControl(BRWqdruz2A0(u"࠻࠳࠸࠵ந")).setPosition(lljaEqwTVtmKsQcOrbXxS5hgNH(u"࠵࠶஦"),-l1DZAt9XNQjqE7YOdrz(u"࠹࠲஧"))
		JJ1KCFbIDXyq7Rv6YzalGMcem.getControl(qqzwE6imYG4c2xojI(u"࠼࠴࠺࠶ன")).setPosition(dJHDqiKf12TXlIzSLkGUuxg4MBs3A(u"࠵࠷࠶ப"),-fWoVd0Bmtkx(u"࠻࠶஫"))
		JJ1KCFbIDXyq7Rv6YzalGMcem.getControl(IaBhDMJc17302LgSvyxd(u"࠵࠲࠳ம")).setPosition(aXqWLoTdVgME(u"࠿࠰஬"),-l32dnTEOU1skGKqeBtI9hmo(u"࠳࠶஭"))
	JJ1KCFbIDXyq7Rv6YzalGMcem.getControl(kYDaz79TFlXoR(u"࠶࠳࠵ய")).setVisible(ag8rjZo1Vz4IPdcOT)
	JJ1KCFbIDXyq7Rv6YzalGMcem.getControl(aXqWLoTdVgME(u"࠷࠴࠷ர")).setVisible(ag8rjZo1Vz4IPdcOT)
	JJ1KCFbIDXyq7Rv6YzalGMcem.getControl(iNc3KxwErnQ(u"࠽࠵࠻࠰ற")).setImage(image_filename)
	JJ1KCFbIDXyq7Rv6YzalGMcem.getControl(V3VlkhgjEF4n1erPXHcC0NOsfwyAJ(u"࠾࠶࠵࠱ல")).setHeight(image_height)
	s7FnXZYOgexlH2MPb8BJck1AKv9.sleep(thr9qLTiZXcbAdY3yMkFJlSK1RuDzf/aXqWLoTdVgME(u"࠷࠰࠱࠲࠱࠴ள"))
	return
def fGChDJbmZANnS(*aargs,**kkwargs):
	lowSfvhZIUHz,Z4vQNwLcAiPVufj9sOgCMU6ezEWG,profile,direction = qpFY4hAwolV3,qpFY4hAwolV3,YY8UDX3MJhb91AHw7fg(u"ࠨࡶࡨࡼࡹࡼࡩࡦࡹࡢࡦ࡮࡭ࡦࡰࡰࡷࡣࡱࡵ࡮ࡨࠩ଍"),c2RKu0xG1eC8MiohyE(u"ࠩ࡯ࡩ࡫ࡺࠧ଎")
	if len(aargs)>=mZi0S72jGoHpLO: lowSfvhZIUHz = aargs[vvXoMLlg513]
	if len(aargs)>=Zwqio2AIWlD5etFa: Z4vQNwLcAiPVufj9sOgCMU6ezEWG = aargs[mZi0S72jGoHpLO]
	if len(aargs)>=DAE6vkyhXGx1wBdHmcFfTVQpL0l: profile = aargs[Zwqio2AIWlD5etFa]
	if len(aargs)>=wn4bG51vUENfaS0Zg: direction = aargs[DAE6vkyhXGx1wBdHmcFfTVQpL0l]
	return W2fBJaUN9kZwVeR1n0o4Dc(direction,lowSfvhZIUHz,Z4vQNwLcAiPVufj9sOgCMU6ezEWG,profile)
def UpqiBMsKgPF9wZQGv3zEx7Nf(*aargs,**kkwargs):
	return q5Kah0DftjNzV.Dialog().contextmenu(*aargs,**kkwargs)
def NEhkcLiSVUeIm(*aargs,**kkwargs):
	return q5Kah0DftjNzV.Dialog().browseSingle(*aargs,**kkwargs)
def LhVtyjDJAxpkHXgRmS35nKuT(*aargs,**kkwargs):
	return q5Kah0DftjNzV.Dialog().input(*aargs,**kkwargs)
def W4HCP0bkSsNZlXp(*aargs,**kkwargs):
	return q5Kah0DftjNzV.DialogProgress(*aargs,**kkwargs)
def eVLmAIGFiwpr94UK6MRP5(direction,button0=qpFY4hAwolV3,button1=qpFY4hAwolV3,button2=qpFY4hAwolV3,lowSfvhZIUHz=qpFY4hAwolV3,Z4vQNwLcAiPVufj9sOgCMU6ezEWG=qpFY4hAwolV3,profile=aXqWLoTdVgME(u"ࠪࡧࡴࡴࡦࡪࡴࡰࡣࡧ࡯ࡧࡧࡱࡱࡸࠬଏ"),D2pF3qWMQrOobA5H61edT=vvXoMLlg513,q3qYvVyuhKAkOt5T=vvXoMLlg513):
	if not direction: direction = UUDAiytEL76RTmMYsuIz5evXB(u"ࠫࡨ࡫࡮ࡵࡧࡵࠫଐ")
	JJ1KCFbIDXyq7Rv6YzalGMcem = GiTBNZQIou29VR1vPx0myMg(UUDAiytEL76RTmMYsuIz5evXB(u"ࠬࡊࡩࡢ࡮ࡲ࡫ࡈࡵ࡮ࡧ࡫ࡵࡱ࡙࡮ࡲࡦࡧࡅࡹࡹࡺ࡯࡯ࡵ࠱ࡼࡲࡲࠧ଑"),mFGa34JHCw9LWlB0,l32dnTEOU1skGKqeBtI9hmo(u"࠭ࡄࡦࡨࡤࡹࡱࡺࠧ଒"),CC1eY6yWZUwf2TkRvnp7EJ0AimjHBX(u"ࠧ࠸࠴࠳ࡴࠬଓ"))
	JJ1KCFbIDXyq7Rv6YzalGMcem.mxUlpDMvro5Akgs4WduwK(button0,button1,button2,lowSfvhZIUHz,Z4vQNwLcAiPVufj9sOgCMU6ezEWG,profile,direction,D2pF3qWMQrOobA5H61edT,q3qYvVyuhKAkOt5T)
	if D2pF3qWMQrOobA5H61edT>vvXoMLlg513: JJ1KCFbIDXyq7Rv6YzalGMcem.SSWxPJVK1Hg5sMEy()
	if q3qYvVyuhKAkOt5T>vvXoMLlg513: JJ1KCFbIDXyq7Rv6YzalGMcem.PzfQ35O8Ce9v0bI()
	if D2pF3qWMQrOobA5H61edT==vvXoMLlg513 and q3qYvVyuhKAkOt5T==vvXoMLlg513: JJ1KCFbIDXyq7Rv6YzalGMcem.n53M0ubimCco2xhpNWRDSHj8g()
	JJ1KCFbIDXyq7Rv6YzalGMcem.doModal()
	muaCBROQ72TixfPh683Y59qH = JJ1KCFbIDXyq7Rv6YzalGMcem.choiceID
	return muaCBROQ72TixfPh683Y59qH
def W2fBJaUN9kZwVeR1n0o4Dc(direction,lowSfvhZIUHz,Z4vQNwLcAiPVufj9sOgCMU6ezEWG,profile=qqzwE6imYG4c2xojI(u"ࠨࡶࡨࡼࡹࡼࡩࡦࡹࡢࡦ࡮࡭ࡦࡰࡰࡷࡣࡱࡵ࡮ࡨࠩଔ")):
	if not direction: direction = dJHDqiKf12TXlIzSLkGUuxg4MBs3A(u"ࠩ࡯ࡩ࡫ࡺࠧକ")
	JJ1KCFbIDXyq7Rv6YzalGMcem = OJNCZ1gTvjdS8xQt(IaBhDMJc17302LgSvyxd(u"ࠪࡈ࡮ࡧ࡬ࡰࡩࡗࡩࡽࡺࡖࡪࡧࡺࡩࡷࡌࡵ࡭࡮ࡖࡧࡷ࡫ࡥ࡯࠰ࡻࡱࡱ࠭ଖ"),mFGa34JHCw9LWlB0,UVa3fJw7k6KM(u"ࠫࡉ࡫ࡦࡢࡷ࡯ࡸࠬଗ"),Ie5s2cBtSfdHjzQ4rA9kYlo6D18(u"ࠬ࠽࠲࠱ࡲࠪଘ"))
	image_filename = GGyUh9CxSiHDrcMJ5d.replace(RlOvin8YIGC2KZXJPk9m0acrMobUex(u"࠭࡟࠱࠲࠳࠴ࡤ࠭ଙ"),lljaEqwTVtmKsQcOrbXxS5hgNH(u"ࠧࡠࠩଚ")+str(s7FnXZYOgexlH2MPb8BJck1AKv9.time())+kYDaz79TFlXoR(u"ࠨࡡࠪଛ"))
	image_filename = image_filename.replace(l32dnTEOU1skGKqeBtI9hmo(u"ࠩ࡟ࡠࠬଜ"),RlOvin8YIGC2KZXJPk9m0acrMobUex(u"ࠪࡠࡡࡢ࡜ࠨଝ")).replace(ttrDbyV5cSO2FjgTzew6qM,LZWMikPEB81KSGyxfJtUsCA(u"ࠫ࠴࠵࠯࠰ࠩଞ"))
	image_height = gKlm29ifcJNFzvIujqbZtBG(qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,lowSfvhZIUHz,Z4vQNwLcAiPVufj9sOgCMU6ezEWG,profile,direction,ag8rjZo1Vz4IPdcOT,image_filename)
	JJ1KCFbIDXyq7Rv6YzalGMcem.show()
	JJ1KCFbIDXyq7Rv6YzalGMcem.getControl(BRWqdruz2A0(u"࠹࠱࠷࠳ழ")).setHeight(image_height)
	JJ1KCFbIDXyq7Rv6YzalGMcem.getControl(DaFZHsThGmd0zv6e(u"࠺࠲࠸࠴வ")).setImage(image_filename)
	GGmfcn2jy9M6lBtpgA3v = JJ1KCFbIDXyq7Rv6YzalGMcem.doModal()
	try: RPbaxsNFVTwek5Kfv21DiJuzCnjMZp.remove(image_filename)
	except: pass
	return GGmfcn2jy9M6lBtpgA3v
def gKlm29ifcJNFzvIujqbZtBG(kefxybcuQmPsVOdR2hAgz3nS6EYB,H5ROEXl094,ppqECyrMYh7GS6as,Wg7JuPLGVU5i6,HY7yaJeI89xE56sbTjdBRZPDwQKFX,zxyvBIL19YHtmX5akFZ,X3XfwMdGq50rSg,pZlm0X6MyzJnaQEu95hF3WPY,hkBoj7PI6R):
	GaKFDvxNUl = RPbaxsNFVTwek5Kfv21DiJuzCnjMZp.path.dirname(hkBoj7PI6R)
	if not RPbaxsNFVTwek5Kfv21DiJuzCnjMZp.path.exists(GaKFDvxNUl):
		try: RPbaxsNFVTwek5Kfv21DiJuzCnjMZp.makedirs(GaKFDvxNUl)
		except: pass
	uuJ2xy9rXUREfGha = OOlHhBkWt7oQy1G6pIwMuzjePsxiFa(zxyvBIL19YHtmX5akFZ)
	clDmuzrjOnfJVG6 = x7TsrYeqh96ivn1XDa0JbUyGZFfjmo(uuJ2xy9rXUREfGha,kefxybcuQmPsVOdR2hAgz3nS6EYB,H5ROEXl094,ppqECyrMYh7GS6as,Wg7JuPLGVU5i6,HY7yaJeI89xE56sbTjdBRZPDwQKFX,zxyvBIL19YHtmX5akFZ,X3XfwMdGq50rSg,pZlm0X6MyzJnaQEu95hF3WPY,hkBoj7PI6R)
	return clDmuzrjOnfJVG6
def OOlHhBkWt7oQy1G6pIwMuzjePsxiFa(zxyvBIL19YHtmX5akFZ):
	xCRPQEH0blTKzYone7AJGdavLDOmS = Y719atFWlPpbO6uTULjZf5VGD2o0
	rAiqvNJTL6UFyWjp81HgOD7s4KlGf = IaBhDMJc17302LgSvyxd(u"࠴࠳ஶ")
	JxLpAuzwngeKMkhIC = iNc3KxwErnQ(u"࠵࠴ஷ")
	CLghBNpEr6e7G5R = vvXoMLlg513
	pbNxaUhsMt84ko3CDJfvZ = tR1krDGPpO025fghMT3a7UnYj(u"ࠬࡩࡥ࡯ࡶࡨࡶࠬଟ")
	yJfgmjAVNaWBqwKlQE = vvXoMLlg513
	dZ60Hih7gUR83z5 = sjtU6GZQg5XC2pH4(u"࠵࠾ஸ")
	ocDZp52PChJISeq84YH0MywjVvQT1 = DaFZHsThGmd0zv6e(u"࠸࠶ஹ")
	ZFE70uGyQSDnXLJlCaTedOvwp9 = RlOvin8YIGC2KZXJPk9m0acrMobUex(u"࠾஺")
	ccAYlymbSgjzTsJeXoEI = gBExoceumj4y8bFW9hY2aNMVSr
	MMxaOeFBi1HX9oGNbPEkD = aXqWLoTdVgME(u"࠳࠸࠷஻")
	IIxLuymM9pYWjO = ddiCzu6yahj5RtTISMJ48sNnZBU(u"࠵࠳࠳஼")
	FUQ215DSyuhAk7 = LZWMikPEB81KSGyxfJtUsCA(u"࠷࠳஽")
	wpRvgM0BaSOnX3VC5WhHeml = RlOvin8YIGC2KZXJPk9m0acrMobUex(u"࠵࠼࠵ா")
	f1CsG8tDaxA34 = qqzwE6imYG4c2xojI(u"࠶࠽ி")
	zC0vr4nLufpHBcwMeQER = Y719atFWlPpbO6uTULjZf5VGD2o0
	CaR3nGswv4cVk91ejD7Jb08IMuSYTK = vvXoMLlg513
	c0WFJMnLszoITQB24KVpX6lS = V3VlkhgjEF4n1erPXHcC0NOsfwyAJ(u"࠸࠷ீ")
	FFwANhmZHQPEds824JTCU3VcKoL = [CC1eY6yWZUwf2TkRvnp7EJ0AimjHBX(u"࠴࠸௃"),c2RKu0xG1eC8MiohyE(u"࠹࠲ு"),zYvEaigKWjoq50pXBLDbGJkFc(u"࠲࠹ூ")]
	from PIL import ImageDraw as h0hk8x6lPiWFEXf1U,ImageFont as QICFUT4M827xecVqjXNudy,Image as ntKANFzB4GqyD
	if ddiCzu6yahj5RtTISMJ48sNnZBU(u"࠭࡮ࡰࡶ࡬ࡪ࡮ࡩࡡࡵ࡫ࡲࡲࠬଠ") in zxyvBIL19YHtmX5akFZ:
		if zxyvBIL19YHtmX5akFZ==N3flV6EJsD5CzS(u"ࠧ࡯ࡱࡷ࡭࡫࡯ࡣࡢࡶ࡬ࡳࡳࡥࡲࡦࡩࡸࡰࡦࡸࠧଡ"):
			Dyv7xCEIOUgLN = Ie5s2cBtSfdHjzQ4rA9kYlo6D18(u"࠳࠴࠻௄")
			pbNxaUhsMt84ko3CDJfvZ = rNdBKI74fAklnoCZ6(u"ࠨ࡮ࡨࡪࡹ࠭ଢ")
			ccAYlymbSgjzTsJeXoEI = ag8rjZo1Vz4IPdcOT
		elif zxyvBIL19YHtmX5akFZ==lljaEqwTVtmKsQcOrbXxS5hgNH(u"ࠩࡱࡳࡹ࡯ࡦࡪࡥࡤࡸ࡮ࡵ࡮ࡠࡣࡸࡸࡴ࠭ଣ"):
			Dyv7xCEIOUgLN = aXqWLoTdVgME(u"࡙ࠪࡕࡖࡅࡓࠩତ")
			pbNxaUhsMt84ko3CDJfvZ = UVa3fJw7k6KM(u"ࠫࡷ࡯ࡧࡩࡶࠪଥ")
			CLghBNpEr6e7G5R = iNc3KxwErnQ(u"࠴࠴௅")
		TT0K2DocCQBthgPkVepOYZJHS = IaBhDMJc17302LgSvyxd(u"࠻࠷࠶ெ")
		FFwANhmZHQPEds824JTCU3VcKoL = [YY8UDX3MJhb91AHw7fg(u"࠸࠹ே"),YY8UDX3MJhb91AHw7fg(u"࠸࠹ே"),YY8UDX3MJhb91AHw7fg(u"࠸࠹ே")]
		JxLpAuzwngeKMkhIC = fWoVd0Bmtkx(u"࠸࠰ை")
		rAiqvNJTL6UFyWjp81HgOD7s4KlGf = vvXoMLlg513
		ocDZp52PChJISeq84YH0MywjVvQT1 = V3VlkhgjEF4n1erPXHcC0NOsfwyAJ(u"࠲࠱௉")
		dZ60Hih7gUR83z5 = l32dnTEOU1skGKqeBtI9hmo(u"࠴࠷ொ")
	elif zxyvBIL19YHtmX5akFZ==LZWMikPEB81KSGyxfJtUsCA(u"ࠬࡳࡥ࡯ࡷࡢ࡭ࡹ࡫࡭ࠨଦ"):
		FFwANhmZHQPEds824JTCU3VcKoL,TT0K2DocCQBthgPkVepOYZJHS,Dyv7xCEIOUgLN = [kYDaz79TFlXoR(u"࠶࠽்"),kYDaz79TFlXoR(u"࠶࠽்"),kYDaz79TFlXoR(u"࠶࠽்")],qoBMmfAWpFlK70xw8ZRh4naJ(u"࠴࠳࠴ோ"),RlOvin8YIGC2KZXJPk9m0acrMobUex(u"࠵࠹࠵ௌ")
		yJfgmjAVNaWBqwKlQE,ocDZp52PChJISeq84YH0MywjVvQT1,dZ60Hih7gUR83z5, = vvXoMLlg513,-mmV2nucZ5Lpl6FO1JMPEqGoQKW(u"࠶࠸௎"),-BRWqdruz2A0(u"࠹࠰௏")
		rAiqvNJTL6UFyWjp81HgOD7s4KlGf = vvXoMLlg513
		Ks6noyx245ivqCwNktzg = ntKANFzB4GqyD.open(ilIOUWdy2X3qrMCvstpgwBbhYSA1xj)
		h5hnD4cFtEbprvPsAO = ntKANFzB4GqyD.new(UUDAiytEL76RTmMYsuIz5evXB(u"࠭ࡒࡈࡄࡄࠫଧ"),(TT0K2DocCQBthgPkVepOYZJHS,Dyv7xCEIOUgLN),(mmV2nucZ5Lpl6FO1JMPEqGoQKW(u"࠲࠶࠷ௐ"),vvXoMLlg513,vvXoMLlg513,mmV2nucZ5Lpl6FO1JMPEqGoQKW(u"࠲࠶࠷ௐ")))
	elif zxyvBIL19YHtmX5akFZ==rNdBKI74fAklnoCZ6(u"ࠧࡤࡱࡱࡪ࡮ࡸ࡭ࡠࡵࡰࡥࡱࡲࡦࡰࡰࡷࠫନ"): FFwANhmZHQPEds824JTCU3VcKoL,Dyv7xCEIOUgLN,TT0K2DocCQBthgPkVepOYZJHS = [BRWqdruz2A0(u"࠶࠽௔"),CC1eY6yWZUwf2TkRvnp7EJ0AimjHBX(u"࠳࠶௑"),l1DZAt9XNQjqE7YOdrz(u"࠴࠳௒")],aXqWLoTdVgME(u"࠺࠶࠰௕"),mmV2nucZ5Lpl6FO1JMPEqGoQKW(u"࠼࠴࠵௓")
	elif zxyvBIL19YHtmX5akFZ==sjtU6GZQg5XC2pH4(u"ࠨࡥࡲࡲ࡫࡯ࡲ࡮ࡡࡰࡩࡩ࡯ࡵ࡮ࡨࡲࡲࡹ࠭଩"): FFwANhmZHQPEds824JTCU3VcKoL,Dyv7xCEIOUgLN,TT0K2DocCQBthgPkVepOYZJHS = [UUDAiytEL76RTmMYsuIz5evXB(u"࠳࠳ௗ"),lljaEqwTVtmKsQcOrbXxS5hgNH(u"࠴࠻௙"),LZWMikPEB81KSGyxfJtUsCA(u"࠸࠴௖")],dJHDqiKf12TXlIzSLkGUuxg4MBs3A(u"࠸࠴࠵௚"),ddiCzu6yahj5RtTISMJ48sNnZBU(u"࠺࠲࠳௘")
	elif zxyvBIL19YHtmX5akFZ==kYDaz79TFlXoR(u"ࠩࡦࡳࡳ࡬ࡩࡳ࡯ࡢࡦ࡮࡭ࡦࡰࡰࡷࠫପ"): FFwANhmZHQPEds824JTCU3VcKoL,Dyv7xCEIOUgLN,TT0K2DocCQBthgPkVepOYZJHS = [UVa3fJw7k6KM(u"࠳࠷௞"),DiJ8CMuYH1daWyjehfN0L(u"࠷࠷௛"),kYDaz79TFlXoR(u"࠸࠸௝")],zYvEaigKWjoq50pXBLDbGJkFc(u"࠶࠲࠳௟"),DiJ8CMuYH1daWyjehfN0L(u"࠾࠶࠰௜")
	elif zxyvBIL19YHtmX5akFZ==UVa3fJw7k6KM(u"ࠪࡸࡪࡾࡴࡷ࡫ࡨࡻࡤࡨࡩࡨࡨࡲࡲࡹ࠭ଫ"): Dyv7xCEIOUgLN,TT0K2DocCQBthgPkVepOYZJHS = IaBhDMJc17302LgSvyxd(u"࠹࠷࠴௠"),l1DZAt9XNQjqE7YOdrz(u"࠴࠶࠼࠶௡")
	elif zxyvBIL19YHtmX5akFZ==l32dnTEOU1skGKqeBtI9hmo(u"ࠫࡹ࡫ࡸࡵࡸ࡬ࡩࡼࡥࡢࡪࡩࡩࡳࡳࡺ࡟࡭ࡱࡱ࡫ࠬବ"): Dyv7xCEIOUgLN,TT0K2DocCQBthgPkVepOYZJHS = qoBMmfAWpFlK70xw8ZRh4naJ(u"࡛ࠬࡐࡑࡇࡕࠫଭ"),qqzwE6imYG4c2xojI(u"࠵࠷࠽࠰௢")
	elif zxyvBIL19YHtmX5akFZ==mmV2nucZ5Lpl6FO1JMPEqGoQKW(u"࠭ࡴࡦࡺࡷࡺ࡮࡫ࡷࡠࡵࡰࡥࡱࡲࡦࡰࡰࡷࠫମ"): FFwANhmZHQPEds824JTCU3VcKoL,Dyv7xCEIOUgLN,TT0K2DocCQBthgPkVepOYZJHS = [dJHDqiKf12TXlIzSLkGUuxg4MBs3A(u"࠳࠺௦"),tR1krDGPpO025fghMT3a7UnYj(u"࠴࠶௧"),qoBMmfAWpFlK70xw8ZRh4naJ(u"࠷࠸௤")],zYvEaigKWjoq50pXBLDbGJkFc(u"࠼࠺࠰௣"),c2RKu0xG1eC8MiohyE(u"࠱࠳࠹࠳௥")
	elif zxyvBIL19YHtmX5akFZ==RlOvin8YIGC2KZXJPk9m0acrMobUex(u"ࠧࡵࡧࡻࡸࡻ࡯ࡥࡸࡡࡶࡱࡦࡲ࡬ࡧࡱࡱࡸࡤࡲ࡯࡯ࡩࠪଯ"): FFwANhmZHQPEds824JTCU3VcKoL,Dyv7xCEIOUgLN,TT0K2DocCQBthgPkVepOYZJHS = [UUDAiytEL76RTmMYsuIz5evXB(u"࠷࠾௪"),qoBMmfAWpFlK70xw8ZRh4naJ(u"࠸࠳௫"),UUDAiytEL76RTmMYsuIz5evXB(u"࠵࠽௩")],ddiCzu6yahj5RtTISMJ48sNnZBU(u"ࠨࡗࡓࡔࡊࡘࠧର"),V3VlkhgjEF4n1erPXHcC0NOsfwyAJ(u"࠴࠶࠼࠶௨")
	FPTS6jNi3HeyXztro,cINruvjCyMgTeOP,K645toXiuOgRL7qPC0amcJvI2UY = FFwANhmZHQPEds824JTCU3VcKoL
	ivFW6JXSj83ETp0bRmy = QICFUT4M827xecVqjXNudy.truetype(IiP4daTz9wSrXfjobZKh8,size=FPTS6jNi3HeyXztro)
	wus37LFSN5Zl2kDfXpTY09aijW = QICFUT4M827xecVqjXNudy.truetype(IiP4daTz9wSrXfjobZKh8,size=cINruvjCyMgTeOP)
	Hqd61OWVYSMbrmlB = QICFUT4M827xecVqjXNudy.truetype(IiP4daTz9wSrXfjobZKh8,size=K645toXiuOgRL7qPC0amcJvI2UY)
	MGsojKFNDk2btIU5 = TT0K2DocCQBthgPkVepOYZJHS-ocDZp52PChJISeq84YH0MywjVvQT1*Zwqio2AIWlD5etFa
	f9gX7xKLiAYzSVq5UQtj = ntKANFzB4GqyD.new(viRJWOC5jsYe84(u"ࠩࡕࡋࡇࡇࠧ଱"),(MGsojKFNDk2btIU5,ddiCzu6yahj5RtTISMJ48sNnZBU(u"࠱࠱࠲௬")),(RlOvin8YIGC2KZXJPk9m0acrMobUex(u"࠳࠷࠸௭"),RlOvin8YIGC2KZXJPk9m0acrMobUex(u"࠳࠷࠸௭"),RlOvin8YIGC2KZXJPk9m0acrMobUex(u"࠳࠷࠸௭"),vvXoMLlg513))
	RufAqwxbzIWn = h0hk8x6lPiWFEXf1U.Draw(f9gX7xKLiAYzSVq5UQtj)
	XmDvGUn0eWC7wirQFE,KBVQnrGFOCX = RufAqwxbzIWn.textsize(CC1eY6yWZUwf2TkRvnp7EJ0AimjHBX(u"ࠪࡌࡍࡎࠠࡃࡄࡅࠤ࠽࠾࠸ࠡ࠲࠳࠴ࠬଲ"),font=ivFW6JXSj83ETp0bRmy)
	sOPENnGaCXtSrmFju,PBsEbL2Xr65CTQYnthSm0oK = RufAqwxbzIWn.textsize(rNdBKI74fAklnoCZ6(u"ࠫࡍࡎࡈࠡࡄࡅࡆࠥ࠾࠸࠹ࠢ࠳࠴࠵࠭ଳ"),font=wus37LFSN5Zl2kDfXpTY09aijW)
	h2ULCTdkjb = {Ie5s2cBtSfdHjzQ4rA9kYlo6D18(u"ࠬࡪࡥ࡭ࡧࡷࡩࡤ࡮ࡡࡳࡣ࡮ࡥࡹ࠭଴"):ag8rjZo1Vz4IPdcOT,UVa3fJw7k6KM(u"࠭ࡳࡶࡲࡳࡳࡷࡺ࡟࡭࡫ࡪࡥࡹࡻࡲࡦࡵࠪଵ"):gBExoceumj4y8bFW9hY2aNMVSr,LZWMikPEB81KSGyxfJtUsCA(u"ࠧࡂࡔࡄࡆࡎࡉࠠࡍࡋࡊࡅ࡙࡛ࡒࡆࠢࡄࡐࡑࡇࡈࠨଶ"):ag8rjZo1Vz4IPdcOT}
	from arabic_reshaper import ArabicReshaper as nR1B7VeXyNTcuopQ
	NtAqwQhgHfCGWylapd4rVL = nR1B7VeXyNTcuopQ(configuration=h2ULCTdkjb)
	uuJ2xy9rXUREfGha = {}
	lBgwrbdHGI8QSajCv06Mi2XOZRN = locals()
	for f79ZnTkH0m45a1vj63xuQSd in lBgwrbdHGI8QSajCv06Mi2XOZRN: uuJ2xy9rXUREfGha[f79ZnTkH0m45a1vj63xuQSd] = lBgwrbdHGI8QSajCv06Mi2XOZRN[f79ZnTkH0m45a1vj63xuQSd]
	return uuJ2xy9rXUREfGha
def x7TsrYeqh96ivn1XDa0JbUyGZFfjmo(uuJ2xy9rXUREfGha,kefxybcuQmPsVOdR2hAgz3nS6EYB,H5ROEXl094,ppqECyrMYh7GS6as,Wg7JuPLGVU5i6,HY7yaJeI89xE56sbTjdBRZPDwQKFX,zxyvBIL19YHtmX5akFZ,X3XfwMdGq50rSg,pZlm0X6MyzJnaQEu95hF3WPY,hkBoj7PI6R):
	for f79ZnTkH0m45a1vj63xuQSd in uuJ2xy9rXUREfGha: globals()[f79ZnTkH0m45a1vj63xuQSd] = uuJ2xy9rXUREfGha[f79ZnTkH0m45a1vj63xuQSd]
	global f1CsG8tDaxA34,zC0vr4nLufpHBcwMeQER
	if zxyvBIL19YHtmX5akFZ!=l32dnTEOU1skGKqeBtI9hmo(u"ࠨ࡯ࡨࡲࡺࡥࡩࡵࡧࡰࠫଷ"):
		rRj4Dqt6c7iWvmauJnKYOUxB = gdPslyFW8ITBcpA302.getSetting(RlOvin8YIGC2KZXJPk9m0acrMobUex(u"ࠩࡤࡺ࠳ࡲࡡ࡯ࡩࡸࡥ࡬࡫࠮ࡵࡴࡤࡲࡸࡲࡡࡵࡧࠪସ"))
		if rRj4Dqt6c7iWvmauJnKYOUxB:
			if kefxybcuQmPsVOdR2hAgz3nS6EYB==aXqWLoTdVgME(u"๊ࠪ฾๋࡛ࠠࠡࡨࡷࠬହ"): kefxybcuQmPsVOdR2hAgz3nS6EYB = aXqWLoTdVgME(u"ࠫ࡞࡫ࡳࠨ଺")
			elif kefxybcuQmPsVOdR2hAgz3nS6EYB==kYDaz79TFlXoR(u"้ࠬไศࠢࠣࡒࡴ࠭଻"): kefxybcuQmPsVOdR2hAgz3nS6EYB = UVa3fJw7k6KM(u"࠭ࡎࡰ଼ࠩ")
			if H5ROEXl094==qoBMmfAWpFlK70xw8ZRh4naJ(u"ࠧ็฻่ࠤࠥ࡟ࡥࡴࠩଽ"): H5ROEXl094 = CC1eY6yWZUwf2TkRvnp7EJ0AimjHBX(u"ࠨ࡛ࡨࡷࠬା")
			elif H5ROEXl094==V3VlkhgjEF4n1erPXHcC0NOsfwyAJ(u"ࠩๆ่ฬࠦࠠࡏࡱࠪି"): H5ROEXl094 = BRWqdruz2A0(u"ࠪࡒࡴ࠭ୀ")
			if ppqECyrMYh7GS6as==V3VlkhgjEF4n1erPXHcC0NOsfwyAJ(u"๋ࠫ฿ๅࠡࠢ࡜ࡩࡸ࠭ୁ"): ppqECyrMYh7GS6as = ddiCzu6yahj5RtTISMJ48sNnZBU(u"ࠬ࡟ࡥࡴࠩୂ")
			elif ppqECyrMYh7GS6as==lljaEqwTVtmKsQcOrbXxS5hgNH(u"࠭ใๅษࠣࠤࡓࡵࠧୃ"): ppqECyrMYh7GS6as = N3flV6EJsD5CzS(u"ࠧࡏࡱࠪୄ")
			import XU4bsNc16i
			slKYBZe0zC3WF6XSunQar = XU4bsNc16i.wxHJ7QuA5Uzi([kefxybcuQmPsVOdR2hAgz3nS6EYB,H5ROEXl094,ppqECyrMYh7GS6as,Wg7JuPLGVU5i6,HY7yaJeI89xE56sbTjdBRZPDwQKFX])
			if slKYBZe0zC3WF6XSunQar: kefxybcuQmPsVOdR2hAgz3nS6EYB,H5ROEXl094,ppqECyrMYh7GS6as,Wg7JuPLGVU5i6,HY7yaJeI89xE56sbTjdBRZPDwQKFX = slKYBZe0zC3WF6XSunQar
	if NJwViHDTMdmO0xnALqQ9voPalC3Ip:
		HY7yaJeI89xE56sbTjdBRZPDwQKFX = HY7yaJeI89xE56sbTjdBRZPDwQKFX.decode(nV3Tip6XsH1rJw79DPOU)
		Wg7JuPLGVU5i6 = Wg7JuPLGVU5i6.decode(nV3Tip6XsH1rJw79DPOU)
		kefxybcuQmPsVOdR2hAgz3nS6EYB = kefxybcuQmPsVOdR2hAgz3nS6EYB.decode(nV3Tip6XsH1rJw79DPOU)
		H5ROEXl094 = H5ROEXl094.decode(nV3Tip6XsH1rJw79DPOU)
		ppqECyrMYh7GS6as = ppqECyrMYh7GS6as.decode(nV3Tip6XsH1rJw79DPOU)
	qTUWGzMX3rKbp9nZN7Bk4l = Wg7JuPLGVU5i6.count(ZLwoRpfnCWI7FgEHsz6te39lMVh)+mZi0S72jGoHpLO
	rzysWjla93EwSgdqH5AYn = rAiqvNJTL6UFyWjp81HgOD7s4KlGf+qTUWGzMX3rKbp9nZN7Bk4l*(KBVQnrGFOCX+CLghBNpEr6e7G5R)-CLghBNpEr6e7G5R
	if HY7yaJeI89xE56sbTjdBRZPDwQKFX:
		zaLji9kKNo5ODG = PBsEbL2Xr65CTQYnthSm0oK+ZFE70uGyQSDnXLJlCaTedOvwp9
		Xplnj29weELFJAMTZUI1fBQ7Pq5iYG = NtAqwQhgHfCGWylapd4rVL.reshape(HY7yaJeI89xE56sbTjdBRZPDwQKFX)
		if ccAYlymbSgjzTsJeXoEI:
			ngk1NzJSae85WOhy4du0LQw7TvF = YqSPcW8btnFKwO1JQfVrovhCNe(RufAqwxbzIWn,wus37LFSN5Zl2kDfXpTY09aijW,Xplnj29weELFJAMTZUI1fBQ7Pq5iYG,cINruvjCyMgTeOP,MGsojKFNDk2btIU5,zaLji9kKNo5ODG)
			MApFPVTv0Qwh6Sazfjo489s5 = OF2XGkApDRwz3vgsy0Mdf(ngk1NzJSae85WOhy4du0LQw7TvF)
			MavEmKV8u6P2T7z1i = MApFPVTv0Qwh6Sazfjo489s5.count(ZLwoRpfnCWI7FgEHsz6te39lMVh)+mZi0S72jGoHpLO
			fa24hAML5BukITon8 = dZ60Hih7gUR83z5+MavEmKV8u6P2T7z1i*zaLji9kKNo5ODG-ZFE70uGyQSDnXLJlCaTedOvwp9
		else:
			fa24hAML5BukITon8 = dZ60Hih7gUR83z5+PBsEbL2Xr65CTQYnthSm0oK
			MApFPVTv0Qwh6Sazfjo489s5 = Xplnj29weELFJAMTZUI1fBQ7Pq5iYG.split(ZLwoRpfnCWI7FgEHsz6te39lMVh)[vvXoMLlg513]
			ngk1NzJSae85WOhy4du0LQw7TvF = Xplnj29weELFJAMTZUI1fBQ7Pq5iYG.split(ZLwoRpfnCWI7FgEHsz6te39lMVh)[vvXoMLlg513]
	else: fa24hAML5BukITon8 = dZ60Hih7gUR83z5
	iE79WVCdUHb = CaR3nGswv4cVk91ejD7Jb08IMuSYTK+c0WFJMnLszoITQB24KVpX6lS
	if pZlm0X6MyzJnaQEu95hF3WPY:
		aotIq6SdjJwHph2mXi0e = IIxLuymM9pYWjO-MMxaOeFBi1HX9oGNbPEkD
		iE79WVCdUHb += aotIq6SdjJwHph2mXi0e
	else: aotIq6SdjJwHph2mXi0e = vvXoMLlg513
	if kefxybcuQmPsVOdR2hAgz3nS6EYB or H5ROEXl094 or ppqECyrMYh7GS6as: iE79WVCdUHb += FUQ215DSyuhAk7
	clDmuzrjOnfJVG6 = Dyv7xCEIOUgLN if Dyv7xCEIOUgLN!=sjtU6GZQg5XC2pH4(u"ࠨࡗࡓࡔࡊࡘࠧ୅") else rzysWjla93EwSgdqH5AYn+fa24hAML5BukITon8+iE79WVCdUHb
	f9gX7xKLiAYzSVq5UQtj = ntKANFzB4GqyD.new(BRWqdruz2A0(u"ࠩࡕࡋࡇࡇࠧ୆"),(TT0K2DocCQBthgPkVepOYZJHS,clDmuzrjOnfJVG6),(YY8UDX3MJhb91AHw7fg(u"࠴࠸࠹௮"),YY8UDX3MJhb91AHw7fg(u"࠴࠸࠹௮"),YY8UDX3MJhb91AHw7fg(u"࠴࠸࠹௮"),vvXoMLlg513))
	JLdP9WrYnF = h0hk8x6lPiWFEXf1U.Draw(f9gX7xKLiAYzSVq5UQtj)
	hKnC8PiLGJNBruI7xMQF2mY3 = clDmuzrjOnfJVG6-rzysWjla93EwSgdqH5AYn-iE79WVCdUHb-dZ60Hih7gUR83z5
	if not H5ROEXl094 and kefxybcuQmPsVOdR2hAgz3nS6EYB and ppqECyrMYh7GS6as:
		f1CsG8tDaxA34 += fWoVd0Bmtkx(u"࠴࠴࠺௯")
		zC0vr4nLufpHBcwMeQER -= UUDAiytEL76RTmMYsuIz5evXB(u"࠵࠶࠶௰")
	import bidi.algorithm as B4BgYe6SZcIobzPEUDHQs5kyiV
	if Wg7JuPLGVU5i6:
		pKIVZ40fkanYFTPrLR5bHU9 = rAiqvNJTL6UFyWjp81HgOD7s4KlGf
		Wg7JuPLGVU5i6 = B4BgYe6SZcIobzPEUDHQs5kyiV.get_display(NtAqwQhgHfCGWylapd4rVL.reshape(Wg7JuPLGVU5i6))
		ooW8A4LRvgDeIr0CNO = Wg7JuPLGVU5i6.splitlines()
		for wYeU08VTvm3fXJ in ooW8A4LRvgDeIr0CNO:
			if wYeU08VTvm3fXJ:
				UsQJn65e43qRYItF,vtLOSnuUo8RsT9Ch = JLdP9WrYnF.textsize(wYeU08VTvm3fXJ,font=ivFW6JXSj83ETp0bRmy)
				if pbNxaUhsMt84ko3CDJfvZ==kYDaz79TFlXoR(u"ࠪࡧࡪࡴࡴࡦࡴࠪେ"): Bfpz3YeAw8VHtimqs7PLnrW0ZK9 = xCRPQEH0blTKzYone7AJGdavLDOmS+(TT0K2DocCQBthgPkVepOYZJHS-UsQJn65e43qRYItF)/Zwqio2AIWlD5etFa
				elif pbNxaUhsMt84ko3CDJfvZ==qqzwE6imYG4c2xojI(u"ࠫࡷ࡯ࡧࡩࡶࠪୈ"): Bfpz3YeAw8VHtimqs7PLnrW0ZK9 = xCRPQEH0blTKzYone7AJGdavLDOmS+TT0K2DocCQBthgPkVepOYZJHS-UsQJn65e43qRYItF-JxLpAuzwngeKMkhIC
				elif pbNxaUhsMt84ko3CDJfvZ==tR1krDGPpO025fghMT3a7UnYj(u"ࠬࡲࡥࡧࡶࠪ୉"): Bfpz3YeAw8VHtimqs7PLnrW0ZK9 = xCRPQEH0blTKzYone7AJGdavLDOmS+JxLpAuzwngeKMkhIC
				JLdP9WrYnF.text((Bfpz3YeAw8VHtimqs7PLnrW0ZK9,pKIVZ40fkanYFTPrLR5bHU9),wYeU08VTvm3fXJ,font=ivFW6JXSj83ETp0bRmy,fill=c2RKu0xG1eC8MiohyE(u"࠭ࡹࡦ࡮࡯ࡳࡼ࠭୊"))
			pKIVZ40fkanYFTPrLR5bHU9 += FPTS6jNi3HeyXztro+CLghBNpEr6e7G5R
	if kefxybcuQmPsVOdR2hAgz3nS6EYB or H5ROEXl094 or ppqECyrMYh7GS6as:
		qrVBZnhDX5Wza6KY9 = rzysWjla93EwSgdqH5AYn+hKnC8PiLGJNBruI7xMQF2mY3+dZ60Hih7gUR83z5+aotIq6SdjJwHph2mXi0e+CaR3nGswv4cVk91ejD7Jb08IMuSYTK
		if kefxybcuQmPsVOdR2hAgz3nS6EYB:
			kefxybcuQmPsVOdR2hAgz3nS6EYB = B4BgYe6SZcIobzPEUDHQs5kyiV.get_display(NtAqwQhgHfCGWylapd4rVL.reshape(kefxybcuQmPsVOdR2hAgz3nS6EYB))
			KKzUMdsQcthI5FeTn7Z,g1AawXfGWU = JLdP9WrYnF.textsize(kefxybcuQmPsVOdR2hAgz3nS6EYB,font=Hqd61OWVYSMbrmlB)
			EdgFpIqxiMSYyX3WaJZ02UReHbG = f1CsG8tDaxA34+vvXoMLlg513*(zC0vr4nLufpHBcwMeQER+wpRvgM0BaSOnX3VC5WhHeml)+(wpRvgM0BaSOnX3VC5WhHeml-KKzUMdsQcthI5FeTn7Z)/Zwqio2AIWlD5etFa
			JLdP9WrYnF.text((EdgFpIqxiMSYyX3WaJZ02UReHbG,qrVBZnhDX5Wza6KY9),kefxybcuQmPsVOdR2hAgz3nS6EYB,font=Hqd61OWVYSMbrmlB,fill=viRJWOC5jsYe84(u"ࠧࡺࡧ࡯ࡰࡴࡽࠧୋ"))
		if H5ROEXl094:
			H5ROEXl094 = B4BgYe6SZcIobzPEUDHQs5kyiV.get_display(NtAqwQhgHfCGWylapd4rVL.reshape(H5ROEXl094))
			ZiP9YSn16zg,tmGCBxWahc14ZiKyue = JLdP9WrYnF.textsize(H5ROEXl094,font=Hqd61OWVYSMbrmlB)
			ovqDKrfsXpTWCJMaiGBYRZd752 = f1CsG8tDaxA34+mZi0S72jGoHpLO*(zC0vr4nLufpHBcwMeQER+wpRvgM0BaSOnX3VC5WhHeml)+(wpRvgM0BaSOnX3VC5WhHeml-ZiP9YSn16zg)/Zwqio2AIWlD5etFa
			JLdP9WrYnF.text((ovqDKrfsXpTWCJMaiGBYRZd752,qrVBZnhDX5Wza6KY9),H5ROEXl094,font=Hqd61OWVYSMbrmlB,fill=ddiCzu6yahj5RtTISMJ48sNnZBU(u"ࠨࡻࡨࡰࡱࡵࡷࠨୌ"))
		if ppqECyrMYh7GS6as:
			ppqECyrMYh7GS6as = B4BgYe6SZcIobzPEUDHQs5kyiV.get_display(NtAqwQhgHfCGWylapd4rVL.reshape(ppqECyrMYh7GS6as))
			iizyDH4FqdYwsp,wDObnVlo4mkdr0CQJfuWcsLK2a = JLdP9WrYnF.textsize(ppqECyrMYh7GS6as,font=Hqd61OWVYSMbrmlB)
			kmvasTNCQIhoKVng1G = f1CsG8tDaxA34+Zwqio2AIWlD5etFa*(zC0vr4nLufpHBcwMeQER+wpRvgM0BaSOnX3VC5WhHeml)+(wpRvgM0BaSOnX3VC5WhHeml-iizyDH4FqdYwsp)/Zwqio2AIWlD5etFa
			JLdP9WrYnF.text((kmvasTNCQIhoKVng1G,qrVBZnhDX5Wza6KY9),ppqECyrMYh7GS6as,font=Hqd61OWVYSMbrmlB,fill=rNdBKI74fAklnoCZ6(u"ࠩࡼࡩࡱࡲ࡯ࡸ୍ࠩ"))
	if HY7yaJeI89xE56sbTjdBRZPDwQKFX:
		ulyJVxM0zG27,qpJkSsEd0Q3MAWoVrC = [],[]
		ngk1NzJSae85WOhy4du0LQw7TvF = WTtB1JGVOAxnQPymqN5M0HUe9(ngk1NzJSae85WOhy4du0LQw7TvF)
		B5hcl2ba6WV = ngk1NzJSae85WOhy4du0LQw7TvF.split(BRWqdruz2A0(u"ࠪࡣࡸࡹࡳࡠࡡࡱࡩࡼࡲࡩ࡯ࡧࡢࠫ୎"))
		for HHQbUVZN8r0K1XMs7GD4qu5Rjp in B5hcl2ba6WV:
			LnqPKgOmCeV3dNu2aA7Ght0 = X3XfwMdGq50rSg
			if   DiJ8CMuYH1daWyjehfN0L(u"ࠫࡤࡹࡳࡴࡡࡢࡰ࡮ࡴࡥ࡭ࡧࡩࡸࡤ࠭୏") in HHQbUVZN8r0K1XMs7GD4qu5Rjp: LnqPKgOmCeV3dNu2aA7Ght0 = ee86G9ladLHVbh5mikzCo(u"ࠬࡲࡥࡧࡶࠪ୐")
			elif fWoVd0Bmtkx(u"࠭࡟ࡴࡵࡶࡣࡤࡲࡩ࡯ࡧࡵ࡭࡬࡮ࡴࡠࠩ୑") in HHQbUVZN8r0K1XMs7GD4qu5Rjp: LnqPKgOmCeV3dNu2aA7Ght0 = YY8UDX3MJhb91AHw7fg(u"ࠧࡳ࡫ࡪ࡬ࡹ࠭୒")
			elif kYDaz79TFlXoR(u"ࠨࡡࡶࡷࡸࡥ࡟࡭࡫ࡱࡩࡨ࡫࡮ࡵࡧࡵࡣࠬ୓") in HHQbUVZN8r0K1XMs7GD4qu5Rjp: LnqPKgOmCeV3dNu2aA7Ght0 = dJHDqiKf12TXlIzSLkGUuxg4MBs3A(u"ࠩࡦࡩࡳࡺࡥࡳࠩ୔")
			JCTBUIHGDuoy = HHQbUVZN8r0K1XMs7GD4qu5Rjp
			FmeUQhdPWDEfpl = ePhmG1jLD6.findall(qqzwE6imYG4c2xojI(u"ࠪࡣࡸࡹࡳࡠࡡ࠱࠮ࡄࡥࠧ୕"),HHQbUVZN8r0K1XMs7GD4qu5Rjp,ePhmG1jLD6.DOTALL)
			for ZaAnCi56jM8FdXJEWbTfBylQOc in FmeUQhdPWDEfpl: JCTBUIHGDuoy = JCTBUIHGDuoy.replace(ZaAnCi56jM8FdXJEWbTfBylQOc,qpFY4hAwolV3)
			if JCTBUIHGDuoy==qpFY4hAwolV3: UsQJn65e43qRYItF,vtLOSnuUo8RsT9Ch = vvXoMLlg513,zaLji9kKNo5ODG
			else: UsQJn65e43qRYItF,vtLOSnuUo8RsT9Ch = JLdP9WrYnF.textsize(JCTBUIHGDuoy,font=wus37LFSN5Zl2kDfXpTY09aijW)
			if   LnqPKgOmCeV3dNu2aA7Ght0==LZWMikPEB81KSGyxfJtUsCA(u"ࠫࡱ࡫ࡦࡵࠩୖ"): ZegnFNqbGBfIc3m1yYar5Os8 = yJfgmjAVNaWBqwKlQE+ocDZp52PChJISeq84YH0MywjVvQT1
			elif LnqPKgOmCeV3dNu2aA7Ght0==CC1eY6yWZUwf2TkRvnp7EJ0AimjHBX(u"ࠬࡸࡩࡨࡪࡷࠫୗ"): ZegnFNqbGBfIc3m1yYar5Os8 = yJfgmjAVNaWBqwKlQE+ocDZp52PChJISeq84YH0MywjVvQT1+MGsojKFNDk2btIU5-UsQJn65e43qRYItF
			elif LnqPKgOmCeV3dNu2aA7Ght0==c2RKu0xG1eC8MiohyE(u"࠭ࡣࡦࡰࡷࡩࡷ࠭୘"): ZegnFNqbGBfIc3m1yYar5Os8 = yJfgmjAVNaWBqwKlQE+ocDZp52PChJISeq84YH0MywjVvQT1+(MGsojKFNDk2btIU5-UsQJn65e43qRYItF)/Zwqio2AIWlD5etFa
			if ZegnFNqbGBfIc3m1yYar5Os8<ocDZp52PChJISeq84YH0MywjVvQT1: ZegnFNqbGBfIc3m1yYar5Os8 = yJfgmjAVNaWBqwKlQE+ocDZp52PChJISeq84YH0MywjVvQT1
			ulyJVxM0zG27.append(ZegnFNqbGBfIc3m1yYar5Os8)
			qpJkSsEd0Q3MAWoVrC.append(UsQJn65e43qRYItF)
		ZegnFNqbGBfIc3m1yYar5Os8 = ulyJVxM0zG27[vvXoMLlg513]
		hAKNY6sCRpljetVZy5zuxOWXJP = ngk1NzJSae85WOhy4du0LQw7TvF.split(RlOvin8YIGC2KZXJPk9m0acrMobUex(u"ࠧࡠࡵࡶࡷࡤ࠭୙"))
		ww9kWMtN5H = (N3flV6EJsD5CzS(u"࠷࠻࠵௱"),N3flV6EJsD5CzS(u"࠷࠻࠵௱"),N3flV6EJsD5CzS(u"࠷࠻࠵௱"),N3flV6EJsD5CzS(u"࠷࠻࠵௱"))
		ZqJLyHdAT6z7ebGtrs = ww9kWMtN5H
		RRM63l54iFmQI2cvyOqzHBnYPdpjU,j58xzS3K6bQua = vvXoMLlg513,vvXoMLlg513
		SlRTxVQcji8LrF10g2JbNyzCeP = ag8rjZo1Vz4IPdcOT
		HNlc5mDnh9yBZe1qrxQ = vvXoMLlg513
		ddjS7QGm4ue = rzysWjla93EwSgdqH5AYn+dZ60Hih7gUR83z5/Zwqio2AIWlD5etFa
		if fa24hAML5BukITon8<(hKnC8PiLGJNBruI7xMQF2mY3+dZ60Hih7gUR83z5):
			GAZkTWbJR6o = (hKnC8PiLGJNBruI7xMQF2mY3+dZ60Hih7gUR83z5-fa24hAML5BukITon8)/Zwqio2AIWlD5etFa
			ddjS7QGm4ue = rzysWjla93EwSgdqH5AYn+dZ60Hih7gUR83z5+GAZkTWbJR6o-PBsEbL2Xr65CTQYnthSm0oK/Zwqio2AIWlD5etFa
		for wYeU08VTvm3fXJ in hAKNY6sCRpljetVZy5zuxOWXJP:
			if not wYeU08VTvm3fXJ or (wYeU08VTvm3fXJ and ord(wYeU08VTvm3fXJ[vvXoMLlg513])==DiJ8CMuYH1daWyjehfN0L(u"࠼࠵࠳࠹࠼௲")): continue
			JOwxLm94v2ZNRjk38Iftb = wYeU08VTvm3fXJ.split(ee86G9ladLHVbh5mikzCo(u"ࠨࡡࡱࡩࡼࡲࡩ࡯ࡧࡢࠫ୚"),mZi0S72jGoHpLO)
			EMfkV1H2GRbAB86cg = wYeU08VTvm3fXJ.split(iNc3KxwErnQ(u"ࠩࡢࡲࡪࡽࡣࡰ࡮ࡲࡶࠬ୛"),mZi0S72jGoHpLO)
			Q72QcwgYeSWuB5FHb0lOKfJo = wYeU08VTvm3fXJ.split(rNdBKI74fAklnoCZ6(u"ࠪࡣࡪࡴࡤࡤࡱ࡯ࡳࡷࡥࠧଡ଼"),mZi0S72jGoHpLO)
			fSjqBO4rJUQE7ckIi3MP = wYeU08VTvm3fXJ.split(kYDaz79TFlXoR(u"ࠫࡤࡲࡩ࡯ࡧࡵࡸࡱࡥࠧଢ଼"),mZi0S72jGoHpLO)
			NN4xSX5LZU0zyEh2R = wYeU08VTvm3fXJ.split(UUDAiytEL76RTmMYsuIz5evXB(u"ࠬࡥ࡬ࡪࡰࡨࡰࡪ࡬ࡴࡠࠩ୞"),mZi0S72jGoHpLO)
			ac3QzGEnNKDHP45dr = wYeU08VTvm3fXJ.split(DaFZHsThGmd0zv6e(u"࠭࡟࡭࡫ࡱࡩࡷ࡯ࡧࡩࡶࡢࠫୟ"),mZi0S72jGoHpLO)
			WiG789BdZoFuR6rhb = wYeU08VTvm3fXJ.split(tR1krDGPpO025fghMT3a7UnYj(u"ࠧࡠ࡮࡬ࡲࡪࡩࡥ࡯ࡶࡨࡶࡤ࠭ୠ"),mZi0S72jGoHpLO)
			if len(JOwxLm94v2ZNRjk38Iftb)>mZi0S72jGoHpLO:
				HNlc5mDnh9yBZe1qrxQ += mZi0S72jGoHpLO
				wYeU08VTvm3fXJ = JOwxLm94v2ZNRjk38Iftb[mZi0S72jGoHpLO]
				RRM63l54iFmQI2cvyOqzHBnYPdpjU = vvXoMLlg513
				ZegnFNqbGBfIc3m1yYar5Os8 = ulyJVxM0zG27[HNlc5mDnh9yBZe1qrxQ]
				j58xzS3K6bQua += zaLji9kKNo5ODG
				SlRTxVQcji8LrF10g2JbNyzCeP = ag8rjZo1Vz4IPdcOT
			elif len(EMfkV1H2GRbAB86cg)>mZi0S72jGoHpLO:
				wYeU08VTvm3fXJ = EMfkV1H2GRbAB86cg[mZi0S72jGoHpLO]
				ZqJLyHdAT6z7ebGtrs = wYeU08VTvm3fXJ[vvXoMLlg513:aXqWLoTdVgME(u"࠸௳")]
				ZqJLyHdAT6z7ebGtrs = fWoVd0Bmtkx(u"ࠨࠥࠪୡ")+ZqJLyHdAT6z7ebGtrs[Zwqio2AIWlD5etFa:]
				wYeU08VTvm3fXJ = wYeU08VTvm3fXJ[kYDaz79TFlXoR(u"࠺௴"):]
			elif len(Q72QcwgYeSWuB5FHb0lOKfJo)>mZi0S72jGoHpLO:
				wYeU08VTvm3fXJ = Q72QcwgYeSWuB5FHb0lOKfJo[mZi0S72jGoHpLO]
				ZqJLyHdAT6z7ebGtrs = ww9kWMtN5H
			elif len(fSjqBO4rJUQE7ckIi3MP)>mZi0S72jGoHpLO:
				wYeU08VTvm3fXJ = fSjqBO4rJUQE7ckIi3MP[mZi0S72jGoHpLO]
				SlRTxVQcji8LrF10g2JbNyzCeP = gBExoceumj4y8bFW9hY2aNMVSr
				RRM63l54iFmQI2cvyOqzHBnYPdpjU = qpJkSsEd0Q3MAWoVrC[HNlc5mDnh9yBZe1qrxQ]
			elif len(NN4xSX5LZU0zyEh2R)>zYvEaigKWjoq50pXBLDbGJkFc(u"࠳௵"): wYeU08VTvm3fXJ = NN4xSX5LZU0zyEh2R[mZi0S72jGoHpLO]
			elif len(ac3QzGEnNKDHP45dr)>ee86G9ladLHVbh5mikzCo(u"࠴௶"): wYeU08VTvm3fXJ = ac3QzGEnNKDHP45dr[mZi0S72jGoHpLO]
			elif len(WiG789BdZoFuR6rhb)>aXqWLoTdVgME(u"࠵௷"): wYeU08VTvm3fXJ = WiG789BdZoFuR6rhb[mZi0S72jGoHpLO]
			if wYeU08VTvm3fXJ:
				L4Lpu8AYnBVG9zMEjZIe = ddjS7QGm4ue+j58xzS3K6bQua
				wYeU08VTvm3fXJ = B4BgYe6SZcIobzPEUDHQs5kyiV.get_display(wYeU08VTvm3fXJ)
				UsQJn65e43qRYItF,vtLOSnuUo8RsT9Ch = JLdP9WrYnF.textsize(wYeU08VTvm3fXJ,font=wus37LFSN5Zl2kDfXpTY09aijW)
				if SlRTxVQcji8LrF10g2JbNyzCeP: RRM63l54iFmQI2cvyOqzHBnYPdpjU -= UsQJn65e43qRYItF
				lFZD5YHXxdo = ZegnFNqbGBfIc3m1yYar5Os8+RRM63l54iFmQI2cvyOqzHBnYPdpjU
				JLdP9WrYnF.text((lFZD5YHXxdo,L4Lpu8AYnBVG9zMEjZIe),wYeU08VTvm3fXJ,font=wus37LFSN5Zl2kDfXpTY09aijW,fill=ZqJLyHdAT6z7ebGtrs)
				if zxyvBIL19YHtmX5akFZ==l32dnTEOU1skGKqeBtI9hmo(u"ࠩࡰࡩࡳࡻ࡟ࡪࡶࡨࡱࠬୢ"): JLdP9WrYnF.text((lFZD5YHXxdo+mZi0S72jGoHpLO,L4Lpu8AYnBVG9zMEjZIe+mZi0S72jGoHpLO),wYeU08VTvm3fXJ,font=wus37LFSN5Zl2kDfXpTY09aijW,fill=ZqJLyHdAT6z7ebGtrs)
				if not SlRTxVQcji8LrF10g2JbNyzCeP: RRM63l54iFmQI2cvyOqzHBnYPdpjU += UsQJn65e43qRYItF
				if L4Lpu8AYnBVG9zMEjZIe>hKnC8PiLGJNBruI7xMQF2mY3+zaLji9kKNo5ODG: break
	if zxyvBIL19YHtmX5akFZ==aXqWLoTdVgME(u"ࠪࡱࡪࡴࡵࡠ࡫ࡷࡩࡲ࠭ୣ"):
		uVPRb4hHFpxeOlLvtnXAs = Ks6noyx245ivqCwNktzg.copy()
		s7FnXZYOgexlH2MPb8BJck1AKv9.sleep(sjtU6GZQg5XC2pH4(u"࠵࠴࠰࠶௸"))
		uVPRb4hHFpxeOlLvtnXAs.paste(h5hnD4cFtEbprvPsAO,(vvXoMLlg513,vvXoMLlg513),mask=f9gX7xKLiAYzSVq5UQtj)
	else: uVPRb4hHFpxeOlLvtnXAs = f9gX7xKLiAYzSVq5UQtj
	if NJwViHDTMdmO0xnALqQ9voPalC3Ip: hkBoj7PI6R = hkBoj7PI6R.decode(nV3Tip6XsH1rJw79DPOU)
	try: uVPRb4hHFpxeOlLvtnXAs.save(hkBoj7PI6R)
	except UnicodeError:
		if NJwViHDTMdmO0xnALqQ9voPalC3Ip:
			hkBoj7PI6R = hkBoj7PI6R.encode(nV3Tip6XsH1rJw79DPOU)
			uVPRb4hHFpxeOlLvtnXAs.save(hkBoj7PI6R)
	return clDmuzrjOnfJVG6
def YqSPcW8btnFKwO1JQfVrovhCNe(RufAqwxbzIWn,wus37LFSN5Zl2kDfXpTY09aijW,ZWUiRP8jKyJbOgsFhXGzkpLrVwvn,pG35TRoB96SP,MGsojKFNDk2btIU5,bniEatR49vXS17AzI0):
	scUJ3ECm9r8evA6GMI2HS5Db,tCi5DMp91GYzjeAdJTrwoEmBHWKsl,P0FeYnqLk1vUxMg = qpFY4hAwolV3,vvXoMLlg513,qoBMmfAWpFlK70xw8ZRh4naJ(u"࠷࠵࠱࠲࠳௹")
	ZWUiRP8jKyJbOgsFhXGzkpLrVwvn = ZWUiRP8jKyJbOgsFhXGzkpLrVwvn.replace(LZWMikPEB81KSGyxfJtUsCA(u"ࠫࡠࡉࡏࡍࡑࡕࠤࠬ୤"),zYvEaigKWjoq50pXBLDbGJkFc(u"ࠬࡡࡃࡐࡎࡒࡖ࠿ࡀ࠺ࠨ୥"))
	dzYpvbouTFn4EL6m7C9QwJ8DfRKU = MGsojKFNDk2btIU5-pG35TRoB96SP*Zwqio2AIWlD5etFa
	for jNLI7MJc0haHAxsofPRFBDW in ZWUiRP8jKyJbOgsFhXGzkpLrVwvn.splitlines():
		tCi5DMp91GYzjeAdJTrwoEmBHWKsl += bniEatR49vXS17AzI0
		L3C7dyhkxQGXqSrNZwiIKHcg0,Qs0KTGNC8u5qra = vvXoMLlg513,qpFY4hAwolV3
		for rzLwtYBK1A90TkiHxhCW in jNLI7MJc0haHAxsofPRFBDW.split(mIsDke0oK5x1zSiOWbF9thGcA):
			R9CZ6JPxNHlcWDam = OF2XGkApDRwz3vgsy0Mdf(mIsDke0oK5x1zSiOWbF9thGcA+rzLwtYBK1A90TkiHxhCW)
			xxq31CGPrJilfnbucHQXVpmwUTO,quZ89RpGc1n = RufAqwxbzIWn.textsize(R9CZ6JPxNHlcWDam,font=wus37LFSN5Zl2kDfXpTY09aijW)
			if L3C7dyhkxQGXqSrNZwiIKHcg0+xxq31CGPrJilfnbucHQXVpmwUTO<dzYpvbouTFn4EL6m7C9QwJ8DfRKU:
				if not Qs0KTGNC8u5qra: Qs0KTGNC8u5qra += rzLwtYBK1A90TkiHxhCW
				else: Qs0KTGNC8u5qra += mIsDke0oK5x1zSiOWbF9thGcA+rzLwtYBK1A90TkiHxhCW
				L3C7dyhkxQGXqSrNZwiIKHcg0 += xxq31CGPrJilfnbucHQXVpmwUTO
			else:
				if xxq31CGPrJilfnbucHQXVpmwUTO<dzYpvbouTFn4EL6m7C9QwJ8DfRKU:
					Qs0KTGNC8u5qra += CC1eY6yWZUwf2TkRvnp7EJ0AimjHBX(u"࠭࡜࡯ࠢࠪ୦")+rzLwtYBK1A90TkiHxhCW
					tCi5DMp91GYzjeAdJTrwoEmBHWKsl += bniEatR49vXS17AzI0
					L3C7dyhkxQGXqSrNZwiIKHcg0 = xxq31CGPrJilfnbucHQXVpmwUTO
				else:
					while xxq31CGPrJilfnbucHQXVpmwUTO>dzYpvbouTFn4EL6m7C9QwJ8DfRKU:
						for av3QBl1coTFsq9jLgydwf in range(mZi0S72jGoHpLO,len(mIsDke0oK5x1zSiOWbF9thGcA+rzLwtYBK1A90TkiHxhCW),mZi0S72jGoHpLO):
							Q0QP9OpwIABo = mIsDke0oK5x1zSiOWbF9thGcA+rzLwtYBK1A90TkiHxhCW[:av3QBl1coTFsq9jLgydwf]
							jEFxQINP5O9LudtX6J0KbHRcZh = rzLwtYBK1A90TkiHxhCW[av3QBl1coTFsq9jLgydwf:]
							LDTGCF2aurbkpjBQU9 = OF2XGkApDRwz3vgsy0Mdf(Q0QP9OpwIABo)
							rvPyV4C0mjUbSW1kfiaZ5Ap,iwgmycPelBbp7QoYNOH4f0 = RufAqwxbzIWn.textsize(LDTGCF2aurbkpjBQU9,font=wus37LFSN5Zl2kDfXpTY09aijW)
							if L3C7dyhkxQGXqSrNZwiIKHcg0+rvPyV4C0mjUbSW1kfiaZ5Ap>dzYpvbouTFn4EL6m7C9QwJ8DfRKU:
								qndEWMisQCVJgeam = xxq31CGPrJilfnbucHQXVpmwUTO-rvPyV4C0mjUbSW1kfiaZ5Ap
								Qs0KTGNC8u5qra += Q0QP9OpwIABo+ZLwoRpfnCWI7FgEHsz6te39lMVh
								tCi5DMp91GYzjeAdJTrwoEmBHWKsl += bniEatR49vXS17AzI0
								xxq31CGPrJilfnbucHQXVpmwUTO = qndEWMisQCVJgeam
								if qndEWMisQCVJgeam>dzYpvbouTFn4EL6m7C9QwJ8DfRKU:
									L3C7dyhkxQGXqSrNZwiIKHcg0 = vvXoMLlg513
									rzLwtYBK1A90TkiHxhCW = jEFxQINP5O9LudtX6J0KbHRcZh
								else:
									L3C7dyhkxQGXqSrNZwiIKHcg0 = qndEWMisQCVJgeam
									Qs0KTGNC8u5qra += jEFxQINP5O9LudtX6J0KbHRcZh
								break
				if tCi5DMp91GYzjeAdJTrwoEmBHWKsl>P0FeYnqLk1vUxMg: break
		scUJ3ECm9r8evA6GMI2HS5Db += ZLwoRpfnCWI7FgEHsz6te39lMVh+Qs0KTGNC8u5qra
		if tCi5DMp91GYzjeAdJTrwoEmBHWKsl>P0FeYnqLk1vUxMg: break
	scUJ3ECm9r8evA6GMI2HS5Db = scUJ3ECm9r8evA6GMI2HS5Db[mZi0S72jGoHpLO:]
	scUJ3ECm9r8evA6GMI2HS5Db = scUJ3ECm9r8evA6GMI2HS5Db.replace(UUDAiytEL76RTmMYsuIz5evXB(u"ࠧ࡜ࡅࡒࡐࡔࡘ࠺࠻࠼ࠪ୧"),RlOvin8YIGC2KZXJPk9m0acrMobUex(u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࠩ୨"))
	return scUJ3ECm9r8evA6GMI2HS5Db
def OF2XGkApDRwz3vgsy0Mdf(rzLwtYBK1A90TkiHxhCW):
	if aXqWLoTdVgME(u"ࠩ࡞ࠫ୩") in rzLwtYBK1A90TkiHxhCW and lljaEqwTVtmKsQcOrbXxS5hgNH(u"ࠪࡡࠬ୪") in rzLwtYBK1A90TkiHxhCW:
		FmeUQhdPWDEfpl = [fF4lt9zWYxXLKZVyAco82PgMj,l32dnTEOU1skGKqeBtI9hmo(u"ࠫࡠ࠵ࡒࡕࡎࡠࠫ୫"),qoBMmfAWpFlK70xw8ZRh4naJ(u"ࠬࡡ࠯ࡍࡇࡉࡘࡢ࠭୬"),YY8UDX3MJhb91AHw7fg(u"࡛࠭࠰ࡔࡌࡋࡍ࡚࡝ࠨ୭"),YY8UDX3MJhb91AHw7fg(u"ࠧ࡜࠱ࡆࡉࡓ࡚ࡅࡓ࡟ࠪ୮"),l32dnTEOU1skGKqeBtI9hmo(u"ࠨ࡝ࡕࡘࡑࡣࠧ୯"),qqzwE6imYG4c2xojI(u"ࠩ࡞ࡐࡊࡌࡔ࡞ࠩ୰"),kYDaz79TFlXoR(u"ࠪ࡟ࡗࡏࡇࡉࡖࡠࠫୱ"),dJHDqiKf12TXlIzSLkGUuxg4MBs3A(u"ࠫࡠࡉࡅࡏࡖࡈࡖࡢ࠭୲")]
		ofGrxFLER307ZOndT9U4iNbKXgp = ePhmG1jLD6.findall(qoBMmfAWpFlK70xw8ZRh4naJ(u"ࠬࡢ࡛ࡄࡑࡏࡓࡗࠦ࠮ࠫࡁ࡟ࡡࠬ୳"),rzLwtYBK1A90TkiHxhCW,ePhmG1jLD6.DOTALL)
		MYEkXpq74nHWjQ6hVDJ = ePhmG1jLD6.findall(V3VlkhgjEF4n1erPXHcC0NOsfwyAJ(u"࠭࡜࡜ࡅࡒࡐࡔࡘ࠺࠻࠼࠱࠮ࡄࡢ࡝ࠨ୴"),rzLwtYBK1A90TkiHxhCW,ePhmG1jLD6.DOTALL)
		aaXhyq2zgUBcwQvjHLT9edNnI = FmeUQhdPWDEfpl+ofGrxFLER307ZOndT9U4iNbKXgp+MYEkXpq74nHWjQ6hVDJ
		for ZaAnCi56jM8FdXJEWbTfBylQOc in aaXhyq2zgUBcwQvjHLT9edNnI: rzLwtYBK1A90TkiHxhCW = rzLwtYBK1A90TkiHxhCW.replace(ZaAnCi56jM8FdXJEWbTfBylQOc,qpFY4hAwolV3)
	return rzLwtYBK1A90TkiHxhCW
def WTtB1JGVOAxnQPymqN5M0HUe9(HY7yaJeI89xE56sbTjdBRZPDwQKFX):
	HY7yaJeI89xE56sbTjdBRZPDwQKFX = HY7yaJeI89xE56sbTjdBRZPDwQKFX.replace(ZLwoRpfnCWI7FgEHsz6te39lMVh,BRWqdruz2A0(u"ࠧࡠࡵࡶࡷࡤࡥ࡮ࡦࡹ࡯࡭ࡳ࡫࡟ࠨ୵"))
	HY7yaJeI89xE56sbTjdBRZPDwQKFX = HY7yaJeI89xE56sbTjdBRZPDwQKFX.replace(tQMjXKCA5dN4xq3beVIzaEoWkFLg(u"ࠨ࡝ࡕࡘࡑࡣࠧ୶"),viRJWOC5jsYe84(u"ࠩࡢࡷࡸࡹ࡟ࡠ࡮࡬ࡲࡪࡸࡴ࡭ࡡࠪ୷"))
	HY7yaJeI89xE56sbTjdBRZPDwQKFX = HY7yaJeI89xE56sbTjdBRZPDwQKFX.replace(DiJ8CMuYH1daWyjehfN0L(u"ࠪ࡟ࡑࡋࡆࡕ࡟ࠪ୸"),YY8UDX3MJhb91AHw7fg(u"ࠫࡤࡹࡳࡴࡡࡢࡰ࡮ࡴࡥ࡭ࡧࡩࡸࡤ࠭୹"))
	HY7yaJeI89xE56sbTjdBRZPDwQKFX = HY7yaJeI89xE56sbTjdBRZPDwQKFX.replace(Ie5s2cBtSfdHjzQ4rA9kYlo6D18(u"ࠬࡡࡒࡊࡉࡋࡘࡢ࠭୺"),ee86G9ladLHVbh5mikzCo(u"࠭࡟ࡴࡵࡶࡣࡤࡲࡩ࡯ࡧࡵ࡭࡬࡮ࡴࡠࠩ୻"))
	HY7yaJeI89xE56sbTjdBRZPDwQKFX = HY7yaJeI89xE56sbTjdBRZPDwQKFX.replace(N3flV6EJsD5CzS(u"ࠧ࡜ࡅࡈࡒ࡙ࡋࡒ࡞ࠩ୼"),ee86G9ladLHVbh5mikzCo(u"ࠨࡡࡶࡷࡸࡥ࡟࡭࡫ࡱࡩࡨ࡫࡮ࡵࡧࡵࡣࠬ୽"))
	HY7yaJeI89xE56sbTjdBRZPDwQKFX = HY7yaJeI89xE56sbTjdBRZPDwQKFX.replace(fF4lt9zWYxXLKZVyAco82PgMj,zYvEaigKWjoq50pXBLDbGJkFc(u"ࠩࡢࡷࡸࡹ࡟ࡠࡧࡱࡨࡨࡵ࡬ࡰࡴࡢࠫ୾"))
	NFl68cYeQRgZnx1iGswmSH = ePhmG1jLD6.findall(Ie5s2cBtSfdHjzQ4rA9kYlo6D18(u"ࠪࡠࡠࡉࡏࡍࡑࡕࠤ࠭࠴ࠪࡀࠫ࡟ࡡࠬ୿"),HY7yaJeI89xE56sbTjdBRZPDwQKFX,ePhmG1jLD6.DOTALL)
	for cTLln7Zpqd4 in NFl68cYeQRgZnx1iGswmSH: HY7yaJeI89xE56sbTjdBRZPDwQKFX = HY7yaJeI89xE56sbTjdBRZPDwQKFX.replace(qqzwE6imYG4c2xojI(u"ࠫࡠࡉࡏࡍࡑࡕࠤࠬ஀")+cTLln7Zpqd4+tR1krDGPpO025fghMT3a7UnYj(u"ࠬࡣࠧ஁"),tQMjXKCA5dN4xq3beVIzaEoWkFLg(u"࠭࡟ࡴࡵࡶࡣࡤࡴࡥࡸࡥࡲࡰࡴࡸࠧஂ")+cTLln7Zpqd4+l1DZAt9XNQjqE7YOdrz(u"ࠧࡠࠩஃ"))
	return HY7yaJeI89xE56sbTjdBRZPDwQKFX