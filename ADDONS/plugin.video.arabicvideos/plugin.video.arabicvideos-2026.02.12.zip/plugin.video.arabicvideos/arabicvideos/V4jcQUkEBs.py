﻿# -*- coding: utf-8 -*-
from pSfaryIjBo import *
Q8Q0IDc6PLZajJAdTntKUmSGXz = 'ALMAAREF'
headers = {'User-Agent':qpFY4hAwolV3}
wwSFijdVJn1QgHW = '_MRF_'
ddBxj51bhNtaK23lDyGMVw = i4bFG3rKE6.SITESURLS[Q8Q0IDc6PLZajJAdTntKUmSGXz][0]
YEIA19ehBwpNfPVzK = ['التواصل الاجتماعي','صور التواصل الاجتماعي','أرشيف جميع البرامج']
def vTNE2Ck1sGnugJYW8y39aLcSH64U(mode,url,text,i02wfPp5EM):
	if   mode==40: MOTjA5H9XFs = nRVAZc4Dp8PSrGU3xBk()
	elif mode==41: MOTjA5H9XFs = A2ajuOxflTL3GQpZhdgi()
	elif mode==42: MOTjA5H9XFs = eeCKx6MB3QUES4jmOV(text,i02wfPp5EM)
	elif mode==43: MOTjA5H9XFs = mzcAeyplZV(url)
	elif mode==44: MOTjA5H9XFs = c8U1BdtxOZS5FH(text,i02wfPp5EM)
	elif mode==49: MOTjA5H9XFs = PPqUACSE3VcGLTvw05jHy9JrFNW(text)
	else: MOTjA5H9XFs = False
	return MOTjA5H9XFs
def nRVAZc4Dp8PSrGU3xBk():
	x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+'بحث في الموقع',qpFY4hAwolV3,49)
	x3WSXnKyPhjqfHG2UrtQs('link',xupTj02bvy3O8R+' ===== ===== ===== '+fF4lt9zWYxXLKZVyAco82PgMj,qpFY4hAwolV3,9999)
	x3WSXnKyPhjqfHG2UrtQs('live',wwSFijdVJn1QgHW+'البث الحي لقناة المعارف',qpFY4hAwolV3,41)
	eeCKx6MB3QUES4jmOV(qpFY4hAwolV3,'1')
	return
def VzOUl6Qpa9jbJqKA8m0(LBylNhMdH6OV1qGk0tWiXFg3,uVrMPvwSzULsgXtq60JY):
	search,sort,ewzAB1OTpg7mEo65Vq8lZ4tLf,n1uwH0oJaGZ5WBd,VR92tig0IkbqrLSYy = qpFY4hAwolV3,[],[],[],[]
	oF67yxKdB8nY3TiH9gAMvlOhaPSws0,vP8fSn3Nol6GH0AzjwU9h7r5Idas = D02sQSgOGhTJxtKyFEId74Nrv8bYU(LBylNhMdH6OV1qGk0tWiXFg3)
	for FLkeT4nCDqrQMmW6ZSlgyU5jIO32 in list(vP8fSn3Nol6GH0AzjwU9h7r5Idas.keys()):
		value = vP8fSn3Nol6GH0AzjwU9h7r5Idas[FLkeT4nCDqrQMmW6ZSlgyU5jIO32]
		if not value: continue
		if   FLkeT4nCDqrQMmW6ZSlgyU5jIO32=='sort': sort = [value]
		elif FLkeT4nCDqrQMmW6ZSlgyU5jIO32=='series': ewzAB1OTpg7mEo65Vq8lZ4tLf = [value]
		elif FLkeT4nCDqrQMmW6ZSlgyU5jIO32=='search': search = value
		elif FLkeT4nCDqrQMmW6ZSlgyU5jIO32=='category': n1uwH0oJaGZ5WBd = [value]
		elif FLkeT4nCDqrQMmW6ZSlgyU5jIO32=='specialist': VR92tig0IkbqrLSYy = [value]
	GI0fwOUzWlVYaicPdBRunFy = {"action":"facetwp_refresh","data":{"facets":{"search":search,"video_categories":n1uwH0oJaGZ5WBd,"specialist":VR92tig0IkbqrLSYy,"series":ewzAB1OTpg7mEo65Vq8lZ4tLf,"number":[],"sort_video":sort,"count":[],"pagination":[]},"frozen_facets":{},"template":"video_desktop_posts","extras":{"sort":"default"},"soft_refresh":0,"is_bfcache":1,"first_load":0,"paged":int(uVrMPvwSzULsgXtq60JY)}}
	GI0fwOUzWlVYaicPdBRunFy = A3AFYmgZLXn4MBab.dumps(GI0fwOUzWlVYaicPdBRunFy)
	MepIvHBYNArkUOdV37shtJ = 'https://almaaref.ch/wp-json/facetwp/v1/refresh'
	IAW0sh6So3NpqM = WWrExJZS3Bj4anOAkpv7(kUz8c7OqsxuPFIGfwg,'POST',MepIvHBYNArkUOdV37shtJ,GI0fwOUzWlVYaicPdBRunFy,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,'ALMAAREF-REQUEST_DATA_PAGE-1st')
	cmWl9dOKHPIy41iaXuxrY = IAW0sh6So3NpqM.content
	data = wB8NUAidPbqjIr9CFasXvYnxOQpL0g('dict',cmWl9dOKHPIy41iaXuxrY)
	return data
def eeCKx6MB3QUES4jmOV(LBylNhMdH6OV1qGk0tWiXFg3,level):
	HLVwBWJ6mFa3ApoNlq178nuXgI = VzOUl6Qpa9jbJqKA8m0(LBylNhMdH6OV1qGk0tWiXFg3,'1')
	mVYdjvor6i4wZ8 = HLVwBWJ6mFa3ApoNlq178nuXgI['facets']
	if level=='1':
		mVYdjvor6i4wZ8 = mVYdjvor6i4wZ8['video_categories']
		items = ePhmG1jLD6.findall('<div(.*?)/div>',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
		for lkd2oKvZF03qmgMbIfQ6cD in items:
			sgWRIGYQHUhXw5kPzN4OnoZJ1c9 = ePhmG1jLD6.findall('data-value=\\"(.*?)\\".*?display-value\\">(.*?)<',lkd2oKvZF03qmgMbIfQ6cD+'<',ePhmG1jLD6.DOTALL)
			if not sgWRIGYQHUhXw5kPzN4OnoZJ1c9: sgWRIGYQHUhXw5kPzN4OnoZJ1c9 = ePhmG1jLD6.findall('data-value=\\"(.*?)\\">(.*?)<',lkd2oKvZF03qmgMbIfQ6cD+'<',ePhmG1jLD6.DOTALL)
			n1uwH0oJaGZ5WBd,title = sgWRIGYQHUhXw5kPzN4OnoZJ1c9[0]
			if NJwViHDTMdmO0xnALqQ9voPalC3Ip: title = N8E37XwL6iQbmBY(title)
			if not LBylNhMdH6OV1qGk0tWiXFg3: x3WSXnKyPhjqfHG2UrtQs('folder',Q8Q0IDc6PLZajJAdTntKUmSGXz+'_SCRIPT_'+wwSFijdVJn1QgHW+title,qpFY4hAwolV3,42,qpFY4hAwolV3,'2','?category='+n1uwH0oJaGZ5WBd)
			else: x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+title,qpFY4hAwolV3,42,qpFY4hAwolV3,'2',LBylNhMdH6OV1qGk0tWiXFg3+'&category='+n1uwH0oJaGZ5WBd)
	if level=='2':
		mVYdjvor6i4wZ8 = mVYdjvor6i4wZ8['specialist']
		items = ePhmG1jLD6.findall('value="(.*?)".*?>(.*?)<',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
		for VR92tig0IkbqrLSYy,title in items:
			if NJwViHDTMdmO0xnALqQ9voPalC3Ip: title = N8E37XwL6iQbmBY(title)
			if not VR92tig0IkbqrLSYy: title = title = 'الجميع'
			x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+title,qpFY4hAwolV3,42,qpFY4hAwolV3,'3',LBylNhMdH6OV1qGk0tWiXFg3+'&specialist='+VR92tig0IkbqrLSYy)
	elif level=='3':
		mVYdjvor6i4wZ8 = mVYdjvor6i4wZ8['series']
		items = ePhmG1jLD6.findall('value="(.*?)".*?>(.*?)<',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
		for ewzAB1OTpg7mEo65Vq8lZ4tLf,title in items:
			if NJwViHDTMdmO0xnALqQ9voPalC3Ip: title = N8E37XwL6iQbmBY(title)
			if not ewzAB1OTpg7mEo65Vq8lZ4tLf: title = title = 'الجميع'
			x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+title,qpFY4hAwolV3,42,qpFY4hAwolV3,'4',LBylNhMdH6OV1qGk0tWiXFg3+'&series='+ewzAB1OTpg7mEo65Vq8lZ4tLf)
	elif level=='4':
		mVYdjvor6i4wZ8 = mVYdjvor6i4wZ8['sort_video']
		items = ePhmG1jLD6.findall('value="(.*?)".*?>(.*?)<',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
		for sort,title in items:
			if not sort: continue
			if NJwViHDTMdmO0xnALqQ9voPalC3Ip: title = N8E37XwL6iQbmBY(title)
			x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+title,qpFY4hAwolV3,44,qpFY4hAwolV3,'1',LBylNhMdH6OV1qGk0tWiXFg3+'&sort='+sort)
	return
def c8U1BdtxOZS5FH(LBylNhMdH6OV1qGk0tWiXFg3,uVrMPvwSzULsgXtq60JY):
	HLVwBWJ6mFa3ApoNlq178nuXgI = VzOUl6Qpa9jbJqKA8m0(LBylNhMdH6OV1qGk0tWiXFg3,uVrMPvwSzULsgXtq60JY)
	mVYdjvor6i4wZ8 = HLVwBWJ6mFa3ApoNlq178nuXgI['template']
	items = ePhmG1jLD6.findall('src="(.*?)".*?href="(.*?)">(.*?)<',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
	for Sj7rMNYRuQPTtkBvpHKeDW3h,MepIvHBYNArkUOdV37shtJ,title in items:
		if NJwViHDTMdmO0xnALqQ9voPalC3Ip: title = N8E37XwL6iQbmBY(title)
		x3WSXnKyPhjqfHG2UrtQs('video',wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,43,Sj7rMNYRuQPTtkBvpHKeDW3h)
	mVYdjvor6i4wZ8 = HLVwBWJ6mFa3ApoNlq178nuXgI['facets']['pagination']
	items = ePhmG1jLD6.findall('data-page="(.*?)">(.*?)<',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
	for i02wfPp5EM,title in items:
		if uVrMPvwSzULsgXtq60JY==i02wfPp5EM: continue
		if NJwViHDTMdmO0xnALqQ9voPalC3Ip: title = N8E37XwL6iQbmBY(title)
		x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+'صفحة '+title,qpFY4hAwolV3,44,qpFY4hAwolV3,i02wfPp5EM,LBylNhMdH6OV1qGk0tWiXFg3)
	return
def mzcAeyplZV(url):
	IAW0sh6So3NpqM = WWrExJZS3Bj4anOAkpv7(kUz8c7OqsxuPFIGfwg,'GET',url,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,'ALMAAREF-PLAY-1st')
	cmWl9dOKHPIy41iaXuxrY = IAW0sh6So3NpqM.content
	MepIvHBYNArkUOdV37shtJ = ePhmG1jLD6.findall('<video src="(.*?)"',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	if not MepIvHBYNArkUOdV37shtJ: MepIvHBYNArkUOdV37shtJ = ePhmG1jLD6.findall('youtube_url.*?(http.*?)&',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	tiYp9ZdbFTQMcB4vWkHw6LXIAKrN5m = []
	if MepIvHBYNArkUOdV37shtJ:
		MepIvHBYNArkUOdV37shtJ = MepIvHBYNArkUOdV37shtJ[0].replace('\/',ShynO8pN9idCE3)
		tiYp9ZdbFTQMcB4vWkHw6LXIAKrN5m.append(MepIvHBYNArkUOdV37shtJ)
	import inVXFK46ET
	inVXFK46ET.q4qTJvuoQUzM3mZAtegy7IXdnb5wH(tiYp9ZdbFTQMcB4vWkHw6LXIAKrN5m,Q8Q0IDc6PLZajJAdTntKUmSGXz,'video',url)
	return
def A2ajuOxflTL3GQpZhdgi():
	IAW0sh6So3NpqM = WWrExJZS3Bj4anOAkpv7(KOyPvpEztYLaZRdMQJWxfTNFHbkg,'GET',ddBxj51bhNtaK23lDyGMVw+'/البث-المباشر-6',qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,'ALMAAREF-LIVE-1st')
	cmWl9dOKHPIy41iaXuxrY = IAW0sh6So3NpqM.content
	url = ePhmG1jLD6.findall('data-item=.*?(http.*?)&',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	url = url[0].replace('\/',ShynO8pN9idCE3)
	dORtnXbEgi5A8m0CH(url,Q8Q0IDc6PLZajJAdTntKUmSGXz,'live')
	return
def PPqUACSE3VcGLTvw05jHy9JrFNW(search):
	search,LBylNhMdH6OV1qGk0tWiXFg3,showDialogs = LLm3sBXHPcnTDxdE5gt6hz0Wkp(search)
	H1EpSANsX0P = False
	if search==qpFY4hAwolV3:
		search = jXgARlWMLVFUBnvmZwI2o5()
		H1EpSANsX0P = True
	if search==qpFY4hAwolV3: return
	if not H1EpSANsX0P: c8U1BdtxOZS5FH('?search='+search,'1')
	else: eeCKx6MB3QUES4jmOV('?search='+search,'1')
	return