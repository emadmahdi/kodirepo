# -*- coding: utf-8 -*-
import sys as TSRUP0dExYGQg
mgNMJhrjcq1xb = TSRUP0dExYGQg.version_info [0] == 2
lQJvf8UXo2de9gjCatY4yH = 2048
YuTB2OjotvlR = 7
def kk0DKyarxq9eS1zwGLMFQTZN35dj (neqP2if8IOJ50aNKcCBLrXdZk):
	global sWerUpk6nQwT7zY43
	vxdNQUujz7ZFV4rtOSK2 = ord (neqP2if8IOJ50aNKcCBLrXdZk [-1])
	yyshZX35KO7JodYjD9qVib6 = neqP2if8IOJ50aNKcCBLrXdZk [:-1]
	fuKReXJ3HPIAU7c = vxdNQUujz7ZFV4rtOSK2 % len (yyshZX35KO7JodYjD9qVib6)
	EEFQdvXog7LPC4Sie0jDkUKxn6M = yyshZX35KO7JodYjD9qVib6 [:fuKReXJ3HPIAU7c] + yyshZX35KO7JodYjD9qVib6 [fuKReXJ3HPIAU7c:]
	if mgNMJhrjcq1xb:
		Clh5YS0XPue68EgT4Uq17GL = unicode () .join ([unichr (ord (AsGVDZFgmuH06jviYrWXTz) - lQJvf8UXo2de9gjCatY4yH - (XvhDIL4ZpzaPs91WkoGnedCEA2rt + vxdNQUujz7ZFV4rtOSK2) % YuTB2OjotvlR) for XvhDIL4ZpzaPs91WkoGnedCEA2rt, AsGVDZFgmuH06jviYrWXTz in enumerate (EEFQdvXog7LPC4Sie0jDkUKxn6M)])
	else:
		Clh5YS0XPue68EgT4Uq17GL = str () .join ([chr (ord (AsGVDZFgmuH06jviYrWXTz) - lQJvf8UXo2de9gjCatY4yH - (XvhDIL4ZpzaPs91WkoGnedCEA2rt + vxdNQUujz7ZFV4rtOSK2) % YuTB2OjotvlR) for XvhDIL4ZpzaPs91WkoGnedCEA2rt, AsGVDZFgmuH06jviYrWXTz in enumerate (EEFQdvXog7LPC4Sie0jDkUKxn6M)])
	return eval (Clh5YS0XPue68EgT4Uq17GL)
qoBMmfAWpFlK70xw8ZRh4naJ,lljaEqwTVtmKsQcOrbXxS5hgNH,aXqWLoTdVgME=kk0DKyarxq9eS1zwGLMFQTZN35dj,kk0DKyarxq9eS1zwGLMFQTZN35dj,kk0DKyarxq9eS1zwGLMFQTZN35dj
UVa3fJw7k6KM,fWoVd0Bmtkx,tQMjXKCA5dN4xq3beVIzaEoWkFLg=aXqWLoTdVgME,lljaEqwTVtmKsQcOrbXxS5hgNH,qoBMmfAWpFlK70xw8ZRh4naJ
viRJWOC5jsYe84,Ie5s2cBtSfdHjzQ4rA9kYlo6D18,sjtU6GZQg5XC2pH4=tQMjXKCA5dN4xq3beVIzaEoWkFLg,fWoVd0Bmtkx,UVa3fJw7k6KM
LZWMikPEB81KSGyxfJtUsCA,rNdBKI74fAklnoCZ6,BRWqdruz2A0=sjtU6GZQg5XC2pH4,Ie5s2cBtSfdHjzQ4rA9kYlo6D18,viRJWOC5jsYe84
CC1eY6yWZUwf2TkRvnp7EJ0AimjHBX,qqzwE6imYG4c2xojI,N3flV6EJsD5CzS=BRWqdruz2A0,rNdBKI74fAklnoCZ6,LZWMikPEB81KSGyxfJtUsCA
UUDAiytEL76RTmMYsuIz5evXB,IaBhDMJc17302LgSvyxd,ddiCzu6yahj5RtTISMJ48sNnZBU=N3flV6EJsD5CzS,qqzwE6imYG4c2xojI,CC1eY6yWZUwf2TkRvnp7EJ0AimjHBX
dJHDqiKf12TXlIzSLkGUuxg4MBs3A,l1DZAt9XNQjqE7YOdrz,l32dnTEOU1skGKqeBtI9hmo=ddiCzu6yahj5RtTISMJ48sNnZBU,IaBhDMJc17302LgSvyxd,UUDAiytEL76RTmMYsuIz5evXB
zYvEaigKWjoq50pXBLDbGJkFc,iNc3KxwErnQ,V3VlkhgjEF4n1erPXHcC0NOsfwyAJ=l32dnTEOU1skGKqeBtI9hmo,l1DZAt9XNQjqE7YOdrz,dJHDqiKf12TXlIzSLkGUuxg4MBs3A
tR1krDGPpO025fghMT3a7UnYj,c2RKu0xG1eC8MiohyE,RlOvin8YIGC2KZXJPk9m0acrMobUex=V3VlkhgjEF4n1erPXHcC0NOsfwyAJ,iNc3KxwErnQ,zYvEaigKWjoq50pXBLDbGJkFc
YY8UDX3MJhb91AHw7fg,ee86G9ladLHVbh5mikzCo,mmV2nucZ5Lpl6FO1JMPEqGoQKW=RlOvin8YIGC2KZXJPk9m0acrMobUex,c2RKu0xG1eC8MiohyE,tR1krDGPpO025fghMT3a7UnYj
DaFZHsThGmd0zv6e,kYDaz79TFlXoR,DiJ8CMuYH1daWyjehfN0L=mmV2nucZ5Lpl6FO1JMPEqGoQKW,ee86G9ladLHVbh5mikzCo,YY8UDX3MJhb91AHw7fg
from pSfaryIjBo import *
Q8Q0IDc6PLZajJAdTntKUmSGXz = UVa3fJw7k6KM(u"࡙ࠬࡅࡓࡘࡌࡇࡊ࡙ࠧၑ")
def vTNE2Ck1sGnugJYW8y39aLcSH64U(ZyiMa3BXVk2xWG0b,HY7yaJeI89xE56sbTjdBRZPDwQKFX=qpFY4hAwolV3):
	if   ZyiMa3BXVk2xWG0b==qoBMmfAWpFlK70xw8ZRh4naJ(u"࠴ፄ"): sJN4cfwBZgkrWuDiyTeq(HY7yaJeI89xE56sbTjdBRZPDwQKFX)
	elif ZyiMa3BXVk2xWG0b==mmV2nucZ5Lpl6FO1JMPEqGoQKW(u"࠶ፅ"): pass
	elif ZyiMa3BXVk2xWG0b==CC1eY6yWZUwf2TkRvnp7EJ0AimjHBX(u"࠸ፆ"): cSYpMx6W4HlAQK9(HY7yaJeI89xE56sbTjdBRZPDwQKFX)
	elif ZyiMa3BXVk2xWG0b==qoBMmfAWpFlK70xw8ZRh4naJ(u"࠳ፇ"): PbEcuOtyd0lZ4Br8xWo1e2()
	elif ZyiMa3BXVk2xWG0b==BRWqdruz2A0(u"࠵ፈ"): zMDB03n1js(HY7yaJeI89xE56sbTjdBRZPDwQKFX)
	elif ZyiMa3BXVk2xWG0b==zYvEaigKWjoq50pXBLDbGJkFc(u"࠷ፉ"): lc4vWLszopQHmU()
	elif ZyiMa3BXVk2xWG0b==tR1krDGPpO025fghMT3a7UnYj(u"࠹ፊ"): IBWlOKRwz0nAU8gZ5STQk()
	elif ZyiMa3BXVk2xWG0b==lljaEqwTVtmKsQcOrbXxS5hgNH(u"࠻ፋ"): jZn8dWH7bUchfGaym3FV()
	elif ZyiMa3BXVk2xWG0b==l1DZAt9XNQjqE7YOdrz(u"࠽ፌ"): xx0h3IHbKCZult()
	elif ZyiMa3BXVk2xWG0b==V3VlkhgjEF4n1erPXHcC0NOsfwyAJ(u"࠷࠵࠱ፍ"): rlKjUZWTwuRg5teHsChQaLokzXf7JS()
	elif ZyiMa3BXVk2xWG0b==rNdBKI74fAklnoCZ6(u"࠱࠶࠳ፎ"): vUr8x1Eh5uHIls7e3ciYQ0JgB()
	elif ZyiMa3BXVk2xWG0b==aXqWLoTdVgME(u"࠲࠷࠵ፏ"): Bg4AU3fVk6CoFje()
	elif ZyiMa3BXVk2xWG0b==tR1krDGPpO025fghMT3a7UnYj(u"࠳࠸࠷ፐ"): VqNaJlpESnm6FAjyuDBL2Mxg4hO7bH()
	elif ZyiMa3BXVk2xWG0b==viRJWOC5jsYe84(u"࠴࠹࠹ፑ"): dJUkRO41LBDnCcvHgqwzb6iVxWQj5()
	elif ZyiMa3BXVk2xWG0b==tQMjXKCA5dN4xq3beVIzaEoWkFLg(u"࠵࠺࠻ፒ"): ej9tk8g5TJfKbwy7andDoH()
	elif ZyiMa3BXVk2xWG0b==LZWMikPEB81KSGyxfJtUsCA(u"࠶࠻࠶ፓ"): OId452eZz8SsWw()
	elif ZyiMa3BXVk2xWG0b==c2RKu0xG1eC8MiohyE(u"࠷࠵࠸ፔ"): YwIVmvTRU1ut2ZdPozEDcWK()
	elif ZyiMa3BXVk2xWG0b==mmV2nucZ5Lpl6FO1JMPEqGoQKW(u"࠱࠶࠺ፕ"): yyuwY8EsjDdkCeNKFzmH()
	elif ZyiMa3BXVk2xWG0b==BRWqdruz2A0(u"࠲࠷࠼ፖ"): vuBjEdkpnKx(gBExoceumj4y8bFW9hY2aNMVSr)
	elif ZyiMa3BXVk2xWG0b==c2RKu0xG1eC8MiohyE(u"࠳࠺࠴ፗ"): mlP2s9hy51FBtMYKUcTdjqr()
	elif ZyiMa3BXVk2xWG0b==DiJ8CMuYH1daWyjehfN0L(u"࠴࠻࠶ፘ"): flrI4xKnmz2A()
	elif ZyiMa3BXVk2xWG0b==N3flV6EJsD5CzS(u"࠵࠼࠸ፙ"): i7aA1MZztsHSxXbpNyj4([HY7yaJeI89xE56sbTjdBRZPDwQKFX],gBExoceumj4y8bFW9hY2aNMVSr,gBExoceumj4y8bFW9hY2aNMVSr,ag8rjZo1Vz4IPdcOT)
	elif ZyiMa3BXVk2xWG0b==DaFZHsThGmd0zv6e(u"࠶࠽࠳ፚ"): qx7AQkCSGFfpTn(DiJ8CMuYH1daWyjehfN0L(u"࠭ࡩ࡯ࡲࡸࡸࡸࡺࡲࡦࡣࡰ࠲ࡦࡪࡡࡱࡶ࡬ࡺࡪ࠭ၒ"),gBExoceumj4y8bFW9hY2aNMVSr)
	elif ZyiMa3BXVk2xWG0b==ee86G9ladLHVbh5mikzCo(u"࠷࠷࠵፛"): qx7AQkCSGFfpTn(kYDaz79TFlXoR(u"ࠧࡪࡰࡳࡹࡹࡹࡴࡳࡧࡤࡱ࠳ࡸࡴ࡮ࡲࠪၓ"),gBExoceumj4y8bFW9hY2aNMVSr)
	elif ZyiMa3BXVk2xWG0b==CC1eY6yWZUwf2TkRvnp7EJ0AimjHBX(u"࠱࠸࠷፜"): nD6NC1uTZ2HeGk9qUmKtwhLAScxOo8()
	elif ZyiMa3BXVk2xWG0b==Ie5s2cBtSfdHjzQ4rA9kYlo6D18(u"࠲࠹࠹፝"): mHNfbl9MJXaQLPK6V4F()
	elif ZyiMa3BXVk2xWG0b==l32dnTEOU1skGKqeBtI9hmo(u"࠳࠺࠻፞"): uehoD6sjLUfM(ee86G9ladLHVbh5mikzCo(u"ࠨࡵࡦࡶ࡮ࡶࡴ࠯࡯ࡲࡨࡺࡲࡥ࠯ࡴࡨࡷࡴࡲࡶࡦࡷࡵࡰࠬၔ"))
	elif ZyiMa3BXVk2xWG0b==lljaEqwTVtmKsQcOrbXxS5hgNH(u"࠴࠻࠾፟"): uehoD6sjLUfM(zYvEaigKWjoq50pXBLDbGJkFc(u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡻࡲࡹࡹࡻࡢࡦࠩၕ"))
	elif ZyiMa3BXVk2xWG0b==c2RKu0xG1eC8MiohyE(u"࠵࠾࠶፠"): hhL6vp9bzkHJQ5qjD1C()
	elif ZyiMa3BXVk2xWG0b==tQMjXKCA5dN4xq3beVIzaEoWkFLg(u"࠶࠿࠱፡"): bmBktdgisLPIU()
	elif ZyiMa3BXVk2xWG0b==DaFZHsThGmd0zv6e(u"࠷࠹࠳።"): lnP150XkcWAKLiITQxa9vsogd8q7()
	elif ZyiMa3BXVk2xWG0b==lljaEqwTVtmKsQcOrbXxS5hgNH(u"࠱࠺࠵፣"): aFKMzijJQg()
	elif ZyiMa3BXVk2xWG0b==DaFZHsThGmd0zv6e(u"࠲࠻࠷፤"): vxWRLXUchyMlDzd1e8N3()
	elif ZyiMa3BXVk2xWG0b==DaFZHsThGmd0zv6e(u"࠳࠼࠹፥"): b8r3Vmv4zSWq9w0sijZT()
	elif ZyiMa3BXVk2xWG0b==V3VlkhgjEF4n1erPXHcC0NOsfwyAJ(u"࠴࠽࠻፦"): Ic0b7mGzQ4fDPLZvHAJnYr3tugs()
	elif ZyiMa3BXVk2xWG0b==RlOvin8YIGC2KZXJPk9m0acrMobUex(u"࠵࠾࠽፧"): KXPLw0x78Zh()
	elif ZyiMa3BXVk2xWG0b==YY8UDX3MJhb91AHw7fg(u"࠶࠿࠸፨"): sRxuBol46jqYEvO2zw9PSnaF()
	elif ZyiMa3BXVk2xWG0b==ee86G9ladLHVbh5mikzCo(u"࠷࠹࠺፩"): JWOnV1cqvfUMhCZj57()
	elif ZyiMa3BXVk2xWG0b==LZWMikPEB81KSGyxfJtUsCA(u"࠳࠵࠲፪"): CFc6iGxzlKYP4ws1WrhavOEJ(HY7yaJeI89xE56sbTjdBRZPDwQKFX)
	elif ZyiMa3BXVk2xWG0b==N3flV6EJsD5CzS(u"࠴࠶࠴፫"): pNUteOHcV7bf62zAWBS0X9()
	elif ZyiMa3BXVk2xWG0b==zYvEaigKWjoq50pXBLDbGJkFc(u"࠵࠷࠶፬"): oJxTRIkhaQX5tyNefSU89csVAWdb()
	elif ZyiMa3BXVk2xWG0b==kYDaz79TFlXoR(u"࠶࠸࠸፭"): GNf1VjeX3mIYLFbhJlwPRCW6nT()
	elif ZyiMa3BXVk2xWG0b==rNdBKI74fAklnoCZ6(u"࠷࠹࠻፮"): wjK3lLYRWQkXtZ6HNqiMEgpPBuC()
	elif ZyiMa3BXVk2xWG0b==BRWqdruz2A0(u"࠸࠺࠶፯"): PThFb1sQXfUl0RuHBVJStj(ag8rjZo1Vz4IPdcOT)
	elif ZyiMa3BXVk2xWG0b==BRWqdruz2A0(u"࠹࠴࠸፰"): Yz4RMHeNEZ9PO7VhxGcQjfs1(gBExoceumj4y8bFW9hY2aNMVSr)
	elif ZyiMa3BXVk2xWG0b==kYDaz79TFlXoR(u"࠳࠵࠺፱"): X0x5yQTtKeNWukpc()
	elif ZyiMa3BXVk2xWG0b==dJHDqiKf12TXlIzSLkGUuxg4MBs3A(u"࠴࠶࠼፲"): JqETagILNDXh(LZWMikPEB81KSGyxfJtUsCA(u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡤࡶࡦࡨࡩࡤࡸ࡬ࡨࡪࡵࡳࠨၖ"),gBExoceumj4y8bFW9hY2aNMVSr,gBExoceumj4y8bFW9hY2aNMVSr)
	elif ZyiMa3BXVk2xWG0b==zYvEaigKWjoq50pXBLDbGJkFc(u"࠷࠳࠴፳"): ZhVt1wGsjK7zyYbc8Jm()
	elif ZyiMa3BXVk2xWG0b==c2RKu0xG1eC8MiohyE(u"࠸࠴࠶፴"): j3oD27Qqv5ugRC6TsUf()
	elif ZyiMa3BXVk2xWG0b==aXqWLoTdVgME(u"࠹࠵࠸፵"): fqMxDmSFLEen9yrCaBNKkIOG84TAg()
	elif ZyiMa3BXVk2xWG0b==kYDaz79TFlXoR(u"࠺࠶࠳፶"): FMUsDIQzPYcZB32(RRCjYOQfEdAKub2s)
	elif ZyiMa3BXVk2xWG0b==c2RKu0xG1eC8MiohyE(u"࠻࠰࠵፷"): FMUsDIQzPYcZB32(V2JfszPWt6jq1hCxYKpyM53RL)
	elif ZyiMa3BXVk2xWG0b==viRJWOC5jsYe84(u"࠵࠱࠷፸"): g7iua9efQTwEcX13GPUxYL()
	elif ZyiMa3BXVk2xWG0b==fWoVd0Bmtkx(u"࠶࠲࠹፹"): PAfd3TnXb2oz(gBExoceumj4y8bFW9hY2aNMVSr)
	elif ZyiMa3BXVk2xWG0b==qoBMmfAWpFlK70xw8ZRh4naJ(u"࠷࠳࠻፺"): aE2H78314kv0uSVFf()
	elif ZyiMa3BXVk2xWG0b==l32dnTEOU1skGKqeBtI9hmo(u"࠸࠴࠽፻"): HbVFkgx1dYPZfUeDT0NAE()
	elif ZyiMa3BXVk2xWG0b==zYvEaigKWjoq50pXBLDbGJkFc(u"࠵࠵࠸࠰፼"): zzlL80Q4uOyKURDfTagqre5PMShVIp()
	elif ZyiMa3BXVk2xWG0b==mmV2nucZ5Lpl6FO1JMPEqGoQKW(u"࠶࠶࠲࠲፽"): yyHwantubcFGI()
	elif ZyiMa3BXVk2xWG0b==CC1eY6yWZUwf2TkRvnp7EJ0AimjHBX(u"࠷࠰࠳࠴፾"): uehoD6sjLUfM(CC1eY6yWZUwf2TkRvnp7EJ0AimjHBX(u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡥࡷࡧࡢࡪࡥࡹ࡭ࡩ࡫࡯ࡴࠩၗ"))
	elif ZyiMa3BXVk2xWG0b==sjtU6GZQg5XC2pH4(u"࠱࠱࠴࠶፿"): VVfrZD0pjUhkO1()
	elif ZyiMa3BXVk2xWG0b==CC1eY6yWZUwf2TkRvnp7EJ0AimjHBX(u"࠲࠲࠵࠸ᎀ"): Q4LNO7l9gpTIXVkwjs(gBExoceumj4y8bFW9hY2aNMVSr)
	elif ZyiMa3BXVk2xWG0b==c2RKu0xG1eC8MiohyE(u"࠳࠳࠶࠺ᎁ"): tmfaZM5pd9DwHO6YBqyxUVI()
	elif ZyiMa3BXVk2xWG0b==IaBhDMJc17302LgSvyxd(u"࠴࠴࠷࠼ᎂ"): hBvbNxJyWaYRg80tqQ15w4s()
	return
def Q4LNO7l9gpTIXVkwjs(showDialogs=ag8rjZo1Vz4IPdcOT):
	vWmZVU7Pan8FLyTS = Rqvw05BorCgcye7VE32Sf.executeJSONRPC(mmV2nucZ5Lpl6FO1JMPEqGoQKW(u"ࠬࢁࠢ࡫ࡵࡲࡲࡷࡶࡣࠣ࠼ࠥ࠶࠳࠶ࠢ࠭ࠤࡰࡩࡹ࡮࡯ࡥࠤ࠽ࠦࡘ࡫ࡴࡵ࡫ࡱ࡫ࡸ࠴ࡇࡦࡶࡖࡩࡹࡺࡩ࡯ࡩ࡙ࡥࡱࡻࡥࠣ࠮ࠥ࡭ࡩࠨ࠺࠲࠮ࠥࡴࡦࡸࡡ࡮ࡵࠥ࠾ࢀࠨࡳࡦࡶࡷ࡭ࡳ࡭ࠢ࠻ࠤ࡯ࡳࡨࡧ࡬ࡦ࠰࡮ࡩࡾࡨ࡯ࡢࡴࡧࡰࡦࡿ࡯ࡶࡶࡶࠦࢂࢃࠧၘ"))
	vWmZVU7Pan8FLyTS = A3AFYmgZLXn4MBab.loads(vWmZVU7Pan8FLyTS)[DiJ8CMuYH1daWyjehfN0L(u"࠭ࡲࡦࡵࡸࡰࡹ࠭ၙ")][iNc3KxwErnQ(u"ࠧࡷࡣ࡯ࡹࡪ࠭ၚ")]
	choice,zVEQWYNxu5bUhwXnK = Zwqio2AIWlD5etFa,vWmZVU7Pan8FLyTS[:]
	if showDialogs:
		cvOeYnZSXyDukUrg1HGjI25mB = tQMjXKCA5dN4xq3beVIzaEoWkFLg(u"ࠨๆ๋ัฮࠦวๅ็ไหฯ๐อࠡษ็฽ึฮ๊ส่ࠢๅ฾๊ษ๊ࠡอ฽๊๊ࠧၛ") if sjtU6GZQg5XC2pH4(u"ࠩࡄࡶࡦࡨࡩࡤࠢࡔ࡛ࡊࡘࡔ࡚ࠩၜ") in vWmZVU7Pan8FLyTS else ddiCzu6yahj5RtTISMJ48sNnZBU(u"่ࠪํำษࠡษ็้ๆอส๋ฯࠣห้฿ัษ์ฬࠤ๊ะ่ใใฬࠫၝ")
		choice = eVLmAIGFiwpr94UK6MRP5(LZWMikPEB81KSGyxfJtUsCA(u"ࠫࡨ࡫࡮ࡵࡧࡵࠫၞ"),l1DZAt9XNQjqE7YOdrz(u"ࠬิั้ฮࠪၟ"),RlOvin8YIGC2KZXJPk9m0acrMobUex(u"࠭ล๋ไสๅࠬၠ"),UVa3fJw7k6KM(u"ࠧหึ฽๎้࠭ၡ"),GLTtERWbHnFuy4PCp,xupTj02bvy3O8R+cvOeYnZSXyDukUrg1HGjI25mB+fF4lt9zWYxXLKZVyAco82PgMj+ZLwoRpfnCWI7FgEHsz6te39lMVh+ZLwoRpfnCWI7FgEHsz6te39lMVh+sjtU6GZQg5XC2pH4(u"ࠨ้ำ๋ࠥอไฺ้ํๅฮࠦสิ็ะࠤออำหะาห๊ࠦไ้ฯฬࠤฬ๊ๅโษอ๎าࠦวๅ฻ิฬ๏ฯࠠศๆ่์ั๎ฯสࠢไ๎้่ࠥะ์ࠣ࠲࠳่่ࠦาสࠤ๊฿ๆศ้ࠣห๋ะࠠหีอ฻๏฿ࠠฤ่ࠣฮ฾๋ไࠡสะฯࠥ็๊ࠡ็๋ห็฿ࠠศๆหี๋อๅอࠢหหุะฮะษ่ࠤฬ๊ไ฻หࠣห้฿ัษ์ฬࠤ࠳࠴ࠠฤ๊ࠣฮุะื๋฻ࠣว๋ࠦสไฬหࠤึูวๅห่้๋ࠣศา็ฯࠤออไๅ฼ฬࠤฬู๊าสํอࠥ࠴࠮้ࠡ็ࠤฯื๊ะࠢส่ว์ࠠหึ฽๎้ࠦไ้ฯฬࠤฬ๊ๅโษอ๎าࠦวๅ฻ิฬ๏ฯࠠฤ็ࠣษ๏่วโ้สࠤฤࠧࠡࠨၢ"))
	if choice==Zwqio2AIWlD5etFa and tQMjXKCA5dN4xq3beVIzaEoWkFLg(u"ࠩࡄࡶࡦࡨࡩࡤࠢࡔ࡛ࡊࡘࡔ࡚ࠩၣ") not in vWmZVU7Pan8FLyTS: zVEQWYNxu5bUhwXnK = [sjtU6GZQg5XC2pH4(u"ࠪࡅࡷࡧࡢࡪࡥࠣࡕ࡜ࡋࡒࡕ࡛ࠪၤ")]+vWmZVU7Pan8FLyTS
	elif choice==mZi0S72jGoHpLO and LZWMikPEB81KSGyxfJtUsCA(u"ࠫࡆࡸࡡࡣ࡫ࡦࠤࡖ࡝ࡅࡓࡖ࡜ࠫၥ") in vWmZVU7Pan8FLyTS:
		zVEQWYNxu5bUhwXnK = vWmZVU7Pan8FLyTS[:]
		zVEQWYNxu5bUhwXnK.remove(UVa3fJw7k6KM(u"ࠬࡇࡲࡢࡤ࡬ࡧࠥࡗࡗࡆࡔࡗ࡝ࠬၦ"))
	if zVEQWYNxu5bUhwXnK!=vWmZVU7Pan8FLyTS:
		zVEQWYNxu5bUhwXnK = str(zVEQWYNxu5bUhwXnK).replace(CC1eY6yWZUwf2TkRvnp7EJ0AimjHBX(u"ࠨࠧࠣၧ"),mmV2nucZ5Lpl6FO1JMPEqGoQKW(u"ࠧࠣࠩၨ"))
		MOTjA5H9XFs = Rqvw05BorCgcye7VE32Sf.executeJSONRPC(UVa3fJw7k6KM(u"ࠨࡽࠥ࡮ࡸࡵ࡮ࡳࡲࡦࠦ࠿ࠨ࠲࠯࠲ࠥ࠰ࠧࡳࡥࡵࡪࡲࡨࠧࡀࠢࡔࡧࡷࡸ࡮ࡴࡧࡴ࠰ࡖࡩࡹ࡙ࡥࡵࡶ࡬ࡲ࡬࡜ࡡ࡭ࡷࡨࠦ࠱ࠨࡩࡥࠤ࠽࠵࠱ࠨࡰࡢࡴࡤࡱࡸࠨ࠺ࡼࠤࡶࡩࡹࡺࡩ࡯ࡩࠥ࠾ࠧࡲ࡯ࡤࡣ࡯ࡩ࠳ࡱࡥࡺࡤࡲࡥࡷࡪ࡬ࡢࡻࡲࡹࡹࡹࠢ࠭ࠤࡹࡥࡱࡻࡥࠣ࠼ࠪၩ")+zVEQWYNxu5bUhwXnK+rNdBKI74fAklnoCZ6(u"ࠩࢀࢁࠬၪ"))
		if showDialogs:
			if dJHDqiKf12TXlIzSLkGUuxg4MBs3A(u"ࠪࡸࡷࡻࡥࠨၫ") in str(MOTjA5H9XFs): iG7Rz2kmn0x1yLNMV3u8O(qpFY4hAwolV3,qpFY4hAwolV3,GLTtERWbHnFuy4PCp,DiJ8CMuYH1daWyjehfN0L(u"ࠫฯ๋สࠡษ็฽๊๊๊สࠢห๊ัออࠨၬ"))
			else: iG7Rz2kmn0x1yLNMV3u8O(qpFY4hAwolV3,qpFY4hAwolV3,GLTtERWbHnFuy4PCp,DiJ8CMuYH1daWyjehfN0L(u"๊ࠬไฤีไࠤฬู๊ๆๆํอࠥ็ิๅฬࠪၭ"))
	return
def VVfrZD0pjUhkO1():
	v6yW5DfOsGhBkj4nzUSwEMXReHa = gdPslyFW8ITBcpA302.getSetting(BRWqdruz2A0(u"࠭ࡡࡷ࠰ࡶࡸࡦࡺࡵࡴ࠰ࡥ࡭ࡹࡸࡡࡵࡧࠪၮ"))
	message = lljaEqwTVtmKsQcOrbXxS5hgNH(u"ࠧศๆิๆ๊ࠦวๅ็ะำิࠦอศๆํหࠥํ่ࠡ࠼ࠣࠤࠥ࠭ၯ")+str(v6yW5DfOsGhBkj4nzUSwEMXReHa)+dJHDqiKf12TXlIzSLkGUuxg4MBs3A(u"ࠨࠢ࡮ࡦࡵࡹࠧၰ") if v6yW5DfOsGhBkj4nzUSwEMXReHa else c2RKu0xG1eC8MiohyE(u"ࠩส่ั๎ฯสࠢส่ศ๎ส้็สฮ๏้๊ส่ࠢฮํ่แสࠢะห้๐วࠨၱ")
	message = xupTj02bvy3O8R+message+l32dnTEOU1skGKqeBtI9hmo(u"ࠪࡠࡳํไࠡฬิ๎ิࠦวๅฤ้ࠤฯฺฺ๋ๆࠣวํࠦส฻์ํีࠥืโๆࠢส่ั๎ฯสࠢส่ศ๎ส้็สฮ๏้๊สࠩၲ")+fF4lt9zWYxXLKZVyAco82PgMj
	r7MXibnK2fa6S31ctA = eVLmAIGFiwpr94UK6MRP5(YY8UDX3MJhb91AHw7fg(u"ࠫࡨ࡫࡮ࡵࡧࡵࠫၳ"),sjtU6GZQg5XC2pH4(u"ࠬิั้ฮࠪၴ"),l1DZAt9XNQjqE7YOdrz(u"࠭ล๋ไสๅࠬၵ"),UVa3fJw7k6KM(u"ࠧหึ฽๎้࠭ၶ"),GLTtERWbHnFuy4PCp,message+BRWqdruz2A0(u"ࠨ࡞ࡱࡠࡳอไอ๊าอࠥอไฤ๊อ์๊อส๋ๅํอࠥํ๊ࠡ฻่่๏ฯ๋ࠠไ๋้ࠥฮ็ศࠢส่อืๆศ็ฯࠤออฮห์สีࠥษูๅ๋ࠣะํีษࠡ็อ์ๆืษࠡๆิๆ๊ࠦวๅฮ๋ำฮࠦวๅาํࠤฬ์สࠡฬะำิํࠠโ์๋ࠣีํࠠศๆืหูฯࠠ࠯࠰ࠣ์์ึวࠡ็฼๊ฬํฺ่ࠠา้ฬࠦสใ๊่ࠤฬ์สࠡสอุ฿๐ไࠡใํำ๏๎ࠠโษ้ࠤฬ๊ศา่ส้ัࠦไ็ࠢํืศ๊ใࠡ฻้ࠤฬ๊ฬ้ัฬࠤฬ๊ส๋ࠢอี๏ี็ศࠢ็ว๋ࠦวๅสิ๊ฬ๋ฬࠡี๋ๅࠥ๐ฮหษิࠤฬ๊ฬ้ัฬࠤศ๎ส้็สฮ๏้๊ศࠢ࠱࠲ࠥ฿ไๆษࠣห๋ํ๋ࠠฮหࠤฬิส๋ษิࠤึ่ๅࠡฮ๋ำฮࠦี฻์ิࠤสึวࠡๅส๊ฯࠦวๅว้ฮึ์สࠡ฻้ำ่ࠦศุ์ษอࠥษ่ࠡไ็๎้ฯࠧၷ"))
	if r7MXibnK2fa6S31ctA in [-qqzwE6imYG4c2xojI(u"࠵ᎃ"),c2RKu0xG1eC8MiohyE(u"࠵ᎄ")]: return
	if r7MXibnK2fa6S31ctA==lljaEqwTVtmKsQcOrbXxS5hgNH(u"࠷ᎅ"):
		v6yW5DfOsGhBkj4nzUSwEMXReHa = qpFY4hAwolV3
		iG7Rz2kmn0x1yLNMV3u8O(qpFY4hAwolV3,qpFY4hAwolV3,GLTtERWbHnFuy4PCp,DiJ8CMuYH1daWyjehfN0L(u"้ࠩะาะฺࠠ็็๎ฮࠦล๋ไสๅࠥอไอ๊าอࠥอไฤ๊อ์๊อส๋ๅํอࠬၸ"))
	else:
		items = [viRJWOC5jsYe84(u"ࠪ࠶࠺࠶ࠠ࡬ࡤࡳࡷࠬၹ"),kYDaz79TFlXoR(u"ࠫ࠺࠶࠰ࠡ࡭ࡥࡴࡸ࠭ၺ"),UVa3fJw7k6KM(u"ࠬ࠽࠵࠱ࠢ࡮ࡦࡵࡹࠧၻ"),YY8UDX3MJhb91AHw7fg(u"࠭࠱࠱࠲࠳ࠤࡰࡨࡰࡴࠩၼ"),tR1krDGPpO025fghMT3a7UnYj(u"ࠧ࠲࠴࠸࠴ࠥࡱࡢࡱࡵࠪၽ"),ddiCzu6yahj5RtTISMJ48sNnZBU(u"ࠨ࠳࠸࠴࠵ࠦ࡫ࡣࡲࡶࠫၾ"),iNc3KxwErnQ(u"ࠩ࠴࠻࠺࠶ࠠ࡬ࡤࡳࡷࠬၿ"),LZWMikPEB81KSGyxfJtUsCA(u"ࠪ࠶࠵࠶࠰ࠡ࡭ࡥࡴࡸ࠭ႀ"),YY8UDX3MJhb91AHw7fg(u"ࠫ࠷࠻࠰࠱ࠢ࡮ࡦࡵࡹࠧႁ"),V3VlkhgjEF4n1erPXHcC0NOsfwyAJ(u"ࠬ࠹࠰࠱࠲ࠣ࡯ࡧࡶࡳࠨႂ"),l1DZAt9XNQjqE7YOdrz(u"࠭࠳࠶࠲࠳ࠤࡰࡨࡰࡴࠩႃ"),DaFZHsThGmd0zv6e(u"ࠧ࠵࠲࠳࠴ࠥࡱࡢࡱࡵࠪႄ"),fWoVd0Bmtkx(u"ࠨ࠶࠸࠴࠵ࠦ࡫ࡣࡲࡶࠫႅ"),zYvEaigKWjoq50pXBLDbGJkFc(u"ࠩ࠸࠴࠵࠶ࠠ࡬ࡤࡳࡷࠬႆ"),sjtU6GZQg5XC2pH4(u"ࠪ࠺࠵࠶࠰ࠡ࡭ࡥࡴࡸ࠭ႇ"),l32dnTEOU1skGKqeBtI9hmo(u"ࠫ࠼࠶࠰࠱ࠢ࡮ࡦࡵࡹࠧႈ"),sjtU6GZQg5XC2pH4(u"ࠬ࠾࠰࠱࠲ࠣ࡯ࡧࡶࡳࠨႉ"),iNc3KxwErnQ(u"࠭࠹࠱࠲࠳ࠤࡰࡨࡰࡴࠩႊ"),l32dnTEOU1skGKqeBtI9hmo(u"ࠧ࠲࠲࠳࠴࠵ࠦ࡫ࡣࡲࡶࠫႋ"),qoBMmfAWpFlK70xw8ZRh4naJ(u"ࠨ࠳࠴࠴࠵࠶ࠠ࡬ࡤࡳࡷࠬႌ"),N3flV6EJsD5CzS(u"ࠩ࠴࠶࠵࠶࠰ࠡ࡭ࡥࡴࡸႍ࠭"),qoBMmfAWpFlK70xw8ZRh4naJ(u"ࠪ࠽࠾࠿࠹࠺ࠢ࡮ࡦࡵࡹࠧႎ")]
		ndm6kKswPpgGHNEbtB = xVzqWbrFXJ(N3flV6EJsD5CzS(u"ࠫฬิสาࠢส่ั๎ฯสࠢส่ศ๎ส้็สฮ๏้๊สࠢส่๊์วิสฬࠫႏ"),items)
		if ndm6kKswPpgGHNEbtB==-BRWqdruz2A0(u"࠱ᎆ"): return
		v6yW5DfOsGhBkj4nzUSwEMXReHa = str(items[ndm6kKswPpgGHNEbtB][:-DaFZHsThGmd0zv6e(u"࠶ᎇ")])
		iG7Rz2kmn0x1yLNMV3u8O(qpFY4hAwolV3,qpFY4hAwolV3,GLTtERWbHnFuy4PCp,iNc3KxwErnQ(u"ࠬ์ฬฮฬࠣ฽๊๊๊สࠢอุ฿๐ไ๊ࠡอัิ๐ฯࠡำๅ้ࠥอไอ๊าอࠥอไฤ๊อ์๊อส๋ๅํอࡡࡴ࡜࡯ࠩ႐")+xupTj02bvy3O8R+v6yW5DfOsGhBkj4nzUSwEMXReHa+DiJ8CMuYH1daWyjehfN0L(u"࠭ࠠ࡬ࡤࡳࡷࠬ႑")+fF4lt9zWYxXLKZVyAco82PgMj)
	gdPslyFW8ITBcpA302.setSetting(tR1krDGPpO025fghMT3a7UnYj(u"ࠧࡢࡸ࠱ࡷࡹࡧࡴࡶࡵ࠱ࡦ࡮ࡺࡲࡢࡶࡨࠫ႒"),v6yW5DfOsGhBkj4nzUSwEMXReHa)
	return
def yyHwantubcFGI(lZimHx5y6VYIfsznu=ag8rjZo1Vz4IPdcOT):
	VwKqlTPdsG5jHpS16Br = pVULK1lCI2oPx()
	cvOeYnZSXyDukUrg1HGjI25mB = CC1eY6yWZUwf2TkRvnp7EJ0AimjHBX(u"ࠨษ็ฮูเ๊ๅࠢส่้ออใࠢํ฽๊๊ࠧ႓") if VwKqlTPdsG5jHpS16Br else l32dnTEOU1skGKqeBtI9hmo(u"ࠩส่ฯฺฺ๋ๆࠣห้๊วฮไ้ࠣฯ๎โโࠩ႔")
	r7MXibnK2fa6S31ctA = eVLmAIGFiwpr94UK6MRP5(aXqWLoTdVgME(u"ࠪࡧࡪࡴࡴࡦࡴࠪ႕"),qqzwE6imYG4c2xojI(u"ࠫำื่อࠩ႖"),l32dnTEOU1skGKqeBtI9hmo(u"ࠬห๊ใษไࠫ႗"),ee86G9ladLHVbh5mikzCo(u"࠭สี฼ํ่ࠬ႘"),GLTtERWbHnFuy4PCp,xupTj02bvy3O8R+cvOeYnZSXyDukUrg1HGjI25mB+fF4lt9zWYxXLKZVyAco82PgMj+ZLwoRpfnCWI7FgEHsz6te39lMVh+CC1eY6yWZUwf2TkRvnp7EJ0AimjHBX(u"่ࠧา๊ࠤฬู๊่์ไอࠥะฬฺๆࠣ็ํี๊ࠡล๋ฮํ๋วห์ๆ๎ฬ๊ࠦใ๊่ࠤอะิ฻์็ࠤฬ๊แ๋ัํ์ࠥอไๅษะๆࠥ࠴࠮ࠡว่หࠥฮูะࠢส๊ฯํวยࠢส่ๆ๐ฯ๋๊ࠣห้ำวๅ์ࠣฬศ้ๅๅ้ࠣ࠲࠳ࠦร้ࠢห฽ิࠦวๅ่ๅีࠥ฿ไ๊ࠢีีࠥࠨสอษ๋ึࠥหไ๊ࠢส่้ออใࠤࠣ࠲࠳่ࠦฤ์ูห๋ࠥๅไ่ࠣษ้เวยࠢส่ฯฺฺ๋ๆࠣห้๊วฮไࠣฬฬ๊ๆใำࠣ฽้๏ࠠำำࠣࠦส๐โศใࠣห้็๊ะ์๋ࠦࠥ࠴࠮๊ࠡฦ๎฻อࠠๆ็ๆ๊ࠥอไศีอๅฬีษࠡ็้ࠤฯเ๊๋ำࠣฮึะ๊ษ่ࠢัฯ๎๊ศฬࠣห้่่ศศ่ࠤ࠳࠴้ࠠะสูฮࠦสาฬํฬࠥำไใษอࠤฬ๊ๅิๆึ่ฬะࠠ࠯࠰๋้ࠣࠦสา์าࠤฬ๊ย็ࠢอุ฿๐ไ้ࠡำ๋ࠥอไฺ้ํๅฮࠦรๆࠢศ๎็อแ่ษࠣรࠦࠧࠧ႙"))
	if r7MXibnK2fa6S31ctA==mZi0S72jGoHpLO: pocxFlQ8n9vL = Rqvw05BorCgcye7VE32Sf.executeJSONRPC(sjtU6GZQg5XC2pH4(u"ࠨࡽࠥ࡮ࡸࡵ࡮ࡳࡲࡦࠦ࠿ࠨ࠲࠯࠲ࠥ࠰ࠧࡳࡥࡵࡪࡲࡨࠧࡀࠢࡔࡧࡷࡸ࡮ࡴࡧࡴ࠰ࡖࡩࡹ࡙ࡥࡵࡶ࡬ࡲ࡬࡜ࡡ࡭ࡷࡨࠦ࠱ࠨࡩࡥࠤ࠽࠵࠱ࠨࡰࡢࡴࡤࡱࡸࠨ࠺ࡼࠤࡶࡩࡹࡺࡩ࡯ࡩࠥ࠾ࠧࡼࡩࡥࡧࡲࡴࡱࡧࡹࡦࡴ࠱ࡥࡺࡺ࡯ࡱ࡮ࡤࡽࡳ࡫ࡸࡵ࡫ࡷࡩࡲࠨࠬࠣࡸࡤࡰࡺ࡫ࠢ࠻࡝ࡠࢁࢂ࠭ႚ"))
	elif r7MXibnK2fa6S31ctA==Zwqio2AIWlD5etFa: pocxFlQ8n9vL = Rqvw05BorCgcye7VE32Sf.executeJSONRPC(Ie5s2cBtSfdHjzQ4rA9kYlo6D18(u"ࠩࡾࠦ࡯ࡹ࡯࡯ࡴࡳࡧࠧࡀࠢ࠳࠰࠳ࠦ࠱ࠨ࡭ࡦࡶ࡫ࡳࡩࠨ࠺ࠣࡕࡨࡸࡹ࡯࡮ࡨࡵ࠱ࡗࡪࡺࡓࡦࡶࡷ࡭ࡳ࡭ࡖࡢ࡮ࡸࡩࠧ࠲ࠢࡪࡦࠥ࠾࠶࠲ࠢࡱࡣࡵࡥࡲࡹࠢ࠻ࡽࠥࡷࡪࡺࡴࡪࡰࡪࠦ࠿ࠨࡶࡪࡦࡨࡳࡵࡲࡡࡺࡧࡵ࠲ࡦࡻࡴࡰࡲ࡯ࡥࡾࡴࡥࡹࡶ࡬ࡸࡪࡳࠢ࠭ࠤࡹࡥࡱࡻࡥࠣ࠼࡞࠵ࡢࢃࡽࠨႛ"))
	if r7MXibnK2fa6S31ctA in [mZi0S72jGoHpLO,Zwqio2AIWlD5etFa]:
		if IaBhDMJc17302LgSvyxd(u"ࠪࡸࡷࡻࡥࠨႜ") in str(pocxFlQ8n9vL): iG7Rz2kmn0x1yLNMV3u8O(qpFY4hAwolV3,qpFY4hAwolV3,GLTtERWbHnFuy4PCp,dJHDqiKf12TXlIzSLkGUuxg4MBs3A(u"ࠫฯ๋สࠡษ็฽๊๊๊สࠢห๊ัออࠨႝ"))
		else: iG7Rz2kmn0x1yLNMV3u8O(qpFY4hAwolV3,qpFY4hAwolV3,GLTtERWbHnFuy4PCp,UVa3fJw7k6KM(u"๊ࠬไฤีไࠤฬู๊ๆๆํอࠥ็ิๅฬࠪ႞"))
	return
def zzlL80Q4uOyKURDfTagqre5PMShVIp():
	url = i4bFG3rKE6.SITESURLS[c2RKu0xG1eC8MiohyE(u"࠭ࡒࡆࡎࡈࡅࡘࡋࡓࠨ႟")][ddiCzu6yahj5RtTISMJ48sNnZBU(u"࠲ᎈ")]
	IAW0sh6So3NpqM = WWrExJZS3Bj4anOAkpv7(dzcNuIbsgK3yZ6SXGaEHPfOj5vk,UVa3fJw7k6KM(u"ࠧࡈࡇࡗࠫႠ"),url,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,qoBMmfAWpFlK70xw8ZRh4naJ(u"ࠨࡕࡈࡖ࡛ࡏࡃࡆࡕ࠰ࡍࡓ࡙ࡔࡂࡎࡏࡣࡔࡒࡄࡠࡔࡈࡐࡊࡇࡓࡆ࠯࠴ࡷࡹ࠭Ⴁ"))
	cmWl9dOKHPIy41iaXuxrY = IAW0sh6So3NpqM.content
	vN0gZI3nVwehLcsEjxm6 = ePhmG1jLD6.findall(zYvEaigKWjoq50pXBLDbGJkFc(u"ࠩ࡫ࡶࡪ࡬࠽ࠣࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࠩࡣࡵࡥࡧ࡯ࡣࡷ࡫ࡧࡩࡴࡹ࠮ࠫࡁࠬ࠲ࡿ࡯ࡰࠣࠩႢ"),cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	vN0gZI3nVwehLcsEjxm6 = sorted(vN0gZI3nVwehLcsEjxm6,reverse=gBExoceumj4y8bFW9hY2aNMVSr)
	ndm6kKswPpgGHNEbtB = xVzqWbrFXJ(BRWqdruz2A0(u"ࠪหำะัࠡษ็ษฺีวาࠢส่ี๐ࠠหำํำࠥะหษ์อ๋ࠬႣ"),vN0gZI3nVwehLcsEjxm6)
	if ndm6kKswPpgGHNEbtB>=fWoVd0Bmtkx(u"࠳ᎉ"):
		hw24tzLlAXy7UNSeQum = url.rsplit(ShynO8pN9idCE3,DiJ8CMuYH1daWyjehfN0L(u"࠵ᎊ"))[BRWqdruz2A0(u"࠵ᎋ")]+rNdBKI74fAklnoCZ6(u"ࠫ࠴ࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࠬႤ")+vN0gZI3nVwehLcsEjxm6[ndm6kKswPpgGHNEbtB]+c2RKu0xG1eC8MiohyE(u"ࠬ࠴ࡺࡪࡲࠪႥ")
		succeeded = WxjKhqVD7XNnTisJIr4Ya8Mwt5(IaBhDMJc17302LgSvyxd(u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡧࡲࡢࡤ࡬ࡧࡻ࡯ࡤࡦࡱࡶࠫႦ"),hw24tzLlAXy7UNSeQum,gBExoceumj4y8bFW9hY2aNMVSr)
		if succeeded:
			gdPslyFW8ITBcpA302.setSetting(BRWqdruz2A0(u"ࠧࡢࡸ࠱ࡺࡪࡸࡳࡪࡱࡱࠫႧ"),qpFY4hAwolV3)
			o4oUxD3u18K59ghHIY = VVpbtSKYUGXrNMwAWFo9IOjZP(qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,GLTtERWbHnFuy4PCp,ee86G9ladLHVbh5mikzCo(u"ࠨฬ่ࠤฯัศ๋ฬࠣษฺีวาࠢๅำ๏๋ࠠๅๆหี๋อๅอࠢ࠱࠲๊ࠥใ็ࠢหี๋อๅอࠢๆ์ิ๐๋ࠠไ๋้ࠥษ่ห๊่หฯ๐ใ๋ษࠣฬฯำฯ๋อࠣะ๊๐ูࠡษ็ฬึอๅอࠢหหุะฮะษ่ࠤวิัࠡวุำฬืࠠๆฬ๋ๅึࠦ࠮࠯๊่ࠢࠥะั๋ัࠣห้ศๆࠡวํๆฬ็ࠠศๆอัิ๐หࠡษ็วํะ่ๆษอ๎่๐ࠠๅ้ำหࠥอไษำ้ห๊าࠠภࠣࠤࠫႨ"))
			if o4oUxD3u18K59ghHIY: JqETagILNDXh(viRJWOC5jsYe84(u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡣࡵࡥࡧ࡯ࡣࡷ࡫ࡧࡩࡴࡹࠧႩ"),gBExoceumj4y8bFW9hY2aNMVSr,gBExoceumj4y8bFW9hY2aNMVSr)
	return
def aE2H78314kv0uSVFf():
	o4oUxD3u18K59ghHIY = VVpbtSKYUGXrNMwAWFo9IOjZP(qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,GLTtERWbHnFuy4PCp,zYvEaigKWjoq50pXBLDbGJkFc(u"๋้ࠪࠦสา์าࠤๆ฿ไศ่ࠢืาࠦลฺัสำฬะࠠศๆหี๋อๅอࠢส่ำอีสࠢห์็ะࠠอๆหࠤฬ๊สฮัํฯฬะࠠ࠯࠰๋ࠣีอࠠศๆ่ืาࠦำ้ใࠣ๎ุฮศࠡฬะำ๏ัࠠโ๊ิ๎๊ࠥฬๆ์฼ࠤํ฾ววใࠣห้ฮั็ษ่ะࠥอไห์ࠣฮ฾ะๅะࠢ฼่๎ࠦๅา๊ิࠤํ่สࠡ็฼๎๋࠭Ⴊ"))
	if o4oUxD3u18K59ghHIY:
		gdPslyFW8ITBcpA302.setSetting(viRJWOC5jsYe84(u"ࠫࡦࡼ࠮࡭ࡣࡶࡸࡨ࡮ࡥࡤ࡭࠱ࡷ࡭ࡵࡲࡵࠩႫ"),qpFY4hAwolV3)
		gdPslyFW8ITBcpA302.setSetting(iNc3KxwErnQ(u"ࠬࡧࡶ࠯࡮ࡤࡷࡹࡩࡨࡦࡥ࡮࠲ࡷ࡫ࡧࡶ࡮ࡤࡶࠬႬ"),qpFY4hAwolV3)
		gdPslyFW8ITBcpA302.setSetting(sjtU6GZQg5XC2pH4(u"࠭ࡡࡷ࠰࡯ࡥࡸࡺࡣࡩࡧࡦ࡯࠳ࡲ࡯࡯ࡩࠪႭ"),qpFY4hAwolV3)
		gdPslyFW8ITBcpA302.setSetting(UUDAiytEL76RTmMYsuIz5evXB(u"ࠧࡢࡸ࠱ࡰࡦࡹࡴࡤࡪࡨࡧࡰ࠴࡭ࡦࡵࡶࡥ࡬࡫ࡳࠨႮ"),qpFY4hAwolV3)
		gdPslyFW8ITBcpA302.setSetting(ddiCzu6yahj5RtTISMJ48sNnZBU(u"ࠨࡣࡹ࠲ࡱࡧࡳࡵࡥ࡫ࡩࡨࡱ࠮ࡲࡷࡨࡷࡹ࡯࡯࡯ࡵࠪႯ"),qpFY4hAwolV3)
		iG7Rz2kmn0x1yLNMV3u8O(qpFY4hAwolV3,qpFY4hAwolV3,GLTtERWbHnFuy4PCp,iNc3KxwErnQ(u"ࠩอ้๋ࠥำฮࠢศ฽ิอฯศฬࠣห้ฮั็ษ่ะࠥอไฯษุอࠥฮ่ใฬࠣะ้ฮࠠศๆอัิ๐หศฬࠣ࠲࠳่ࠦิ๊ไࠤ๏่่ๆࠢส่อืๆศ็ฯࠤฬ๊ย็ࠢหฮาี๊ฬ๊ࠢิ์ࠦวๅว฼ำฬีวหࠢ࠱࠲ࠥ๎รุ๋สࠤฯำฯ๋อࠣ์฽อฦโࠢส่อืๆศ็ฯࠤฬ๊ส๋ࠢอ฽ฯ๋ฯࠡ฻็ํࠥอไ้ไอࠫႰ"))
		E2E18vJ4hLaZpuWSfoMlY9yBzj6b(ag8rjZo1Vz4IPdcOT)
	return
def g7iua9efQTwEcX13GPUxYL():
	mlykPoGXbJIjFnarp9KihxfN(WoFsvbmUlDZp7PzRfdGknCV,Ie5s2cBtSfdHjzQ4rA9kYlo6D18(u"ࠪࡑࡎ࡙ࡃࡠࡖࡈࡑࡕࡥ࠱ࠨႱ"),ee86G9ladLHVbh5mikzCo(u"ࠫࡖ࡛ࡅࡔࡖࡌࡓࡓ࡙ࠧႲ"))
	weoxDcHJ1PsSiE5pqY7bWMIfX = asFZzCl2vSoiNRU34K(ag8rjZo1Vz4IPdcOT)
	a8QGclgFznx = ZLwoRpfnCWI7FgEHsz6te39lMVh
	j29dQ4nWa51frts = IQ2KCmObsTGuiRdEzt931a40jLg+DaFZHsThGmd0zv6e(u"ࠬࠦ࠭࠮࠯࠰࠱ࠥ࠳࠭࠮࠯࠰ࠤ࠲࠳࠭࠮࠯ࠣ࠱࠲࠳࠭࠮ࠢ࠰࠱࠲࠳࠭ࠡࠩႳ")+fF4lt9zWYxXLKZVyAco82PgMj
	pUfhAr4x6nlC3jV = ZLwoRpfnCWI7FgEHsz6te39lMVh+xupTj02bvy3O8R+ddiCzu6yahj5RtTISMJ48sNnZBU(u"࠭ࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࠪႴ")+fF4lt9zWYxXLKZVyAco82PgMj+rNdBKI74fAklnoCZ6(u"ࠧ࡝ࡰ࡟ࡲࠬႵ")
	for id,WRbn1LC2xPJMZft,nKb2w7UW0qVN,OkL6wBRsf4,T97ftnWyDr2coKalSe,reason in reversed(weoxDcHJ1PsSiE5pqY7bWMIfX):
		if id==kYDaz79TFlXoR(u"ࠨ࠲ࠪႶ"):
			SYdPURfIsm4j1CT80upw,j8XLTuY5xcO = OkL6wBRsf4.split(dJHDqiKf12TXlIzSLkGUuxg4MBs3A(u"ࠩ࡟ࡲࡀࡁࠧႷ"))
			continue
		if a8QGclgFznx!=ZLwoRpfnCWI7FgEHsz6te39lMVh: a8QGclgFznx += pUfhAr4x6nlC3jV
		JQ0OTpbAGY8khnwf = Ie5s2cBtSfdHjzQ4rA9kYlo6D18(u"ࠪ࡟ࡗ࡚ࡌ࡞ࠩႸ")+IQ2KCmObsTGuiRdEzt931a40jLg+id+c2RKu0xG1eC8MiohyE(u"ࠫࠥࡀࠠࠨႹ")+DaFZHsThGmd0zv6e(u"ࠬอไิฦส่ࠥࡀࠠࠨႺ")+fF4lt9zWYxXLKZVyAco82PgMj+nKb2w7UW0qVN
		UJqj5NE0ZKm = kYDaz79TFlXoR(u"࠭࡜࡯࡝ࡕࡘࡑࡣࠧႻ")+IQ2KCmObsTGuiRdEzt931a40jLg+tQMjXKCA5dN4xq3beVIzaEoWkFLg(u"ࠧศๆฯ์ฬฮࠠ࠻ࠢࠪႼ")+fF4lt9zWYxXLKZVyAco82PgMj+OkL6wBRsf4
		kKBpAYVRmwnCJaQ = rNdBKI74fAklnoCZ6(u"ࠨ࡝ࡕࡘࡑࡣࠧႽ")+IQ2KCmObsTGuiRdEzt931a40jLg+qoBMmfAWpFlK70xw8ZRh4naJ(u"ࠩส่ำ฽รࠡ࠼ࠣࠫႾ")+fF4lt9zWYxXLKZVyAco82PgMj+T97ftnWyDr2coKalSe
		RzXMe3OaJQhIG5kBHVLiSs74rdD = l1DZAt9XNQjqE7YOdrz(u"ࠪࡠࡳࡡࡒࡕࡎࡠࠫႿ")+IQ2KCmObsTGuiRdEzt931a40jLg+fWoVd0Bmtkx(u"ࠫฬ๊ำษสࠣ࠾ࠥ࠭Ⴠ")+fF4lt9zWYxXLKZVyAco82PgMj+reason
		a8QGclgFznx += JQ0OTpbAGY8khnwf+UJqj5NE0ZKm+ZLwoRpfnCWI7FgEHsz6te39lMVh+j29dQ4nWa51frts+ZLwoRpfnCWI7FgEHsz6te39lMVh+kKBpAYVRmwnCJaQ+RzXMe3OaJQhIG5kBHVLiSs74rdD+ZLwoRpfnCWI7FgEHsz6te39lMVh
	W2fBJaUN9kZwVeR1n0o4Dc(qoBMmfAWpFlK70xw8ZRh4naJ(u"ࠬࡸࡩࡨࡪࡷࠫჁ"),j8XLTuY5xcO,a8QGclgFznx,sjtU6GZQg5XC2pH4(u"࠭ࡴࡦࡺࡷࡺ࡮࡫ࡷࡠࡤ࡬࡫࡫ࡵ࡮ࡵࡡ࡯ࡳࡳ࡭ࠧჂ"))
	return
def FMUsDIQzPYcZB32(file):
	if file==V2JfszPWt6jq1hCxYKpyM53RL: X3rpWgPGf1NbukqR04Zid = DiJ8CMuYH1daWyjehfN0L(u"ࠧใ๊สส๊ࠦวๅ็ไฺ้ฯࠧჃ")
	elif file==RRCjYOQfEdAKub2s: X3rpWgPGf1NbukqR04Zid = dJHDqiKf12TXlIzSLkGUuxg4MBs3A(u"ࠨไ๋หห๋ࠠระิࠤฬ๊แ๋ัํ์์อสࠨჄ")
	r7MXibnK2fa6S31ctA = eVLmAIGFiwpr94UK6MRP5(qqzwE6imYG4c2xojI(u"ࠩࡦࡩࡳࡺࡥࡳࠩჅ"),iNc3KxwErnQ(u"ุ้ࠪำࠧ჆"),UUDAiytEL76RTmMYsuIz5evXB(u"ࠫส฻ไศฯࠪჇ"),fWoVd0Bmtkx(u"ࠬิั้ฮࠪ჈"),GLTtERWbHnFuy4PCp,UVa3fJw7k6KM(u"࠭็ๅࠢอี๏ีࠠฦื็หาࠦๅๅใࠣࠫ჉")+X3rpWgPGf1NbukqR04Zid+aXqWLoTdVgME(u"ࠧࠡล่ࠤฯื๊ะ่ࠢืาࠦวๅ็็ๅࠥลࠧ჊"))
	if r7MXibnK2fa6S31ctA==V3VlkhgjEF4n1erPXHcC0NOsfwyAJ(u"࠶ᎌ"):
		if RPbaxsNFVTwek5Kfv21DiJuzCnjMZp.path.exists(file):
			try: RPbaxsNFVTwek5Kfv21DiJuzCnjMZp.remove(file)
			except: pass
		iG7Rz2kmn0x1yLNMV3u8O(qpFY4hAwolV3,qpFY4hAwolV3,GLTtERWbHnFuy4PCp,DiJ8CMuYH1daWyjehfN0L(u"ࠨฬ่ࠤู๊อࠡ็็ๅࠥ࠭჋")+X3rpWgPGf1NbukqR04Zid)
	elif r7MXibnK2fa6S31ctA==DiJ8CMuYH1daWyjehfN0L(u"࠱ᎍ"):
		data = O8UnIZ9TiHSzXbvxGgs7wlR(file)
		iG7Rz2kmn0x1yLNMV3u8O(qpFY4hAwolV3,qpFY4hAwolV3,GLTtERWbHnFuy4PCp,CC1eY6yWZUwf2TkRvnp7EJ0AimjHBX(u"ࠩอ้ࠥหีๅษะࠤ๊๊แࠡࠩ჌")+X3rpWgPGf1NbukqR04Zid)
	return
def j3oD27Qqv5ugRC6TsUf():
	if oyFvr0T96AwpqEIgxmP<mmV2nucZ5Lpl6FO1JMPEqGoQKW(u"࠲࠺ᎎ"):
		w0CZ6B3WDJknhEsdRYyH1XAM = tR1krDGPpO025fghMT3a7UnYj(u"่้ࠪษำโࠢฦ๊ฯࠦสิฬัำ๊ࠦลึัสี้่ࠥะ์ࠣๆิ๐ๅࠡำๅ้ࠥ࠭Ⴭ")+str(oyFvr0T96AwpqEIgxmP)+sjtU6GZQg5XC2pH4(u"ࠫࠥ๎ไ่าสࠤฬ๊โ้ษษ้ࠥอไๆื๋ีฮࠦไศࠢอ฽ฺ๊๊่ࠠา็ࠥ࠴่ࠠา๊ࠤฬ๊ๅ๋ิฬࠤฯ๋ใ็ๅ้๋ࠣࠦัล์ฬࠤ็๎วว็ࠣห้็๊ะ์๋๋ฬะࠠโ์ࠣฬึ์วๆฮࠣ฽๊อฯࠡสื็้ࠦี้ำࠣฬิ๊วࠡ็้ࠤฬ๊ใหษหอࠥ࠴ࠠๅวุ่ฬำࠠศๆุ่่๊ษࠡไ่ࠤอะอะ์ฮࠤอืๆศ็ฯࠤ่๎ฯ๋ࠢศ่๎ࠦล๋ࠢศูิอัࠡำๅ้์ࠦรฺๆ์ࠤ๊์ࠠ࠲࠺࠱࠴ࠬ჎")
		iG7Rz2kmn0x1yLNMV3u8O(qpFY4hAwolV3,qpFY4hAwolV3,GLTtERWbHnFuy4PCp,w0CZ6B3WDJknhEsdRYyH1XAM)
		return
	aAxiq8p26lNG = Rqvw05BorCgcye7VE32Sf.executeJSONRPC(l32dnTEOU1skGKqeBtI9hmo(u"ࠬࢁࠢ࡫ࡵࡲࡲࡷࡶࡣࠣ࠼ࠥ࠶࠳࠶ࠢ࠭ࠤࡰࡩࡹ࡮࡯ࡥࠤ࠽ࠦࡘ࡫ࡴࡵ࡫ࡱ࡫ࡸ࠴ࡇࡦࡶࡖࡩࡹࡺࡩ࡯ࡩ࡙ࡥࡱࡻࡥࠣ࠮ࠥ࡭ࡩࠨ࠺࠲࠮ࠥࡴࡦࡸࡡ࡮ࡵࠥ࠾ࢀࠨࡳࡦࡶࡷ࡭ࡳ࡭ࠢ࠻ࠤ࡯ࡳࡴࡱࡡ࡯ࡦࡩࡩࡪࡲ࠮ࡴ࡭࡬ࡲࠧࢃࡽࠨ჏"))
	jNmfig0xKqC3MFIrQt6 = yJOhc6G7ier1Fj2pzA([sjtU6GZQg5XC2pH4(u"࠭ࡳ࡬࡫ࡱ࠲ࡲ࡫ࡴࡳࡱࡳࡳࡱ࡯ࡳࡆࡏࡄࡈࠬა")])
	UQoBYWuIxVM7894F6SsXn1ZfvAjG,aYBoHn147kXCNluEm,c32c9FHUSsnDf8l0,ceVNGJqbAIFMS1UQdZz0l6ykaOhY,WATE9RVZUtawyPrcv3z,bbeFWgZu8ftzi,JORrqtnjLT5K8AHGbQwlc0py6EhW = jNmfig0xKqC3MFIrQt6[zYvEaigKWjoq50pXBLDbGJkFc(u"ࠧࡴ࡭࡬ࡲ࠳ࡳࡥࡵࡴࡲࡴࡴࡲࡩࡴࡇࡐࡅࡉ࠭ბ")]
	if UQoBYWuIxVM7894F6SsXn1ZfvAjG or tQMjXKCA5dN4xq3beVIzaEoWkFLg(u"ࠨࡵ࡮࡭ࡳ࠴࡭ࡦࡶࡵࡳࡵࡵ࡬ࡪࡵࡈࡑࡆࡊࠧგ") not in str(aAxiq8p26lNG):
		iG7Rz2kmn0x1yLNMV3u8O(qpFY4hAwolV3,qpFY4hAwolV3,GLTtERWbHnFuy4PCp,lljaEqwTVtmKsQcOrbXxS5hgNH(u"ࠩส่็๎วว็ࠣห้๋ี้ำฬࠤฯ฿ๅๅࠢไๆ฼ࠦๅฺࠢฯ่ิࠦๅหำ๋ฬํ๊ำࠡ฻่หิࠦ࠮้ࠡำ๋ࠥอไใ๊สส๊ࠦสๆๅ้็๋ࠥๆࠡำว๎ฮࠦโ้ษษ้ࠥฮั็ษ่ะࠥ฿ๅศัࠣฬู้ไࠡื๋ีࠥฮฯๅษ้๋ࠣࠦวๅๅอหอฯࠧდ"))
		zlQAfuT2Z7nKhGdXs = fqMxDmSFLEen9yrCaBNKkIOG84TAg()
		if not zlQAfuT2Z7nKhGdXs: return
	zzV4dDTMsGIoB8hqWp5(gBExoceumj4y8bFW9hY2aNMVSr)
	return
def zzV4dDTMsGIoB8hqWp5(showDialogs=gBExoceumj4y8bFW9hY2aNMVSr):
	aAxiq8p26lNG = Rqvw05BorCgcye7VE32Sf.executeJSONRPC(UVa3fJw7k6KM(u"ࠪࡿࠧࡰࡳࡰࡰࡵࡴࡨࠨ࠺ࠣ࠴࠱࠴ࠧ࠲ࠢ࡮ࡧࡷ࡬ࡴࡪࠢ࠻ࠤࡖࡩࡹࡺࡩ࡯ࡩࡶ࠲ࡌ࡫ࡴࡔࡧࡷࡸ࡮ࡴࡧࡗࡣ࡯ࡹࡪࠨࠬࠣ࡫ࡧࠦ࠿࠷ࠬࠣࡲࡤࡶࡦࡳࡳࠣ࠼ࡾࠦࡸ࡫ࡴࡵ࡫ࡱ࡫ࠧࡀࠢ࡭ࡱࡲ࡯ࡦࡴࡤࡧࡧࡨࡰ࠳ࡹ࡫ࡪࡰࠥࢁࢂ࠭ე"))
	if UUDAiytEL76RTmMYsuIz5evXB(u"ࠫࡸࡱࡩ࡯࠰ࡰࡩࡹࡸ࡯ࡱࡱ࡯࡭ࡸࡋࡍࡂࡆࠪვ") not in str(aAxiq8p26lNG):
		if showDialogs:
			iG7Rz2kmn0x1yLNMV3u8O(qpFY4hAwolV3,qpFY4hAwolV3,GLTtERWbHnFuy4PCp,YY8UDX3MJhb91AHw7fg(u"๊ࠬไฤีไࠤัํวำๅ่ࠣฬ๊ࠦิฬัำ๊ࠦฬๅั้ࠣฯื่ษ๊็ืࠥ฿ๅศัࠣ࠲ࠥอไใ๊สส๊ࠦวๅ็ุ์ึฯࠠห฻่่ࠥ็โุ่ࠢ฽ࠥาไะ่ࠢฮึ๎ศ้ๆึࠤ฾๋วะࠢ࠱ࠤ์ึ็ࠡษ็ๆํอฦๆࠢอ้่์ใࠡ็้ࠤึส๊สࠢๅ์ฬฬๅࠡสิ๊ฬ๋ฬࠡ฻่หิࠦศีๅ็ࠤฺ๎ัࠡสา่ฬࠦๅ็ࠢส่่ะวษหࠪზ"))
		return
	orSXGBMALzHplbV = RPbaxsNFVTwek5Kfv21DiJuzCnjMZp.path.join(ssQ5T7em6WrVwIGtXoxNKaBv48zHAM,l32dnTEOU1skGKqeBtI9hmo(u"࠭ࡡࡥࡦࡲࡲࡸ࠭თ"),sjtU6GZQg5XC2pH4(u"ࠧࡴ࡭࡬ࡲ࠳ࡳࡥࡵࡴࡲࡴࡴࡲࡩࡴࡇࡐࡅࡉ࠭ი"),aXqWLoTdVgME(u"ࠨ࠹࠵࠴ࡵ࠭კ"),mmV2nucZ5Lpl6FO1JMPEqGoQKW(u"ࠩࡐࡽ࡛࡯ࡤࡦࡱࡑࡥࡻ࠴ࡸ࡮࡮ࠪლ"))
	if not RPbaxsNFVTwek5Kfv21DiJuzCnjMZp.path.exists(orSXGBMALzHplbV): return
	BdTIyXJb43x1g26YicFWC0sP = open(orSXGBMALzHplbV,aXqWLoTdVgME(u"ࠪࡶࡧ࠭მ")).read()
	if DLod2Of8CkRrtzJynev: BdTIyXJb43x1g26YicFWC0sP = BdTIyXJb43x1g26YicFWC0sP.decode(nV3Tip6XsH1rJw79DPOU)
	pzfxCOilGUmActSDXj3Z75YoMsI = ePhmG1jLD6.findall(N3flV6EJsD5CzS(u"ࠫࡁࡼࡩࡦࡹࡶࡂ࠭ࡢࡤࠬ࠮࡟ࡨ࠰࠲࡜ࡥ࠭ࠬ࠰࠭࠴ࠪࡀࠫ࠿࠳ࡻ࡯ࡥࡸࡵࡁࠫნ"),BdTIyXJb43x1g26YicFWC0sP,ePhmG1jLD6.DOTALL)
	CCYyKvHcDfNtkGSzExXIepnB3,nnhGYLzxSZOHbIDrTPiaqjgQ = pzfxCOilGUmActSDXj3Z75YoMsI[vvXoMLlg513]
	OLpeGxuEDVSNtw4 = rNdBKI74fAklnoCZ6(u"ࠬࡂࡶࡪࡧࡺࡷࡃ࠭ო")+CCYyKvHcDfNtkGSzExXIepnB3+mmV2nucZ5Lpl6FO1JMPEqGoQKW(u"࠭ࠬࠨპ")+nnhGYLzxSZOHbIDrTPiaqjgQ+BRWqdruz2A0(u"ࠧ࠽࠱ࡹ࡭ࡪࡽࡳ࠿ࠩჟ")
	if showDialogs:
		PIMHsfkX1EZOR0o2SAzcyQVi4rNm98 = Rqvw05BorCgcye7VE32Sf.getInfoLabel(aXqWLoTdVgME(u"ࠨࡅࡲࡲࡹࡧࡩ࡯ࡧࡵ࠲࡛࡯ࡥࡸ࡯ࡲࡨࡪ࠭რ"))
		if PIMHsfkX1EZOR0o2SAzcyQVi4rNm98==N3flV6EJsD5CzS(u"ࠩࡈࡑࡆࡊࠠࡍ࡫ࡶࡸࠬს"): Zev6iJWjks = l1DZAt9XNQjqE7YOdrz(u"ࠪๆํอฦๆࠢส่่ะวษหࠪტ")
		elif PIMHsfkX1EZOR0o2SAzcyQVi4rNm98==DaFZHsThGmd0zv6e(u"ࠫࡊࡓࡁࡅࠢࡊࡥࡱࡲࡥࡳࡻࠪუ"): Zev6iJWjks = Ie5s2cBtSfdHjzQ4rA9kYlo6D18(u"่่ࠬศศ่ࠤฬ๊ี้ำࠪფ")
		else: Zev6iJWjks = qqzwE6imYG4c2xojI(u"࠭โ้ษษ้ࠥษฮา๋ࠪქ")
		r7MXibnK2fa6S31ctA = eVLmAIGFiwpr94UK6MRP5(aXqWLoTdVgME(u"ࠧࡤࡧࡱࡸࡪࡸࠧღ"),Ie5s2cBtSfdHjzQ4rA9kYlo6D18(u"ࠨไ๋หห๋ࠠฤะิํࠬყ"),l32dnTEOU1skGKqeBtI9hmo(u"ࠩๅ์ฬฬๅࠡษ็็ฯอศสࠩშ"),RlOvin8YIGC2KZXJPk9m0acrMobUex(u"ࠪๆํอฦๆࠢสฺ่๎ัࠨჩ"),BRWqdruz2A0(u"ࠫฬ์สࠡฯส่๏อࠠหีอาิ๋ࠠࠨც")+Zev6iJWjks,l32dnTEOU1skGKqeBtI9hmo(u"ࠬอๆหࠢส่ว์ࠠหีอาิ๋ࠠศๆศูิอัࠡษ็วำ๐ัࠡๆฯ่ิࠦๅหำ๋ฬํ๊ำࠡ฻่หิࠦ࠮๊๊ࠡิฬࠦๅฺ่ส๋ࠥอๆไࠢอืฯ฽ฺ๊ࠢสืฯิฯศ็ࠣห้่่ศศ่ࠤฬ๊ๅึ๊ิอࠥฮฯๅษ้๋ࠣࠦโ้ษษ้ࠥอไไฬสฬฮࠦ࠮๊ࠡฦ๎฻อࠠหีอ฻๏฿ࠠฦ์ๅหๆํวࠡใํࠤศ๐้ࠠไอࠤฯฺวยࠢ࡟ࡲࡡࡴࠠࠨძ")+IQ2KCmObsTGuiRdEzt931a40jLg+LZWMikPEB81KSGyxfJtUsCA(u"࠭ࠠฤะอีࠥอไร่๊ࠣํ฿ࠠศๆๅ์ฬฬๅࠡษ็ฮ๏ࠦสา์าࠤศูสฯัส้์อࠠภࠣࠪწ")+fF4lt9zWYxXLKZVyAco82PgMj)
		if r7MXibnK2fa6S31ctA==aXqWLoTdVgME(u"࠳ᎏ"): ZSXxf8nba4PEOzoyW = tR1krDGPpO025fghMT3a7UnYj(u"ࠧࡆࡏࡄࡈࠥࡒࡩࡴࡶࠪჭ")
		elif r7MXibnK2fa6S31ctA==Ie5s2cBtSfdHjzQ4rA9kYlo6D18(u"࠵᎐"): ZSXxf8nba4PEOzoyW = DiJ8CMuYH1daWyjehfN0L(u"ࠨࡇࡐࡅࡉࠦࡇࡢ࡮࡯ࡩࡷࡿࠧხ")
		else: ZSXxf8nba4PEOzoyW = qpFY4hAwolV3
	else:
		PIMHsfkX1EZOR0o2SAzcyQVi4rNm98 = gdPslyFW8ITBcpA302.getSetting(Ie5s2cBtSfdHjzQ4rA9kYlo6D18(u"ࠩࡤࡺ࠳ࡳࡹࡴ࡭࡬ࡲ࠳ࡼࡩࡦࡹࡰࡳࡩ࡫ࠧჯ"))
		if   PIMHsfkX1EZOR0o2SAzcyQVi4rNm98==qpFY4hAwolV3: r7MXibnK2fa6S31ctA = tQMjXKCA5dN4xq3beVIzaEoWkFLg(u"࠴᎑")
		elif PIMHsfkX1EZOR0o2SAzcyQVi4rNm98==RlOvin8YIGC2KZXJPk9m0acrMobUex(u"ࠪࡉࡒࡇࡄࠡࡎ࡬ࡷࡹ࠭ჰ"): r7MXibnK2fa6S31ctA = Ie5s2cBtSfdHjzQ4rA9kYlo6D18(u"࠶᎒")
		elif PIMHsfkX1EZOR0o2SAzcyQVi4rNm98==sjtU6GZQg5XC2pH4(u"ࠫࡊࡓࡁࡅࠢࡊࡥࡱࡲࡥࡳࡻࠪჱ"): r7MXibnK2fa6S31ctA = ddiCzu6yahj5RtTISMJ48sNnZBU(u"࠸᎓")
		ZSXxf8nba4PEOzoyW = PIMHsfkX1EZOR0o2SAzcyQVi4rNm98
	if   r7MXibnK2fa6S31ctA==LZWMikPEB81KSGyxfJtUsCA(u"࠰᎔"): VVhbNrcPEmozvALgf = CC1eY6yWZUwf2TkRvnp7EJ0AimjHBX(u"ࠬ࠻࠵࠭࠷࠷࠸࠱࠻࠵࠶ࠩჲ")
	elif r7MXibnK2fa6S31ctA==N3flV6EJsD5CzS(u"࠲᎕"): VVhbNrcPEmozvALgf = sjtU6GZQg5XC2pH4(u"࠭࠵࠵࠶࠯࠹࠺࠻ࠬ࠶࠷ࠪჳ")
	elif r7MXibnK2fa6S31ctA==ee86G9ladLHVbh5mikzCo(u"࠴᎖"): VVhbNrcPEmozvALgf = mmV2nucZ5Lpl6FO1JMPEqGoQKW(u"ࠧ࠶࠷࠸࠰࠺࠻ࠬ࠶࠶࠷ࠫჴ")
	else: return
	gdPslyFW8ITBcpA302.setSetting(iNc3KxwErnQ(u"ࠨࡣࡹ࠲ࡲࡿࡳ࡬࡫ࡱ࠲ࡻ࡯ࡥࡸ࡯ࡲࡨࡪ࠭ჵ"),ZSXxf8nba4PEOzoyW)
	QQULFpDty9rEOP0G4W = LZWMikPEB81KSGyxfJtUsCA(u"ࠩ࠿ࡺ࡮࡫ࡷࡴࡀࠪჶ")+VVhbNrcPEmozvALgf+fWoVd0Bmtkx(u"ࠪ࠰ࠬჷ")+nnhGYLzxSZOHbIDrTPiaqjgQ+l1DZAt9XNQjqE7YOdrz(u"ࠫࡁ࠵ࡶࡪࡧࡺࡷࡃ࠭ჸ")
	BAm6WyxJ0ahYvlcN4b1sUELPSru5Q = BdTIyXJb43x1g26YicFWC0sP.replace(OLpeGxuEDVSNtw4,QQULFpDty9rEOP0G4W)
	if DLod2Of8CkRrtzJynev: BAm6WyxJ0ahYvlcN4b1sUELPSru5Q = BAm6WyxJ0ahYvlcN4b1sUELPSru5Q.encode(nV3Tip6XsH1rJw79DPOU)
	open(orSXGBMALzHplbV,fWoVd0Bmtkx(u"ࠬࡽࡢࠨჹ")).write(BAm6WyxJ0ahYvlcN4b1sUELPSru5Q)
	LLvyStW429DEZKlA(k8kdUSxohLVljnrY,fWoVd0Bmtkx(u"࠭࠮࡝ࡶࡖ࡯࡮ࡴࠠࡅࡧࡩࡥࡺࡲࡴࠡࡘ࡬ࡩࡼࡹ࠺ࠡ࡝ࠣࠫჺ")+VVhbNrcPEmozvALgf+fWoVd0Bmtkx(u"ࠧࠡ࡟ࠪ჻"))
	if showDialogs: Rqvw05BorCgcye7VE32Sf.executebuiltin(V3VlkhgjEF4n1erPXHcC0NOsfwyAJ(u"ࠨࡔࡨࡰࡴࡧࡤࡔ࡭࡬ࡲ࠭࠯ࠧჼ"))
	return
def ZhVt1wGsjK7zyYbc8Jm():
	o4oUxD3u18K59ghHIY = VVpbtSKYUGXrNMwAWFo9IOjZP(qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,GLTtERWbHnFuy4PCp,Ie5s2cBtSfdHjzQ4rA9kYlo6D18(u"ࠩหี๋อๅอࠢ฼้ฬีࠠโ์๊ࠤฺ๊ใๅหࠣ฽๋ีใࠡ࠰࠱࠲ࠥหๅศࠢฦ่ส฻ฯศำࠣๆิ๐ๅࠡ࠰࠱࠲ࠥษ่ࠡษ้ฮ๋ࠥๅ็๊฼ࠤ๊์ࠠศีอาิอๅࠡษ็ฬึ์วๆฮࠣ࠲࠳࠴ࠠฤ๊่ࠣิ๐ใࠡ็ื็้ฯࠠฤะิํࠥะฮึࠢฯ๋ฬุใࠡล้ฮࠥ๎ไศࠢอาฺࠦศใ์ฬࠤำ๊โࠡษ็่์ࠦ࡜࡯࡞ࡱࠤาอ่ๅࠢอัิ๐หࠡษ็ฬึ์วๆฮࠣวํࠦวหื็ࠤออไๆสิ้ัࠦไๆ฻ิๅฮࠦำษสࠣห้๋ิไๆฬࠤ฾์ฯไࠢ࠱࠲࠳ࠦ็ๅࠢอี๏ีࠠโฯุࠤฬ๊สฮัํฯฬะࠠศๆล๊ࠥลࠧჽ"))
	if o4oUxD3u18K59ghHIY==sjtU6GZQg5XC2pH4(u"࠴᎗"): jZn8dWH7bUchfGaym3FV()
	return
def xx0h3IHbKCZult():
	iG7Rz2kmn0x1yLNMV3u8O(qpFY4hAwolV3,qpFY4hAwolV3,GLTtERWbHnFuy4PCp,BRWqdruz2A0(u"๋ࠪีอࠠศๆ่์็฿ࠠๆ฼็ๆ๋ࠥๆࠡษ็ฺ้ีั๊ࠡ฽๎ึࠦๅฺำ๋ๅ๋ࠥส๋ࠢํีั฿ࠠๅๆ฼้้࠭ჾ"))
	return
def X0x5yQTtKeNWukpc():
	JQ0OTpbAGY8khnwf = IQ2KCmObsTGuiRdEzt931a40jLg+qqzwE6imYG4c2xojI(u"ࠫฯ฿ฯศัุࠣ๏฿ษࠡฤ็ࠤ๊ำๅะࠢ็ื๋ฯࠠ࠳࠲࠵࠵ࠥࡀࠠࠨჿ")+fF4lt9zWYxXLKZVyAco82PgMj
	JQ0OTpbAGY8khnwf += BRWqdruz2A0(u"ࠬอไๆ๊ๅ฽ࠥษฯ็ษ๊ࠤๆ๐็ࠡวะูฬฬ๊สࠢ็฽ิีࠠศๆื๎฾ฯࠠโ์ࠣห้฿วๅ็ࠣฮ๊ࠦฬๆ฻๊ห๋ࠥๆࠡฮ่๎฾ࠦวๅ็ุหิืࠠศๆ่ฮํ็ัสࠢไ๎ࠥอไฦ่อี๋ะࠠศๆๅำ๏๋ษ๊ࠡส่ัี๊ะหࠣห้ำใ้็ํอࠥ๎วๅ฼ํีࠥำใ้็ํอࠥ๎ๅ็ࠢฯ้๏฿ࠠะ๊็ࠤฬู๊ศๆ่ࠤะ๋ࠠห็ࠣฮํำ๊ะ้สࠤํำำศสࠣหู้๋ะๆࠣัุฮࠠิๅส๊ࠥี่ๅࠢส่฾อไๆࠢ็ื๋ฯࠠ࠳࠲࠵࠵ࠥ๎็๋ࠢส่สำีศศํอࠥอไฤฯาฯࠥ๎วๅลื้้ࠦวๅฬํࠤฯฺ๋ࠠ็็๋ฬࠦแ๋ࠢสุ่์่ศฬࠣห้฿ิาหࠣห้๋วื์ฬࠫᄀ")
	JQ0OTpbAGY8khnwf += ZLwoRpfnCWI7FgEHsz6te39lMVh+IQ2KCmObsTGuiRdEzt931a40jLg+BRWqdruz2A0(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡵ࡫ࡱࡽ࠳ࡩࡣ࠰ࡵ࡫࡭ࡦࡩ࡯ࡶࡰࡷࠫᄁ")+fF4lt9zWYxXLKZVyAco82PgMj
	UJqj5NE0ZKm = IQ2KCmObsTGuiRdEzt931a40jLg+LZWMikPEB81KSGyxfJtUsCA(u"ࠧษำ้ห๊าࠠีำํ฻ࠥอไๆี็้ࠥࡀࠠࠨᄂ")+fF4lt9zWYxXLKZVyAco82PgMj
	UJqj5NE0ZKm += c2RKu0xG1eC8MiohyE(u"ࠨ้๋ࠤ฾ฮวาหࠣ฽๋ࠦศา่ส้ั๊้ࠦใิࠤ๊฿ไ้็สฮࠥำำศสํอ้ࠥห๋ำฬࠤฯํๅࠡฮ่๎฾ࠦวๅ็ึ่๊๐ๆࠡ็ฮ่ࠥษ่ใษอࠤฬ๊ีๅษฬࠤํษ่ใษอࠤฬ๊ใิ๊ไࠤํอไฯี๋ๅࠥ๎ิไๆࠣห้่ๅา๋ࠢวํ่วหࠢส่็๋ั๊ࠡฦ๎฻อ๋๊ࠠไีࠥืฤ๋หࠣห้ํไศๆࠣๅ๏ࠦฬๆ์฼ࠤิ๎ไࠡษ็฽ฬ๊ๅ๊ࠡฦ๎฻อࠠโ์๊ࠤฯ่่๋็้ࠣ๏๊วะ์ࠣ์์าั๋๋ࠢๅ๏ํࠠฤ์ูหࠥฮอฬ๋ࠢๆึอมสࠢส่็ืย็๋ࠢว๏฼วࠡใํ๋ࠥอำหะสีฮ่ࠦหใสศ้่ࠦโ์๊ࠤศ่่ศๆู้๋่ࠣษห่้ࠣษๅศ็ࠣ฽้๐้ࠠล่์ึࠦรฯำ์ࠤฯํๅࠡๅ็ࠤู๊ไๆࠢ࠱ࠤฬ๊ศา่ส้ัࠦๅไฬ๋ฬࠥฮไ฻หࠣะฬ็วࠡีๆีอะ้ࠠ์ึฮำีๅ่ࠡ฻ห๊่๋่ࠦา์ืࠦสฮฬࠣฬ๏ฬษ๊ࠡํ๊ิ๎าࠡๅสะ๏ะ้ࠠ็ัฺูࠦแใู่ࠣศา็ำหࠣห้๎๊็ั๋ึࠥ࠴ࠠศๆ่์็฿ࠠศๆิื๊๐ࠠๅๆหี๋อๅอ๊ࠢ์ࠬᄃ")
	UJqj5NE0ZKm += ZLwoRpfnCWI7FgEHsz6te39lMVh+IQ2KCmObsTGuiRdEzt931a40jLg+BRWqdruz2A0(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡸ࡮ࡴࡹ࠯ࡥࡦ࠳ࡲࡻࡳ࡭࡫ࡰࡶࡺࡲࡥࡳࠩᄄ")+fF4lt9zWYxXLKZVyAco82PgMj
	w0CZ6B3WDJknhEsdRYyH1XAM = lljaEqwTVtmKsQcOrbXxS5hgNH(u"ࠪ࡟ࡗ࡚ࡌ࡞ࠩᄅ")+JQ0OTpbAGY8khnwf+qqzwE6imYG4c2xojI(u"ࠫࡡࡴ࡜࡯࡞ࡱ࡟ࡗ࡚ࡌ࡞ࠩᄆ")+UJqj5NE0ZKm
	W2fBJaUN9kZwVeR1n0o4Dc(dJHDqiKf12TXlIzSLkGUuxg4MBs3A(u"ࠬࡸࡩࡨࡪࡷࠫᄇ"),qpFY4hAwolV3,w0CZ6B3WDJknhEsdRYyH1XAM)
	return
def PThFb1sQXfUl0RuHBVJStj(FAHCtdm48uIsx):
	UnGr9wJWdq(dzcNuIbsgK3yZ6SXGaEHPfOj5vk)
	weoxDcHJ1PsSiE5pqY7bWMIfX = asFZzCl2vSoiNRU34K(FAHCtdm48uIsx)
	for UUNoXGAs6Py in [tR1krDGPpO025fghMT3a7UnYj(u"࠭ࡍࡆࡕࡖࡅࡌࡋࡓࠨᄈ"),kYDaz79TFlXoR(u"ࠧࡒࡗࡈࡗ࡙ࡏࡏࡏࡕࠪᄉ"),V3VlkhgjEF4n1erPXHcC0NOsfwyAJ(u"ࠨࡏࡈࡗࡘࡇࡇࡆࡕࡢࡘࡘ࠭ᄊ"),viRJWOC5jsYe84(u"ࠩࡔ࡙ࡊ࡙ࡔࡊࡑࡑࡗࡤ࡚ࡓࠨᄋ")]:
		if UUNoXGAs6Py in i4bFG3rKE6.SEND_THESE_EVENTS: i4bFG3rKE6.SEND_THESE_EVENTS.remove(UUNoXGAs6Py)
	WRa8n54C9T(l32dnTEOU1skGKqeBtI9hmo(u"ࠪࡈࡔࡔࡁࡕࡋࡒࡒࡘ࠭ᄌ"))
	id,WRbn1LC2xPJMZft,nKb2w7UW0qVN,OkL6wBRsf4,T97ftnWyDr2coKalSe,reason = weoxDcHJ1PsSiE5pqY7bWMIfX[vvXoMLlg513]
	SYdPURfIsm4j1CT80upw,j8XLTuY5xcO = OkL6wBRsf4.split(l32dnTEOU1skGKqeBtI9hmo(u"ࠫࡡࡴ࠻࠼ࠩᄍ"))
	UJqj5NE0ZKm,kKBpAYVRmwnCJaQ,RzXMe3OaJQhIG5kBHVLiSs74rdD = T97ftnWyDr2coKalSe.split(dJHDqiKf12TXlIzSLkGUuxg4MBs3A(u"ࠬࡢ࡮࠼࠽ࠪᄎ"))
	AqN4mJIwugrCLDzWS3VZplvidU = gBExoceumj4y8bFW9hY2aNMVSr
	while AqN4mJIwugrCLDzWS3VZplvidU:
		Gy580jFVbXqft3d = eVLmAIGFiwpr94UK6MRP5(qpFY4hAwolV3,RlOvin8YIGC2KZXJPk9m0acrMobUex(u"࠭ฮา๊ฯࠫᄏ"),tQMjXKCA5dN4xq3beVIzaEoWkFLg(u"ࠧฦำึห้ࠦัิษ็อ๊ࠥไๆสิ้ั࠭ᄐ"),BRWqdruz2A0(u"ࠨไสส๊ฯࠠศๆอฬึ฿วหࠩᄑ"),zYvEaigKWjoq50pXBLDbGJkFc(u"ࠩ็ษ๏่วโࠢส่ส฿ไศ่สฮࠥࡀࠠࠡฬหี฾ࠦร้ࠢสุ้ำࠠศๆหี๋อๅอࠩᄒ"),UJqj5NE0ZKm)
		if Gy580jFVbXqft3d==Ie5s2cBtSfdHjzQ4rA9kYlo6D18(u"࠶᎘"): kZWeo1YjIEz3lXGMt4siHN = eVLmAIGFiwpr94UK6MRP5(qpFY4hAwolV3,qpFY4hAwolV3,iNc3KxwErnQ(u"ࠪ฽ํีษࠨᄓ"),qpFY4hAwolV3,DiJ8CMuYH1daWyjehfN0L(u"๊ࠫฮฯฤࠢส่ฯฮัฺࠢ฽๎ึࠦโศส็ࠤ้๊ๆใษืࠫᄔ"),kKBpAYVRmwnCJaQ,qqzwE6imYG4c2xojI(u"ࠬࡩ࡯࡯ࡨ࡬ࡶࡲࡥࡳ࡮ࡣ࡯ࡰ࡫ࡵ࡮ࡵࠩᄕ"))
		elif Gy580jFVbXqft3d==DaFZHsThGmd0zv6e(u"࠶᎙"): cSYpMx6W4HlAQK9()
		else: AqN4mJIwugrCLDzWS3VZplvidU = ag8rjZo1Vz4IPdcOT
	if FAHCtdm48uIsx: E2E18vJ4hLaZpuWSfoMlY9yBzj6b(ag8rjZo1Vz4IPdcOT)
	return
def wjK3lLYRWQkXtZ6HNqiMEgpPBuC():
	hhL6vp9bzkHJQ5qjD1C()
	wwCRPSDInyYMQtWLq7gm8NTsO = gdPslyFW8ITBcpA302.getSetting(zYvEaigKWjoq50pXBLDbGJkFc(u"࠭ࡡࡷ࠰ࡶࡸࡦࡺࡵࡴ࠰ࡦࡥࡨ࡮ࡥࠨᄖ"))
	w0CZ6B3WDJknhEsdRYyH1XAM = {}
	w0CZ6B3WDJknhEsdRYyH1XAM[aXqWLoTdVgME(u"ࠧࡂࡗࡗࡓࠬᄗ")] = DiJ8CMuYH1daWyjehfN0L(u"ࠨษ็็ฬฺࠠศๆอ่็อฦ๋ࠢํ฽๊๊ࠧᄘ")
	w0CZ6B3WDJknhEsdRYyH1XAM[zYvEaigKWjoq50pXBLDbGJkFc(u"ࠩࡖࡘࡔࡖࠧᄙ")] = YY8UDX3MJhb91AHw7fg(u"ࠪห้้วี่ࠢฮํ่แࠡฬ่ห๊อ้ࠠสส่่อๅๅࠩᄚ")
	w0CZ6B3WDJknhEsdRYyH1XAM[UUDAiytEL76RTmMYsuIz5evXB(u"ࠫࡑࡏࡍࡊࡖࡈࡈࠬᄛ")] = aXqWLoTdVgME(u"้ࠬวีࠢฯำฬࠦโึ์ิࠤฬ๊ๅะ๋ࠣ࠲ࠥ࠭ᄜ")+str(FeUDj5b2oEV/ddiCzu6yahj5RtTISMJ48sNnZBU(u"࠼࠰᎚"))+Ie5s2cBtSfdHjzQ4rA9kYlo6D18(u"࠭ࠠะไํๆฮࠦแใูࠪᄝ")
	LH9DBmcbiw = w0CZ6B3WDJknhEsdRYyH1XAM[wwCRPSDInyYMQtWLq7gm8NTsO]
	r7MXibnK2fa6S31ctA = eVLmAIGFiwpr94UK6MRP5(qpFY4hAwolV3,kYDaz79TFlXoR(u"ࠧไษืࠤࠬᄞ")+str(FeUDj5b2oEV/ee86G9ladLHVbh5mikzCo(u"࠶࠱᎛"))+zYvEaigKWjoq50pXBLDbGJkFc(u"ࠨࠢาๆ๏่ษࠨᄟ"),ee86G9ladLHVbh5mikzCo(u"ࠩอุ฿๐ไࠡฬ็ๆฬฬ๊ࠨᄠ"),YY8UDX3MJhb91AHw7fg(u"ࠪษ๏่วโࠢๆห๊๊ࠧᄡ"),LH9DBmcbiw,BRWqdruz2A0(u"ࠫ์๊ࠠหำํำࠥอำหะาห๊ࠦวๅๅสุࠥอไัๅํࠤฬ๊สๅไสส๏ࠦรๆࠢอี๏ีࠠฦ์ๅหๆࠦวๅๅสุࠥฮวๅๅส้้ࠦรๆࠢอี๏ีࠠไษืࠤ฾๋ั่ࠢๅู๏ืࠠอัสࠤฤࠧࠧᄢ"))
	if r7MXibnK2fa6S31ctA==RlOvin8YIGC2KZXJPk9m0acrMobUex(u"࠱᎜"): Z5GDXLJHVCir80NwcjWdBAUxR2vI = UUDAiytEL76RTmMYsuIz5evXB(u"ࠬࡒࡉࡎࡋࡗࡉࡉ࠭ᄣ")
	elif r7MXibnK2fa6S31ctA==aXqWLoTdVgME(u"࠳᎝"): Z5GDXLJHVCir80NwcjWdBAUxR2vI = aXqWLoTdVgME(u"࠭ࡁࡖࡖࡒࠫᄤ")
	elif r7MXibnK2fa6S31ctA==IaBhDMJc17302LgSvyxd(u"࠵᎞"): Z5GDXLJHVCir80NwcjWdBAUxR2vI = V3VlkhgjEF4n1erPXHcC0NOsfwyAJ(u"ࠧࡔࡖࡒࡔࠬᄥ")
	else: Z5GDXLJHVCir80NwcjWdBAUxR2vI = qpFY4hAwolV3
	if Z5GDXLJHVCir80NwcjWdBAUxR2vI:
		gdPslyFW8ITBcpA302.setSetting(Ie5s2cBtSfdHjzQ4rA9kYlo6D18(u"ࠨࡣࡹ࠲ࡸࡺࡡࡵࡷࡶ࠲ࡨࡧࡣࡩࡧࠪᄦ"),Z5GDXLJHVCir80NwcjWdBAUxR2vI)
		r6fZq1hIQAox7 = w0CZ6B3WDJknhEsdRYyH1XAM[Z5GDXLJHVCir80NwcjWdBAUxR2vI]
		iG7Rz2kmn0x1yLNMV3u8O(qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,r6fZq1hIQAox7)
	return
def GNf1VjeX3mIYLFbhJlwPRCW6nT():
	w0CZ6B3WDJknhEsdRYyH1XAM = {}
	w0CZ6B3WDJknhEsdRYyH1XAM[zYvEaigKWjoq50pXBLDbGJkFc(u"ࠩࡄ࡙࡙ࡕࠧᄧ")] = ddiCzu6yahj5RtTISMJ48sNnZBU(u"ࠪื๏ืแาࠢࡇࡒࡘࠦวๅฬ็ๆฬฬ๊ࠡ์฼้้ࡀࠠࠨᄨ")
	w0CZ6B3WDJknhEsdRYyH1XAM[ee86G9ladLHVbh5mikzCo(u"ࠫࡆ࡙ࡋࠨᄩ")] = CC1eY6yWZUwf2TkRvnp7EJ0AimjHBX(u"ู๊ࠬาใิࠤࡉࡔࡓࠡีํ฽๊๊ࠠษ฻าࠤฬ๊ำๆษะࠤ้ํ࠺ࠡࠩᄪ")
	w0CZ6B3WDJknhEsdRYyH1XAM[ee86G9ladLHVbh5mikzCo(u"࠭ࡓࡕࡑࡓࠫᄫ")] = mmV2nucZ5Lpl6FO1JMPEqGoQKW(u"ࠧิ์ิๅึࠦࡄࡏࡕ้ࠣฯ๎โโࠢอ้ฬ๋ว๊ࠡหห้้วๆๆࠪᄬ")
	TtHFL2ShCiKYAEwfaBbMrVjdRO = gdPslyFW8ITBcpA302.getSetting(N3flV6EJsD5CzS(u"ࠨࡣࡹ࠲ࡸࡺࡡࡵࡷࡶ࠲ࡩࡴࡳࠨᄭ"))
	wwCRPSDInyYMQtWLq7gm8NTsO = gdPslyFW8ITBcpA302.getSetting(aXqWLoTdVgME(u"ࠩࡤࡺ࠳ࡹࡴࡢࡶࡸࡷ࠳ࡻࡳࡦࡦࡱࡷࠬᄮ"))
	LH9DBmcbiw = w0CZ6B3WDJknhEsdRYyH1XAM[wwCRPSDInyYMQtWLq7gm8NTsO]+TtHFL2ShCiKYAEwfaBbMrVjdRO
	r7MXibnK2fa6S31ctA = eVLmAIGFiwpr94UK6MRP5(qpFY4hAwolV3,IaBhDMJc17302LgSvyxd(u"ࠪฮูเ๊ๅࠢ฼๊ิࠦวๅ็๋หๆ่ษࠨᄯ"),mmV2nucZ5Lpl6FO1JMPEqGoQKW(u"ࠫฯฺฺ๋ๆࠣฮ้่วว์ࠪᄰ"),rNdBKI74fAklnoCZ6(u"ࠬห๊ใษไࠤ่อๅๅࠩᄱ"),LH9DBmcbiw,N3flV6EJsD5CzS(u"࠭ำ๋ำไีࠥࡊࡎࡔ๊ࠢ์ࠥา็ศิࠣๅ๏ࠦวๅว้ฮึ์๊หࠢํๆํ๋ࠠษฬะ์๏๊ࠠฤี่หฦࠦวๅ็๋ห็฿้ࠠษ็ื๏ืแาษอࠤส๊้ࠡลิๆฬ๋้ࠠ฻้ำࠥฮูืࠢส่๋อำࠡ์ๅ์๊ࠦศฮฮหࠤํ๋ๆฺ๋ࠢั฻ืࠠษ฻ูࠤฬ๊ๅ้ษๅ฽ࠥ࠴ࠠๅฬื฾๏๊ࠠิ์ิๅึࠦࡄࡏࡕࠣๆ๊ࠦศศะอ๎ฬืࠠศๆึ๎ึ็ัࠡษ็้๋อำษࠢฦ์่ࠥๅࠡสศ๎็อแ่ࠢหห้้วๆๆࠪᄲ"))
	if r7MXibnK2fa6S31ctA==viRJWOC5jsYe84(u"࠴᎟"): Z5GDXLJHVCir80NwcjWdBAUxR2vI = UUDAiytEL76RTmMYsuIz5evXB(u"ࠧࡂࡕࡎࠫᄳ")
	elif r7MXibnK2fa6S31ctA==YY8UDX3MJhb91AHw7fg(u"࠶Ꭰ"): Z5GDXLJHVCir80NwcjWdBAUxR2vI = qqzwE6imYG4c2xojI(u"ࠨࡃࡘࡘࡔ࠭ᄴ")
	elif r7MXibnK2fa6S31ctA==LZWMikPEB81KSGyxfJtUsCA(u"࠸Ꭱ"): Z5GDXLJHVCir80NwcjWdBAUxR2vI = V3VlkhgjEF4n1erPXHcC0NOsfwyAJ(u"ࠩࡖࡘࡔࡖࠧᄵ")
	if r7MXibnK2fa6S31ctA in [mmV2nucZ5Lpl6FO1JMPEqGoQKW(u"࠱Ꭳ"),ddiCzu6yahj5RtTISMJ48sNnZBU(u"࠱Ꭲ")]:
		o4oUxD3u18K59ghHIY = VVpbtSKYUGXrNMwAWFo9IOjZP(kYDaz79TFlXoR(u"ࠪࡧࡪࡴࡴࡦࡴࠪᄶ"),l32dnTEOU1skGKqeBtI9hmo(u"ุࠫ๐ัโำ࠽ࠤࠬᄷ")+i4bFG3rKE6.DNS_SERVERS[mZi0S72jGoHpLO],aXqWLoTdVgME(u"ู๊ࠬาใิ࠾ࠥ࠭ᄸ")+i4bFG3rKE6.DNS_SERVERS[vvXoMLlg513],qpFY4hAwolV3,CC1eY6yWZUwf2TkRvnp7EJ0AimjHBX(u"࠭รฯฬสีู๊ࠥาใิࠤࡉࡔࡓࠡษ็้๋อำษࠢ็็ࠬᄹ"))
		if o4oUxD3u18K59ghHIY==l32dnTEOU1skGKqeBtI9hmo(u"࠳Ꭴ"): FbPVyxAuaIiYj2wlJgsRm3G = i4bFG3rKE6.DNS_SERVERS[vvXoMLlg513]
		else: FbPVyxAuaIiYj2wlJgsRm3G = i4bFG3rKE6.DNS_SERVERS[mZi0S72jGoHpLO]
	elif r7MXibnK2fa6S31ctA==tR1krDGPpO025fghMT3a7UnYj(u"࠵Ꭵ"): FbPVyxAuaIiYj2wlJgsRm3G = qpFY4hAwolV3
	else: Z5GDXLJHVCir80NwcjWdBAUxR2vI = qpFY4hAwolV3
	if Z5GDXLJHVCir80NwcjWdBAUxR2vI:
		gdPslyFW8ITBcpA302.setSetting(IaBhDMJc17302LgSvyxd(u"ࠧࡢࡸ࠱ࡷࡹࡧࡴࡶࡵ࠱ࡹࡸ࡫ࡤ࡯ࡵࠪᄺ"),Z5GDXLJHVCir80NwcjWdBAUxR2vI)
		gdPslyFW8ITBcpA302.setSetting(YY8UDX3MJhb91AHw7fg(u"ࠨࡣࡹ࠲ࡸࡺࡡࡵࡷࡶ࠲ࡩࡴࡳࠨᄻ"),FbPVyxAuaIiYj2wlJgsRm3G)
		r6fZq1hIQAox7 = w0CZ6B3WDJknhEsdRYyH1XAM[Z5GDXLJHVCir80NwcjWdBAUxR2vI]+FbPVyxAuaIiYj2wlJgsRm3G
		iG7Rz2kmn0x1yLNMV3u8O(qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,r6fZq1hIQAox7)
	return
def oJxTRIkhaQX5tyNefSU89csVAWdb():
	wwCRPSDInyYMQtWLq7gm8NTsO = gdPslyFW8ITBcpA302.getSetting(l1DZAt9XNQjqE7YOdrz(u"ࠩࡤࡺ࠳ࡹࡴࡢࡶࡸࡷ࠳ࡻࡳࡦࡲࡵࡳࡽࡿࠧᄼ"))
	w0CZ6B3WDJknhEsdRYyH1XAM = {}
	w0CZ6B3WDJknhEsdRYyH1XAM[dJHDqiKf12TXlIzSLkGUuxg4MBs3A(u"ࠪࡅ࡚࡚ࡏࠨᄽ")] = DaFZHsThGmd0zv6e(u"ࠫฬ๊ศา๊ๆื๏ࠦวๅฬ็ๆฬฬ๊ࠡฮส๋ืࠦไๅ฻่่ࠬᄾ")
	w0CZ6B3WDJknhEsdRYyH1XAM[N3flV6EJsD5CzS(u"ࠬࡇࡓࡌࠩᄿ")] = aXqWLoTdVgME(u"࠭วๅสิ์ู่๊ࠡีํ฽๊๊ࠠษ฻าࠤฬ๊ำๆษะࠤ้ํࠧᅀ")
	w0CZ6B3WDJknhEsdRYyH1XAM[tQMjXKCA5dN4xq3beVIzaEoWkFLg(u"ࠧࡔࡖࡒࡔࠬᅁ")] = aXqWLoTdVgME(u"ࠨษ็ฬึ๎ใิ์้ࠣฯ๎โโࠢอ้ฬ๋ว๊ࠡหห้้วๆๆࠪᅂ")
	LH9DBmcbiw = w0CZ6B3WDJknhEsdRYyH1XAM[wwCRPSDInyYMQtWLq7gm8NTsO]
	r7MXibnK2fa6S31ctA = eVLmAIGFiwpr94UK6MRP5(qpFY4hAwolV3,l1DZAt9XNQjqE7YOdrz(u"ࠩอุ฿๐ไࠡ฻้ำࠥอไๆ๊สๅ็ฯࠧᅃ"),V3VlkhgjEF4n1erPXHcC0NOsfwyAJ(u"ࠪฮูเ๊ๅࠢอ่็อฦ๋ࠩᅄ"),fWoVd0Bmtkx(u"ࠫส๐โศใࠣ็ฬ๋ไࠨᅅ"),LH9DBmcbiw,fWoVd0Bmtkx(u"ࠬอไษำ๋็ุ๐่๊ࠠࠣะ์อาࠡใํࠤฬ๊ล็ฬิ๊๏ะ๋ࠠ฻่่ࠥ๎ำู๋ࠣฬ๏์ࠠอ้สึ่่ࠦศๆศ๊ฯืๆ๋ฬࠣ࠲ࠥํ่ࠡ์ึฮุ้๋ࠠๆหหฯ้้ࠠ์ๅ์๊ࠦศิฯห๋ฬࠦศะๆสࠤ๊์ใࠡอ่ࠤ๏ฮูฬ้สࠤ้้ࠠ࠯๊่ࠢࠥะั๋ัࠣฮูเ๊ๅࠢฦ้ࠥห๊ใษไࠤฬ๊ศา๊ๆื๏ࠦฟࠨᅆ"))
	if r7MXibnK2fa6S31ctA==tQMjXKCA5dN4xq3beVIzaEoWkFLg(u"࠴Ꭶ"): Z5GDXLJHVCir80NwcjWdBAUxR2vI = zYvEaigKWjoq50pXBLDbGJkFc(u"࠭ࡁࡔࡍࠪᅇ")
	elif r7MXibnK2fa6S31ctA==YY8UDX3MJhb91AHw7fg(u"࠶Ꭷ"): Z5GDXLJHVCir80NwcjWdBAUxR2vI = ddiCzu6yahj5RtTISMJ48sNnZBU(u"ࠧࡂࡗࡗࡓࠬᅈ")
	elif r7MXibnK2fa6S31ctA==c2RKu0xG1eC8MiohyE(u"࠸Ꭸ"): Z5GDXLJHVCir80NwcjWdBAUxR2vI = rNdBKI74fAklnoCZ6(u"ࠨࡕࡗࡓࡕ࠭ᅉ")
	else: Z5GDXLJHVCir80NwcjWdBAUxR2vI = qpFY4hAwolV3
	if Z5GDXLJHVCir80NwcjWdBAUxR2vI:
		gdPslyFW8ITBcpA302.setSetting(aXqWLoTdVgME(u"ࠩࡤࡺ࠳ࡹࡴࡢࡶࡸࡷ࠳ࡻࡳࡦࡲࡵࡳࡽࡿࠧᅊ"),Z5GDXLJHVCir80NwcjWdBAUxR2vI)
		r6fZq1hIQAox7 = w0CZ6B3WDJknhEsdRYyH1XAM[Z5GDXLJHVCir80NwcjWdBAUxR2vI]
		iG7Rz2kmn0x1yLNMV3u8O(qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,r6fZq1hIQAox7)
	return
def hBvbNxJyWaYRg80tqQ15w4s():
	JSW8a9DgvZz = gdPslyFW8ITBcpA302.getSetting(iNc3KxwErnQ(u"ࠪࡥࡻ࠴ࡳࡵࡣࡷࡹࡸ࠴ࡡࡶࡶࡲࡷࡨࡸࡡࡱࡧࡵࡷࠬᅋ"))
	if JSW8a9DgvZz==N3flV6EJsD5CzS(u"ࠫࡘ࡚ࡏࡑࠩᅌ"): header = viRJWOC5jsYe84(u"ࠬะฬศ๊ีࠤฬ๊ออสࠣห้ษ่ห๊่หฯ๐ใ๋่ࠢฮํ่แࠨᅍ")
	else: header = sjtU6GZQg5XC2pH4(u"࠭สอษ๋ึࠥอไฮฮหࠤฬ๊ร้ฬ๋้ฬะ๊ไ์้ࠣๆ฿ไࠨᅎ")
	o4oUxD3u18K59ghHIY = VVpbtSKYUGXrNMwAWFo9IOjZP(qpFY4hAwolV3,fWoVd0Bmtkx(u"ࠧฦ์ๅหๆ࠭ᅏ"),Ie5s2cBtSfdHjzQ4rA9kYlo6D18(u"ࠨฬไ฽๏๊ࠧᅐ"),header,DiJ8CMuYH1daWyjehfN0L(u"ࠩห฽฻ࠦวๅ็๋ห็฿ࠠห฻ส๊๏ࠦๅ็ุ่่๊ࠢษࠡษ็ััฮࠠ࠯࠰๋ࠣีอࠠศๆะะอ๊ࠦๆ่฼ࠤฬ๊ศา่ส้ัࠦๅ็ࠢไฮาࠦวๅืไัฬะ้ࠠไิหฦะ็ศࠢ࠱࠲ࠥํๆศࠢอืฯ฽ฺ๊ࠢฦ๊ࠥะำๆฯ่้ࠣฮั็ษ่ะࠥษๆࠡ์ๅ์๊ࠦร้ฬ๋้ฬะ๊ไ์สࠤอ๋อศ๊็อࠥะฬศ๊ีࠤ์ึวࠡษ็ััฮࠠ࡝ࡰ࡟ࡲࠥํไࠡฬิ๎ิࠦสโ฻ํ่ࠥษๅࠡวํๆฬ็ࠠหฮส์ืࠦวๅฯฯฬࠥอไฤ๊อ์๊อส๋ๅํࠤฤࠧࠡࠨᅑ"))
	if o4oUxD3u18K59ghHIY==-lljaEqwTVtmKsQcOrbXxS5hgNH(u"࠱Ꭹ"): return
	elif o4oUxD3u18K59ghHIY:
		gdPslyFW8ITBcpA302.setSetting(qqzwE6imYG4c2xojI(u"ࠪࡥࡻ࠴ࡳࡵࡣࡷࡹࡸ࠴ࡡࡶࡶࡲࡷࡨࡸࡡࡱࡧࡵࡷࠬᅒ"),rNdBKI74fAklnoCZ6(u"ࠫࡆ࡛ࡔࡐࠩᅓ"))
		iG7Rz2kmn0x1yLNMV3u8O(qpFY4hAwolV3,qpFY4hAwolV3,GLTtERWbHnFuy4PCp,BRWqdruz2A0(u"ࠬะๅࠡฬไ฽๏๊ࠠหฮส์ืࠦวๅฯฯฬࠥอไฤ๊อ์๊อส๋ๅํࠫᅔ"))
	else:
		gdPslyFW8ITBcpA302.setSetting(Ie5s2cBtSfdHjzQ4rA9kYlo6D18(u"࠭ࡡࡷ࠰ࡶࡸࡦࡺࡵࡴ࠰ࡤࡹࡹࡵࡳࡤࡴࡤࡴࡪࡸࡳࠨᅕ"),tR1krDGPpO025fghMT3a7UnYj(u"ࠧࡔࡖࡒࡔࠬᅖ"))
		iG7Rz2kmn0x1yLNMV3u8O(qpFY4hAwolV3,qpFY4hAwolV3,GLTtERWbHnFuy4PCp,IaBhDMJc17302LgSvyxd(u"ࠨฬ่ࠤส๐โศใࠣฮัอ่ำࠢส่าาศࠡษ็วํะ่ๆษอ๎่๐ࠧᅗ"))
	return
def HbVFkgx1dYPZfUeDT0NAE():
	JSW8a9DgvZz = gdPslyFW8ITBcpA302.getSetting(l1DZAt9XNQjqE7YOdrz(u"ࠩࡤࡺ࠳ࡹࡴࡢࡶࡸࡷ࠳ࡳࡥ࡯ࡷࡶࡧࡦࡩࡨࡦࠩᅘ"))
	if JSW8a9DgvZz==LZWMikPEB81KSGyxfJtUsCA(u"ࠪࡗ࡙ࡕࡐࠨᅙ"): header = RlOvin8YIGC2KZXJPk9m0acrMobUex(u"ࠫฯิา๋่ࠣห้่่ศศ่ࠤ๊ะ่ใใࠪᅚ")
	else: header = qoBMmfAWpFlK70xw8ZRh4naJ(u"ࠬะฮำ์้ࠤฬ๊โ้ษษ้๋ࠥแฺๆࠪᅛ")
	o4oUxD3u18K59ghHIY = VVpbtSKYUGXrNMwAWFo9IOjZP(qpFY4hAwolV3,sjtU6GZQg5XC2pH4(u"࠭ล๋ไสๅࠬᅜ"),ee86G9ladLHVbh5mikzCo(u"ࠧหใ฼๎้࠭ᅝ"),header,fWoVd0Bmtkx(u"ࠨไ๋หห๋ࠠศๆหี๋อๅอࠢํฮ๊ࠦสฮัํฯ์อࠠฤ๊อ์๊อส๋ๅํหࠥฮูะࠢ࠴࠺ูࠥวฺห้๋ࠣࠦร้ๆࠣวุะฮะษ่ࠤ࠳࠴้ࠠวํๆฬ็ࠠหะี๎๋ࠦวๅไ๋หห๋๋ࠠฦา๎ࠥหไ๊ࠢอัิ๐ห่ษࠣๅ๏ࠦใๅ่ࠢีฮ๊ࠦห็ࠣหุะฮะษ่ࠤฬ๊โ้ษษ้ࠥ࠴࠮๊๊ࠡิฬ๊ࠦิสหࠤอ฽ฦࠡใํࠤๆะอࠡไ๋หห๋ࠠศๆหี๋อๅอ࡞ࡱࡠࡳࠦ็ๅࠢอี๏ีࠠหใ฼๎้ࠦรๆࠢศ๎็อแࠡฬัึ๏์ࠠศๆๅ์ฬฬๅࠡมࠤࠥࠬᅞ"))
	if o4oUxD3u18K59ghHIY==-tQMjXKCA5dN4xq3beVIzaEoWkFLg(u"࠲Ꭺ"): return
	elif o4oUxD3u18K59ghHIY:
		gdPslyFW8ITBcpA302.setSetting(mmV2nucZ5Lpl6FO1JMPEqGoQKW(u"ࠩࡤࡺ࠳ࡹࡴࡢࡶࡸࡷ࠳ࡳࡥ࡯ࡷࡶࡧࡦࡩࡨࡦࠩᅟ"),aXqWLoTdVgME(u"ࠪࡅ࡚࡚ࡏࠨᅠ"))
		iG7Rz2kmn0x1yLNMV3u8O(qpFY4hAwolV3,qpFY4hAwolV3,GLTtERWbHnFuy4PCp,ddiCzu6yahj5RtTISMJ48sNnZBU(u"ࠫฯ๋ࠠหใ฼๎้ࠦสฯิํ๊ࠥอไใ๊สส๊࠭ᅡ"))
	else:
		gdPslyFW8ITBcpA302.setSetting(N3flV6EJsD5CzS(u"ࠬࡧࡶ࠯ࡵࡷࡥࡹࡻࡳ࠯࡯ࡨࡲࡺࡹࡣࡢࡥ࡫ࡩࠬᅢ"),DiJ8CMuYH1daWyjehfN0L(u"࠭ࡓࡕࡑࡓࠫᅣ"))
		iG7Rz2kmn0x1yLNMV3u8O(qpFY4hAwolV3,qpFY4hAwolV3,GLTtERWbHnFuy4PCp,CC1eY6yWZUwf2TkRvnp7EJ0AimjHBX(u"ࠧห็ࠣษ๏่วโࠢอาื๐ๆࠡษ็ๆํอฦๆࠩᅤ"))
	return
def tmfaZM5pd9DwHO6YBqyxUVI():
	RpPaQoIJm7DxAfHdYwTgL5rM = gdPslyFW8ITBcpA302.getSetting(iNc3KxwErnQ(u"ࠨࡣࡹ࠲ࡸࡺࡡࡵࡷࡶ࠲ࡲ࡫࡮ࡶࡵࡺࡩࡧࡩࡡࡤࡪࡨࠫᅥ"))
	if RpPaQoIJm7DxAfHdYwTgL5rM==fWoVd0Bmtkx(u"ࠩࡖࡘࡔࡖࠧᅦ"): header = V3VlkhgjEF4n1erPXHcC0NOsfwyAJ(u"ࠪะ้ฮࠠศๆๅ์ฬฬๅࠡ็้ࠤฬ๊ล็ฬิ๊ฯࠦๅห๊ๅๅࠬᅧ")
	else: header = N3flV6EJsD5CzS(u"ࠫั๊ศࠡษ็ๆํอฦๆ่๊ࠢࠥอไฦ่อี๋ะࠠๆใ฼่ࠬᅨ")
	o4oUxD3u18K59ghHIY = VVpbtSKYUGXrNMwAWFo9IOjZP(qpFY4hAwolV3,sjtU6GZQg5XC2pH4(u"ࠬห๊ใษไࠫᅩ"),DaFZHsThGmd0zv6e(u"࠭สโ฻ํ่ࠬᅪ"),header,V3VlkhgjEF4n1erPXHcC0NOsfwyAJ(u"ࠧใ๊สส๊ࠦศฺุࠣห้๋่ศไ฼ࠤํิวึหࠣห้๋ออ๊หอ๋ࠥๅไ่ࠣฮำุ๊็้สࠤๆ๐ࠠศๆศ๊ฯืๆหࠢไ๎ู๊ࠥาใิหฯࠦไศࠢํ์ัีࠠโ์๊ห๋ࠥิไๆฬࠤาาศࠡ࠰࠱ࠤ์ึ็ࠡษ็฻ึ๐โสࠢอืฬ฿ฯࠡใํࠤ็ืวยหࠣ์ฬูสฯัส้ࠥอไๆ๊สๆ฾ࠦวๅ็ะะํฮษࠡๆๆ๊๋ࠥๆࠡ็๋ๆ฾ࠦศะ์็ࠤ๊ะ่โำࠣ์฿๐ัࠡ็ะะํฮࠠ࡝ࡰ࡟ࡲࡡࡴ่ࠠๆࠣฮึ๐ฯࠡฬไ฽๏๊ࠠฤ็ࠣษ๏่วโࠢฯ่อࠦวๅไ๋หห๋ࠠๆ่ࠣห้หๆหำ้ฮࠥลࠡࠢࠩᅫ"))
	if o4oUxD3u18K59ghHIY==-viRJWOC5jsYe84(u"࠳Ꭻ"): return
	elif o4oUxD3u18K59ghHIY:
		gdPslyFW8ITBcpA302.setSetting(viRJWOC5jsYe84(u"ࠨࡣࡹ࠲ࡸࡺࡡࡵࡷࡶ࠲ࡲ࡫࡮ࡶࡵࡺࡩࡧࡩࡡࡤࡪࡨࠫᅬ"),CC1eY6yWZUwf2TkRvnp7EJ0AimjHBX(u"ࠩࡄ࡙࡙ࡕࠧᅭ"))
		iG7Rz2kmn0x1yLNMV3u8O(qpFY4hAwolV3,qpFY4hAwolV3,GLTtERWbHnFuy4PCp,c2RKu0xG1eC8MiohyE(u"ࠪฮ๊ࠦสโ฻ํ่ࠥาไษࠢส่็๎วว็้๋ࠣࠦวๅ๊ํฬࠬᅮ"))
	else:
		gdPslyFW8ITBcpA302.setSetting(Ie5s2cBtSfdHjzQ4rA9kYlo6D18(u"ࠫࡦࡼ࠮ࡴࡶࡤࡸࡺࡹ࠮࡮ࡧࡱࡹࡸࡽࡥࡣࡥࡤࡧ࡭࡫ࠧᅯ"),tR1krDGPpO025fghMT3a7UnYj(u"࡙ࠬࡔࡐࡒࠪᅰ"))
		iG7Rz2kmn0x1yLNMV3u8O(qpFY4hAwolV3,qpFY4hAwolV3,GLTtERWbHnFuy4PCp,ddiCzu6yahj5RtTISMJ48sNnZBU(u"࠭สๆࠢศ๎็อแࠡฮ็ฬࠥอไใ๊สส๊ࠦๅ็ࠢส่ํ๐ศࠨᅱ"))
	return
def sJN4cfwBZgkrWuDiyTeq(HY7yaJeI89xE56sbTjdBRZPDwQKFX):
	if HY7yaJeI89xE56sbTjdBRZPDwQKFX!=qpFY4hAwolV3:
		HY7yaJeI89xE56sbTjdBRZPDwQKFX = qZ5W2HkliSK9CN(HY7yaJeI89xE56sbTjdBRZPDwQKFX)
		HY7yaJeI89xE56sbTjdBRZPDwQKFX = HY7yaJeI89xE56sbTjdBRZPDwQKFX.decode(nV3Tip6XsH1rJw79DPOU).encode(nV3Tip6XsH1rJw79DPOU)
		OkRt1mN0ZhW7EXcMpYaQgSB9x = l1DZAt9XNQjqE7YOdrz(u"࠴࠴࠶࠶࠳Ꭼ")
		oQfLyVaD2zJgOEvX9 = q5Kah0DftjNzV.Window(OkRt1mN0ZhW7EXcMpYaQgSB9x)
		oQfLyVaD2zJgOEvX9.getControl(BRWqdruz2A0(u"࠷࠶࠷Ꭽ")).setLabel(HY7yaJeI89xE56sbTjdBRZPDwQKFX)
	return
qRHo5AGaS6vumXlC1Q = [
			 UVa3fJw7k6KM(u"ࠢࡦࡺࡷࡩࡳࡹࡩࡰࡰࠣࡥࡻࡹࡰࡢࡥࡨࡷ࠵ࠦࡩࡴࠢࡱࡳࡹࠦࡣࡶࡴࡵࡩࡳࡺ࡬ࡺࠢࡶࡹࡵࡶ࡯ࡳࡶࡨࡨࠧᅲ")
			,sjtU6GZQg5XC2pH4(u"ࠨࡅ࡫ࡩࡨࡱࡩ࡯ࡩࠣࡪࡴࡸࠠࡎࡣ࡯࡭ࡨ࡯࡯ࡶࡵࠣࡷࡨࡸࡩࡱࡶࡶࠫᅳ")
			,DiJ8CMuYH1daWyjehfN0L(u"ࠩࡓ࡚ࡗࠦࡉࡑࡖ࡙ࠤࡘ࡯࡭ࡱ࡮ࡨࠤࡈࡲࡩࡦࡰࡷࠫᅴ")
			,Ie5s2cBtSfdHjzQ4rA9kYlo6D18(u"࡙ࠪࡳࡱ࡮ࡰࡹࡱࠤ࡛࡯ࡤࡦࡱࠣࡍࡳ࡬࡯ࠡࡍࡨࡽࠬᅵ")
			,viRJWOC5jsYe84(u"ࠫࡹ࡮ࡩࡴࠢ࡫ࡥࡸ࡮ࠠࡧࡷࡱࡧࡹ࡯࡯࡯ࠢ࡬ࡷࠥࡨࡲࡰ࡭ࡨࡲࠬᅶ")
			,mmV2nucZ5Lpl6FO1JMPEqGoQKW(u"ࠬࡻࡳࡦࡵࠣࡴࡱࡧࡩ࡯ࠢࡋࡘ࡙ࡖࠠࡧࡱࡵࠤࡦࡪࡤ࠮ࡱࡱࠤࡩࡵࡷ࡯࡮ࡲࡥࡩࡹࠧᅷ")
			,l32dnTEOU1skGKqeBtI9hmo(u"࠭ࡡࡥࡸࡤࡲࡨ࡫ࡤ࠮ࡷࡶࡥ࡬࡫࠮ࡩࡶࡰࡰࠬᅸ")+lljaEqwTVtmKsQcOrbXxS5hgNH(u"ࠧࠤࠩᅹ")+iNc3KxwErnQ(u"ࠨࡵࡶࡰ࠲ࡽࡡࡳࡰ࡬ࡲ࡬ࡹࠧᅺ")
			,V3VlkhgjEF4n1erPXHcC0NOsfwyAJ(u"ࠩࡌࡲࡸ࡫ࡣࡶࡴࡨࡖࡪࡷࡵࡦࡵࡷ࡛ࡦࡸ࡮ࡪࡰࡪ࠰ࠬᅻ")
			,fWoVd0Bmtkx(u"ࠪࡉࡷࡸ࡯ࡳࠢࡪࡩࡹࡺࡩ࡯ࡩࠣࡴࡱࡻࡧࡪࡰ࠽࠳࠴ࡹ࡫ࡪࡰ࠱ࡱࡪࡺࡲࡰࡲࡲࡰ࡮ࡹࡅࡎࡃࡇ࠳ࡄࡳ࡯ࡥࡧࡨࡁ࠵ࠬࡴࡦࡺࡷࡸࡂ࠭ᅼ")
			,IaBhDMJc17302LgSvyxd(u"ࠫࡼࡧࡲ࡯࡫ࡱ࡫ࡸ࠴ࡷࡢࡴࡱࠬࠬᅽ")
			,ddiCzu6yahj5RtTISMJ48sNnZBU(u"ࠬࡤ࡞࡟ࡠࡡࠫᅾ")
			,tR1krDGPpO025fghMT3a7UnYj(u"࠭ࡌࡰࡣࡧ࡭ࡳ࡭ࠠࡴ࡭࡬ࡲࠥ࡬ࡩ࡭ࡧ࠽ࠫᅿ")
			,Ie5s2cBtSfdHjzQ4rA9kYlo6D18(u"ࠧ࡭ࡣࡵ࡫ࡪࠦࡡࡶࡦ࡬ࡳࠥࡹࡹ࡯ࡥࠣࡩࡷࡸ࡯ࡳ࠼ࠪᆀ")
			,CC1eY6yWZUwf2TkRvnp7EJ0AimjHBX(u"ࠨ࡫ࡱࡪࡴࡀࠠࡎࡧࡧ࡭ࡦࡩ࡯ࡥࡧࡦࠤࡩ࡫ࡣࡰࡦࡨࡶ࠿࠭ᆁ")
			]
def tPw2A9G4HfqOLYDUmrolNI6icJ(N3S5LUH7Fwztgu9qshjIfvKn8Txlk1):
	if DaFZHsThGmd0zv6e(u"ࠩࡏࡳࡦࡪࡩ࡯ࡩࠣࡷࡰ࡯࡮ࠡࡨ࡬ࡰࡪࡀࠧᆂ") in N3S5LUH7Fwztgu9qshjIfvKn8Txlk1 and kYDaz79TFlXoR(u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡤࡶࡦࡨࡩࡤࡸ࡬ࡨࡪࡵࡳࠨᆃ") in N3S5LUH7Fwztgu9qshjIfvKn8Txlk1: return gBExoceumj4y8bFW9hY2aNMVSr
	for HY7yaJeI89xE56sbTjdBRZPDwQKFX in qRHo5AGaS6vumXlC1Q:
		if HY7yaJeI89xE56sbTjdBRZPDwQKFX in N3S5LUH7Fwztgu9qshjIfvKn8Txlk1: return gBExoceumj4y8bFW9hY2aNMVSr
	return ag8rjZo1Vz4IPdcOT
def DMx1n65ra9gGSH(data):
	ppE6Nc4QAI1tyBkZq = l32dnTEOU1skGKqeBtI9hmo(u"࠽Ꭿ") if DLod2Of8CkRrtzJynev else kYDaz79TFlXoR(u"࠶࠻Ꭾ")
	data = data.replace(DiJ8CMuYH1daWyjehfN0L(u"࠳࠱Ꮀ")*mIsDke0oK5x1zSiOWbF9thGcA,ppE6Nc4QAI1tyBkZq*mIsDke0oK5x1zSiOWbF9thGcA)
	data = data.replace(LZWMikPEB81KSGyxfJtUsCA(u"ࠫࠥࡂࡧࡦࡰࡨࡶࡦࡲ࠾࠻ࠢࠪᆄ"),mmV2nucZ5Lpl6FO1JMPEqGoQKW(u"ࠬࡀࠠࠨᆅ"))
	RZ2SwHp6GQvAy = qpFY4hAwolV3
	for N3S5LUH7Fwztgu9qshjIfvKn8Txlk1 in data.splitlines():
		dShvBTVoFGkatzJj = ePhmG1jLD6.findall(c2RKu0xG1eC8MiohyE(u"࠭ࠠࠡࠢࠣࠤࡋ࡯࡬ࡦࠢࠥࠬ࠳࠰࠿ࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡡࡳࡣࡥ࡭ࡨࡼࡩࡥࡧࡲࡷ࠳࠯ࡡࡳࡣࡥ࡭ࡨࡼࡩࡥࡧࡲࡷࠬᆆ"),N3S5LUH7Fwztgu9qshjIfvKn8Txlk1,ePhmG1jLD6.DOTALL)
		if dShvBTVoFGkatzJj: N3S5LUH7Fwztgu9qshjIfvKn8Txlk1 = N3S5LUH7Fwztgu9qshjIfvKn8Txlk1.replace(dShvBTVoFGkatzJj[vvXoMLlg513],qpFY4hAwolV3)
		RZ2SwHp6GQvAy += ZLwoRpfnCWI7FgEHsz6te39lMVh+N3S5LUH7Fwztgu9qshjIfvKn8Txlk1
	return RZ2SwHp6GQvAy
def CFc6iGxzlKYP4ws1WrhavOEJ(ebCj7R6hNcvglS4rt1WodGB):
	if N3flV6EJsD5CzS(u"ࠧࡐࡎࡇࠫᆇ") in ebCj7R6hNcvglS4rt1WodGB:
		BBnMfXkSdhTwbl7KgoJ3Nu4rF = Zxm9QJBbv7GEkYVK6X8fA3DM0
		header = tQMjXKCA5dN4xq3beVIzaEoWkFLg(u"ࠨไิหฦฯࠠศๆึะ้ࠦวๅไา๎๊ࠦฟࠨᆈ")
	else:
		BBnMfXkSdhTwbl7KgoJ3Nu4rF = k8AjFZIlXNLg5diJCHMR20TEznOY
		header = zYvEaigKWjoq50pXBLDbGJkFc(u"ࠩๅีฬวษࠡษ็ืั๊ࠠศๆะห้๐ࠠภࠩᆉ")
	o4oUxD3u18K59ghHIY = VVpbtSKYUGXrNMwAWFo9IOjZP(qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,header,aXqWLoTdVgME(u"ࠪืั๊ࠠศๆฦา฼อมࠡ์ะฮํ๐ࠠฤ์ูหࠥ฿ไ๊ࠢึะ้ࠦวๅษึฮำีวๆࠢ࠱ࠤํอไศอ้๎๋ࠦึา๊ิ๎ฮࠦไๆ฻ิๅฮࠦใ๋ใࠣัิัสࠡษ็ู้้ไส๋้ࠢฬࠦ็้ࠢส่๊้ว็ࠢส่ี๐ࠠิสหࠤาี่ฬࠢสฺ่๊ใๅหࠣ࠲้่ࠥะ์ࠣ๎าะแูࠢหืั๊๊็ࠢ࠱ࠤฬ๊ร้ๆ๋ࠣํࠦวๅีฯ่ࠥอไฮษ็๎ࠥ๎แ๋้้ࠣ฾๊่ๆษอࠤฯฮฯฤ่๊ࠢีࠦศะษํอࠥอไหึ฽๎้ࠦวๅฯส่๏ࠦไษำ้ห๊าࠠไ๊า๎ࠥ๎วๅ๋ࠣห้ศๆࠡ࠰ࠣว๊อࠠศๆึะ้ࠦวๅไา๎๊ࠦแ่๊ࠣหู้ฬๅࠢสุ่อศใࠢส่ี๐ࠠห็ࠣะ๊฿็ࠡ็้ࠤอืๆศ็ฯࠤ่๎ฯ๋ࠢๅฬ้ࠦยฯำࠣษ฼็วยࠢ็๋ࠥ࠴่ࠠๆࠣฮึ๐ฯࠡษ็หุะๅาษิࠤฤ࠭ᆊ"))
	if o4oUxD3u18K59ghHIY!=N3flV6EJsD5CzS(u"࠲Ꮁ"): return
	lsDWF6UEpxa5KAeRjXMCI,Ljv3VaAWEBGxrRzbQJYhN = [],DaFZHsThGmd0zv6e(u"࠲Ꮂ")
	size,count = e2YrFAdw9WBl8740uPKUcGCbL(BBnMfXkSdhTwbl7KgoJ3Nu4rF)
	file = open(BBnMfXkSdhTwbl7KgoJ3Nu4rF,N3flV6EJsD5CzS(u"ࠫࡷࡨࠧᆋ"))
	if size>tR1krDGPpO025fghMT3a7UnYj(u"࠵࠵࠶࠲࠱࠲Ꮄ"): file.seek(-l1DZAt9XNQjqE7YOdrz(u"࠴࠴࠵࠷࠰࠱Ꮃ"),RPbaxsNFVTwek5Kfv21DiJuzCnjMZp.SEEK_END)
	data = file.read()
	file.close()
	if DLod2Of8CkRrtzJynev: data = data.decode(nV3Tip6XsH1rJw79DPOU)
	data = DMx1n65ra9gGSH(data)
	Mm8BldxpifLUa5s2 = data.split(ZLwoRpfnCWI7FgEHsz6te39lMVh)
	for N3S5LUH7Fwztgu9qshjIfvKn8Txlk1 in reversed(Mm8BldxpifLUa5s2):
		pG06jynh5g = tPw2A9G4HfqOLYDUmrolNI6icJ(N3S5LUH7Fwztgu9qshjIfvKn8Txlk1)
		if pG06jynh5g: continue
		N3S5LUH7Fwztgu9qshjIfvKn8Txlk1 = N3S5LUH7Fwztgu9qshjIfvKn8Txlk1.replace(RlOvin8YIGC2KZXJPk9m0acrMobUex(u"ࠬࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡥࠧᆌ"),IQ2KCmObsTGuiRdEzt931a40jLg+dJHDqiKf12TXlIzSLkGUuxg4MBs3A(u"࠭ࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡࠩᆍ")+fF4lt9zWYxXLKZVyAco82PgMj)
		N3S5LUH7Fwztgu9qshjIfvKn8Txlk1 = N3S5LUH7Fwztgu9qshjIfvKn8Txlk1.replace(kYDaz79TFlXoR(u"ࠧࡆࡔࡕࡓࡗࡀࠧᆎ"),RlOvin8YIGC2KZXJPk9m0acrMobUex(u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡊࡋ࠶࠰࠱࠲ࡠࠫᆏ")+V3VlkhgjEF4n1erPXHcC0NOsfwyAJ(u"ࠩࡈࡖࡗࡕࡒ࠻ࠩᆐ")+fF4lt9zWYxXLKZVyAco82PgMj)
		iMVwflgGSqtXWDcE68J = qpFY4hAwolV3
		vB9hes2mpanzkc36Cq4wfyIQoiKM = ePhmG1jLD6.findall(tQMjXKCA5dN4xq3beVIzaEoWkFLg(u"ࠪࡢ࠭ࡢࡤࠬ࠯ࠫࡠࡩ࠱࠭࡝ࡦ࠮ࠤࡡࡪࠫ࠻࡞ࡧ࠯࠿ࡢࡤࠬ࡞࠱ࡠࡩ࠱ࠩࠪࠪࠣࡘ࠿ࡢࡤࠬࠫࠪᆑ"),N3S5LUH7Fwztgu9qshjIfvKn8Txlk1,ePhmG1jLD6.DOTALL)
		if vB9hes2mpanzkc36Cq4wfyIQoiKM:
			N3S5LUH7Fwztgu9qshjIfvKn8Txlk1 = N3S5LUH7Fwztgu9qshjIfvKn8Txlk1.replace(vB9hes2mpanzkc36Cq4wfyIQoiKM[vvXoMLlg513][vvXoMLlg513],vB9hes2mpanzkc36Cq4wfyIQoiKM[vvXoMLlg513][mZi0S72jGoHpLO]).replace(vB9hes2mpanzkc36Cq4wfyIQoiKM[vvXoMLlg513][Zwqio2AIWlD5etFa],qpFY4hAwolV3)
			iMVwflgGSqtXWDcE68J = vB9hes2mpanzkc36Cq4wfyIQoiKM[vvXoMLlg513][mZi0S72jGoHpLO]
		else:
			vB9hes2mpanzkc36Cq4wfyIQoiKM = ePhmG1jLD6.findall(IaBhDMJc17302LgSvyxd(u"ࠫࡣ࠮࡜ࡥ࠭࠽ࡠࡩ࠱࠺࡝ࡦ࠮ࡠ࠳ࡢࡤࠬࠫࠫࠤ࡙ࡀ࡜ࡥ࠭ࠬࠫᆒ"),N3S5LUH7Fwztgu9qshjIfvKn8Txlk1,ePhmG1jLD6.DOTALL)
			if vB9hes2mpanzkc36Cq4wfyIQoiKM:
				N3S5LUH7Fwztgu9qshjIfvKn8Txlk1 = N3S5LUH7Fwztgu9qshjIfvKn8Txlk1.replace(vB9hes2mpanzkc36Cq4wfyIQoiKM[vvXoMLlg513][mZi0S72jGoHpLO],qpFY4hAwolV3)
				iMVwflgGSqtXWDcE68J = vB9hes2mpanzkc36Cq4wfyIQoiKM[vvXoMLlg513][vvXoMLlg513]
		if iMVwflgGSqtXWDcE68J: N3S5LUH7Fwztgu9qshjIfvKn8Txlk1 = N3S5LUH7Fwztgu9qshjIfvKn8Txlk1.replace(iMVwflgGSqtXWDcE68J,xupTj02bvy3O8R+iMVwflgGSqtXWDcE68J+fF4lt9zWYxXLKZVyAco82PgMj)
		lsDWF6UEpxa5KAeRjXMCI.append(N3S5LUH7Fwztgu9qshjIfvKn8Txlk1)
		if len(str(lsDWF6UEpxa5KAeRjXMCI))>UUDAiytEL76RTmMYsuIz5evXB(u"࠺࠶࠱࠱࠲Ꮅ"): break
	lsDWF6UEpxa5KAeRjXMCI = reversed(lsDWF6UEpxa5KAeRjXMCI)
	xnbh94i3Pyfm = ZLwoRpfnCWI7FgEHsz6te39lMVh.join(lsDWF6UEpxa5KAeRjXMCI)
	W2fBJaUN9kZwVeR1n0o4Dc(tQMjXKCA5dN4xq3beVIzaEoWkFLg(u"ࠬࡲࡥࡧࡶࠪᆓ"),fWoVd0Bmtkx(u"࠭ยฯำࠣวุ฽ัࠡีฯ่ࠥอไฤะฺหฦ่ࠦศๆสืฯิฯศ็ࠪᆔ"),xnbh94i3Pyfm,DaFZHsThGmd0zv6e(u"ࠧࡵࡧࡻࡸࡻ࡯ࡥࡸࡡࡶࡱࡦࡲ࡬ࡧࡱࡱࡸࡤࡲ࡯࡯ࡩࠪᆕ"))
	return
def JWOnV1cqvfUMhCZj57():
	Vn8pxJHuQwG1jsm = open(hPapTifLD0Co7g9M2ur,ddiCzu6yahj5RtTISMJ48sNnZBU(u"ࠨࡴࡥࠫᆖ")).read()
	if DLod2Of8CkRrtzJynev: Vn8pxJHuQwG1jsm = Vn8pxJHuQwG1jsm.decode(nV3Tip6XsH1rJw79DPOU)
	Vn8pxJHuQwG1jsm = Vn8pxJHuQwG1jsm.replace(c2RKu0xG1eC8MiohyE(u"ࠩ࡟ࡸࠬᆗ"),mmV2nucZ5Lpl6FO1JMPEqGoQKW(u"ࠪࠤࠥࠦࠠࠡࠢࠣࠤࠬᆘ"))
	jNmfig0xKqC3MFIrQt6 = ePhmG1jLD6.findall(UVa3fJw7k6KM(u"ࠫ࠭ࡼ࡜ࡥ࠰࠭ࡃ࠮ࡡ࡜࡯࡞ࡵࡡࠬᆙ"),Vn8pxJHuQwG1jsm,ePhmG1jLD6.DOTALL)
	for N3S5LUH7Fwztgu9qshjIfvKn8Txlk1 in jNmfig0xKqC3MFIrQt6:
		Vn8pxJHuQwG1jsm = Vn8pxJHuQwG1jsm.replace(N3S5LUH7Fwztgu9qshjIfvKn8Txlk1,IQ2KCmObsTGuiRdEzt931a40jLg+N3S5LUH7Fwztgu9qshjIfvKn8Txlk1+fF4lt9zWYxXLKZVyAco82PgMj)
	fGChDJbmZANnS(aXqWLoTdVgME(u"ࠬอไห฼ํ๎ึอสࠡษ็วำ๐ัสࠢไ๎ࠥอไษำส้ั࠭ᆚ"),Vn8pxJHuQwG1jsm)
	return
def sRxuBol46jqYEvO2zw9PSnaF():
	JQ0OTpbAGY8khnwf = tQMjXKCA5dN4xq3beVIzaEoWkFLg(u"࠭ศฺุࠣห้ษาาษิࠤ฾๊้ࠡษ็ี๏๋่หࠢๆ์๋ะั้ๆࠣฮํ็ัࠡว่็ฬ์๊สࠢอๆิ๐ๅ๊ࠡอวำ๐ัࠡษ็ๅ๏ี๊้๋๋ࠢีํࠠศๆฦึึอั้ࠡํࠤฬ๊ริ้่ࠤํอไฤำๅห๊ࠦๅฺࠢห฽฻่ࠦไษ็ฮฬ๊๊ࠨᆛ")
	UJqj5NE0ZKm = Ie5s2cBtSfdHjzQ4rA9kYlo6D18(u"ࠧๅฬๅำ๏๋ࠠศๆไ๎ิ๐่ࠡษึฮำีๅࠡษ็ื์๋ࠠศๆํ้๏์้ࠠๆอวำ๐ั่ࠢสืฯิฯๆࠢสุ่ํๅࠡษ็๎ุอัࠡ࠰ࠣว๊อฺࠠัฬࠤฬู็ๆ่ࠢฮฯอไ๋หࠣๅ์ึ็ࠡฬๅ์๊ࠦศหฯิ๎่ࠦวๅใํำ๏๎ࠠษ๊ๅฮࠥอใษำ้๋่ࠣࠦใฬࠣหู้็ๆࠢส่ํออะࠢ࠱ࠤศ๋วࠡษ็ื์๋ࠠศๆฦ฽้๏้ࠠษ็วุ็ไࠡใ๊์ࠥ๐อาๅࠣห้็๊ะ์๋ࠤส๊้ࠡษ็ว๊อๅࠡล๋ࠤส๊้ࠡษ็์ึอม๊ࠡ็็๋ࠦศใใีอ้ࠥศ๋ำฬࠫᆜ")
	kKBpAYVRmwnCJaQ = qqzwE6imYG4c2xojI(u"ࠨล่หࠥอไฤำๅห๊ࠦแ่์ࠣฮุะฮะ็่้ࠣะโะ์่ࠤํอไหลั๎ึ่ࠦๅๅ้ࠤอ๋โะษิࠤ฾ีฯࠡษ็ฯํอๆ๋๋ࠢห้ีโศศๅࠤ࠳ࠦๅฬๆสࠤึ่ๅࠡ࠷࠷࠸ࠥะู็์ࠣ࠹ࠥีโศศๅࠤํࠦ࠴࠵ࠢฮห๋๐ษࠡว็ํࠥอไฤ็ส้ࠥษ่ࠡว็ํࠥอไ้ำสลࠥฮอิสࠣหุะฮะษ่็๊ࠥไิ้่ࠤฬ๊๊ๆ์้ࠤศ๎ࠠิ้่ࠤฬ๊๊ิษิࠫᆝ")
	w0CZ6B3WDJknhEsdRYyH1XAM = JQ0OTpbAGY8khnwf+l32dnTEOU1skGKqeBtI9hmo(u"ࠩ࠽ࠤࠬᆞ")+UJqj5NE0ZKm+viRJWOC5jsYe84(u"ࠪࠤ࠳ࠦࠧᆟ")+kKBpAYVRmwnCJaQ
	W2fBJaUN9kZwVeR1n0o4Dc(fWoVd0Bmtkx(u"ࠫࡨ࡫࡮ࡵࡧࡵࠫᆠ"),GLTtERWbHnFuy4PCp,w0CZ6B3WDJknhEsdRYyH1XAM,RlOvin8YIGC2KZXJPk9m0acrMobUex(u"ࠬࡺࡥࡹࡶࡹ࡭ࡪࡽ࡟ࡣ࡫ࡪࡪࡴࡴࡴࠨᆡ"))
	return
def CCfRqS47rTDe9GyQ5za2JwxpIUV(type,w0CZ6B3WDJknhEsdRYyH1XAM,showDialogs=gBExoceumj4y8bFW9hY2aNMVSr,url=qpFY4hAwolV3,n38oH7wd6BDyAMJQS=qpFY4hAwolV3,HY7yaJeI89xE56sbTjdBRZPDwQKFX=qpFY4hAwolV3,xxpI8yblnvEV=qpFY4hAwolV3):
	o2gtGzZXiDy4nAqUPwKf578EVaOY1M = gBExoceumj4y8bFW9hY2aNMVSr
	if not i4bFG3rKE6.ogLe6xzIfJyT75HCQa:
		if showDialogs:
			xDtClya1EI329WuqwZHTUOFA48KGR = (dJHDqiKf12TXlIzSLkGUuxg4MBs3A(u"࠭วๅีฺี࠿࠭ᆢ") in w0CZ6B3WDJknhEsdRYyH1XAM and LZWMikPEB81KSGyxfJtUsCA(u"ࠧศๆ่็ฬ์࠺ࠨᆣ") in w0CZ6B3WDJknhEsdRYyH1XAM and IaBhDMJc17302LgSvyxd(u"ࠨษ็้้็࠺ࠨᆤ") in w0CZ6B3WDJknhEsdRYyH1XAM and sjtU6GZQg5XC2pH4(u"ࠩส่ำ฽รࠨᆥ") in w0CZ6B3WDJknhEsdRYyH1XAM and iNc3KxwErnQ(u"ࠪห้๋ีะำ࠽ࠫᆦ") in w0CZ6B3WDJknhEsdRYyH1XAM)
			if not xDtClya1EI329WuqwZHTUOFA48KGR: o2gtGzZXiDy4nAqUPwKf578EVaOY1M = VVpbtSKYUGXrNMwAWFo9IOjZP(l1DZAt9XNQjqE7YOdrz(u"ࠫࡨ࡫࡮ࡵࡧࡵࠫᆧ"),qpFY4hAwolV3,qpFY4hAwolV3,DiJ8CMuYH1daWyjehfN0L(u"ࠬํไࠡฬิื้ࠦ็ั้ࠣห้ืำศๆฬࠤส๊้ࠡษ็้อืๅอࠩᆨ"),w0CZ6B3WDJknhEsdRYyH1XAM.replace(Ie5s2cBtSfdHjzQ4rA9kYlo6D18(u"࠭࡜࡝ࡰࠪᆩ"),ZLwoRpfnCWI7FgEHsz6te39lMVh))
	elif showDialogs:
		w0CZ6B3WDJknhEsdRYyH1XAM = mmV2nucZ5Lpl6FO1JMPEqGoQKW(u"ࠧ࡝࡞ࡱฮ๊ࠦๅิฯࠣห้ืำศๆฬࡠࡡࡴสๆ่ࠢืาࠦัิษ็อࡡࡢ࡮ห็ุ้ࠣำࠠศๆิืฬ๊ษ࡝࡞ࡱฮ๊ࠦๅิฯࠣห้ืำศๆฬࡠࡡࡴสๆ่ࠢืาࠦวๅำึห้ฯࠧᆪ")
		pv2TX5Na1RS849euWxEKMItHAj = VVpbtSKYUGXrNMwAWFo9IOjZP(LZWMikPEB81KSGyxfJtUsCA(u"ࠨࡥࡨࡲࡹ࡫ࡲࠨᆫ"),qpFY4hAwolV3,qpFY4hAwolV3,iNc3KxwErnQ(u"ࠩอ้๋ࠥำฮࠢิืฬ๊สไࠩᆬ")+ddiCzu6yahj5RtTISMJ48sNnZBU(u"ࠪࠤࠥ࠷࠯࠶ࠩᆭ"),aXqWLoTdVgME(u"ࠫ์๊ࠠหำํำࠥหัิษ็ࠤึูวๅหࠣๅฬืฺสࠩᆮ"))
		IoRr7kFZW9inOe3Ey5vCYKhQz = VVpbtSKYUGXrNMwAWFo9IOjZP(aXqWLoTdVgME(u"ࠬࡩࡥ࡯ࡶࡨࡶࠬᆯ"),qpFY4hAwolV3,qpFY4hAwolV3,N3flV6EJsD5CzS(u"࠭สๆ่ࠢืาࠦัิษ็ฮ่࠭ᆰ")+IaBhDMJc17302LgSvyxd(u"ࠧࠡࠢ࠵࠳࠺࠭ᆱ"),tQMjXKCA5dN4xq3beVIzaEoWkFLg(u"ࠨ้็ࠤฯื๊ะࠢศีุอไࠡำึห้ฯࠠโษิ฾ฮ࠭ᆲ"))
		x6t2RXGEkl37oYIVynZ = VVpbtSKYUGXrNMwAWFo9IOjZP(UVa3fJw7k6KM(u"ࠩࡦࡩࡳࡺࡥࡳࠩᆳ"),qpFY4hAwolV3,qpFY4hAwolV3,DiJ8CMuYH1daWyjehfN0L(u"ࠪฮ๊ࠦๅิฯࠣีุอไหๅࠪᆴ")+c2RKu0xG1eC8MiohyE(u"ࠫࠥࠦ࠳࠰࠷ࠪᆵ"),lljaEqwTVtmKsQcOrbXxS5hgNH(u"ࠬํไࠡฬิ๎ิࠦลาีส่ࠥืำศๆฬࠤๆอั฻หࠪᆶ"))
		Qbgnh9cWkAL8UdeCTs20XtNBKVI = VVpbtSKYUGXrNMwAWFo9IOjZP(aXqWLoTdVgME(u"࠭ࡣࡦࡰࡷࡩࡷ࠭ᆷ"),qpFY4hAwolV3,qpFY4hAwolV3,l32dnTEOU1skGKqeBtI9hmo(u"ࠧห็ุ้ࠣำࠠาีส่ฯ้ࠧᆸ")+aXqWLoTdVgME(u"ࠨࠢࠣ࠸࠴࠻ࠧᆹ"),sjtU6GZQg5XC2pH4(u"๊่ࠩࠥะั๋ัࠣษึูวๅࠢิืฬ๊ษࠡใสี฿ฯࠧᆺ"))
		o2gtGzZXiDy4nAqUPwKf578EVaOY1M = VVpbtSKYUGXrNMwAWFo9IOjZP(tR1krDGPpO025fghMT3a7UnYj(u"ࠪࡧࡪࡴࡴࡦࡴࠪᆻ"),qpFY4hAwolV3,qpFY4hAwolV3,sjtU6GZQg5XC2pH4(u"ࠫฯ๋ࠠๆีะࠤึูวๅฬๆࠫᆼ")+kYDaz79TFlXoR(u"ࠬࠦࠠ࠶࠱࠸ࠫᆽ"),UUDAiytEL76RTmMYsuIz5evXB(u"࠭็ๅࠢอี๏ีࠠฦำึห้ࠦัิษ็อࠥ็วา฼ฬࠫᆾ"))
	WRbn1LC2xPJMZft = VfIUXSM1GcvJ6hdr7(ag8rjZo1Vz4IPdcOT)
	pKanENhR1k8sUBYqOFZzP = lljaEqwTVtmKsQcOrbXxS5hgNH(u"ࠧࡂࡘ࠽ࠤࠬᆿ")+WRbn1LC2xPJMZft+UUDAiytEL76RTmMYsuIz5evXB(u"ࠨ࠯ࠪᇀ")+type
	k2nju1XItgCWLobyG6 = gBExoceumj4y8bFW9hY2aNMVSr if viRJWOC5jsYe84(u"ࠩࡢࡔࡗࡕࡂࡍࡇࡐࡣࠬᇁ") in HY7yaJeI89xE56sbTjdBRZPDwQKFX else ag8rjZo1Vz4IPdcOT
	if not o2gtGzZXiDy4nAqUPwKf578EVaOY1M:
		if showDialogs: iG7Rz2kmn0x1yLNMV3u8O(qpFY4hAwolV3,qpFY4hAwolV3,GLTtERWbHnFuy4PCp,RlOvin8YIGC2KZXJPk9m0acrMobUex(u"ࠪฮ๊ࠦลๅ฼สลࠥอไฦำึห้ࠦศ็ษฤࠤ฾ู๊้ࠡ็ฬ่࠭ᇂ"))
		return ag8rjZo1Vz4IPdcOT
	dGYH7oq0Xy93iBkL1 = Rqvw05BorCgcye7VE32Sf.getInfoLabel(CC1eY6yWZUwf2TkRvnp7EJ0AimjHBX(u"ࠫࡘࡿࡳࡵࡧࡰ࠲ࡋࡸࡩࡦࡰࡧࡰࡾࡔࡡ࡮ࡧࠪᇃ"))
	w0CZ6B3WDJknhEsdRYyH1XAM += RlOvin8YIGC2KZXJPk9m0acrMobUex(u"ࠬࠦ࡜࡝ࡰ࡟ࡠࡳࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࠦ࡜࡝ࡰࡄࡨࡩࡵ࡮ࠡࡘࡨࡶࡸ࡯࡯࡯࠼ࠣࠫᇄ")+Q8q1YzIF6icWtSp2L+l32dnTEOU1skGKqeBtI9hmo(u"࠭ࠠ࠻࡞࡟ࡲࠬᇅ")
	w0CZ6B3WDJknhEsdRYyH1XAM += mmV2nucZ5Lpl6FO1JMPEqGoQKW(u"ࠧࡆ࡯ࡤ࡭ࡱࠦࡓࡦࡰࡧࡩࡷࡀࠠࠨᇆ")+WRbn1LC2xPJMZft+V3VlkhgjEF4n1erPXHcC0NOsfwyAJ(u"ࠨࠢ࠽ࡠࡡࡴࡋࡰࡦ࡬ࠤ࡛࡫ࡲࡴ࡫ࡲࡲ࠿ࠦࠧᇇ")+wjuB8sDm0oPfShXWp+iNc3KxwErnQ(u"ࠩࠣ࠾ࡡࡢ࡮ࠨᇈ")
	w0CZ6B3WDJknhEsdRYyH1XAM += YY8UDX3MJhb91AHw7fg(u"ࠪࡏࡴࡪࡩࠡࡐࡤࡱࡪࡀࠠࠨᇉ")+dGYH7oq0Xy93iBkL1
	UZHj1CuOIxPzAoTvcEV05d7NFi2G3m = bfLg2cN8FvsxWMeyj7q()
	UZHj1CuOIxPzAoTvcEV05d7NFi2G3m = UZHj1CuOIxPzAoTvcEV05d7NFi2G3m.replace(zYvEaigKWjoq50pXBLDbGJkFc(u"ࠫ࠱࠲ࠧᇊ"),ddiCzu6yahj5RtTISMJ48sNnZBU(u"ࠬ࠲ࠧᇋ"))
	UZHj1CuOIxPzAoTvcEV05d7NFi2G3m = BUKlErdIu7Ggqcz3jYpf09wMePF4V(UZHj1CuOIxPzAoTvcEV05d7NFi2G3m)
	if UZHj1CuOIxPzAoTvcEV05d7NFi2G3m: w0CZ6B3WDJknhEsdRYyH1XAM += fWoVd0Bmtkx(u"࠭ࠠ࠻࡞࡟ࡲࡑࡵࡣࡢࡶ࡬ࡳࡳࡀࠠࠨᇌ")+UZHj1CuOIxPzAoTvcEV05d7NFi2G3m
	if url: w0CZ6B3WDJknhEsdRYyH1XAM += ddiCzu6yahj5RtTISMJ48sNnZBU(u"ࠧࠡ࠼࡟ࡠࡳ࡛ࡒࡍ࠼ࠣࠫᇍ")+url
	if n38oH7wd6BDyAMJQS: w0CZ6B3WDJknhEsdRYyH1XAM += LZWMikPEB81KSGyxfJtUsCA(u"ࠨࠢ࠽ࡠࡡࡴࡓࡰࡷࡵࡧࡪࡀࠠࠨᇎ")+n38oH7wd6BDyAMJQS
	w0CZ6B3WDJknhEsdRYyH1XAM += Ie5s2cBtSfdHjzQ4rA9kYlo6D18(u"ࠩࠣ࠾ࡡࡢ࡮ࠨᇏ")
	if showDialogs: t8yiLuJp3cBA6d1QE9x7eZ4fa(kYDaz79TFlXoR(u"ࠪะฬื๊ࠡษ็ษึูวๅࠩᇐ"),dJHDqiKf12TXlIzSLkGUuxg4MBs3A(u"ࠫฬ๊ัอษฤࠤฬ๊ว็ฬ฻หึ࠭ᇑ"))
	if k2nju1XItgCWLobyG6:
		if fWoVd0Bmtkx(u"ࠬࡥࡐࡓࡑࡅࡐࡊࡓ࡟ࡐࡎࡇࡣࠬᇒ") in HY7yaJeI89xE56sbTjdBRZPDwQKFX: Z5XdOD4pj8RbTYJxy12vS = Zxm9QJBbv7GEkYVK6X8fA3DM0
		else: Z5XdOD4pj8RbTYJxy12vS = k8AjFZIlXNLg5diJCHMR20TEznOY
		if not RPbaxsNFVTwek5Kfv21DiJuzCnjMZp.path.exists(Z5XdOD4pj8RbTYJxy12vS):
			iG7Rz2kmn0x1yLNMV3u8O(qpFY4hAwolV3,qpFY4hAwolV3,GLTtERWbHnFuy4PCp,iNc3KxwErnQ(u"࠭ำอๆࠣห้ษฮุษฤࠤํอไศีอาิอๅࠡ฼ํี๋่ࠥอ๊าࠫᇓ"))
			return ag8rjZo1Vz4IPdcOT
		LLvyStW429DEZKlA(k8kdUSxohLVljnrY,V3VlkhgjEF4n1erPXHcC0NOsfwyAJ(u"ࠧ࠯࡞ࡷࡔࡷ࡫ࡰࡢࡴ࡬ࡲ࡬ࠦࡴࡰࠢࡶࡩࡳࡪࠠࡵࡪࡨࠤࡱࡵࡧࡧ࡫࡯ࡩࠬᇔ"))
		lsDWF6UEpxa5KAeRjXMCI,Ljv3VaAWEBGxrRzbQJYhN = [],UVa3fJw7k6KM(u"࠶Ꮆ")
		file = open(Z5XdOD4pj8RbTYJxy12vS,c2RKu0xG1eC8MiohyE(u"ࠨࡴࡥࠫᇕ"))
		size,count = e2YrFAdw9WBl8740uPKUcGCbL(Z5XdOD4pj8RbTYJxy12vS)
		if size>CC1eY6yWZUwf2TkRvnp7EJ0AimjHBX(u"࠳࠱࠳࠳࠴࠵Ꮇ"): file.seek(-CC1eY6yWZUwf2TkRvnp7EJ0AimjHBX(u"࠳࠱࠳࠳࠴࠵Ꮇ"),RPbaxsNFVTwek5Kfv21DiJuzCnjMZp.SEEK_END)
		data = file.read()
		file.close()
		data = data.decode(nV3Tip6XsH1rJw79DPOU)
		data = DMx1n65ra9gGSH(data)
		Mm8BldxpifLUa5s2 = data.splitlines()
		for N3S5LUH7Fwztgu9qshjIfvKn8Txlk1 in reversed(Mm8BldxpifLUa5s2):
			pG06jynh5g = tPw2A9G4HfqOLYDUmrolNI6icJ(N3S5LUH7Fwztgu9qshjIfvKn8Txlk1)
			if pG06jynh5g: continue
			vB9hes2mpanzkc36Cq4wfyIQoiKM = ePhmG1jLD6.findall(BRWqdruz2A0(u"ࠩࡡࠬࡡࡪࠫ࠮ࠪ࡟ࡨ࠰࠳࡜ࡥ࠭ࠣࡠࡩ࠱࠺࡝ࡦ࠮࠾ࡡࡪࠫ࡝࠰࡟ࡨ࠰࠯ࠩࠩࠢࡗ࠾ࡡࡪࠫࠪࠩᇖ"),N3S5LUH7Fwztgu9qshjIfvKn8Txlk1,ePhmG1jLD6.DOTALL)
			if vB9hes2mpanzkc36Cq4wfyIQoiKM:
				N3S5LUH7Fwztgu9qshjIfvKn8Txlk1 = N3S5LUH7Fwztgu9qshjIfvKn8Txlk1.replace(vB9hes2mpanzkc36Cq4wfyIQoiKM[vvXoMLlg513][vvXoMLlg513],vB9hes2mpanzkc36Cq4wfyIQoiKM[vvXoMLlg513][mZi0S72jGoHpLO]).replace(vB9hes2mpanzkc36Cq4wfyIQoiKM[vvXoMLlg513][Zwqio2AIWlD5etFa],qpFY4hAwolV3)
			else:
				vB9hes2mpanzkc36Cq4wfyIQoiKM = ePhmG1jLD6.findall(BRWqdruz2A0(u"ࠪࡢ࠭ࡢࡤࠬ࠼࡟ࡨ࠰ࡀ࡜ࡥ࠭࡟࠲ࡡࡪࠫࠪࠪࠣࡘ࠿ࡢࡤࠬࠫࠪᇗ"),N3S5LUH7Fwztgu9qshjIfvKn8Txlk1,ePhmG1jLD6.DOTALL)
				if vB9hes2mpanzkc36Cq4wfyIQoiKM: N3S5LUH7Fwztgu9qshjIfvKn8Txlk1 = N3S5LUH7Fwztgu9qshjIfvKn8Txlk1.replace(vB9hes2mpanzkc36Cq4wfyIQoiKM[vvXoMLlg513][mZi0S72jGoHpLO],qpFY4hAwolV3)
			lsDWF6UEpxa5KAeRjXMCI.append(N3S5LUH7Fwztgu9qshjIfvKn8Txlk1)
			if len(str(lsDWF6UEpxa5KAeRjXMCI))>mmV2nucZ5Lpl6FO1JMPEqGoQKW(u"࠳࠷࠴࠴࠵࠶Ꮈ"): break
		lsDWF6UEpxa5KAeRjXMCI = reversed(lsDWF6UEpxa5KAeRjXMCI)
		xnbh94i3Pyfm = LZWMikPEB81KSGyxfJtUsCA(u"ࠫࡡࡸ࡜࡯ࠩᇘ").join(lsDWF6UEpxa5KAeRjXMCI)
	elif xxpI8yblnvEV: xnbh94i3Pyfm = xxpI8yblnvEV
	else: xnbh94i3Pyfm = qpFY4hAwolV3
	url = i4bFG3rKE6.SITESURLS[iNc3KxwErnQ(u"ࠬࡖ࡙ࡕࡊࡒࡒࠬᇙ")][Zwqio2AIWlD5etFa]
	GI0fwOUzWlVYaicPdBRunFy = {kYDaz79TFlXoR(u"࠭ࡳࡶࡤ࡭ࡩࡨࡺࠧᇚ"):pKanENhR1k8sUBYqOFZzP,tQMjXKCA5dN4xq3beVIzaEoWkFLg(u"ࠧ࡮ࡧࡶࡷࡦ࡭ࡥࠨᇛ"):w0CZ6B3WDJknhEsdRYyH1XAM,DiJ8CMuYH1daWyjehfN0L(u"ࠨ࡮ࡲ࡫࡫࡯࡬ࡦࠩᇜ"):xnbh94i3Pyfm}
	IAW0sh6So3NpqM = WWrExJZS3Bj4anOAkpv7(dzcNuIbsgK3yZ6SXGaEHPfOj5vk,aXqWLoTdVgME(u"ࠩࡓࡓࡘ࡚ࠧᇝ"),url,GI0fwOUzWlVYaicPdBRunFy,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,sjtU6GZQg5XC2pH4(u"ࠪࡗࡊࡘࡖࡊࡅࡈࡗ࠲࡙ࡅࡏࡆࡢࡉࡒࡇࡉࡍ࠯࠴ࡷࡹ࠭ᇞ"))
	cmWl9dOKHPIy41iaXuxrY = IAW0sh6So3NpqM.content
	if lljaEqwTVtmKsQcOrbXxS5hgNH(u"ࠫࡸ࡫࡮ࡥࡡࡶࡹࡨࡩࡥࡦࡦࡨࡨࠬᇟ") in cmWl9dOKHPIy41iaXuxrY: zlQAfuT2Z7nKhGdXs = gBExoceumj4y8bFW9hY2aNMVSr
	else: zlQAfuT2Z7nKhGdXs = ag8rjZo1Vz4IPdcOT
	if showDialogs:
		if zlQAfuT2Z7nKhGdXs:
			t8yiLuJp3cBA6d1QE9x7eZ4fa(qoBMmfAWpFlK70xw8ZRh4naJ(u"ࠬะๅࠡษ็ษึูวๅࠢห๊ัออࠨᇠ"),RlOvin8YIGC2KZXJPk9m0acrMobUex(u"࠭ࡓࡶࡥࡦࡩࡸࡹࠧᇡ"))
			iG7Rz2kmn0x1yLNMV3u8O(qpFY4hAwolV3,qpFY4hAwolV3,l1DZAt9XNQjqE7YOdrz(u"ࠧࡎࡧࡶࡷࡦ࡭ࡥࠡࡵࡨࡲࡹ࠭ᇢ"),mmV2nucZ5Lpl6FO1JMPEqGoQKW(u"ࠨฬ่ࠤสืำศๆࠣห้ืำศๆฬࠤอ์ฬศฯࠪᇣ"))
		else:
			t8yiLuJp3cBA6d1QE9x7eZ4fa(aXqWLoTdVgME(u"ࠩ็่ศูแࠡใื่ࠥอไฦำึห้࠭ᇤ"),l1DZAt9XNQjqE7YOdrz(u"ࠪࡊࡦ࡯࡬ࡶࡴࡨࠫᇥ"))
			iG7Rz2kmn0x1yLNMV3u8O(qpFY4hAwolV3,qpFY4hAwolV3,GLTtERWbHnFuy4PCp,qqzwE6imYG4c2xojI(u"ࠫำ฽ร๊ࠡไุ้ࠦแ๋ࠢศีุอไࠡษ็ีุอไสࠩᇦ"))
	return zlQAfuT2Z7nKhGdXs
def vUr8x1Eh5uHIls7e3ciYQ0JgB():
	JQ0OTpbAGY8khnwf = qqzwE6imYG4c2xojI(u"ࠬࡊ࡯ࠡࡻࡲࡹࠥࡽࡡ࡯ࡶࠣࡸࡴࠦࡴࡳࡣࡱࡷࡱࡧࡴࡦࠢࡰࡩࡳࡻࠠࡪࡶࡨࡱࡸࠦࡴࡰࠢࡤࠤࡱࡧ࡮ࡨࡷࡤ࡫ࡪࠦ࡯ࡵࡪࡨࡶࠥࡺࡨࡢࡰࠣࡅࡷࡧࡢࡪࡥࠣ࠲࠳ࠦࡏࡳࠢࡼࡳࡺࠦࡷࡢࡰࡷࠤࡹࡵࠠࡴࡪࡲࡻࠥࡇࡲࡢࡤ࡬ࡧࠥࡲࡥࡵࡶࡨࡶࡸࠦࡡ࡯ࡦࠣࡸࡪࡾࡴࠡࡁࠤࠫᇧ")
	UJqj5NE0ZKm = V3VlkhgjEF4n1erPXHcC0NOsfwyAJ(u"࠭็ๅࠢอี๏ีࠠหำฯ้ฮࠦโ้ษษ้ࠥอไษำ้ห๊าࠠฦๆ์ࠤ้เษࠡลัี๎ฺ๋ࠦำࠣห้฿ัษ์ฬࠤ࠳࠴ࠠฤ็ࠣฮึ๐ฯࠡว฻๋ฬืࠠศๆฦัึ็้ࠠษ็็ฯอศสࠢส่฾ืศ๋หࠣรࠦ࠭ᇨ")
	choice = eVLmAIGFiwpr94UK6MRP5(YY8UDX3MJhb91AHw7fg(u"ࠧࡤࡧࡱࡸࡪࡸࠧᇩ"),qoBMmfAWpFlK70xw8ZRh4naJ(u"ࠨะิ์ัࠦࡅࡹ࡫ࡷࠫᇪ"),tR1krDGPpO025fghMT3a7UnYj(u"ࠩࡗࡶࡦࡴࡳ࡭ࡣࡷࡩࠥะัอ็ฬࠫᇫ"),RlOvin8YIGC2KZXJPk9m0acrMobUex(u"ࠪ฽ึฮ๊ࠡࡃࡵࡥࡧ࡯ࡣࠨᇬ"),GLTtERWbHnFuy4PCp,JQ0OTpbAGY8khnwf+LZWMikPEB81KSGyxfJtUsCA(u"ࠫࡡࡴ࡜࡯ࠩᇭ")+UJqj5NE0ZKm)
	if choice in [-fWoVd0Bmtkx(u"࠳Ꮉ"),dJHDqiKf12TXlIzSLkGUuxg4MBs3A(u"࠳Ꮊ")]: return
	elif choice==LZWMikPEB81KSGyxfJtUsCA(u"࠵Ꮋ"):
		import f5akw4Lux3
		f5akw4Lux3.ziNdvWtuIUTPxH9GMcban8jRq47f()
		return
	Zr5HDvxymhe3Lqa = gBExoceumj4y8bFW9hY2aNMVSr
	while Zr5HDvxymhe3Lqa:
		Zr5HDvxymhe3Lqa = ag8rjZo1Vz4IPdcOT
		message = kYDaz79TFlXoR(u"ࠬหะศࠢ฼๊ิ้ࠠๆึๆ่ฮࠦแ๋ࠢส่ศำัโࠢส่฾ืศ๋หࠣๅฬึ็ษࠢศ่๎ࠦࠢฦ฻าหิอส๊ࠡสะ์ฯࠠไ๊า๎ࠧࠦหๆࠢ฽๎ึࠦวๅะฺࠤส๊้ࠡࠤࡄࡶ࡮ࡧ࡬ࠣࠢ࠱࠲ࠥหะศࠢ็้ࠥะฬะࠢส่ำ฽ࠠࠣࡃࡵ࡭ࡦࡲࠢࠡใ฽๎ึࠦวๅฮ็ำࠥหไ๊ࠢฦ๎ࠥาไะࠢฮห๋๐ࠠโ์๊ࠤฬ๊ฮุࠢࠥࡅࡷ࡯ࡡ࡭ࠤࠣ࠲࠳ࠦหๆࠢห฽ิํวࠡ฼ํีࠥอไฯูࠣษ้๏ࠠࠣࡃࡵ࡭ࡦࡲࠢࠡ࡞ࡱࠤสึวࠡๆ๋ัฮࠦวๅ็ไหฯ๐อࠡษ็฽ึฮ๊สࠢ็หࠥะุ่ำ่่ࠣࠦ࠮࠯ࠢสิ์ฮࠠฦๆ์ࠤࠧหูะษาหฯ่ࠦศฮ๊อ้่ࠥะ์ࠥࠤ࠳࠴ࠠฬ็ࠣ฾๏ืࠠฦ฻าหิอสࠡษ็้ํู่ࠡษ็ะ฿ืวโ์ࠣࡠࡳࡢ࡮้ࠡ็ࠤฯื๊ะࠢส่ว์ࠠโฬะࠤࠧหูะษาหฯ่ࠦศฮ๊อ้่ࠥะ์ࠥࠤฤࠧࠧᇮ")
		choice = eVLmAIGFiwpr94UK6MRP5(DiJ8CMuYH1daWyjehfN0L(u"࠭ࡣࡦࡰࡷࡩࡷ࠭ᇯ"),tQMjXKCA5dN4xq3beVIzaEoWkFLg(u"ࠧࡆࡺ࡬ࡸࠥิั้ฮࠪᇰ"),N3flV6EJsD5CzS(u"ࠨ࡛ࡨࡷࠥ์ูๆࠩᇱ"),IaBhDMJc17302LgSvyxd(u"ࠩࡈࡲ࡬ࡲࡩࡴࡪࠣษ๋าไ๋ิํࠫᇲ"),CC1eY6yWZUwf2TkRvnp7EJ0AimjHBX(u"ࠪ฽ิู๋้๋ࠠีࠥอไฤฯิๅࠥ๎วๅๅอหอฯࠠศๆ฼ีอ๐ษࠨᇳ"),message,profile=rNdBKI74fAklnoCZ6(u"ࠫࡨࡵ࡮ࡧ࡫ࡵࡱࡤࡳࡥࡥ࡫ࡸࡱ࡫ࡵ࡮ࡵࠩᇴ"))
		if choice==lljaEqwTVtmKsQcOrbXxS5hgNH(u"࠷Ꮌ"):
			message = qoBMmfAWpFlK70xw8ZRh4naJ(u"ࠬࡏࡦࠡࡻࡲࡹࠥ࡮ࡡࡷࡧࠣࡴࡷࡵࡢ࡭ࡧࡰࠤࡼ࡯ࡴࡩࠢࡄࡶࡦࡨࡩࡤࠢ࡯ࡩࡹࡺࡥࡳࡵࠣࡸ࡭࡫࡮ࠡࡱࡳࡩࡳࠦࠢࡌࡱࡧ࡭ࠥࡏ࡮ࡵࡧࡵࡪࡦࡩࡥࠡࡕࡨࡸࡹ࡯࡮ࡨࡵࠥࠤࡦࡴࡤࠡࡥ࡫ࡥࡳ࡭ࡥࠡࡶ࡫ࡩࠥ࡬࡯࡯ࡶࠣࡸࡴࠦࠢࡂࡴ࡬ࡥࡱࠨࠠ࠯࠰ࠣࡍ࡫ࠦࡹࡰࡷࠣࡧࡦࡴ࡜ࠨࡶࠣࡪ࡮ࡴࡤࠡࠤࡄࡶ࡮ࡧ࡬ࠣࠢࡩࡳࡳࡺࠠࡵࡪࡨࡲࠥࡩࡨࡢࡰࡪࡩࠥࡺࡨࡦࠢࡶ࡯࡮ࡴࠠࡵࡱࠣࡥࡳࡿࠠࡰࡶ࡫ࡩࡷࠦࡳ࡬࡫ࡱࠤࡹ࡮ࡡࡵࠢ࡫ࡥࡻ࡫ࠠ࡝ࠤࡄࡶ࡮ࡧ࡬࡝ࠤࠣࡪࡴࡴࡴࠡ࠰࠱ࠤࡆࡴࡤࠡࡶ࡫ࡩࡳࠦࡣࡩࡣࡱ࡫ࡪࠦࡴࡩࡧࠣࡪࡴࡴࡴࠡࡶࡲࠤࠧࡇࡲࡪࡣ࡯ࠦࠥࡢ࡮ࠡࡋࡩࠤࡆࡸࡡࡣ࡫ࡦࠤࡐ࡫ࡹࡣࡱࡤࡶࡩࠦࡩࡴࠢࡱࡳࡹࠦࡡࡷࡣ࡬ࡰࡦࡨ࡬ࡦࠢ࠱࠲࡚ࠥࡨࡦࡰࠣࡳࡵ࡫࡮ࠡࠤࡎࡳࡩ࡯ࠠࡊࡰࡷࡩࡷ࡬ࡡࡤࡧࠣࡗࡪࡺࡴࡪࡰࡪࡷࠧࠦࡡ࡯ࡦࠣࡧ࡭ࡧ࡮ࡨࡧࠣࡸ࡭࡫ࠠࡳࡧࡪ࡭ࡴࡴࡡ࡭ࠢࡶࡩࡹࡺࡩ࡯ࡩࡶࠤࡡࡴ࡜࡯ࠢࡇࡳࠥࡿ࡯ࡶࠢࡺࡥࡳࡺࠠ࡯ࡱࡺࠤࡹࡵࠠࡰࡲࡨࡲࠥࡺࡨࡦࠢࠥࡏࡴࡪࡩࠡࡋࡱࡸࡪࡸࡦࡢࡥࡨࠤࡘ࡫ࡴࡵ࡫ࡱ࡫ࡸࠨࠠࡀࠣࠪᇵ")
			choice = eVLmAIGFiwpr94UK6MRP5(l1DZAt9XNQjqE7YOdrz(u"࠭ࡣࡦࡰࡷࡩࡷ࠭ᇶ"),tR1krDGPpO025fghMT3a7UnYj(u"ࠧࡆࡺ࡬ࡸࠥิั้ฮࠪᇷ"),dJHDqiKf12TXlIzSLkGUuxg4MBs3A(u"ࠨ࡛ࡨࡷࠥ์ูๆࠩᇸ"),fWoVd0Bmtkx(u"ࠩࡄࡶࡦࡨࡩࡤࠢ฼ีอ๐ࠧᇹ"),dJHDqiKf12TXlIzSLkGUuxg4MBs3A(u"ࠪࡑ࡮ࡹࡳࡪࡰࡪࠤࡆࡸࡡࡣ࡫ࡦࠤࡋࡵ࡮ࡵࠢࠩࠤ࡙࡫ࡸࡵࠩᇺ"),message,profile=l1DZAt9XNQjqE7YOdrz(u"ࠫࡨࡵ࡮ࡧ࡫ࡵࡱࡤࡳࡥࡥ࡫ࡸࡱ࡫ࡵ࡮ࡵࠩᇻ"))
			if choice==lljaEqwTVtmKsQcOrbXxS5hgNH(u"࠸Ꮍ"): Zr5HDvxymhe3Lqa = gBExoceumj4y8bFW9hY2aNMVSr
		if choice==zYvEaigKWjoq50pXBLDbGJkFc(u"࠱Ꮎ"): IBWlOKRwz0nAU8gZ5STQk()
	return
def VqNaJlpESnm6FAjyuDBL2Mxg4hO7bH():
	iG7Rz2kmn0x1yLNMV3u8O(qpFY4hAwolV3,qpFY4hAwolV3,GLTtERWbHnFuy4PCp,lljaEqwTVtmKsQcOrbXxS5hgNH(u"ࠬเวๅสสࠤฬ๊ำษส๋ࠣํࠦๅ็ࠢส่๊๎โฺࠢส่ศ฻ไ๋ࠢส่๊เะ๋ࠢ็่อืๆศ็ฯࠤํ๊ไหลๆำ่ࠥๅࠡสอุ฿๐ไࠡษ็ีฬฮืࠡษ็ิ๏ࠦไศࠢํ฽๊๊ࠠฬ็ࠣๆ๊ࠦศฦำึห้ࠦๅีๅ็อࠥหไ๊ࠢส่๊ฮัๆฮ้๋ࠣࠦวๅไสส๊ฯࠠศๆิส๏ู๊สࠢ็่อืๆศ็ฯࠫᇼ"))
	return
def dJUkRO41LBDnCcvHgqwzb6iVxWQj5():
	w0CZ6B3WDJknhEsdRYyH1XAM = aXqWLoTdVgME(u"࠭็ัษࠣห้ฮั็ษ่ะ๋ࠥฮึืࠣๅ็฽ࠠๅๆ฽อࠥอไฺำห๎ฮ่ࠦๅๅ้ࠤ์ึวࠡๆสࠤ๏๋ๆฺ๋ࠢะํีࠠๆ๊สๆ฾ࠦแ๋้สࠤศ็ไศ็ࠣ์ู๊ไิๆสฮ๋ࠥสาฮ่อࠥษ่ࠡ็าฬ้าษࠡว็ํࠥอไๅ฼ฬࠤฬู๊าสํอࠥ๎วๅ๋่ࠣ฿อสࠡษัี๎่ࠦๅษࠣ๎ําฯࠡีหฬ๊ࠥไหๅิหึ࠭ᇽ")
	iG7Rz2kmn0x1yLNMV3u8O(qpFY4hAwolV3,qpFY4hAwolV3,GLTtERWbHnFuy4PCp,w0CZ6B3WDJknhEsdRYyH1XAM)
	return
def ej9tk8g5TJfKbwy7andDoH():
	w0CZ6B3WDJknhEsdRYyH1XAM = rNdBKI74fAklnoCZ6(u"ࠧศๆิ์ฬฮืࠡษ็ฬ฼๐ฦสࠢ็หࠥ฿ไศไฬࠤ้ํวࠡสส่อืๆศ็ฯࠤํเวๅสสࠤฬ๊ำษส๋ࠣํࠦๅ็ࠢส่๊๎โฺࠢส่ศ฻ไ๋ࠢส่๊เะ๋ࠢ็่อืๆศ็ฯࠫᇾ")
	iG7Rz2kmn0x1yLNMV3u8O(qpFY4hAwolV3,qpFY4hAwolV3,GLTtERWbHnFuy4PCp,w0CZ6B3WDJknhEsdRYyH1XAM)
	return
def OId452eZz8SsWw():
	w0CZ6B3WDJknhEsdRYyH1XAM = viRJWOC5jsYe84(u"ࠨ้ํࠤุ๐ัโำสฮ๊ࠥวࠡ์ึฮ฼๐ูࠡษ็ฬึ์วๆฮࠣหุะฮะษ่๋ฬࠦศิสหࠤ่๎ๆ่ษ้ࠣา๋๊ส่๊ࠢࠥอไๆืาีࠥษ่ࠡสะหัฯࠠฦๆ์ࠤฬฺสาษๆࠤึูๅ๋ࠢฦ์ࠥาฯ๋ัฬࠤศ๎ࠠๅษࠣ๎฾ืแ่ษࠣห้ฮั็ษ่ะࠬᇿ")
	iG7Rz2kmn0x1yLNMV3u8O(qpFY4hAwolV3,qpFY4hAwolV3,GLTtERWbHnFuy4PCp,LZWMikPEB81KSGyxfJtUsCA(u"ࠩึ๎ึ็ัศฬࠣื๏ฬษࠡล๋ࠤ๊า็้ๆฬࠫሀ"),w0CZ6B3WDJknhEsdRYyH1XAM)
	return
def YwIVmvTRU1ut2ZdPozEDcWK():
	w0CZ6B3WDJknhEsdRYyH1XAM = aXqWLoTdVgME(u"ࠪหู้๊าใิหฯࠦวๅ฻ส้ฮࠦ็๋ࠢึ๎ึ็ัศฬࠣาฬืฬ๋หࠣ์฿๐ัࠡฬสฬ฾ฯࠠๅๆ่์็฿ࠠศๆฦู้๐้ࠠฮ่๎฾ࠦวๅ็๋ห็฿ࠠหีอาิ๋็ศ๋ࠢ฽ฬีษࠡฬๆ์๋ࠦๅอษ้๎ฮ่ࠦๆึส็้ํวࠡๅฮ๎ึฯࠠๅษ้ࠤฬ๊แ๋ัํ์์อสࠡใํ๋ฬࠦลๆษࠣฬ฼๐ฦสࠢฦ์๋ࠥๅ็๊฼อࠥษ่ࠡ็ะิํ็ษࠡล๋ࠤๆ๐็ศุ่่๊ࠢษࠡฯๅ์็ࠦวๅ็็็๏ฯ࡜࡯࡞ࡱࡠࡳอไิ์ิๅึอสࠡษ็าฬ฻ษ้ࠡํࠤุ๐ัโำสฮࠥะวษ฻ฬࠤ้๊ๅ้ไ฼ࠤฬ๊รึๆํࠤํ๋ำหะา้ฮࠦแ๋่ࠢ์ฬู่ࠡไ็๎้ฯࠠอัสࠤํ฿วะหࠣฮ่๎ๆࠡ็าๅํ฿ษࠡษ็วัืࠠฤ๊ࠣ๎๊๊ใ่ษࠣห้๋่ใ฻ࠣห้ษีๅ์ࠣ์้ํะศࠢไ๋๏ࠦฬ๋ัฬࠤู๋ศ๋ษࠣ์ุืฺ๊หࠣ์ฺ๊วไๆ๊ห่ࠥไ๋ๆฬࠤัีวࠨሁ")
	W2fBJaUN9kZwVeR1n0o4Dc(LZWMikPEB81KSGyxfJtUsCA(u"ࠫࡨ࡫࡮ࡵࡧࡵࠫሂ"),GLTtERWbHnFuy4PCp,w0CZ6B3WDJknhEsdRYyH1XAM,aXqWLoTdVgME(u"ࠬࡺࡥࡹࡶࡹ࡭ࡪࡽ࡟ࡣ࡫ࡪࡪࡴࡴࡴࠨሃ"))
	return
def yyuwY8EsjDdkCeNKFzmH():
	JQ0OTpbAGY8khnwf = CC1eY6yWZUwf2TkRvnp7EJ0AimjHBX(u"࠭วษฬ฼ำࠥ฿ๆࠡ็็ๅฬะࠠศๆาๆฮࠦวๅ฻ส่๏ฯࠧሄ")
	UJqj5NE0ZKm = qoBMmfAWpFlK70xw8ZRh4naJ(u"ࠧศสอ฽ิูࠦ็่่ࠢๆอสࠡล็ࠤࡲ࠹ࡵ࠹ࠩህ")
	kKBpAYVRmwnCJaQ = DaFZHsThGmd0zv6e(u"ࠨษหฮ฾ีฺ่้้ࠠࠣ็วหࠢส่ฯำๅ๋ๆࠣ์ฬ๊ฯศ๊้่ํีࠠࡥࡱࡺࡲࡱࡵࡡࡥࠩሆ")
	iG7Rz2kmn0x1yLNMV3u8O(qpFY4hAwolV3,qpFY4hAwolV3,GLTtERWbHnFuy4PCp,JQ0OTpbAGY8khnwf,UJqj5NE0ZKm,kKBpAYVRmwnCJaQ)
	return
def hhL6vp9bzkHJQ5qjD1C():
	UJqj5NE0ZKm = sjtU6GZQg5XC2pH4(u"ࠩส่่อิ้๋ࠡࠤ๊ิา็่ࠢศ็ะࠠๅๆ่฽้๎ๅศฬࠣ๎ุะฮะ็๊ࠤฬ๊ศา่ส้ัࠦไฯิ้ࠤฺ็อศฬࠣห้หๆหำ้๎ฯ่ࠦา๊สฬ฼ࠦวๅใํำ๏๎็ศฬ่้ࠣ๎ี้ๆࠣษ้๐็ศࠢหืึ฿ษ๊ࠡหำํ์ࠠฦ่อี๋๐ส๊ࠡส่อืๆศ็ฯࠤ๏๋ำฮ้สࠤฯ๊โศศํหࠥฮูะࠢส๊ฯํวยࠢ฼้ึํว๊ࠡฦ๎฻อฺ่ࠠาࠤฯำฯ๋อࠣห้ฮั็ษ่ะࠥ࠴้้ࠠำหࠥอไษำ้ห๊า๋ࠠีอาิ๋ࠠิส฼อࠥษๆ้ษ฼ࠤ้฿ๅาࠢส่่อิࠡ࠼ࠪሇ")
	UJqj5NE0ZKm += LZWMikPEB81KSGyxfJtUsCA(u"ࠪࡠࡳࡢ࡮ࠨለ") + dJHDqiKf12TXlIzSLkGUuxg4MBs3A(u"ࠫ࠶࠴ࠠฬษหฮ๊ࠥไึใะหฯࠦวๅฬํࠤ๊฿ั้ใࠣว๋ํวࠡๆสࠤฯะฺ๋ำ๊ࠣ์อฦ๋ษࠣ์๊ีส่ࠢࠪሉ") + str(ivLg9zRnGF83u/N3flV6EJsD5CzS(u"࠷࠲Ꮏ")/N3flV6EJsD5CzS(u"࠷࠲Ꮏ")/qqzwE6imYG4c2xojI(u"࠴࠷Ꮐ")/RlOvin8YIGC2KZXJPk9m0acrMobUex(u"࠶࠴Ꮑ")) + YY8UDX3MJhb91AHw7fg(u"ࠬࠦิ่ำࠪሊ")
	UJqj5NE0ZKm += ZLwoRpfnCWI7FgEHsz6te39lMVh + LZWMikPEB81KSGyxfJtUsCA(u"࠭࠲࠯ࠢฯำฬࠦื้์็ࠤฬ๊ๅะ๋่้ࠣ฻แฮษอࠤฬ๊ๅโำฺ๋ࠥษๆ่ษ่ࠣฬࠦสห฼ํีࠥ๎ๅะฬ๊ࠤࠬላ") + str(IZVKS7o3q0/aXqWLoTdVgME(u"࠺࠵Ꮒ")/aXqWLoTdVgME(u"࠺࠵Ꮒ")/tQMjXKCA5dN4xq3beVIzaEoWkFLg(u"࠷࠺Ꮓ")) + qoBMmfAWpFlK70xw8ZRh4naJ(u"ࠧࠡ์๋้ࠬሌ")
	UJqj5NE0ZKm += ZLwoRpfnCWI7FgEHsz6te39lMVh + tQMjXKCA5dN4xq3beVIzaEoWkFLg(u"ࠨ࠵࠱ࠤ฼๎๊ๅࠢส่๊ี้ࠡๆ็ูๆำวหࠢส่ฯ๐ࠠ็ษาีฬࠦสห฼ํีࠥ๎ๅะฬ๊ࠤࠬል") + str(KOyPvpEztYLaZRdMQJWxfTNFHbkg/aXqWLoTdVgME(u"࠼࠰Ꮔ")/aXqWLoTdVgME(u"࠼࠰Ꮔ")/c2RKu0xG1eC8MiohyE(u"࠲࠵Ꮕ")) + rNdBKI74fAklnoCZ6(u"ࠩࠣ๎ํ๋ࠧሎ")
	UJqj5NE0ZKm += ZLwoRpfnCWI7FgEHsz6te39lMVh + rNdBKI74fAklnoCZ6(u"ࠪ࠸࠳ࠦๅห๊ึ฻ࠥอไๆั์ࠤ้๊ีโฯสฮࠥอไห์ࠣๆิࠦสห฼ํีࠥ๎ๅะฬ๊ࠤࠬሏ") + str(kUz8c7OqsxuPFIGfwg/aXqWLoTdVgME(u"࠷࠲Ꮖ")/aXqWLoTdVgME(u"࠷࠲Ꮖ")) + qqzwE6imYG4c2xojI(u"ูࠫࠥวฺหࠪሐ")
	UJqj5NE0ZKm += ZLwoRpfnCWI7FgEHsz6te39lMVh + kYDaz79TFlXoR(u"ࠬ࠻࠮ࠡไุ๎ึࠦวๅ็าํ๊ࠥไึใะหฯࠦวๅฬํࠤฯะฺ๋ำࠣำฬฬๅศ๋้ࠢิะ็ࠡࠩሑ") + str(rGY36xBwT1bLZAngSfcWEIeXdQVNij/rNdBKI74fAklnoCZ6(u"࠸࠳Ꮗ")/rNdBKI74fAklnoCZ6(u"࠸࠳Ꮗ")) + iNc3KxwErnQ(u"࠭ࠠิษ฼อࠬሒ")
	UJqj5NE0ZKm += ZLwoRpfnCWI7FgEHsz6te39lMVh + tR1krDGPpO025fghMT3a7UnYj(u"ࠧ࠷࠰ࠣะิอࠠใืํีࠥอไๆั์ࠤ้๊ีโฯสฮࠥอไห์ࠣฮฯเ๊าࠢๆฯ๏ืว๊่ࠡำฯํࠠࠨሓ") + str(K6imQHZDCI9pewE/LZWMikPEB81KSGyxfJtUsCA(u"࠹࠴Ꮘ")) + c2RKu0xG1eC8MiohyE(u"ࠨࠢาๆ๏่ษࠨሔ")
	UJqj5NE0ZKm += ZLwoRpfnCWI7FgEHsz6te39lMVh + dJHDqiKf12TXlIzSLkGUuxg4MBs3A(u"ࠩ࠺࠲ࠥฮฯ้่ࠣ็ฬฺࠠๅๆุๅาอสࠡษ็ฮ๏ࠦสห฼ํีࠥฮำา฻ฬࠤํ๋ฯห้ࠣࠫሕ") + str(dzcNuIbsgK3yZ6SXGaEHPfOj5vk) + DiJ8CMuYH1daWyjehfN0L(u"ࠪࠤิ่๊ใหࠪሖ")
	UJqj5NE0ZKm += DaFZHsThGmd0zv6e(u"ࠫࡡࡴ࡜࡯ࠩሗ") + ddiCzu6yahj5RtTISMJ48sNnZBU(u"๋ࠬหๅษ࠽ࠤฺ็อศฬࠣๆํอฦๆࠢส่ศ็ไศ็ࠣ์ฬ๊ๅิๆึ่ฬะ้ࠠษ็ั้่วหࠢ฼้ึํวࠡࠩመ") + str(kUz8c7OqsxuPFIGfwg/aXqWLoTdVgME(u"࠺࠵Ꮙ")/aXqWLoTdVgME(u"࠺࠵Ꮙ")) + DiJ8CMuYH1daWyjehfN0L(u"࠭ࠠิษ฼อࠥ࠴ࠠฤ็สࠤ็๎วว็ࠣว๋๎วฺࠢส่ๆ๐ฯ๋๊๊หฯࠦแฺ็ิ๋ฬࠦࠧሙ") + str(KOyPvpEztYLaZRdMQJWxfTNFHbkg/aXqWLoTdVgME(u"࠺࠵Ꮙ")/aXqWLoTdVgME(u"࠺࠵Ꮙ")/N3flV6EJsD5CzS(u"࠷࠺Ꮚ")) + CC1eY6yWZUwf2TkRvnp7EJ0AimjHBX(u"ࠧࠡลํห๊ࠦ࠮ࠡล่ห๋ࠥไโษอࠤฬ๊แ๋ัํ์ࠥ็ูๆำ๊หࠥ࠭ሚ") + str(rGY36xBwT1bLZAngSfcWEIeXdQVNij/aXqWLoTdVgME(u"࠺࠵Ꮙ")/aXqWLoTdVgME(u"࠺࠵Ꮙ")) + kYDaz79TFlXoR(u"ࠨࠢึห฾ฯࠠโไฺࠤ࠳ࠦรๆษࠣๅา฻ࠠาไ่ࠤฬ๊ลึัสีࠥ็ูๆำ๊ࠤࠬማ") + str(K6imQHZDCI9pewE/aXqWLoTdVgME(u"࠺࠵Ꮙ")) + tR1krDGPpO025fghMT3a7UnYj(u"ࠩࠣำ็๐โสࠢ࠱ࠤศ๋วࠡใะูࠥอิหำส็ࠥๆࡉࡑࡖ࡙ࠤๆ฿ๅา้ࠣࠫሜ") + str(dzcNuIbsgK3yZ6SXGaEHPfOj5vk) + dJHDqiKf12TXlIzSLkGUuxg4MBs3A(u"ࠪࠤิ่๊ใหࠪም")
	W2fBJaUN9kZwVeR1n0o4Dc(YY8UDX3MJhb91AHw7fg(u"ࠫࡷ࡯ࡧࡩࡶࠪሞ"),ddiCzu6yahj5RtTISMJ48sNnZBU(u"๋ࠬว้๋ࠡࠤฬ๊ใศึࠣห้๋ำหะา้ࠥ็๊ࠡษ็ฬึ์วๆฮࠪሟ"),UJqj5NE0ZKm,iNc3KxwErnQ(u"࠭ࡴࡦࡺࡷࡺ࡮࡫ࡷࡠࡤ࡬࡫࡫ࡵ࡮ࡵࠩሠ"))
	return
def bmBktdgisLPIU():
	w0CZ6B3WDJknhEsdRYyH1XAM = DaFZHsThGmd0zv6e(u"ࠧศๆไหฺ๊ษࠡฬ฼๊๏ࠦๅอๆาࠤอ์แิࠢสื๊ํࠠศๆฦู้๐้ࠠษ็๊็฽ษࠡฬ฼๊๏ࠦร็ࠢส่ฬูๅࠡษ็วฺ๊๊ࠡฬ่ࠤฯ฿ฯ๋ๆ๊ࠤํ็วึๆฬࠤํ์โุหࠣฮ฾์้ࠡ็ฯ่ิ่ࠦห็ࠣฮ฾ี๊ๅࠢสื๊ํ้ࠠสา์ู๋ࠦๅษ่อࠥะู็์้้ࠣ็ࠠษ่ไืࠥอำๆ้ࠣห้ษีๅ์ࠪሡ")
	iG7Rz2kmn0x1yLNMV3u8O(qpFY4hAwolV3,qpFY4hAwolV3,GLTtERWbHnFuy4PCp,w0CZ6B3WDJknhEsdRYyH1XAM)
	return
def lnP150XkcWAKLiITQxa9vsogd8q7():
	w0CZ6B3WDJknhEsdRYyH1XAM = mmV2nucZ5Lpl6FO1JMPEqGoQKW(u"ࠨวำหࠥ๎วอ้อ็๋ࠥิไๆฬࠤๆ๐ࠠศๆืฬ่ฯ้ࠠฬ่ࠤา๊็ศࠢ࠱࠲࠳ࠦร้ࠢส๊่ࠦสู่ࠣว๋ࠦวๅ็๋ๆ฾ࠦวๅลุ่๏ࠦใศ่ࠣๅ๏ํࠠๆึๆ่ฮࠦๅลไอ๋ࠥ๎สๆࠢะ่์อࠠ࠯࠰࠱ࠤๆหะ็ࠢฯีอࠦๅิฯࠣ็ฬฺࠠศๆหี๋อๅอࠢ็็๏๊ࠦใ๊่ࠤฬ๊ศา่ส้ัࠦศุๆหࠤฬ๊ีโฯฬࠤฬ๊ีฮ์ะอࠥ๎สฯิํ๊์อࠠษั็ห๋ࠥๆࠡษ็ูๆำษࠡษ็ๆิ๐ๅสࠩሢ")
	iG7Rz2kmn0x1yLNMV3u8O(qpFY4hAwolV3,qpFY4hAwolV3,GLTtERWbHnFuy4PCp,w0CZ6B3WDJknhEsdRYyH1XAM)
	return
def aFKMzijJQg():
	w0CZ6B3WDJknhEsdRYyH1XAM = UUDAiytEL76RTmMYsuIz5evXB(u"ࠩส่฿ืึࠡ็้ࠤูํวะหࠣห้ะิโ์ิࠤ์๎ࠠื็ส๊ࠥ฻อส๋ࠢืึ๐ษࠡษ็้฾๊่ๆษอࠤฬ๊ๅหสสำ้ฯࠠษ์้ࠤฬ๊ศา่ส้ั่ࠦศๆ่์็฿ࠠศๆุ่ๆื้้ࠠำหࠥอไื็ส๊ࠥเ๊า่ࠢ฻้๎ศ๊ࠡ็หࠥำวอห่ࠣ์ูࠦ็ัࠣห้อสึษ็ࠤฬ๎ࠠศๆิฬ฼ࠦๅฺ่ࠢ์ฬู่ࠡษ็ๅ๏ี๊้้สฮࠥอไๆึไีฮ࠭ሣ")
	iG7Rz2kmn0x1yLNMV3u8O(qpFY4hAwolV3,qpFY4hAwolV3,GLTtERWbHnFuy4PCp,w0CZ6B3WDJknhEsdRYyH1XAM)
	return
def vxWRLXUchyMlDzd1e8N3():
	iG7Rz2kmn0x1yLNMV3u8O(qpFY4hAwolV3,qpFY4hAwolV3,GLTtERWbHnFuy4PCp,DiJ8CMuYH1daWyjehfN0L(u"่่ࠪ๐๋ࠠ฻่่ࠥํะศࠢส่๋๎ูࠡ็้ࠤฬ๊แ๋ัํ์์อสࠡ࡞ࡱࠤ๏าศࠡฬไ฽๏๊ࠠฦุสๅฮࠦวิ็๊หࠥࡢ࡮ࠡ࡫ࡱࡴࡺࡺࡳࡵࡴࡨࡥࡲ࠴ࡡࡥࡣࡳࡸ࡮ࡼࡥࠨሤ"))
	qx7AQkCSGFfpTn(N3flV6EJsD5CzS(u"ࠫ࡮ࡴࡰࡶࡶࡶࡸࡷ࡫ࡡ࡮࠰ࡤࡨࡦࡶࡴࡪࡸࡨࠫሥ"),gBExoceumj4y8bFW9hY2aNMVSr)
	return
def b8r3Vmv4zSWq9w0sijZT():
	w0CZ6B3WDJknhEsdRYyH1XAM  = l1DZAt9XNQjqE7YOdrz(u"๋ࠬฤฯำสࠤ็อๅหࠢห฽฻ࠦิาๅสฮࠥอไฦ่อี๋ะࠠศๆา์้๐ࠠษู๊฽ࠥ฿ววไฺࠣิࠦวๅสิห๊าࠠๆอ็ࠤ่๎ฯ๋ࠢ็ฮุ๋อࠡใๅ฻๊ࠥศฺุุ้ࠣะฮะ็ํࠤฬ๊ๅหืไัࠥฮวๅัั์้ࠦไๆ๊สๆ฾ࠦวๅใํำ๏๎ࠧሦ")
	w0CZ6B3WDJknhEsdRYyH1XAM += mmV2nucZ5Lpl6FO1JMPEqGoQKW(u"้่࠭ࠠอ๎ัฯࠠๅ้ำหࠥอไฺษษๆࠥ็ว็้ࠣฮ็ื๊ษษࠣะ๊๐ูࠡ็ึฮำีๅ๋ࠢหี๋อๅอࠢๆ์ิ๐ࠠๅษࠣ๎ุะื๋฻๋๊ࠥอไะะ๋่๊ࠥฬๆ์฼ࠤ๊๎วใ฻ࠣห้ฮั็ษ่ะࠥำส๊่ࠢ฽ࠥอำหะาห๊࠭ሧ")
	w0CZ6B3WDJknhEsdRYyH1XAM += ZLwoRpfnCWI7FgEHsz6te39lMVh+xupTj02bvy3O8R+mmV2nucZ5Lpl6FO1JMPEqGoQKW(u"ࠧแ࡚ࠢࠣࡕࡔࠠࠡล๋ࠤࠥࡖࡲࡰࡺࡼࠤࠥษ่ࠡࠢࡇࡒࡘࠦࠠฤ๊ࠣว๏ࠦอๅࠢหื๏฽ࠠระิࠫረ")+fF4lt9zWYxXLKZVyAco82PgMj+ZLwoRpfnCWI7FgEHsz6te39lMVh
	w0CZ6B3WDJknhEsdRYyH1XAM += UUDAiytEL76RTmMYsuIz5evXB(u"ࠨ࡞ࡱ่ฬ์่ࠠาสࠤ้์๋ࠠฯ็ࠤฬ๊ๅีๅ็อࠥ๎ล็็สࠤๆ่ืࠡีํๆํ๋ࠠษวุ่ฬำࠠษ฻ูࠤฬ๊ๅ้ษๅ฽ࠥ๎ลฺษๅอ๋่ࠥศไ฼ࠤฬิั๊ࠢๆห๋ะࠠห฻ู่่ࠥวษไสࠤอี่็ุ่ࠢฬ้ไࠨሩ")
	W2fBJaUN9kZwVeR1n0o4Dc(iNc3KxwErnQ(u"ࠩࡵ࡭࡬࡮ࡴࠨሪ"),GLTtERWbHnFuy4PCp,w0CZ6B3WDJknhEsdRYyH1XAM,fWoVd0Bmtkx(u"ࠪࡸࡪࡾࡴࡷ࡫ࡨࡻࡤࡨࡩࡨࡨࡲࡲࡹ࠭ራ"))
	w0CZ6B3WDJknhEsdRYyH1XAM = tQMjXKCA5dN4xq3beVIzaEoWkFLg(u"ࠫฬ๊ๅ้ษๅ฽ࠥอไห์ࠣฮศััหࠢหห้฿ววไࠣ฽๋ีࠠษ฻ูࠤฬ๊ๆศี๋ࠣ๏ࡀࠧሬ")
	w0CZ6B3WDJknhEsdRYyH1XAM += ZLwoRpfnCWI7FgEHsz6te39lMVh+xupTj02bvy3O8R+ddiCzu6yahj5RtTISMJ48sNnZBU(u"ࠬࡧ࡫ࡰࡣࡰࠤࠥ࡫ࡧࡺࡤࡨࡷࡹࠦࠠࡦࡩࡼࡦࡪࡹࡴࡷ࡫ࡳࠤࠥࡳ࡯ࡷ࡫ࡽࡰࡦࡴࡤࠡࠢࡶࡩࡷ࡯ࡥࡴ࠶ࡺࡥࡹࡩࡨࠡࠢࡶ࡬ࡦ࡮ࡩࡥ࠶ࡸࠫር")+fF4lt9zWYxXLKZVyAco82PgMj
	w0CZ6B3WDJknhEsdRYyH1XAM += DiJ8CMuYH1daWyjehfN0L(u"࠭࡜࡯࡞ࡱࠫሮ")+kYDaz79TFlXoR(u"ࠧศๆา์้ࠦวๅฬํࠤฯษหาฬࠣฬฬู๊ศศๅࠤ฾์ฯࠡส฼ฺࠥอไ็ษึࠤ์๐࠺ࠨሯ")
	w0CZ6B3WDJknhEsdRYyH1XAM += ZLwoRpfnCWI7FgEHsz6te39lMVh+xupTj02bvy3O8R+YY8UDX3MJhb91AHw7fg(u"ࠨ็ุีࠥࠦวๅๅ๋๎ฯࠦࠠฤ็ํี่อࠠࠡๅ้ำฬࠦࠠโำ้ืฬࠦࠠศๆํ์๋อๆࠡࠢหี๏฽ว็์สࠤฬ๊ลๆษิหฯࠦรๅ็ส๊๏อࠠา๊ึ๎ฬࠦวๅ์สฬฬ์ࠠศๆึ฽ํี๊สࠢิ์๊อๆ๋ษ๋ࠣํ๊ๆะษࠪሰ")+fF4lt9zWYxXLKZVyAco82PgMj
	w0CZ6B3WDJknhEsdRYyH1XAM += aXqWLoTdVgME(u"ࠩ࡟ࡲࡡࡴࠧሱ")+DaFZHsThGmd0zv6e(u"ࠪห้๋ศา็ฯࠤําฯูࠡิ๎็ฯࠠๅฬฯหํุࠠศๆ฼หห่้ࠠๆๆ๊์อࠠหฯอหัࠦฬ่ัࠣ็อ๐ั๊ࠡส่๊ฮัๆฮࠣ๎฽์ࠠศๆุ่่๊ษࠡื฽๎ึฯ้ࠠๆสࠤฯูสฮไࠣห้ะูษࠢไษีอࠠๅัํ็๋ࠥิไๆฬࠤออไะะ๋่๊ࠥศฺุࠣห้๋่ศไ฼ࠤํษ๊ืษ่่ࠣ๐๋ࠠฬูัࠥำฬๆࠢสฺ่๊ใๅหࠣࠫሲ")
	w0CZ6B3WDJknhEsdRYyH1XAM += xupTj02bvy3O8R+Ie5s2cBtSfdHjzQ4rA9kYlo6D18(u"ࠫฬืำๅࠢิืฬ๊ษࠡ็วำอฯࠠฦๆ์ࠤฬ๊ๅษำ่ะࠥ๎วไฬหࠤๆ๐็ศࠢสื๊ࠦศๅัๆࠤํษำๆษฤࠤฬ๊ๅ้ษๅ฽ࠥอไห์่ࠣฬࠦสิฬฺ๎฾ࠦฯฯ๊็๋ฬ࠭ሳ")+fF4lt9zWYxXLKZVyAco82PgMj
	W2fBJaUN9kZwVeR1n0o4Dc(tR1krDGPpO025fghMT3a7UnYj(u"ࠬࡸࡩࡨࡪࡷࠫሴ"),GLTtERWbHnFuy4PCp,w0CZ6B3WDJknhEsdRYyH1XAM,fWoVd0Bmtkx(u"࠭ࡴࡦࡺࡷࡺ࡮࡫ࡷࡠࡤ࡬࡫࡫ࡵ࡮ࡵࠩስ"))
	return
def Ic0b7mGzQ4fDPLZvHAJnYr3tugs():
	iG7Rz2kmn0x1yLNMV3u8O(qpFY4hAwolV3,qpFY4hAwolV3,tQMjXKCA5dN4xq3beVIzaEoWkFLg(u"ࠧฬๆสฯࠥ฽ัใࠢ็่ฯ๎วึๆ้ࠣ฾ࠦวๅ็หี๊าࠧሶ"),lljaEqwTVtmKsQcOrbXxS5hgNH(u"ࠨลิื้ࠦัิษ็อࠥษ่ࠡ็ื็้ฯࠠๆ่ࠣๆฬฬๅสࠢิืฬฬไ้ࠡำหࠥอไษำ้ห๊า࡜࡯࡞ࡱวํࠦศศีอาิอๅࠡษ็ๅ๏ูศ้ๅࠣวิ์ว่࡞ࡱࠫሷ")+xupTj02bvy3O8R+CC1eY6yWZUwf2TkRvnp7EJ0AimjHBX(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡩࡥࡨ࡫ࡢࡰࡱ࡮࠲ࡨࡵ࡭࠰ࡣࡵࡥࡧ࡯ࡣࡷ࡫ࡧࡩࡴࡹ࠲࠱࠳࠻ࠫሸ")+fF4lt9zWYxXLKZVyAco82PgMj+lljaEqwTVtmKsQcOrbXxS5hgNH(u"ࠪࡠࡳࡢ࡮ฤ๊ࠣฬฬืำศๆࠣห๏๋๊ๅࠢส่๎ࠦระ่ส๋ࠥࠦ࡜࡯ࠢࠪሹ")+xupTj02bvy3O8R+DiJ8CMuYH1daWyjehfN0L(u"ࠫࡦࡸࡡࡣ࡫ࡦࡺ࡮ࡪࡥࡰࡵ࠵࠴࠶࠾ࡀࡨ࡯ࡤ࡭ࡱ࠴ࡣࡰ࡯ࠪሺ")+fF4lt9zWYxXLKZVyAco82PgMj)
	return
def zMDB03n1js(showDialogs=gBExoceumj4y8bFW9hY2aNMVSr):
	if not showDialogs: showDialogs = gBExoceumj4y8bFW9hY2aNMVSr
	IAW0sh6So3NpqM = WWrExJZS3Bj4anOAkpv7(dzcNuIbsgK3yZ6SXGaEHPfOj5vk,Ie5s2cBtSfdHjzQ4rA9kYlo6D18(u"ࠬࡍࡅࡕࠩሻ"),ddiCzu6yahj5RtTISMJ48sNnZBU(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡦࡺࡤࡱࡵࡲࡥ࠯ࡥࡲࡱࠬሼ"),qpFY4hAwolV3,qpFY4hAwolV3,ag8rjZo1Vz4IPdcOT,qpFY4hAwolV3,c2RKu0xG1eC8MiohyE(u"ࠧࡔࡇࡕ࡚ࡎࡉࡅࡔ࠯ࡋࡘ࡙ࡖࡓࡠࡖࡈࡗ࡙࠳࠱ࡴࡶࠪሽ"))
	if not IAW0sh6So3NpqM.succeeded:
		dek8wZj45CcVTWx3BLSDJf = ag8rjZo1Vz4IPdcOT
		GWALnz3yjFrg2av9BUE = iyEOYZTQV32LshS1(ag8rjZo1Vz4IPdcOT)
		LLvyStW429DEZKlA(j8gFJIMYPoBzcCvG9T,lTW9p1v7uPfOxB(Q8Q0IDc6PLZajJAdTntKUmSGXz)+DiJ8CMuYH1daWyjehfN0L(u"ࠨࠢࠣࠤࡍ࡚ࡔࡑࡕࠣࡊࡦ࡯࡬ࡦࡦࠣࠤࠥࡒࡡࡣࡧ࡯࠾ࡠ࠭ሾ")+GWALnz3yjFrg2av9BUE+zYvEaigKWjoq50pXBLDbGJkFc(u"ࠩࡠࠫሿ"))
		if showDialogs: iG7Rz2kmn0x1yLNMV3u8O(qpFY4hAwolV3,qpFY4hAwolV3,GLTtERWbHnFuy4PCp,V3VlkhgjEF4n1erPXHcC0NOsfwyAJ(u"ࠪๅา฻ࠠศๆสฮฺอไࠡษ็ู้็ัࠡ࠰࠱࠲๋ࠥิไๆฬࠤ࠳࠴࠮ࠡษ็หฯ฻วๅࠢสฺ่๊แาࠢࠫห้ืศุࠢสฺ่๊แา่ࠫࠣฬฺ๊ࠦ็็ࠤ฾์ฯไࠢ฼่๎ࠦใ้ัํࠤ࠳࠴࠮๊ࠡ฼๊ิ้ࠠไ๊า๎ࠥเ๊าࠢๅหิืฺࠠๆ์ࠤฬูสฯัส้ࠥอไๆ๊สๆ฾ࠦวๅ็ืๅึฯࠧቀ"))
	else:
		dek8wZj45CcVTWx3BLSDJf = gBExoceumj4y8bFW9hY2aNMVSr
		if showDialogs: iG7Rz2kmn0x1yLNMV3u8O(qpFY4hAwolV3,qpFY4hAwolV3,GLTtERWbHnFuy4PCp,LZWMikPEB81KSGyxfJtUsCA(u"ࠫั๐ฯࠡฮาหࠥ࠴࠮࠯ࠢส่ฬะีศๆࠣห้๋ิโำࠣࠬฬ๊ัษูࠣห้๋ิโำࠬࠤ๏฿ๅๅࠢ฼๊ิ้้ࠠษ็ฬึ์วๆฮࠣๆฬีัࠡ฻็ํࠥอำหะาห๊ࠦวๅ็๋ห็฿ࠠศๆุ่ๆืษࠨቁ"))
	if not dek8wZj45CcVTWx3BLSDJf and showDialogs: Bg4AU3fVk6CoFje()
	return dek8wZj45CcVTWx3BLSDJf
def Bg4AU3fVk6CoFje():
	iG7Rz2kmn0x1yLNMV3u8O(qpFY4hAwolV3,qpFY4hAwolV3,GLTtERWbHnFuy4PCp,fWoVd0Bmtkx(u"ࠬฮูืࠢส่๊๎วใ฻ࠣฮาะวอࠢิฬ฼ࠦๅีใิࠤํ่ฯࠡ์ๆ์๋ࠦฬ่ษี็ࠥเ๊าࠢๅหิืฺࠠๆ์ࠤฬ๊ัษูࠣห้๋ิโำࠣวํࠦ็็ษๆࠤฺ๊ใๅหࠣๅ๏ࠦิ่ษาอࠥอไหึไ๎ึࠦวๅะสูฮࠦศไ๊า๎ࠥ฿ๆะๅࠣ฽้๋วࠡษ้๋ࠥะๅࠡใะูࠥอไษำ้ห๊าฺࠠๆ์ࠤ่๎ฯ๋ࠢส่ส฻ฯศำสฮࠥࡢ࡮ࠡ࠳࠺࠲࠻ࠦࠠࠧࠢࠣ࠵࠽࠴࡛࠱࠯࠼ࡡࠥࠦࠦࠡࠢ࠴࠽࠳ࡡ࠰࠮࠵ࡠࠫቂ"))
	iZFceBlMC9JuHx1R5fKAYO8Eyrsnzj()
	return
def cSYpMx6W4HlAQK9(HY7yaJeI89xE56sbTjdBRZPDwQKFX=qpFY4hAwolV3):
	k2nju1XItgCWLobyG6 = gBExoceumj4y8bFW9hY2aNMVSr
	if DiJ8CMuYH1daWyjehfN0L(u"࠭࡟ࡑࡔࡒࡆࡑࡋࡍࡠࠩቃ") not in HY7yaJeI89xE56sbTjdBRZPDwQKFX:
		k2nju1XItgCWLobyG6 = ag8rjZo1Vz4IPdcOT
		r7MXibnK2fa6S31ctA = eVLmAIGFiwpr94UK6MRP5(tR1krDGPpO025fghMT3a7UnYj(u"ࠧࡤࡧࡱࡸࡪࡸࠧቄ"),ee86G9ladLHVbh5mikzCo(u"ࠨะิ์ั࠭ቅ"),UVa3fJw7k6KM(u"ࠩศีุอไࠡ็ื็้ฯࠧቆ"),CC1eY6yWZUwf2TkRvnp7EJ0AimjHBX(u"ࠪษึูวๅࠢิืฬ๊ษࠨቇ"),GLTtERWbHnFuy4PCp,CC1eY6yWZUwf2TkRvnp7EJ0AimjHBX(u"ࠫ์๊ࠠหำํำࠥษๆࠡฬิื้ࠦัิษ็อࠥหไ๊ࠢส่๊ฮัๆฮࠣ࠲࠳ࠦรๆࠢอี๏ีࠠฤ่ࠣฮึูไࠡ็ื็้ฯࠠๆ๊ฯ์ิฯࠠโ์ࠣห้ฮั็ษ่ะࠥลࠧቈ"))
		if r7MXibnK2fa6S31ctA in [-ddiCzu6yahj5RtTISMJ48sNnZBU(u"࠷Ꮛ"),DiJ8CMuYH1daWyjehfN0L(u"࠰Ꮜ")]: return
		elif r7MXibnK2fa6S31ctA==N3flV6EJsD5CzS(u"࠲Ꮝ"):
			k2nju1XItgCWLobyG6 = gBExoceumj4y8bFW9hY2aNMVSr
			HY7yaJeI89xE56sbTjdBRZPDwQKFX = qoBMmfAWpFlK70xw8ZRh4naJ(u"ࠬࡥࡐࡓࡑࡅࡐࡊࡓ࡟ࠨ቉")
	if k2nju1XItgCWLobyG6:
		if ee86G9ladLHVbh5mikzCo(u"࠭࡟ࡑࡔࡒࡆࡑࡋࡍࡠࡑࡏࡈࡤ࠭ቊ") not in HY7yaJeI89xE56sbTjdBRZPDwQKFX:
			o4oUxD3u18K59ghHIY = VVpbtSKYUGXrNMwAWFo9IOjZP(LZWMikPEB81KSGyxfJtUsCA(u"ࠧࡤࡧࡱࡸࡪࡸࠧቋ"),qpFY4hAwolV3,qpFY4hAwolV3,c2RKu0xG1eC8MiohyE(u"ࠨู๊฽ࠥอไๆึๆ่ฮࠦแ๋ࠢสุ่าไࠨቌ"),N3flV6EJsD5CzS(u"ࠩๅฬ้ࠦลาีส่ࠥอไิฮ็ࠤ฾๊๊ไࠢฦ๊ࠥะใาำࠣࠤ๋็ำࠡษ็ๅ฾๊ࠠศๆำ๎ࠥษูุษๆࠤฬ๊ๅีๅ็อࠥ࠴ࠠๅๅํࠤ๏ะๅࠡฬึะ๏๊่ࠠา๊ࠤฬ๊ๅีๅ็อࠥ็๊ࠡีฯ่ࠥอไฤะฺหฦ่ࠦศๆสืฯิฯศ็ࠣ࠲ࠥ๎ศะ๊้ࠤ์ึวࠡษ็ฮุา๊ๅࠢึ์ๆࠦสาี็ࠤ๊๊แࠡๆสࠤๆอฦะห้๋ࠣํࠠๅว้๋๊ࠥวࠡ์ะฮํ๐ฺࠠๆ์ࠤฬ๊ๅีๅ็อࠥอไห์ࠣฮึ๐ฯࠡษ้ฮࠥอไฦส็ห฿ูࠦ็้สࠤ࠳ࠦ็ๅࠢๅ้ฯࠦศหๅิหึࠦวๅ็ื็้ฯࠠภࠩቍ"))
			if o4oUxD3u18K59ghHIY!=DiJ8CMuYH1daWyjehfN0L(u"࠳Ꮞ"):
				iG7Rz2kmn0x1yLNMV3u8O(qpFY4hAwolV3,qpFY4hAwolV3,dJHDqiKf12TXlIzSLkGUuxg4MBs3A(u"ࠪฮ๊ࠦลๅ฼สลࠥอไฦำึห้࠭቎"),sjtU6GZQg5XC2pH4(u"้๊ࠫริใࠣฬิ๎ๆࠡฬึะ๏๊ࠠศๆุ่่๊ษࠡใํࠤุาไࠡษ็วำ฽วย๋ࠢห้อำหะาห๊ࠦแศ่ࠣห้๋ศา็ฯࠤ้อ๋ࠠีอ฻๏฿ࠠๆ฻ิๅฮࠦวๅ็ื็้ฯ้ࠠๆสࠤา๊็ศࠢ็ห๋ࠦวๅ็หี๊าࠠๅษࠣ๎฾๊ๅࠡษ็฾๏ฮࠧ቏"))
				return
	iG7Rz2kmn0x1yLNMV3u8O(qpFY4hAwolV3,qpFY4hAwolV3,GLTtERWbHnFuy4PCp,viRJWOC5jsYe84(u"ࠬ็๊ࠡษ็ุฬฺษࠡษ็ๆฬีๅสࠢะหํ๊ࠠฤ่ࠣฮ่ะศࠡำึห้ฯࠠฦๆ์ࠤฬ๊ๅษำ่ะࠥ๎วีำะࠤๆ๐็ศࠢสฺ่๊ใๅหࠣวํࠦวๅ็ฺ๋ํ฿้ࠠวำหࠥษัะฬࠣะํอศࠡ็้ࠤฬ๊ๅษำ่ะࠥ็ลั่ࠣว่ะศࠡ฻้์ฬ์ࠠษำํำ่ࠦรๅว็็ฯื่็์ࠣห้ห๊ๆ์็ࠤํะะไำࠣ์้อࠠห่ึํࠥษๆࠡษ็้อืๅอࠢ็หࠥ๐ูๅ็ࠣห้เ๊ษࠩቐ"))
	w0CZ6B3WDJknhEsdRYyH1XAM = jXgARlWMLVFUBnvmZwI2o5(header=dJHDqiKf12TXlIzSLkGUuxg4MBs3A(u"࠭ࡗࡳ࡫ࡷࡩࠥࡧࠠ࡮ࡧࡶࡷࡦ࡭ࡥࠡࠢࠣห่ะศࠡำึห้ฯࠧቑ"),source=Q8Q0IDc6PLZajJAdTntKUmSGXz)
	if not w0CZ6B3WDJknhEsdRYyH1XAM: return
	if k2nju1XItgCWLobyG6: type = tR1krDGPpO025fghMT3a7UnYj(u"ࠧࡑࡴࡲࡦࡱ࡫࡭ࠨቒ")
	else: type = c2RKu0xG1eC8MiohyE(u"ࠨࡏࡨࡷࡸࡧࡧࡦࠩቓ")
	zlQAfuT2Z7nKhGdXs = CCfRqS47rTDe9GyQ5za2JwxpIUV(type,w0CZ6B3WDJknhEsdRYyH1XAM,gBExoceumj4y8bFW9hY2aNMVSr,qpFY4hAwolV3,mmV2nucZ5Lpl6FO1JMPEqGoQKW(u"ࠩࡈࡑࡆࡏࡌ࠮ࡈࡕࡓࡒ࠳ࡕࡔࡇࡕࡗࠬቔ"),HY7yaJeI89xE56sbTjdBRZPDwQKFX)
	return
def PbEcuOtyd0lZ4Br8xWo1e2():
	HY7yaJeI89xE56sbTjdBRZPDwQKFX = tR1krDGPpO025fghMT3a7UnYj(u"๋ࠪีอࠠศๆหี๋อๅอࠢ็หࠥ๐่อั่ࠣ์ࠦร๋ࠢึ๎ึ็ัࠡ์ึฮ฻๐แࠡลํࠤ๊ำส้์สฮ࠳ࠦวๅสิ๊ฬ๋ฬࠡ์ึฮำีๅࠡำ๋หอ฽้ࠠฬู้๏์ࠠๅ็ะฮํ๐วห่ࠢีๆ๎ูสࠢ฼่๎ࠦำ๋ำไีฬะࠠฯษิะ๏ฯ࠮ࠡษ็ฬึ์วๆฮࠣ฾๏ืࠠๆีว์ู้ࠦ็ࠢฦ๎๋ࠥอห๊ํหฯࠦสๆࠢอั๊๐ไ่ษࠣ฽้๏ࠠิ์ิๅึอส๊่ࠡ์ฬู่ࠡะสีั๐ษࠡࠤ่์ฬูู่ࠡิๅࠥัวๅอࠥ࠲ࠥาๅ๋฻ࠣห้ษำๆษฤࠤํอไๆษิ็ฬะ้ࠠษ็ูํื้ࠠษ็ฺ้๋่าษอࠤ์๐ࠠฯษุอࠥฮวึฯสฬ์อ࠮ࠡษ็ฬึ์วๆฮ่ࠣฬ๊ࠦ็ฬ๊็ࠥำโ้ไࠣห้฽ศฺ๋ࠢห้์ิา๋ࠢๆฬ์่็ࠢส่ศ๊แ๋ห่้๋ࠣไไ์ฬࠤฬ๊ัใ็ํอࠥࡊࡍࡄࡃࠣษีอࠠไษ้ࠤ้ี๊ไࠢื็ํ๏ࠠฯษุอࠥฮวๅำ๋หอ฽้ࠠษ็ฮ฻อๅ๋่ࠣห้ิวาฮํอࠥ็วๅำฯหฦࠦวๅฬ๋หฺ๊ࠠๆ฻ࠣษิอัส๊ࠢิ์ࠦวๅีํีๆืวห๋ࠢห้๋่ศไ฼ࠤฬ๊ฮศำฯ๎ฮ࠴่ࠠาสࠤฬ๊ศา่ส้ัࠦ็้ࠢหฬุอืส่ࠢฮฺ็อࠡๆ่์ฬู่ࠡษ็์๏ฮࠧቕ")
	W2fBJaUN9kZwVeR1n0o4Dc(kYDaz79TFlXoR(u"ࠫࡷ࡯ࡧࡩࡶࠪቖ"),BRWqdruz2A0(u"ࠬำโ้ไࠣห้฽ศฺ๋ࠢห้์ิา๋ࠢๆฬ์่็ࠢส่ศ๊แ๋ห่้๋ࠣไไ์ฬࠤฬ๊ัใ็ํอࠬ቗"),HY7yaJeI89xE56sbTjdBRZPDwQKFX,viRJWOC5jsYe84(u"࠭ࡴࡦࡺࡷࡺ࡮࡫ࡷࡠࡤ࡬࡫࡫ࡵ࡮ࡵࠩቘ"))
	HY7yaJeI89xE56sbTjdBRZPDwQKFX = sjtU6GZQg5XC2pH4(u"ࠧࡕࡪ࡬ࡷࠥࡶࡲࡰࡩࡵࡥࡲࠦࡤࡰࡧࡶࠤࡳࡵࡴࠡࡪࡲࡷࡹࠦࡡ࡯ࡻࠣࡧࡴࡴࡴࡦࡰࡷࠤࡴࡴࠠࡢࡰࡼࠤࡸ࡫ࡲࡷࡧࡵ࠲ࠥࡏࡴࠡࡱࡱࡰࡾࠦࡵࡴࡧࡶࠤࡱ࡯࡮࡬ࡵࠣࡸࡴࠦࡥ࡮ࡤࡨࡨࡩ࡫ࡤࠡࡥࡲࡲࡹ࡫࡮ࡵࠢࡷ࡬ࡦࡺࠠࡸࡣࡶࠤࡺࡶ࡬ࡰࡣࡧࡩࡩࠦࡴࡰࠢࡳࡳࡵࡻ࡬ࡢࡴࠣࡳࡳࡲࡩ࡯ࡧࠣࡺ࡮ࡪࡥࡰࠢ࡫ࡳࡸࡺࡩ࡯ࡩࠣࡷ࡮ࡺࡥࡴ࠰ࠣࡅࡱࡲࠠࡵࡴࡤࡨࡪࡳࡡࡳ࡭ࡶ࠰ࠥࡼࡩࡥࡧࡲࡷ࠱ࠦࡴࡳࡣࡧࡩࠥࡴࡡ࡮ࡧࡶ࠰ࠥࡹࡥࡳࡸ࡬ࡧࡪࠦ࡭ࡢࡴ࡮ࡷ࠱ࠦࡣࡰࡲࡼࡶ࡮࡭ࡨࡵࡧࡧࠤࡼࡵࡲ࡬࠮ࠣࡰࡴ࡭࡯ࡴࠢࡵࡩ࡫࡫ࡲࡦࡰࡦࡩࡩࠦࡨࡦࡴࡨ࡭ࡳࠦࡢࡦ࡮ࡲࡲ࡬ࠦࡴࡰࠢࡷ࡬ࡪ࡯ࡲࠡࡴࡨࡷࡵ࡫ࡣࡵ࡫ࡹࡩࠥࡵࡷ࡯ࡧࡵࡷࠥ࠵ࠠࡤࡱࡰࡴࡦࡴࡩࡦࡵ࠱ࠤ࡙࡮ࡥࠡࡲࡵࡳ࡬ࡸࡡ࡮ࠢ࡬ࡷࠥࡴ࡯ࡵࠢࡵࡩࡸࡶ࡯࡯ࡵ࡬ࡦࡱ࡫ࠠࡧࡱࡵࠤࡼ࡮ࡡࡵࠢࡲࡸ࡭࡫ࡲࠡࡲࡨࡳࡵࡲࡥࠡࡷࡳࡰࡴࡧࡤࠡࡶࡲࠤ࠸ࡸࡤࠡࡲࡤࡶࡹࡿࠠࡴ࡫ࡷࡩࡸ࠴ࠠࡘࡧࠣࡹࡷ࡭ࡥࠡࡣ࡯ࡰࠥࡩ࡯ࡱࡻࡵ࡭࡬࡮ࡴࠡࡱࡺࡲࡪࡸࡳ࠭ࠢࡷࡳࠥࡸࡥࡤࡱࡪࡲ࡮ࢀࡥࠡࡶ࡫ࡥࡹࠦࡴࡩࡧࠣࡰ࡮ࡴ࡫ࡴࠢࡦࡳࡳࡺࡡࡪࡰࡨࡨࠥࡽࡩࡵࡪ࡬ࡲࠥࡺࡨࡪࡵࠣࡴࡷࡵࡧࡳࡣࡰࠤࡦࡸࡥࠡ࡮ࡲࡧࡦࡺࡥࡥࠢࡶࡳࡲ࡫ࡷࡩࡧࡵࡩࠥ࡫࡬ࡴࡧࠣࡳࡳࠦࡴࡩࡧࠣࡻࡪࡨࠠࡰࡴࠣࡺ࡮ࡪࡥࡰࠢࡨࡱࡧ࡫ࡤࡥࡧࡧࠤࡦࡸࡥࠡࡨࡵࡳࡲࠦ࡯ࡵࡪࡨࡶࠥࡼࡡࡳ࡫ࡲࡹࡸࠦࡳࡪࡶࡨࡷ࠳ࠦࡉࡧࠢࡼࡳࡺࠦࡨࡢࡸࡨࠤࡦࡴࡹࠡ࡮ࡨ࡫ࡦࡲࠠࡪࡵࡶࡹࡪࡹࠠࡱ࡮ࡨࡥࡸ࡫ࠠࡤࡱࡱࡸࡦࡩࡴࠡࡣࡳࡴࡷࡵࡰࡳ࡫ࡤࡸࡪࠦ࡭ࡦࡦ࡬ࡥࠥ࡬ࡩ࡭ࡧࠣࡳࡼࡴࡥࡳࡵࠣ࠳ࠥ࡮࡯ࡴࡶࡨࡶࡸ࠴ࠠࡕࡪ࡬ࡷࠥࡶࡲࡰࡩࡵࡥࡲࠦࡩࡴࠢࡶ࡭ࡲࡶ࡬ࡺࠢࡤࠤࡼ࡫ࡢࠡࡤࡵࡳࡼࡹࡥࡳ࠰ࠪ቙")
	W2fBJaUN9kZwVeR1n0o4Dc(LZWMikPEB81KSGyxfJtUsCA(u"ࠨ࡮ࡨࡪࡹ࠭ቚ"),IaBhDMJc17302LgSvyxd(u"ࠩࡇ࡭࡬࡯ࡴࡢ࡮ࠣࡑ࡮ࡲ࡬ࡦࡰࡱ࡭ࡺࡳࠠࡄࡱࡳࡽࡷ࡯ࡧࡩࡶࠣࡅࡨࡺࠠࠩࡆࡐࡇࡆ࠯ࠧቛ"),HY7yaJeI89xE56sbTjdBRZPDwQKFX,DiJ8CMuYH1daWyjehfN0L(u"ࠪࡸࡪࡾࡴࡷ࡫ࡨࡻࡤࡨࡩࡨࡨࡲࡲࡹ࠭ቜ"))
	return
def flrI4xKnmz2A():
	iG7Rz2kmn0x1yLNMV3u8O(qpFY4hAwolV3,qpFY4hAwolV3,GLTtERWbHnFuy4PCp,ee86G9ladLHVbh5mikzCo(u"ࠫฬ๊ศา่ส้ัࠦไศࠢํๅา฻ࠠี้สำฮࠦวๅฬืๅ๏ืฺ่ࠠาࠤฬ๊วหืส่ࠥฮวๅ็๋ห็฿ࠠศๆุ่ๆืษ๊ࠡ็๋ีอࠠโ์ࠣัฬ๊้ࠠฮ๋ำฺࠥ็ศัฬࠤ฿๐ัࠡืะ๎าฯࠠฤ๊้๋ࠣะ็๋หࠣห้฻ไศฯํอࠥษ่ࠡ็ี๎ๆฯࠠโษ้ࠤ์ึวࠡๆ้ࠤ๏๎โโࠢส่ึฮืࠡษ็ู้็ั๊ࠡ็๊ࠥ๐่ใใࠣ฽๊๊ࠠศๆหี๋อๅอࠩቝ"))
	aFKMzijJQg()
	return
def mHNfbl9MJXaQLPK6V4F():
	RR4CXiLvyl6r5 = {}
	VkelYOQJDq7I6,RSs8DOKPaxVFdAeI4w1,GP8aR7oKEXWij1 = AAEc2whI4s1G9PqxHaWVRSLCTztfD3(ag8rjZo1Vz4IPdcOT)
	JQ0OTpbAGY8khnwf,UJqj5NE0ZKm,kKBpAYVRmwnCJaQ,RzXMe3OaJQhIG5kBHVLiSs74rdD,C9IThP68n7ZV,IOfqUa5JC1GtiAXV4Y3L8pebx,RXBM9LVSdloYWq7vPEs3 = qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3
	JQ0OTpbAGY8khnwf = r1roOXYi7UQw9FLThzPEdD0ZlvAnRc.join(RSs8DOKPaxVFdAeI4w1)
	UJqj5NE0ZKm = r1roOXYi7UQw9FLThzPEdD0ZlvAnRc.join(GP8aR7oKEXWij1)
	bx3jTse48lZ0Lyo1,QSw4EotG8i6uhWVzOgYk2BZDqmUrpc,P7aKopEAw5tjyVULJbIc = VkelYOQJDq7I6
	for j7HgbsXoUDfzcSkmniPu9w6,SEmBRMGhrOAykanY,Dd6CzsItHvW5 in QSw4EotG8i6uhWVzOgYk2BZDqmUrpc:
		Dd6CzsItHvW5 = N8E37XwL6iQbmBY(Dd6CzsItHvW5)
		Dd6CzsItHvW5 = Dd6CzsItHvW5.strip(mIsDke0oK5x1zSiOWbF9thGcA).strip(UUDAiytEL76RTmMYsuIz5evXB(u"ࠬࠦ࠮ࠨ቞"))
		S9lZt5DJXuUxhV = j7HgbsXoUDfzcSkmniPu9w6.replace(DiJ8CMuYH1daWyjehfN0L(u"࠭ࡐ࡚ࡖࡋࡓࡓ࠭቟"),qqzwE6imYG4c2xojI(u"ࠧࡂࡒࡌࠫበ"))
		RzXMe3OaJQhIG5kBHVLiSs74rdD += ZLwoRpfnCWI7FgEHsz6te39lMVh+IQ2KCmObsTGuiRdEzt931a40jLg+S9lZt5DJXuUxhV+fWoVd0Bmtkx(u"ࠨ࠼ࠣࠫቡ")+fF4lt9zWYxXLKZVyAco82PgMj+Dd6CzsItHvW5+ZLwoRpfnCWI7FgEHsz6te39lMVh
		if SEmBRMGhrOAykanY.isdigit(): RR4CXiLvyl6r5[j7HgbsXoUDfzcSkmniPu9w6] = int(SEmBRMGhrOAykanY)
	pH9MfytD4W7iq6j5USONC,ttQHK2uSWlY59aAJn7ExdjD,fGPbHEB0hJUFN4vpsWD = list(zip(*QSw4EotG8i6uhWVzOgYk2BZDqmUrpc))
	for j7HgbsXoUDfzcSkmniPu9w6 in sorted(F19lhKQpNHsdr0ak7TOn):
		if j7HgbsXoUDfzcSkmniPu9w6 not in pH9MfytD4W7iq6j5USONC:
			RzXMe3OaJQhIG5kBHVLiSs74rdD += ZLwoRpfnCWI7FgEHsz6te39lMVh+IQ2KCmObsTGuiRdEzt931a40jLg+j7HgbsXoUDfzcSkmniPu9w6+tR1krDGPpO025fghMT3a7UnYj(u"ࠩ࠽ࠤࠬቢ")+fF4lt9zWYxXLKZVyAco82PgMj+l32dnTEOU1skGKqeBtI9hmo(u"่ࠪฬ๊้ࠦฮาࠫባ")+ZLwoRpfnCWI7FgEHsz6te39lMVh
			if j7HgbsXoUDfzcSkmniPu9w6 not in i4bFG3rKE6.non_videos_actions: kKBpAYVRmwnCJaQ += r1roOXYi7UQw9FLThzPEdD0ZlvAnRc+j7HgbsXoUDfzcSkmniPu9w6
	for Dd6CzsItHvW5,Ljv3VaAWEBGxrRzbQJYhN in bx3jTse48lZ0Lyo1:
		Dd6CzsItHvW5 = N8E37XwL6iQbmBY(Dd6CzsItHvW5)
		C9IThP68n7ZV += Dd6CzsItHvW5+UVa3fJw7k6KM(u"ࠫ࠿ࠦࠧቤ")+xupTj02bvy3O8R+str(Ljv3VaAWEBGxrRzbQJYhN)+fF4lt9zWYxXLKZVyAco82PgMj+bJGaEk9wcz
	JQ0OTpbAGY8khnwf = JQ0OTpbAGY8khnwf.strip(mIsDke0oK5x1zSiOWbF9thGcA)
	UJqj5NE0ZKm = UJqj5NE0ZKm.strip(mIsDke0oK5x1zSiOWbF9thGcA)
	kKBpAYVRmwnCJaQ = kKBpAYVRmwnCJaQ.strip(mIsDke0oK5x1zSiOWbF9thGcA)
	kaK8HtjnxWQSRpodIOLqXM = JQ0OTpbAGY8khnwf+RlOvin8YIGC2KZXJPk9m0acrMobUex(u"ࠬࠦࠠ࠯࠰ࠣࠤࠬብ")+UJqj5NE0ZKm
	udc5H1vQqxK8bln  = BRWqdruz2A0(u"࠭ๅ้ษๅ฽ࠥา๊ะหุࠣ฿๊ࠠศๆหี๋อๅอ่๊ࠢ์อࠠโ์า๎ํํวหࠢไ๎ࠥ࠹ࠠฤ์ส้ࠥอไๆษู๎ฮࠦࠨๆ่ࠣห้ษใฬำࠣษ้๏ࠠศๆฦๆ้࠯ࠧቦ")+ZLwoRpfnCWI7FgEHsz6te39lMVh+CC1eY6yWZUwf2TkRvnp7EJ0AimjHBX(u"้้ࠧำหู๋ࠥ็ษ๊ࠤสึวࠡๆา๎่ࠦๅีๅ็อࠥ็๊่็ࠣๅ์๐ࠠๆ่ࠣ฽๋ีใ๊ࠡ็๎ุะࠠๆ่ࠣห้ฮั็ษ่ะࠥ๎ไศ่๊ࠢࠥอไๆ๊ๅ฽ࠬቧ")+ZLwoRpfnCWI7FgEHsz6te39lMVh
	udc5H1vQqxK8bln += xupTj02bvy3O8R+kaK8HtjnxWQSRpodIOLqXM+fF4lt9zWYxXLKZVyAco82PgMj+tQMjXKCA5dN4xq3beVIzaEoWkFLg(u"ࠨ࡞ࡱࡠࡳ࠭ቨ")
	udc5H1vQqxK8bln += DaFZHsThGmd0zv6e(u"่ࠩ์ฬู่ࠡๆ่ࠤ๏ฺฺๅ่๊ࠢ์อࠠศๆหี๋อๅอࠢไ๎ิ๐่่ษอࠤๆ๐ࠠ࠴ࠢฦ๎ฬ๋ࠠศๆ่ห฻๐ษ่ࠡࠪีฯฮษࠡลหะิ๐ࠩࠨቩ")+ZLwoRpfnCWI7FgEHsz6te39lMVh+qoBMmfAWpFlK70xw8ZRh4naJ(u"ࠪ์์ึวࠡ็฼๊ฬํࠠศฯอ้ฬ๊้ࠠฮ๋ำ๋ࠥิไๆฬࠤ฾์ฯไࠢฦ์ࠥ็๊ࠡษ็้ํู่ࠡล๋ࠤๆ๐ࠠศๆหี๋อๅอࠩቪ")+ZLwoRpfnCWI7FgEHsz6te39lMVh
	kKBpAYVRmwnCJaQ = r1roOXYi7UQw9FLThzPEdD0ZlvAnRc.join(sorted(kKBpAYVRmwnCJaQ.split(r1roOXYi7UQw9FLThzPEdD0ZlvAnRc)))
	udc5H1vQqxK8bln += xupTj02bvy3O8R+kKBpAYVRmwnCJaQ+fF4lt9zWYxXLKZVyAco82PgMj
	xxt7oNyuqWmbe6cr,CEKjosMHr4Jlau0kz9OeInfBX,ydUg2C7JbwQhKrAWIR6tHeZvOXlTmD,vGtg1Dl5UryIR3PZm0 = RlOvin8YIGC2KZXJPk9m0acrMobUex(u"࠳Ꮟ"),RlOvin8YIGC2KZXJPk9m0acrMobUex(u"࠳Ꮟ"),RlOvin8YIGC2KZXJPk9m0acrMobUex(u"࠳Ꮟ"),RlOvin8YIGC2KZXJPk9m0acrMobUex(u"࠳Ꮟ")
	all = RR4CXiLvyl6r5[V3VlkhgjEF4n1erPXHcC0NOsfwyAJ(u"ࠫࡆࡒࡌࠨቫ")]
	if viRJWOC5jsYe84(u"ࠬࡖ࡙ࡕࡊࡒࡒࠬቬ") in list(RR4CXiLvyl6r5.keys()): xxt7oNyuqWmbe6cr = RR4CXiLvyl6r5[fWoVd0Bmtkx(u"࠭ࡐ࡚ࡖࡋࡓࡓ࠭ቭ")]
	if N3flV6EJsD5CzS(u"ࠧࡊࡐࡖࡘࡆࡒࡌࠨቮ") in list(RR4CXiLvyl6r5.keys()): CEKjosMHr4Jlau0kz9OeInfBX = RR4CXiLvyl6r5[UUDAiytEL76RTmMYsuIz5evXB(u"ࠨࡋࡑࡗ࡙ࡇࡌࡍࠩቯ")]
	if UVa3fJw7k6KM(u"ࠩࡐࡉ࡙ࡘࡏࡑࡑࡏࡍࡘ࠭ተ") in list(RR4CXiLvyl6r5.keys()): ydUg2C7JbwQhKrAWIR6tHeZvOXlTmD = RR4CXiLvyl6r5[iNc3KxwErnQ(u"ࠪࡑࡊ࡚ࡒࡐࡒࡒࡐࡎ࡙ࠧቱ")]
	if UUDAiytEL76RTmMYsuIz5evXB(u"ࠫࡗࡋࡐࡐࡕࠪቲ") in list(RR4CXiLvyl6r5.keys()): vGtg1Dl5UryIR3PZm0 = RR4CXiLvyl6r5[lljaEqwTVtmKsQcOrbXxS5hgNH(u"ࠬࡘࡅࡑࡑࡖࠫታ")]
	TNXf65EtOUhgpxDFJWG = all-xxt7oNyuqWmbe6cr-CEKjosMHr4Jlau0kz9OeInfBX-ydUg2C7JbwQhKrAWIR6tHeZvOXlTmD-vGtg1Dl5UryIR3PZm0
	oF67yxKdB8nY3TiH9gAMvlOhaPSws0,uo1xpqQR3z4hZAUP2OMB = P7aKopEAw5tjyVULJbIc[vvXoMLlg513]
	oF67yxKdB8nY3TiH9gAMvlOhaPSws0,RP1Tt0zJrl35XH = P7aKopEAw5tjyVULJbIc[mZi0S72jGoHpLO]
	deit7uXy8C0xLw9FNgUTb2YSG3n = uo1xpqQR3z4hZAUP2OMB-RP1Tt0zJrl35XH
	RXBM9LVSdloYWq7vPEs3 += IQ2KCmObsTGuiRdEzt931a40jLg+str(RP1Tt0zJrl35XH)+fF4lt9zWYxXLKZVyAco82PgMj+RlOvin8YIGC2KZXJPk9m0acrMobUex(u"࠭วๅ฻าำࠥอไฮไํๆ๏ࠦไๅลฯ๋ืฯࠠ࠻ࠢࠪቴ")
	RXBM9LVSdloYWq7vPEs3 += ZLwoRpfnCWI7FgEHsz6te39lMVh+IQ2KCmObsTGuiRdEzt931a40jLg+str(deit7uXy8C0xLw9FNgUTb2YSG3n)+fF4lt9zWYxXLKZVyAco82PgMj+Ie5s2cBtSfdHjzQ4rA9kYlo6D18(u"ࠧษษึฮำีวๆࠢࡳࡶࡴࡾࡹࠡล๋ࠤࡻࡶ࡮ࠡ࠼ࠣࠫት")
	RXBM9LVSdloYWq7vPEs3 += ZLwoRpfnCWI7FgEHsz6te39lMVh+IQ2KCmObsTGuiRdEzt931a40jLg+str(uo1xpqQR3z4hZAUP2OMB)+fF4lt9zWYxXLKZVyAco82PgMj+ddiCzu6yahj5RtTISMJ48sNnZBU(u"ࠨษ็฽ิีࠠศๆๆ่๏ࠦไอ็ํ฽ࠥอไฤฮ๊ึฮࠦ࠺ࠡࠩቶ")
	RXBM9LVSdloYWq7vPEs3 += ZLwoRpfnCWI7FgEHsz6te39lMVh+IQ2KCmObsTGuiRdEzt931a40jLg+str(len(P7aKopEAw5tjyVULJbIc[iNc3KxwErnQ(u"࠶Ꮠ"):]))+fF4lt9zWYxXLKZVyAco82PgMj+UVa3fJw7k6KM(u"ࠩ฼ำิࠦวๅั๋่ࠥอไห์ࠣๅ๏ํวࠡลฯ๋ืฯࠠ࠻ࠢ࡟ࡲࡡࡴࠧቷ")
	for F1KMGjNvHegbIJEs3fcOtwq,WRbn1LC2xPJMZft in P7aKopEAw5tjyVULJbIc[sjtU6GZQg5XC2pH4(u"࠷Ꮡ"):]:
		F1KMGjNvHegbIJEs3fcOtwq = N8E37XwL6iQbmBY(F1KMGjNvHegbIJEs3fcOtwq)
		F1KMGjNvHegbIJEs3fcOtwq = F1KMGjNvHegbIJEs3fcOtwq.strip(mIsDke0oK5x1zSiOWbF9thGcA).strip(qqzwE6imYG4c2xojI(u"ࠪࠤ࠳࠭ቸ"))
		RXBM9LVSdloYWq7vPEs3 += F1KMGjNvHegbIJEs3fcOtwq+qqzwE6imYG4c2xojI(u"ࠫ࠿ࠦࠧቹ")+xupTj02bvy3O8R+str(WRbn1LC2xPJMZft)+fF4lt9zWYxXLKZVyAco82PgMj+kYDaz79TFlXoR(u"ࠬࠦࠠࠡࠩቺ")
	IOfqUa5JC1GtiAXV4Y3L8pebx += IQ2KCmObsTGuiRdEzt931a40jLg+str(TNXf65EtOUhgpxDFJWG)+fF4lt9zWYxXLKZVyAco82PgMj+dJHDqiKf12TXlIzSLkGUuxg4MBs3A(u"࠭แ๋ัํ์์อสࠡษืฮ฿๊สࠡ࠼ࠣࠫቻ")
	IOfqUa5JC1GtiAXV4Y3L8pebx += ZLwoRpfnCWI7FgEHsz6te39lMVh+IQ2KCmObsTGuiRdEzt931a40jLg+str(xxt7oNyuqWmbe6cr)+fF4lt9zWYxXLKZVyAco82PgMj+iNc3KxwErnQ(u"ุࠧๆหหฯࠦำ๋ำไีࠥࡇࡐࡊࠢ࠽ࠤࠬቼ")
	IOfqUa5JC1GtiAXV4Y3L8pebx += ZLwoRpfnCWI7FgEHsz6te39lMVh+IQ2KCmObsTGuiRdEzt931a40jLg+str(vGtg1Dl5UryIR3PZm0)+fF4lt9zWYxXLKZVyAco82PgMj+qqzwE6imYG4c2xojI(u"ࠨู็ฬฬะࠠิ์ิๅึࠦวๅ็ึฮํีูࠡ࠼ࠣࠫች")
	IOfqUa5JC1GtiAXV4Y3L8pebx += ZLwoRpfnCWI7FgEHsz6te39lMVh+IQ2KCmObsTGuiRdEzt931a40jLg+str(CEKjosMHr4Jlau0kz9OeInfBX)+fF4lt9zWYxXLKZVyAco82PgMj+l32dnTEOU1skGKqeBtI9hmo(u"ࠩอฯอ๐สࠡฬฺฬ๏่ࠠไ๊า๎ࠥ฿ๅศัࠣ࠾ࠥ࠭ቾ")
	IOfqUa5JC1GtiAXV4Y3L8pebx += ZLwoRpfnCWI7FgEHsz6te39lMVh+IQ2KCmObsTGuiRdEzt931a40jLg+str(ydUg2C7JbwQhKrAWIR6tHeZvOXlTmD)+fF4lt9zWYxXLKZVyAco82PgMj+lljaEqwTVtmKsQcOrbXxS5hgNH(u"ࠪฮะฮ๊หࠢฯ่ิࠦๅหำ๋ฬํ๊ำࠡ฻่หิࠦ࠺ࠡࠩቿ")
	IOfqUa5JC1GtiAXV4Y3L8pebx += ZLwoRpfnCWI7FgEHsz6te39lMVh+IQ2KCmObsTGuiRdEzt931a40jLg+str(len(bx3jTse48lZ0Lyo1))+fF4lt9zWYxXLKZVyAco82PgMj+V3VlkhgjEF4n1erPXHcC0NOsfwyAJ(u"ࠫิ๎ไࠡึ฽่ฯࠦแ๋ัํ์์อสࠡ࠼ࠣࠫኀ")
	IOfqUa5JC1GtiAXV4Y3L8pebx += c2RKu0xG1eC8MiohyE(u"ࠬࡢ࡮࡝ࡰࠪኁ")+C9IThP68n7ZV
	W2fBJaUN9kZwVeR1n0o4Dc(IaBhDMJc17302LgSvyxd(u"࠭ࡣࡦࡰࡷࡩࡷ࠭ኂ"),UUDAiytEL76RTmMYsuIz5evXB(u"ฺࠧัาࠤฬ๊แ๋ัํ์์อสࠡษ็ฮ๏ࠦิ฻ๆ๊หࠥํะศࠢส่อืๆศ็ฯࠤๆ๐ࠠ࠴ࠢฦ๎ฬ๋ࠠศๆ่ห฻๐ษࠡใํࠤฬู๊ศๆ่ࠤ่๊็ࠨኃ"),IOfqUa5JC1GtiAXV4Y3L8pebx,YY8UDX3MJhb91AHw7fg(u"ࠨࡶࡨࡼࡹࡼࡩࡦࡹࡢࡦ࡮࡭ࡦࡰࡰࡷࠫኄ"))
	W2fBJaUN9kZwVeR1n0o4Dc(tR1krDGPpO025fghMT3a7UnYj(u"ࠩࡦࡩࡳࡺࡥࡳࠩኅ"),ddiCzu6yahj5RtTISMJ48sNnZBU(u"้ࠪํอโฺࠢสุฯเไหࠢไ๎ࠥ࠹ࠠฤ์ส้ࠥอไๆษู๎ฮࠦแ๋ࠢส่฾อไๆࠢๆ่์࠭ኆ"),udc5H1vQqxK8bln,rNdBKI74fAklnoCZ6(u"ࠫࡹ࡫ࡸࡵࡸ࡬ࡩࡼࡥࡢࡪࡩࡩࡳࡳࡺࠧኇ"))
	W2fBJaUN9kZwVeR1n0o4Dc(l32dnTEOU1skGKqeBtI9hmo(u"ࠬࡲࡥࡧࡶࠪኈ"),mmV2nucZ5Lpl6FO1JMPEqGoQKW(u"࠭รฺๆ์ࠤฬ๊ฯ้ๆࠣห้ะ๊ࠡษึฮำีๅหࠢส่อืๆศ็ฯࠤๆ๐ࠠ࠴ࠢฦ๎ฬ๋ࠠศๆ่ห฻๐ษࠨ኉"),RzXMe3OaJQhIG5kBHVLiSs74rdD,sjtU6GZQg5XC2pH4(u"ࠧࡵࡧࡻࡸࡻ࡯ࡥࡸࡡࡥ࡭࡬࡬࡯࡯ࡶࡢࡰࡴࡴࡧࠨኊ"))
	return
def KXPLw0x78Zh():
	w0CZ6B3WDJknhEsdRYyH1XAM = DiJ8CMuYH1daWyjehfN0L(u"ࠨ้ำหࠥอไษำ้ห๊า๋ࠠ฻่่ࠥอแืๆࠣฬฬูสฯัส้ࠥาไะࠢๆ์ิ๐ࠠࠩࡍࡲࡨ࡮ࠦࡓ࡬࡫ࡱ࠭ࠥอไั์ࠣหุ๋็࡝ࡰࠪኋ")+IQ2KCmObsTGuiRdEzt931a40jLg+rNdBKI74fAklnoCZ6(u"ࠩࡶ࡯࡮ࡴ࠮࡮ࡧࡷࡶࡴࡶ࡯࡭࡫ࡶࡉࡒࡇࡄࠨኌ")+fF4lt9zWYxXLKZVyAco82PgMj+Ie5s2cBtSfdHjzQ4rA9kYlo6D18(u"ࠪࡠࡳࡢ࡮࡝ࡰࠣ์๊๋ใ็ࠢอฯอ๐ส่ࠢหหุะฮะษ่ࠤู๊ส้ั฼ࠤ฾๋วะࠢࡈࡑࡆࡊࠠࡓࡧࡳࡳࡸ࡯ࡴࡰࡴࡼࠤศ๎ࠠหฯ่๎้ํࠠๆ่࡟ࡲࠬኍ")+IQ2KCmObsTGuiRdEzt931a40jLg+N3flV6EJsD5CzS(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡰࡵࡤࡪࡴࡨࡴࡴ࠴ࡵ࡬࠰ࡷࡳࠬ኎")+fF4lt9zWYxXLKZVyAco82PgMj+N3flV6EJsD5CzS(u"ࠬࡢ࡮࡝ࡰ࡟ࡲࠥํะ่ࠢส่ึูวๅหࠣ์฿๐ั่ษࠣ็ะ๐ัࠡ็๋ะํีษࠡใํࠤ็อฦๆหูࠣ๏อๆสࠢส่อืๆศ็ฯࠤํอไๆิํำࠥษ๊ืษ้ࠣํา่ะࠢไ๎่ࠥวว็ฬࠤ๊฿ไ้็สฮࠥอไษำ้ห๊าࠧ኏")
	W2fBJaUN9kZwVeR1n0o4Dc(UVa3fJw7k6KM(u"࠭ࡣࡦࡰࡷࡩࡷ࠭ነ"),GLTtERWbHnFuy4PCp,w0CZ6B3WDJknhEsdRYyH1XAM,iNc3KxwErnQ(u"ࠧࡵࡧࡻࡸࡻ࡯ࡥࡸࡡࡥ࡭࡬࡬࡯࡯ࡶࠪኑ"))
	return
def pNUteOHcV7bf62zAWBS0X9():
	w0CZ6B3WDJknhEsdRYyH1XAM = UUDAiytEL76RTmMYsuIz5evXB(u"ࠨษ็ีฬฮื๋่ࠣวิ์ว่ࠢไ๎์๋วࠡฬฺฬ๏่ࠠไ๊า๎ࠥ฿ๅศัࠣ์์๎ฺࠠสสีฮูࠦ็ࠢอฯอ๐สࠡๅส้้ࠦว้ฬ๋้ฬะ๊ไ์่ࠣอืๆศ็ฯࠤ่๎ฯ๋๋้ࠢ฾ํࠠศุสๅฮูࠦๆษาࠤ้๊แ๋ัํ์์อสࠡษ็฽ึฮ๊ส๋้ࠢ฾ํࠠศุสๅฮࠦฬๅั้ࠣฯื่ษ๊็ืࠥ฿ๅศัࠣ์๊฿็ࠡษูหๆฯࠠๆีอ์ิ฿ฺࠠ็สำࠥ๎แ๋้ࠣว๏฼วࠡฮ่๎฾ࠦวฺัสำฯࠦใ้ัํࠤฬ๊ๅุๆ๋ฬฮࠦไฺ็็ࠤอืๆศ็ฯࠤ฾๋วะ๋ࠢ็้ํวࠡฬอ้ࠥอ่ห๊่หฯ๐ใ๋ษࠣ์้อࠠหฯอหัࠦร๋้ࠢ์฾ࠦๅ็ࠢส่ำฮัสࠢไ๎้่ࠥะ์ࠣวํࠦวๅะหีฮࠦแ๋ࠢอฯอ๐สࠡลูหๆอสࠡๅ๋ำ๏࠭ኒ")+ZLwoRpfnCWI7FgEHsz6te39lMVh+xupTj02bvy3O8R+i4bFG3rKE6.SITESURLS[DaFZHsThGmd0zv6e(u"ࠩࡎࡓࡉࡏࡅࡎࡃࡇࡣࡆࡖࡐࠨና")][vvXoMLlg513]+fF4lt9zWYxXLKZVyAco82PgMj+Ie5s2cBtSfdHjzQ4rA9kYlo6D18(u"ࠪࠤࠥࠦࠠฤ๊ࠣࠤࠥࠦࠧኔ")+xupTj02bvy3O8R+i4bFG3rKE6.SITESURLS[ee86G9ladLHVbh5mikzCo(u"ࠫࡐࡕࡄࡊࡇࡐࡅࡉࡥࡁࡑࡒࠪን")][mZi0S72jGoHpLO]+fF4lt9zWYxXLKZVyAco82PgMj
	w0CZ6B3WDJknhEsdRYyH1XAM += viRJWOC5jsYe84(u"ࠬࡢ࡮࡝ࡰ࡟ࡲฬ๊ัศสฺࠤศีๆศ้๋ࠣํࠦวๅี๋ีุࠦวๅาํࠤ๏ำสศฮ๊ࠤ๊ี๊า่่ࠢๆอสࠡๅ๋ำ๏ࠦไหอห๎ฯࠦศา่ส้ัูࠦๆษาࠤออไุำํๆฮࠦวๅฬๅ่๏ี๊สࠢส่็ี๊ๆห࡟ࡲࠬኖ")+xupTj02bvy3O8R+i4bFG3rKE6.SITESURLS[fWoVd0Bmtkx(u"࠭ࡋࡐࡆࡌࡣࡘࡕࡕࡓࡅࡈࡗࠬኗ")][vvXoMLlg513]+fF4lt9zWYxXLKZVyAco82PgMj+ddiCzu6yahj5RtTISMJ48sNnZBU(u"ࠧࠡࠢࠣࠤศ๎ࠠࠡࠢࠣࠫኘ")+xupTj02bvy3O8R+i4bFG3rKE6.SITESURLS[IaBhDMJc17302LgSvyxd(u"ࠨࡍࡒࡈࡎࡥࡓࡐࡗࡕࡇࡊ࡙ࠧኙ")][mZi0S72jGoHpLO]+fF4lt9zWYxXLKZVyAco82PgMj
	w0CZ6B3WDJknhEsdRYyH1XAM += kYDaz79TFlXoR(u"ࠩ࡟ࡲࡡࡴ࡜࡯ฮ่๎฾ࠦๅๅใสฮࠥ฿ๅศั้ࠣํา่ะหࠣๅ๏ࠦวๅ็๋ๆ฾ࠦระ่ส๋ࠬኚ")+ZLwoRpfnCWI7FgEHsz6te39lMVh+xupTj02bvy3O8R+i4bFG3rKE6.SITESURLS[IaBhDMJc17302LgSvyxd(u"ࠪࡊࡎࡒࡅࡔࡡࡖࡓ࡚ࡘࡃࡆࡕࠪኛ")][vvXoMLlg513]+fF4lt9zWYxXLKZVyAco82PgMj
	W2fBJaUN9kZwVeR1n0o4Dc(c2RKu0xG1eC8MiohyE(u"ࠫࡨ࡫࡮ࡵࡧࡵࠫኜ"),dJHDqiKf12TXlIzSLkGUuxg4MBs3A(u"ࠬอไๆ๊สๆ฾ࠦวๅำึ้๏ฯࠠๅสิ๊ฬ๋ฬࠡ฻่หิࠦไๅใํำ๏๎็ศฬࠣห้฿ัษ์ฬࠫኝ"),w0CZ6B3WDJknhEsdRYyH1XAM,mmV2nucZ5Lpl6FO1JMPEqGoQKW(u"࠭ࡴࡦࡺࡷࡺ࡮࡫ࡷࡠࡤ࡬࡫࡫ࡵ࡮ࡵࠩኞ"))
	return
def uehoD6sjLUfM(Kjci73hCZV2qX1):
	Rqvw05BorCgcye7VE32Sf.executebuiltin(ddiCzu6yahj5RtTISMJ48sNnZBU(u"ࠧࡂࡦࡧࡳࡳ࠴ࡏࡱࡧࡱࡗࡪࡺࡴࡪࡰࡪࡷ࠭࠭ኟ")+Kjci73hCZV2qX1+c2RKu0xG1eC8MiohyE(u"ࠨࠫࠪአ"), gBExoceumj4y8bFW9hY2aNMVSr)
	return
def IBWlOKRwz0nAU8gZ5STQk():
	s4PBNzhy8l(zYvEaigKWjoq50pXBLDbGJkFc(u"ࠩࡶࡸࡴࡶࠧኡ"))
	Rqvw05BorCgcye7VE32Sf.executebuiltin(IaBhDMJc17302LgSvyxd(u"ࠥࡅࡨࡺࡩࡷࡣࡷࡩ࡜࡯࡮ࡥࡱࡺࠬࡎࡴࡴࡦࡴࡩࡥࡨ࡫ࡓࡦࡶࡷ࡭ࡳ࡭ࡳࠪࠤኢ"))
	return
def lc4vWLszopQHmU():
	Rqvw05BorCgcye7VE32Sf.executebuiltin(V3VlkhgjEF4n1erPXHcC0NOsfwyAJ(u"ࠫࡆࡪࡤࡰࡰ࠱ࡓࡵ࡫࡮ࡔࡧࡷࡸ࡮ࡴࡧࡴࠪ࡬ࡲࡵࡻࡴࡴࡶࡵࡩࡦࡳ࠮ࡢࡦࡤࡴࡹ࡯ࡶࡦࠫࠪኣ"), gBExoceumj4y8bFW9hY2aNMVSr)
	return
def mlP2s9hy51FBtMYKUcTdjqr():
	iG7Rz2kmn0x1yLNMV3u8O(qpFY4hAwolV3,qpFY4hAwolV3,GLTtERWbHnFuy4PCp,l1DZAt9XNQjqE7YOdrz(u"๊ࠬๅิฯ้ࠣาะ่๋ษอࠤ็อฦๆหࠣ࠲ࠥอะ่สࠣษ้๏ࠠศๆๅหห๋ษࠡษ็ฮ๏ࠦสา์าࠤู๊อ่ษࠣ์้อࠠหัั่ࠥหไ๋้สࠤํ๊ใ็ࠢหหุะฮะษ่ࠤࠧอไๆษ๋ืࠧࠦร้ࠢࠥห้ื๊ๆ๊อࠦࠥอึ฻ูࠣ฽้๏ࠠศๆีีࠥา็สࠢส่๏๋๊็ࠢฦ์ࠥอำหะา้ࠥࠨวๅๅํฬํืฯ๋ࠣࠢห฻เืࠡ฻็ํࠥำัโࠢࠥࡇࠧࠦร้ࠢ฼่๎ࠦวื฼ฺࠤ฾๊้ࠡิิࠤࠧอไใษษ้ฮࠨࠠศๆำ๎ࠥ็๊ࠡฮ๊อࠥอไ๋็ํ๊ࠬኤ"))
	return
def rlKjUZWTwuRg5teHsChQaLokzXf7JS():
	iG7Rz2kmn0x1yLNMV3u8O(qpFY4hAwolV3,qpFY4hAwolV3,GLTtERWbHnFuy4PCp,ee86G9ladLHVbh5mikzCo(u"࠭ไๅฬ฼ห๊๊ࠠๆ฻ࠣห้๋แืๆฬࠤ࠳ࠦวั้หࠤส๊้ࠡษ็ีฬฮืࠡษ็ิ๏ࠦสา์าࠤส฼วโฬ๊ࠤศ๎ࠠๆีะ๋๋ࠥๆࠡࠢๅหห๋ษࠡษ็้ๆ฼ไส๋่่ࠢ์ࠠๅษࠣฮ๋่ัࠡ฻็๎์่ࠦๅษࠣฮูเไ่ࠢ࠱ࠤํฮวิฬัำฬ๋ࠠࠣษ็้ฬ๎ำࠣࠢฦ์ࠥࠨวๅำํ้ํะࠢࠡษู฾฼ูࠦๅ๋ࠣหุ้ัࠡฮ๊อࠥอไ๋็ํ๊ࠥ࠴้ࠠล่หࠥฮวิฬัำฬ๋ࠠࠣษ็็๏ฮ่าัࠥࠤๆอึ฻ูࠣ฽้๏ࠠฮำไࠤࠧࡉࠢࠡล๋ࠤ฾๊้ࠡิิࠤࠧอไใษษ้ฮࠨࠠศๆำ๎ࠥ็๊ࠡฮ๊อࠥอไ๋็ํ๊ࠥ࠴้่ࠠไืࠥอไไๆส้ࠥ๎วๅูิ๎็ฯฺ่ࠠาࠤฬ๊สฺษู่่๋ࠥࠡ็ะฮํ๐วหࠢๅ์ฬฬๅࠡษ็้ๆ฼ไสࠩእ"))
	return
def fqMxDmSFLEen9yrCaBNKkIOG84TAg(J3uNKy879Mh=fWoVd0Bmtkx(u"ࠧࡴ࡭࡬ࡲ࠳ࡳࡥࡵࡴࡲࡴࡴࡲࡩࡴࡇࡐࡅࡉ࠭ኦ"),showDialogs=gBExoceumj4y8bFW9hY2aNMVSr):
	aAxiq8p26lNG = Rqvw05BorCgcye7VE32Sf.executeJSONRPC(iNc3KxwErnQ(u"ࠨࡽࠥ࡮ࡸࡵ࡮ࡳࡲࡦࠦ࠿ࠨ࠲࠯࠲ࠥ࠰ࠧࡳࡥࡵࡪࡲࡨࠧࡀࠢࡔࡧࡷࡸ࡮ࡴࡧࡴ࠰ࡊࡩࡹ࡙ࡥࡵࡶ࡬ࡲ࡬࡜ࡡ࡭ࡷࡨࠦ࠱ࠨࡩࡥࠤ࠽࠵࠱ࠨࡰࡢࡴࡤࡱࡸࠨ࠺ࡼࠤࡶࡩࡹࡺࡩ࡯ࡩࠥ࠾ࠧࡲ࡯ࡰ࡭ࡤࡲࡩ࡬ࡥࡦ࡮࠱ࡷࡰ࡯࡮ࠣࡿࢀࠫኧ"))
	data = A3AFYmgZLXn4MBab.loads(aAxiq8p26lNG)
	X72XKGEmS3AuHRYeOaDBLVtJjv = data[UUDAiytEL76RTmMYsuIz5evXB(u"ࠩࡵࡩࡸࡻ࡬ࡵࠩከ")][DiJ8CMuYH1daWyjehfN0L(u"ࠪࡺࡦࡲࡵࡦࠩኩ")]
	if NJwViHDTMdmO0xnALqQ9voPalC3Ip: X72XKGEmS3AuHRYeOaDBLVtJjv = X72XKGEmS3AuHRYeOaDBLVtJjv.encode(nV3Tip6XsH1rJw79DPOU)
	if showDialogs:
		o4oUxD3u18K59ghHIY = VVpbtSKYUGXrNMwAWFo9IOjZP(qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,GLTtERWbHnFuy4PCp,rNdBKI74fAklnoCZ6(u"ࠫ์๊ࠠหำํำࠥะฺ๋์ิࠤั๊ฯࠡࠩኪ")+X72XKGEmS3AuHRYeOaDBLVtJjv+dJHDqiKf12TXlIzSLkGUuxg4MBs3A(u"ࠬࠦวๅาํࠤู๊สฯั่ࠤฬ๊ย็ࠢไ๎้่ࠥะ์ࠣษ้๏ࠠศๆศูิอัࠡษ็วำ๐ัࠡๆฯ่ิࠦࠧካ")+J3uNKy879Mh+qqzwE6imYG4c2xojI(u"࠭ࠠภࠣࠪኬ"))
		if o4oUxD3u18K59ghHIY!=UUDAiytEL76RTmMYsuIz5evXB(u"࠷Ꮢ"): return ag8rjZo1Vz4IPdcOT
	zlQAfuT2Z7nKhGdXs,wcQG7RlEUBVWdMFk,TczCeVBQ7KfGXo3SAmksg4x8 = uJPyVz9Im0(J3uNKy879Mh,ag8rjZo1Vz4IPdcOT,ag8rjZo1Vz4IPdcOT)
	if zlQAfuT2Z7nKhGdXs:
		if showDialogs: iG7Rz2kmn0x1yLNMV3u8O(qpFY4hAwolV3,qpFY4hAwolV3,GLTtERWbHnFuy4PCp,UVa3fJw7k6KM(u"ࠧห็อࠤ฾๋ไ๋หࠣฮะฮ๊หࠢส่ั๊ฯࠡษ็ะิ๐ฯ๊๊ࠡ์ࠥาว่ิ่้ࠣอำหะาห๊ࠦ࠮ࠡี๋ๅࠥ๐สๆࠢส่ว์ࠠห฼ํ๎ึࠦลฺัสำฬะࠠไ๊า๎๊ࠥใ๋ࠢํืฯ฿ๅๅࠢส่ั๊ฯࠡษ็ะิ๐ฯࠡสา่ฬࠦๅ็ࠢส่็ี๊ๆࠩክ"))
		l0bSC83stEymKhqY5WicIvLP67 = Rqvw05BorCgcye7VE32Sf.executeJSONRPC(Ie5s2cBtSfdHjzQ4rA9kYlo6D18(u"ࠨࡽࠥ࡮ࡸࡵ࡮ࡳࡲࡦࠦ࠿ࠨ࠲࠯࠲ࠥ࠰ࠧࡳࡥࡵࡪࡲࡨࠧࡀࠢࡔࡧࡷࡸ࡮ࡴࡧࡴ࠰ࡖࡩࡹ࡙ࡥࡵࡶ࡬ࡲ࡬࡜ࡡ࡭ࡷࡨࠦ࠱ࠨࡩࡥࠤ࠽࠵࠱ࠨࡰࡢࡴࡤࡱࡸࠨ࠺ࡼࠤࡶࡩࡹࡺࡩ࡯ࡩࠥ࠾ࠧࡲ࡯ࡰ࡭ࡤࡲࡩ࡬ࡥࡦ࡮࠱ࡷࡰ࡯࡮ࠣ࠮ࠥࡺࡦࡲࡵࡦࠤ࠽ࠦࠬኮ")+J3uNKy879Mh+ddiCzu6yahj5RtTISMJ48sNnZBU(u"ࠩࠥࢁࢂ࠭ኯ"))
		zlQAfuT2Z7nKhGdXs = gBExoceumj4y8bFW9hY2aNMVSr if ee86G9ladLHVbh5mikzCo(u"ࠪࡓࡐ࠭ኰ") in l0bSC83stEymKhqY5WicIvLP67 else ag8rjZo1Vz4IPdcOT
		s7FnXZYOgexlH2MPb8BJck1AKv9.sleep(c2RKu0xG1eC8MiohyE(u"࠱Ꮣ"))
		Rqvw05BorCgcye7VE32Sf.executebuiltin(l1DZAt9XNQjqE7YOdrz(u"ࠫࡘ࡫࡮ࡥࡅ࡯࡭ࡨࡱࠨ࠲࠳ࠬࠫ኱"))
	elif showDialogs: iG7Rz2kmn0x1yLNMV3u8O(qpFY4hAwolV3,qpFY4hAwolV3,GLTtERWbHnFuy4PCp,V3VlkhgjEF4n1erPXHcC0NOsfwyAJ(u"๊ࠬไฤีไࠤๆฺไหࠢ฼้้๐ษࠡฬฮฬ๏ะ้ࠠฬไ฽๏๊ࠠศๆฯ่ิࠦวๅ็ฺ่ํฮࠧኲ"))
	return zlQAfuT2Z7nKhGdXs
def iZFceBlMC9JuHx1R5fKAYO8Eyrsnzj():
	url = IaBhDMJc17302LgSvyxd(u"࠭ࡨࡵࡶࡳ࠾࠴࠵࡭ࡪࡴࡵࡳࡷࡹ࠮࡬ࡱࡧ࡭࠳ࡺࡶ࠰ࡴࡨࡰࡪࡧࡳࡦࡵ࠲ࡻ࡮ࡴࡤࡰࡹࡶ࠳ࡼ࡯࡮࠷࠶࠲ࠫኳ")
	IAW0sh6So3NpqM = WWrExJZS3Bj4anOAkpv7(kUz8c7OqsxuPFIGfwg,UVa3fJw7k6KM(u"ࠧࡈࡇࡗࠫኴ"),url,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,ee86G9ladLHVbh5mikzCo(u"ࠨࡕࡈࡖ࡛ࡏࡃࡆࡕ࠰ࡗࡍࡕࡗࡠࡎࡄࡘࡊ࡙ࡔࡠࡍࡒࡈࡎࡥࡖࡆࡔࡖࡍࡔࡔ࠭࠲ࡵࡷࠫኵ"))
	cmWl9dOKHPIy41iaXuxrY = IAW0sh6So3NpqM.content
	MXRSgVpiKFtTJknLlHvdwAG1cb = ePhmG1jLD6.findall(tR1krDGPpO025fghMT3a7UnYj(u"ࠩࡷ࡭ࡹࡲࡥ࠾ࠤ࡮ࡳࡩ࡯࠭ࠩ࡞ࡧ࠯ࡡ࠴࡜ࡥ࠭࠰࡟ࡦ࠳ࡺࡂ࠯࡝ࡡ࠰࠯࠭ࠨ኶"),cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	MXRSgVpiKFtTJknLlHvdwAG1cb = MXRSgVpiKFtTJknLlHvdwAG1cb[vvXoMLlg513].split(ee86G9ladLHVbh5mikzCo(u"ࠪ࠱ࠬ኷"))[vvXoMLlg513]
	hhFdft4nuEOZHSyQzqPw6l = str(oyFvr0T96AwpqEIgxmP)
	RzXMe3OaJQhIG5kBHVLiSs74rdD = tQMjXKCA5dN4xq3beVIzaEoWkFLg(u"ࠫࡠࡘࡔࡍ࡟ศูิอัࠡๅ๋ำ๏ࠦวๅลั๎ึࠦวๅ็อ์ๆืࠠศๆล๊ࠥํ่ࠡ࠼ࠣࠤࠥ࠭ኸ")+IQ2KCmObsTGuiRdEzt931a40jLg+MXRSgVpiKFtTJknLlHvdwAG1cb+fF4lt9zWYxXLKZVyAco82PgMj
	RzXMe3OaJQhIG5kBHVLiSs74rdD += ee86G9ladLHVbh5mikzCo(u"ࠬࡢ࡮࡝ࡰࠪኹ")+sjtU6GZQg5XC2pH4(u"࡛࠭ࡓࡖࡏࡡส฻ฯศำࠣ็ํี๊ࠡษ็ิ๏ࠦว็ฬࠣฮุะฮะ็๊ࠤ์๎ࠠ࠻ࠢࠣࠤࠬኺ")+IQ2KCmObsTGuiRdEzt931a40jLg+hhFdft4nuEOZHSyQzqPw6l+fF4lt9zWYxXLKZVyAco82PgMj
	iG7Rz2kmn0x1yLNMV3u8O(qpFY4hAwolV3,qpFY4hAwolV3,GLTtERWbHnFuy4PCp,RzXMe3OaJQhIG5kBHVLiSs74rdD)
	return
def XL2k6KGdvhAlMNoa3u0eHrqmjOy():
	pO8VeqZokYFrbjfx0IiQEuW4PUgtH,ZMbikH6LaqXGUw8gn2cvFT,iIE7Oenyw8fWcrGoCmQFNAb2 = ag8rjZo1Vz4IPdcOT,qpFY4hAwolV3,qpFY4hAwolV3
	VVbJWyli4fPzmsMG57qC0HSFprk6cQ,WnzUM0je6FiP7KDlp28NcB,RapmDEs4KyuUOT3L7ivFdQq5 = ag8rjZo1Vz4IPdcOT,qpFY4hAwolV3,qpFY4hAwolV3
	RbU35LjaHTM2Gy7YkwA0 = [Ie5s2cBtSfdHjzQ4rA9kYlo6D18(u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡡࡳࡣࡥ࡭ࡨࡼࡩࡥࡧࡲࡷࠬኻ"),l1DZAt9XNQjqE7YOdrz(u"ࠨࡴࡨࡴࡴࡹࡩࡵࡱࡵࡽ࠳࡫࡭ࡢࡦࠪኼ"),rNdBKI74fAklnoCZ6(u"ࠩࡶ࡯࡮ࡴ࠮࡮ࡧࡷࡶࡴࡶ࡯࡭࡫ࡶࡉࡒࡇࡄࠨኽ")]
	jNmfig0xKqC3MFIrQt6 = yJOhc6G7ier1Fj2pzA(RbU35LjaHTM2Gy7YkwA0)
	for xqJBEohLpFs in RbU35LjaHTM2Gy7YkwA0:
		if xqJBEohLpFs not in list(jNmfig0xKqC3MFIrQt6.keys()): continue
		UQoBYWuIxVM7894F6SsXn1ZfvAjG,C4jGlOfiq6w,vjc0VWYzlITUufJ9X,ddGithIMzBpkfPx67,d7tOFAycUTp,JcCvFaqhzAPr9yxielEKZRopwkU,diRE2cprJLWKwY0Bku8xS7CaVh6DI = jNmfig0xKqC3MFIrQt6[xqJBEohLpFs]
		if xqJBEohLpFs==RlOvin8YIGC2KZXJPk9m0acrMobUex(u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡤࡶࡦࡨࡩࡤࡸ࡬ࡨࡪࡵࡳࠨኾ"):
			VVbJWyli4fPzmsMG57qC0HSFprk6cQ = UQoBYWuIxVM7894F6SsXn1ZfvAjG
			WnzUM0je6FiP7KDlp28NcB = C4jGlOfiq6w+tQMjXKCA5dN4xq3beVIzaEoWkFLg(u"ࠫࠥࠦࠠࠡࠪࠣࠫ኿")+nqTpa5zm20MfRNsVSIuG7A3biHZ6Fw(JcCvFaqhzAPr9yxielEKZRopwkU)+zYvEaigKWjoq50pXBLDbGJkFc(u"ࠬࠦࠩࠨዀ")
			RapmDEs4KyuUOT3L7ivFdQq5 = ddGithIMzBpkfPx67
		elif xqJBEohLpFs==LZWMikPEB81KSGyxfJtUsCA(u"࠭ࡲࡦࡲࡲࡷ࡮ࡺ࡯ࡳࡻ࠱ࡩࡲࡧࡤࠨ዁"):
			pO8VeqZokYFrbjfx0IiQEuW4PUgtH = pO8VeqZokYFrbjfx0IiQEuW4PUgtH or UQoBYWuIxVM7894F6SsXn1ZfvAjG
			ZMbikH6LaqXGUw8gn2cvFT += UVa3fJw7k6KM(u"ࠧࠡࠢ࠯ࠤࠥ࠭ዂ")+C4jGlOfiq6w+mmV2nucZ5Lpl6FO1JMPEqGoQKW(u"ࠨࠢࠣࠤࠥ࠮ࠠࠨዃ")+nqTpa5zm20MfRNsVSIuG7A3biHZ6Fw(JcCvFaqhzAPr9yxielEKZRopwkU)+zYvEaigKWjoq50pXBLDbGJkFc(u"ࠩࠣ࠭ࠬዄ")
			iIE7Oenyw8fWcrGoCmQFNAb2 += lljaEqwTVtmKsQcOrbXxS5hgNH(u"ࠪࠤࠥ࠲ࠠࠡࠩዅ")+ddGithIMzBpkfPx67
		elif xqJBEohLpFs==tR1krDGPpO025fghMT3a7UnYj(u"ࠫࡸࡱࡩ࡯࠰ࡰࡩࡹࡸ࡯ࡱࡱ࡯࡭ࡸࡋࡍࡂࡆࠪ዆"):
			zdWcGyIuq7NRhTZi = UQoBYWuIxVM7894F6SsXn1ZfvAjG
			PF7WtcmaQHvgK8bIyZ5hDOSolARuns = C4jGlOfiq6w+qoBMmfAWpFlK70xw8ZRh4naJ(u"ࠬࠦࠠࠡࠢࠫࠤࠬ዇")+nqTpa5zm20MfRNsVSIuG7A3biHZ6Fw(JcCvFaqhzAPr9yxielEKZRopwkU)+V3VlkhgjEF4n1erPXHcC0NOsfwyAJ(u"࠭ࠠࠪࠩወ")
			MKI3CLO5BwTc6d40lWY2m8QRGEk = ddGithIMzBpkfPx67
	ZMbikH6LaqXGUw8gn2cvFT = ZMbikH6LaqXGUw8gn2cvFT.strip(l32dnTEOU1skGKqeBtI9hmo(u"ࠧࠡࠢ࠯ࠤࠥ࠭ዉ"))
	iIE7Oenyw8fWcrGoCmQFNAb2 = iIE7Oenyw8fWcrGoCmQFNAb2.strip(tR1krDGPpO025fghMT3a7UnYj(u"ࠨࠢࠣ࠰ࠥࠦࠧዊ"))
	owkcGMKPsR24z790  = DiJ8CMuYH1daWyjehfN0L(u"ࠩ࡞ࡖ࡙ࡒ࡝ศๆศูิอัࠡษ็วำ๐ัࠡๆหี๋อๅอࠢ฼้ฬีࠠศๆ่ฮํ็ัࠡษ็ฦ๋ࠦ็้ࠢ࠽ࠤࠥࠦࠧዋ")+IQ2KCmObsTGuiRdEzt931a40jLg+RapmDEs4KyuUOT3L7ivFdQq5+fF4lt9zWYxXLKZVyAco82PgMj
	owkcGMKPsR24z790 += ZLwoRpfnCWI7FgEHsz6te39lMVh+c2RKu0xG1eC8MiohyE(u"ࠪ࡟ࡗ࡚ࡌ࡞ษ็ษฺีวาࠢส่ี๐ࠠศ่อࠤฯูสฯั่๋๊ࠥศา่ส้ัูࠦๆษาࠤ์๎ࠠ࠻ࠢࠣࠤࠬዌ")+IQ2KCmObsTGuiRdEzt931a40jLg+WnzUM0je6FiP7KDlp28NcB+fF4lt9zWYxXLKZVyAco82PgMj
	owkcGMKPsR24z790 += Ie5s2cBtSfdHjzQ4rA9kYlo6D18(u"ࠫࡡࡴ࡜࡯ࠩው")+DaFZHsThGmd0zv6e(u"ࠬࡡࡒࡕࡎࡠห้หีะษิࠤฬ๊รฯ์ิࠤ้๋ำห๊า฽ࠥ฿ๅศัࠣห้๋ส้ใิࠤฬ๊ย็๊ࠢ์ࠥࡀࠠࠡࠢࠪዎ")+IQ2KCmObsTGuiRdEzt931a40jLg+iIE7Oenyw8fWcrGoCmQFNAb2+fF4lt9zWYxXLKZVyAco82PgMj
	owkcGMKPsR24z790 += ZLwoRpfnCWI7FgEHsz6te39lMVh+c2RKu0xG1eC8MiohyE(u"࡛࠭ࡓࡖࡏࡡฬ๊ลึัสีࠥอไั์ࠣห๋ะࠠหีอาิ๋็ࠡๆ่ืฯ๎ฯฺࠢ฼้ฬี่๊ࠠࠣ࠾ࠥࠦࠠࠨዏ")+IQ2KCmObsTGuiRdEzt931a40jLg+ZMbikH6LaqXGUw8gn2cvFT+fF4lt9zWYxXLKZVyAco82PgMj
	owkcGMKPsR24z790 += CC1eY6yWZUwf2TkRvnp7EJ0AimjHBX(u"ࠧ࡝ࡰ࡟ࡲࠬዐ")+DiJ8CMuYH1daWyjehfN0L(u"ࠨ࡝ࡕࡘࡑࡣวๅวุำฬืࠠศๆฦา๏ืࠠๅฮ็ำ๋ࠥสา๊ห์ฺู้ࠠ็สำࠥอไๆฬ๋ๅึࠦวๅฤ้ࠤ์๎ࠠ࠻ࠢࠣࠤࠬዑ")+IQ2KCmObsTGuiRdEzt931a40jLg+MKI3CLO5BwTc6d40lWY2m8QRGEk+fF4lt9zWYxXLKZVyAco82PgMj
	owkcGMKPsR24z790 += ZLwoRpfnCWI7FgEHsz6te39lMVh+l1DZAt9XNQjqE7YOdrz(u"ࠩ࡞ࡖ࡙ࡒ࡝ศๆศูิอัࠡษ็ิ๏ࠦว็ฬࠣฮุะฮะ็๊ࠤ้าไะ่ࠢฮึ๎ศ้ๆึࠤ฾๋วะ๊ࠢ์ࠥࡀࠠࠡࠢࠪዒ")+IQ2KCmObsTGuiRdEzt931a40jLg+PF7WtcmaQHvgK8bIyZ5hDOSolARuns+fF4lt9zWYxXLKZVyAco82PgMj
	UQoBYWuIxVM7894F6SsXn1ZfvAjG = VVbJWyli4fPzmsMG57qC0HSFprk6cQ or pO8VeqZokYFrbjfx0IiQEuW4PUgtH
	if UQoBYWuIxVM7894F6SsXn1ZfvAjG:
		header = l1DZAt9XNQjqE7YOdrz(u"ࠪห้ืฬศรࠣฮาี๊ฬࠢศฺฬ็วหࠢๆ์ิ๐ࠠๅฯ็ࠤฬ๊ๅีษๆ่ࠬዓ")
		TRw3lZxuU0hiKtJa = qqzwE6imYG4c2xojI(u"ࠫฬ์สࠡสะหัฯࠠๅฬะำ๏ัࠠษำ้ห๊าฺࠠ็สำࠥษ่ࠡฬะำ๏ัࠠๆีอ์ิ฿ฺࠠ็สำࠬዔ")
	else:
		header = qoBMmfAWpFlK70xw8ZRh4naJ(u"ࠬำวๅ์สࠤ้อ๋๊ࠠฯำࠥะอะ์ฮหฯࠦไษำ้ห๊าฺࠠ็สำࠥษ่ࠡ็ึฮํีูࠡ฻่หิ࠭ዕ")
		TRw3lZxuU0hiKtJa = RlOvin8YIGC2KZXJPk9m0acrMobUex(u"࠭วๅำฯหฦࠦลษๆส฾ࠥอไๆสิ้ัูࠦ็ࠢสฺ่๊ใๅหࠣห้ะ๊ࠡฬ๋หัํใࠨዖ")
	AiDhS4QCJKxgU = qoBMmfAWpFlK70xw8ZRh4naJ(u"ࠧๅๅํࠤ๏฿ๅๅࠢ฼๊ิ้ࠠศๆอัิ๐หࠡษ็ฮ้่วว์ࠣ๎ัฮࠠฤ่ࠣ๎่๎ๆࠡๆา๎่ࠦแ๋ࠢๆ์ิ๐࡜࡯็ึฮํีูࠡ฻่หิࠦࡅࡎࡃࡇࠤࡗ࡫ࡰࡰࡵ࡬ࡸࡴࡸࡹࠨ዗")
	wcgKBRM9eIjpSbCPhN = owkcGMKPsR24z790+c2RKu0xG1eC8MiohyE(u"ࠨ࡞ࡱࡠࡳ࠭ዘ")+TRw3lZxuU0hiKtJa+dJHDqiKf12TXlIzSLkGUuxg4MBs3A(u"ࠩ࡟ࡲࡡࡴࠧዙ")+AiDhS4QCJKxgU
	W2fBJaUN9kZwVeR1n0o4Dc(Ie5s2cBtSfdHjzQ4rA9kYlo6D18(u"ࠪࡶ࡮࡭ࡨࡵࠩዚ"),header,wcgKBRM9eIjpSbCPhN,DiJ8CMuYH1daWyjehfN0L(u"ࠫࡹ࡫ࡸࡵࡸ࡬ࡩࡼࡥࡢࡪࡩࡩࡳࡳࡺࠧዛ"))
	return UQoBYWuIxVM7894F6SsXn1ZfvAjG
def WxjKhqVD7XNnTisJIr4Ya8Mwt5(xqJBEohLpFs,diRE2cprJLWKwY0Bku8xS7CaVh6DI,showDialogs):
	zlQAfuT2Z7nKhGdXs = ag8rjZo1Vz4IPdcOT
	if showDialogs:
		o4oUxD3u18K59ghHIY = VVpbtSKYUGXrNMwAWFo9IOjZP(qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,GLTtERWbHnFuy4PCp,qoBMmfAWpFlK70xw8ZRh4naJ(u"ู่ࠬโࠢํฮ๊ࠦวๅฤ้ࠤั๊ศࠡษ็้้็ࠠศๆฺ่฿๎ืࠡๆ็ษ฻อแสࠢส่๊฽ไ้สฬࠤ้้๊ࠡ์อ้ࠥะหษ์อ๋ࠥ฿ไ๊ࠢๆ์ิ๐ࠠ࠯ࠢส่๊๊แࠡไาࠤ๏้่็ࠢๆฬ๏ื้ࠠไาࠤ๏ำสศฮࠣฬ฾฼ࠠศๆ๋ๆฯࠦ࠮้ࠡ็ࠤฯื๊ะࠢอั๊๐ไࠡษ็้้็ࠠศๆล๊ࠥลࠡࠨዜ"))
		if o4oUxD3u18K59ghHIY!=mZi0S72jGoHpLO: return ag8rjZo1Vz4IPdcOT
	oOS7uVmcqM6XCyJE0ps = OPCnG7Q8agh4wcdeZ(diRE2cprJLWKwY0Bku8xS7CaVh6DI,{},showDialogs)
	if oOS7uVmcqM6XCyJE0ps:
		pG6lJ8Y3aARDyq9QwoKBNFEhIc = RPbaxsNFVTwek5Kfv21DiJuzCnjMZp.path.join(ABbonyRm60ptY7ErO4UD19SXu,xqJBEohLpFs)
		EOJmze1pUvdCgVPLRt3(pG6lJ8Y3aARDyq9QwoKBNFEhIc,gBExoceumj4y8bFW9hY2aNMVSr,ag8rjZo1Vz4IPdcOT)
		import zipfile as iYSnLfzoN7xUDvVeh8yAsaqMH6w,io as cne5YRvOoGMAZ0JgiuW7a2
		m5yDUtSsjQCWT9il3MwBo8xNpReZ = cne5YRvOoGMAZ0JgiuW7a2.BytesIO(oOS7uVmcqM6XCyJE0ps)
		try:
			ewFWDLYQJgnVCspyhkUdPuO = iYSnLfzoN7xUDvVeh8yAsaqMH6w.ZipFile(m5yDUtSsjQCWT9il3MwBo8xNpReZ)
			ewFWDLYQJgnVCspyhkUdPuO.extractall(ABbonyRm60ptY7ErO4UD19SXu)
			s7FnXZYOgexlH2MPb8BJck1AKv9.sleep(mZi0S72jGoHpLO)
			Rqvw05BorCgcye7VE32Sf.executebuiltin(DaFZHsThGmd0zv6e(u"࠭ࡕࡱࡦࡤࡸࡪࡒ࡯ࡤࡣ࡯ࡅࡩࡪ࡯࡯ࡵࠪዝ"))
			s7FnXZYOgexlH2MPb8BJck1AKv9.sleep(mZi0S72jGoHpLO)
			zlQAfuT2Z7nKhGdXs = onj4dWsP2O8eqZriy(xqJBEohLpFs)
		except: zlQAfuT2Z7nKhGdXs = ag8rjZo1Vz4IPdcOT
	if showDialogs:
		if zlQAfuT2Z7nKhGdXs: iG7Rz2kmn0x1yLNMV3u8O(qpFY4hAwolV3,qpFY4hAwolV3,GLTtERWbHnFuy4PCp,qoBMmfAWpFlK70xw8ZRh4naJ(u"ࠧห็ࠣฬ๋าวฮࠢอฯอ๐สࠡษ็ษ฻อแสࠢส่๊฽ไ้สฬࠫዞ"))
		else: iG7Rz2kmn0x1yLNMV3u8O(qpFY4hAwolV3,qpFY4hAwolV3,GLTtERWbHnFuy4PCp,YY8UDX3MJhb91AHw7fg(u"ࠨๆ็วุ็ࠠโึ็ฮࠥ฿ๅๅ์ฬࠤฯัศ๋ฬࠣห้หึศใฬࠤฬ๊ๅุๆ๋ฬฮ࠭ዟ"))
	return zlQAfuT2Z7nKhGdXs
def qx7AQkCSGFfpTn(xqJBEohLpFs,showDialogs=gBExoceumj4y8bFW9hY2aNMVSr):
	if showDialogs==qpFY4hAwolV3: showDialogs = gBExoceumj4y8bFW9hY2aNMVSr
	w2bZR5AvG4ycgEz1BUfSNLiHxn9 = fitmbL0nNUGKqpgV2([xqJBEohLpFs])
	JsQLOy631x,g978XsaeAohL = w2bZR5AvG4ycgEz1BUfSNLiHxn9[xqJBEohLpFs]
	if g978XsaeAohL:
		zlQAfuT2Z7nKhGdXs = gBExoceumj4y8bFW9hY2aNMVSr
		if showDialogs: iG7Rz2kmn0x1yLNMV3u8O(qpFY4hAwolV3,qpFY4hAwolV3,GLTtERWbHnFuy4PCp,qoBMmfAWpFlK70xw8ZRh4naJ(u"ࠩไัฺࠦวๅวูหๆฯࠠ࡝ࡰࠣࠫዠ")+xqJBEohLpFs+l1DZAt9XNQjqE7YOdrz(u"ࠪࠤࡡࡴ่ࠠา๊ࠤศ๊ลืษไอࠥ฿ๆะๅ้ࠣํา่ะหࠣ์๊็ูๅหࠣ์ัอ็ำห่้ࠣอำหะาห๊࠭ዡ"))
	else:
		zlQAfuT2Z7nKhGdXs = ag8rjZo1Vz4IPdcOT
		o4oUxD3u18K59ghHIY = VVpbtSKYUGXrNMwAWFo9IOjZP(iNc3KxwErnQ(u"ࠫࡨ࡫࡮ࡵࡧࡵࠫዢ"),qpFY4hAwolV3,qpFY4hAwolV3,GLTtERWbHnFuy4PCp,qpFY4hAwolV3+xqJBEohLpFs+kYDaz79TFlXoR(u"ࠬࠦ࡜࡯࡞ࡱࠤ์ึ็ࠡล็ษ฻อแสࠢ฼๊ิ้ࠠ฻์ิࠤ๊็ูๅหࠣวํฺ๋ࠦำ้ࠣํา่ะหࠣ์ฬ๊ศา่ส้ัࠦศฮษฯอ๊ࠥ็ศࠢ࠱ࠤ์๊ࠠหำํำࠥะหษ์อࠤํะแฺ์็ࠤ์ึ็ࠡษ็ษ฻อแสࠢส่ว์ࠠภࠩዣ"))
		if o4oUxD3u18K59ghHIY==iNc3KxwErnQ(u"࠲Ꮤ"):
			Rqvw05BorCgcye7VE32Sf.executebuiltin(UVa3fJw7k6KM(u"࠭ࡉ࡯ࡵࡷࡥࡱࡲࡁࡥࡦࡲࡲ࠭࠭ዤ")+xqJBEohLpFs+V3VlkhgjEF4n1erPXHcC0NOsfwyAJ(u"ࠧࠪࠩዥ"))
			s7FnXZYOgexlH2MPb8BJck1AKv9.sleep(lljaEqwTVtmKsQcOrbXxS5hgNH(u"࠳Ꮥ"))
			Rqvw05BorCgcye7VE32Sf.executebuiltin(tR1krDGPpO025fghMT3a7UnYj(u"ࠨࡕࡨࡲࡩࡉ࡬ࡪࡥ࡮ࠬ࠶࠷ࠩࠨዦ"))
			s7FnXZYOgexlH2MPb8BJck1AKv9.sleep(mmV2nucZ5Lpl6FO1JMPEqGoQKW(u"࠴Ꮦ"))
			while Rqvw05BorCgcye7VE32Sf.getCondVisibility(dJHDqiKf12TXlIzSLkGUuxg4MBs3A(u"࡚ࠩ࡭ࡳࡪ࡯ࡸ࠰ࡌࡷࡆࡩࡴࡪࡸࡨࠬࡵࡸ࡯ࡨࡴࡨࡷࡸࡪࡩࡢ࡮ࡲ࡫࠮࠭ዧ")): s7FnXZYOgexlH2MPb8BJck1AKv9.sleep(tR1krDGPpO025fghMT3a7UnYj(u"࠵Ꮧ"))
			zlQAfuT2Z7nKhGdXs = onj4dWsP2O8eqZriy(xqJBEohLpFs)
			if showDialogs and zlQAfuT2Z7nKhGdXs: iG7Rz2kmn0x1yLNMV3u8O(qpFY4hAwolV3,qpFY4hAwolV3,GLTtERWbHnFuy4PCp,iNc3KxwErnQ(u"ࠪฮ๊ࠦแฮืࠣห้หึศใฬࠤฬ๊ๅุๆ๋ฬฮ่่ࠦ์ࠣห้ศๆࠡฮส๋ืฯࠠๅๆสืฯิฯศ็ࠪየ"))
			elif showDialogs: iG7Rz2kmn0x1yLNMV3u8O(qpFY4hAwolV3,qpFY4hAwolV3,GLTtERWbHnFuy4PCp,aXqWLoTdVgME(u"ࠫๆฺไࠡใํࠤฯัศ๋ฬࠣวํࠦสโ฻ํ่ࠥษ่ࠡฬะำ๏ัࠠศๆศฺฬ็ษࠡษ็้฼๊่ษหࠣ࠲ࠥ๎วๅฯ็ࠤ์๎ࠠหอห๎ฯํว๊ࠡอๅ฾๐ไ่ษ้๋ࠣࠦฮศำฯࠤฬ๊ศา่ส้ั࠭ዩ"))
	return zlQAfuT2Z7nKhGdXs
def vuBjEdkpnKx(showDialogs):
	if not showDialogs: o4oUxD3u18K59ghHIY = gBExoceumj4y8bFW9hY2aNMVSr
	else: o4oUxD3u18K59ghHIY = VVpbtSKYUGXrNMwAWFo9IOjZP(DaFZHsThGmd0zv6e(u"ࠬࡩࡥ࡯ࡶࡨࡶࠬዪ"),qpFY4hAwolV3,qpFY4hAwolV3,GLTtERWbHnFuy4PCp,N3flV6EJsD5CzS(u"࠭ศา่ส้ัࠦใ้ัํࠤ๏่่ๆࠢห฽๊๊๊สࠢอัิ๐หࠡฮ่๎฾ࠦวๅวูหๆอสࠡฬ็ๆฬฬ๊ศࠢๆ่ࠥ࠸࠴ࠡีส฽ฮ่ࠦๅๅ้ࠤ๊๋ใ็ࠢศะึอม่ษࠣห้ศๆࠡ࠰๋้ࠣࠦสา์าࠤฬ๊ย็ࠢฦ๊ࠥะืๅส้๋ࠣࠦใ้ัํࠤๆำี๊ࠡอัิ๐หࠡฮ่๎฾ࠦวๅวูหๆอสࠡมࠪያ"))
	if o4oUxD3u18K59ghHIY==l32dnTEOU1skGKqeBtI9hmo(u"࠶Ꮨ"):
		Rqvw05BorCgcye7VE32Sf.executebuiltin(tQMjXKCA5dN4xq3beVIzaEoWkFLg(u"ࠧࡖࡲࡧࡥࡹ࡫ࡁࡥࡦࡲࡲࡗ࡫ࡰࡰࡵࠪዬ"))
		if showDialogs:
			iG7Rz2kmn0x1yLNMV3u8O(qpFY4hAwolV3,qpFY4hAwolV3,GLTtERWbHnFuy4PCp,IaBhDMJc17302LgSvyxd(u"ࠨฬ่ࠤสืำศๆࠣ฻้ฮࠠฦๆ์ࠤอืๆศ็ฯࠤ่๎ฯ๋ࠢส่ี๐ࠠโ์ࠣะ์อาไࠢ็็๏๊ࠦใ๊่ࠤอะอะ์ฮࠤัฺ๋๊ࠢศฺฬ็วหࠢๆ์ิ๐ࠠ࠯ࠢห้ฬࠦแ๋้สࠤฯำฯ๋อ๋ࠣีอࠠศๆหี๋อๅอ๋ࠢฮาี๊ฬ่ࠢืฯ๎ฯฺࠢ฼้ฬีࠠ࠯ࠢํีั๏ࠠฦ฻ฺหฦࠦใ้ัํࠤ࠺ࠦฯใษษๆࠥษ่ࠡลๆฯึࠦไไ์ࠣ๎๋ํ๊ࠡ฻่่๏ฯࠠศๆอัิ๐หࠨይ"))
	return
def jZn8dWH7bUchfGaym3FV():
	mlykPoGXbJIjFnarp9KihxfN(WoFsvbmUlDZp7PzRfdGknCV,fWoVd0Bmtkx(u"ࠩࡐࡍࡘࡉ࡟ࡕࡇࡐࡔࡤ࠷ࠧዮ"),sjtU6GZQg5XC2pH4(u"ࠪࡅࡑࡒ࡟ࡂࡆࡇࡓࡓ࡙࡟࡙ࡏࡏࠫዯ"))
	iZFceBlMC9JuHx1R5fKAYO8Eyrsnzj()
	UQoBYWuIxVM7894F6SsXn1ZfvAjG = XL2k6KGdvhAlMNoa3u0eHrqmjOy()
	if UQoBYWuIxVM7894F6SsXn1ZfvAjG:
		Yz4RMHeNEZ9PO7VhxGcQjfs1(gBExoceumj4y8bFW9hY2aNMVSr)
		vuBjEdkpnKx(gBExoceumj4y8bFW9hY2aNMVSr)
		E2E18vJ4hLaZpuWSfoMlY9yBzj6b(ag8rjZo1Vz4IPdcOT)
	return
def onj4dWsP2O8eqZriy(xqJBEohLpFs):
	MOTjA5H9XFs = Rqvw05BorCgcye7VE32Sf.executeJSONRPC(ee86G9ladLHVbh5mikzCo(u"ࠫࢀࠨࡪࡴࡱࡱࡶࡵࡩࠢ࠻ࠤ࠵࠲࠵ࠨࠬࠣ࡯ࡨࡸ࡭ࡵࡤࠣ࠼ࠥࡅࡩࡪ࡯࡯ࡵ࠱ࡗࡪࡺࡁࡥࡦࡲࡲࡊࡴࡡࡣ࡮ࡨࡨࠧ࠲ࠢࡪࡦࠥ࠾࠶࠲ࠢࡱࡣࡵࡥࡲࡹࠢ࠻ࡽࠥࡥࡩࡪ࡯࡯࡫ࡧࠦ࠿ࠨࠧደ")+xqJBEohLpFs+CC1eY6yWZUwf2TkRvnp7EJ0AimjHBX(u"ࠬࠨࠬࠣࡧࡱࡥࡧࡲࡥࡥࠤ࠽ࡸࡷࡻࡥࡾࡿࠪዱ"))
	succeeded = gBExoceumj4y8bFW9hY2aNMVSr if LZWMikPEB81KSGyxfJtUsCA(u"࠭ࡏࡌࠩዲ") in MOTjA5H9XFs else ag8rjZo1Vz4IPdcOT
	return succeeded
def qzkXPHw0NFSoe(xqJBEohLpFs):
	MOTjA5H9XFs = Rqvw05BorCgcye7VE32Sf.executeJSONRPC(qqzwE6imYG4c2xojI(u"ࠧࡼࠤ࡭ࡷࡴࡴࡲࡱࡥࠥ࠾ࠧ࠸࠮࠱ࠤ࠯ࠦࡲ࡫ࡴࡩࡱࡧࠦ࠿ࠨࡁࡥࡦࡲࡲࡸ࠴ࡓࡦࡶࡄࡨࡩࡵ࡮ࡆࡰࡤࡦࡱ࡫ࡤࠣ࠮ࠥ࡭ࡩࠨ࠺࠲࠮ࠥࡴࡦࡸࡡ࡮ࡵࠥ࠾ࢀࠨࡡࡥࡦࡲࡲ࡮ࡪࠢ࠻ࠤࠪዳ")+xqJBEohLpFs+fWoVd0Bmtkx(u"ࠨࠤ࠯ࠦࡪࡴࡡࡣ࡮ࡨࡨࠧࡀࡦࡢ࡮ࡶࡩࢂࢃࠧዴ"))
	succeeded = gBExoceumj4y8bFW9hY2aNMVSr if aXqWLoTdVgME(u"ࠩࡒࡏࠬድ") in MOTjA5H9XFs else ag8rjZo1Vz4IPdcOT
	return succeeded
def uJPyVz9Im0(xqJBEohLpFs,showDialogs,XHh1xY6S4elg,jNmfig0xKqC3MFIrQt6=None):
	o4oUxD3u18K59ghHIY,succeeded,wcQG7RlEUBVWdMFk,C4jGlOfiq6w = gBExoceumj4y8bFW9hY2aNMVSr,ag8rjZo1Vz4IPdcOT,Ie5s2cBtSfdHjzQ4rA9kYlo6D18(u"ࠪࡪࡦ࡯࡬ࡦࡦࠪዶ"),qpFY4hAwolV3
	if not jNmfig0xKqC3MFIrQt6: jNmfig0xKqC3MFIrQt6 = yJOhc6G7ier1Fj2pzA([xqJBEohLpFs])
	if xqJBEohLpFs in list(jNmfig0xKqC3MFIrQt6.keys()):
		UQoBYWuIxVM7894F6SsXn1ZfvAjG,C4jGlOfiq6w,vjc0VWYzlITUufJ9X,ddGithIMzBpkfPx67,d7tOFAycUTp,JcCvFaqhzAPr9yxielEKZRopwkU,diRE2cprJLWKwY0Bku8xS7CaVh6DI = jNmfig0xKqC3MFIrQt6[xqJBEohLpFs]
		if JcCvFaqhzAPr9yxielEKZRopwkU==N3flV6EJsD5CzS(u"ࠫ࡬ࡵ࡯ࡥࠩዷ"):
			succeeded,wcQG7RlEUBVWdMFk = gBExoceumj4y8bFW9hY2aNMVSr,V3VlkhgjEF4n1erPXHcC0NOsfwyAJ(u"ࠬࡴ࡯ࡵࡪ࡬ࡲ࡬࠭ዸ")
			if XHh1xY6S4elg and showDialogs:
				o4oUxD3u18K59ghHIY = VVpbtSKYUGXrNMwAWFo9IOjZP(qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,GLTtERWbHnFuy4PCp,tQMjXKCA5dN4xq3beVIzaEoWkFLg(u"࠭ฬ๋ัࠣะิอࠠ࠯࠰ࠣ็ํี๊ࠡ์ึฮำีๅࠡลัีࠥหีะษิࠤ๊ะ่โำࠣๅ๏ࠦๅ้ษๅ฽๋ࠥำห๊า฽ࠥ฿ๅศั่ࠣ์ึ็ࠡษ็ษ฻อแส࡞ࡱࡠࡳ࠭ዹ")+xqJBEohLpFs+tQMjXKCA5dN4xq3beVIzaEoWkFLg(u"ࠧ࡝ࡰ࡟ࡲ์๊ࠠหำํำࠥหูศัฬࠤฯัศ๋ฬ๋ࠣีํࠠศๆศฺฬ็ษࠡ็ิอࠥษฮา๋ࠪዺ"))
				if o4oUxD3u18K59ghHIY:
					succeeded = WxjKhqVD7XNnTisJIr4Ya8Mwt5(xqJBEohLpFs,diRE2cprJLWKwY0Bku8xS7CaVh6DI,ag8rjZo1Vz4IPdcOT)
					if succeeded:
						wcQG7RlEUBVWdMFk = LZWMikPEB81KSGyxfJtUsCA(u"ࠨࡴࡨ࡭ࡳࡹࡴࡢ࡮࡯ࡩࡩ࠭ዻ")
						if showDialogs: iG7Rz2kmn0x1yLNMV3u8O(qpFY4hAwolV3,qpFY4hAwolV3,GLTtERWbHnFuy4PCp,qqzwE6imYG4c2xojI(u"ࠩฯ๎ิࠦฬะษࠣ࠲࠳ࠦวๅวูหๆฯࠠไษ้ฮ๋่ࠥอ๊าอࠥ࠴࠮๊ࠡๅห๊ࠦวๅสิ๊ฬ๋ฬࠡสศ฽ฬีษࠡฬฮฬ๏ะ็ศ࡞ࡱࡠࡳ࠭ዼ")+xqJBEohLpFs)
					else:
						wcQG7RlEUBVWdMFk = rNdBKI74fAklnoCZ6(u"ࠪࡪࡦ࡯࡬ࡦࡦࠪዽ")
						iG7Rz2kmn0x1yLNMV3u8O(qpFY4hAwolV3,qpFY4hAwolV3,GLTtERWbHnFuy4PCp,c2RKu0xG1eC8MiohyE(u"้๊ࠫริใࠣ࠲࠳ࠦวๅสิ๊ฬ๋ฬࠡๆ่ࠤ๏ูสุ์฼ࠤส฿วะหࠣฮะฮ๊ห๊ࠢิ์ࠦวๅวูหๆฯ࡜࡯࡞ࡱࠫዾ")+xqJBEohLpFs)
		else:
			if showDialogs:
				if JcCvFaqhzAPr9yxielEKZRopwkU==V3VlkhgjEF4n1erPXHcC0NOsfwyAJ(u"ࠬࡪࡩࡴࡣࡥࡰࡪࡪࠧዿ"): w0CZ6B3WDJknhEsdRYyH1XAM = mmV2nucZ5Lpl6FO1JMPEqGoQKW(u"࠭ๅห๊ๅๅฮ࠭ጀ")
				elif JcCvFaqhzAPr9yxielEKZRopwkU==DaFZHsThGmd0zv6e(u"ࠧࡰ࡮ࡧࠫጁ"): w0CZ6B3WDJknhEsdRYyH1XAM = ddiCzu6yahj5RtTISMJ48sNnZBU(u"ࠨไา๎๊ฯࠧጂ")
				elif JcCvFaqhzAPr9yxielEKZRopwkU==rNdBKI74fAklnoCZ6(u"ࠩࡰ࡭ࡸࡹࡩ࡯ࡩࠪጃ"): w0CZ6B3WDJknhEsdRYyH1XAM = N3flV6EJsD5CzS(u"ࠪ฾๏ืࠠๆอหฮฮ࠭ጄ")
				o4oUxD3u18K59ghHIY = VVpbtSKYUGXrNMwAWFo9IOjZP(qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,GLTtERWbHnFuy4PCp,sjtU6GZQg5XC2pH4(u"ࠫ์ึ็ࠡษ็ษ฻อแสࠢࠪጅ")+w0CZ6B3WDJknhEsdRYyH1XAM+N3flV6EJsD5CzS(u"ࠬࠦ࠮࠯๊่ࠢࠥะั๋ัࠣษฺ๊วฮ๊ࠢิ์ࠦวๅ็ื็้ฯࠠภࠣ࡟ࡲࡡࡴࠧጆ")+xqJBEohLpFs)
			if not o4oUxD3u18K59ghHIY: wcQG7RlEUBVWdMFk = V3VlkhgjEF4n1erPXHcC0NOsfwyAJ(u"࠭ࡣࡢࡰࡦࡩࡱ࡫ࡤࠨጇ")
			else:
				if JcCvFaqhzAPr9yxielEKZRopwkU==CC1eY6yWZUwf2TkRvnp7EJ0AimjHBX(u"ࠧࡥ࡫ࡶࡥࡧࡲࡥࡥࠩገ"):
					succeeded = onj4dWsP2O8eqZriy(xqJBEohLpFs)
					if succeeded:
						wcQG7RlEUBVWdMFk = lljaEqwTVtmKsQcOrbXxS5hgNH(u"ࠨࡧࡱࡥࡧࡲࡥࡥࠩጉ")
						if showDialogs: iG7Rz2kmn0x1yLNMV3u8O(qpFY4hAwolV3,qpFY4hAwolV3,GLTtERWbHnFuy4PCp,N3flV6EJsD5CzS(u"ࠩฯ๎ิࠦฬะษࠣ࠲࠳ࠦวๅวูหๆฯࠠไษ้ฮ๋ࠥส้ไไอࠥ࠴࠮๊ࠡๅห๊ࠦวๅสิ๊ฬ๋ฬࠡสอุ฿๐ไ่ษ࡟ࡲࡡࡴࠧጊ")+xqJBEohLpFs)
					elif showDialogs: iG7Rz2kmn0x1yLNMV3u8O(qpFY4hAwolV3,qpFY4hAwolV3,GLTtERWbHnFuy4PCp,CC1eY6yWZUwf2TkRvnp7EJ0AimjHBX(u"่้ࠪษำโࠢ࠱࠲ࠥอไฦุสๅฮࠦๅห๊ๅๅฮࠦ࠮࠯๋่๊๊ࠢࠦิฬฺ๎฾ࠦวๅสิ๊ฬ๋ฬࠡฬื฾๏๊็ศ࡞ࡱࡠࡳ࠭ጋ")+xqJBEohLpFs)
				elif JcCvFaqhzAPr9yxielEKZRopwkU in [qoBMmfAWpFlK70xw8ZRh4naJ(u"ࠫࡴࡲࡤࠨጌ"),BRWqdruz2A0(u"ࠬࡳࡩࡴࡵ࡬ࡲ࡬࠭ግ")]:
					succeeded = WxjKhqVD7XNnTisJIr4Ya8Mwt5(xqJBEohLpFs,diRE2cprJLWKwY0Bku8xS7CaVh6DI,ag8rjZo1Vz4IPdcOT)
					if succeeded:
						if JcCvFaqhzAPr9yxielEKZRopwkU==YY8UDX3MJhb91AHw7fg(u"࠭࡯࡭ࡦࠪጎ"): wcQG7RlEUBVWdMFk = dJHDqiKf12TXlIzSLkGUuxg4MBs3A(u"ࠧࡶࡲࡧࡥࡹ࡫ࡤࠨጏ")
						elif JcCvFaqhzAPr9yxielEKZRopwkU==zYvEaigKWjoq50pXBLDbGJkFc(u"ࠨ࡯࡬ࡷࡸ࡯࡮ࡨࠩጐ"): wcQG7RlEUBVWdMFk = ddiCzu6yahj5RtTISMJ48sNnZBU(u"ࠩ࡬ࡲࡸࡺࡡ࡭࡮ࡨࡨࠬ጑")
						C4jGlOfiq6w = ddGithIMzBpkfPx67
						if showDialogs:
							if wcQG7RlEUBVWdMFk==tR1krDGPpO025fghMT3a7UnYj(u"ࠪࡹࡵࡪࡡࡵࡧࡧࠫጒ"): iG7Rz2kmn0x1yLNMV3u8O(qpFY4hAwolV3,qpFY4hAwolV3,GLTtERWbHnFuy4PCp,N3flV6EJsD5CzS(u"ࠫั๐ฯࠡฮาหࠥ࠴࠮ࠡษ็ษ฻อแสࠢๆห๋ะࠠใัํ้ฮࠦ࠮࠯๋ࠢห้ฮั็ษ่ะ่ࠥวๆࠢหฮาี๊ฬ้สࡠࡳࡢ࡮ࠨጓ")+xqJBEohLpFs)
							elif wcQG7RlEUBVWdMFk==N3flV6EJsD5CzS(u"ࠬ࡯࡮ࡴࡶࡤࡰࡱ࡫ࡤࠨጔ"): iG7Rz2kmn0x1yLNMV3u8O(qpFY4hAwolV3,qpFY4hAwolV3,GLTtERWbHnFuy4PCp,sjtU6GZQg5XC2pH4(u"࠭ฬ๋ัࠣะิอࠠ࠯࠰ࠣห้หึศใฬࠤ้๋ࠠหๅ้ࠤ๊๎ฬ้ัฬࠤๆ๐ࠠไ๊า๎ࠥ࠴࠮๊ࠡส่อืๆศ็ฯࠤ็อๅࠡสอฯอ๐ส่ษ࡟ࡲࡡࡴࠧጕ")+xqJBEohLpFs)
					elif showDialogs: iG7Rz2kmn0x1yLNMV3u8O(qpFY4hAwolV3,qpFY4hAwolV3,GLTtERWbHnFuy4PCp,dJHDqiKf12TXlIzSLkGUuxg4MBs3A(u"ࠧๅๆฦืๆࠦ࠮࠯ࠢส่อืๆศ็ฯࠤ้๋๋ࠠีอ฻๏฿ࠠหฯา๎ะࠦร้ࠢอฯอ๐ส้ࠡำ๋ࠥอไฦุสๅฮࡢ࡮࡝ࡰࠪ጖")+xqJBEohLpFs)
	elif showDialogs: iG7Rz2kmn0x1yLNMV3u8O(qpFY4hAwolV3,qpFY4hAwolV3,GLTtERWbHnFuy4PCp,UVa3fJw7k6KM(u"ࠨๆ็วุ็ࠠ࠯࠰๋ࠣีํࠠศๆศฺฬ็ษࠡ฼ํี๋่ࠥอ๊าอࠥ็๊ࠡ็ึฮํีูࠡ฻่หิࠦ࠮࠯๋่ࠢ์ึวࠡๆสࠤ๏ูสุ์฼ࠤฬ๊ศา่ส้ัࠦร็ࠢํๆํ๋ࠠษฬฮฬ๏ะ่ࠠา๊ࠤฬ๊ลืษไอࠥษ่ࠡฬะำ๏ั็ศ࡞ࡱࡠࡳ࠭጗")+xqJBEohLpFs)
	return succeeded,wcQG7RlEUBVWdMFk,C4jGlOfiq6w
def JqETagILNDXh(xqJBEohLpFs,showDialogs,bYT5m304syVl6ERp9SWeQIFP7LZx2d):
	m7b9T3ScArQEKj4D0o = IkS3LDtnyvAh2NaQU5p6P1KHZ.connect(Rb017YwecyPpEVQWAIu6HGhJ9k3tf)
	m7b9T3ScArQEKj4D0o.text_factory = str
	EHQhicPzSdtkG = m7b9T3ScArQEKj4D0o.cursor()
	succeeded,rIGfDuv9WljqKES2LY = gBExoceumj4y8bFW9hY2aNMVSr,ag8rjZo1Vz4IPdcOT
	try:
		unERF480B5e = LZWMikPEB81KSGyxfJtUsCA(u"ࠩࡵࡩࡵࡵࡳࡪࡶࡲࡶࡾ࠴ࡥ࡮ࡣࡧࠫጘ")
		EHQhicPzSdtkG.execute(l1DZAt9XNQjqE7YOdrz(u"ࠪࡗࡊࡒࡅࡄࡖࠣࡳࡷ࡯ࡧࡪࡰࠣࡊࡗࡕࡍࠡ࡫ࡱࡷࡹࡧ࡬࡭ࡧࡧࠤ࡜ࡎࡅࡓࡇࠣࡥࡩࡪ࡯࡯ࡋࡇࠤࡂࠦࠢࠨጙ")+xqJBEohLpFs+qqzwE6imYG4c2xojI(u"ࠫࠧࠦ࠻ࠨጚ"))
		sQviLuhq3tZyGbaJCI9dorR52cmg = EHQhicPzSdtkG.fetchall()
		if sQviLuhq3tZyGbaJCI9dorR52cmg and unERF480B5e not in str(sQviLuhq3tZyGbaJCI9dorR52cmg): EHQhicPzSdtkG.execute(tR1krDGPpO025fghMT3a7UnYj(u"࡛ࠬࡐࡅࡃࡗࡉࠥ࡯࡮ࡴࡶࡤࡰࡱ࡫ࡤࠡࡕࡈࡘࠥࡵࡲࡪࡩ࡬ࡲࠥࡃࠠࠣࠩጛ")+unERF480B5e+ddiCzu6yahj5RtTISMJ48sNnZBU(u"࡙࠭ࠢࠡࡋࡉࡗࡋࠠࡢࡦࡧࡳࡳࡏࡄࠡ࠿ࠣࠦࠬጜ")+xqJBEohLpFs+sjtU6GZQg5XC2pH4(u"ࠧࠣࠢ࠾ࠫጝ"))
		q8SdUknB6o1CL = ee86G9ladLHVbh5mikzCo(u"ࠨࡤ࡯ࡥࡨࡱ࡬ࡪࡵࡷࠫጞ") if NJwViHDTMdmO0xnALqQ9voPalC3Ip else IaBhDMJc17302LgSvyxd(u"ࠩࡸࡴࡩࡧࡴࡦࡡࡵࡹࡱ࡫ࡳࠨጟ")
		EHQhicPzSdtkG.execute(BRWqdruz2A0(u"ࠪࡗࡊࡒࡅࡄࡖࠣ࠮ࠥࡌࡒࡐࡏࠣࠫጠ")+q8SdUknB6o1CL+DiJ8CMuYH1daWyjehfN0L(u"ࠫࠥ࡝ࡈࡆࡔࡈࠤࡦࡪࡤࡰࡰࡌࡈࠥࡃࠠࠣࠩጡ")+xqJBEohLpFs+IaBhDMJc17302LgSvyxd(u"ࠬࠨࠠ࠼ࠩጢ"))
		sQviLuhq3tZyGbaJCI9dorR52cmg = EHQhicPzSdtkG.fetchall()
		if sQviLuhq3tZyGbaJCI9dorR52cmg:
			if showDialogs: o4oUxD3u18K59ghHIY = VVpbtSKYUGXrNMwAWFo9IOjZP(qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,GLTtERWbHnFuy4PCp,kYDaz79TFlXoR(u"࠭วๅฬะำ๏ัࠠศๆฦ์ฯ๎ๅศฬํ็๏ࠦไฦุสๅฮࠦ࡜࡯ࠢࠪጣ")+xqJBEohLpFs+iNc3KxwErnQ(u"ࠧࠡ࡞ࡱࡠࡳࠦࠧጤ")+xupTj02bvy3O8R+N3flV6EJsD5CzS(u"ࠨ่ࠢฮํ่แ๊ࠡ็หࠥ๐ูๆๆࠣ࠲࠳ࠦ็ๅࠢอี๏ีࠠหใ฼๎้ํࠠศๆล๊ࠥลࠡࠢࠢࠪጥ")+fF4lt9zWYxXLKZVyAco82PgMj+Ie5s2cBtSfdHjzQ4rA9kYlo6D18(u"ࠩࠣࡠࡳࡢ࡮ࠡฬึฮ฼๐ูࠡวํๆฬ็็ࠡสึ๋ํ๊ษࠡ฻้ำࠥอไฺ๊าอࠥหไ๊๊ࠢิ์ࠦวๅึสุฮࠦวๅ็๋ะํีษࠡใํࠤ็อฦๆหูࠣ๏อๆสࠢหี๋อๅอࠢ฼้ฬีࠧጦ"))
			else: o4oUxD3u18K59ghHIY = mZi0S72jGoHpLO
			if o4oUxD3u18K59ghHIY==mZi0S72jGoHpLO:
				rIGfDuv9WljqKES2LY = gBExoceumj4y8bFW9hY2aNMVSr
				EHQhicPzSdtkG.execute(V3VlkhgjEF4n1erPXHcC0NOsfwyAJ(u"ࠪࡈࡊࡒࡅࡕࡇࠣࡊࡗࡕࡍࠡࠩጧ")+q8SdUknB6o1CL+qoBMmfAWpFlK70xw8ZRh4naJ(u"ࠫࠥ࡝ࡈࡆࡔࡈࠤࡦࡪࡤࡰࡰࡌࡈࠥࡃࠠࠣࠩጨ")+xqJBEohLpFs+IaBhDMJc17302LgSvyxd(u"ࠬࠨࠠ࠼ࠩጩ"))
		elif bYT5m304syVl6ERp9SWeQIFP7LZx2d:
			if showDialogs: o4oUxD3u18K59ghHIY = VVpbtSKYUGXrNMwAWFo9IOjZP(qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,GLTtERWbHnFuy4PCp,BRWqdruz2A0(u"࠭วๅฬะำ๏ัࠠศๆฦ์ฯ๎ๅศฬํ็๏ࠦไฦุสๅฮࠦ࡜࡯ࠢࠪጪ")+xqJBEohLpFs+dJHDqiKf12TXlIzSLkGUuxg4MBs3A(u"ࠧࠡ࡞ࡱࡠࡳࠦࠧጫ")+xupTj02bvy3O8R+DaFZHsThGmd0zv6e(u"ࠨ่ࠢๅ฾๊้ࠠ์฼้้ࠦ࠮࠯๊่ࠢࠥะั๋ัࠣษ๏่วโ้ࠣห้ศๆࠡมࠤࠥࠥ࠭ጬ")+fF4lt9zWYxXLKZVyAco82PgMj+fWoVd0Bmtkx(u"ࠩࠣࡠࡳࡢ࡮ࠡฬึฮ฼๐ูࠡฬไ฽๏๊็ࠡสึ๋ํ๊ษࠡ฻้ำࠥอไฺ๊าอࠥหไ๊๊ࠢิ์ࠦวๅึสุฮࠦวๅ็๋ะํีษࠡใํࠤ็อฦๆหูࠣ๏อๆสࠢหี๋อๅอࠢ฼้ฬีࠧጭ"))
			else: o4oUxD3u18K59ghHIY = mZi0S72jGoHpLO
			if o4oUxD3u18K59ghHIY==mZi0S72jGoHpLO:
				rIGfDuv9WljqKES2LY = gBExoceumj4y8bFW9hY2aNMVSr
				if NJwViHDTMdmO0xnALqQ9voPalC3Ip: EHQhicPzSdtkG.execute(DiJ8CMuYH1daWyjehfN0L(u"ࠪࡍࡓ࡙ࡅࡓࡖࠣࡍࡓ࡚ࡏࠡࠩጮ")+q8SdUknB6o1CL+DiJ8CMuYH1daWyjehfN0L(u"ࠫࠥ࠮ࡡࡥࡦࡲࡲࡎࡊࠩࠡࡘࡄࡐ࡚ࡋࡓࠡࠪࠥࠫጯ")+xqJBEohLpFs+tQMjXKCA5dN4xq3beVIzaEoWkFLg(u"ࠬࠨࠩࠡ࠽ࠪጰ"))
				else: EHQhicPzSdtkG.execute(l32dnTEOU1skGKqeBtI9hmo(u"࠭ࡉࡏࡕࡈࡖ࡙ࠦࡉࡏࡖࡒࠤࠬጱ")+q8SdUknB6o1CL+l1DZAt9XNQjqE7YOdrz(u"ࠧࠡࠪࡤࡨࡩࡵ࡮ࡊࡆ࠯ࡹࡵࡪࡡࡵࡧࡕࡹࡱ࡫ࠩࠡࡘࡄࡐ࡚ࡋࡓࠡࠪࠥࠫጲ")+xqJBEohLpFs+RlOvin8YIGC2KZXJPk9m0acrMobUex(u"ࠨࠤ࠯࠵࠮ࠦ࠻ࠨጳ"))
	except: succeeded = ag8rjZo1Vz4IPdcOT
	m7b9T3ScArQEKj4D0o.commit()
	m7b9T3ScArQEKj4D0o.close()
	if rIGfDuv9WljqKES2LY:
		s7FnXZYOgexlH2MPb8BJck1AKv9.sleep(sjtU6GZQg5XC2pH4(u"࠷Ꮩ"))
		Rqvw05BorCgcye7VE32Sf.executebuiltin(CC1eY6yWZUwf2TkRvnp7EJ0AimjHBX(u"ࠩࡘࡴࡩࡧࡴࡦࡎࡲࡧࡦࡲࡁࡥࡦࡲࡲࡸ࠭ጴ"))
		s7FnXZYOgexlH2MPb8BJck1AKv9.sleep(l1DZAt9XNQjqE7YOdrz(u"࠱Ꮪ"))
		if showDialogs:
			if succeeded: iG7Rz2kmn0x1yLNMV3u8O(qpFY4hAwolV3,qpFY4hAwolV3,GLTtERWbHnFuy4PCp,tR1krDGPpO025fghMT3a7UnYj(u"๊ࠪัำสࠡ฻่่๏ฯࠠฦื็หาࠦสฮัํฯࠥอไฦุสๅฮࠦ࡜࡯࡞ࡱࠫጵ")+xqJBEohLpFs)
			else: iG7Rz2kmn0x1yLNMV3u8O(qpFY4hAwolV3,qpFY4hAwolV3,GLTtERWbHnFuy4PCp,lljaEqwTVtmKsQcOrbXxS5hgNH(u"ࠫๆฺไหࠢ฼้้๐ษࠡวุ่ฬำࠠหฯา๎ะࠦวๅวูหๆฯࠠ࡝ࡰ࡟ࡲࠬጶ")+xqJBEohLpFs)
	return rIGfDuv9WljqKES2LY
def i7aA1MZztsHSxXbpNyj4(RbU35LjaHTM2Gy7YkwA0,showDialogs,XHh1xY6S4elg,bYT5m304syVl6ERp9SWeQIFP7LZx2d):
	jNmfig0xKqC3MFIrQt6 = yJOhc6G7ier1Fj2pzA(RbU35LjaHTM2Gy7YkwA0)
	zzcfNkTxaWn3 = ag8rjZo1Vz4IPdcOT
	for xqJBEohLpFs in RbU35LjaHTM2Gy7YkwA0:
		succeeded,wcQG7RlEUBVWdMFk,C4jGlOfiq6w = uJPyVz9Im0(xqJBEohLpFs,showDialogs,XHh1xY6S4elg,jNmfig0xKqC3MFIrQt6)
		rIGfDuv9WljqKES2LY = JqETagILNDXh(xqJBEohLpFs,showDialogs,bYT5m304syVl6ERp9SWeQIFP7LZx2d)
		if rIGfDuv9WljqKES2LY: zzcfNkTxaWn3 = gBExoceumj4y8bFW9hY2aNMVSr
	if zzcfNkTxaWn3:
		s7FnXZYOgexlH2MPb8BJck1AKv9.sleep(sjtU6GZQg5XC2pH4(u"࠲Ꮫ"))
		Rqvw05BorCgcye7VE32Sf.executebuiltin(UUDAiytEL76RTmMYsuIz5evXB(u"࡛ࠬࡰࡥࡣࡷࡩࡑࡵࡣࡢ࡮ࡄࡨࡩࡵ࡮ࡴࠩጷ"))
		s7FnXZYOgexlH2MPb8BJck1AKv9.sleep(dJHDqiKf12TXlIzSLkGUuxg4MBs3A(u"࠳Ꮬ"))
	if showDialogs:
		if len(RbU35LjaHTM2Gy7YkwA0)>tR1krDGPpO025fghMT3a7UnYj(u"࠴Ꮭ"): iG7Rz2kmn0x1yLNMV3u8O(qpFY4hAwolV3,qpFY4hAwolV3,GLTtERWbHnFuy4PCp,aXqWLoTdVgME(u"࠭สๆࠢห๊ัออࠡใะูࠥาๅ๋฻ࠣห้หึศใสฮࠬጸ"))
		else: iG7Rz2kmn0x1yLNMV3u8O(qpFY4hAwolV3,qpFY4hAwolV3,GLTtERWbHnFuy4PCp,qoBMmfAWpFlK70xw8ZRh4naJ(u"ࠧห็ࠣฬ๋าวฮࠢไัฺࠦวๅวูหๆฯ࡜࡯࡞ࡱࠫጹ")+RbU35LjaHTM2Gy7YkwA0[fWoVd0Bmtkx(u"࠴Ꮮ")])
	return
def Yz4RMHeNEZ9PO7VhxGcQjfs1(showDialogs):
	PPmrGYLgVaNXTyACQhW7qjI18we = [UVa3fJw7k6KM(u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡢࡴࡤࡦ࡮ࡩࡶࡪࡦࡨࡳࡸ࠭ጺ"),qqzwE6imYG4c2xojI(u"ࠩࡵࡩࡵࡵࡳࡪࡶࡲࡶࡾ࠴ࡥ࡮ࡣࡧࠫጻ"),dJHDqiKf12TXlIzSLkGUuxg4MBs3A(u"ࠪࡷࡨࡸࡩࡱࡶ࠱ࡱࡴࡪࡵ࡭ࡧ࠱ࡶࡪࡹ࡯࡭ࡸࡨࡹࡷࡲࠧጼ"),DiJ8CMuYH1daWyjehfN0L(u"ࠫࡸࡩࡲࡪࡲࡷ࠲ࡲࡵࡤࡶ࡮ࡨ࠲ࡾࡺ࠭ࡥ࡮ࡳࠫጽ")]
	Aygv49TBOzQ1xYewPL = [Ie5s2cBtSfdHjzQ4rA9kYlo6D18(u"ࠬࡸࡥࡱࡱࡶ࡭ࡹࡵࡲࡺ࠰ࡨࡱࡦࡪ࠮ࡰࡶ࡫ࡩࡷࡹࠧጾ"),dJHDqiKf12TXlIzSLkGUuxg4MBs3A(u"࠭ࡲࡦࡲࡲࡷ࡮ࡺ࡯ࡳࡻ࠱ࡩࡲࡧࡤ࠯ࡩ࡬ࡸࡪ࡫ࠧጿ"),c2RKu0xG1eC8MiohyE(u"ࠧࡳࡧࡳࡳࡸ࡯ࡴࡰࡴࡼ࠲ࡪࡳࡡࡥ࠰ࡳࡽࡹ࡮࡯࡯ࡣࡱࡽࡼ࡮ࡥࡳࡧࠪፀ"),BRWqdruz2A0(u"ࠨࡴࡨࡴࡴࡹࡩࡵࡱࡵࡽ࠳࡫࡭ࡢࡦ࠱࡫࡮ࡺࡨࡶࡤࠪፁ"),LZWMikPEB81KSGyxfJtUsCA(u"ࠩࡵࡩࡵࡵࡳࡪࡶࡲࡶࡾ࠴ࡥ࡮ࡣࡧ࠲࡬࡯ࡴࡦࡣࠪፂ"),lljaEqwTVtmKsQcOrbXxS5hgNH(u"ࠪࡶࡪࡶ࡯ࡴ࡫ࡷࡳࡷࡿ࠮ࡦ࡯ࡤࡨ࠳ࡩ࡯ࡥࡧࡥࡩࡷ࡭ࠧፃ")]
	for xqJBEohLpFs in Aygv49TBOzQ1xYewPL: qzkXPHw0NFSoe(xqJBEohLpFs)
	i7aA1MZztsHSxXbpNyj4(PPmrGYLgVaNXTyACQhW7qjI18we,showDialogs,ag8rjZo1Vz4IPdcOT,ag8rjZo1Vz4IPdcOT)
	return