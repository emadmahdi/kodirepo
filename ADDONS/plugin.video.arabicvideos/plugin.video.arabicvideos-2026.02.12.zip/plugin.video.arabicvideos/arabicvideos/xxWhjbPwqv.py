# -*- coding: utf-8 -*-
from pSfaryIjBo import *
headers = { 'User-Agent' : qpFY4hAwolV3 }
Q8Q0IDc6PLZajJAdTntKUmSGXz = 'AKOAM'
wwSFijdVJn1QgHW = '_AKO_'
ddBxj51bhNtaK23lDyGMVw = i4bFG3rKE6.SITESURLS[Q8Q0IDc6PLZajJAdTntKUmSGXz][0]
R35jsQdBMoXUyDkZ7etmI = ['فيلم','كليب','العرض الاسبوعي','مسرحية','مسرحيه','اغنية','اعلان','لقاء']
def vTNE2Ck1sGnugJYW8y39aLcSH64U(mode,url,text):
	if   mode==70: MOTjA5H9XFs = nRVAZc4Dp8PSrGU3xBk()
	elif mode==71: MOTjA5H9XFs = KK3QFHikTNzwY8j25G7vr14cWh(url)
	elif mode==72: MOTjA5H9XFs = c8U1BdtxOZS5FH(url,text)
	elif mode==73: MOTjA5H9XFs = DOU6ZrBqoeYyQX4V(url)
	elif mode==74: MOTjA5H9XFs = mzcAeyplZV(url)
	elif mode==79: MOTjA5H9XFs = PPqUACSE3VcGLTvw05jHy9JrFNW(text)
	else: MOTjA5H9XFs = False
	return MOTjA5H9XFs
def nRVAZc4Dp8PSrGU3xBk():
	x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+'بحث في الموقع',qpFY4hAwolV3,79,qpFY4hAwolV3,qpFY4hAwolV3,'_REMEMBERRESULTS_')
	x3WSXnKyPhjqfHG2UrtQs('folder',Q8Q0IDc6PLZajJAdTntKUmSGXz+'_SCRIPT_'+wwSFijdVJn1QgHW+'سلسلة افلام',qpFY4hAwolV3,79,qpFY4hAwolV3,qpFY4hAwolV3,'سلسلة افلام')
	x3WSXnKyPhjqfHG2UrtQs('folder',Q8Q0IDc6PLZajJAdTntKUmSGXz+'_SCRIPT_'+wwSFijdVJn1QgHW+'سلاسل منوعة',qpFY4hAwolV3,79,qpFY4hAwolV3,qpFY4hAwolV3,'سلسلة')
	x3WSXnKyPhjqfHG2UrtQs('link',xupTj02bvy3O8R+' ===== ===== ===== '+fF4lt9zWYxXLKZVyAco82PgMj,qpFY4hAwolV3,9999)
	YEIA19ehBwpNfPVzK = ['الكتب و الابحاث','الكورسات التعليمية','الألعاب','البرامج','الاجهزة اللوحية','الصور و الخلفيات','المصارعة الحرة']
	cmWl9dOKHPIy41iaXuxrY = GMqfDK9V4F8eTPE1pNOAaiYUbhr(KOyPvpEztYLaZRdMQJWxfTNFHbkg,ddBxj51bhNtaK23lDyGMVw,qpFY4hAwolV3,headers,qpFY4hAwolV3,'AKOAM-MENU-1st')
	pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('class="partions"(.*?)</ul>',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	if pfRkcVlLmUxo561g0A8qSbO:
		mVYdjvor6i4wZ8 = pfRkcVlLmUxo561g0A8qSbO[0]
		items = ePhmG1jLD6.findall('href="(.*?)">(.*?)<',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
		for MepIvHBYNArkUOdV37shtJ,title in items:
			if title not in YEIA19ehBwpNfPVzK:
				x3WSXnKyPhjqfHG2UrtQs('folder',Q8Q0IDc6PLZajJAdTntKUmSGXz+'_SCRIPT_'+wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,71)
	return cmWl9dOKHPIy41iaXuxrY
def KK3QFHikTNzwY8j25G7vr14cWh(url):
	cmWl9dOKHPIy41iaXuxrY = GMqfDK9V4F8eTPE1pNOAaiYUbhr(KOyPvpEztYLaZRdMQJWxfTNFHbkg,url,qpFY4hAwolV3,headers,qpFY4hAwolV3,'AKOAM-CATEGORIES-1st')
	pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('sect_parts(.*?)</div>',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	if pfRkcVlLmUxo561g0A8qSbO:
		mVYdjvor6i4wZ8 = pfRkcVlLmUxo561g0A8qSbO[0]
		items = ePhmG1jLD6.findall('href="(.*?)".*?>(.*?)<',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
		for MepIvHBYNArkUOdV37shtJ,title in items:
			title = title.strip(mIsDke0oK5x1zSiOWbF9thGcA)
			x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,72)
		x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+'جميع الفروع',url,72)
	else: c8U1BdtxOZS5FH(url,qpFY4hAwolV3)
	return
def c8U1BdtxOZS5FH(url,type):
	cmWl9dOKHPIy41iaXuxrY = GMqfDK9V4F8eTPE1pNOAaiYUbhr(kUz8c7OqsxuPFIGfwg,url,qpFY4hAwolV3,headers,True,'AKOAM-TITLES-1st')
	items = []
	if type=='featured':
		pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('section_title featured_title(.*?)subjects-crousel',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
		mVYdjvor6i4wZ8 = pfRkcVlLmUxo561g0A8qSbO[0]
		items = ePhmG1jLD6.findall('href="(.*?)"><div class="subject_box.*?src="(.*?)".*?<h3.*?>(.*?)</h3>',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
	elif type=='search':
		pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('akoam_result(.*?)<script',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
		mVYdjvor6i4wZ8 = pfRkcVlLmUxo561g0A8qSbO[0]
		items = ePhmG1jLD6.findall('href="(.*?)".*?background-image: url\((.*?)\).*?<h1>(.*?)</h1>',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
	elif type=='more':
		pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('section_title more_title(.*?)footer_bottom_services',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	else:
		pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('navigation(.*?)<script',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	if not items and pfRkcVlLmUxo561g0A8qSbO:
		mVYdjvor6i4wZ8 = pfRkcVlLmUxo561g0A8qSbO[0]
		items = ePhmG1jLD6.findall('div class="subject_box.*?href="(.*?)".*?src="(.*?)".*?<h3.*?>(.*?)</h3>',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
	for MepIvHBYNArkUOdV37shtJ,Sj7rMNYRuQPTtkBvpHKeDW3h,title in items:
		if 'توضيح هام' in title: continue
		title = title.replace(ZLwoRpfnCWI7FgEHsz6te39lMVh,qpFY4hAwolV3).strip(mIsDke0oK5x1zSiOWbF9thGcA)
		title = j8PDV0pthfSTidZbsQxNIOmCYKWzH(title)
		if any(value in title for value in R35jsQdBMoXUyDkZ7etmI): x3WSXnKyPhjqfHG2UrtQs('video',wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,73,Sj7rMNYRuQPTtkBvpHKeDW3h)
		else: x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,73,Sj7rMNYRuQPTtkBvpHKeDW3h)
	pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('class="pagination"(.*?)</ul>',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	if pfRkcVlLmUxo561g0A8qSbO:
		mVYdjvor6i4wZ8 = pfRkcVlLmUxo561g0A8qSbO[0]
		items = ePhmG1jLD6.findall("</li><li >.*?href='(.*?)'>(.*?)<",mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
		for MepIvHBYNArkUOdV37shtJ,title in items:
			x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+'صفحة '+title,MepIvHBYNArkUOdV37shtJ,72,qpFY4hAwolV3,qpFY4hAwolV3,type)
	return
def FPYKdDzCXV30m8M65TGf4(url):
	cmWl9dOKHPIy41iaXuxrY = GMqfDK9V4F8eTPE1pNOAaiYUbhr(KOyPvpEztYLaZRdMQJWxfTNFHbkg,url,qpFY4hAwolV3,headers,True,'AKOAM-SECTIONS-2nd')
	WSQlG8mDhqsNe = ePhmG1jLD6.findall('"href","(.*?)"',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	WSQlG8mDhqsNe = WSQlG8mDhqsNe[1]
	return WSQlG8mDhqsNe
def DOU6ZrBqoeYyQX4V(url):
	cmWl9dOKHPIy41iaXuxrY = GMqfDK9V4F8eTPE1pNOAaiYUbhr(kUz8c7OqsxuPFIGfwg,url,qpFY4hAwolV3,headers,True,'AKOAM-SECTIONS-1st')
	JHtPO4Z0Kki8gAqubF6yGVoDcf = ePhmG1jLD6.findall('"(https*://akwam.net/\w+.*?)"',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	F0enqMSDyICNvTlQ3x = ePhmG1jLD6.findall('"(https*://underurl.com/\w+.*?)"',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	if JHtPO4Z0Kki8gAqubF6yGVoDcf or F0enqMSDyICNvTlQ3x:
		if JHtPO4Z0Kki8gAqubF6yGVoDcf: hhpztscnBD1GP = JHtPO4Z0Kki8gAqubF6yGVoDcf[0]
		elif F0enqMSDyICNvTlQ3x: hhpztscnBD1GP = FPYKdDzCXV30m8M65TGf4(F0enqMSDyICNvTlQ3x[0])
		hhpztscnBD1GP = cTt4u6reEMKZqVLplmkNW7(hhpztscnBD1GP)
		import ZYG147KNkS
		if '/series/' in hhpztscnBD1GP or '/shows/' in hhpztscnBD1GP: ZYG147KNkS.v1gmfxDcRrWKQ(hhpztscnBD1GP)
		else: ZYG147KNkS.mzcAeyplZV(hhpztscnBD1GP)
		return
	GIE2XSj0vVJPZA6dgmOs9TMDy8UkQW = ePhmG1jLD6.findall('محتوى الفيلم.*?>.*?(\w*?)\W*?<',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	if GIE2XSj0vVJPZA6dgmOs9TMDy8UkQW and u0E18eO3HnCzr(Q8Q0IDc6PLZajJAdTntKUmSGXz,url,GIE2XSj0vVJPZA6dgmOs9TMDy8UkQW): return
	items = ePhmG1jLD6.findall('<br />\n<a href="(.*?)".*?<span style="color:.*?">(.*?)</span>',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	for MepIvHBYNArkUOdV37shtJ,title in items:
		title = j8PDV0pthfSTidZbsQxNIOmCYKWzH(title)
		x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,73)
	pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('class="sub_title".*?<h1.*?>(.*?)</h1>.*?class="main_img".*?src="(.*?)".*?ad-300-250(.*?)ako-feedback',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	if not pfRkcVlLmUxo561g0A8qSbO:
		t8yiLuJp3cBA6d1QE9x7eZ4fa('خطأ خارجي','لا يوجد ملف فيديو')
		return
	name,Sj7rMNYRuQPTtkBvpHKeDW3h,mVYdjvor6i4wZ8 = pfRkcVlLmUxo561g0A8qSbO[0]
	name = name.strip(mIsDke0oK5x1zSiOWbF9thGcA)
	if 'sub_epsiode_title' in mVYdjvor6i4wZ8:
		items = ePhmG1jLD6.findall('sub_epsiode_title">(.*?)</h2>.*?sub_file_title.*?>(.*?)<',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
	else:
		WWsj62S5AZTyF9VHa1vc7fPqkGtYL = ePhmG1jLD6.findall('sub_file_title\'>(.*?) - <i>',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
		items = []
		for filename in WWsj62S5AZTyF9VHa1vc7fPqkGtYL:
			items.append( ('رابط التشغيل',filename) )
	if not items: items = [ ('رابط التشغيل',qpFY4hAwolV3) ]
	count = 0
	QQLqrElamjfneR8GoP9IpuZ,EZ5G4YUypLA6hSP3lsgkH1QV2z = [],[]
	size = len(items)
	for title,filename in items:
		jGoKM4rgu7YFfm5WtPEin0sNRTq = qpFY4hAwolV3
		if ' - ' in filename: filename = filename.split(' - ')[0]
		else: filename = 'dummy.zip'
		if '.' in filename: jGoKM4rgu7YFfm5WtPEin0sNRTq = filename.split('.')[-1]
		title = title.replace(ZLwoRpfnCWI7FgEHsz6te39lMVh,qpFY4hAwolV3).strip(mIsDke0oK5x1zSiOWbF9thGcA)
		QQLqrElamjfneR8GoP9IpuZ.append(title)
		EZ5G4YUypLA6hSP3lsgkH1QV2z.append(count)
		count += 1
	if size>0:
		if any(value in name for value in R35jsQdBMoXUyDkZ7etmI):
			if size==1:
				ndm6kKswPpgGHNEbtB = 0
			else:
				ndm6kKswPpgGHNEbtB = xVzqWbrFXJ('اختر الفيديو المناسب:', QQLqrElamjfneR8GoP9IpuZ)
				if ndm6kKswPpgGHNEbtB == -1: return
			mzcAeyplZV(url+'?section='+str(1+EZ5G4YUypLA6hSP3lsgkH1QV2z[size-ndm6kKswPpgGHNEbtB-1]))
		else:
			for a2jQ83ZCfcM5 in reversed(range(size)):
				title = name + ' - ' + QQLqrElamjfneR8GoP9IpuZ[a2jQ83ZCfcM5]
				title = title.replace(ZLwoRpfnCWI7FgEHsz6te39lMVh,qpFY4hAwolV3).strip(mIsDke0oK5x1zSiOWbF9thGcA)
				MepIvHBYNArkUOdV37shtJ = url + '?section='+str(size-a2jQ83ZCfcM5)
				x3WSXnKyPhjqfHG2UrtQs('video',wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,74,Sj7rMNYRuQPTtkBvpHKeDW3h)
	else:
		x3WSXnKyPhjqfHG2UrtQs('video',wwSFijdVJn1QgHW+'الرابط ليس فيديو',qpFY4hAwolV3,9999,Sj7rMNYRuQPTtkBvpHKeDW3h)
	return
def mzcAeyplZV(url):
	WSQlG8mDhqsNe,ZDTxRSMbW7PNz = url.split('?section=')
	IAW0sh6So3NpqM = WWrExJZS3Bj4anOAkpv7(kUz8c7OqsxuPFIGfwg,'GET',WSQlG8mDhqsNe,qpFY4hAwolV3,headers,True,qpFY4hAwolV3,'AKOAM-PLAY_AKOAM-1st')
	cmWl9dOKHPIy41iaXuxrY = IAW0sh6So3NpqM.content
	pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('ad-300-250.*?ad-300-250(.*?)ako-feedback',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	byp4gitNZUDPKmqvdF6zBx2rEhI1 = pfRkcVlLmUxo561g0A8qSbO[0].replace("'direct_link_box",'"direct_link_box epsoide_box')
	byp4gitNZUDPKmqvdF6zBx2rEhI1 = byp4gitNZUDPKmqvdF6zBx2rEhI1 + 'direct_link_box'
	HLVwBWJ6mFa3ApoNlq178nuXgI = ePhmG1jLD6.findall('epsoide_box(.*?)direct_link_box',byp4gitNZUDPKmqvdF6zBx2rEhI1,ePhmG1jLD6.DOTALL)
	ZDTxRSMbW7PNz = len(HLVwBWJ6mFa3ApoNlq178nuXgI)-int(ZDTxRSMbW7PNz)
	mVYdjvor6i4wZ8 = HLVwBWJ6mFa3ApoNlq178nuXgI[ZDTxRSMbW7PNz]
	tiYp9ZdbFTQMcB4vWkHw6LXIAKrN5m = []
	vCQndJ6jFI = {'1423075862':'dailymotion','1477487601':'estream','1505328404':'streamango',
		'1423080015':'flashx','1458117295':'openload','1423079306':'vimple','1430052371':'ok.ru',
		'1477488213':'thevid','1558278006':'uqload','1477487990':'vidtodo'}
	items = ePhmG1jLD6.findall("class='download_btn.*?href='(.*?)'",mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
	for MepIvHBYNArkUOdV37shtJ in items:
		tiYp9ZdbFTQMcB4vWkHw6LXIAKrN5m.append(MepIvHBYNArkUOdV37shtJ+'?named=________akoam')
	items = ePhmG1jLD6.findall('background-image: url\((.*?)\).*?href=\'(.*?)\'',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
	for zfIVA18GW6,MepIvHBYNArkUOdV37shtJ in items:
		zfIVA18GW6 = zfIVA18GW6.split(ShynO8pN9idCE3)[-1]
		zfIVA18GW6 = zfIVA18GW6.split('.')[0]
		if zfIVA18GW6 in vCQndJ6jFI:
			tiYp9ZdbFTQMcB4vWkHw6LXIAKrN5m.append(MepIvHBYNArkUOdV37shtJ+'?named='+vCQndJ6jFI[zfIVA18GW6]+'________akoam')
		else: tiYp9ZdbFTQMcB4vWkHw6LXIAKrN5m.append(MepIvHBYNArkUOdV37shtJ+'?named='+zfIVA18GW6+'________akoam')
	if not tiYp9ZdbFTQMcB4vWkHw6LXIAKrN5m:
		message = ePhmG1jLD6.findall('sub-no-file.*?\n(.*?)\n',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
		if message: iG7Rz2kmn0x1yLNMV3u8O(qpFY4hAwolV3,qpFY4hAwolV3,'رسالة من الموقع الاصلي',message[0])
	else:
		import inVXFK46ET
		inVXFK46ET.q4qTJvuoQUzM3mZAtegy7IXdnb5wH(tiYp9ZdbFTQMcB4vWkHw6LXIAKrN5m,Q8Q0IDc6PLZajJAdTntKUmSGXz,'video',url)
	return
def PPqUACSE3VcGLTvw05jHy9JrFNW(search):
	search,LBylNhMdH6OV1qGk0tWiXFg3,showDialogs = LLm3sBXHPcnTDxdE5gt6hz0Wkp(search)
	if search==qpFY4hAwolV3: search = jXgARlWMLVFUBnvmZwI2o5()
	if search==qpFY4hAwolV3: return
	K7m9Otk3h1VYIN8rcP6jp2 = search.replace(mIsDke0oK5x1zSiOWbF9thGcA,'%20')
	url = ddBxj51bhNtaK23lDyGMVw + '/search/'+K7m9Otk3h1VYIN8rcP6jp2
	MOTjA5H9XFs = c8U1BdtxOZS5FH(url,'search')
	return