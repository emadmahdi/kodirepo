# -*- coding: utf-8 -*-
from pSfaryIjBo import *
Q8Q0IDc6PLZajJAdTntKUmSGXz = 'SHOOFNET'
wwSFijdVJn1QgHW = '_SNT_'
ddBxj51bhNtaK23lDyGMVw = i4bFG3rKE6.SITESURLS[Q8Q0IDc6PLZajJAdTntKUmSGXz][0]
YEIA19ehBwpNfPVzK = ['الرئيسية','يلا شوت','دكتنا','فيديو نسائم']
def vTNE2Ck1sGnugJYW8y39aLcSH64U(mode,url,text):
	if   mode==840: MOTjA5H9XFs = nRVAZc4Dp8PSrGU3xBk()
	elif mode==841: MOTjA5H9XFs = c8U1BdtxOZS5FH(url,text)
	elif mode==842: MOTjA5H9XFs = mzcAeyplZV(url)
	elif mode==843: MOTjA5H9XFs = A8s6orYkjplw(url)
	elif mode==849: MOTjA5H9XFs = PPqUACSE3VcGLTvw05jHy9JrFNW(text)
	else: MOTjA5H9XFs = False
	return MOTjA5H9XFs
def nRVAZc4Dp8PSrGU3xBk():
	IAW0sh6So3NpqM = WWrExJZS3Bj4anOAkpv7(kUz8c7OqsxuPFIGfwg,'GET',ddBxj51bhNtaK23lDyGMVw,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,'SHOOFNET-MENU-1st')
	cmWl9dOKHPIy41iaXuxrY = IAW0sh6So3NpqM.content
	x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+'بحث في الموقع',qpFY4hAwolV3,849,qpFY4hAwolV3,qpFY4hAwolV3,'_REMEMBERRESULTS_')
	x3WSXnKyPhjqfHG2UrtQs('link',xupTj02bvy3O8R+' ===== ===== ===== '+fF4lt9zWYxXLKZVyAco82PgMj,qpFY4hAwolV3,9999)
	pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('"primary-links"(.*?)</u',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	if pfRkcVlLmUxo561g0A8qSbO:
		mVYdjvor6i4wZ8 = pfRkcVlLmUxo561g0A8qSbO[0]
		items = ePhmG1jLD6.findall('href="(.*?)".*?<span>(.*?)<',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
		for MepIvHBYNArkUOdV37shtJ,title in items:
			if title in YEIA19ehBwpNfPVzK: continue
			x3WSXnKyPhjqfHG2UrtQs('folder',Q8Q0IDc6PLZajJAdTntKUmSGXz+'_SCRIPT_'+wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,841)
	pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('"list-categories"(.*?)</u',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	if pfRkcVlLmUxo561g0A8qSbO:
		mVYdjvor6i4wZ8 = pfRkcVlLmUxo561g0A8qSbO[0]
		items = ePhmG1jLD6.findall('href="(.*?)".*?>(.*?)<',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
		for MepIvHBYNArkUOdV37shtJ,title in items:
			if title in YEIA19ehBwpNfPVzK: continue
			x3WSXnKyPhjqfHG2UrtQs('folder',Q8Q0IDc6PLZajJAdTntKUmSGXz+'_SCRIPT_'+wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,841)
	return
def c8U1BdtxOZS5FH(url,kc8s5wJ4Px9zbiWQm=qpFY4hAwolV3):
	IAW0sh6So3NpqM = WWrExJZS3Bj4anOAkpv7(kUz8c7OqsxuPFIGfwg,'GET',url,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,'SHOOFNET-TITLES-1st')
	cmWl9dOKHPIy41iaXuxrY = IAW0sh6So3NpqM.content
	pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('"home-content"(.*?)"footer"',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	if pfRkcVlLmUxo561g0A8qSbO:
		mVYdjvor6i4wZ8 = pfRkcVlLmUxo561g0A8qSbO[0]
		mVYdjvor6i4wZ8 = mVYdjvor6i4wZ8.replace('"overlay"','"duration"><')
		items = ePhmG1jLD6.findall('"thumb".*?data-src="(.*?)".*?"duration">(.*?)<.*?href="(.*?)">(.*?)<',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
		aaCNAJdtsguSRELh2I = []
		for Sj7rMNYRuQPTtkBvpHKeDW3h,dq0kBrGuKXiP,MepIvHBYNArkUOdV37shtJ,title in items:
			title = title.strip(' ')
			title = j8PDV0pthfSTidZbsQxNIOmCYKWzH(title)
			ZDTxRSMbW7PNz = ePhmG1jLD6.findall('(.*?) (الحلقة|حلقة).\d+',title,ePhmG1jLD6.DOTALL)
			if 'episodes' not in kc8s5wJ4Px9zbiWQm and ZDTxRSMbW7PNz:
				title = '_MOD_' + ZDTxRSMbW7PNz[0][0]
				title = title.replace('اون لاين',qpFY4hAwolV3)
				if title not in aaCNAJdtsguSRELh2I:
					x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,843,Sj7rMNYRuQPTtkBvpHKeDW3h)
					aaCNAJdtsguSRELh2I.append(title)
			else: x3WSXnKyPhjqfHG2UrtQs('video',wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,842,Sj7rMNYRuQPTtkBvpHKeDW3h,dq0kBrGuKXiP)
	pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('''["']pagination["'](.*?)["']footer["']''',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	if pfRkcVlLmUxo561g0A8qSbO:
		kc8s5wJ4Px9zbiWQm = 'episodes_pages' if 'episodes' in kc8s5wJ4Px9zbiWQm else 'pages'
		mVYdjvor6i4wZ8 = pfRkcVlLmUxo561g0A8qSbO[0]
		items = ePhmG1jLD6.findall('href="(.*?)">(.*?)</a>',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
		for MepIvHBYNArkUOdV37shtJ,title in items:
			title = j8PDV0pthfSTidZbsQxNIOmCYKWzH(title)
			x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+'صفحة '+title,MepIvHBYNArkUOdV37shtJ,841,qpFY4hAwolV3,qpFY4hAwolV3,kc8s5wJ4Px9zbiWQm)
	return
def A8s6orYkjplw(url):
	IAW0sh6So3NpqM = WWrExJZS3Bj4anOAkpv7(kUz8c7OqsxuPFIGfwg,'GET',url,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,'SHOOFNET-SERIES-1st')
	cmWl9dOKHPIy41iaXuxrY = IAW0sh6So3NpqM.content
	MepIvHBYNArkUOdV37shtJ = ePhmG1jLD6.findall('"category".*?href="(.*?)"',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	if MepIvHBYNArkUOdV37shtJ: c8U1BdtxOZS5FH(MepIvHBYNArkUOdV37shtJ[0],'episodes')
	return
def mzcAeyplZV(url):
	tiYp9ZdbFTQMcB4vWkHw6LXIAKrN5m = []
	IAW0sh6So3NpqM = WWrExJZS3Bj4anOAkpv7(kUz8c7OqsxuPFIGfwg,'GET',url,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,'SHOOFNET-PLAY-1st')
	cmWl9dOKHPIy41iaXuxrY = IAW0sh6So3NpqM.content
	ed5GKJzygXNsS6il2 = ePhmG1jLD6.findall("var post_id	= '(.*?)'",cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	if ed5GKJzygXNsS6il2:
		MepIvHBYNArkUOdV37shtJ = ddBxj51bhNtaK23lDyGMVw+'/wp-admin/admin-ajax.php?action=video_info&post_id='+ed5GKJzygXNsS6il2[0]
		headers = {'Referer':url}
		IAW0sh6So3NpqM = WWrExJZS3Bj4anOAkpv7(kUz8c7OqsxuPFIGfwg,'GET',MepIvHBYNArkUOdV37shtJ,qpFY4hAwolV3,headers,qpFY4hAwolV3,qpFY4hAwolV3,'SHOOFNET-PLAY-2nd')
		cmWl9dOKHPIy41iaXuxrY = IAW0sh6So3NpqM.content
		items = ePhmG1jLD6.findall('"name":"(.*?)","src":"(.*?)"',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
		for title,MepIvHBYNArkUOdV37shtJ in items:
			title = N8E37XwL6iQbmBY(title)
			MepIvHBYNArkUOdV37shtJ = MepIvHBYNArkUOdV37shtJ.replace('\\/',ShynO8pN9idCE3)
			MepIvHBYNArkUOdV37shtJ = MepIvHBYNArkUOdV37shtJ+'?named='+title+'__watch'
			tiYp9ZdbFTQMcB4vWkHw6LXIAKrN5m.append(MepIvHBYNArkUOdV37shtJ)
	import inVXFK46ET
	inVXFK46ET.q4qTJvuoQUzM3mZAtegy7IXdnb5wH(tiYp9ZdbFTQMcB4vWkHw6LXIAKrN5m,Q8Q0IDc6PLZajJAdTntKUmSGXz,'video',url)
	return
def PPqUACSE3VcGLTvw05jHy9JrFNW(search):
	search,LBylNhMdH6OV1qGk0tWiXFg3,showDialogs = LLm3sBXHPcnTDxdE5gt6hz0Wkp(search)
	if search==qpFY4hAwolV3: search = jXgARlWMLVFUBnvmZwI2o5()
	if search==qpFY4hAwolV3: return
	search = search.replace(mIsDke0oK5x1zSiOWbF9thGcA,'+')
	url = ddBxj51bhNtaK23lDyGMVw+'/?s='+search
	c8U1BdtxOZS5FH(url,'search')
	return