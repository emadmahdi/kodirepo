# -*- coding: utf-8 -*-
from pSfaryIjBo import *
Q8Q0IDc6PLZajJAdTntKUmSGXz = 'ARABICTOONS'
wwSFijdVJn1QgHW = '_ART_'
ddBxj51bhNtaK23lDyGMVw = i4bFG3rKE6.SITESURLS[Q8Q0IDc6PLZajJAdTntKUmSGXz][0]
def vTNE2Ck1sGnugJYW8y39aLcSH64U(mode,url,text):
	if   mode==730: MOTjA5H9XFs = nRVAZc4Dp8PSrGU3xBk()
	elif mode==731: MOTjA5H9XFs = c8U1BdtxOZS5FH(url,text)
	elif mode==732: MOTjA5H9XFs = mzcAeyplZV(url)
	elif mode==733: MOTjA5H9XFs = v1gmfxDcRrWKQ(url)
	elif mode==734: MOTjA5H9XFs = kqT3bILCsBv1nxJSPZyiVHtQ(url)
	elif mode==735: MOTjA5H9XFs = kwgbSlZUBQR0c(url)
	elif mode==739: MOTjA5H9XFs = PPqUACSE3VcGLTvw05jHy9JrFNW(text)
	else: MOTjA5H9XFs = False
	return MOTjA5H9XFs
def nRVAZc4Dp8PSrGU3xBk():
	x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+'بحث في الموقع',qpFY4hAwolV3,739,qpFY4hAwolV3,qpFY4hAwolV3,'_REMEMBERRESULTS_')
	x3WSXnKyPhjqfHG2UrtQs('link',xupTj02bvy3O8R+' ===== ===== ===== '+fF4lt9zWYxXLKZVyAco82PgMj,qpFY4hAwolV3,9999)
	x3WSXnKyPhjqfHG2UrtQs('folder',Q8Q0IDc6PLZajJAdTntKUmSGXz+'_SCRIPT_'+wwSFijdVJn1QgHW+'افلام',ddBxj51bhNtaK23lDyGMVw+'/movies.php',731)
	x3WSXnKyPhjqfHG2UrtQs('folder',Q8Q0IDc6PLZajJAdTntKUmSGXz+'_SCRIPT_'+wwSFijdVJn1QgHW+'مسلسلات',ddBxj51bhNtaK23lDyGMVw+'/cartoon.php',734)
	x3WSXnKyPhjqfHG2UrtQs('folder',Q8Q0IDc6PLZajJAdTntKUmSGXz+'_SCRIPT_'+wwSFijdVJn1QgHW+'مسلسلات مميزة',ddBxj51bhNtaK23lDyGMVw+'/top.php',735)
	x3WSXnKyPhjqfHG2UrtQs('folder',Q8Q0IDc6PLZajJAdTntKUmSGXz+'_SCRIPT_'+wwSFijdVJn1QgHW+'أحدث الأفلام المضافة',ddBxj51bhNtaK23lDyGMVw,731,'','','LATEST_MOVIES')
	x3WSXnKyPhjqfHG2UrtQs('folder',Q8Q0IDc6PLZajJAdTntKUmSGXz+'_SCRIPT_'+wwSFijdVJn1QgHW+'أحدث المسلسلات المضافة',ddBxj51bhNtaK23lDyGMVw,731,'','','LATEST_SERIES')
	return
def kqT3bILCsBv1nxJSPZyiVHtQ(url):
	x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+'الكل',url,731)
	IAW0sh6So3NpqM = WWrExJZS3Bj4anOAkpv7(kUz8c7OqsxuPFIGfwg,'GET',url,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,'ARABICTOONS-SERIES_SUBMENU-1st')
	cmWl9dOKHPIy41iaXuxrY = IAW0sh6So3NpqM.content
	pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('label="navigation"(.*?)</ul>',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	if pfRkcVlLmUxo561g0A8qSbO:
		mVYdjvor6i4wZ8 = pfRkcVlLmUxo561g0A8qSbO[0]
		items = ePhmG1jLD6.findall("href='(.*?)'>(.*?)</a>",mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
		for MepIvHBYNArkUOdV37shtJ,title in items:
			MepIvHBYNArkUOdV37shtJ = ddBxj51bhNtaK23lDyGMVw+ShynO8pN9idCE3+MepIvHBYNArkUOdV37shtJ
			title = 'حرف '+title
			x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,731)
	return
def kwgbSlZUBQR0c(url):
	IAW0sh6So3NpqM = WWrExJZS3Bj4anOAkpv7(kUz8c7OqsxuPFIGfwg,'GET',url,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,'ARABICTOONS-SERIES_FEATURED-2nd')
	cmWl9dOKHPIy41iaXuxrY = IAW0sh6So3NpqM.content
	pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('class="slider"(.*?)</ul>',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	if pfRkcVlLmUxo561g0A8qSbO:
		mVYdjvor6i4wZ8 = pfRkcVlLmUxo561g0A8qSbO[0]
		items = ePhmG1jLD6.findall('title="(.*?)" href="(.*?)".*?src="(.*?)"',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
		for title,MepIvHBYNArkUOdV37shtJ,Sj7rMNYRuQPTtkBvpHKeDW3h in items:
			MepIvHBYNArkUOdV37shtJ = ddBxj51bhNtaK23lDyGMVw+ShynO8pN9idCE3+MepIvHBYNArkUOdV37shtJ
			Sj7rMNYRuQPTtkBvpHKeDW3h = ddBxj51bhNtaK23lDyGMVw+ShynO8pN9idCE3+Sj7rMNYRuQPTtkBvpHKeDW3h
			title = title.strip(mIsDke0oK5x1zSiOWbF9thGcA)
			x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,733,Sj7rMNYRuQPTtkBvpHKeDW3h)
	return
def c8U1BdtxOZS5FH(url,AMbRf4XTpQNvio6J5GELducy0k):
	IAW0sh6So3NpqM = WWrExJZS3Bj4anOAkpv7(kUz8c7OqsxuPFIGfwg,'GET',url,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,'ARABICTOONS-TITLES-1st')
	cmWl9dOKHPIy41iaXuxrY = IAW0sh6So3NpqM.content
	pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall("class='moviesBlocks(.*?)list-group",cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	if AMbRf4XTpQNvio6J5GELducy0k=='LATEST_SERIES': mVYdjvor6i4wZ8 = pfRkcVlLmUxo561g0A8qSbO[1]
	else: mVYdjvor6i4wZ8 = pfRkcVlLmUxo561g0A8qSbO[0]
	items = ePhmG1jLD6.findall('class="movie.*?href="(.*?)".*?src="(.*?)".*?title="(.*?)"',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
	for MepIvHBYNArkUOdV37shtJ,Sj7rMNYRuQPTtkBvpHKeDW3h,title in items:
		MepIvHBYNArkUOdV37shtJ = ddBxj51bhNtaK23lDyGMVw+ShynO8pN9idCE3+MepIvHBYNArkUOdV37shtJ
		Sj7rMNYRuQPTtkBvpHKeDW3h = ddBxj51bhNtaK23lDyGMVw+ShynO8pN9idCE3+Sj7rMNYRuQPTtkBvpHKeDW3h
		title = title.strip(mIsDke0oK5x1zSiOWbF9thGcA)
		if 'movies.php' in url or AMbRf4XTpQNvio6J5GELducy0k=='LATEST_MOVIES':
			x3WSXnKyPhjqfHG2UrtQs('video',wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,732,Sj7rMNYRuQPTtkBvpHKeDW3h)
		else: x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,733,Sj7rMNYRuQPTtkBvpHKeDW3h)
	pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('"pagination(.*?)</ul>',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	if pfRkcVlLmUxo561g0A8qSbO:
		mVYdjvor6i4wZ8 = pfRkcVlLmUxo561g0A8qSbO[-1]
		items = ePhmG1jLD6.findall('href="(.*?)".*?>(.*?)</a>',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
		for MepIvHBYNArkUOdV37shtJ,title in items:
			MepIvHBYNArkUOdV37shtJ = ddBxj51bhNtaK23lDyGMVw+ShynO8pN9idCE3+MepIvHBYNArkUOdV37shtJ
			title = title.strip(mIsDke0oK5x1zSiOWbF9thGcA)
			title = j8PDV0pthfSTidZbsQxNIOmCYKWzH(title)
			x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+'صفحة '+title,MepIvHBYNArkUOdV37shtJ,731)
	return
def v1gmfxDcRrWKQ(url):
	IAW0sh6So3NpqM = WWrExJZS3Bj4anOAkpv7(kUz8c7OqsxuPFIGfwg,'GET',url,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,'ARABICTOONS-EPISODES-1st')
	cmWl9dOKHPIy41iaXuxrY = IAW0sh6So3NpqM.content
	pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall("class='moviesBlocks(.*?)script",cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	if pfRkcVlLmUxo561g0A8qSbO:
		mVYdjvor6i4wZ8 = pfRkcVlLmUxo561g0A8qSbO[0]
		items = ePhmG1jLD6.findall('class="movie.*?href="(.*?)".*?badge-light ">(.*?)<.*?src="(.*?)"',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
		for MepIvHBYNArkUOdV37shtJ,title,Sj7rMNYRuQPTtkBvpHKeDW3h in items:
			MepIvHBYNArkUOdV37shtJ = ddBxj51bhNtaK23lDyGMVw+ShynO8pN9idCE3+MepIvHBYNArkUOdV37shtJ
			Sj7rMNYRuQPTtkBvpHKeDW3h = ddBxj51bhNtaK23lDyGMVw+ShynO8pN9idCE3+Sj7rMNYRuQPTtkBvpHKeDW3h
			title = title.strip()
			x3WSXnKyPhjqfHG2UrtQs('video',wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,732,Sj7rMNYRuQPTtkBvpHKeDW3h)
	return
def mzcAeyplZV(url):
	tiYp9ZdbFTQMcB4vWkHw6LXIAKrN5m = []
	IAW0sh6So3NpqM = WWrExJZS3Bj4anOAkpv7(kUz8c7OqsxuPFIGfwg,'GET',url,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,'ARABICTOONS-PLAY-1st')
	cmWl9dOKHPIy41iaXuxrY = IAW0sh6So3NpqM.content
	MepIvHBYNArkUOdV37shtJ = ePhmG1jLD6.findall('videoSrc = "(.*?)"',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	if MepIvHBYNArkUOdV37shtJ:
		MepIvHBYNArkUOdV37shtJ = MepIvHBYNArkUOdV37shtJ[0]
		MepIvHBYNArkUOdV37shtJ = MepIvHBYNArkUOdV37shtJ+'|Sec-Fetch-Dest=video'
		tiYp9ZdbFTQMcB4vWkHw6LXIAKrN5m.append(MepIvHBYNArkUOdV37shtJ+'?named=__embed')
	pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('"player-choice-form"(.*?)</form>',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	if pfRkcVlLmUxo561g0A8qSbO:
		mVYdjvor6i4wZ8 = pfRkcVlLmUxo561g0A8qSbO[0]
		items = ePhmG1jLD6.findall('value="(.*?)".*?"btn-text">(.*?)<',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
		for choice,title in items:
			MepIvHBYNArkUOdV37shtJ = url+'?player_choice='+choice+'&form_submitted=1'
			tiYp9ZdbFTQMcB4vWkHw6LXIAKrN5m.append(MepIvHBYNArkUOdV37shtJ+'?named='+title+'__watch')
	qqzMc6ZKkBslJthFpLxmTdHO9riXuI = ePhmG1jLD6.findall(r'dynamique.*?}\);', cmWl9dOKHPIy41iaXuxrY, ePhmG1jLD6.DOTALL)
	if not qqzMc6ZKkBslJthFpLxmTdHO9riXuI: qqzMc6ZKkBslJthFpLxmTdHO9riXuI = ePhmG1jLD6.findall(r'dynamique.*?}\)', cmWl9dOKHPIy41iaXuxrY, ePhmG1jLD6.DOTALL)
	if qqzMc6ZKkBslJthFpLxmTdHO9riXuI:
		iGu4DPXEQUIblCr = qqzMc6ZKkBslJthFpLxmTdHO9riXuI[0]
		ZEVp34nqiXkCTJ2FvQmLYd = dict(ePhmG1jLD6.findall(r'(\w+):\s*"([^"]+)"', iGu4DPXEQUIblCr))
		Q1JNLHofwu4STg9y = ePhmG1jLD6.search(r'const\s+(\w+)', iGu4DPXEQUIblCr)
		JJAsQ4pRYXPhqugN2to9TEzLIS = Q1JNLHofwu4STg9y.group(1) if Q1JNLHofwu4STg9y else ""
		keys = ePhmG1jLD6.findall(r'\$\{' + JJAsQ4pRYXPhqugN2to9TEzLIS + r'\.(\w+)\}', iGu4DPXEQUIblCr)
		if ZEVp34nqiXkCTJ2FvQmLYd and keys:
			MepIvHBYNArkUOdV37shtJ = "%s://%s/%s?%s" % (ZEVp34nqiXkCTJ2FvQmLYd[keys[0]], ZEVp34nqiXkCTJ2FvQmLYd[keys[1]], ZEVp34nqiXkCTJ2FvQmLYd[keys[2]], ZEVp34nqiXkCTJ2FvQmLYd[keys[3]])
			tiYp9ZdbFTQMcB4vWkHw6LXIAKrN5m.append(MepIvHBYNArkUOdV37shtJ+'?named=__embed')
	MepIvHBYNArkUOdV37shtJ = ePhmG1jLD6.findall('source src="http(.*?)"',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	if MepIvHBYNArkUOdV37shtJ:
		MepIvHBYNArkUOdV37shtJ = MepIvHBYNArkUOdV37shtJ[0]
		if 'Referer=' not in MepIvHBYNArkUOdV37shtJ: MepIvHBYNArkUOdV37shtJ = MepIvHBYNArkUOdV37shtJ+'|Referer=https://www.arabic-toons.com'
		tiYp9ZdbFTQMcB4vWkHw6LXIAKrN5m.append(MepIvHBYNArkUOdV37shtJ+'?named=__embed')
	import inVXFK46ET
	inVXFK46ET.q4qTJvuoQUzM3mZAtegy7IXdnb5wH(tiYp9ZdbFTQMcB4vWkHw6LXIAKrN5m,Q8Q0IDc6PLZajJAdTntKUmSGXz,'video',url)
	return
def PPqUACSE3VcGLTvw05jHy9JrFNW(search):
	search,LBylNhMdH6OV1qGk0tWiXFg3,showDialogs = LLm3sBXHPcnTDxdE5gt6hz0Wkp(search)
	if search==qpFY4hAwolV3: search = jXgARlWMLVFUBnvmZwI2o5()
	if search==qpFY4hAwolV3: return
	search = search.replace(mIsDke0oK5x1zSiOWbF9thGcA,'%20')
	U7V0BQZPxXqMbyJnRw6f = [qpFY4hAwolV3,'m']
	HHXPdv1aOo8WAZYIn0NFQ = ['مسلسلات','افلام']
	if showDialogs:
		ndm6kKswPpgGHNEbtB = xVzqWbrFXJ('اختر النوع المطلوب:', HHXPdv1aOo8WAZYIn0NFQ)
		if ndm6kKswPpgGHNEbtB==-1: return
	else: ndm6kKswPpgGHNEbtB = 0
	type = U7V0BQZPxXqMbyJnRw6f[ndm6kKswPpgGHNEbtB]
	url = ddBxj51bhNtaK23lDyGMVw+'/livesearch.php?'+type+'&q='+search
	IAW0sh6So3NpqM = WWrExJZS3Bj4anOAkpv7(kUz8c7OqsxuPFIGfwg,'GET',url,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,'ARABICTOONS-SEARCH-1st')
	cmWl9dOKHPIy41iaXuxrY = IAW0sh6So3NpqM.content
	items = ePhmG1jLD6.findall('href="(.*?)">(.*?)<',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	for MepIvHBYNArkUOdV37shtJ,title in items:
		MepIvHBYNArkUOdV37shtJ = ddBxj51bhNtaK23lDyGMVw+ShynO8pN9idCE3+MepIvHBYNArkUOdV37shtJ
		title = title.strip(mIsDke0oK5x1zSiOWbF9thGcA)
		if type=='m': x3WSXnKyPhjqfHG2UrtQs('video',wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,732)
		else: x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,733)
	return