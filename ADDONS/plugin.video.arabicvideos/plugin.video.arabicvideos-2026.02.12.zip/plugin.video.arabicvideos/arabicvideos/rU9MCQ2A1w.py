# -*- coding: utf-8 -*-
from pSfaryIjBo import *
Q8Q0IDc6PLZajJAdTntKUmSGXz = 'BOKRA'
wwSFijdVJn1QgHW = '_BKR_'
ddBxj51bhNtaK23lDyGMVw = i4bFG3rKE6.SITESURLS[Q8Q0IDc6PLZajJAdTntKUmSGXz][0]
headers = {'User-Agent':qpFY4hAwolV3}
YEIA19ehBwpNfPVzK = ['افلام للكبار','بكرا TV']
def vTNE2Ck1sGnugJYW8y39aLcSH64U(mode,url,text):
	if   mode==370: MOTjA5H9XFs = nRVAZc4Dp8PSrGU3xBk()
	elif mode==371: MOTjA5H9XFs = c8U1BdtxOZS5FH(url,text)
	elif mode==372: MOTjA5H9XFs = mzcAeyplZV(url)
	elif mode==374: MOTjA5H9XFs = IW9tAFZaoXkRMLq4jB5ev(url)
	elif mode==375: MOTjA5H9XFs = DZVXoSzp8PexHucRJdfFnG1tv(url)
	elif mode==376: MOTjA5H9XFs = eIH1JwrZF6N7kydfKuDBX0Qsjlx9(0,url)
	elif mode==377: MOTjA5H9XFs = eIH1JwrZF6N7kydfKuDBX0Qsjlx9(1,url)
	elif mode==379: MOTjA5H9XFs = PPqUACSE3VcGLTvw05jHy9JrFNW(text)
	else: MOTjA5H9XFs = False
	return MOTjA5H9XFs
def nRVAZc4Dp8PSrGU3xBk():
	IAW0sh6So3NpqM = WWrExJZS3Bj4anOAkpv7(KOyPvpEztYLaZRdMQJWxfTNFHbkg,'GET',ddBxj51bhNtaK23lDyGMVw,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,'BOKRA-MENU-1st')
	x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+'بحث في الموقع',qpFY4hAwolV3,379,qpFY4hAwolV3,qpFY4hAwolV3,'_REMEMBERRESULTS_')
	x3WSXnKyPhjqfHG2UrtQs('link',xupTj02bvy3O8R+' ===== ===== ===== '+fF4lt9zWYxXLKZVyAco82PgMj,qpFY4hAwolV3,9999)
	cmWl9dOKHPIy41iaXuxrY = IAW0sh6So3NpqM.content
	pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('right-side(.*?)</ul>',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	if pfRkcVlLmUxo561g0A8qSbO:
		mVYdjvor6i4wZ8 = pfRkcVlLmUxo561g0A8qSbO[0]
		items = ePhmG1jLD6.findall('href="(.*?)">(.*?)<',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
		for MepIvHBYNArkUOdV37shtJ,title in items:
			MepIvHBYNArkUOdV37shtJ = ddBxj51bhNtaK23lDyGMVw+MepIvHBYNArkUOdV37shtJ
			if not any(value in title for value in YEIA19ehBwpNfPVzK):
				x3WSXnKyPhjqfHG2UrtQs('folder',Q8Q0IDc6PLZajJAdTntKUmSGXz+'_SCRIPT_'+wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,371)
	x3WSXnKyPhjqfHG2UrtQs('folder',Q8Q0IDc6PLZajJAdTntKUmSGXz+'_SCRIPT_'+wwSFijdVJn1QgHW+'المميزة',ddBxj51bhNtaK23lDyGMVw,375)
	x3WSXnKyPhjqfHG2UrtQs('folder',Q8Q0IDc6PLZajJAdTntKUmSGXz+'_SCRIPT_'+wwSFijdVJn1QgHW+'الأحدث',ddBxj51bhNtaK23lDyGMVw,376)
	x3WSXnKyPhjqfHG2UrtQs('folder',Q8Q0IDc6PLZajJAdTntKUmSGXz+'_SCRIPT_'+wwSFijdVJn1QgHW+'قائمة الممثلين',ddBxj51bhNtaK23lDyGMVw,374)
	x3WSXnKyPhjqfHG2UrtQs('link',xupTj02bvy3O8R+' ===== ===== ===== '+fF4lt9zWYxXLKZVyAco82PgMj,qpFY4hAwolV3,9999)
	pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('class="container"(.*?)top-menu',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	if pfRkcVlLmUxo561g0A8qSbO:
		mVYdjvor6i4wZ8 = pfRkcVlLmUxo561g0A8qSbO[0]
		items = ePhmG1jLD6.findall('href="(.*?)">(.*?)<',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
		for MepIvHBYNArkUOdV37shtJ,title in items[7:]:
			title = title.strip(mIsDke0oK5x1zSiOWbF9thGcA)
			MepIvHBYNArkUOdV37shtJ = ddBxj51bhNtaK23lDyGMVw+MepIvHBYNArkUOdV37shtJ
			if not any(value in title for value in YEIA19ehBwpNfPVzK):
				x3WSXnKyPhjqfHG2UrtQs('folder',Q8Q0IDc6PLZajJAdTntKUmSGXz+'_SCRIPT_'+wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,371)
		for MepIvHBYNArkUOdV37shtJ,title in items[0:7]:
			title = title.strip(mIsDke0oK5x1zSiOWbF9thGcA)
			MepIvHBYNArkUOdV37shtJ = ddBxj51bhNtaK23lDyGMVw+MepIvHBYNArkUOdV37shtJ
			if not any(value in title for value in YEIA19ehBwpNfPVzK):
				x3WSXnKyPhjqfHG2UrtQs('folder',Q8Q0IDc6PLZajJAdTntKUmSGXz+'_SCRIPT_'+wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,371)
	return
def IW9tAFZaoXkRMLq4jB5ev(website=qpFY4hAwolV3):
	IAW0sh6So3NpqM = WWrExJZS3Bj4anOAkpv7(KOyPvpEztYLaZRdMQJWxfTNFHbkg,'GET',ddBxj51bhNtaK23lDyGMVw,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,'BOKRA-ACTORSMENU-1st')
	cmWl9dOKHPIy41iaXuxrY = IAW0sh6So3NpqM.content
	pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('class="row cat Tags"(.*?)</div>',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	if pfRkcVlLmUxo561g0A8qSbO:
		mVYdjvor6i4wZ8 = pfRkcVlLmUxo561g0A8qSbO[0]
		items = ePhmG1jLD6.findall('href="(.*?)" title="(.*?)"',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
		for MepIvHBYNArkUOdV37shtJ,title in items:
			if 'http' in MepIvHBYNArkUOdV37shtJ: continue
			else: MepIvHBYNArkUOdV37shtJ = ddBxj51bhNtaK23lDyGMVw+MepIvHBYNArkUOdV37shtJ
			if not any(value in title for value in YEIA19ehBwpNfPVzK):
				x3WSXnKyPhjqfHG2UrtQs('folder',Q8Q0IDc6PLZajJAdTntKUmSGXz+'_SCRIPT_'+wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,371)
	return
def DZVXoSzp8PexHucRJdfFnG1tv(website=qpFY4hAwolV3):
	IAW0sh6So3NpqM = WWrExJZS3Bj4anOAkpv7(rGY36xBwT1bLZAngSfcWEIeXdQVNij,'GET',ddBxj51bhNtaK23lDyGMVw,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,'BOKRA-FEATURED-1st')
	cmWl9dOKHPIy41iaXuxrY = IAW0sh6So3NpqM.content
	pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('"MainContent"(.*?)main-title2',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	if pfRkcVlLmUxo561g0A8qSbO:
		mVYdjvor6i4wZ8 = pfRkcVlLmUxo561g0A8qSbO[0]
		items = ePhmG1jLD6.findall('href="(/vidpage_.*?)".*? src="(.*?)".*?<h3>(.*?)</h3>',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
		for MepIvHBYNArkUOdV37shtJ,Sj7rMNYRuQPTtkBvpHKeDW3h,title in items:
			MepIvHBYNArkUOdV37shtJ = ddBxj51bhNtaK23lDyGMVw+MepIvHBYNArkUOdV37shtJ
			if not any(value in title for value in YEIA19ehBwpNfPVzK):
				Sj7rMNYRuQPTtkBvpHKeDW3h = Sj7rMNYRuQPTtkBvpHKeDW3h.replace('://',':///').replace(ttrDbyV5cSO2FjgTzew6qM,ShynO8pN9idCE3).replace(mIsDke0oK5x1zSiOWbF9thGcA,'%20')
				x3WSXnKyPhjqfHG2UrtQs('video',Q8Q0IDc6PLZajJAdTntKUmSGXz+'_SCRIPT_'+wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,372,Sj7rMNYRuQPTtkBvpHKeDW3h)
	return
def eIH1JwrZF6N7kydfKuDBX0Qsjlx9(id,website=qpFY4hAwolV3):
	IAW0sh6So3NpqM = WWrExJZS3Bj4anOAkpv7(rGY36xBwT1bLZAngSfcWEIeXdQVNij,'GET',ddBxj51bhNtaK23lDyGMVw,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,'BOKRA-WATCHINGNOW-1st')
	cmWl9dOKHPIy41iaXuxrY = IAW0sh6So3NpqM.content
	pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('main-title2(.*?)class="row',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	if pfRkcVlLmUxo561g0A8qSbO:
		mVYdjvor6i4wZ8 = pfRkcVlLmUxo561g0A8qSbO[id]
		items = ePhmG1jLD6.findall('href="(.*?)".*? src="(.*?)".*?<h4>(.*?)</h4>',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
		for MepIvHBYNArkUOdV37shtJ,Sj7rMNYRuQPTtkBvpHKeDW3h,title in items:
			MepIvHBYNArkUOdV37shtJ = ddBxj51bhNtaK23lDyGMVw+MepIvHBYNArkUOdV37shtJ
			if not any(value in title for value in YEIA19ehBwpNfPVzK):
				Sj7rMNYRuQPTtkBvpHKeDW3h = Sj7rMNYRuQPTtkBvpHKeDW3h.replace('://',':///').replace(ttrDbyV5cSO2FjgTzew6qM,ShynO8pN9idCE3).replace(mIsDke0oK5x1zSiOWbF9thGcA,'%20')
				x3WSXnKyPhjqfHG2UrtQs('video',Q8Q0IDc6PLZajJAdTntKUmSGXz+'_SCRIPT_'+wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,372,Sj7rMNYRuQPTtkBvpHKeDW3h)
	return
def c8U1BdtxOZS5FH(url,CNu3MSi9Yz4B=qpFY4hAwolV3):
	IAW0sh6So3NpqM = WWrExJZS3Bj4anOAkpv7(kUz8c7OqsxuPFIGfwg,'GET',url,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,'BOKRA-TITLES-1st')
	cmWl9dOKHPIy41iaXuxrY = IAW0sh6So3NpqM.content
	if 'vidpage_' in url:
		MepIvHBYNArkUOdV37shtJ = ePhmG1jLD6.findall('href="(/Album-.*?)"',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
		if MepIvHBYNArkUOdV37shtJ:
			MepIvHBYNArkUOdV37shtJ = ddBxj51bhNtaK23lDyGMVw+MepIvHBYNArkUOdV37shtJ[0]
			c8U1BdtxOZS5FH(MepIvHBYNArkUOdV37shtJ)
			return
	pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('class=" subcats"(.*?)class="col-md-3',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	if CNu3MSi9Yz4B==qpFY4hAwolV3 and pfRkcVlLmUxo561g0A8qSbO and pfRkcVlLmUxo561g0A8qSbO[0].count('href')>1:
		x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+'الجميع',url,371,qpFY4hAwolV3,qpFY4hAwolV3,'titles')
		mVYdjvor6i4wZ8 = pfRkcVlLmUxo561g0A8qSbO[0]
		items = ePhmG1jLD6.findall('href="(.*?)" title="(.*?)"',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
		for MepIvHBYNArkUOdV37shtJ,title in items:
			MepIvHBYNArkUOdV37shtJ = ddBxj51bhNtaK23lDyGMVw+ShynO8pN9idCE3+MepIvHBYNArkUOdV37shtJ
			title = title.strip(mIsDke0oK5x1zSiOWbF9thGcA)
			x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,371)
	else:
		aaCNAJdtsguSRELh2I = []
		pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('class="col-md-3(.*?)col-xs-12',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
		if not pfRkcVlLmUxo561g0A8qSbO: pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('class="col-sm-8"(.*?)col-xs-12',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
		if pfRkcVlLmUxo561g0A8qSbO:
			mVYdjvor6i4wZ8 = pfRkcVlLmUxo561g0A8qSbO[0]
			items = ePhmG1jLD6.findall('href="(.*?)".*?src="(.*?)".*?<h4>(.*?)</h4>',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
			for MepIvHBYNArkUOdV37shtJ,Sj7rMNYRuQPTtkBvpHKeDW3h,title in items:
				MepIvHBYNArkUOdV37shtJ = ddBxj51bhNtaK23lDyGMVw+MepIvHBYNArkUOdV37shtJ
				title = title.strip(mIsDke0oK5x1zSiOWbF9thGcA)
				Sj7rMNYRuQPTtkBvpHKeDW3h = Sj7rMNYRuQPTtkBvpHKeDW3h.replace('://',':///').replace(ttrDbyV5cSO2FjgTzew6qM,ShynO8pN9idCE3).replace(mIsDke0oK5x1zSiOWbF9thGcA,'%20')
				if '/al_' in MepIvHBYNArkUOdV37shtJ:
					x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,371,Sj7rMNYRuQPTtkBvpHKeDW3h)
				elif 'الحلقة' in title and ('/Cat-' in url or '/Search/' in url):
					ZDTxRSMbW7PNz = ePhmG1jLD6.findall('(.*?) - +الحلقة +\d+',title,ePhmG1jLD6.DOTALL)
					if ZDTxRSMbW7PNz: title = '_MOD_مسلسل '+ZDTxRSMbW7PNz[0]
					if title not in aaCNAJdtsguSRELh2I:
						aaCNAJdtsguSRELh2I.append(title)
						x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,371,Sj7rMNYRuQPTtkBvpHKeDW3h)
				else: x3WSXnKyPhjqfHG2UrtQs('video',wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,372,Sj7rMNYRuQPTtkBvpHKeDW3h)
		pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('class="pagination(.*?)</div>',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
		if pfRkcVlLmUxo561g0A8qSbO:
			mVYdjvor6i4wZ8 = pfRkcVlLmUxo561g0A8qSbO[0]
			items = ePhmG1jLD6.findall('class="".*?href="(.*?)">(.*?)<',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
			for MepIvHBYNArkUOdV37shtJ,title in items:
				MepIvHBYNArkUOdV37shtJ = ddBxj51bhNtaK23lDyGMVw+MepIvHBYNArkUOdV37shtJ
				title = 'صفحة '+j8PDV0pthfSTidZbsQxNIOmCYKWzH(title)
				x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,371,qpFY4hAwolV3,qpFY4hAwolV3,'titles')
	return
def mzcAeyplZV(url):
	IAW0sh6So3NpqM = WWrExJZS3Bj4anOAkpv7(rGY36xBwT1bLZAngSfcWEIeXdQVNij,'GET',url,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,'BOKRA-PLAY-1st')
	cmWl9dOKHPIy41iaXuxrY = IAW0sh6So3NpqM.content
	GIE2XSj0vVJPZA6dgmOs9TMDy8UkQW = ePhmG1jLD6.findall('label-success mrg-btm-5 ">(.*?)<',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	if GIE2XSj0vVJPZA6dgmOs9TMDy8UkQW and u0E18eO3HnCzr(Q8Q0IDc6PLZajJAdTntKUmSGXz,url,GIE2XSj0vVJPZA6dgmOs9TMDy8UkQW): return
	hhpztscnBD1GP = qpFY4hAwolV3
	WSQlG8mDhqsNe = ePhmG1jLD6.findall('var url = "(.*?)"',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	if WSQlG8mDhqsNe: WSQlG8mDhqsNe = WSQlG8mDhqsNe[0]
	else: WSQlG8mDhqsNe = url.replace('/vidpage_','/Play/')
	if 'http' not in WSQlG8mDhqsNe: WSQlG8mDhqsNe = ddBxj51bhNtaK23lDyGMVw+WSQlG8mDhqsNe
	WSQlG8mDhqsNe = WSQlG8mDhqsNe.strip('-')
	IAW0sh6So3NpqM = WWrExJZS3Bj4anOAkpv7(K6imQHZDCI9pewE,'GET',WSQlG8mDhqsNe,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,'BOKRA-PLAY-2nd')
	CC8IKXmYeo = IAW0sh6So3NpqM.content
	hhpztscnBD1GP = ePhmG1jLD6.findall('src="(.*?)"',CC8IKXmYeo,ePhmG1jLD6.DOTALL)
	if hhpztscnBD1GP:
		hhpztscnBD1GP = hhpztscnBD1GP[-1]
		if 'http' not in hhpztscnBD1GP: hhpztscnBD1GP = 'http:'+hhpztscnBD1GP
		if '/PLAY/' not in WSQlG8mDhqsNe:
			if 'embed.min.js' in hhpztscnBD1GP:
				cdm6LafhbuqCU = ePhmG1jLD6.findall('data-publisher-id="(.*?)" data-video-id="(.*?)"',CC8IKXmYeo,ePhmG1jLD6.DOTALL)
				if cdm6LafhbuqCU:
					tIs8x9MZvOyF4wb, Luw7aKckRf53ZnJ2A6qThFp1dg = cdm6LafhbuqCU[0]
					hhpztscnBD1GP = AWeJuo2LhZ5xiD8KNSqd9G0rtT74FE(hhpztscnBD1GP,'url')+'/v2/'+tIs8x9MZvOyF4wb+'/config/'+Luw7aKckRf53ZnJ2A6qThFp1dg+'.json'
		import inVXFK46ET
		inVXFK46ET.q4qTJvuoQUzM3mZAtegy7IXdnb5wH([hhpztscnBD1GP],Q8Q0IDc6PLZajJAdTntKUmSGXz,'video',url)
	return
def PPqUACSE3VcGLTvw05jHy9JrFNW(search):
	search,LBylNhMdH6OV1qGk0tWiXFg3,showDialogs = LLm3sBXHPcnTDxdE5gt6hz0Wkp(search)
	if search==qpFY4hAwolV3: search = jXgARlWMLVFUBnvmZwI2o5()
	if search==qpFY4hAwolV3: return
	search = search.replace(mIsDke0oK5x1zSiOWbF9thGcA,'+')
	url = ddBxj51bhNtaK23lDyGMVw+'/Search/'+search
	c8U1BdtxOZS5FH(url)
	return