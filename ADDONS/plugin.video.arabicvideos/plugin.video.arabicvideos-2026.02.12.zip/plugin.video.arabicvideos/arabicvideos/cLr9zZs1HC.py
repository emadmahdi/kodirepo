# -*- coding: utf-8 -*-
from pSfaryIjBo import *
Q8Q0IDc6PLZajJAdTntKUmSGXz = 'MOVS4U'
wwSFijdVJn1QgHW = '_M4U_'
ddBxj51bhNtaK23lDyGMVw = i4bFG3rKE6.SITESURLS[Q8Q0IDc6PLZajJAdTntKUmSGXz][0]
YEIA19ehBwpNfPVzK = ['انواع افلام','جودات افلام']
def vTNE2Ck1sGnugJYW8y39aLcSH64U(mode,url,text):
	if   mode==380: MOTjA5H9XFs = nRVAZc4Dp8PSrGU3xBk()
	elif mode==381: MOTjA5H9XFs = c8U1BdtxOZS5FH(url,text)
	elif mode==382: MOTjA5H9XFs = mzcAeyplZV(url)
	elif mode==383: MOTjA5H9XFs = v1gmfxDcRrWKQ(url)
	elif mode==389: MOTjA5H9XFs = PPqUACSE3VcGLTvw05jHy9JrFNW(text)
	else: MOTjA5H9XFs = False
	return MOTjA5H9XFs
def nRVAZc4Dp8PSrGU3xBk():
	x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+'بحث في الموقع',qpFY4hAwolV3,389,qpFY4hAwolV3,qpFY4hAwolV3,'_REMEMBERRESULTS_')
	x3WSXnKyPhjqfHG2UrtQs('link',xupTj02bvy3O8R+' ===== ===== ===== '+fF4lt9zWYxXLKZVyAco82PgMj,qpFY4hAwolV3,9999)
	x3WSXnKyPhjqfHG2UrtQs('folder',Q8Q0IDc6PLZajJAdTntKUmSGXz+'_SCRIPT_'+wwSFijdVJn1QgHW+'المميزة',ddBxj51bhNtaK23lDyGMVw,381,qpFY4hAwolV3,qpFY4hAwolV3,'featured')
	x3WSXnKyPhjqfHG2UrtQs('folder',Q8Q0IDc6PLZajJAdTntKUmSGXz+'_SCRIPT_'+wwSFijdVJn1QgHW+'الجانبية',ddBxj51bhNtaK23lDyGMVw,381,qpFY4hAwolV3,qpFY4hAwolV3,'sider')
	IAW0sh6So3NpqM = WWrExJZS3Bj4anOAkpv7(KOyPvpEztYLaZRdMQJWxfTNFHbkg,'GET',ddBxj51bhNtaK23lDyGMVw,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,'MOVS4U-MENU-1st')
	cmWl9dOKHPIy41iaXuxrY = IAW0sh6So3NpqM.content
	items = ePhmG1jLD6.findall('<header>.*?<h2>(.*?)<',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	for P71nY8vWLi4xBOr9tZVNRQzJUbSG6 in range(len(items)):
		title = items[P71nY8vWLi4xBOr9tZVNRQzJUbSG6]
		x3WSXnKyPhjqfHG2UrtQs('folder',Q8Q0IDc6PLZajJAdTntKUmSGXz+'_SCRIPT_'+wwSFijdVJn1QgHW+title,ddBxj51bhNtaK23lDyGMVw,381,qpFY4hAwolV3,qpFY4hAwolV3,'latest'+str(P71nY8vWLi4xBOr9tZVNRQzJUbSG6))
	mVYdjvor6i4wZ8 = qpFY4hAwolV3
	pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('class="menu"(.*?)id="contenedor"',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	if pfRkcVlLmUxo561g0A8qSbO: mVYdjvor6i4wZ8 += pfRkcVlLmUxo561g0A8qSbO[0]
	pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('class="sidebar(.*?)aside',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	if pfRkcVlLmUxo561g0A8qSbO: mVYdjvor6i4wZ8 += pfRkcVlLmUxo561g0A8qSbO[0]
	items = ePhmG1jLD6.findall('href="(.*?)">(.*?)<',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
	x3WSXnKyPhjqfHG2UrtQs('link',xupTj02bvy3O8R+' ===== ===== ===== '+fF4lt9zWYxXLKZVyAco82PgMj,qpFY4hAwolV3,9999)
	QrAXouklfYpzqd = True
	for MepIvHBYNArkUOdV37shtJ,title in items:
		title = j8PDV0pthfSTidZbsQxNIOmCYKWzH(title)
		if title=='الأعلى مشاهدة':
			if QrAXouklfYpzqd:
				title = 'الافلام '+title
				QrAXouklfYpzqd = False
			else: title = 'المسلسلات '+title
		if title not in YEIA19ehBwpNfPVzK:
			x3WSXnKyPhjqfHG2UrtQs('folder',Q8Q0IDc6PLZajJAdTntKUmSGXz+'_SCRIPT_'+wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,381)
	return cmWl9dOKHPIy41iaXuxrY
def c8U1BdtxOZS5FH(url,type):
	mVYdjvor6i4wZ8,items = [],[]
	IAW0sh6So3NpqM = WWrExJZS3Bj4anOAkpv7(kUz8c7OqsxuPFIGfwg,'GET',url,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,'MOVS4U-TITLES-1st')
	cmWl9dOKHPIy41iaXuxrY = IAW0sh6So3NpqM.content
	if type=='search':
		pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('class="search-page"(.*?)class="sidebar',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
		if pfRkcVlLmUxo561g0A8qSbO:
			mVYdjvor6i4wZ8 = pfRkcVlLmUxo561g0A8qSbO[0]
			items = ePhmG1jLD6.findall('img src="(.*?)".*?href="(.*?)">(.*?)<',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
	elif type=='sider':
		pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('class="widget(.*?)class="widget',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
		mVYdjvor6i4wZ8 = pfRkcVlLmUxo561g0A8qSbO[0]
		fPMvCobi0RlWQy2OLwHBXn1zDqgc = ePhmG1jLD6.findall('href="(.*?)".*?img src="(.*?)".*?<h3>(.*?)<',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
		U7V0BQZPxXqMbyJnRw6f,vtznksEwXcaC83AKQRWYZd96oI1L,QQLqrElamjfneR8GoP9IpuZ = zip(*fPMvCobi0RlWQy2OLwHBXn1zDqgc)
		items = zip(vtznksEwXcaC83AKQRWYZd96oI1L,U7V0BQZPxXqMbyJnRw6f,QQLqrElamjfneR8GoP9IpuZ)
	elif type=='featured':
		pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('id="slider-movies-tvshows"(.*?)<header>',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
		mVYdjvor6i4wZ8 = pfRkcVlLmUxo561g0A8qSbO[0]
		items = ePhmG1jLD6.findall('img src="(.*?)".*?href="(.*?)".*?"title">(.*?)<',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
	elif 'latest' in type:
		P71nY8vWLi4xBOr9tZVNRQzJUbSG6 = int(type[-1:])
		cmWl9dOKHPIy41iaXuxrY = cmWl9dOKHPIy41iaXuxrY.replace('<header>','<end><start>')
		cmWl9dOKHPIy41iaXuxrY = cmWl9dOKHPIy41iaXuxrY.replace('<div class="sidebar','<end><div class="sidebar')
		pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('<start>(.*?)<end>',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
		mVYdjvor6i4wZ8 = pfRkcVlLmUxo561g0A8qSbO[P71nY8vWLi4xBOr9tZVNRQzJUbSG6]
		if P71nY8vWLi4xBOr9tZVNRQzJUbSG6==2: items = ePhmG1jLD6.findall('img src="(.*?)".*?href="(.*?)">(.*?)<',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
	else:
		pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('class="content"(.*?)class="(pagination|sidebar)',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
		if pfRkcVlLmUxo561g0A8qSbO:
			mVYdjvor6i4wZ8 = pfRkcVlLmUxo561g0A8qSbO[0][0]
			if '/collection/' in url:
				items = ePhmG1jLD6.findall('img src="(.*?)".*?href="(.*?)">(.*?)<',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
			elif '/quality/' in url:
				items = ePhmG1jLD6.findall('img src="(.*?)".*?href="(.*?)".*?"title">(.*?)<',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
	if not items and mVYdjvor6i4wZ8:
		items = ePhmG1jLD6.findall('img src="(.*?)".*?href=.*?href="(.*?)">(.*?)</div>',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
	aaCNAJdtsguSRELh2I = []
	for Sj7rMNYRuQPTtkBvpHKeDW3h,MepIvHBYNArkUOdV37shtJ,title in items:
		if 'serie' in title:
			title = ePhmG1jLD6.findall('^(.*?)<.*?serie">(.*?)<',title,ePhmG1jLD6.DOTALL)
			title = title[0][1]
			if title in aaCNAJdtsguSRELh2I: continue
			aaCNAJdtsguSRELh2I.append(title)
			title = '_MOD_'+title
		UdbGw48M6rCHDRmea5qP91nKI = ePhmG1jLD6.findall('^(.*?)<',title,ePhmG1jLD6.DOTALL)
		if UdbGw48M6rCHDRmea5qP91nKI: title = UdbGw48M6rCHDRmea5qP91nKI[0]
		title = j8PDV0pthfSTidZbsQxNIOmCYKWzH(title)
		if '/tvshows/' in MepIvHBYNArkUOdV37shtJ: x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,383,Sj7rMNYRuQPTtkBvpHKeDW3h)
		elif '/episodes/' in MepIvHBYNArkUOdV37shtJ: x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,383,Sj7rMNYRuQPTtkBvpHKeDW3h)
		elif '/seasons/' in MepIvHBYNArkUOdV37shtJ: x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,383,Sj7rMNYRuQPTtkBvpHKeDW3h)
		elif '/collection/' in MepIvHBYNArkUOdV37shtJ: x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,381,Sj7rMNYRuQPTtkBvpHKeDW3h)
		else: x3WSXnKyPhjqfHG2UrtQs('video',wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,382,Sj7rMNYRuQPTtkBvpHKeDW3h)
	pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('class="pagination".*?Page (.*?) of (.*?)<(.*?)</div>',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	if pfRkcVlLmUxo561g0A8qSbO:
		iuor7FhO4IC6 = pfRkcVlLmUxo561g0A8qSbO[0][0]
		anEoq9LsSb6mU1 = pfRkcVlLmUxo561g0A8qSbO[0][1]
		mVYdjvor6i4wZ8 = pfRkcVlLmUxo561g0A8qSbO[0][2]
		items = ePhmG1jLD6.findall("href='(.*?)'.*?>(.*?)<",mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
		for MepIvHBYNArkUOdV37shtJ,title in items:
			if title==qpFY4hAwolV3 or title==anEoq9LsSb6mU1: continue
			x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+'صفحة '+title,MepIvHBYNArkUOdV37shtJ,381,qpFY4hAwolV3,qpFY4hAwolV3,type)
		MepIvHBYNArkUOdV37shtJ = MepIvHBYNArkUOdV37shtJ.replace('/page/'+title+ShynO8pN9idCE3,'/page/'+anEoq9LsSb6mU1+ShynO8pN9idCE3)
		x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+'اخر صفحة '+anEoq9LsSb6mU1,MepIvHBYNArkUOdV37shtJ,381,qpFY4hAwolV3,qpFY4hAwolV3,type)
	return
def v1gmfxDcRrWKQ(url):
	IAW0sh6So3NpqM = WWrExJZS3Bj4anOAkpv7(kUz8c7OqsxuPFIGfwg,'GET',url,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,'MOVS4U-EPISODES-1st')
	cmWl9dOKHPIy41iaXuxrY = IAW0sh6So3NpqM.content
	GIE2XSj0vVJPZA6dgmOs9TMDy8UkQW = ePhmG1jLD6.findall('class="C rated".*?>(.*?)<',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	if GIE2XSj0vVJPZA6dgmOs9TMDy8UkQW and u0E18eO3HnCzr(Q8Q0IDc6PLZajJAdTntKUmSGXz,url,GIE2XSj0vVJPZA6dgmOs9TMDy8UkQW,False):
		x3WSXnKyPhjqfHG2UrtQs('link',wwSFijdVJn1QgHW+'المسلسل للكبار والمبرمج منعه',qpFY4hAwolV3,9999)
		return
	if '/episodes/' in url or '/tvshows/' in url:
		WSQlG8mDhqsNe = ePhmG1jLD6.findall('''class='item'><a href="(.*?)"''',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
		if WSQlG8mDhqsNe:
			WSQlG8mDhqsNe = WSQlG8mDhqsNe[1]
			v1gmfxDcRrWKQ(WSQlG8mDhqsNe)
			return
	pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('''class='episodios'(.*?)id="cast"''',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	if pfRkcVlLmUxo561g0A8qSbO:
		mVYdjvor6i4wZ8 = pfRkcVlLmUxo561g0A8qSbO[0]
		items = ePhmG1jLD6.findall('''src='(.*?)'.*?class='numerando'>(.*?)<.*?href='(.*?)'>(.*?)<''',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
		for Sj7rMNYRuQPTtkBvpHKeDW3h,ZDTxRSMbW7PNz,MepIvHBYNArkUOdV37shtJ,name in items:
			title = ZDTxRSMbW7PNz+' : '+name+' الحلقة'
			x3WSXnKyPhjqfHG2UrtQs('video',wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,382)
	return
def mzcAeyplZV(url):
	IAW0sh6So3NpqM = WWrExJZS3Bj4anOAkpv7(kUz8c7OqsxuPFIGfwg,'GET',url,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,'MOVS4U-PLAY-1st')
	cmWl9dOKHPIy41iaXuxrY = IAW0sh6So3NpqM.content
	GIE2XSj0vVJPZA6dgmOs9TMDy8UkQW = ePhmG1jLD6.findall('class="C rated".*?>(.*?)<',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	if GIE2XSj0vVJPZA6dgmOs9TMDy8UkQW and u0E18eO3HnCzr(Q8Q0IDc6PLZajJAdTntKUmSGXz,url,GIE2XSj0vVJPZA6dgmOs9TMDy8UkQW): return
	U7V0BQZPxXqMbyJnRw6f = []
	pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('''id='player-option-1'(.*?)class=("sheader"|'pag_episodes')''',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	if pfRkcVlLmUxo561g0A8qSbO:
		mVYdjvor6i4wZ8 = pfRkcVlLmUxo561g0A8qSbO[0][0]
		items = ePhmG1jLD6.findall("data-url='(.*?)'.*?class='server'>(.*?)<",mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
		for MepIvHBYNArkUOdV37shtJ,title in items:
			MepIvHBYNArkUOdV37shtJ = MepIvHBYNArkUOdV37shtJ+'?named='+title+'__watch'
			U7V0BQZPxXqMbyJnRw6f.append(MepIvHBYNArkUOdV37shtJ)
	pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('class="remodal"(.*?)class="remodal-close"',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	if pfRkcVlLmUxo561g0A8qSbO:
		mVYdjvor6i4wZ8 = pfRkcVlLmUxo561g0A8qSbO[0]
		items = ePhmG1jLD6.findall('class="___dl_gdrive.*?href="(.*?)".*?">(.*?)<',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
		for MepIvHBYNArkUOdV37shtJ,title in items:
			MepIvHBYNArkUOdV37shtJ = ddBxj51bhNtaK23lDyGMVw+MepIvHBYNArkUOdV37shtJ
			MepIvHBYNArkUOdV37shtJ = MepIvHBYNArkUOdV37shtJ+'?named='+title+'__download'
			U7V0BQZPxXqMbyJnRw6f.append(MepIvHBYNArkUOdV37shtJ)
	import inVXFK46ET
	inVXFK46ET.q4qTJvuoQUzM3mZAtegy7IXdnb5wH(U7V0BQZPxXqMbyJnRw6f,Q8Q0IDc6PLZajJAdTntKUmSGXz,'video',url)
	return
def PPqUACSE3VcGLTvw05jHy9JrFNW(search):
	search,LBylNhMdH6OV1qGk0tWiXFg3,showDialogs = LLm3sBXHPcnTDxdE5gt6hz0Wkp(search)
	if search==qpFY4hAwolV3: search = jXgARlWMLVFUBnvmZwI2o5()
	if search==qpFY4hAwolV3: return
	search = search.replace(mIsDke0oK5x1zSiOWbF9thGcA,'+')
	url = ddBxj51bhNtaK23lDyGMVw+'/?s='+search
	c8U1BdtxOZS5FH(url,'search')
	return