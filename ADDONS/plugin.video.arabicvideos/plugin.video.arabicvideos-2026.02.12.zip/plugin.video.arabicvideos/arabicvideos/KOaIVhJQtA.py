# -*- coding: utf-8 -*-
from pSfaryIjBo import *
Q8Q0IDc6PLZajJAdTntKUmSGXz = 'FASELHD1'
headers = {'User-Agent':qpFY4hAwolV3}
wwSFijdVJn1QgHW = '_FH1_'
ddBxj51bhNtaK23lDyGMVw = i4bFG3rKE6.SITESURLS[Q8Q0IDc6PLZajJAdTntKUmSGXz][0]
YEIA19ehBwpNfPVzK = ['جوائز الأوسكار','المراجعات','wwe']
def vTNE2Ck1sGnugJYW8y39aLcSH64U(mode,url,text):
	if   mode==570: MOTjA5H9XFs = nRVAZc4Dp8PSrGU3xBk()
	elif mode==571: MOTjA5H9XFs = c8U1BdtxOZS5FH(url,text)
	elif mode==572: MOTjA5H9XFs = mzcAeyplZV(url)
	elif mode==573: MOTjA5H9XFs = eewkhcztmSDWKrPIX(url,text)
	elif mode==576: MOTjA5H9XFs = TJopmWqUYFQRi4l93KHPXNyZOj()
	elif mode==579: MOTjA5H9XFs = PPqUACSE3VcGLTvw05jHy9JrFNW(text)
	else: MOTjA5H9XFs = False
	return MOTjA5H9XFs
def nRVAZc4Dp8PSrGU3xBk():
	x3WSXnKyPhjqfHG2UrtQs('link',wwSFijdVJn1QgHW+'لماذا الموقع بطيء',qpFY4hAwolV3,576)
	iipsGz2LKq,url = ddBxj51bhNtaK23lDyGMVw,ddBxj51bhNtaK23lDyGMVw
	IAW0sh6So3NpqM = WWrExJZS3Bj4anOAkpv7(kUz8c7OqsxuPFIGfwg,'GET',url,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,'FASELHD1-MENU-1st')
	cmWl9dOKHPIy41iaXuxrY = IAW0sh6So3NpqM.content
	x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+'بحث في الموقع',iipsGz2LKq,579,qpFY4hAwolV3,qpFY4hAwolV3,'_REMEMBERRESULTS_')
	x3WSXnKyPhjqfHG2UrtQs('link',xupTj02bvy3O8R+' ===== ===== ===== '+fF4lt9zWYxXLKZVyAco82PgMj,qpFY4hAwolV3,9999)
	x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+'المميزة',iipsGz2LKq,571,qpFY4hAwolV3,qpFY4hAwolV3,'featured1')
	items = ePhmG1jLD6.findall('class="h3">(.*?)<.*?href="(.*?)"',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	for title,MepIvHBYNArkUOdV37shtJ in items:
		x3WSXnKyPhjqfHG2UrtQs('folder',Q8Q0IDc6PLZajJAdTntKUmSGXz+'_SCRIPT_'+wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,571,qpFY4hAwolV3,qpFY4hAwolV3,'details1')
	pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('"menu-primary"(.*?)</ul>',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	if pfRkcVlLmUxo561g0A8qSbO:
		mVYdjvor6i4wZ8 = pfRkcVlLmUxo561g0A8qSbO[0]
		ylaZeqO8cxV = ePhmG1jLD6.findall('<li (.*?)</li>',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
		ccHJ5Ri4FBKEn9t6I = [qpFY4hAwolV3,'أفلام: ','مسلسلات: ','برامج: ','آسيوي: ','أنمي: ']
		nnZ13Rr6tYXio0DyfLVvSxBec = 0
		for HZTvVym7W3M4Nh5CQe in ylaZeqO8cxV:
			if nnZ13Rr6tYXio0DyfLVvSxBec>0: x3WSXnKyPhjqfHG2UrtQs('link',xupTj02bvy3O8R+' ===== ===== ===== '+fF4lt9zWYxXLKZVyAco82PgMj,qpFY4hAwolV3,9999)
			items = ePhmG1jLD6.findall('href="(.*?)".*?>(.*?)<',HZTvVym7W3M4Nh5CQe,ePhmG1jLD6.DOTALL)
			for MepIvHBYNArkUOdV37shtJ,title in items:
				if MepIvHBYNArkUOdV37shtJ=='#': continue
				if 'http' not in MepIvHBYNArkUOdV37shtJ: MepIvHBYNArkUOdV37shtJ = iipsGz2LKq+MepIvHBYNArkUOdV37shtJ
				if title==qpFY4hAwolV3: continue
				if any(value in title.lower() for value in YEIA19ehBwpNfPVzK): continue
				title = ccHJ5Ri4FBKEn9t6I[nnZ13Rr6tYXio0DyfLVvSxBec]+title
				x3WSXnKyPhjqfHG2UrtQs('folder',Q8Q0IDc6PLZajJAdTntKUmSGXz+'_SCRIPT_'+wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,571,qpFY4hAwolV3,qpFY4hAwolV3,'details2')
			nnZ13Rr6tYXio0DyfLVvSxBec += 1
	return
def TJopmWqUYFQRi4l93KHPXNyZOj():
	iG7Rz2kmn0x1yLNMV3u8O(qpFY4hAwolV3,qpFY4hAwolV3,GLTtERWbHnFuy4PCp,'موقع فاصل الأول بطيء من المصدر .. بسبب قيام أصحاب الموقع بإضافة فحص وتحقق أمني ضد هجوم البرامج وهجوم القراصنة على صفحات الموقع .. والوقت الضائع يذهب في محاولة تجاوز هذا الفحص واثبات أن هذا البرنامج هو مجرد متصفح للمواقع ولا يقوم بالهجوم على المواقع')
	return
def c8U1BdtxOZS5FH(url,type=qpFY4hAwolV3):
	IAW0sh6So3NpqM = WWrExJZS3Bj4anOAkpv7(kUz8c7OqsxuPFIGfwg,'GET',url,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,'FASELHD1-TITLES-1st')
	cmWl9dOKHPIy41iaXuxrY = IAW0sh6So3NpqM.content
	T9TAc28ayKvFgjfd6SD = ePhmG1jLD6.findall('class="h4">(.*?)</div>(.*?)"container"',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	if not T9TAc28ayKvFgjfd6SD: return
	if type=='filters':
		pfRkcVlLmUxo561g0A8qSbO = [cmWl9dOKHPIy41iaXuxrY.replace('\\/',ShynO8pN9idCE3).replace('\\"','"')]
	elif type=='featured1':
		pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('"homeSlide"(.*?)"container"',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
		mVYdjvor6i4wZ8 = pfRkcVlLmUxo561g0A8qSbO[0]
		items = ePhmG1jLD6.findall(' src="(.*?)".*? href="(.*?)">(.*?)</a>',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
		rS1xqU30RcTwZsVDfuCyzKbLPoaX4,CFevtSjzbpn,EmejzBHJ28TqtDAZ74NUhF = zip(*items)
		items = zip(CFevtSjzbpn,rS1xqU30RcTwZsVDfuCyzKbLPoaX4,EmejzBHJ28TqtDAZ74NUhF)
	elif type=='featured2':
		title,mVYdjvor6i4wZ8 = T9TAc28ayKvFgjfd6SD[0]
		items = ePhmG1jLD6.findall('href="(.*?)".*? data-src="(.*?)".*? alt="(.*?)"',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
	elif type=='details2' and len(T9TAc28ayKvFgjfd6SD)>1:
		title = T9TAc28ayKvFgjfd6SD[0][0]
		x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+title,url,571,qpFY4hAwolV3,qpFY4hAwolV3,'featured2')
		title = T9TAc28ayKvFgjfd6SD[1][0]
		x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+title,url,571,qpFY4hAwolV3,qpFY4hAwolV3,'details3')
		return
	else:
		title,mVYdjvor6i4wZ8 = T9TAc28ayKvFgjfd6SD[-1]
		items = ePhmG1jLD6.findall('href="(.*?)".*? data-src="(.*?)".*?"h1">(.*?)<',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
	aaCNAJdtsguSRELh2I = []
	for MepIvHBYNArkUOdV37shtJ,Sj7rMNYRuQPTtkBvpHKeDW3h,title in items:
		if any(value in title.lower() for value in YEIA19ehBwpNfPVzK): continue
		Sj7rMNYRuQPTtkBvpHKeDW3h = N8E37XwL6iQbmBY(Sj7rMNYRuQPTtkBvpHKeDW3h)
		Sj7rMNYRuQPTtkBvpHKeDW3h = Sj7rMNYRuQPTtkBvpHKeDW3h.split('?resize=')[0]
		title = j8PDV0pthfSTidZbsQxNIOmCYKWzH(title)
		ZDTxRSMbW7PNz = ePhmG1jLD6.findall('(.*?) (الحلقة|حلقة).\d+',title,ePhmG1jLD6.DOTALL)
		if '/collections/' in MepIvHBYNArkUOdV37shtJ:
			x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,571,Sj7rMNYRuQPTtkBvpHKeDW3h)
		elif ZDTxRSMbW7PNz and type==qpFY4hAwolV3:
			title = '_MOD_'+ZDTxRSMbW7PNz[0][0]
			title = title.strip(' –')
			if title not in aaCNAJdtsguSRELh2I:
				x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,573,Sj7rMNYRuQPTtkBvpHKeDW3h)
				aaCNAJdtsguSRELh2I.append(title)
		elif 'episodes/' in MepIvHBYNArkUOdV37shtJ or 'movies/' in MepIvHBYNArkUOdV37shtJ or 'hindi/' in MepIvHBYNArkUOdV37shtJ:
			x3WSXnKyPhjqfHG2UrtQs('video',wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,572,Sj7rMNYRuQPTtkBvpHKeDW3h)
		else: x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,573,Sj7rMNYRuQPTtkBvpHKeDW3h)
	if type=='filters':
		ppB9zFEedcVZ4GXuwr0 = ePhmG1jLD6.findall('"more_button_page":(.*?),',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
		if ppB9zFEedcVZ4GXuwr0:
			count = ppB9zFEedcVZ4GXuwr0[0]
			MepIvHBYNArkUOdV37shtJ = url+'/offset/'+count
			x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+'صفحة أخرى',MepIvHBYNArkUOdV37shtJ,571,qpFY4hAwolV3,qpFY4hAwolV3,'filters')
	elif 'details' in type:
		pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall("class='pagination(.*?)</div>",cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
		if pfRkcVlLmUxo561g0A8qSbO:
			mVYdjvor6i4wZ8 = pfRkcVlLmUxo561g0A8qSbO[0]
			items = ePhmG1jLD6.findall("href='(.*?)'.*?>(.*?)<",mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
			for MepIvHBYNArkUOdV37shtJ,title in items:
				title = 'صفحة '+j8PDV0pthfSTidZbsQxNIOmCYKWzH(title)
				x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,571,qpFY4hAwolV3,qpFY4hAwolV3,'details4')
	return
def eewkhcztmSDWKrPIX(url,type=qpFY4hAwolV3):
	IAW0sh6So3NpqM = WWrExJZS3Bj4anOAkpv7(kUz8c7OqsxuPFIGfwg,'GET',url,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,'FASELHD1-SEASONS_EPISODES-1st')
	cmWl9dOKHPIy41iaXuxrY = IAW0sh6So3NpqM.content
	WWQOoJZpXFmLHnDht1j = False
	if not type:
		pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('"seasonList"(.*?)"container"',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
		if pfRkcVlLmUxo561g0A8qSbO:
			mVYdjvor6i4wZ8 = pfRkcVlLmUxo561g0A8qSbO[0]
			items = ePhmG1jLD6.findall('href = \'(.*?)\'.*? data-src="(.*?)".*?alt="(.*?)".*?"title">(.*?)</div>',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
			if len(items)>1:
				iipsGz2LKq = AWeJuo2LhZ5xiD8KNSqd9G0rtT74FE(url,'url')
				WWQOoJZpXFmLHnDht1j = True
				for MepIvHBYNArkUOdV37shtJ,Sj7rMNYRuQPTtkBvpHKeDW3h,name,title in items:
					name = j8PDV0pthfSTidZbsQxNIOmCYKWzH(name)
					if 'http' not in MepIvHBYNArkUOdV37shtJ: MepIvHBYNArkUOdV37shtJ = iipsGz2LKq+MepIvHBYNArkUOdV37shtJ
					title = name+' - '+title
					x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,573,Sj7rMNYRuQPTtkBvpHKeDW3h,qpFY4hAwolV3,'episodes')
	if type=='episodes' or not WWQOoJZpXFmLHnDht1j:
		BvbuigUeoJLnTaN2qWxQ415AtYMK9I = ePhmG1jLD6.findall('"posterImg".*?src="(.*?)"',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
		if BvbuigUeoJLnTaN2qWxQ415AtYMK9I: Sj7rMNYRuQPTtkBvpHKeDW3h = BvbuigUeoJLnTaN2qWxQ415AtYMK9I[0]
		else: Sj7rMNYRuQPTtkBvpHKeDW3h = qpFY4hAwolV3
		pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('"epAll"(.*?)</div>',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
		if pfRkcVlLmUxo561g0A8qSbO:
			mVYdjvor6i4wZ8 = pfRkcVlLmUxo561g0A8qSbO[0]
			items = ePhmG1jLD6.findall('href="(.*?)".*?>(.*?)</a>',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
			for MepIvHBYNArkUOdV37shtJ,title in items:
				title = title.strip(mIsDke0oK5x1zSiOWbF9thGcA)
				title = j8PDV0pthfSTidZbsQxNIOmCYKWzH(title)
				x3WSXnKyPhjqfHG2UrtQs('video',wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,572,Sj7rMNYRuQPTtkBvpHKeDW3h)
	return
def mzcAeyplZV(url):
	tiYp9ZdbFTQMcB4vWkHw6LXIAKrN5m,oXZHbnhjTlFK6x9O,rdkXS7oJ6bD = [],[],[]
	IAW0sh6So3NpqM = WWrExJZS3Bj4anOAkpv7(rGY36xBwT1bLZAngSfcWEIeXdQVNij,'GET',url,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,'FASELHD1-PLAY-1st')
	cmWl9dOKHPIy41iaXuxrY = IAW0sh6So3NpqM.content
	N39rcOfDjte7wUmVqsHK8ioB = ePhmG1jLD6.findall('مستوى المشاهدة.*?">(.*?)</span>',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	if N39rcOfDjte7wUmVqsHK8ioB:
		GIE2XSj0vVJPZA6dgmOs9TMDy8UkQW = ePhmG1jLD6.findall('"tag">(.*?)</a>',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
		if GIE2XSj0vVJPZA6dgmOs9TMDy8UkQW and u0E18eO3HnCzr(Q8Q0IDc6PLZajJAdTntKUmSGXz,url,GIE2XSj0vVJPZA6dgmOs9TMDy8UkQW): return
	pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('"videoRow"(.*?)</div>',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	if pfRkcVlLmUxo561g0A8qSbO:
		mVYdjvor6i4wZ8 = pfRkcVlLmUxo561g0A8qSbO[0]
		items = ePhmG1jLD6.findall('src="(.*?)"',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
		for MepIvHBYNArkUOdV37shtJ in items:
			MepIvHBYNArkUOdV37shtJ = MepIvHBYNArkUOdV37shtJ.split('&img=')[0]
			tiYp9ZdbFTQMcB4vWkHw6LXIAKrN5m.append(MepIvHBYNArkUOdV37shtJ+'?named=__embed')
	pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('class="streamHeader(.*?)</ul>',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	if pfRkcVlLmUxo561g0A8qSbO:
		mVYdjvor6i4wZ8 = pfRkcVlLmUxo561g0A8qSbO[0]
		items = ePhmG1jLD6.findall("href = '(.*?)'.*?</i>(.*?)</a>",mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
		for MepIvHBYNArkUOdV37shtJ,name in items:
			MepIvHBYNArkUOdV37shtJ = MepIvHBYNArkUOdV37shtJ.split('&img=')[0]
			name = name.strip(mIsDke0oK5x1zSiOWbF9thGcA)
			tiYp9ZdbFTQMcB4vWkHw6LXIAKrN5m.append(MepIvHBYNArkUOdV37shtJ+'?named='+name+'__watch')
	pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('class="downloadLinks(.*?)blackwindow',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	if pfRkcVlLmUxo561g0A8qSbO:
		mVYdjvor6i4wZ8 = pfRkcVlLmUxo561g0A8qSbO[0]
		items = ePhmG1jLD6.findall('href="(.*?)".*?</span>(.*?)</a>',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
		for MepIvHBYNArkUOdV37shtJ,name in items:
			MepIvHBYNArkUOdV37shtJ = MepIvHBYNArkUOdV37shtJ.split('&img=')[0]
			tiYp9ZdbFTQMcB4vWkHw6LXIAKrN5m.append(MepIvHBYNArkUOdV37shtJ+'?named='+name+'__download')
	for wonOFZLNYPThyXKbz7v2iUCJx6k in tiYp9ZdbFTQMcB4vWkHw6LXIAKrN5m:
		MepIvHBYNArkUOdV37shtJ,name = wonOFZLNYPThyXKbz7v2iUCJx6k.split('?named')
		if MepIvHBYNArkUOdV37shtJ not in oXZHbnhjTlFK6x9O:
			oXZHbnhjTlFK6x9O.append(MepIvHBYNArkUOdV37shtJ)
			rdkXS7oJ6bD.append(wonOFZLNYPThyXKbz7v2iUCJx6k)
	import inVXFK46ET
	inVXFK46ET.q4qTJvuoQUzM3mZAtegy7IXdnb5wH(rdkXS7oJ6bD,Q8Q0IDc6PLZajJAdTntKUmSGXz,'video',url)
	return
def PPqUACSE3VcGLTvw05jHy9JrFNW(search):
	search,LBylNhMdH6OV1qGk0tWiXFg3,showDialogs = LLm3sBXHPcnTDxdE5gt6hz0Wkp(search)
	if search==qpFY4hAwolV3: search = jXgARlWMLVFUBnvmZwI2o5()
	if search==qpFY4hAwolV3: return
	search = search.replace(mIsDke0oK5x1zSiOWbF9thGcA,'+')
	WSQlG8mDhqsNe = ddBxj51bhNtaK23lDyGMVw+'/?s='+search
	c8U1BdtxOZS5FH(WSQlG8mDhqsNe,'details5')
	return