# -*- coding: utf-8 -*-
from pSfaryIjBo import *
headers = { 'User-Agent' : qpFY4hAwolV3 }
Q8Q0IDc6PLZajJAdTntKUmSGXz = 'AKOAMCAM'
wwSFijdVJn1QgHW = '_AKC_'
ddBxj51bhNtaK23lDyGMVw = i4bFG3rKE6.SITESURLS[Q8Q0IDc6PLZajJAdTntKUmSGXz][0]
YEIA19ehBwpNfPVzK = ['مصارعة']
def vTNE2Ck1sGnugJYW8y39aLcSH64U(mode,url,text):
	if   mode==350: MOTjA5H9XFs = nRVAZc4Dp8PSrGU3xBk()
	elif mode==351: MOTjA5H9XFs = c8U1BdtxOZS5FH(url,text)
	elif mode==352: MOTjA5H9XFs = v1gmfxDcRrWKQ(url)
	elif mode==353: MOTjA5H9XFs = mzcAeyplZV(url)
	elif mode==354: MOTjA5H9XFs = R9pWUgVhBGLd2CQb0z(url,'FILTERS___'+text)
	elif mode==355: MOTjA5H9XFs = R9pWUgVhBGLd2CQb0z(url,'CATEGORIES___'+text)
	elif mode==356: MOTjA5H9XFs = TTeJxDswtly1q(url)
	elif mode==357: MOTjA5H9XFs = ITbnr8vt6KykEOwY0l7SzAfCDQmaJg(url)
	elif mode==359: MOTjA5H9XFs = PPqUACSE3VcGLTvw05jHy9JrFNW(text)
	else: MOTjA5H9XFs = False
	return MOTjA5H9XFs
def nRVAZc4Dp8PSrGU3xBk():
	x3WSXnKyPhjqfHG2UrtQs('link',wwSFijdVJn1QgHW+IQ2KCmObsTGuiRdEzt931a40jLg+'هذا الموقع مغلق'+fF4lt9zWYxXLKZVyAco82PgMj,qpFY4hAwolV3,8)
	x3WSXnKyPhjqfHG2UrtQs('link',xupTj02bvy3O8R+' ===== ===== ===== '+fF4lt9zWYxXLKZVyAco82PgMj,qpFY4hAwolV3,9999)
	x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+'بحث في الموقع',qpFY4hAwolV3,359,qpFY4hAwolV3,qpFY4hAwolV3,'_REMEMBERRESULTS_')
	x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+'فلتر محدد',ddBxj51bhNtaK23lDyGMVw,356)
	x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+'فلتر كامل',ddBxj51bhNtaK23lDyGMVw,357)
	x3WSXnKyPhjqfHG2UrtQs('link',xupTj02bvy3O8R+' ===== ===== ===== '+fF4lt9zWYxXLKZVyAco82PgMj,qpFY4hAwolV3,9999)
	cmWl9dOKHPIy41iaXuxrY = GMqfDK9V4F8eTPE1pNOAaiYUbhr(kUz8c7OqsxuPFIGfwg,ddBxj51bhNtaK23lDyGMVw,qpFY4hAwolV3,headers,qpFY4hAwolV3,'AKOAMCAM-MENU-1st')
	WSQlG8mDhqsNe = ePhmG1jLD6.findall('recently-container.*?href="(.*?)"',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	if WSQlG8mDhqsNe: WSQlG8mDhqsNe = WSQlG8mDhqsNe[0]
	else: WSQlG8mDhqsNe = ddBxj51bhNtaK23lDyGMVw
	x3WSXnKyPhjqfHG2UrtQs('folder',Q8Q0IDc6PLZajJAdTntKUmSGXz+'_SCRIPT_'+wwSFijdVJn1QgHW+'اضيف حديثا',WSQlG8mDhqsNe,351)
	WSQlG8mDhqsNe = ePhmG1jLD6.findall('@id":"(.*?)"',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	if WSQlG8mDhqsNe: WSQlG8mDhqsNe = WSQlG8mDhqsNe[0]
	else: WSQlG8mDhqsNe = ddBxj51bhNtaK23lDyGMVw
	x3WSXnKyPhjqfHG2UrtQs('folder',Q8Q0IDc6PLZajJAdTntKUmSGXz+'_SCRIPT_'+wwSFijdVJn1QgHW+'المميزة',WSQlG8mDhqsNe,351,qpFY4hAwolV3,qpFY4hAwolV3,'featured')
	pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('main-categories-list(.*?)main-categories-list',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	if pfRkcVlLmUxo561g0A8qSbO:
		mVYdjvor6i4wZ8 = pfRkcVlLmUxo561g0A8qSbO[0]
		items = ePhmG1jLD6.findall('href="(.*?)".*?class="font.*?>(.*?)<',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
		for MepIvHBYNArkUOdV37shtJ,title in items:
			if title not in YEIA19ehBwpNfPVzK: x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,351)
		x3WSXnKyPhjqfHG2UrtQs('link',xupTj02bvy3O8R+' ===== ===== ===== '+fF4lt9zWYxXLKZVyAco82PgMj,qpFY4hAwolV3,9999)
	pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('class="categories-box(.*?)<footer',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	if pfRkcVlLmUxo561g0A8qSbO:
		mVYdjvor6i4wZ8 = pfRkcVlLmUxo561g0A8qSbO[0]
		items = ePhmG1jLD6.findall('href="(.*?)".*?">(.*?)<',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
		for MepIvHBYNArkUOdV37shtJ,title in items:
			MepIvHBYNArkUOdV37shtJ = j8PDV0pthfSTidZbsQxNIOmCYKWzH(MepIvHBYNArkUOdV37shtJ)
			if title not in YEIA19ehBwpNfPVzK: x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,351)
	return cmWl9dOKHPIy41iaXuxrY
def TTeJxDswtly1q(website=qpFY4hAwolV3):
	cmWl9dOKHPIy41iaXuxrY = GMqfDK9V4F8eTPE1pNOAaiYUbhr(KOyPvpEztYLaZRdMQJWxfTNFHbkg,ddBxj51bhNtaK23lDyGMVw,qpFY4hAwolV3,headers,qpFY4hAwolV3,'AKOAMCAM-MENU-1st')
	pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('class="menu(.*?)<nav',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	if pfRkcVlLmUxo561g0A8qSbO:
		mVYdjvor6i4wZ8 = pfRkcVlLmUxo561g0A8qSbO[0]
		items = ePhmG1jLD6.findall('href="(.*?)".*?text">(.*?)<',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
		for MepIvHBYNArkUOdV37shtJ,title in items:
			if title not in YEIA19ehBwpNfPVzK:
				title = title+' مصنفة'
				x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,355)
		if website==qpFY4hAwolV3: x3WSXnKyPhjqfHG2UrtQs('link',xupTj02bvy3O8R+' ===== ===== ===== '+fF4lt9zWYxXLKZVyAco82PgMj,qpFY4hAwolV3,9999)
	return cmWl9dOKHPIy41iaXuxrY
def ITbnr8vt6KykEOwY0l7SzAfCDQmaJg(website=qpFY4hAwolV3):
	cmWl9dOKHPIy41iaXuxrY = GMqfDK9V4F8eTPE1pNOAaiYUbhr(KOyPvpEztYLaZRdMQJWxfTNFHbkg,ddBxj51bhNtaK23lDyGMVw,qpFY4hAwolV3,headers,qpFY4hAwolV3,'AKOAMCAM-MENU-1st')
	pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('class="menu(.*?)<nav',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	if pfRkcVlLmUxo561g0A8qSbO:
		mVYdjvor6i4wZ8 = pfRkcVlLmUxo561g0A8qSbO[0]
		items = ePhmG1jLD6.findall('href="(.*?)".*?text">(.*?)<',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
		for MepIvHBYNArkUOdV37shtJ,title in items:
			if title not in YEIA19ehBwpNfPVzK:
				title = title+' مفلترة'
				x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,354)
		if website==qpFY4hAwolV3: x3WSXnKyPhjqfHG2UrtQs('link',xupTj02bvy3O8R+' ===== ===== ===== '+fF4lt9zWYxXLKZVyAco82PgMj,qpFY4hAwolV3,9999)
	return cmWl9dOKHPIy41iaXuxrY
def c8U1BdtxOZS5FH(url,type=qpFY4hAwolV3):
	cmWl9dOKHPIy41iaXuxrY = GMqfDK9V4F8eTPE1pNOAaiYUbhr(dzcNuIbsgK3yZ6SXGaEHPfOj5vk,url,qpFY4hAwolV3,headers,True,'AKOAMCAM-TITLES-1st')
	if type=='featured': pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('swiper-container(.*?)swiper-button-prev',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	else: pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('class="container"(.*?)main-footer',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	if pfRkcVlLmUxo561g0A8qSbO:
		mVYdjvor6i4wZ8 = pfRkcVlLmUxo561g0A8qSbO[0]
		items = ePhmG1jLD6.findall('xlink:href="(.*?)".*?href="(.*?)".*?text-white">(.*?)<',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
		aaCNAJdtsguSRELh2I = []
		for Sj7rMNYRuQPTtkBvpHKeDW3h,MepIvHBYNArkUOdV37shtJ,title in items:
			title = j8PDV0pthfSTidZbsQxNIOmCYKWzH(title)
			if 'الحلقة' in title or 'الحلقه' in title:
				ZDTxRSMbW7PNz = ePhmG1jLD6.findall('(.*?) (الحلقة|الحلقه) \d+',title,ePhmG1jLD6.DOTALL)
				if ZDTxRSMbW7PNz:
					title = '_MOD_' + ZDTxRSMbW7PNz[0][0]
					if title not in aaCNAJdtsguSRELh2I:
						x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,352,Sj7rMNYRuQPTtkBvpHKeDW3h)
						aaCNAJdtsguSRELh2I.append(title)
			elif 'مسلسل' in title:
				x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,352,Sj7rMNYRuQPTtkBvpHKeDW3h)
			else: x3WSXnKyPhjqfHG2UrtQs('video',wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,353,Sj7rMNYRuQPTtkBvpHKeDW3h)
	pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('pagination(.*?)</div>',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	if pfRkcVlLmUxo561g0A8qSbO:
		mVYdjvor6i4wZ8 = pfRkcVlLmUxo561g0A8qSbO[0]
		items = ePhmG1jLD6.findall('href=["\'](.*?)["\'].*?>(.*?)<',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
		for MepIvHBYNArkUOdV37shtJ,title in items:
			MepIvHBYNArkUOdV37shtJ = j8PDV0pthfSTidZbsQxNIOmCYKWzH(MepIvHBYNArkUOdV37shtJ)
			title = j8PDV0pthfSTidZbsQxNIOmCYKWzH(title)
			x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+'صفحة '+title,MepIvHBYNArkUOdV37shtJ,351)
	return
def PPqUACSE3VcGLTvw05jHy9JrFNW(search):
	search,LBylNhMdH6OV1qGk0tWiXFg3,showDialogs = LLm3sBXHPcnTDxdE5gt6hz0Wkp(search)
	if search==qpFY4hAwolV3: search = jXgARlWMLVFUBnvmZwI2o5()
	if search==qpFY4hAwolV3: return
	K7m9Otk3h1VYIN8rcP6jp2 = search.replace(mIsDke0oK5x1zSiOWbF9thGcA,'+')
	url = ddBxj51bhNtaK23lDyGMVw + '/?s='+K7m9Otk3h1VYIN8rcP6jp2
	MOTjA5H9XFs = c8U1BdtxOZS5FH(url)
	return
def v1gmfxDcRrWKQ(url):
	cmWl9dOKHPIy41iaXuxrY = GMqfDK9V4F8eTPE1pNOAaiYUbhr(kUz8c7OqsxuPFIGfwg,url,qpFY4hAwolV3,headers,True,'AKOAMCAM-EPISODES-1st')
	pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('text-white">الحلقات(.*?)<header',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	if pfRkcVlLmUxo561g0A8qSbO:
		mVYdjvor6i4wZ8 = pfRkcVlLmUxo561g0A8qSbO[0]
		pzLc3HwImv2dru = ePhmG1jLD6.findall('href="(http.*?)".*?src="(.*?)".*?alt="(.*?)"',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
		for MepIvHBYNArkUOdV37shtJ,Sj7rMNYRuQPTtkBvpHKeDW3h,title in pzLc3HwImv2dru:
			if 'الحلقة' in title or 'الحلقه' in title: x3WSXnKyPhjqfHG2UrtQs('video',wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,353,Sj7rMNYRuQPTtkBvpHKeDW3h)
	else:
		Sj7rMNYRuQPTtkBvpHKeDW3h = Rqvw05BorCgcye7VE32Sf.getInfoLabel('ListItem.Icon')
		if cmWl9dOKHPIy41iaXuxrY.count('<title>')>1: title = ePhmG1jLD6.findall('<title>(.*?)<',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)[1]
		else: title = 'رابط التشغيل'
		x3WSXnKyPhjqfHG2UrtQs('video',wwSFijdVJn1QgHW+title,url,353,Sj7rMNYRuQPTtkBvpHKeDW3h)
	return
def mzcAeyplZV(url):
	U7V0BQZPxXqMbyJnRw6f,QQLqrElamjfneR8GoP9IpuZ = [],[]
	i6PXlgSYUEbOQAm7z1h9Mtuap = WWrExJZS3Bj4anOAkpv7(KOyPvpEztYLaZRdMQJWxfTNFHbkg,'GET',url,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,'AKOAMCAM-PLAY-1st')
	cmWl9dOKHPIy41iaXuxrY = i6PXlgSYUEbOQAm7z1h9Mtuap.content
	ed5GKJzygXNsS6il2 = ePhmG1jLD6.findall('post_id=(.*?)"',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	if ed5GKJzygXNsS6il2:
		ed5GKJzygXNsS6il2 = ed5GKJzygXNsS6il2[0]
		headers = {'User-Agent':qpFY4hAwolV3,'Content-Type':'application/x-www-form-urlencoded'}
		data = {'post_id':ed5GKJzygXNsS6il2}
		WSQlG8mDhqsNe = ddBxj51bhNtaK23lDyGMVw+'/wp-content/themes/aflam8kkk/Inc/Ajax/Single/Watch.php'
		MCD3Q6TuaslNf0chP8LKyUBiH = WWrExJZS3Bj4anOAkpv7(KOyPvpEztYLaZRdMQJWxfTNFHbkg,'POST',WSQlG8mDhqsNe,data,headers,qpFY4hAwolV3,qpFY4hAwolV3,'AKOAMCAM-PLAY-1st')
		CC8IKXmYeo = MCD3Q6TuaslNf0chP8LKyUBiH.content
		items = ePhmG1jLD6.findall('data-server="(.*?)".*?class="text">(.*?)<',CC8IKXmYeo,ePhmG1jLD6.DOTALL)
		for YoxGJTz0QS8dLrAcZq5tBeXVNK1,name in items:
			MepIvHBYNArkUOdV37shtJ = 'https://w.akoam.cam/wp-content/themes/aflam8kkk/Inc/Ajax/Single/Server.php'
			MepIvHBYNArkUOdV37shtJ = MepIvHBYNArkUOdV37shtJ+'?postid='+ed5GKJzygXNsS6il2+'&serverid='+YoxGJTz0QS8dLrAcZq5tBeXVNK1+'?named='+name+'__watch'
			U7V0BQZPxXqMbyJnRw6f.append(MepIvHBYNArkUOdV37shtJ)
			QQLqrElamjfneR8GoP9IpuZ.append(name)
		WSQlG8mDhqsNe = ddBxj51bhNtaK23lDyGMVw+'/wp-content/themes/aflam8kkk/Inc/Ajax/Single/Download.php'
		MCD3Q6TuaslNf0chP8LKyUBiH = WWrExJZS3Bj4anOAkpv7(KOyPvpEztYLaZRdMQJWxfTNFHbkg,'POST',WSQlG8mDhqsNe,data,headers,qpFY4hAwolV3,qpFY4hAwolV3,'AKOAMCAM-PLAY-1st')
		CC8IKXmYeo = MCD3Q6TuaslNf0chP8LKyUBiH.content
		items = ePhmG1jLD6.findall('href="(.*?)".*?class="text">(.*?)<',CC8IKXmYeo,ePhmG1jLD6.DOTALL)
		for MepIvHBYNArkUOdV37shtJ,title in items:
			MepIvHBYNArkUOdV37shtJ = MepIvHBYNArkUOdV37shtJ.strip(mIsDke0oK5x1zSiOWbF9thGcA)
			MepIvHBYNArkUOdV37shtJ = MepIvHBYNArkUOdV37shtJ+'?named='+title+'__download'
			U7V0BQZPxXqMbyJnRw6f.append(MepIvHBYNArkUOdV37shtJ)
			QQLqrElamjfneR8GoP9IpuZ.append(title)
	import inVXFK46ET
	inVXFK46ET.q4qTJvuoQUzM3mZAtegy7IXdnb5wH(U7V0BQZPxXqMbyJnRw6f,Q8Q0IDc6PLZajJAdTntKUmSGXz,'video',url)
	return
def R9pWUgVhBGLd2CQb0z(url,filter):
	LLAbR2tC6J7OuvqfV4iYg = ['cat','genre','release-year','quality','orderby']
	if '?' in url: url = url.split('?')[0]
	type,filter = filter.split('___',1)
	if filter==qpFY4hAwolV3: eAYm1EkvcnOzXWpFB68o9rglSQ0M5,M0jc2ZsJHPb1d3DCoyXIzmgt = qpFY4hAwolV3,qpFY4hAwolV3
	else: eAYm1EkvcnOzXWpFB68o9rglSQ0M5,M0jc2ZsJHPb1d3DCoyXIzmgt = filter.split('___')
	if type=='CATEGORIES':
		if LLAbR2tC6J7OuvqfV4iYg[0]+'=' not in eAYm1EkvcnOzXWpFB68o9rglSQ0M5: n1uwH0oJaGZ5WBd = LLAbR2tC6J7OuvqfV4iYg[0]
		for a2jQ83ZCfcM5 in range(len(LLAbR2tC6J7OuvqfV4iYg[0:-1])):
			if LLAbR2tC6J7OuvqfV4iYg[a2jQ83ZCfcM5]+'=' in eAYm1EkvcnOzXWpFB68o9rglSQ0M5: n1uwH0oJaGZ5WBd = LLAbR2tC6J7OuvqfV4iYg[a2jQ83ZCfcM5+1]
		OI4ExuWvaLU = eAYm1EkvcnOzXWpFB68o9rglSQ0M5+'&'+n1uwH0oJaGZ5WBd+'=0'
		vmTWLw30V2PFNC8DrRqI = M0jc2ZsJHPb1d3DCoyXIzmgt+'&'+n1uwH0oJaGZ5WBd+'=0'
		nxGqbf39mXPhwl1NtAsSYK = OI4ExuWvaLU.strip('&')+'___'+vmTWLw30V2PFNC8DrRqI.strip('&')
		ekvC3tHRVnZGM4uDsmE2pBc5x = ZX8DyBJbV4lNAG(M0jc2ZsJHPb1d3DCoyXIzmgt,'all')
		WSQlG8mDhqsNe = url+'?'+ekvC3tHRVnZGM4uDsmE2pBc5x
	elif type=='FILTERS':
		Q7PrOdIzEeXgpT4HL38GK = ZX8DyBJbV4lNAG(eAYm1EkvcnOzXWpFB68o9rglSQ0M5,'modified_values')
		Q7PrOdIzEeXgpT4HL38GK = cTt4u6reEMKZqVLplmkNW7(Q7PrOdIzEeXgpT4HL38GK)
		if M0jc2ZsJHPb1d3DCoyXIzmgt!=qpFY4hAwolV3: M0jc2ZsJHPb1d3DCoyXIzmgt = ZX8DyBJbV4lNAG(M0jc2ZsJHPb1d3DCoyXIzmgt,'all')
		if M0jc2ZsJHPb1d3DCoyXIzmgt==qpFY4hAwolV3: WSQlG8mDhqsNe = url
		else: WSQlG8mDhqsNe = url+'?'+M0jc2ZsJHPb1d3DCoyXIzmgt
		x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+'أظهار قائمة الفيديو التي تم اختيارها',WSQlG8mDhqsNe,351,qpFY4hAwolV3,'1')
		x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+' [[   '+Q7PrOdIzEeXgpT4HL38GK+'   ]]',WSQlG8mDhqsNe,351,qpFY4hAwolV3,'1')
		x3WSXnKyPhjqfHG2UrtQs('link',xupTj02bvy3O8R+' ===== ===== ===== '+fF4lt9zWYxXLKZVyAco82PgMj,qpFY4hAwolV3,9999)
	cmWl9dOKHPIy41iaXuxrY = GMqfDK9V4F8eTPE1pNOAaiYUbhr(KOyPvpEztYLaZRdMQJWxfTNFHbkg,url,qpFY4hAwolV3,headers,True,'AKOAMCAM-FILTERS_MENU-1st')
	pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('<form id(.*?)</form>',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	mVYdjvor6i4wZ8 = pfRkcVlLmUxo561g0A8qSbO[0]
	YF4LRjr6TuagQk9o3PiMeIcHx = ePhmG1jLD6.findall('<select.*?name="(.*?)".*?">(.*?)<(.*?)</select>',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
	dict = {}
	for CQlVpYyFN6bzXRBZIMxPWdn,name,mVYdjvor6i4wZ8 in YF4LRjr6TuagQk9o3PiMeIcHx:
		items = ePhmG1jLD6.findall('<option(.*?)>(.*?)<',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
		if '=' not in WSQlG8mDhqsNe: WSQlG8mDhqsNe = url
		if type=='CATEGORIES':
			if n1uwH0oJaGZ5WBd!=CQlVpYyFN6bzXRBZIMxPWdn: continue
			elif len(items)<=1:
				if CQlVpYyFN6bzXRBZIMxPWdn==LLAbR2tC6J7OuvqfV4iYg[-1]: c8U1BdtxOZS5FH(WSQlG8mDhqsNe)
				else: R9pWUgVhBGLd2CQb0z(WSQlG8mDhqsNe,'CATEGORIES___'+nxGqbf39mXPhwl1NtAsSYK)
				return
			else:
				if CQlVpYyFN6bzXRBZIMxPWdn==LLAbR2tC6J7OuvqfV4iYg[-1]: x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+'الجميع',WSQlG8mDhqsNe,351,qpFY4hAwolV3,'1')
				else: x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+'الجميع',WSQlG8mDhqsNe,355,qpFY4hAwolV3,qpFY4hAwolV3,nxGqbf39mXPhwl1NtAsSYK)
		elif type=='FILTERS':
			OI4ExuWvaLU = eAYm1EkvcnOzXWpFB68o9rglSQ0M5+'&'+CQlVpYyFN6bzXRBZIMxPWdn+'=0'
			vmTWLw30V2PFNC8DrRqI = M0jc2ZsJHPb1d3DCoyXIzmgt+'&'+CQlVpYyFN6bzXRBZIMxPWdn+'=0'
			nxGqbf39mXPhwl1NtAsSYK = OI4ExuWvaLU+'___'+vmTWLw30V2PFNC8DrRqI
			x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+'الجميع : '+name,WSQlG8mDhqsNe,354,qpFY4hAwolV3,qpFY4hAwolV3,nxGqbf39mXPhwl1NtAsSYK)
		dict[CQlVpYyFN6bzXRBZIMxPWdn] = {}
		for value,FLkeT4nCDqrQMmW6ZSlgyU5jIO32 in items:
			if FLkeT4nCDqrQMmW6ZSlgyU5jIO32 in YEIA19ehBwpNfPVzK: continue
			if 'value' not in value: value = FLkeT4nCDqrQMmW6ZSlgyU5jIO32
			else: value = ePhmG1jLD6.findall('"(.*?)"',value,ePhmG1jLD6.DOTALL)[0]
			dict[CQlVpYyFN6bzXRBZIMxPWdn][value] = FLkeT4nCDqrQMmW6ZSlgyU5jIO32
			OI4ExuWvaLU = eAYm1EkvcnOzXWpFB68o9rglSQ0M5+'&'+CQlVpYyFN6bzXRBZIMxPWdn+'='+FLkeT4nCDqrQMmW6ZSlgyU5jIO32
			vmTWLw30V2PFNC8DrRqI = M0jc2ZsJHPb1d3DCoyXIzmgt+'&'+CQlVpYyFN6bzXRBZIMxPWdn+'='+value
			lJWPN5EDIbft92m6iCQqAYLjav4p = OI4ExuWvaLU+'___'+vmTWLw30V2PFNC8DrRqI
			title = FLkeT4nCDqrQMmW6ZSlgyU5jIO32+' : '#+dict[CQlVpYyFN6bzXRBZIMxPWdn]['0']
			title = FLkeT4nCDqrQMmW6ZSlgyU5jIO32+' : '+name
			if type=='FILTERS': x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+title,url,354,qpFY4hAwolV3,qpFY4hAwolV3,lJWPN5EDIbft92m6iCQqAYLjav4p)
			elif type=='CATEGORIES' and LLAbR2tC6J7OuvqfV4iYg[-2]+'=' in eAYm1EkvcnOzXWpFB68o9rglSQ0M5:
				ekvC3tHRVnZGM4uDsmE2pBc5x = ZX8DyBJbV4lNAG(vmTWLw30V2PFNC8DrRqI,'all')
				hhpztscnBD1GP = url+'?'+ekvC3tHRVnZGM4uDsmE2pBc5x
				x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+title,hhpztscnBD1GP,351,qpFY4hAwolV3,'1')
			else: x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+title,url,355,qpFY4hAwolV3,qpFY4hAwolV3,lJWPN5EDIbft92m6iCQqAYLjav4p)
	return
def ZX8DyBJbV4lNAG(bbaYxjcVnksy,mode):
	bbaYxjcVnksy = bbaYxjcVnksy.strip('&')
	J9ASCRhfiDyTB = {}
	if '=' in bbaYxjcVnksy:
		items = bbaYxjcVnksy.split('&')
		for lkd2oKvZF03qmgMbIfQ6cD in items:
			JJAsQ4pRYXPhqugN2to9TEzLIS,value = lkd2oKvZF03qmgMbIfQ6cD.split('=')
			J9ASCRhfiDyTB[JJAsQ4pRYXPhqugN2to9TEzLIS] = value
	LxOIqpMU7E1hPKH5fSzj2iW9v = qpFY4hAwolV3
	VlsAo2qQ0BbEhZTgNL9u = ['cat','genre','release-year','quality','orderby']
	for key in VlsAo2qQ0BbEhZTgNL9u:
		if key in list(J9ASCRhfiDyTB.keys()): value = J9ASCRhfiDyTB[key]
		else: value = '0'
		if mode=='modified_values' and value!='0': LxOIqpMU7E1hPKH5fSzj2iW9v = LxOIqpMU7E1hPKH5fSzj2iW9v+' + '+value
		elif mode=='modified_filters' and value!='0': LxOIqpMU7E1hPKH5fSzj2iW9v = LxOIqpMU7E1hPKH5fSzj2iW9v+'&'+key+'='+value
		elif mode=='all': LxOIqpMU7E1hPKH5fSzj2iW9v = LxOIqpMU7E1hPKH5fSzj2iW9v+'&'+key+'='+value
	LxOIqpMU7E1hPKH5fSzj2iW9v = LxOIqpMU7E1hPKH5fSzj2iW9v.strip(' + ')
	LxOIqpMU7E1hPKH5fSzj2iW9v = LxOIqpMU7E1hPKH5fSzj2iW9v.strip('&')
	return LxOIqpMU7E1hPKH5fSzj2iW9v