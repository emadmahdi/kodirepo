# -*- coding: utf-8 -*-
from pSfaryIjBo import *
Q8Q0IDc6PLZajJAdTntKUmSGXz = 'MYCIMA'
headers = {'User-Agent':qpFY4hAwolV3}
wwSFijdVJn1QgHW = '_MCM_'
ddBxj51bhNtaK23lDyGMVw = i4bFG3rKE6.SITESURLS[Q8Q0IDc6PLZajJAdTntKUmSGXz][0]
YEIA19ehBwpNfPVzK = ['مصارعة حرة','wwe']
def vTNE2Ck1sGnugJYW8y39aLcSH64U(mode,url,text):
	if   mode==360: MOTjA5H9XFs = nRVAZc4Dp8PSrGU3xBk()
	elif mode==361: MOTjA5H9XFs = c8U1BdtxOZS5FH(url,text)
	elif mode==362: MOTjA5H9XFs = mzcAeyplZV(url)
	elif mode==363: MOTjA5H9XFs = v1gmfxDcRrWKQ(url,text)
	elif mode==364: MOTjA5H9XFs = R9pWUgVhBGLd2CQb0z(url,'CATEGORIES___'+text)
	elif mode==365: MOTjA5H9XFs = R9pWUgVhBGLd2CQb0z(url,'FILTERS___'+text)
	elif mode==366: MOTjA5H9XFs = X2rO3lubqIdCGMLYWcxA6DK5(url)
	elif mode==369: MOTjA5H9XFs = PPqUACSE3VcGLTvw05jHy9JrFNW(text,url)
	else: MOTjA5H9XFs = False
	return MOTjA5H9XFs
def nRVAZc4Dp8PSrGU3xBk():
	x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+'بحث في الموقع',ddBxj51bhNtaK23lDyGMVw,369,qpFY4hAwolV3,qpFY4hAwolV3,'_REMEMBERRESULTS_')
	x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+'فلتر محدد',ddBxj51bhNtaK23lDyGMVw+'/AjaxCenter/RightBar',364)
	x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+'فلتر كامل',ddBxj51bhNtaK23lDyGMVw+'/AjaxCenter/RightBar',365)
	x3WSXnKyPhjqfHG2UrtQs('link',xupTj02bvy3O8R+' ===== ===== ===== '+fF4lt9zWYxXLKZVyAco82PgMj,qpFY4hAwolV3,9999)
	IAW0sh6So3NpqM = WWrExJZS3Bj4anOAkpv7(KOyPvpEztYLaZRdMQJWxfTNFHbkg,'GET',ddBxj51bhNtaK23lDyGMVw,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,'MYCIMA-MENU-2nd')
	cmWl9dOKHPIy41iaXuxrY = IAW0sh6So3NpqM.content
	pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('class="NavigationMenu"(.*?)class="ProductionsListButton"',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	if pfRkcVlLmUxo561g0A8qSbO:
		mVYdjvor6i4wZ8 = pfRkcVlLmUxo561g0A8qSbO[0]
		items = ePhmG1jLD6.findall('class="menu-item.*?href="(.*?)">(.*?)<',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
		for MepIvHBYNArkUOdV37shtJ,title in items:
			if title==qpFY4hAwolV3: continue
			if any(value in title.lower() for value in YEIA19ehBwpNfPVzK): continue
			x3WSXnKyPhjqfHG2UrtQs('folder',Q8Q0IDc6PLZajJAdTntKUmSGXz+'_SCRIPT_'+wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,366)
		x3WSXnKyPhjqfHG2UrtQs('link',xupTj02bvy3O8R+' ===== ===== ===== '+fF4lt9zWYxXLKZVyAco82PgMj,qpFY4hAwolV3,9999)
	pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('hoverable activable(.*?)hoverable activable',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	if pfRkcVlLmUxo561g0A8qSbO:
		mVYdjvor6i4wZ8 = pfRkcVlLmUxo561g0A8qSbO[0]
		items = ePhmG1jLD6.findall('href="(.*?)".*?url\((.*?)\).*?span>(.*?)<',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
		for MepIvHBYNArkUOdV37shtJ,Sj7rMNYRuQPTtkBvpHKeDW3h,title in items:
			x3WSXnKyPhjqfHG2UrtQs('folder',Q8Q0IDc6PLZajJAdTntKUmSGXz+'_SCRIPT_'+wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,366,Sj7rMNYRuQPTtkBvpHKeDW3h)
	return cmWl9dOKHPIy41iaXuxrY
def X2rO3lubqIdCGMLYWcxA6DK5(url):
	IAW0sh6So3NpqM = WWrExJZS3Bj4anOAkpv7(KOyPvpEztYLaZRdMQJWxfTNFHbkg,'GET',url,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,'MYCIMA-SUBMENU-1st')
	cmWl9dOKHPIy41iaXuxrY = IAW0sh6So3NpqM.content
	if 'class="Slider--Grid"' in cmWl9dOKHPIy41iaXuxrY:
		x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+'المميزة',url,361,qpFY4hAwolV3,qpFY4hAwolV3,'featured')
	pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('class="list--Tabsui"(.*?)div',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	if pfRkcVlLmUxo561g0A8qSbO:
		mVYdjvor6i4wZ8 = pfRkcVlLmUxo561g0A8qSbO[0]
		items = ePhmG1jLD6.findall('href="(.*?)".*?i>(.*?)<',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
		for MepIvHBYNArkUOdV37shtJ,title in items:
			x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,361)
	return
def c8U1BdtxOZS5FH(aM24zy36A9EeIcBn,type=qpFY4hAwolV3):
	if '::' in aM24zy36A9EeIcBn:
		hhpztscnBD1GP,url = aM24zy36A9EeIcBn.split('::')
		XPNkVcWFUr = AWeJuo2LhZ5xiD8KNSqd9G0rtT74FE(hhpztscnBD1GP,'url')
		url = XPNkVcWFUr+url
	else: url,hhpztscnBD1GP = aM24zy36A9EeIcBn,aM24zy36A9EeIcBn
	IAW0sh6So3NpqM = WWrExJZS3Bj4anOAkpv7(kUz8c7OqsxuPFIGfwg,'GET',url,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,'MYCIMA-TITLES-1st')
	cmWl9dOKHPIy41iaXuxrY = IAW0sh6So3NpqM.content
	if type=='featured':
		pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('class="Slider--Grid"(.*?)class="list--Tabsui"',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	elif type=='filters':
		pfRkcVlLmUxo561g0A8qSbO = [cmWl9dOKHPIy41iaXuxrY.replace('\\/',ShynO8pN9idCE3).replace('\\"','"')]
	else:
		pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('class="Grid--MycimaPosts"(.*?)</li></ul></div></div>',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	aaCNAJdtsguSRELh2I = []
	if pfRkcVlLmUxo561g0A8qSbO:
		mVYdjvor6i4wZ8 = pfRkcVlLmUxo561g0A8qSbO[0]
		items = ePhmG1jLD6.findall('GridItem"><a href="(.*?)" title="(.*?)".*?url\((.*?)\)',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
		for MepIvHBYNArkUOdV37shtJ,title,Sj7rMNYRuQPTtkBvpHKeDW3h in items:
			if any(value in title.lower() for value in YEIA19ehBwpNfPVzK): continue
			Sj7rMNYRuQPTtkBvpHKeDW3h = N8E37XwL6iQbmBY(Sj7rMNYRuQPTtkBvpHKeDW3h)
			title = j8PDV0pthfSTidZbsQxNIOmCYKWzH(title)
			title = N8E37XwL6iQbmBY(title)
			title = title.replace('مشاهدة ',qpFY4hAwolV3)
			if '/series/' in MepIvHBYNArkUOdV37shtJ: x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,363,Sj7rMNYRuQPTtkBvpHKeDW3h)
			elif 'حلقة' in title:
				ZDTxRSMbW7PNz = ePhmG1jLD6.findall('(.*?) +حلقة +\d+',title,ePhmG1jLD6.DOTALL)
				if ZDTxRSMbW7PNz: title = '_MOD_' + ZDTxRSMbW7PNz[0]
				if title not in aaCNAJdtsguSRELh2I:
					aaCNAJdtsguSRELh2I.append(title)
					x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,363,Sj7rMNYRuQPTtkBvpHKeDW3h)
			else:
				x3WSXnKyPhjqfHG2UrtQs('video',wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,362,Sj7rMNYRuQPTtkBvpHKeDW3h)
		if type=='filters':
			ppB9zFEedcVZ4GXuwr0 = ePhmG1jLD6.findall('"more_button_page":(.*?),',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
			if ppB9zFEedcVZ4GXuwr0:
				count = ppB9zFEedcVZ4GXuwr0[0]
				MepIvHBYNArkUOdV37shtJ = url+'/offset/'+count
				x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+'صفحة أخرى',MepIvHBYNArkUOdV37shtJ,361,qpFY4hAwolV3,qpFY4hAwolV3,'filters')
		elif type==qpFY4hAwolV3:
			pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('class="pagination(.*?)</div>',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
			if pfRkcVlLmUxo561g0A8qSbO:
				mVYdjvor6i4wZ8 = pfRkcVlLmUxo561g0A8qSbO[0]
				items = ePhmG1jLD6.findall('href="(.*?)">(.*?)<',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
				for MepIvHBYNArkUOdV37shtJ,title in items:
					title = 'صفحة '+j8PDV0pthfSTidZbsQxNIOmCYKWzH(title)
					x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,361)
	return
def v1gmfxDcRrWKQ(url,type=qpFY4hAwolV3):
	IAW0sh6So3NpqM = WWrExJZS3Bj4anOAkpv7(kUz8c7OqsxuPFIGfwg,'GET',url,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,'MYCIMA-EPISODES-1st')
	cmWl9dOKHPIy41iaXuxrY = IAW0sh6So3NpqM.content
	cmWl9dOKHPIy41iaXuxrY = cTt4u6reEMKZqVLplmkNW7(cmWl9dOKHPIy41iaXuxrY)
	name = ePhmG1jLD6.findall('itemprop="item" href=".*?/series/(.*?)"',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	if name: name = name[-1].replace('-',mIsDke0oK5x1zSiOWbF9thGcA).strip(ShynO8pN9idCE3)
	if 'موسم' in name and type==qpFY4hAwolV3:
		name = name.split('موسم')[0]
		name = name.replace('مشاهدة',qpFY4hAwolV3).strip(mIsDke0oK5x1zSiOWbF9thGcA)
	elif 'حلقة' in name:
		name = name.split('حلقة')[0]
		name = name.replace('مشاهدة',qpFY4hAwolV3).strip(mIsDke0oK5x1zSiOWbF9thGcA)
	else: name = name
	pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('class="Seasons--Episodes"(.*?)</singlesection',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	if pfRkcVlLmUxo561g0A8qSbO:
		mVYdjvor6i4wZ8 = pfRkcVlLmUxo561g0A8qSbO[0]
		if type==qpFY4hAwolV3:
			items = ePhmG1jLD6.findall('href="(.*?)">(.*?)</a>',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
			for MepIvHBYNArkUOdV37shtJ,title in items:
				if 'class' in title: continue
				if 'episode' in title: continue
				title = name+' - '+title
				x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,363,qpFY4hAwolV3,qpFY4hAwolV3,'episodes')
		if len(i4bFG3rKE6.menuItemsLIST)==0:
			WqdHmfQpP0ITnjJOAbDR6u8t7EiU = ePhmG1jLD6.findall('class="Episodes--Seasons--Episodes"(.*?)&&',mVYdjvor6i4wZ8+'&&',ePhmG1jLD6.DOTALL)
			if WqdHmfQpP0ITnjJOAbDR6u8t7EiU: mVYdjvor6i4wZ8 = WqdHmfQpP0ITnjJOAbDR6u8t7EiU[0]
			items = ePhmG1jLD6.findall('href="(.*?)".*?<episodeTitle>(.*?)<',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
			for MepIvHBYNArkUOdV37shtJ,title in items:
				title = title.strip(mIsDke0oK5x1zSiOWbF9thGcA)
				title = name+' - '+title
				x3WSXnKyPhjqfHG2UrtQs('video',wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,362)
	if len(i4bFG3rKE6.menuItemsLIST)==0:
		title = ePhmG1jLD6.findall('<title>(.*?)<',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
		if title: title = title[0].replace(' - ماي سيما',qpFY4hAwolV3).replace('مشاهدة ',qpFY4hAwolV3)
		else: title = 'ملف التشغيل'
		x3WSXnKyPhjqfHG2UrtQs('video',wwSFijdVJn1QgHW+title,url,362)
	return
def mzcAeyplZV(url):
	U7V0BQZPxXqMbyJnRw6f = []
	IAW0sh6So3NpqM = WWrExJZS3Bj4anOAkpv7(rGY36xBwT1bLZAngSfcWEIeXdQVNij,'GET',url,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,'MYCIMA-PLAY-1st')
	cmWl9dOKHPIy41iaXuxrY = IAW0sh6So3NpqM.content
	GIE2XSj0vVJPZA6dgmOs9TMDy8UkQW = ePhmG1jLD6.findall('<span>التصنيف<.*?<a.*?">(.*?)<.*?">(.*?)<',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	if GIE2XSj0vVJPZA6dgmOs9TMDy8UkQW:
		GIE2XSj0vVJPZA6dgmOs9TMDy8UkQW = [GIE2XSj0vVJPZA6dgmOs9TMDy8UkQW[0][0],GIE2XSj0vVJPZA6dgmOs9TMDy8UkQW[0][1]]
		if GIE2XSj0vVJPZA6dgmOs9TMDy8UkQW and u0E18eO3HnCzr(Q8Q0IDc6PLZajJAdTntKUmSGXz,url,GIE2XSj0vVJPZA6dgmOs9TMDy8UkQW): return
	pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('class="WatchServersList"(.*?)class="WatchServersEmbed"',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	if pfRkcVlLmUxo561g0A8qSbO:
		mVYdjvor6i4wZ8 = pfRkcVlLmUxo561g0A8qSbO[0]
		items = ePhmG1jLD6.findall('data-url="(.*?)".*?strong>(.*?)<',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
		for MepIvHBYNArkUOdV37shtJ,name in items:
			if 'http' not in MepIvHBYNArkUOdV37shtJ: MepIvHBYNArkUOdV37shtJ = ddBxj51bhNtaK23lDyGMVw+MepIvHBYNArkUOdV37shtJ
			if name=='سيرفر ماي سيما': name = 'mycima'
			MepIvHBYNArkUOdV37shtJ = MepIvHBYNArkUOdV37shtJ+'?named='+name+'__watch'
			U7V0BQZPxXqMbyJnRw6f.append(MepIvHBYNArkUOdV37shtJ)
	pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('class="List--Download(.*?)</div>',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	if pfRkcVlLmUxo561g0A8qSbO:
		mVYdjvor6i4wZ8 = pfRkcVlLmUxo561g0A8qSbO[0]
		items = ePhmG1jLD6.findall('href="(.*?)".*?</i>(.*?)<',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
		for MepIvHBYNArkUOdV37shtJ,Mrp5ZdGHFv9Xi6mkxfac3JDB in items:
			if 'http' not in MepIvHBYNArkUOdV37shtJ: MepIvHBYNArkUOdV37shtJ = ddBxj51bhNtaK23lDyGMVw+MepIvHBYNArkUOdV37shtJ
			Mrp5ZdGHFv9Xi6mkxfac3JDB = ePhmG1jLD6.findall('\d\d\d+',Mrp5ZdGHFv9Xi6mkxfac3JDB,ePhmG1jLD6.DOTALL)
			if Mrp5ZdGHFv9Xi6mkxfac3JDB: Mrp5ZdGHFv9Xi6mkxfac3JDB = '____'+Mrp5ZdGHFv9Xi6mkxfac3JDB[0]
			else: Mrp5ZdGHFv9Xi6mkxfac3JDB = qpFY4hAwolV3
			MepIvHBYNArkUOdV37shtJ = MepIvHBYNArkUOdV37shtJ+'?named=mycima'+'__download'+Mrp5ZdGHFv9Xi6mkxfac3JDB
			U7V0BQZPxXqMbyJnRw6f.append(MepIvHBYNArkUOdV37shtJ)
	import inVXFK46ET
	inVXFK46ET.q4qTJvuoQUzM3mZAtegy7IXdnb5wH(U7V0BQZPxXqMbyJnRw6f,Q8Q0IDc6PLZajJAdTntKUmSGXz,'video',url)
	return
def PPqUACSE3VcGLTvw05jHy9JrFNW(search,tyJqRYHPmc=qpFY4hAwolV3):
	search,LBylNhMdH6OV1qGk0tWiXFg3,showDialogs = LLm3sBXHPcnTDxdE5gt6hz0Wkp(search)
	if search==qpFY4hAwolV3: search = jXgARlWMLVFUBnvmZwI2o5()
	if search==qpFY4hAwolV3: return
	search = search.replace(mIsDke0oK5x1zSiOWbF9thGcA,'+')
	U7V0BQZPxXqMbyJnRw6f = ['/list',ShynO8pN9idCE3,'/list/series','/list/anime','/list/tv']
	HHXPdv1aOo8WAZYIn0NFQ = ['الكل','الأفلام','المسلسلات','الانيمي و الكرتون','البرامج تليفزيونية']
	if showDialogs:
		ndm6kKswPpgGHNEbtB = xVzqWbrFXJ('اختر النوع المطلوب:', HHXPdv1aOo8WAZYIn0NFQ)
		if ndm6kKswPpgGHNEbtB==-1: return
	else: ndm6kKswPpgGHNEbtB = 0
	if tyJqRYHPmc==qpFY4hAwolV3:
		IAW0sh6So3NpqM = WWrExJZS3Bj4anOAkpv7(rGY36xBwT1bLZAngSfcWEIeXdQVNij,'GET',ddBxj51bhNtaK23lDyGMVw,qpFY4hAwolV3,qpFY4hAwolV3,False,qpFY4hAwolV3,'MYCIMA-SEARCH-1st')
		tyJqRYHPmc = IAW0sh6So3NpqM.headers['Location']
		tyJqRYHPmc = tyJqRYHPmc.strip(ShynO8pN9idCE3)
	WSQlG8mDhqsNe = tyJqRYHPmc+'/search/'+search+U7V0BQZPxXqMbyJnRw6f[ndm6kKswPpgGHNEbtB]
	c8U1BdtxOZS5FH(WSQlG8mDhqsNe)
	return
def R9pWUgVhBGLd2CQb0z(aM24zy36A9EeIcBn,filter):
	if '??' in aM24zy36A9EeIcBn: url = aM24zy36A9EeIcBn.split('//getposts??')[0]
	else: url = aM24zy36A9EeIcBn
	filter = filter.replace('_FORGETRESULTS_',qpFY4hAwolV3)
	type,filter = filter.split('___',1)
	if filter==qpFY4hAwolV3: eAYm1EkvcnOzXWpFB68o9rglSQ0M5,M0jc2ZsJHPb1d3DCoyXIzmgt = qpFY4hAwolV3,qpFY4hAwolV3
	else: eAYm1EkvcnOzXWpFB68o9rglSQ0M5,M0jc2ZsJHPb1d3DCoyXIzmgt = filter.split('___')
	if type=='CATEGORIES':
		if xOc1qk9GYV[0]+'==' not in eAYm1EkvcnOzXWpFB68o9rglSQ0M5: n1uwH0oJaGZ5WBd = xOc1qk9GYV[0]
		for a2jQ83ZCfcM5 in range(len(xOc1qk9GYV[0:-1])):
			if xOc1qk9GYV[a2jQ83ZCfcM5]+'==' in eAYm1EkvcnOzXWpFB68o9rglSQ0M5: n1uwH0oJaGZ5WBd = xOc1qk9GYV[a2jQ83ZCfcM5+1]
		OI4ExuWvaLU = eAYm1EkvcnOzXWpFB68o9rglSQ0M5+'&&'+n1uwH0oJaGZ5WBd+'==0'
		vmTWLw30V2PFNC8DrRqI = M0jc2ZsJHPb1d3DCoyXIzmgt+'&&'+n1uwH0oJaGZ5WBd+'==0'
		nxGqbf39mXPhwl1NtAsSYK = OI4ExuWvaLU.strip('&&')+'___'+vmTWLw30V2PFNC8DrRqI.strip('&&')
		ekvC3tHRVnZGM4uDsmE2pBc5x = ZX8DyBJbV4lNAG(M0jc2ZsJHPb1d3DCoyXIzmgt,'modified_filters')
		WSQlG8mDhqsNe = url+'//getposts??'+ekvC3tHRVnZGM4uDsmE2pBc5x
	elif type=='FILTERS':
		Q7PrOdIzEeXgpT4HL38GK = ZX8DyBJbV4lNAG(eAYm1EkvcnOzXWpFB68o9rglSQ0M5,'modified_values')
		Q7PrOdIzEeXgpT4HL38GK = cTt4u6reEMKZqVLplmkNW7(Q7PrOdIzEeXgpT4HL38GK)
		if M0jc2ZsJHPb1d3DCoyXIzmgt!=qpFY4hAwolV3: M0jc2ZsJHPb1d3DCoyXIzmgt = ZX8DyBJbV4lNAG(M0jc2ZsJHPb1d3DCoyXIzmgt,'modified_filters')
		if M0jc2ZsJHPb1d3DCoyXIzmgt==qpFY4hAwolV3: WSQlG8mDhqsNe = url
		else: WSQlG8mDhqsNe = url+'//getposts??'+M0jc2ZsJHPb1d3DCoyXIzmgt
		y2SIoiHRUhNMmqPYjrwA3TWg69pxV = BMWgGkaVvlpfeHY4r8sI(WSQlG8mDhqsNe,aM24zy36A9EeIcBn)
		x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+'أظهار قائمة الفيديو التي تم اختيارها ',y2SIoiHRUhNMmqPYjrwA3TWg69pxV,361,qpFY4hAwolV3,qpFY4hAwolV3,'filters')
		x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+' [[   '+Q7PrOdIzEeXgpT4HL38GK+'   ]]',y2SIoiHRUhNMmqPYjrwA3TWg69pxV,361,qpFY4hAwolV3,qpFY4hAwolV3,'filters')
		x3WSXnKyPhjqfHG2UrtQs('link',xupTj02bvy3O8R+' ===== ===== ===== '+fF4lt9zWYxXLKZVyAco82PgMj,qpFY4hAwolV3,9999)
	IAW0sh6So3NpqM = WWrExJZS3Bj4anOAkpv7(KOyPvpEztYLaZRdMQJWxfTNFHbkg,'GET',url,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,'MYCIMA-FILTERS_MENU-1st')
	cmWl9dOKHPIy41iaXuxrY = IAW0sh6So3NpqM.content
	cmWl9dOKHPIy41iaXuxrY = cmWl9dOKHPIy41iaXuxrY.replace('\\"','"').replace('\\/',ShynO8pN9idCE3)
	pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('<mycima--filter(.*?)</mycima--filter>',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	if not pfRkcVlLmUxo561g0A8qSbO: return
	mVYdjvor6i4wZ8 = pfRkcVlLmUxo561g0A8qSbO[0]
	YF4LRjr6TuagQk9o3PiMeIcHx = ePhmG1jLD6.findall('taxonomy="(.*?)".*?<span>(.*?)<(.*?)<filterbox',mVYdjvor6i4wZ8+'<filterbox',ePhmG1jLD6.DOTALL)
	dict = {}
	for CQlVpYyFN6bzXRBZIMxPWdn,name,mVYdjvor6i4wZ8 in YF4LRjr6TuagQk9o3PiMeIcHx:
		name = N8E37XwL6iQbmBY(name)
		if 'interest' in CQlVpYyFN6bzXRBZIMxPWdn: continue
		items = ePhmG1jLD6.findall('data-term="(.*?)".*?<txt>(.*?)</txt>',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
		if '==' not in WSQlG8mDhqsNe: WSQlG8mDhqsNe = url
		if type=='CATEGORIES':
			if n1uwH0oJaGZ5WBd!=CQlVpYyFN6bzXRBZIMxPWdn: continue
			elif len(items)<=1:
				if CQlVpYyFN6bzXRBZIMxPWdn==xOc1qk9GYV[-1]: c8U1BdtxOZS5FH(WSQlG8mDhqsNe)
				else: R9pWUgVhBGLd2CQb0z(WSQlG8mDhqsNe,'CATEGORIES___'+nxGqbf39mXPhwl1NtAsSYK)
				return
			else:
				y2SIoiHRUhNMmqPYjrwA3TWg69pxV = BMWgGkaVvlpfeHY4r8sI(WSQlG8mDhqsNe,aM24zy36A9EeIcBn)
				if CQlVpYyFN6bzXRBZIMxPWdn==xOc1qk9GYV[-1]:
					x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+'الجميع',y2SIoiHRUhNMmqPYjrwA3TWg69pxV,361,qpFY4hAwolV3,qpFY4hAwolV3,'filters')
				else: x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+'الجميع',WSQlG8mDhqsNe,364,qpFY4hAwolV3,qpFY4hAwolV3,nxGqbf39mXPhwl1NtAsSYK)
		elif type=='FILTERS':
			OI4ExuWvaLU = eAYm1EkvcnOzXWpFB68o9rglSQ0M5+'&&'+CQlVpYyFN6bzXRBZIMxPWdn+'==0'
			vmTWLw30V2PFNC8DrRqI = M0jc2ZsJHPb1d3DCoyXIzmgt+'&&'+CQlVpYyFN6bzXRBZIMxPWdn+'==0'
			nxGqbf39mXPhwl1NtAsSYK = OI4ExuWvaLU+'___'+vmTWLw30V2PFNC8DrRqI
			x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+name+': الجميع',WSQlG8mDhqsNe,365,qpFY4hAwolV3,qpFY4hAwolV3,nxGqbf39mXPhwl1NtAsSYK+'_FORGETRESULTS_')
		dict[CQlVpYyFN6bzXRBZIMxPWdn] = {}
		for value,FLkeT4nCDqrQMmW6ZSlgyU5jIO32 in items:
			name = N8E37XwL6iQbmBY(name)
			FLkeT4nCDqrQMmW6ZSlgyU5jIO32 = N8E37XwL6iQbmBY(FLkeT4nCDqrQMmW6ZSlgyU5jIO32)
			if value=='r' or value=='nc-17': continue
			if any(value in FLkeT4nCDqrQMmW6ZSlgyU5jIO32.lower() for value in YEIA19ehBwpNfPVzK): continue
			if 'http' in FLkeT4nCDqrQMmW6ZSlgyU5jIO32: continue
			if 'الكل' in FLkeT4nCDqrQMmW6ZSlgyU5jIO32: continue
			if 'n-a' in value: continue
			if FLkeT4nCDqrQMmW6ZSlgyU5jIO32==qpFY4hAwolV3: FLkeT4nCDqrQMmW6ZSlgyU5jIO32 = value
			rr1mzIljJHqkx = FLkeT4nCDqrQMmW6ZSlgyU5jIO32
			aTKNPrW6ie1msSX9HBg = ePhmG1jLD6.findall('<name>(.*?)</name>',FLkeT4nCDqrQMmW6ZSlgyU5jIO32,ePhmG1jLD6.DOTALL)
			if aTKNPrW6ie1msSX9HBg: rr1mzIljJHqkx = aTKNPrW6ie1msSX9HBg[0]
			UdbGw48M6rCHDRmea5qP91nKI = name+': '+rr1mzIljJHqkx
			dict[CQlVpYyFN6bzXRBZIMxPWdn][value] = UdbGw48M6rCHDRmea5qP91nKI
			OI4ExuWvaLU = eAYm1EkvcnOzXWpFB68o9rglSQ0M5+'&&'+CQlVpYyFN6bzXRBZIMxPWdn+'=='+rr1mzIljJHqkx
			vmTWLw30V2PFNC8DrRqI = M0jc2ZsJHPb1d3DCoyXIzmgt+'&&'+CQlVpYyFN6bzXRBZIMxPWdn+'=='+value
			lJWPN5EDIbft92m6iCQqAYLjav4p = OI4ExuWvaLU+'___'+vmTWLw30V2PFNC8DrRqI
			if type=='FILTERS':
				x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+UdbGw48M6rCHDRmea5qP91nKI,url,365,qpFY4hAwolV3,qpFY4hAwolV3,lJWPN5EDIbft92m6iCQqAYLjav4p+'_FORGETRESULTS_')
			elif type=='CATEGORIES' and xOc1qk9GYV[-2]+'==' in eAYm1EkvcnOzXWpFB68o9rglSQ0M5:
				ekvC3tHRVnZGM4uDsmE2pBc5x = ZX8DyBJbV4lNAG(vmTWLw30V2PFNC8DrRqI,'modified_filters')
				hhpztscnBD1GP = url+'//getposts??'+ekvC3tHRVnZGM4uDsmE2pBc5x
				y2SIoiHRUhNMmqPYjrwA3TWg69pxV = BMWgGkaVvlpfeHY4r8sI(hhpztscnBD1GP,aM24zy36A9EeIcBn)
				x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+UdbGw48M6rCHDRmea5qP91nKI,y2SIoiHRUhNMmqPYjrwA3TWg69pxV,361,qpFY4hAwolV3,qpFY4hAwolV3,'filters')
			else: x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+UdbGw48M6rCHDRmea5qP91nKI,url,364,qpFY4hAwolV3,qpFY4hAwolV3,lJWPN5EDIbft92m6iCQqAYLjav4p)
	return
xOc1qk9GYV = ['genre','release-year','nation']
D4QyIwCApsmkBLr = ['mpaa','genre','release-year','category','Quality','interest','nation','language']
def BMWgGkaVvlpfeHY4r8sI(WSQlG8mDhqsNe,hhpztscnBD1GP):
	if '/AjaxCenter/RightBar' in WSQlG8mDhqsNe: WSQlG8mDhqsNe = WSQlG8mDhqsNe.replace('/AjaxCenter/RightBar','/AjaxCenter/Filtering')
	WSQlG8mDhqsNe = WSQlG8mDhqsNe.replace('//getposts??','::/AjaxCenter/Filtering/')
	WSQlG8mDhqsNe = WSQlG8mDhqsNe.replace('==',ShynO8pN9idCE3)
	WSQlG8mDhqsNe = WSQlG8mDhqsNe.replace('&&',ShynO8pN9idCE3)
	return WSQlG8mDhqsNe
def ZX8DyBJbV4lNAG(bbaYxjcVnksy,mode):
	bbaYxjcVnksy = bbaYxjcVnksy.strip('&&')
	J9ASCRhfiDyTB,LxOIqpMU7E1hPKH5fSzj2iW9v = {},qpFY4hAwolV3
	if '==' in bbaYxjcVnksy:
		items = bbaYxjcVnksy.split('&&')
		for lkd2oKvZF03qmgMbIfQ6cD in items:
			JJAsQ4pRYXPhqugN2to9TEzLIS,value = lkd2oKvZF03qmgMbIfQ6cD.split('==')
			J9ASCRhfiDyTB[JJAsQ4pRYXPhqugN2to9TEzLIS] = value
	for key in D4QyIwCApsmkBLr:
		if key in list(J9ASCRhfiDyTB.keys()): value = J9ASCRhfiDyTB[key]
		else: value = '0'
		if '%' not in value: value = BUKlErdIu7Ggqcz3jYpf09wMePF4V(value)
		if mode=='modified_values' and value!='0': LxOIqpMU7E1hPKH5fSzj2iW9v = LxOIqpMU7E1hPKH5fSzj2iW9v+' + '+value
		elif mode=='modified_filters' and value!='0': LxOIqpMU7E1hPKH5fSzj2iW9v = LxOIqpMU7E1hPKH5fSzj2iW9v+'&&'+key+'=='+value
		elif mode=='all': LxOIqpMU7E1hPKH5fSzj2iW9v = LxOIqpMU7E1hPKH5fSzj2iW9v+'&&'+key+'=='+value
	LxOIqpMU7E1hPKH5fSzj2iW9v = LxOIqpMU7E1hPKH5fSzj2iW9v.strip(' + ')
	LxOIqpMU7E1hPKH5fSzj2iW9v = LxOIqpMU7E1hPKH5fSzj2iW9v.strip('&&')
	return LxOIqpMU7E1hPKH5fSzj2iW9v