# -*- coding: utf-8 -*-
import sys as TSRUP0dExYGQg
mgNMJhrjcq1xb = TSRUP0dExYGQg.version_info [0] == 2
lQJvf8UXo2de9gjCatY4yH = 2048
YuTB2OjotvlR = 7
def kk0DKyarxq9eS1zwGLMFQTZN35dj (neqP2if8IOJ50aNKcCBLrXdZk):
	global sWerUpk6nQwT7zY43
	vxdNQUujz7ZFV4rtOSK2 = ord (neqP2if8IOJ50aNKcCBLrXdZk [-1])
	yyshZX35KO7JodYjD9qVib6 = neqP2if8IOJ50aNKcCBLrXdZk [:-1]
	fuKReXJ3HPIAU7c = vxdNQUujz7ZFV4rtOSK2 % len (yyshZX35KO7JodYjD9qVib6)
	EEFQdvXog7LPC4Sie0jDkUKxn6M = yyshZX35KO7JodYjD9qVib6 [:fuKReXJ3HPIAU7c] + yyshZX35KO7JodYjD9qVib6 [fuKReXJ3HPIAU7c:]
	if mgNMJhrjcq1xb:
		Clh5YS0XPue68EgT4Uq17GL = unicode () .join ([unichr (ord (AsGVDZFgmuH06jviYrWXTz) - lQJvf8UXo2de9gjCatY4yH - (XvhDIL4ZpzaPs91WkoGnedCEA2rt + vxdNQUujz7ZFV4rtOSK2) % YuTB2OjotvlR) for XvhDIL4ZpzaPs91WkoGnedCEA2rt, AsGVDZFgmuH06jviYrWXTz in enumerate (EEFQdvXog7LPC4Sie0jDkUKxn6M)])
	else:
		Clh5YS0XPue68EgT4Uq17GL = str () .join ([chr (ord (AsGVDZFgmuH06jviYrWXTz) - lQJvf8UXo2de9gjCatY4yH - (XvhDIL4ZpzaPs91WkoGnedCEA2rt + vxdNQUujz7ZFV4rtOSK2) % YuTB2OjotvlR) for XvhDIL4ZpzaPs91WkoGnedCEA2rt, AsGVDZFgmuH06jviYrWXTz in enumerate (EEFQdvXog7LPC4Sie0jDkUKxn6M)])
	return eval (Clh5YS0XPue68EgT4Uq17GL)
qoBMmfAWpFlK70xw8ZRh4naJ,lljaEqwTVtmKsQcOrbXxS5hgNH,aXqWLoTdVgME=kk0DKyarxq9eS1zwGLMFQTZN35dj,kk0DKyarxq9eS1zwGLMFQTZN35dj,kk0DKyarxq9eS1zwGLMFQTZN35dj
UVa3fJw7k6KM,fWoVd0Bmtkx,tQMjXKCA5dN4xq3beVIzaEoWkFLg=aXqWLoTdVgME,lljaEqwTVtmKsQcOrbXxS5hgNH,qoBMmfAWpFlK70xw8ZRh4naJ
viRJWOC5jsYe84,Ie5s2cBtSfdHjzQ4rA9kYlo6D18,sjtU6GZQg5XC2pH4=tQMjXKCA5dN4xq3beVIzaEoWkFLg,fWoVd0Bmtkx,UVa3fJw7k6KM
LZWMikPEB81KSGyxfJtUsCA,rNdBKI74fAklnoCZ6,BRWqdruz2A0=sjtU6GZQg5XC2pH4,Ie5s2cBtSfdHjzQ4rA9kYlo6D18,viRJWOC5jsYe84
CC1eY6yWZUwf2TkRvnp7EJ0AimjHBX,qqzwE6imYG4c2xojI,N3flV6EJsD5CzS=BRWqdruz2A0,rNdBKI74fAklnoCZ6,LZWMikPEB81KSGyxfJtUsCA
UUDAiytEL76RTmMYsuIz5evXB,IaBhDMJc17302LgSvyxd,ddiCzu6yahj5RtTISMJ48sNnZBU=N3flV6EJsD5CzS,qqzwE6imYG4c2xojI,CC1eY6yWZUwf2TkRvnp7EJ0AimjHBX
dJHDqiKf12TXlIzSLkGUuxg4MBs3A,l1DZAt9XNQjqE7YOdrz,l32dnTEOU1skGKqeBtI9hmo=ddiCzu6yahj5RtTISMJ48sNnZBU,IaBhDMJc17302LgSvyxd,UUDAiytEL76RTmMYsuIz5evXB
zYvEaigKWjoq50pXBLDbGJkFc,iNc3KxwErnQ,V3VlkhgjEF4n1erPXHcC0NOsfwyAJ=l32dnTEOU1skGKqeBtI9hmo,l1DZAt9XNQjqE7YOdrz,dJHDqiKf12TXlIzSLkGUuxg4MBs3A
tR1krDGPpO025fghMT3a7UnYj,c2RKu0xG1eC8MiohyE,RlOvin8YIGC2KZXJPk9m0acrMobUex=V3VlkhgjEF4n1erPXHcC0NOsfwyAJ,iNc3KxwErnQ,zYvEaigKWjoq50pXBLDbGJkFc
YY8UDX3MJhb91AHw7fg,ee86G9ladLHVbh5mikzCo,mmV2nucZ5Lpl6FO1JMPEqGoQKW=RlOvin8YIGC2KZXJPk9m0acrMobUex,c2RKu0xG1eC8MiohyE,tR1krDGPpO025fghMT3a7UnYj
DaFZHsThGmd0zv6e,kYDaz79TFlXoR,DiJ8CMuYH1daWyjehfN0L=mmV2nucZ5Lpl6FO1JMPEqGoQKW,ee86G9ladLHVbh5mikzCo,YY8UDX3MJhb91AHw7fg
from pSfaryIjBo import *
Q8Q0IDc6PLZajJAdTntKUmSGXz = aXqWLoTdVgME(u"ࠧࡅࡑ࡚ࡒࡑࡕࡁࡅࠩ௺")
def vTNE2Ck1sGnugJYW8y39aLcSH64U(ZyiMa3BXVk2xWG0b,WWowRmHkj1ZAO2SUhtNvdrcKa9E6C):
	if   ZyiMa3BXVk2xWG0b==tR1krDGPpO025fghMT3a7UnYj(u"࠹࠳࠱౾"): MOTjA5H9XFs = cweVJPafZQECjx6RLr()
	elif ZyiMa3BXVk2xWG0b==aXqWLoTdVgME(u"࠳࠴࠳౿"): MOTjA5H9XFs = mzcAeyplZV(WWowRmHkj1ZAO2SUhtNvdrcKa9E6C)
	elif ZyiMa3BXVk2xWG0b==iNc3KxwErnQ(u"࠴࠵࠵ಀ"): MOTjA5H9XFs = kRfjSdtUbYr7PDO0HT9qvl()
	elif ZyiMa3BXVk2xWG0b==qoBMmfAWpFlK70xw8ZRh4naJ(u"࠵࠶࠷ಁ"): MOTjA5H9XFs = fLiq9hI2Tr8DYbO1BcdJXEU()
	else: MOTjA5H9XFs = ag8rjZo1Vz4IPdcOT
	return MOTjA5H9XFs
def mzcAeyplZV(WWowRmHkj1ZAO2SUhtNvdrcKa9E6C):
	dORtnXbEgi5A8m0CH(WWowRmHkj1ZAO2SUhtNvdrcKa9E6C,Q8Q0IDc6PLZajJAdTntKUmSGXz,rNdBKI74fAklnoCZ6(u"ࠨࡸ࡬ࡨࡪࡵࠧ௻"))
	return
def fLiq9hI2Tr8DYbO1BcdJXEU():
	w0CZ6B3WDJknhEsdRYyH1XAM = sjtU6GZQg5XC2pH4(u"ࠩฦิ์ฮࠠฦๆ์ࠤึอศุࠢส่ๆ๐ฯ๋๊ࠣวํࠦวๅื๋ฮࠥ็๊ࠡษ็้ํู่ࠡษ็้฼๊่ษࠢฮ้ࠥษึ฻ูࠣ฽้๏ࠠำำࠣห้่วว็ฬࠤฬ๊๊ๆ์้ࠤะ๋ࠠฤะอหึࠦࠢหฯ่๎้ࠦๅๅใสฮࠥ็๊ะ์๋ࠦࠥัๅࠡษัฮฬืࠠะไฬࠤฬ๊ี้ำฬࠤํอฮหษิࠤ๋๎ูࠡ็็ๅࠥอไึ๊ิอࠥ๎ศฺั๊หู่ࠥโࠢํฬิษࠠศๆอั๊๐ไࠨ௼")
	iG7Rz2kmn0x1yLNMV3u8O(qpFY4hAwolV3,qpFY4hAwolV3,ee86G9ladLHVbh5mikzCo(u"ࠪ฻ึ๐โสࠢอั๊๐ไࠡษ็้้็วหࠩ௽"),w0CZ6B3WDJknhEsdRYyH1XAM)
	return
def cweVJPafZQECjx6RLr():
	x3WSXnKyPhjqfHG2UrtQs(iNc3KxwErnQ(u"ࠫࡱ࡯࡮࡬ࠩ௾"),fWoVd0Bmtkx(u"ࠬ฽ั๋ไฬࠤฯำๅ๋ๆ้้ࠣ็วหࠢส่ๆ๐ฯ๋๊ࠪ௿"),qpFY4hAwolV3,kYDaz79TFlXoR(u"࠶࠷࠸ಂ"))
	x3WSXnKyPhjqfHG2UrtQs(lljaEqwTVtmKsQcOrbXxS5hgNH(u"࠭࡬ࡪࡰ࡮ࠫఀ"),zYvEaigKWjoq50pXBLDbGJkFc(u"ࠧห฼ํ๎ึࠦๅไษ้ࠤฯำๅ๋ๆࠣห้็๊ะ์๋๋ฬะࠧఁ"),qpFY4hAwolV3,RlOvin8YIGC2KZXJPk9m0acrMobUex(u"࠷࠸࠸ಃ"))
	x3WSXnKyPhjqfHG2UrtQs(RlOvin8YIGC2KZXJPk9m0acrMobUex(u"ࠨ࡮࡬ࡲࡰ࠭ం"),xupTj02bvy3O8R+IaBhDMJc17302LgSvyxd(u"ࠩࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠࠨః")+fF4lt9zWYxXLKZVyAco82PgMj,qpFY4hAwolV3,kYDaz79TFlXoR(u"࠾࠿࠹࠺಄"))
	PAcU8EHIOVM5fT0JD = EELMc4sgPhUo2VFyRTi0zp5()
	HeWohX1EJ7FKRAk2 = RPbaxsNFVTwek5Kfv21DiJuzCnjMZp.stat(PAcU8EHIOVM5fT0JD).st_mtime
	vN0gZI3nVwehLcsEjxm6 = []
	if DLod2Of8CkRrtzJynev: YZCg0W7yRTUmPdu = RPbaxsNFVTwek5Kfv21DiJuzCnjMZp.listdir(PAcU8EHIOVM5fT0JD.encode(nV3Tip6XsH1rJw79DPOU))
	else: YZCg0W7yRTUmPdu = RPbaxsNFVTwek5Kfv21DiJuzCnjMZp.listdir(PAcU8EHIOVM5fT0JD.decode(nV3Tip6XsH1rJw79DPOU))
	for vvKPsk74UZ9q in YZCg0W7yRTUmPdu:
		if DLod2Of8CkRrtzJynev: vvKPsk74UZ9q = vvKPsk74UZ9q.decode(nV3Tip6XsH1rJw79DPOU)
		if not vvKPsk74UZ9q.startswith(YY8UDX3MJhb91AHw7fg(u"ࠪࡪ࡮ࡲࡥࡠࠩఄ")): continue
		yaIirbsC0jDTxStO = RPbaxsNFVTwek5Kfv21DiJuzCnjMZp.path.join(PAcU8EHIOVM5fT0JD,vvKPsk74UZ9q)
		HeWohX1EJ7FKRAk2 = RPbaxsNFVTwek5Kfv21DiJuzCnjMZp.path.getmtime(yaIirbsC0jDTxStO)
		vN0gZI3nVwehLcsEjxm6.append([vvKPsk74UZ9q,HeWohX1EJ7FKRAk2])
	vN0gZI3nVwehLcsEjxm6 = sorted(vN0gZI3nVwehLcsEjxm6,reverse=gBExoceumj4y8bFW9hY2aNMVSr,key=lambda key: key[mZi0S72jGoHpLO])
	for vvKPsk74UZ9q,HeWohX1EJ7FKRAk2 in vN0gZI3nVwehLcsEjxm6:
		if NJwViHDTMdmO0xnALqQ9voPalC3Ip:
			try: vvKPsk74UZ9q = vvKPsk74UZ9q.decode(nV3Tip6XsH1rJw79DPOU)
			except: pass
			vvKPsk74UZ9q = vvKPsk74UZ9q.encode(nV3Tip6XsH1rJw79DPOU)
		yaIirbsC0jDTxStO = RPbaxsNFVTwek5Kfv21DiJuzCnjMZp.path.join(PAcU8EHIOVM5fT0JD,vvKPsk74UZ9q)
		x3WSXnKyPhjqfHG2UrtQs(sjtU6GZQg5XC2pH4(u"ࠫࡻ࡯ࡤࡦࡱࠪఅ"),vvKPsk74UZ9q,yaIirbsC0jDTxStO,ee86G9ladLHVbh5mikzCo(u"࠹࠳࠲ಅ"))
	return
def EELMc4sgPhUo2VFyRTi0zp5():
	PAcU8EHIOVM5fT0JD = gdPslyFW8ITBcpA302.getSetting(RlOvin8YIGC2KZXJPk9m0acrMobUex(u"ࠬࡧࡶ࠯ࡦࡲࡻࡳࡲ࡯ࡢࡦ࠱ࡴࡦࡺࡨࠨఆ"))
	if PAcU8EHIOVM5fT0JD: return PAcU8EHIOVM5fT0JD
	gdPslyFW8ITBcpA302.setSetting(UUDAiytEL76RTmMYsuIz5evXB(u"࠭ࡡࡷ࠰ࡧࡳࡼࡴ࡬ࡰࡣࡧ࠲ࡵࡧࡴࡩࠩఇ"),F8qeAKZjGRMNXimho2gntaV0)
	return F8qeAKZjGRMNXimho2gntaV0
def kRfjSdtUbYr7PDO0HT9qvl():
	PAcU8EHIOVM5fT0JD = EELMc4sgPhUo2VFyRTi0zp5()
	DhIGy4JQpo5t7n9VYEi = VVpbtSKYUGXrNMwAWFo9IOjZP(UUDAiytEL76RTmMYsuIz5evXB(u"ࠧࡤࡧࡱࡸࡪࡸࠧఈ"),qpFY4hAwolV3,qpFY4hAwolV3,IaBhDMJc17302LgSvyxd(u"ࠨ็ๆห๋ࠦสฯิํ๊๋ࠥไโษอࠤฬ๊สฮ็ํ่ࠬఉ"),IQ2KCmObsTGuiRdEzt931a40jLg+PAcU8EHIOVM5fT0JD+fF4lt9zWYxXLKZVyAco82PgMj+kYDaz79TFlXoR(u"ࠩ࡟ࡲࡡࡴ็ัษ๋ࠣํࠦๅไษ้ࠤฯิา๋่้้ࠣ็วหࠢส่ๆ๐ฯ๋๊ࠣห้ะ๊ࠡฬะ้้ํวࠡษ้ฮࠥฮวิฬัำฬ๋่ࠠาสࠤฬ๊ศา่ส้ัࠦ࠮้ࠡ็ࠤฯื๊ะࠢอ฾๏๐ัࠡษ็้่อๆࠡมࠪఊ"))
	if DhIGy4JQpo5t7n9VYEi==CC1eY6yWZUwf2TkRvnp7EJ0AimjHBX(u"࠱ಆ"):
		yu4YBg3czOh2ZMJ5X = NEhkcLiSVUeIm(tQMjXKCA5dN4xq3beVIzaEoWkFLg(u"࠴ಇ"),zYvEaigKWjoq50pXBLDbGJkFc(u"้่ࠪอๆࠡฬะ้๏๊ࠠๆๆไหฯࠦวๅใํำ๏๎ࠧఋ"),RlOvin8YIGC2KZXJPk9m0acrMobUex(u"ࠫࡱࡵࡣࡢ࡮ࠪఌ"),qpFY4hAwolV3,ag8rjZo1Vz4IPdcOT,gBExoceumj4y8bFW9hY2aNMVSr,PAcU8EHIOVM5fT0JD)
		o4oUxD3u18K59ghHIY = VVpbtSKYUGXrNMwAWFo9IOjZP(CC1eY6yWZUwf2TkRvnp7EJ0AimjHBX(u"ࠬࡩࡥ࡯ࡶࡨࡶࠬ఍"),qpFY4hAwolV3,qpFY4hAwolV3,sjtU6GZQg5XC2pH4(u"࠭ๅไษ้ࠤฯิา๋่้้ࠣ็วหࠢส่ฯำๅ๋ๆࠪఎ"),IQ2KCmObsTGuiRdEzt931a40jLg+PAcU8EHIOVM5fT0JD+fF4lt9zWYxXLKZVyAco82PgMj+mmV2nucZ5Lpl6FO1JMPEqGoQKW(u"ࠧ࡝ࡰ࡟ࡲ์ึว้๋ࠡࠤฬ๊ๅไษ้ࠤฬ๊ฬะ์าࠤ้ะฮำ์้ࠤ๊๊แศฬࠣห้็๊ะ์๋ࠤฬ๊ส๋ࠢอั๊๊็ศࠢส๊ฯࠦศศีอาิอๅ้ࠡำหࠥอไษำ้ห๊าࠠ࠯๊่ࠢࠥะั๋ัࠣหุะฮะษ่๋ࠥฮฯๅษ้๋ࠣࠦวๅ็ๆห๋ࠦวๅไา๎๊ࠦฟࠨఏ"))
		if o4oUxD3u18K59ghHIY==qqzwE6imYG4c2xojI(u"࠳ಈ"):
			gdPslyFW8ITBcpA302.setSetting(zYvEaigKWjoq50pXBLDbGJkFc(u"ࠨࡣࡹ࠲ࡩࡵࡷ࡯࡮ࡲࡥࡩ࠴ࡰࡢࡶ࡫ࠫఐ"),yu4YBg3czOh2ZMJ5X)
			iG7Rz2kmn0x1yLNMV3u8O(qpFY4hAwolV3,qpFY4hAwolV3,GLTtERWbHnFuy4PCp,viRJWOC5jsYe84(u"ࠩอ้ࠥะฺ๋์ิࠤ๊้ว็ࠢอาื๐ๆࠡษ็้้็วหࠢส่๊ำๅๅหࠪ఑"))
	return
def EIaixhl4wmUAvYWXgGsjb(WWowRmHkj1ZAO2SUhtNvdrcKa9E6C,gyEQS6JIZKa=qpFY4hAwolV3,website=qpFY4hAwolV3):
	LLvyStW429DEZKlA(k8kdUSxohLVljnrY,lTW9p1v7uPfOxB(Q8Q0IDc6PLZajJAdTntKUmSGXz)+ddiCzu6yahj5RtTISMJ48sNnZBU(u"ࠪࠤࠥࠦࡐࡳࡧࡳࡥࡷ࡯࡮ࡨࠢࡷࡳࠥࡪ࡯ࡸࡰ࡯ࡳࡦࡪࠠࠡࠢࡘࡖࡑࡀࠠ࡜ࠢࠪఒ")+WWowRmHkj1ZAO2SUhtNvdrcKa9E6C+sjtU6GZQg5XC2pH4(u"ࠫࠥࡣࠧఓ"))
	if not gyEQS6JIZKa: gyEQS6JIZKa = RRwxKI27Mk(WWowRmHkj1ZAO2SUhtNvdrcKa9E6C)
	PAcU8EHIOVM5fT0JD = EELMc4sgPhUo2VFyRTi0zp5()
	GWALnz3yjFrg2av9BUE = iyEOYZTQV32LshS1(ag8rjZo1Vz4IPdcOT)
	vvKPsk74UZ9q = GWALnz3yjFrg2av9BUE.replace(mIsDke0oK5x1zSiOWbF9thGcA,ddiCzu6yahj5RtTISMJ48sNnZBU(u"ࠬࡥࠧఔ"))
	vvKPsk74UZ9q = GmlDbno5psqtUL9XrS(vvKPsk74UZ9q)
	vvKPsk74UZ9q = l32dnTEOU1skGKqeBtI9hmo(u"࠭ࡦࡪ࡮ࡨࡣࠬక")+str(int(dAeP20gNJ6ltq))[-Ie5s2cBtSfdHjzQ4rA9kYlo6D18(u"࠷ಉ"):]+ddiCzu6yahj5RtTISMJ48sNnZBU(u"ࠧࡠࠩఖ")+vvKPsk74UZ9q+gyEQS6JIZKa
	T0jVYrzHDqwE8ScfXxu3BtkhgyPvlC = RPbaxsNFVTwek5Kfv21DiJuzCnjMZp.path.join(PAcU8EHIOVM5fT0JD,vvKPsk74UZ9q)
	EBOwuZ71x92omaIKbGFU3A54pqkc = {}
	EBOwuZ71x92omaIKbGFU3A54pqkc[l32dnTEOU1skGKqeBtI9hmo(u"ࠨࡃࡦࡧࡪࡶࡴ࠮ࡇࡱࡧࡴࡪࡩ࡯ࡩࠪగ")] = qpFY4hAwolV3
	EBOwuZ71x92omaIKbGFU3A54pqkc[ddiCzu6yahj5RtTISMJ48sNnZBU(u"ࠩࡄࡧࡨ࡫ࡰࡵࠩఘ")] = sjtU6GZQg5XC2pH4(u"ࠪ࠮࠴࠰ࠧఙ")
	WWowRmHkj1ZAO2SUhtNvdrcKa9E6C = WWowRmHkj1ZAO2SUhtNvdrcKa9E6C.replace(aXqWLoTdVgME(u"ࠫࡻ࡫ࡲࡪࡨࡼࡴࡪ࡫ࡲ࠾ࡨࡤࡰࡸ࡫ࠧచ"),qpFY4hAwolV3)
	if c2RKu0xG1eC8MiohyE(u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵ࠿ࠪఛ") in WWowRmHkj1ZAO2SUhtNvdrcKa9E6C:
		WSQlG8mDhqsNe,NNWJKEyq13t2kglAZ7d = WWowRmHkj1ZAO2SUhtNvdrcKa9E6C.rsplit(ee86G9ladLHVbh5mikzCo(u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࡀࠫజ"),tQMjXKCA5dN4xq3beVIzaEoWkFLg(u"࠵ಊ"))
		NNWJKEyq13t2kglAZ7d = NNWJKEyq13t2kglAZ7d.replace(ee86G9ladLHVbh5mikzCo(u"ࠧࡽࠩఝ"),qpFY4hAwolV3).replace(ee86G9ladLHVbh5mikzCo(u"ࠨࠨࠪఞ"),qpFY4hAwolV3)
	else: WSQlG8mDhqsNe,NNWJKEyq13t2kglAZ7d = WWowRmHkj1ZAO2SUhtNvdrcKa9E6C,None
	if not NNWJKEyq13t2kglAZ7d: NNWJKEyq13t2kglAZ7d = IyjRtqkmHFBvTCDYwuQNJ0()
	if NNWJKEyq13t2kglAZ7d: EBOwuZ71x92omaIKbGFU3A54pqkc[tQMjXKCA5dN4xq3beVIzaEoWkFLg(u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭ట")] = NNWJKEyq13t2kglAZ7d
	if zYvEaigKWjoq50pXBLDbGJkFc(u"ࠪࡖࡪ࡬ࡥࡳࡧࡵࡁࠬఠ") in WSQlG8mDhqsNe: WSQlG8mDhqsNe,SPhHAEby41Wa = WSQlG8mDhqsNe.rsplit(c2RKu0xG1eC8MiohyE(u"ࠫࡗ࡫ࡦࡦࡴࡨࡶࡂ࠭డ"),CC1eY6yWZUwf2TkRvnp7EJ0AimjHBX(u"࠶ಋ"))
	else: WSQlG8mDhqsNe,SPhHAEby41Wa = WSQlG8mDhqsNe,qpFY4hAwolV3
	WSQlG8mDhqsNe = WSQlG8mDhqsNe.strip(dJHDqiKf12TXlIzSLkGUuxg4MBs3A(u"ࠬࢂࠧఢ")).strip(CC1eY6yWZUwf2TkRvnp7EJ0AimjHBX(u"࠭ࠦࠨణ")).strip(tR1krDGPpO025fghMT3a7UnYj(u"ࠧࡽࠩత")).strip(V3VlkhgjEF4n1erPXHcC0NOsfwyAJ(u"ࠨࠨࠪథ"))
	SPhHAEby41Wa = SPhHAEby41Wa.replace(viRJWOC5jsYe84(u"ࠩࡿࠫద"),qpFY4hAwolV3).replace(CC1eY6yWZUwf2TkRvnp7EJ0AimjHBX(u"ࠪࠪࠬధ"),qpFY4hAwolV3)
	if SPhHAEby41Wa:	EBOwuZ71x92omaIKbGFU3A54pqkc[l32dnTEOU1skGKqeBtI9hmo(u"ࠫࡗ࡫ࡦࡦࡴࡨࡶࠬన")] = SPhHAEby41Wa
	LLvyStW429DEZKlA(k8kdUSxohLVljnrY,lTW9p1v7uPfOxB(Q8Q0IDc6PLZajJAdTntKUmSGXz)+V3VlkhgjEF4n1erPXHcC0NOsfwyAJ(u"ࠬࠦࠠࠡࡆࡲࡻࡳࡲ࡯ࡢࡦ࡬ࡲ࡬ࠦࡶࡪࡦࡨࡳࠥ࡬ࡩ࡭ࡧࠣࠤ࡛ࠥࡒࡍ࠼ࠣ࡟ࠥ࠭఩")+WSQlG8mDhqsNe+mmV2nucZ5Lpl6FO1JMPEqGoQKW(u"࠭ࠠ࡞ࠢࠣࠤࡍ࡫ࡡࡥࡧࡵࡷ࠿࡛ࠦࠡࠩప")+str(EBOwuZ71x92omaIKbGFU3A54pqkc)+aXqWLoTdVgME(u"ࠧࠡ࡟ࠣࠤࠥࡌࡩ࡭ࡧ࠽ࠤࡠࠦࠧఫ")+T0jVYrzHDqwE8ScfXxu3BtkhgyPvlC+kYDaz79TFlXoR(u"ࠨࠢࡠࠫబ"))
	aHgp7ChWjV32 = N3flV6EJsD5CzS(u"࠷࠰࠳࠶ಌ")*N3flV6EJsD5CzS(u"࠷࠰࠳࠶ಌ")
	J8QWl5zrS0FHyhBtqPK2kOCi3djXVE = O8YxFVZUhBXd6wDcb()//aHgp7ChWjV32
	if not J8QWl5zrS0FHyhBtqPK2kOCi3djXVE:
		W2fBJaUN9kZwVeR1n0o4Dc(tQMjXKCA5dN4xq3beVIzaEoWkFLg(u"ࠩࡵ࡭࡬࡮ࡴࠨభ"),rNdBKI74fAklnoCZ6(u"ุ้ࠪออสࠢส่ฯิา๋่้ࠣัํ่ๅหࠪమ"),IaBhDMJc17302LgSvyxd(u"้๊ࠫริใࠣห้ฮั็ษ่ะࠥเ๊าࠢๅหิืࠠฤ่ࠣ๎าีฯࠡ็ๅำฬืࠠๆีสัฮࠦวๅฬัึ๏์ࠠศๆไหึเษࠡใํࠤัํวำๅࠣ์฾๊๊่ࠢไห๋ࠦสฮ็ํ่ࠥอไโ์า๎ํํวหࠢ็๊ࠥ๐ูๆๆࠣ฽๋ีใࠡว็ํࠥษๆࠡ์ๅ์๊ࠦๅษำ่ะ๏ࠦศา่ส้ัࠦใ้ัํࠤอำไ้ࠡำ๋ࠥอไๆึๆ่ฮࠦไศ่ࠣฮา๋๊ๅࠢส่ๆ๐ฯ๋๊๊หฯࠦโะࠢํือฮࠠศ็อ่ฬวࠠอ้สึ่ࠦศศๆ่่ๆอส๊๊ࠡิฬࠦแ๋้ࠣา฼๎ัสࠢ฼่๎ูࠦๆๆࠣะ์อาไࠢหูํืษࠡืะ๎าฯ้ࠠๆ๊ิฬࠦวๅีหฬ่ࠥวๆࠢส่๊ฮัๆฮ้ࠣษ่สศࠢห้๋฿ࠠศๆหี๋อๅอ่๊ࠢࠥะอๆ์็ࠤฬ๊แ๋ัํ์์อสࠨయ"),Ie5s2cBtSfdHjzQ4rA9kYlo6D18(u"ࠬࡺࡥࡹࡶࡹ࡭ࡪࡽ࡟ࡣ࡫ࡪࡪࡴࡴࡴࠨర"))
		LLvyStW429DEZKlA(j8gFJIMYPoBzcCvG9T,lTW9p1v7uPfOxB(Q8Q0IDc6PLZajJAdTntKUmSGXz)+zYvEaigKWjoq50pXBLDbGJkFc(u"࠭ࠠࠡࠢࡘࡲࡦࡨ࡬ࡦࠢࡷࡳࠥࡪࡥࡵࡧࡵࡱ࡮ࡴࡥࠡࡶ࡫ࡩࠥࡪࡩࡴ࡭ࠣࡪࡷ࡫ࡥࠡࡵࡳࡥࡨ࡫ࠧఱ"))
		return ag8rjZo1Vz4IPdcOT
	if gyEQS6JIZKa==sjtU6GZQg5XC2pH4(u"ࠧ࠯࡯࠶ࡹ࠽࠭ల"):
		QQLqrElamjfneR8GoP9IpuZ,U7V0BQZPxXqMbyJnRw6f = kkrVFUT4SCmKvAXRfe5gQuYoal(Q8Q0IDc6PLZajJAdTntKUmSGXz,WSQlG8mDhqsNe,EBOwuZ71x92omaIKbGFU3A54pqkc)
		if len(QQLqrElamjfneR8GoP9IpuZ)==c2RKu0xG1eC8MiohyE(u"࠰಍"):
			t8yiLuJp3cBA6d1QE9x7eZ4fa(YY8UDX3MJhb91AHw7fg(u"ࠨใื่ࠥ็๊ࠡวํะฬีࠠๆๆไࠤฬ๊สฮ็ํ่ࠬళ"),qpFY4hAwolV3)
			return ag8rjZo1Vz4IPdcOT
		elif len(QQLqrElamjfneR8GoP9IpuZ)==l32dnTEOU1skGKqeBtI9hmo(u"࠲ಎ"): ndm6kKswPpgGHNEbtB = UUDAiytEL76RTmMYsuIz5evXB(u"࠲ಏ")
		elif len(QQLqrElamjfneR8GoP9IpuZ)>ddiCzu6yahj5RtTISMJ48sNnZBU(u"࠴ಐ"):
			ndm6kKswPpgGHNEbtB = xVzqWbrFXJ(BRWqdruz2A0(u"ࠩสาฯืࠠศๆ่่ๆࠦวๅ็้หุฮࠧఴ"), QQLqrElamjfneR8GoP9IpuZ)
			if ndm6kKswPpgGHNEbtB == -tQMjXKCA5dN4xq3beVIzaEoWkFLg(u"࠵಑") :
				t8yiLuJp3cBA6d1QE9x7eZ4fa(iNc3KxwErnQ(u"ࠪฮ๊ࠦลๅ฼สลࠥอไหฯ่๎้࠭వ"),qpFY4hAwolV3)
				return ag8rjZo1Vz4IPdcOT
		WSQlG8mDhqsNe = U7V0BQZPxXqMbyJnRw6f[ndm6kKswPpgGHNEbtB]
	gCnze7FfNJw0BSljqDhHWdQYcLuyxG = tQMjXKCA5dN4xq3beVIzaEoWkFLg(u"࠵ಒ")
	import requests as lFScPefz0pyYM7QrH41n6woV
	if gyEQS6JIZKa==l1DZAt9XNQjqE7YOdrz(u"ࠫ࠳ࡳ࠳ࡶ࠺ࠪశ"):
		T0jVYrzHDqwE8ScfXxu3BtkhgyPvlC = T0jVYrzHDqwE8ScfXxu3BtkhgyPvlC.rsplit(BRWqdruz2A0(u"ࠬ࠴࡭࠴ࡷ࠻ࠫష"))[vvXoMLlg513]+N3flV6EJsD5CzS(u"࠭࠮࡮ࡲ࠷ࠫస")
		UEey2i9D3MTfhd7okHj6QSqJp0VBYA = WWrExJZS3Bj4anOAkpv7(rGY36xBwT1bLZAngSfcWEIeXdQVNij,qqzwE6imYG4c2xojI(u"ࠧࡈࡇࡗࠫహ"),WSQlG8mDhqsNe,qpFY4hAwolV3,EBOwuZ71x92omaIKbGFU3A54pqkc,qpFY4hAwolV3,qpFY4hAwolV3,l1DZAt9XNQjqE7YOdrz(u"ࠨࡆࡒ࡛ࡓࡒࡏࡂࡆ࠰ࡈࡔ࡝ࡎࡍࡑࡄࡈࡤ࡜ࡉࡅࡇࡒ࠱࠶ࡹࡴࠨ఺"))
		KKRxaNPL0I7znBvmpUCWrjJ2y = UEey2i9D3MTfhd7okHj6QSqJp0VBYA.content
		CFevtSjzbpn = ePhmG1jLD6.findall(UUDAiytEL76RTmMYsuIz5evXB(u"ࠩࠦࡉ࡝࡚ࡉࡏࡈ࠽࠲࠯ࡅ࡛࡝ࡰ࡟ࡶࡢ࠮࠮ࠫࡁࠬ࡟ࡡࡴ࡜ࡳ࡟ࠪ఻"),KKRxaNPL0I7znBvmpUCWrjJ2y+l32dnTEOU1skGKqeBtI9hmo(u"ࠪࡠࡳࡢࡲࠨ఼"),ePhmG1jLD6.DOTALL)
		if not CFevtSjzbpn:
			LLvyStW429DEZKlA(j8gFJIMYPoBzcCvG9T,lTW9p1v7uPfOxB(Q8Q0IDc6PLZajJAdTntKUmSGXz)+qqzwE6imYG4c2xojI(u"ࠫࠥࠦࠠࡕࡪࡨࠤࡲ࠹ࡵ࠹ࠢࡩ࡭ࡱ࡫ࠠࡥ࡫ࡧࠤࡳࡵࡴࠡࡪࡤࡺࡪࠦࡴࡩࡧࠣࡶࡪࡷࡵࡪࡴࡨࡨࠥࡲࡩ࡯࡭ࡶࠤࠥࠦࡕࡓࡎ࠽ࠤࡠࠦࠧఽ")+WSQlG8mDhqsNe+aXqWLoTdVgME(u"ࠬࠦ࡝ࠨా"))
			return ag8rjZo1Vz4IPdcOT
		MepIvHBYNArkUOdV37shtJ = CFevtSjzbpn[vvXoMLlg513]
		if not MepIvHBYNArkUOdV37shtJ.startswith(YY8UDX3MJhb91AHw7fg(u"࠭ࡨࡵࡶࡳࠫి")):
			if MepIvHBYNArkUOdV37shtJ.startswith(ttrDbyV5cSO2FjgTzew6qM): MepIvHBYNArkUOdV37shtJ = WSQlG8mDhqsNe.split(UUDAiytEL76RTmMYsuIz5evXB(u"ࠧ࠻ࠩీ"),sjtU6GZQg5XC2pH4(u"࠷ಓ"))[vvXoMLlg513]+viRJWOC5jsYe84(u"ࠨ࠼ࠪు")+MepIvHBYNArkUOdV37shtJ
			elif MepIvHBYNArkUOdV37shtJ.startswith(ShynO8pN9idCE3): MepIvHBYNArkUOdV37shtJ = AWeJuo2LhZ5xiD8KNSqd9G0rtT74FE(WSQlG8mDhqsNe,c2RKu0xG1eC8MiohyE(u"ࠩࡸࡶࡱ࠭ూ"))+MepIvHBYNArkUOdV37shtJ
			else: MepIvHBYNArkUOdV37shtJ = WSQlG8mDhqsNe.rsplit(ShynO8pN9idCE3,zYvEaigKWjoq50pXBLDbGJkFc(u"࠱ಔ"))[vvXoMLlg513]+ShynO8pN9idCE3+MepIvHBYNArkUOdV37shtJ
		UEey2i9D3MTfhd7okHj6QSqJp0VBYA = lFScPefz0pyYM7QrH41n6woV.request(ee86G9ladLHVbh5mikzCo(u"ࠪࡋࡊ࡚ࠧృ"),MepIvHBYNArkUOdV37shtJ,headers=EBOwuZ71x92omaIKbGFU3A54pqkc,verify=ag8rjZo1Vz4IPdcOT)
		z6DmT7KVnfo32dZR = UEey2i9D3MTfhd7okHj6QSqJp0VBYA.content
		mE2Tvl8q7iGnhDK3zB = len(z6DmT7KVnfo32dZR)
		qqZPRzobWCpDXUVQt6KkFg = len(CFevtSjzbpn)
		gCnze7FfNJw0BSljqDhHWdQYcLuyxG = mE2Tvl8q7iGnhDK3zB*qqZPRzobWCpDXUVQt6KkFg
	else:
		mE2Tvl8q7iGnhDK3zB = sjtU6GZQg5XC2pH4(u"࠲ಕ")*aHgp7ChWjV32
		UEey2i9D3MTfhd7okHj6QSqJp0VBYA = lFScPefz0pyYM7QrH41n6woV.request(tQMjXKCA5dN4xq3beVIzaEoWkFLg(u"ࠫࡌࡋࡔࠨౄ"),WSQlG8mDhqsNe,headers=EBOwuZ71x92omaIKbGFU3A54pqkc,verify=ag8rjZo1Vz4IPdcOT,stream=gBExoceumj4y8bFW9hY2aNMVSr)
		if sjtU6GZQg5XC2pH4(u"ࠬࡉ࡯࡯ࡶࡨࡲࡹ࠳ࡌࡦࡰࡪࡸ࡭࠭౅") in UEey2i9D3MTfhd7okHj6QSqJp0VBYA.headers: gCnze7FfNJw0BSljqDhHWdQYcLuyxG = int(UEey2i9D3MTfhd7okHj6QSqJp0VBYA.headers[RlOvin8YIGC2KZXJPk9m0acrMobUex(u"࠭ࡃࡰࡰࡷࡩࡳࡺ࠭ࡍࡧࡱ࡫ࡹ࡮ࠧె")])
		qqZPRzobWCpDXUVQt6KkFg = int(gCnze7FfNJw0BSljqDhHWdQYcLuyxG//mE2Tvl8q7iGnhDK3zB)
	KKahdkrjb61p4zJSytY = int(gCnze7FfNJw0BSljqDhHWdQYcLuyxG//aHgp7ChWjV32)+qqzwE6imYG4c2xojI(u"࠳ಖ")
	if gCnze7FfNJw0BSljqDhHWdQYcLuyxG<YY8UDX3MJhb91AHw7fg(u"࠵࠵࠵࠶࠰ಗ"):
		LLvyStW429DEZKlA(j8gFJIMYPoBzcCvG9T,lTW9p1v7uPfOxB(Q8Q0IDc6PLZajJAdTntKUmSGXz)+Ie5s2cBtSfdHjzQ4rA9kYlo6D18(u"࡚ࠧࠡࠢࠣ࡮ࡪࡥࡰࠢࡩ࡭ࡱ࡫ࠠࡪࡵࠣࡸࡴࡵࠠࡴ࡯ࡤࡰࡱࠦ࡯ࡳࠢ࡬ࡸࠥ࡯ࡳࠡ࡯࠶ࡹ࠽ࠦࠠࠡࡗࡕࡐ࠿࡛ࠦࠡࠩే")+WSQlG8mDhqsNe+UUDAiytEL76RTmMYsuIz5evXB(u"ࠨࠢࡠࠤࠥࠦࡖࡪࡦࡨࡳࠥ࡬ࡩ࡭ࡧࠣࡷ࡮ࢀࡥ࠻ࠢ࡞ࠤࠬై")+str(KKahdkrjb61p4zJSytY)+YY8UDX3MJhb91AHw7fg(u"ࠩࠣࡑࡇࠦ࡝ࠡࠢࠣࡅࡻࡧࡩ࡭ࡣࡥࡰࡪࠦࡳࡪࡼࡨ࠾ࠥࡡࠠࠨ౉")+str(J8QWl5zrS0FHyhBtqPK2kOCi3djXVE)+lljaEqwTVtmKsQcOrbXxS5hgNH(u"ࠪࠤࡒࡈࠠ࡞ࠢࠣࠤࡋ࡯࡬ࡦ࠼ࠣ࡟ࠥ࠭ొ")+T0jVYrzHDqwE8ScfXxu3BtkhgyPvlC+LZWMikPEB81KSGyxfJtUsCA(u"ࠫࠥࡣࠧో"))
		iG7Rz2kmn0x1yLNMV3u8O(qpFY4hAwolV3,qpFY4hAwolV3,GLTtERWbHnFuy4PCp,DiJ8CMuYH1daWyjehfN0L(u"ࠬ็ิๅࠢไ๎ู๋ࠥาใฬࠤาาๅࠡ็็ๅࠥอไโ์า๎ํࠦร้ࠢส่๊๊แࠡื฽๎ึࠦฬะษࠣ์้ํะศࠢ็หࠥ๐ๅไ่่้ࠣฮั็ษ่ะࠥะอๆ์็ࠤ์ึวࠡษ็้้็ࠧౌ"))
		return ag8rjZo1Vz4IPdcOT
	R7Io4HlteTLEMck8jCh93 = V3VlkhgjEF4n1erPXHcC0NOsfwyAJ(u"࠸࠵࠶ಘ")
	cJ6tl8IVskWQ0TxBea = J8QWl5zrS0FHyhBtqPK2kOCi3djXVE-KKahdkrjb61p4zJSytY
	if cJ6tl8IVskWQ0TxBea<R7Io4HlteTLEMck8jCh93:
		LLvyStW429DEZKlA(j8gFJIMYPoBzcCvG9T,lTW9p1v7uPfOxB(Q8Q0IDc6PLZajJAdTntKUmSGXz)+ddiCzu6yahj5RtTISMJ48sNnZBU(u"࠭ࠠࠡࠢࡑࡳࡹࠦࡥ࡯ࡱࡸ࡫࡭ࠦࡤࡪࡵ࡮ࠤࡸࡶࡡࡤࡧࠣࡸࡴࠦࡤࡰࡹࡱࡰࡴࡧࡤࠡࡶ࡫ࡩࠥࡼࡩࡥࡧࡲࠤ࡫࡯࡬ࡦࠢࠣࠤ࡚ࡘࡌ࠻ࠢ࡞ࠤ్ࠬ")+WSQlG8mDhqsNe+qoBMmfAWpFlK70xw8ZRh4naJ(u"ࠧࠡ࡟ࠣࠤࠥ࡜ࡩࡥࡧࡲࠤ࡫࡯࡬ࡦࠢࡶ࡭ࡿ࡫࠺ࠡ࡝ࠣࠫ౎")+str(KKahdkrjb61p4zJSytY)+viRJWOC5jsYe84(u"ࠨࠢࡐࡆࠥࡣࠠࠡࠢࡄࡺࡦ࡯࡬ࡢࡤ࡯ࡩࠥࡹࡩࡻࡧ࠽ࠤࡠࠦࠧ౏")+str(J8QWl5zrS0FHyhBtqPK2kOCi3djXVE)+LZWMikPEB81KSGyxfJtUsCA(u"ࠩࠣࡑࡇࠦ࠭ࠡࠩ౐")+str(R7Io4HlteTLEMck8jCh93)+zYvEaigKWjoq50pXBLDbGJkFc(u"ࠪࠤࡒࡈࠠ࡞ࠢࠣࠤࡋ࡯࡬ࡦ࠼ࠣ࡟ࠥ࠭౑")+T0jVYrzHDqwE8ScfXxu3BtkhgyPvlC+ddiCzu6yahj5RtTISMJ48sNnZBU(u"ࠫࠥࡣࠧ౒"))
		iG7Rz2kmn0x1yLNMV3u8O(qpFY4hAwolV3,qpFY4hAwolV3,DaFZHsThGmd0zv6e(u"๊ࠬวࠡ์๋ะิࠦๅิษะอ้ࠥวโ์ฬࠤ้๊สฮ็ํ่ࠬ౓"),UVa3fJw7k6KM(u"࠭วๅ็็ๅࠥอไๆู็์อࠦสฮ็ํ่์ࠦออ็๊ࠤࠬ౔")+str(KKahdkrjb61p4zJSytY)+UVa3fJw7k6KM(u"ࠧࠡ็ํ฾ฬฮว๋ฬࠣ์ัํวำๅࠣๅ๏ํࠠๆีสัฮࠦแศำ฽อౕࠥ࠭")+str(J8QWl5zrS0FHyhBtqPK2kOCi3djXVE)+zYvEaigKWjoq50pXBLDbGJkFc(u"ࠨ่ࠢ๎฿อศศ์อࠤํ๊ไๆฯสๅ฽ฯฺࠠๆ์ࠤ฾๋ไࠡฮ๊หื้ࠠษั๋๊๋ࠥิศๅ็ࠤ๏าศࠡวหๆฬวࠠࠨౖ")+str(R7Io4HlteTLEMck8jCh93)+ddiCzu6yahj5RtTISMJ48sNnZBU(u"้ࠩࠣ๏เวษษํฮࠥ็วา฼ฬࠤิอฦๆษࠣ์์ึวࠡ็฼๊ฬํࠠฤ่ࠣะ์อาไࠢ็หࠥะ่อัࠣๅ๏ํࠠๆีสัฮࠦใศใํอ๊ࠥสฮ็ํ่๋ࠥไโࠢส่ๆ๐ฯ๋๊ࠣห้๋ืๅ๊หࠫ౗"))
		return ag8rjZo1Vz4IPdcOT
	o4oUxD3u18K59ghHIY = VVpbtSKYUGXrNMwAWFo9IOjZP(DiJ8CMuYH1daWyjehfN0L(u"ࠪࡧࡪࡴࡴࡦࡴࠪౘ"),qpFY4hAwolV3,qpFY4hAwolV3,l32dnTEOU1skGKqeBtI9hmo(u"ࠫ์๊ࠠหำํำࠥะอๆ์็ࠤฬ๊ๅๅใࠣรࠬౙ"),V3VlkhgjEF4n1erPXHcC0NOsfwyAJ(u"ࠬอไๆๆไࠤฬ๊ๅุๆ๋ฬࠥำฬๆ้ࠣฮ็ื๊ษษࠣࠫౚ")+str(KKahdkrjb61p4zJSytY)+RlOvin8YIGC2KZXJPk9m0acrMobUex(u"࠭ࠠๆ์฽หออ๊ห๋ࠢะ์อาไࠢไ๎์ࠦๅิษะอࠥ็วา฼ฬࠤฯ่ั๋สสࠤࠬ౛")+str(J8QWl5zrS0FHyhBtqPK2kOCi3djXVE)+UUDAiytEL76RTmMYsuIz5evXB(u"ࠧࠡ็ํ฾ฬฮว๋ฬࠣ์์ึวࠡษ็้้็ࠠใัࠣ๎าะวอࠢห฽฻ࠦวๅ๊ๅฮ๊ࠥไหฯ่๎้ࠦๅ็ࠢส่ส์สา่อࠤส๊้ࠡฮ๊หื้ࠠ࠯๊่ࠢࠥอๆห่ࠢฮศ้ฯ๊ࠡอี๏ีࠠศๆสืฯ๋ัศำࠣฬฯำๅ๋ๆ้้ࠣ็ࠠศๆไ๎ิ๐่ࠡมࠪ౜"))
	if o4oUxD3u18K59ghHIY!=iNc3KxwErnQ(u"࠶ಙ"):
		iG7Rz2kmn0x1yLNMV3u8O(qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,DiJ8CMuYH1daWyjehfN0L(u"ࠨฬ่ࠤสฺ๊ศรࠣ฽๊๊๊สࠢอั๊๐ไࠡ็็ๅࠥอไโ์า๎ํ࠭ౝ"))
		LLvyStW429DEZKlA(k8kdUSxohLVljnrY,lTW9p1v7uPfOxB(Q8Q0IDc6PLZajJAdTntKUmSGXz)+UVa3fJw7k6KM(u"ࠩࠣࠤ࡛ࠥࡳࡦࡴࠣࡧࡦࡴࡣࡦ࡮ࡨࡨࠥࡺࡨࡦࠢࡧࡳࡼࡴ࡬ࡰࡣࡧࠤࡴ࡬ࠠࡵࡪࡨࠤࡻ࡯ࡤࡦࡱࠣࡪ࡮ࡲࡥ࡙ࠡࠢࠣࡗࡒ࠺ࠡ࡝ࠣࠫ౞")+WSQlG8mDhqsNe+kYDaz79TFlXoR(u"ࠪࠤࡢࠦࠠࠡࡈ࡬ࡰࡪࡀࠠ࡜ࠢࠪ౟")+T0jVYrzHDqwE8ScfXxu3BtkhgyPvlC+rNdBKI74fAklnoCZ6(u"ࠫࠥࡣࠧౠ"))
		return ag8rjZo1Vz4IPdcOT
	LLvyStW429DEZKlA(k8kdUSxohLVljnrY,lTW9p1v7uPfOxB(Q8Q0IDc6PLZajJAdTntKUmSGXz)+V3VlkhgjEF4n1erPXHcC0NOsfwyAJ(u"ࠬࠦࠠࠡࡆࡲࡻࡳࡲ࡯ࡢࡦࠣࡷࡹࡧࡲࡵࡧࡧࠤࡸࡻࡣࡤࡧࡶࡷ࡫ࡻ࡬࡭ࡻࠪౡ"))
	r2reEIBPDyxK5u3RhFq = W4HCP0bkSsNZlXp()
	r2reEIBPDyxK5u3RhFq.create(T0jVYrzHDqwE8ScfXxu3BtkhgyPvlC,viRJWOC5jsYe84(u"࠭วๅีฺีࠥ็่ใ๊ࠢ์๋ࠥใศ่ࠣฮำุ๊็่่ࠢๆࠦวๅใํำ๏๎ࠧౢ"))
	VLnafQMgjO9dCe5mvbW = gBExoceumj4y8bFW9hY2aNMVSr
	Z0JRfngy6coNe8FsCIu2O9tip = s7FnXZYOgexlH2MPb8BJck1AKv9.time()
	if not i4bFG3rKE6.ZZFcMiWJ3nfg29XH4L:
		iG7Rz2kmn0x1yLNMV3u8O(qpFY4hAwolV3,qpFY4hAwolV3,GLTtERWbHnFuy4PCp,N3flV6EJsD5CzS(u"ࠧษีหฬࠥ฿ฯๆࠢส่ฯฮัฺࠢอ้ࠥหไ฻ษฤࠤฯำๅ๋ๆ้้ࠣ็ࠠศๆไ๎ิ๐่ࠨౣ"))
		return ag8rjZo1Vz4IPdcOT
	if DLod2Of8CkRrtzJynev: ESqRDuntjYZFBO2oXVkGQfNa = open(T0jVYrzHDqwE8ScfXxu3BtkhgyPvlC,ee86G9ladLHVbh5mikzCo(u"ࠨࡹࡥࠫ౤"))
	else: ESqRDuntjYZFBO2oXVkGQfNa = open(T0jVYrzHDqwE8ScfXxu3BtkhgyPvlC.decode(nV3Tip6XsH1rJw79DPOU),fWoVd0Bmtkx(u"ࠩࡺࡦࠬ౥"))
	if gyEQS6JIZKa==DaFZHsThGmd0zv6e(u"ࠪ࠲ࡲ࠹ࡵ࠹ࠩ౦"):
		for nnZ13Rr6tYXio0DyfLVvSxBec in range(Ie5s2cBtSfdHjzQ4rA9kYlo6D18(u"࠷ಚ"),qqZPRzobWCpDXUVQt6KkFg+Ie5s2cBtSfdHjzQ4rA9kYlo6D18(u"࠷ಚ")):
			MepIvHBYNArkUOdV37shtJ = CFevtSjzbpn[nnZ13Rr6tYXio0DyfLVvSxBec-UVa3fJw7k6KM(u"࠱ಛ")]
			if not MepIvHBYNArkUOdV37shtJ.startswith(tQMjXKCA5dN4xq3beVIzaEoWkFLg(u"ࠫ࡭ࡺࡴࡱࠩ౧")):
				if MepIvHBYNArkUOdV37shtJ.startswith(ttrDbyV5cSO2FjgTzew6qM): MepIvHBYNArkUOdV37shtJ = WSQlG8mDhqsNe.split(fWoVd0Bmtkx(u"ࠬࡀࠧ౨"),dJHDqiKf12TXlIzSLkGUuxg4MBs3A(u"࠲ಜ"))[vvXoMLlg513]+IaBhDMJc17302LgSvyxd(u"࠭࠺ࠨ౩")+MepIvHBYNArkUOdV37shtJ
				elif MepIvHBYNArkUOdV37shtJ.startswith(ShynO8pN9idCE3): MepIvHBYNArkUOdV37shtJ = AWeJuo2LhZ5xiD8KNSqd9G0rtT74FE(WSQlG8mDhqsNe,qqzwE6imYG4c2xojI(u"ࠧࡶࡴ࡯ࠫ౪"))+MepIvHBYNArkUOdV37shtJ
				else: MepIvHBYNArkUOdV37shtJ = WSQlG8mDhqsNe.rsplit(ShynO8pN9idCE3,tQMjXKCA5dN4xq3beVIzaEoWkFLg(u"࠳ಝ"))[vvXoMLlg513]+ShynO8pN9idCE3+MepIvHBYNArkUOdV37shtJ
			UEey2i9D3MTfhd7okHj6QSqJp0VBYA = lFScPefz0pyYM7QrH41n6woV.request(tQMjXKCA5dN4xq3beVIzaEoWkFLg(u"ࠨࡉࡈࡘࠬ౫"),MepIvHBYNArkUOdV37shtJ,headers=EBOwuZ71x92omaIKbGFU3A54pqkc,verify=ag8rjZo1Vz4IPdcOT)
			z6DmT7KVnfo32dZR = UEey2i9D3MTfhd7okHj6QSqJp0VBYA.content
			UEey2i9D3MTfhd7okHj6QSqJp0VBYA.close()
			ESqRDuntjYZFBO2oXVkGQfNa.write(z6DmT7KVnfo32dZR)
			dgyMG76vzkC0HKVP4sD = s7FnXZYOgexlH2MPb8BJck1AKv9.time()
			tuFo4DWRr0I = dgyMG76vzkC0HKVP4sD-Z0JRfngy6coNe8FsCIu2O9tip
			RozxY56HAMvEiDtcPVKjTWd = tuFo4DWRr0I//nnZ13Rr6tYXio0DyfLVvSxBec
			CmrUVknHE4pfbzs9Yd1lo = RozxY56HAMvEiDtcPVKjTWd*(qqZPRzobWCpDXUVQt6KkFg+UUDAiytEL76RTmMYsuIz5evXB(u"࠴ಞ"))
			fj2s5AQBiOkDaSztHG3P0WhoMV = CmrUVknHE4pfbzs9Yd1lo-tuFo4DWRr0I
			fgVlCuI8wy0znKvp1E5oj9xmD(r2reEIBPDyxK5u3RhFq,int(mmV2nucZ5Lpl6FO1JMPEqGoQKW(u"࠶࠶࠰ಠ")*nnZ13Rr6tYXio0DyfLVvSxBec//(qqZPRzobWCpDXUVQt6KkFg+UUDAiytEL76RTmMYsuIz5evXB(u"࠵ಟ"))),V3VlkhgjEF4n1erPXHcC0NOsfwyAJ(u"ࠩสุ่฽ัࠡใ๋ๆࠥํ่ࠡ็ๆห๋ࠦสฯิํ๊๋ࠥไโࠢส่ๆ๐ฯ๋๊ࠪ౬"),zYvEaigKWjoq50pXBLDbGJkFc(u"ࠪะ้ฮࠠๆๆไࠤฬ๊แ๋ัํ์࠿࠳ࠠศๆฯึฦࠦัใ็ࠪ౭"),str(nnZ13Rr6tYXio0DyfLVvSxBec*mE2Tvl8q7iGnhDK3zB//aHgp7ChWjV32)+ShynO8pN9idCE3+str(KKahdkrjb61p4zJSytY)+LZWMikPEB81KSGyxfJtUsCA(u"ࠫࠥࡓࡂࠡࠢࠣࠤํ่สࠡ็อฬ็๐࠺ࠡࠩ౮")+s7FnXZYOgexlH2MPb8BJck1AKv9.strftime(DaFZHsThGmd0zv6e(u"ࠧࠫࡈ࠻ࠧࡐ࠾࡙ࠪࠢ౯"),s7FnXZYOgexlH2MPb8BJck1AKv9.gmtime(fj2s5AQBiOkDaSztHG3P0WhoMV))+YY8UDX3MJhb91AHw7fg(u"࠭ࠠแࠩ౰"))
			if r2reEIBPDyxK5u3RhFq.iscanceled():
				VLnafQMgjO9dCe5mvbW = ag8rjZo1Vz4IPdcOT
				break
	else:
		nnZ13Rr6tYXio0DyfLVvSxBec = LZWMikPEB81KSGyxfJtUsCA(u"࠶ಡ")
		for z6DmT7KVnfo32dZR in UEey2i9D3MTfhd7okHj6QSqJp0VBYA.iter_content(chunk_size=mE2Tvl8q7iGnhDK3zB):
			ESqRDuntjYZFBO2oXVkGQfNa.write(z6DmT7KVnfo32dZR)
			nnZ13Rr6tYXio0DyfLVvSxBec = nnZ13Rr6tYXio0DyfLVvSxBec+l1DZAt9XNQjqE7YOdrz(u"࠱ಢ")
			dgyMG76vzkC0HKVP4sD = s7FnXZYOgexlH2MPb8BJck1AKv9.time()
			tuFo4DWRr0I = dgyMG76vzkC0HKVP4sD-Z0JRfngy6coNe8FsCIu2O9tip
			RozxY56HAMvEiDtcPVKjTWd = tuFo4DWRr0I/nnZ13Rr6tYXio0DyfLVvSxBec
			CmrUVknHE4pfbzs9Yd1lo = RozxY56HAMvEiDtcPVKjTWd*(qqZPRzobWCpDXUVQt6KkFg+tQMjXKCA5dN4xq3beVIzaEoWkFLg(u"࠲ಣ"))
			fj2s5AQBiOkDaSztHG3P0WhoMV = CmrUVknHE4pfbzs9Yd1lo-tuFo4DWRr0I
			fgVlCuI8wy0znKvp1E5oj9xmD(r2reEIBPDyxK5u3RhFq,int(qoBMmfAWpFlK70xw8ZRh4naJ(u"࠴࠴࠵ಥ")*nnZ13Rr6tYXio0DyfLVvSxBec/(qqZPRzobWCpDXUVQt6KkFg+rNdBKI74fAklnoCZ6(u"࠳ತ"))),lljaEqwTVtmKsQcOrbXxS5hgNH(u"ࠧศๆึ฻ึࠦแ้ไ๋ࠣํࠦๅไษ้ࠤฯิา๋่้้ࠣ็ࠠศๆไ๎ิ๐่ࠨ౱"),viRJWOC5jsYe84(u"ࠨฮ็ฬ๋ࠥไโࠢส่ๆ๐ฯ๋๊࠽࠱ࠥอไอิฤࠤึ่ๅࠨ౲"),str(nnZ13Rr6tYXio0DyfLVvSxBec*mE2Tvl8q7iGnhDK3zB//aHgp7ChWjV32)+ShynO8pN9idCE3+str(KKahdkrjb61p4zJSytY)+V3VlkhgjEF4n1erPXHcC0NOsfwyAJ(u"ࠩࠣࡑࡇ๋ࠦࠠࠡࠢๆฯࠦๅหสๅ๎࠿ࠦࠧ౳")+s7FnXZYOgexlH2MPb8BJck1AKv9.strftime(iNc3KxwErnQ(u"ࠥࠩࡍࡀࠥࡎ࠼ࠨࡗࠧ౴"),s7FnXZYOgexlH2MPb8BJck1AKv9.gmtime(fj2s5AQBiOkDaSztHG3P0WhoMV))+YY8UDX3MJhb91AHw7fg(u"ࠫࠥๆࠧ౵"))
			if r2reEIBPDyxK5u3RhFq.iscanceled():
				VLnafQMgjO9dCe5mvbW = ag8rjZo1Vz4IPdcOT
				break
		UEey2i9D3MTfhd7okHj6QSqJp0VBYA.close()
	ESqRDuntjYZFBO2oXVkGQfNa.close()
	r2reEIBPDyxK5u3RhFq.close()
	if not VLnafQMgjO9dCe5mvbW:
		LLvyStW429DEZKlA(k8kdUSxohLVljnrY,lTW9p1v7uPfOxB(Q8Q0IDc6PLZajJAdTntKUmSGXz)+V3VlkhgjEF4n1erPXHcC0NOsfwyAJ(u"ࠬࠦࠠࠡࡗࡶࡩࡷࠦࡣࡢࡰࡦࡩࡱ࡫ࡤ࠰࡫ࡱࡸࡪࡸࡲࡶࡲࡷࡩࡩࠦࡴࡩࡧࠣࡨࡴࡽ࡮࡭ࡱࡤࡨࠥࡶࡲࡰࡥࡨࡷࡸࠦࠠࠡࡗࡕࡐ࠿࡛ࠦࠡࠩ౶")+WSQlG8mDhqsNe+viRJWOC5jsYe84(u"࠭ࠠ࡞ࠢࠣࠤࡋ࡯࡬ࡦ࠼ࠣ࡟ࠥ࠭౷")+T0jVYrzHDqwE8ScfXxu3BtkhgyPvlC+dJHDqiKf12TXlIzSLkGUuxg4MBs3A(u"ࠧࠡ࡟ࠪ౸"))
		iG7Rz2kmn0x1yLNMV3u8O(qpFY4hAwolV3,qpFY4hAwolV3,GLTtERWbHnFuy4PCp,N3flV6EJsD5CzS(u"ࠨสะือࠦืๅสๆࠤฯ๋ࠠฦๆ฽หฦูࠦๆๆํอࠥะอๆ์็ࠤ๊๊แࠡษ็ๅ๏ี๊้ࠩ౹"))
		return gBExoceumj4y8bFW9hY2aNMVSr
	LLvyStW429DEZKlA(k8kdUSxohLVljnrY,lTW9p1v7uPfOxB(Q8Q0IDc6PLZajJAdTntKUmSGXz)+ee86G9ladLHVbh5mikzCo(u"ࠩࠣࠤࠥ࡜ࡩࡥࡧࡲࠤ࡫࡯࡬ࡦࠢࡧࡳࡼࡴ࡬ࡰࡣࡧࡩࡩࠦࡳࡶࡥࡦࡩࡸࡹࡦࡶ࡮࡯ࡽࠥࠦࠠࡖࡔࡏ࠾ࠥࡡࠠࠨ౺")+WSQlG8mDhqsNe+fWoVd0Bmtkx(u"ࠪࠤࡢࠦࠠࠡࡈ࡬ࡰࡪࡀࠠ࡜ࠢࠪ౻")+T0jVYrzHDqwE8ScfXxu3BtkhgyPvlC+qoBMmfAWpFlK70xw8ZRh4naJ(u"ࠫࠥࡣࠧ౼"))
	iG7Rz2kmn0x1yLNMV3u8O(qpFY4hAwolV3,qpFY4hAwolV3,GLTtERWbHnFuy4PCp,Ie5s2cBtSfdHjzQ4rA9kYlo6D18(u"ࠬะๅࠡฬะ้๏๊ࠠๆๆไࠤฬ๊แ๋ัํ์ࠥฮๆอษะࠫ౽"))
	return gBExoceumj4y8bFW9hY2aNMVSr