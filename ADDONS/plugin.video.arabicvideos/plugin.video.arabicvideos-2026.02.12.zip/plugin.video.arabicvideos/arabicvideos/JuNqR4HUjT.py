# -*- coding: utf-8 -*-
from pSfaryIjBo import *
Q8Q0IDc6PLZajJAdTntKUmSGXz = 'ALFATIMI'
wwSFijdVJn1QgHW = '_FTM_'
ddBxj51bhNtaK23lDyGMVw = i4bFG3rKE6.SITESURLS[Q8Q0IDc6PLZajJAdTntKUmSGXz][0]
yrDHPTzRYOUGv6XfZiCSs = ['1239','1250','1245','20','1259','218','485','1238','1258','292']
zq46t8Peb1KpNUJ5rGaIBCuXsRdl = ['3030','628']
def vTNE2Ck1sGnugJYW8y39aLcSH64U(mode,url,text):
	if   mode==60: MOTjA5H9XFs = nRVAZc4Dp8PSrGU3xBk()
	elif mode==61: MOTjA5H9XFs = c8U1BdtxOZS5FH(url,text)
	elif mode==62: MOTjA5H9XFs = v1gmfxDcRrWKQ(url)
	elif mode==63: MOTjA5H9XFs = mzcAeyplZV(url)
	elif mode==64: MOTjA5H9XFs = kvrROcPmibde1gTWojHpV(text)
	elif mode==69: MOTjA5H9XFs = PPqUACSE3VcGLTvw05jHy9JrFNW(text)
	else: MOTjA5H9XFs = False
	return MOTjA5H9XFs
def nRVAZc4Dp8PSrGU3xBk():
	x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+'بحث في الموقع',qpFY4hAwolV3,69,qpFY4hAwolV3,qpFY4hAwolV3,'_REMEMBERRESULTS_')
	x3WSXnKyPhjqfHG2UrtQs('folder',Q8Q0IDc6PLZajJAdTntKUmSGXz+'_SCRIPT_'+wwSFijdVJn1QgHW+'ما يتم مشاهدته الان',ddBxj51bhNtaK23lDyGMVw,64,qpFY4hAwolV3,qpFY4hAwolV3,'recent_viewed_vids')
	x3WSXnKyPhjqfHG2UrtQs('folder',Q8Q0IDc6PLZajJAdTntKUmSGXz+'_SCRIPT_'+wwSFijdVJn1QgHW+'الاكثر مشاهدة',ddBxj51bhNtaK23lDyGMVw,64,qpFY4hAwolV3,qpFY4hAwolV3,'most_viewed_vids')
	x3WSXnKyPhjqfHG2UrtQs('folder',Q8Q0IDc6PLZajJAdTntKUmSGXz+'_SCRIPT_'+wwSFijdVJn1QgHW+'اضيفت مؤخرا',ddBxj51bhNtaK23lDyGMVw,64,qpFY4hAwolV3,qpFY4hAwolV3,'recently_added_vids')
	x3WSXnKyPhjqfHG2UrtQs('folder',Q8Q0IDc6PLZajJAdTntKUmSGXz+'_SCRIPT_'+wwSFijdVJn1QgHW+'فيديو عشوائي',ddBxj51bhNtaK23lDyGMVw,64,qpFY4hAwolV3,qpFY4hAwolV3,'random_vids')
	x3WSXnKyPhjqfHG2UrtQs('folder',Q8Q0IDc6PLZajJAdTntKUmSGXz+'_SCRIPT_'+wwSFijdVJn1QgHW+'افلام ومسلسلات',ddBxj51bhNtaK23lDyGMVw,61,qpFY4hAwolV3,qpFY4hAwolV3,'-1')
	x3WSXnKyPhjqfHG2UrtQs('folder',Q8Q0IDc6PLZajJAdTntKUmSGXz+'_SCRIPT_'+wwSFijdVJn1QgHW+'البرامج الدينية',ddBxj51bhNtaK23lDyGMVw,61,qpFY4hAwolV3,qpFY4hAwolV3,'-2')
	x3WSXnKyPhjqfHG2UrtQs('folder',Q8Q0IDc6PLZajJAdTntKUmSGXz+'_SCRIPT_'+wwSFijdVJn1QgHW+'English Videos',ddBxj51bhNtaK23lDyGMVw,61,qpFY4hAwolV3,qpFY4hAwolV3,'-3')
	return qpFY4hAwolV3
def c8U1BdtxOZS5FH(url,n1uwH0oJaGZ5WBd):
	wAiu7RQK1rboNnLS0vMEI = qpFY4hAwolV3
	if n1uwH0oJaGZ5WBd not in ['-1','-2','-3']: wAiu7RQK1rboNnLS0vMEI = '?cat='+n1uwH0oJaGZ5WBd
	WSQlG8mDhqsNe = ddBxj51bhNtaK23lDyGMVw+'/menu_level.php'+wAiu7RQK1rboNnLS0vMEI
	cmWl9dOKHPIy41iaXuxrY = GMqfDK9V4F8eTPE1pNOAaiYUbhr(kUz8c7OqsxuPFIGfwg,WSQlG8mDhqsNe,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,'ALFATIMI-TITLES-1st')
	items = ePhmG1jLD6.findall('href=\'(.*?)\'.*?>(.*?)<.*?>(.*?)</span>',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	vv7cpjFmH8,u0eDOmMnFCiR = False,False
	for MepIvHBYNArkUOdV37shtJ,title,count in items:
		title = j8PDV0pthfSTidZbsQxNIOmCYKWzH(title)
		title = title.strip(mIsDke0oK5x1zSiOWbF9thGcA)
		if 'http' not in MepIvHBYNArkUOdV37shtJ: MepIvHBYNArkUOdV37shtJ = 'http:'+MepIvHBYNArkUOdV37shtJ
		wAiu7RQK1rboNnLS0vMEI = ePhmG1jLD6.findall('cat=(.*?)&',MepIvHBYNArkUOdV37shtJ,ePhmG1jLD6.DOTALL)[0]
		if n1uwH0oJaGZ5WBd==wAiu7RQK1rboNnLS0vMEI: vv7cpjFmH8 = True
		elif vv7cpjFmH8 	or (n1uwH0oJaGZ5WBd=='-1' and wAiu7RQK1rboNnLS0vMEI in yrDHPTzRYOUGv6XfZiCSs)  						or (n1uwH0oJaGZ5WBd=='-2' and wAiu7RQK1rboNnLS0vMEI not in zq46t8Peb1KpNUJ5rGaIBCuXsRdl and wAiu7RQK1rboNnLS0vMEI not in yrDHPTzRYOUGv6XfZiCSs)  						or (n1uwH0oJaGZ5WBd=='-3' and wAiu7RQK1rboNnLS0vMEI in zq46t8Peb1KpNUJ5rGaIBCuXsRdl):
							if count=='1': x3WSXnKyPhjqfHG2UrtQs('video',wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,63)
							else: x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,61,qpFY4hAwolV3,qpFY4hAwolV3,wAiu7RQK1rboNnLS0vMEI)
							u0eDOmMnFCiR = True
	if not u0eDOmMnFCiR: v1gmfxDcRrWKQ(url)
	return
def v1gmfxDcRrWKQ(url):
	cmWl9dOKHPIy41iaXuxrY = GMqfDK9V4F8eTPE1pNOAaiYUbhr(kUz8c7OqsxuPFIGfwg,url,qpFY4hAwolV3,qpFY4hAwolV3,True,'ALFATIMI-EPISODES-1st')
	pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('pagination(.*?)id="footer',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	mVYdjvor6i4wZ8 = pfRkcVlLmUxo561g0A8qSbO[0]
	items = ePhmG1jLD6.findall('grid_view.*?src="(.*?)".*?title="(.*?)".*?<h2.*?href="(.*?)"',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
	MepIvHBYNArkUOdV37shtJ = qpFY4hAwolV3
	for Sj7rMNYRuQPTtkBvpHKeDW3h,title,MepIvHBYNArkUOdV37shtJ in items:
		title = title.replace('Add',qpFY4hAwolV3).replace('to Quicklist',qpFY4hAwolV3).strip(mIsDke0oK5x1zSiOWbF9thGcA)
		if 'http' not in MepIvHBYNArkUOdV37shtJ: MepIvHBYNArkUOdV37shtJ = 'http:'+MepIvHBYNArkUOdV37shtJ
		x3WSXnKyPhjqfHG2UrtQs('video',wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,63,Sj7rMNYRuQPTtkBvpHKeDW3h)
	pfRkcVlLmUxo561g0A8qSbO=ePhmG1jLD6.findall('(.*?)div',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
	mVYdjvor6i4wZ8=pfRkcVlLmUxo561g0A8qSbO[0]
	mVYdjvor6i4wZ8=ePhmG1jLD6.findall('pagination(.*?)</div>',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)[0]
	items=ePhmG1jLD6.findall('href="(.*?)".*?>(.*?)<',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
	WSQlG8mDhqsNe = url.split('?')[0]
	for MepIvHBYNArkUOdV37shtJ,oIPJVAsxMyShfcYrqWng in items:
		MepIvHBYNArkUOdV37shtJ = WSQlG8mDhqsNe + MepIvHBYNArkUOdV37shtJ
		title = j8PDV0pthfSTidZbsQxNIOmCYKWzH(oIPJVAsxMyShfcYrqWng)
		title = 'صفحة ' + title
		x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,62)
	return MepIvHBYNArkUOdV37shtJ
def mzcAeyplZV(url):
	if 'videos.php' in url: url = v1gmfxDcRrWKQ(url)
	cmWl9dOKHPIy41iaXuxrY = GMqfDK9V4F8eTPE1pNOAaiYUbhr(KOyPvpEztYLaZRdMQJWxfTNFHbkg,url,qpFY4hAwolV3,qpFY4hAwolV3,True,'ALFATIMI-PLAY-1st')
	items = ePhmG1jLD6.findall('playlistfile:"(.*?)"',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	url = items[0]
	if 'http' not in url: url = 'http:'+url
	dORtnXbEgi5A8m0CH(url,Q8Q0IDc6PLZajJAdTntKUmSGXz,'video')
	return
def kvrROcPmibde1gTWojHpV(n1uwH0oJaGZ5WBd):
	GI0fwOUzWlVYaicPdBRunFy = { 'mode' : n1uwH0oJaGZ5WBd }
	url = 'http://alfatimi.tv/ajax.php'
	headers = { 'Content-Type' : 'application/x-www-form-urlencoded' }
	data = AfCyLXU4p8uE6H39Z7D(GI0fwOUzWlVYaicPdBRunFy)
	cmWl9dOKHPIy41iaXuxrY = GMqfDK9V4F8eTPE1pNOAaiYUbhr(rGY36xBwT1bLZAngSfcWEIeXdQVNij,url,data,headers,True,'ALFATIMI-MOSTS-1st')
	items = ePhmG1jLD6.findall('href="(.*?)".*?title="(.*?)".*?src="(.*?)".*?href',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	for MepIvHBYNArkUOdV37shtJ,title,Sj7rMNYRuQPTtkBvpHKeDW3h in items:
		title = title.strip(mIsDke0oK5x1zSiOWbF9thGcA)
		if 'http' not in MepIvHBYNArkUOdV37shtJ: MepIvHBYNArkUOdV37shtJ = 'http:'+MepIvHBYNArkUOdV37shtJ
		x3WSXnKyPhjqfHG2UrtQs('video',wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,63,Sj7rMNYRuQPTtkBvpHKeDW3h)
	return
def PPqUACSE3VcGLTvw05jHy9JrFNW(search):
	search,LBylNhMdH6OV1qGk0tWiXFg3,showDialogs = LLm3sBXHPcnTDxdE5gt6hz0Wkp(search)
	if search==qpFY4hAwolV3: search = jXgARlWMLVFUBnvmZwI2o5()
	if search==qpFY4hAwolV3: return
	K7m9Otk3h1VYIN8rcP6jp2 = search.replace(mIsDke0oK5x1zSiOWbF9thGcA,'+')
	url = ddBxj51bhNtaK23lDyGMVw + '/search_result.php?query=' + K7m9Otk3h1VYIN8rcP6jp2
	v1gmfxDcRrWKQ(url)
	return