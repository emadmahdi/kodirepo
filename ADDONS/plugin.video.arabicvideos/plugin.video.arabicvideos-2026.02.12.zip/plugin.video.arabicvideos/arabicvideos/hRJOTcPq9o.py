# -*- coding: utf-8 -*-
from pSfaryIjBo import *
Q8Q0IDc6PLZajJAdTntKUmSGXz = 'DAILYMOTION'
wwSFijdVJn1QgHW = '_DLM_'
ddBxj51bhNtaK23lDyGMVw = i4bFG3rKE6.SITESURLS[Q8Q0IDc6PLZajJAdTntKUmSGXz][0]
WsvFbLApfU = i4bFG3rKE6.SITESURLS[Q8Q0IDc6PLZajJAdTntKUmSGXz][1]
ecyzJ5qXfBnOiMHRLShmw = i4bFG3rKE6.SITESURLS[Q8Q0IDc6PLZajJAdTntKUmSGXz][2]
def vTNE2Ck1sGnugJYW8y39aLcSH64U(mode,url,text,type,i02wfPp5EM):
	if	 mode==400: MOTjA5H9XFs = nRVAZc4Dp8PSrGU3xBk()
	elif mode==401: MOTjA5H9XFs = YWuHFi18QkbIKjJvlTrgfX(url,text)
	elif mode==402: MOTjA5H9XFs = jQOV78wt0gnioeFyYHE4ukahc(url,text)
	elif mode==403: MOTjA5H9XFs = mzcAeyplZV(url,text)
	elif mode==404: MOTjA5H9XFs = jhzd07SxafLVucJ8v6(text,i02wfPp5EM)
	elif mode==405: MOTjA5H9XFs = GTbUZS3fv64MRAO2P9F17(text,i02wfPp5EM)
	elif mode==406: MOTjA5H9XFs = rMtdiKkEmsnXc7BxhDwbO8JaQ5R9qy(text,i02wfPp5EM)
	elif mode==407: MOTjA5H9XFs = G3esmuynchr5FT(url,i02wfPp5EM)
	elif mode==408: MOTjA5H9XFs = HobNL2t3zslR(url,i02wfPp5EM)
	elif mode==409: MOTjA5H9XFs = PPqUACSE3VcGLTvw05jHy9JrFNW(text,i02wfPp5EM)
	elif mode==411: MOTjA5H9XFs = BuQg8Nojq5Ph4aRw(url,text)
	elif mode==414: MOTjA5H9XFs = ztTGLogIFSW71RfqHx2Z(text)
	elif mode==415: MOTjA5H9XFs = c0IaUs6OEor7LhqHiu1NfVmAd(text,i02wfPp5EM)
	elif mode==416: MOTjA5H9XFs = qqIVKYoOZpdmHrz(text,i02wfPp5EM)
	elif mode==417: MOTjA5H9XFs = sdBe1SxHAZ(url,i02wfPp5EM)
	else: MOTjA5H9XFs = False
	return MOTjA5H9XFs
def nRVAZc4Dp8PSrGU3xBk():
	x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+'الرئيسية',qpFY4hAwolV3,414)
	x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+'بحث في الموقع',qpFY4hAwolV3,409,qpFY4hAwolV3,qpFY4hAwolV3,'_REMEMBERRESULTS_')
	x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+'بحث عن فيديوهات',qpFY4hAwolV3,409,qpFY4hAwolV3,'videos?sortBy=','_REMEMBERRESULTS_')
	x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+'بحث عن آخر الفيديوهات',qpFY4hAwolV3,409,qpFY4hAwolV3,'videos?sortBy=RECENT','_REMEMBERRESULTS_')
	x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+'بحث عن الفيديوهات الأكثر مشاهدة',qpFY4hAwolV3,409,qpFY4hAwolV3,'videos?sortBy=VIEW_COUNT','_REMEMBERRESULTS_')
	x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+'بحث عن قوائم التشغيل',qpFY4hAwolV3,409,qpFY4hAwolV3,'playlists','_REMEMBERRESULTS_')
	x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+'بحث عن مستخدم',qpFY4hAwolV3,409,qpFY4hAwolV3,'channels','_REMEMBERRESULTS_')
	x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+'بحث عن بث حي',qpFY4hAwolV3,409,qpFY4hAwolV3,'lives','_REMEMBERRESULTS_')
	x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+'بحث عن هاشتاك',qpFY4hAwolV3,409,qpFY4hAwolV3,'hashtags','_REMEMBERRESULTS_')
	return
def jQOV78wt0gnioeFyYHE4ukahc(url,qkUQREjo9ibsO50AMmLwJIhBxp):
	if '/dm_' in url:
		IAW0sh6So3NpqM = WWrExJZS3Bj4anOAkpv7(rGY36xBwT1bLZAngSfcWEIeXdQVNij,'GET',url,qpFY4hAwolV3,qpFY4hAwolV3,False,qpFY4hAwolV3,'DAILYMOTION-CHANNELS_SUBMENU-1st',False,False)
		headers = IAW0sh6So3NpqM.headers
		if 'Location' in list(headers.keys()): url = ddBxj51bhNtaK23lDyGMVw+headers['Location']
	qkUQREjo9ibsO50AMmLwJIhBxp = xupTj02bvy3O8R+qkUQREjo9ibsO50AMmLwJIhBxp+fF4lt9zWYxXLKZVyAco82PgMj
	qkUQREjo9ibsO50AMmLwJIhBxp = yId69qYhzF0ic(qkUQREjo9ibsO50AMmLwJIhBxp)
	x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+':: بث حي',url,411,qpFY4hAwolV3,qpFY4hAwolV3,'channel_lives_now')
	x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+':: آخر الفيديوهات',url+'/videos',408)
	x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+':: الأكثر مشاهدة',url+'/videos?sort=visited',408)
	x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+':: المميزة',url,411,qpFY4hAwolV3,qpFY4hAwolV3,'channel_featured_videos')
	x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+':: قوائم التشغيل',url+'/playlists',407)
	x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+':: قوائم التشغيل أبجدية',url+'/playlists?sort=alphaaz',407)
	x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+':: قنوات ذات صلة',url,411,qpFY4hAwolV3,qpFY4hAwolV3,'channel_related_channel')
	return
def yId69qYhzF0ic(title):
	title = title.rstrip('\\').strip(mIsDke0oK5x1zSiOWbF9thGcA).replace('\\\\','\\')
	title = N8E37XwL6iQbmBY(title)
	return title
def mzcAeyplZV(url,WtgVhfrHisQOy0p9UjMDT):
	import inVXFK46ET
	inVXFK46ET.q4qTJvuoQUzM3mZAtegy7IXdnb5wH([url],Q8Q0IDc6PLZajJAdTntKUmSGXz,'video',url)
	return
def jhzd07SxafLVucJ8v6(search,i02wfPp5EM=qpFY4hAwolV3):
	if i02wfPp5EM==qpFY4hAwolV3: i02wfPp5EM = '1'
	if 'sortBy=' in search: sort = search.split('sortBy=')[1].split('&')[0]
	else: sort = qpFY4hAwolV3
	search = search.split('/videos')[0]
	AMbRf4XTpQNvio6J5GELducy0k = '''{"operationName":"SEARCH_QUERY","variables":{"query":"mysearchwords","shouldIncludeChannels":false,"shouldIncludePlaylists":false,"shouldIncludeVideos":true,"page":mypagenumber,"limit":mypagelimitmysortmethod},"query":"fragment VIDEO_BASE_FRAGMENT on Video {  id  xid  title  createdAt  stats {    views {      total      __typename    }    __typename  }  channel {    id    xid    name    displayName    accountType    __typename  }  duration  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  __typename}fragment VIDEO_WATCH_LATER_FRAGMENT on Video {  id  isInWatchLater  __typename}fragment CHANNEL_BASE_FRAG on Channel {  accountType  id  xid  name  displayName  isFollowed  thumbnailx60: logoURL(size: \\"x60\\")  thumbnailx120: logoURL(size: \\"x120\\")  thumbnailx240: logoURL(size: \\"x240\\")  thumbnailx720: logoURL(size: \\"x720\\")  __typename}fragment PLAYLIST_BASE_FRAG on Collection {  id  xid  name  channel {    id    xid    name    displayName    accountType    __typename  }  description  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  stats {    videos {      total      __typename    }    __typename  }  __typename}query SEARCH_QUERY($query: String!, $shouldIncludeVideos: Boolean!, $shouldIncludeChannels: Boolean!, $shouldIncludePlaylists: Boolean!, $page: Int, $limit: Int, $sortByVideos: SearchVideoSort, $durationMinVideos: Int, $durationMaxVideos: Int, $createdAfterVideos: DateTime) {  search {    id    videos(query: $query, first: $limit, page: $page, sort: $sortByVideos, durationMin: $durationMinVideos, durationMax: $durationMaxVideos, createdAfter: $createdAfterVideos) @include(if: $shouldIncludeVideos) {      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...VIDEO_BASE_FRAGMENT          ...VIDEO_WATCH_LATER_FRAGMENT          __typename        }        __typename      }      __typename    }    channels(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeChannels) {      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...CHANNEL_BASE_FRAG          __typename        }        __typename      }      __typename    }    playlists: collections(query: $query, first: $limit, page: $page) @include(if: $shouldIncludePlaylists) {      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...PLAYLIST_BASE_FRAG          __typename        }        __typename      }      __typename    }    __typename  }}"}'''
	AMbRf4XTpQNvio6J5GELducy0k = AMbRf4XTpQNvio6J5GELducy0k.replace('mysearchwords',search)
	AMbRf4XTpQNvio6J5GELducy0k = AMbRf4XTpQNvio6J5GELducy0k.replace('mypagelimit','40')
	AMbRf4XTpQNvio6J5GELducy0k = AMbRf4XTpQNvio6J5GELducy0k.replace('mypagenumber',i02wfPp5EM)
	if sort==qpFY4hAwolV3: AMbRf4XTpQNvio6J5GELducy0k = AMbRf4XTpQNvio6J5GELducy0k.replace('mysortmethod',qpFY4hAwolV3)
	else: AMbRf4XTpQNvio6J5GELducy0k = AMbRf4XTpQNvio6J5GELducy0k.replace('mysortmethod',',"sortByVideos":"'+sort+'"')
	url = ddBxj51bhNtaK23lDyGMVw+'/search/'+search+'/videos'
	cmWl9dOKHPIy41iaXuxrY = pLVAohQrUi2JePNxzmDHC9Ru(AMbRf4XTpQNvio6J5GELducy0k,search)
	pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('"videos"(.*?)"VideoConnection"',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	if pfRkcVlLmUxo561g0A8qSbO:
		mVYdjvor6i4wZ8 = pfRkcVlLmUxo561g0A8qSbO[0]
		items = ePhmG1jLD6.findall('"node":.*?"xid":"(.*?)",.*?"title":"(.*?)",.*?"name":"(.*?)",.*?"displayName":"(.*?)",.*?"duration":(.*?),".*?thumbnailx240":"(.*?)",',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
		for id,title,uuTMWEOrK26JIzRPAw0tD9plh5,qkUQREjo9ibsO50AMmLwJIhBxp,dq0kBrGuKXiP,Sj7rMNYRuQPTtkBvpHKeDW3h in items:
			Sj7rMNYRuQPTtkBvpHKeDW3h = Sj7rMNYRuQPTtkBvpHKeDW3h.replace('\/',ShynO8pN9idCE3)
			MepIvHBYNArkUOdV37shtJ = ddBxj51bhNtaK23lDyGMVw+'/video/'+id
			title = yId69qYhzF0ic(title)
			WtgVhfrHisQOy0p9UjMDT = uuTMWEOrK26JIzRPAw0tD9plh5+'::'+qkUQREjo9ibsO50AMmLwJIhBxp
			x3WSXnKyPhjqfHG2UrtQs('video',wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,403,Sj7rMNYRuQPTtkBvpHKeDW3h,dq0kBrGuKXiP,WtgVhfrHisQOy0p9UjMDT)
		if '"hasNextPage":true' in cmWl9dOKHPIy41iaXuxrY:
			i02wfPp5EM = str(int(i02wfPp5EM)+1)
			x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+'صفحة '+i02wfPp5EM,url,404,qpFY4hAwolV3,i02wfPp5EM,search)
	return
def GTbUZS3fv64MRAO2P9F17(search,i02wfPp5EM=qpFY4hAwolV3):
	if i02wfPp5EM==qpFY4hAwolV3: i02wfPp5EM = '1'
	AMbRf4XTpQNvio6J5GELducy0k = '''{"operationName":"SEARCH_QUERY","variables":{"query":"mysearchwords","shouldIncludeChannels":false,"shouldIncludePlaylists":true,"shouldIncludeVideos":false,"page":mypagenumber,"limit":mypagelimit},"query":"fragment VIDEO_BASE_FRAGMENT on Video {  id  xid  title  createdAt  stats {    views {      total      __typename    }    __typename  }  channel {    id    xid    name    displayName    accountType    __typename  }  duration  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  __typename}fragment VIDEO_WATCH_LATER_FRAGMENT on Video {  id  isInWatchLater  __typename}fragment CHANNEL_BASE_FRAG on Channel {  accountType  id  xid  name  displayName  isFollowed  thumbnailx60: logoURL(size: \\"x60\\")  thumbnailx120: logoURL(size: \\"x120\\")  thumbnailx240: logoURL(size: \\"x240\\")  thumbnailx720: logoURL(size: \\"x720\\")  __typename}fragment PLAYLIST_BASE_FRAG on Collection {  id  xid  name  channel {    id    xid    name    displayName    accountType    __typename  }  description  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  stats {    videos {      total      __typename    }    __typename  }  __typename}query SEARCH_QUERY($query: String!, $shouldIncludeVideos: Boolean!, $shouldIncludeChannels: Boolean!, $shouldIncludePlaylists: Boolean!, $page: Int, $limit: Int, $sortByVideos: SearchVideoSort, $durationMinVideos: Int, $durationMaxVideos: Int, $createdAfterVideos: DateTime) {  search {    id    videos(query: $query, first: $limit, page: $page, sort: $sortByVideos, durationMin: $durationMinVideos, durationMax: $durationMaxVideos, createdAfter: $createdAfterVideos) @include(if: $shouldIncludeVideos) {      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...VIDEO_BASE_FRAGMENT          ...VIDEO_WATCH_LATER_FRAGMENT          __typename        }        __typename      }      __typename    }    channels(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeChannels) {      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...CHANNEL_BASE_FRAG          __typename        }        __typename      }      __typename    }    playlists: collections(query: $query, first: $limit, page: $page) @include(if: $shouldIncludePlaylists) {      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...PLAYLIST_BASE_FRAG          __typename        }        __typename      }      __typename    }    __typename  }}"}'''
	AMbRf4XTpQNvio6J5GELducy0k = AMbRf4XTpQNvio6J5GELducy0k.replace('mysearchwords',search)
	AMbRf4XTpQNvio6J5GELducy0k = AMbRf4XTpQNvio6J5GELducy0k.replace('mypagelimit','40')
	AMbRf4XTpQNvio6J5GELducy0k = AMbRf4XTpQNvio6J5GELducy0k.replace('mypagenumber',i02wfPp5EM)
	url = ddBxj51bhNtaK23lDyGMVw+'/search/'+search+'/playlists'
	cmWl9dOKHPIy41iaXuxrY = pLVAohQrUi2JePNxzmDHC9Ru(AMbRf4XTpQNvio6J5GELducy0k,search)
	items = ePhmG1jLD6.findall('"node".*?"xid":"(.*?)",.*?"name":"(.*?)",.*?"xid":"(.*?)",.*?"name":"(.*?)",.*?"displayName":"(.*?)",.*?"thumbnailx240":"(.*?)",.*?"total":(.*?),"',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	for id,name,QKqSPm5fJz,uuTMWEOrK26JIzRPAw0tD9plh5,qkUQREjo9ibsO50AMmLwJIhBxp,Sj7rMNYRuQPTtkBvpHKeDW3h,count in items:
		Sj7rMNYRuQPTtkBvpHKeDW3h = Sj7rMNYRuQPTtkBvpHKeDW3h.replace('\/',ShynO8pN9idCE3)
		MepIvHBYNArkUOdV37shtJ = ddBxj51bhNtaK23lDyGMVw+'/playlist/'+id
		title = 'LIST'+count+':  '+name
		title = yId69qYhzF0ic(title)
		WtgVhfrHisQOy0p9UjMDT = uuTMWEOrK26JIzRPAw0tD9plh5+'::'+qkUQREjo9ibsO50AMmLwJIhBxp
		x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,401,Sj7rMNYRuQPTtkBvpHKeDW3h,qpFY4hAwolV3,WtgVhfrHisQOy0p9UjMDT)
	if '"hasNextPage":true' in cmWl9dOKHPIy41iaXuxrY:
		i02wfPp5EM = str(int(i02wfPp5EM)+1)
		x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+'صفحة '+i02wfPp5EM,url,405,qpFY4hAwolV3,i02wfPp5EM,search)
	return
def rMtdiKkEmsnXc7BxhDwbO8JaQ5R9qy(search,i02wfPp5EM=qpFY4hAwolV3):
	if i02wfPp5EM==qpFY4hAwolV3: i02wfPp5EM = '1'
	AMbRf4XTpQNvio6J5GELducy0k = '''{"operationName":"SEARCH_QUERY","variables":{"query":"mysearchwords","shouldIncludeChannels":true,"shouldIncludePlaylists":false,"shouldIncludeVideos":false,"page":mypagenumber,"limit":mypagelimit},"query":"fragment VIDEO_BASE_FRAGMENT on Video {  id  xid  title  createdAt  stats {    views {      total      __typename    }    __typename  }  channel {    id    xid    name    displayName    accountType    __typename  }  duration  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  __typename}fragment VIDEO_WATCH_LATER_FRAGMENT on Video {  id  isInWatchLater  __typename}fragment CHANNEL_BASE_FRAG on Channel {  accountType  id  xid  name  displayName  isFollowed  thumbnailx60: logoURL(size: \\"x60\\")  thumbnailx120: logoURL(size: \\"x120\\")  thumbnailx240: logoURL(size: \\"x240\\")  thumbnailx720: logoURL(size: \\"x720\\")  __typename}fragment PLAYLIST_BASE_FRAG on Collection {  id  xid  name  channel {    id    xid    name    displayName    accountType    __typename  }  description  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  stats {    videos {      total      __typename    }    __typename  }  __typename}query SEARCH_QUERY($query: String!, $shouldIncludeVideos: Boolean!, $shouldIncludeChannels: Boolean!, $shouldIncludePlaylists: Boolean!, $page: Int, $limit: Int, $sortByVideos: SearchVideoSort, $durationMinVideos: Int, $durationMaxVideos: Int, $createdAfterVideos: DateTime) {  search {    id    videos(query: $query, first: $limit, page: $page, sort: $sortByVideos, durationMin: $durationMinVideos, durationMax: $durationMaxVideos, createdAfter: $createdAfterVideos) @include(if: $shouldIncludeVideos) {      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...VIDEO_BASE_FRAGMENT          ...VIDEO_WATCH_LATER_FRAGMENT          __typename        }        __typename      }      __typename    }    channels(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeChannels) {      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...CHANNEL_BASE_FRAG          __typename        }        __typename      }      __typename    }    playlists: collections(query: $query, first: $limit, page: $page) @include(if: $shouldIncludePlaylists) {      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...PLAYLIST_BASE_FRAG          __typename        }        __typename      }      __typename    }    __typename  }}"}'''
	AMbRf4XTpQNvio6J5GELducy0k = AMbRf4XTpQNvio6J5GELducy0k.replace('mysearchwords',search)
	AMbRf4XTpQNvio6J5GELducy0k = AMbRf4XTpQNvio6J5GELducy0k.replace('mypagelimit','40')
	AMbRf4XTpQNvio6J5GELducy0k = AMbRf4XTpQNvio6J5GELducy0k.replace('mypagenumber',i02wfPp5EM)
	url = ddBxj51bhNtaK23lDyGMVw+'/search/'+search+'/channels'
	cmWl9dOKHPIy41iaXuxrY = pLVAohQrUi2JePNxzmDHC9Ru(AMbRf4XTpQNvio6J5GELducy0k,search)
	pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('"channels"(.*?)"ChannelConnection"',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	if pfRkcVlLmUxo561g0A8qSbO:
		mVYdjvor6i4wZ8 = pfRkcVlLmUxo561g0A8qSbO[0]
		items = ePhmG1jLD6.findall('"node".*?"name":"(.*?)",.*?"displayName":"(.*?)",.*?"thumbnailx240":"(.*?)",',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
		for id,name,Sj7rMNYRuQPTtkBvpHKeDW3h in items:
			Sj7rMNYRuQPTtkBvpHKeDW3h = Sj7rMNYRuQPTtkBvpHKeDW3h.replace('\/',ShynO8pN9idCE3)
			MepIvHBYNArkUOdV37shtJ = ddBxj51bhNtaK23lDyGMVw+ShynO8pN9idCE3+id
			title = 'USER:  '+name
			title = yId69qYhzF0ic(title)
			x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,402,Sj7rMNYRuQPTtkBvpHKeDW3h,qpFY4hAwolV3,name)
		if '"hasNextPage":true' in cmWl9dOKHPIy41iaXuxrY:
			i02wfPp5EM = str(int(i02wfPp5EM)+1)
			x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+'صفحة '+i02wfPp5EM,url,406,qpFY4hAwolV3,i02wfPp5EM,search)
	return
def ztTGLogIFSW71RfqHx2Z(BDp3lZg1uHoN2jWd0EJPXIMQiO):
	AMbRf4XTpQNvio6J5GELducy0k = '''{"operationName":"HOME_QUERY","variables":{"space":"nextplore"},"query":"fragment TOPIC_BASE_FRAG on Topic {  id  xid  name  thumbnail: coverURL(size: \\"x532\\")  coverURL: coverURL(size: \\"x532\\")  isFollowed  whitelistStatus {    id    isWhitelisted    __typename  }  __typename}query HOME_QUERY($space: String!) {  home: views {    id    neon {      id      sections(space: $space) {        edges {          node {            id            name            title            description            groupingType            type            relatedComponent {              __typename              ... on Collection {                id                xid                __typename              }              ... on Channel {                id                xid                name                displayName                logoURL(size: \\"x60\\")                __typename              }              ... on Topic {                id                __typename                ...TOPIC_BASE_FRAG              }            }            components {              edges {                node {                  __typename                  ... on Video {                    id                    xid                    title                    thumbnailx60: thumbnailURL(size: \\"x60\\")                    thumbnailx120: thumbnailURL(size: \\"x120\\")                    thumbnailx240: thumbnailURL(size: \\"x240\\")                    thumbnailx360: thumbnailURL(size: \\"x360\\")                    thumbnailx480: thumbnailURL(size: \\"x480\\")                    thumbnailx720: thumbnailURL(size: \\"x720\\")                    aspectRatio                    createdAt                    channel {                      id                      xid                      name                      displayName                      logoURLx25: logoURL(size: \\"x25\\")                      accountType                      __typename                    }                    description                    duration                    __typename                  }                  ... on Live {                    id                    xid                    title                    thumbnailx60: thumbnailURL(size: \\"x60\\")                    thumbnailx120: thumbnailURL(size: \\"x120\\")                    thumbnailx240: thumbnailURL(size: \\"x240\\")                    thumbnailx360: thumbnailURL(size: \\"x360\\")                    thumbnailx480: thumbnailURL(size: \\"x480\\")                    thumbnailx720: thumbnailURL(size: \\"x720\\")                    aspectRatio                    createdAt                    channel {                      id                      xid                      name                      displayName                      logoURLx25: logoURL(size: \\"x25\\")                      accountType                      __typename                    }                    startAt                    __typename                  }                }                __typename              }              __typename            }            __typename          }          __typename        }        __typename      }      __typename    }    __typename  }}"}'''
	ppHs9AECcZ8 = pLVAohQrUi2JePNxzmDHC9Ru(AMbRf4XTpQNvio6J5GELducy0k)
	if ppHs9AECcZ8:
		UuoQtlfEkaicdLWY50ZOj = wB8NUAidPbqjIr9CFasXvYnxOQpL0g('dict',ppHs9AECcZ8)
		llM5hBSovHuxIWLXYtUiRTFVj3J9 = UuoQtlfEkaicdLWY50ZOj['data']['home']['neon']['sections']['edges']
		if not BDp3lZg1uHoN2jWd0EJPXIMQiO:
			vOBlpysaG620W8j = []
			for gIleHBFXDq in llM5hBSovHuxIWLXYtUiRTFVj3J9:
				wpPIyaVkiGK = gIleHBFXDq['node']['title']
				if wpPIyaVkiGK not in vOBlpysaG620W8j: x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+wpPIyaVkiGK,qpFY4hAwolV3,414,qpFY4hAwolV3,qpFY4hAwolV3,wpPIyaVkiGK)
				vOBlpysaG620W8j.append(wpPIyaVkiGK)
		else:
			for gIleHBFXDq in llM5hBSovHuxIWLXYtUiRTFVj3J9:
				wpPIyaVkiGK = gIleHBFXDq['node']['title']
				if wpPIyaVkiGK==BDp3lZg1uHoN2jWd0EJPXIMQiO:
					Jhm9wXj0L7GN6tnPZybr = gIleHBFXDq['node']['components']['edges']
					for YZgr4C9InBQHPc8XdoAMNa0Jp in Jhm9wXj0L7GN6tnPZybr:
						dq0kBrGuKXiP = str(YZgr4C9InBQHPc8XdoAMNa0Jp['node']['duration'])
						title = N8E37XwL6iQbmBY(YZgr4C9InBQHPc8XdoAMNa0Jp['node']['title'])
						title = title.replace('\/',ShynO8pN9idCE3)
						i7nJwdLB5vqPRuVYfrKh9m2eg = YZgr4C9InBQHPc8XdoAMNa0Jp['node']['xid']
						Sj7rMNYRuQPTtkBvpHKeDW3h = YZgr4C9InBQHPc8XdoAMNa0Jp['node']['thumbnailx480']
						Sj7rMNYRuQPTtkBvpHKeDW3h = Sj7rMNYRuQPTtkBvpHKeDW3h.replace('\/',ShynO8pN9idCE3)
						MepIvHBYNArkUOdV37shtJ = ddBxj51bhNtaK23lDyGMVw+'/video/'+i7nJwdLB5vqPRuVYfrKh9m2eg
						x3WSXnKyPhjqfHG2UrtQs('video',wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,403,Sj7rMNYRuQPTtkBvpHKeDW3h,dq0kBrGuKXiP)
	return
def c0IaUs6OEor7LhqHiu1NfVmAd(search,i02wfPp5EM=qpFY4hAwolV3):
	if i02wfPp5EM==qpFY4hAwolV3: i02wfPp5EM = '1'
	AMbRf4XTpQNvio6J5GELducy0k = '''{"operationName":"SEARCH_QUERY","variables":{"query":"mysearchwords","shouldIncludeChannels":false,"shouldIncludePlaylists":false,"shouldIncludeTopics":false,"shouldIncludeVideos":false,"shouldIncludeLives":true,"page":mypagenumber,"limit":mypagelimit},"query":"fragment VIDEO_BASE_FRAGMENT on Video {  id  xid  title  createdAt  stats {    id    views {      id      total      __typename    }    __typename  }  channel {    id    xid    name    displayName    accountType    __typename  }  duration  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  aspectRatio  __typename}fragment VIDEO_FAVORITES_FRAGMENT on Media {  __typename  ... on Video {    id    viewerEngagement {      id      favorited      __typename    }    __typename  }  ... on Live {    id    viewerEngagement {      id      favorited      __typename    }    __typename  }}fragment CHANNEL_BASE_FRAG on Channel {  accountType  id  xid  name  displayName  isFollowed  thumbnailx60: logoURL(size: \\"x60\\")  thumbnailx120: logoURL(size: \\"x120\\")  thumbnailx240: logoURL(size: \\"x240\\")  thumbnailx720: logoURL(size: \\"x720\\")  __typename}fragment PLAYLIST_BASE_FRAG on Collection {  id  xid  name  channel {    id    xid    name    displayName    accountType    __typename  }  description  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  stats {    id    videos {      id      total      __typename    }    __typename  }  __typename}fragment TOPIC_BASE_FRAG on Topic {  id  xid  name  videos(sort: \\"recent\\", first: 5) {    pageInfo {      hasNextPage      nextPage      __typename    }    edges {      node {        id        ...VIDEO_BASE_FRAGMENT        ...VIDEO_FAVORITES_FRAGMENT        __typename      }      __typename    }    __typename  }  stats {    id    videos {      id      total      __typename    }    __typename  }  __typename}query SEARCH_QUERY($query: String!, $shouldIncludeVideos: Boolean!, $shouldIncludeChannels: Boolean!, $shouldIncludePlaylists: Boolean!, $shouldIncludeTopics: Boolean!, $shouldIncludeLives: Boolean!, $page: Int, $limit: Int, $sortByVideos: SearchVideoSort, $durationMinVideos: Int, $durationMaxVideos: Int, $createdAfterVideos: DateTime) {  search {    id    videos(      query: $query      first: $limit      page: $page      sort: $sortByVideos      durationMin: $durationMinVideos      durationMax: $durationMaxVideos      createdAfter: $createdAfterVideos    ) @include(if: $shouldIncludeVideos) {      metadata {        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...VIDEO_BASE_FRAGMENT          ...VIDEO_FAVORITES_FRAGMENT          __typename        }        __typename      }      __typename    }    lives(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeLives) {      metadata {        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          xid          title          thumbnail: thumbnailURL(size: \\"x240\\")          thumbnailx60: thumbnailURL(size: \\"x60\\")          thumbnailx120: thumbnailURL(size: \\"x120\\")          thumbnailx240: thumbnailURL(size: \\"x240\\")          thumbnailx720: thumbnailURL(size: \\"x720\\")          audienceCount          aspectRatio          isOnAir          channel {            id            xid            name            displayName            accountType            __typename          }          __typename        }        __typename      }      __typename    }    channels(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeChannels) {      metadata {        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...CHANNEL_BASE_FRAG          __typename        }        __typename      }      __typename    }    playlists: collections(query: $query, first: $limit, page: $page) @include(if: $shouldIncludePlaylists) {      metadata {        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...PLAYLIST_BASE_FRAG          __typename        }        __typename      }      __typename    }    topics(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeTopics) {      metadata {        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...TOPIC_BASE_FRAG          __typename        }        __typename      }      __typename    }    __typename  }}"}'''
	AMbRf4XTpQNvio6J5GELducy0k = AMbRf4XTpQNvio6J5GELducy0k.replace('mysearchwords',search)
	AMbRf4XTpQNvio6J5GELducy0k = AMbRf4XTpQNvio6J5GELducy0k.replace('mypagelimit','40')
	AMbRf4XTpQNvio6J5GELducy0k = AMbRf4XTpQNvio6J5GELducy0k.replace('mypagenumber',i02wfPp5EM)
	url = ddBxj51bhNtaK23lDyGMVw+'/search/'+search+'/lives'
	ppHs9AECcZ8 = pLVAohQrUi2JePNxzmDHC9Ru(AMbRf4XTpQNvio6J5GELducy0k,search)
	if ppHs9AECcZ8:
		UuoQtlfEkaicdLWY50ZOj = wB8NUAidPbqjIr9CFasXvYnxOQpL0g('dict',ppHs9AECcZ8)
		try: llM5hBSovHuxIWLXYtUiRTFVj3J9 = UuoQtlfEkaicdLWY50ZOj['data']['search']['lives']['edges']
		except: llM5hBSovHuxIWLXYtUiRTFVj3J9 = []
		for gIleHBFXDq in llM5hBSovHuxIWLXYtUiRTFVj3J9:
			name = gIleHBFXDq['node']['title']
			name = N8E37XwL6iQbmBY(name)
			i7nJwdLB5vqPRuVYfrKh9m2eg = gIleHBFXDq['node']['xid']
			MepIvHBYNArkUOdV37shtJ = ddBxj51bhNtaK23lDyGMVw+'/video/'+i7nJwdLB5vqPRuVYfrKh9m2eg
			x3WSXnKyPhjqfHG2UrtQs('live',wwSFijdVJn1QgHW+'LIVE: '+name,MepIvHBYNArkUOdV37shtJ,403)
		if '"hasNextPage":true' in ppHs9AECcZ8:
			i02wfPp5EM = str(int(i02wfPp5EM)+1)
			x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+'صفحة '+i02wfPp5EM,url,415,qpFY4hAwolV3,i02wfPp5EM,search)
	return
def Wo3KjfOUFmsSP1r5n2V(search,i02wfPp5EM=qpFY4hAwolV3):
	if i02wfPp5EM==qpFY4hAwolV3: i02wfPp5EM = '1'
	AMbRf4XTpQNvio6J5GELducy0k = '''{"operationName":"SEARCH_QUERY","variables":{"query":"mysearchwords","shouldIncludeChannels":false,"shouldIncludePlaylists":false,"shouldIncludeTopics":true,"shouldIncludeVideos":false,"shouldIncludeLives":false,"page":mypagenumber,"limit":mypagelimit},"query":"fragment VIDEO_BASE_FRAGMENT on Video {  id  xid  title  createdAt  stats {    id    views {      id      total      __typename    }    __typename  }  channel {    id    xid    name    displayName    accountType    __typename  }  duration  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  aspectRatio  __typename}fragment VIDEO_FAVORITES_FRAGMENT on Media {  __typename  ... on Video {    id    isInWatchLater    __typename  }  ... on Live {    id    isInWatchLater    __typename  }}fragment CHANNEL_BASE_FRAG on Channel {  accountType  id  xid  name  displayName  isFollowed  thumbnailx60: logoURL(size: \\"x60\\")  thumbnailx120: logoURL(size: \\"x120\\")  thumbnailx240: logoURL(size: \\"x240\\")  thumbnailx720: logoURL(size: \\"x720\\")  __typename}fragment PLAYLIST_BASE_FRAG on Collection {  id  xid  name  channel {    id    xid    name    displayName    accountType    __typename  }  description  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  stats {    id    videos {      id      total      __typename    }    __typename  }  __typename}fragment TOPIC_BASE_FRAG on Topic {  id  xid  name  videos(sort: \\"recent\\", first: 5) {    pageInfo {      hasNextPage      nextPage      __typename    }    edges {      node {        id        ...VIDEO_BASE_FRAGMENT        ...VIDEO_FAVORITES_FRAGMENT        __typename      }      __typename    }    __typename  }  stats {    id    videos {      id      total      __typename    }    __typename  }  __typename}query SEARCH_QUERY($query: String!, $shouldIncludeVideos: Boolean!, $shouldIncludeChannels: Boolean!, $shouldIncludePlaylists: Boolean!, $shouldIncludeTopics: Boolean!, $page: Int, $limit: Int, $sortByVideos: SearchVideoSort, $durationMinVideos: Int, $durationMaxVideos: Int, $createdAfterVideos: DateTime) {  search {    id    videos(      query: $query      first: $limit      page: $page      sort: $sortByVideos      durationMin: $durationMinVideos      durationMax: $durationMaxVideos      createdAfter: $createdAfterVideos    ) @include(if: $shouldIncludeVideos) {      metadata {        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...VIDEO_BASE_FRAGMENT          ...VIDEO_FAVORITES_FRAGMENT          __typename        }        __typename      }      __typename    }    channels(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeChannels) {      metadata {        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...CHANNEL_BASE_FRAG          __typename        }        __typename      }      __typename    }    playlists: collections(query: $query, first: $limit, page: $page) @include(if: $shouldIncludePlaylists) {      metadata {        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...PLAYLIST_BASE_FRAG          __typename        }        __typename      }      __typename    }    topics(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeTopics) {      metadata {        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...TOPIC_BASE_FRAG          __typename        }        __typename      }      __typename    }    __typename  }}"}'''
	AMbRf4XTpQNvio6J5GELducy0k = AMbRf4XTpQNvio6J5GELducy0k.replace('mysearchwords',search)
	AMbRf4XTpQNvio6J5GELducy0k = AMbRf4XTpQNvio6J5GELducy0k.replace('mypagelimit','40')
	AMbRf4XTpQNvio6J5GELducy0k = AMbRf4XTpQNvio6J5GELducy0k.replace('mypagenumber',i02wfPp5EM)
	url = ddBxj51bhNtaK23lDyGMVw+'/search/'+search+'/topics'
	ppHs9AECcZ8 = pLVAohQrUi2JePNxzmDHC9Ru(AMbRf4XTpQNvio6J5GELducy0k,search)
	if ppHs9AECcZ8:
		UuoQtlfEkaicdLWY50ZOj = wB8NUAidPbqjIr9CFasXvYnxOQpL0g('dict',ppHs9AECcZ8)
		try: llM5hBSovHuxIWLXYtUiRTFVj3J9 = UuoQtlfEkaicdLWY50ZOj['data']['search']['topics']['edges']
		except: llM5hBSovHuxIWLXYtUiRTFVj3J9 = []
		for gIleHBFXDq in llM5hBSovHuxIWLXYtUiRTFVj3J9:
			name = gIleHBFXDq['node']['name']
			i7nJwdLB5vqPRuVYfrKh9m2eg = gIleHBFXDq['node']['xid']
			MepIvHBYNArkUOdV37shtJ = ddBxj51bhNtaK23lDyGMVw+'/topic/'+i7nJwdLB5vqPRuVYfrKh9m2eg
			x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+'TOPIC: '+name,MepIvHBYNArkUOdV37shtJ,413)
		if '"hasNextPage":true' in ppHs9AECcZ8:
			i02wfPp5EM = str(int(i02wfPp5EM)+1)
			x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+'صفحة '+i02wfPp5EM,url,412,qpFY4hAwolV3,i02wfPp5EM,search)
	return
def zSVH8UIQdpCfR(url,i02wfPp5EM=qpFY4hAwolV3):
	if i02wfPp5EM==qpFY4hAwolV3: i02wfPp5EM = '1'
	i7nJwdLB5vqPRuVYfrKh9m2eg = url.split(ShynO8pN9idCE3)[-1]
	AMbRf4XTpQNvio6J5GELducy0k = '''{"operationName":"DISCOVERY_TOPIC_MAIN_QUERY","variables":{"page":mypagenumber,"xid":"mytopicid"},"query":"fragment TOPIC_VIDEO_FRAGMENT on Video {  id  xid  title  duration  isLiked  isInWatchLater  isCreatedForKids  createdAt  isExplicit  videoHeight: height  videoWidth: width  category  channel {    id    xid    name    displayName    logoURLx25: logoURL(size: \\"x25\\")    logoURL(size: \\"x60\\")    accountType    __typename  }  stats {    id    views {      id      total      __typename    }    __typename  }  language {    id    codeAlpha2    __typename  }  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx360: thumbnailURL(size: \\"x360\\")  thumbnailx480: thumbnailURL(size: \\"x480\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  bestAvailableQuality  aspectRatio  isPublished  __typename}query DISCOVERY_TOPIC_MAIN_QUERY($xid: String!, $page: Int = 1) {  topic(xid: $xid) {    id    xid    name    videos(sort: \\"recent\\", first: 30, page: $page) {      pageInfo {        hasNextPage        nextPage        __typename      }      edges {        node {          id          ...TOPIC_VIDEO_FRAGMENT          __typename        }        __typename      }      __typename    }    __typename  }}"}'''
	AMbRf4XTpQNvio6J5GELducy0k = AMbRf4XTpQNvio6J5GELducy0k.replace('mytopicid',i7nJwdLB5vqPRuVYfrKh9m2eg)
	AMbRf4XTpQNvio6J5GELducy0k = AMbRf4XTpQNvio6J5GELducy0k.replace('mypagenumber',i02wfPp5EM)
	ppHs9AECcZ8 = pLVAohQrUi2JePNxzmDHC9Ru(AMbRf4XTpQNvio6J5GELducy0k)
	if ppHs9AECcZ8:
		UuoQtlfEkaicdLWY50ZOj = wB8NUAidPbqjIr9CFasXvYnxOQpL0g('dict',ppHs9AECcZ8)
		llM5hBSovHuxIWLXYtUiRTFVj3J9 = UuoQtlfEkaicdLWY50ZOj['data']['topic']['videos']['edges']
		for gIleHBFXDq in llM5hBSovHuxIWLXYtUiRTFVj3J9:
			dq0kBrGuKXiP = str(gIleHBFXDq['node']['duration'])
			title = N8E37XwL6iQbmBY(gIleHBFXDq['node']['title'])
			title = title.replace('\/',ShynO8pN9idCE3)
			i7nJwdLB5vqPRuVYfrKh9m2eg = gIleHBFXDq['node']['xid']
			Sj7rMNYRuQPTtkBvpHKeDW3h = gIleHBFXDq['node']['thumbnailx480']
			Sj7rMNYRuQPTtkBvpHKeDW3h = Sj7rMNYRuQPTtkBvpHKeDW3h.replace('\/',ShynO8pN9idCE3)
			MepIvHBYNArkUOdV37shtJ = ddBxj51bhNtaK23lDyGMVw+'/video/'+i7nJwdLB5vqPRuVYfrKh9m2eg
			x3WSXnKyPhjqfHG2UrtQs('video',wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,403,Sj7rMNYRuQPTtkBvpHKeDW3h,dq0kBrGuKXiP)
		if '"hasNextPage":true' in ppHs9AECcZ8:
			i02wfPp5EM = str(int(i02wfPp5EM)+1)
			x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+'صفحة '+i02wfPp5EM,url,413,qpFY4hAwolV3,i02wfPp5EM)
	return
def YWuHFi18QkbIKjJvlTrgfX(url,WtgVhfrHisQOy0p9UjMDT):
	id = url.split(ShynO8pN9idCE3)[-1]
	uuTMWEOrK26JIzRPAw0tD9plh5,qkUQREjo9ibsO50AMmLwJIhBxp = WtgVhfrHisQOy0p9UjMDT.split('::',1)
	MepIvHBYNArkUOdV37shtJ = ddBxj51bhNtaK23lDyGMVw+ShynO8pN9idCE3+uuTMWEOrK26JIzRPAw0tD9plh5
	qkUQREjo9ibsO50AMmLwJIhBxp = yId69qYhzF0ic(qkUQREjo9ibsO50AMmLwJIhBxp)
	title = xupTj02bvy3O8R+'OWNER:  '+qkUQREjo9ibsO50AMmLwJIhBxp+fF4lt9zWYxXLKZVyAco82PgMj
	x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,402,qpFY4hAwolV3,qpFY4hAwolV3,qkUQREjo9ibsO50AMmLwJIhBxp)
	AMbRf4XTpQNvio6J5GELducy0k = '''{"operationName":"DISCOVERY_QUEUE_QUERY","variables":{"collectionXid":"myplaylistid","videoXid":"x7s7qbn"},"query":"query DISCOVERY_QUEUE_QUERY($videoXid: String!, $collectionXid: String, $device: String, $videoCountPerSection: Int) {  views {    id    neon {      id      sections(device: $device, space: \\"watching\\", followingChannelXids: [], followingTopicXids: [], watchedVideoXids: [], context: {mediaXid: $videoXid, collectionXid: $collectionXid}, first: 20) {        edges {          node {            id            name            groupingType            relatedComponent {              ... on Channel {                __typename                id                xid                name                displayName                logoURL(size: \\"x60\\")                logoURLx25: logoURL(size: \\"x25\\")              }              ... on Topic {                __typename                id                xid                name                names {                  edges {                    node {                      id                      name                      language {                        id                        codeAlpha2                        __typename                      }                      __typename                    }                    __typename                  }                  __typename                }              }              ... on Collection {                __typename                id                xid                name              }              __typename            }            components(first: $videoCountPerSection) {              metadata {                algorithm {                  name                  version                  uuid                  __typename                }                __typename              }              edges {                node {                  ... on Video {                    __typename                    id                    xid                    title                    duration                    thumbnailx60: thumbnailURL(size: \\"x60\\")                    thumbnailx120: thumbnailURL(size: \\"x120\\")                    thumbnailx240: thumbnailURL(size: \\"x240\\")                    thumbnailx720: thumbnailURL(size: \\"x720\\")                    channel {                      id                      xid                      accountType                      displayName                      logoURLx25: logoURL(size: \\"x25\\")                      logoURL(size: \\"x60\\")                      __typename                    }                  }                  ... on Channel {                    __typename                    id                    xid                    name                    displayName                    accountType                    logoURL(size: \\"x60\\")                  }                  __typename                }                __typename              }              __typename            }            __typename          }          __typename        }        __typename      }      __typename    }    __typename  }}"}'''
	AMbRf4XTpQNvio6J5GELducy0k = AMbRf4XTpQNvio6J5GELducy0k.replace('myplaylistid',id)
	cmWl9dOKHPIy41iaXuxrY = pLVAohQrUi2JePNxzmDHC9Ru(AMbRf4XTpQNvio6J5GELducy0k)
	pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('"collection_videos"(.*?)"SectionEdge"',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	if pfRkcVlLmUxo561g0A8qSbO:
		mVYdjvor6i4wZ8 = pfRkcVlLmUxo561g0A8qSbO[0]
		items = ePhmG1jLD6.findall('"node".*?"xid":"(.*?)",.*?"title":"(.*?)",.*?"duration":(.*?),".*?thumbnailx240":"(.*?)",.*?"xid":"(.*?)",.*?"displayName":"(.*?)",',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
		for id,title,dq0kBrGuKXiP,Sj7rMNYRuQPTtkBvpHKeDW3h,uuTMWEOrK26JIzRPAw0tD9plh5,qkUQREjo9ibsO50AMmLwJIhBxp in items:
			Sj7rMNYRuQPTtkBvpHKeDW3h = Sj7rMNYRuQPTtkBvpHKeDW3h.replace('\/',ShynO8pN9idCE3)
			MepIvHBYNArkUOdV37shtJ = ddBxj51bhNtaK23lDyGMVw+'/video/'+id
			title = yId69qYhzF0ic(title)
			WtgVhfrHisQOy0p9UjMDT = uuTMWEOrK26JIzRPAw0tD9plh5+'::'+qkUQREjo9ibsO50AMmLwJIhBxp
			x3WSXnKyPhjqfHG2UrtQs('video',wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,403,Sj7rMNYRuQPTtkBvpHKeDW3h,dq0kBrGuKXiP,WtgVhfrHisQOy0p9UjMDT)
	return
def HobNL2t3zslR(url,i02wfPp5EM=qpFY4hAwolV3):
	if i02wfPp5EM==qpFY4hAwolV3: i02wfPp5EM = '1'
	KpzHWlsYVwvhfdN0A8Lk2n6M = url.split(ShynO8pN9idCE3)[-2]
	if 'sort=' in url: sort = url.split('sort=')[1].split('&')[0]
	else: sort = 'recent'
	AMbRf4XTpQNvio6J5GELducy0k = '''{"operationName":"CHANNEL_VIDEOS_QUERY","variables":{"channel_xid":"mychannelid","sort":"mysortmethod","page":mypagenumber},"query":"fragment CHANNEL_BASE_FRAGMENT on Channel {  id  xid  name  displayName  isArtist  logoURL(size: \\"x60\\")  isFollowed  accountType  __typename}fragment CHANNEL_IMAGES_FRAGMENT on Channel {  id  coverURLx375: coverURL(size: \\"x375\\")  __typename}fragment CHANNEL_UPDATED_FRAGMENT on Channel {  id  isFollowed  stats {    views {      total      __typename    }    followers {      total      __typename    }    videos {      total      __typename    }    __typename  }  __typename}fragment CHANNEL_COMPLETE_FRAGMENT on Channel {  id  ...CHANNEL_BASE_FRAGMENT  ...CHANNEL_IMAGES_FRAGMENT  ...CHANNEL_UPDATED_FRAGMENT  description  coverURL1024x: coverURL(size: \\"1024x\\")  coverURL1920x: coverURL(size: \\"1920x\\")  externalLinks {    facebookURL    twitterURL    websiteURL    instagramURL    __typename  }  __typename}fragment CHANNEL_FRAGMENT on Channel {  accountType  id  xid  name  displayName  isArtist  logoURL(size: \\"x60\\")  coverURLx375: coverURL(size: \\"x375\\")  isFollowed  stats {    views {      total      __typename    }    followers {      total      __typename    }    videos {      total      __typename    }    __typename  }  __typename}fragment VIDEO_FRAGMENT on Video {  id  xid  title  viewCount  duration  createdAt  isInWatchLater  channel {    id    ...CHANNEL_FRAGMENT    __typename  }  thumbURLx240: thumbnailURL(size: \\"x240\\")  thumbURLx360: thumbnailURL(size: \\"x360\\")  thumbURLx480: thumbnailURL(size: \\"x480\\")  thumbURLx720: thumbnailURL(size: \\"x720\\")  __typename}query CHANNEL_VIDEOS_QUERY($channel_xid: String!, $sort: String, $page: Int!) {  channel(xid: $channel_xid) {    id    ...CHANNEL_COMPLETE_FRAGMENT    channel_videos_all_videos: videos(sort: $sort, page: $page, first: mypagelimit) {      pageInfo {        hasNextPage        nextPage        __typename      }      edges {        node {          id          ...VIDEO_FRAGMENT          __typename        }        __typename      }      __typename    }    __typename  }}"}'''
	AMbRf4XTpQNvio6J5GELducy0k = AMbRf4XTpQNvio6J5GELducy0k.replace('mychannelid',KpzHWlsYVwvhfdN0A8Lk2n6M)
	AMbRf4XTpQNvio6J5GELducy0k = AMbRf4XTpQNvio6J5GELducy0k.replace('mypagelimit','40')
	AMbRf4XTpQNvio6J5GELducy0k = AMbRf4XTpQNvio6J5GELducy0k.replace('mypagenumber',i02wfPp5EM)
	AMbRf4XTpQNvio6J5GELducy0k = AMbRf4XTpQNvio6J5GELducy0k.replace('mysortmethod',sort)
	cmWl9dOKHPIy41iaXuxrY = pLVAohQrUi2JePNxzmDHC9Ru(AMbRf4XTpQNvio6J5GELducy0k)
	pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('"channel_videos_all_videos"(.*?)"VideoConnection"',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	if pfRkcVlLmUxo561g0A8qSbO:
		mVYdjvor6i4wZ8 = pfRkcVlLmUxo561g0A8qSbO[0]
		items = ePhmG1jLD6.findall('"node".*?"xid":"(.*?)",.*?"title":"(.*?)",.*?"duration":(.*?),".*?name":"(.*?)",.*?"displayName":"(.*?)",.*?"thumbURLx240":"(.*?)",',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
		for id,title,dq0kBrGuKXiP,uuTMWEOrK26JIzRPAw0tD9plh5,qkUQREjo9ibsO50AMmLwJIhBxp,Sj7rMNYRuQPTtkBvpHKeDW3h in items:
			Sj7rMNYRuQPTtkBvpHKeDW3h = Sj7rMNYRuQPTtkBvpHKeDW3h.replace('\/',ShynO8pN9idCE3)
			MepIvHBYNArkUOdV37shtJ = ddBxj51bhNtaK23lDyGMVw+'/video/'+id
			title = yId69qYhzF0ic(title)
			WtgVhfrHisQOy0p9UjMDT = uuTMWEOrK26JIzRPAw0tD9plh5+'::'+qkUQREjo9ibsO50AMmLwJIhBxp
			x3WSXnKyPhjqfHG2UrtQs('video',wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,403,Sj7rMNYRuQPTtkBvpHKeDW3h,dq0kBrGuKXiP,WtgVhfrHisQOy0p9UjMDT)
		if '"hasNextPage":true' in cmWl9dOKHPIy41iaXuxrY:
			i02wfPp5EM = str(int(i02wfPp5EM)+1)
			x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+'صفحة '+i02wfPp5EM,url,408,qpFY4hAwolV3,i02wfPp5EM)
	return
def G3esmuynchr5FT(url,i02wfPp5EM=qpFY4hAwolV3):
	if i02wfPp5EM==qpFY4hAwolV3: i02wfPp5EM = '1'
	KpzHWlsYVwvhfdN0A8Lk2n6M = url.split(ShynO8pN9idCE3)[-2]
	if 'sort=' in url: sort = url.split('sort=')[1].split('&')[0]
	else: sort = 'recent'
	AMbRf4XTpQNvio6J5GELducy0k = '''{"operationName":"CHANNEL_COLLECTIONS_QUERY","variables":{"channel_xid":"mychannelid","sort":"mysortmethod","page":mypagenumber},"query":"fragment CHANNEL_BASE_FRAGMENT on Channel {  id  xid  name  displayName  isArtist  logoURL(size: \\"x60\\")  isFollowed  accountType  __typename}fragment CHANNEL_IMAGES_FRAGMENT on Channel {  id  coverURLx375: coverURL(size: \\"x375\\")  __typename}fragment CHANNEL_UPDATED_FRAGMENT on Channel {  id  isFollowed  stats {    views {      total      __typename    }    followers {      total      __typename    }    videos {      total      __typename    }    __typename  }  __typename}fragment CHANNEL_COMPLETE_FRAGMENT on Channel {  id  ...CHANNEL_BASE_FRAGMENT  ...CHANNEL_IMAGES_FRAGMENT  ...CHANNEL_UPDATED_FRAGMENT  description  coverURL1024x: coverURL(size: \\"1024x\\")  coverURL1920x: coverURL(size: \\"1920x\\")  externalLinks {    facebookURL    twitterURL    websiteURL    instagramURL    __typename  }  __typename}fragment CHANNEL_FRAGMENT on Channel {  accountType  id  xid  name  displayName  isArtist  logoURL(size: \\"x60\\")  coverURLx375: coverURL(size: \\"x375\\")  isFollowed  stats {    views {      total      __typename    }    followers {      total      __typename    }    videos {      total      __typename    }    __typename  }  __typename}query CHANNEL_COLLECTIONS_QUERY($channel_xid: String!, $sort: String, $page: Int!) {  channel(xid: $channel_xid) {    id    ...CHANNEL_COMPLETE_FRAGMENT    channel_playlist_collections: collections(sort: $sort, page: $page, first: mypagelimit) {      pageInfo {        hasNextPage        nextPage        __typename      }      edges {        node {          id          xid          updatedAt          name          description          thumbURLx240: thumbnailURL(size: \\"x240\\")          thumbURLx360: thumbnailURL(size: \\"x360\\")          thumbURLx480: thumbnailURL(size: \\"x480\\")          stats {            videos {              total              __typename            }            __typename          }          channel {            id            ...CHANNEL_FRAGMENT            __typename          }          __typename        }        __typename      }      __typename    }    __typename  }}"}'''
	AMbRf4XTpQNvio6J5GELducy0k = AMbRf4XTpQNvio6J5GELducy0k.replace('mychannelid',KpzHWlsYVwvhfdN0A8Lk2n6M)
	AMbRf4XTpQNvio6J5GELducy0k = AMbRf4XTpQNvio6J5GELducy0k.replace('mypagelimit','40')
	AMbRf4XTpQNvio6J5GELducy0k = AMbRf4XTpQNvio6J5GELducy0k.replace('mypagenumber',i02wfPp5EM)
	AMbRf4XTpQNvio6J5GELducy0k = AMbRf4XTpQNvio6J5GELducy0k.replace('mysortmethod',sort)
	cmWl9dOKHPIy41iaXuxrY = pLVAohQrUi2JePNxzmDHC9Ru(AMbRf4XTpQNvio6J5GELducy0k)
	pfRkcVlLmUxo561g0A8qSbO = ePhmG1jLD6.findall('"channel_playlist_collections"(.*?)"CollectionConnection"',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	if pfRkcVlLmUxo561g0A8qSbO:
		mVYdjvor6i4wZ8 = pfRkcVlLmUxo561g0A8qSbO[0]
		items = ePhmG1jLD6.findall('"node".*?"xid":"(.*?)",.*?"name":"(.*?)",.*?"thumbURLx240":"(.*?)",.*?"total":(.*?),".*?xid":"(.*?)",.*?"name":"(.*?)",.*?"displayName":"(.*?)",',mVYdjvor6i4wZ8,ePhmG1jLD6.DOTALL)
		for id,name,Sj7rMNYRuQPTtkBvpHKeDW3h,count,QKqSPm5fJz,uuTMWEOrK26JIzRPAw0tD9plh5,qkUQREjo9ibsO50AMmLwJIhBxp in items:
			Sj7rMNYRuQPTtkBvpHKeDW3h = Sj7rMNYRuQPTtkBvpHKeDW3h.replace('\/',ShynO8pN9idCE3)
			MepIvHBYNArkUOdV37shtJ = ddBxj51bhNtaK23lDyGMVw+'/playlist/'+id
			title = 'LIST'+count+':  '+name
			title = yId69qYhzF0ic(title)
			WtgVhfrHisQOy0p9UjMDT = uuTMWEOrK26JIzRPAw0tD9plh5+'::'+qkUQREjo9ibsO50AMmLwJIhBxp
			x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,401,Sj7rMNYRuQPTtkBvpHKeDW3h,qpFY4hAwolV3,WtgVhfrHisQOy0p9UjMDT)
		if '"hasNextPage":true' in cmWl9dOKHPIy41iaXuxrY:
			i02wfPp5EM = str(int(i02wfPp5EM)+1)
			x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+'صفحة '+i02wfPp5EM,url,407,qpFY4hAwolV3,i02wfPp5EM)
	return
def BuQg8Nojq5Ph4aRw(url,NdIzHy4nGpxBbaUw):
	KpzHWlsYVwvhfdN0A8Lk2n6M = url.split(ShynO8pN9idCE3)[3]
	AMbRf4XTpQNvio6J5GELducy0k = '''{"operationName":"CHANNEL_QUERY_DESKTOP","variables":{"channel_name":"mychannelid","relatedChannels":100},"query":"fragment CHANNEL_FRAGMENT on Channel {  accountType  id  xid  name  displayName  isArtist  logoURL(size: \\"x60\\")  coverURLx375: coverURL(size: \\"x375\\")  isFollowed  stats {    id    views {      id      total      __typename    }    followers {      id      total      __typename    }    videos {      id      total      __typename    }    __typename  }  __typename}fragment LIVE_FRAGMENT on Live {  id  xid  title  startAt  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx360: thumbnailURL(size: \\"x360\\")  thumbnailx480: thumbnailURL(size: \\"x480\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  channel {    id    ...CHANNEL_FRAGMENT    __typename  }  __typename}fragment VIDEO_FRAGMENT on Video {  id  xid  title  viewCount  duration  createdAt  isInWatchLater  channel {    id    ...CHANNEL_FRAGMENT    __typename  }  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx360: thumbnailURL(size: \\"x360\\")  thumbnailx480: thumbnailURL(size: \\"x480\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  __typename}fragment CHANNEL_MAIN_FRAGMENT on Channel {  id  xid  name  displayName  description  accountType  isArtist  logoURL(size: \\"x60\\")  coverURL1024x: coverURL(size: \\"1024x\\")  coverURL1920x: coverURL(size: \\"1920x\\")  isFollowed  tagline  country {    id    codeAlpha2    __typename  }  stats {    id    views {      id      total      __typename    }    followers {      id      total      __typename    }    videos {      id      total      __typename    }    __typename  }  externalLinks {    id    facebookURL    twitterURL    websiteURL    instagramURL    pinterestURL    __typename  }  channel_lives_now: lives(first: 4, isOnAir: true) {    edges {      node {        id        ...LIVE_FRAGMENT        __typename      }      __typename    }    __typename  }  channel_lives_scheduled: lives(first: 4, startIn: 7200) {    edges {      node {        id        ...LIVE_FRAGMENT        __typename      }      __typename    }    __typename  }  channel_featured_videos: videos(first: 4, isFeatured: true) {    edges {      node {        id        ...VIDEO_FRAGMENT        __typename      }      __typename    }    __typename  }  channel_all_videos: videos(first: 4) {    edges {      node {        id        ...VIDEO_FRAGMENT        __typename      }      __typename    }    __typename  }  channel_most_viewed: videos(first: 4, sort: \\"visited\\") {    edges {      node {        id        ...VIDEO_FRAGMENT        __typename      }      __typename    }    __typename  }  channel_collections: collections(first: 4) {    edges {      node {        id        xid        name        description        stats {          id          videos {            id            total            __typename          }          __typename        }        thumbnailx240: thumbnailURL(size: \\"x240\\")        thumbnailx360: thumbnailURL(size: \\"x360\\")        thumbnailx480: thumbnailURL(size: \\"x480\\")        channel {          id          ...CHANNEL_FRAGMENT          __typename        }        __typename      }      __typename    }    __typename  }  channel_related_channel: networkChannels(    hasPublicVideos: true    first: $relatedChannels  ) {    edges {      node {        id        ...CHANNEL_FRAGMENT        __typename      }      __typename    }    __typename  }  __typename}query CHANNEL_QUERY_DESKTOP($channel_name: String!, $relatedChannels: Int) {  channel(name: $channel_name) {    id    ...CHANNEL_MAIN_FRAGMENT    __typename  }}"}'''
	AMbRf4XTpQNvio6J5GELducy0k = AMbRf4XTpQNvio6J5GELducy0k.replace('mychannelid',KpzHWlsYVwvhfdN0A8Lk2n6M)
	cmWl9dOKHPIy41iaXuxrY = pLVAohQrUi2JePNxzmDHC9Ru(AMbRf4XTpQNvio6J5GELducy0k)
	PzLx57D4NeW1 = A3AFYmgZLXn4MBab.loads(cmWl9dOKHPIy41iaXuxrY)
	try: items = PzLx57D4NeW1['data']['channel'][NdIzHy4nGpxBbaUw]['edges']
	except: items = []
	if not items: x3WSXnKyPhjqfHG2UrtQs('link',wwSFijdVJn1QgHW+'لا توجد نتائج',qpFY4hAwolV3,9999)
	else:
		for lkd2oKvZF03qmgMbIfQ6cD in items:
			BBlKUuJVgvEqYIRsZCMy = lkd2oKvZF03qmgMbIfQ6cD['node']
			i7nJwdLB5vqPRuVYfrKh9m2eg = BBlKUuJVgvEqYIRsZCMy['xid']
			keys = list(BBlKUuJVgvEqYIRsZCMy.keys())
			vdFpV06ByfWkqbnSueLR = BBlKUuJVgvEqYIRsZCMy['__typename'].lower()
			if vdFpV06ByfWkqbnSueLR=='channel':
				name = BBlKUuJVgvEqYIRsZCMy['name']
				BPpy2qXY5aiuID0lK3xbh9LsOE = BBlKUuJVgvEqYIRsZCMy['displayName']
				title = 'USER:  '+BPpy2qXY5aiuID0lK3xbh9LsOE
				Sj7rMNYRuQPTtkBvpHKeDW3h = BBlKUuJVgvEqYIRsZCMy['coverURLx375']
			else:
				name = BBlKUuJVgvEqYIRsZCMy['channel']['name']
				BPpy2qXY5aiuID0lK3xbh9LsOE = BBlKUuJVgvEqYIRsZCMy['channel']['displayName']
				title = BBlKUuJVgvEqYIRsZCMy['title']
				Sj7rMNYRuQPTtkBvpHKeDW3h = BBlKUuJVgvEqYIRsZCMy['thumbnailx360']
				if vdFpV06ByfWkqbnSueLR=='live': title = 'LIVE:  '+title
			title = yId69qYhzF0ic(title)
			WtgVhfrHisQOy0p9UjMDT = name+'::'+BPpy2qXY5aiuID0lK3xbh9LsOE
			if NJwViHDTMdmO0xnALqQ9voPalC3Ip:
				title = title.encode(nV3Tip6XsH1rJw79DPOU)
				WtgVhfrHisQOy0p9UjMDT = WtgVhfrHisQOy0p9UjMDT.encode(nV3Tip6XsH1rJw79DPOU)
			Sj7rMNYRuQPTtkBvpHKeDW3h = Sj7rMNYRuQPTtkBvpHKeDW3h.replace('\/',ShynO8pN9idCE3)
			if vdFpV06ByfWkqbnSueLR=='channel':
				MepIvHBYNArkUOdV37shtJ = ddBxj51bhNtaK23lDyGMVw+ShynO8pN9idCE3+i7nJwdLB5vqPRuVYfrKh9m2eg
				x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,402,Sj7rMNYRuQPTtkBvpHKeDW3h,qpFY4hAwolV3,WtgVhfrHisQOy0p9UjMDT)
			else:
				if vdFpV06ByfWkqbnSueLR=='video': dq0kBrGuKXiP = str(BBlKUuJVgvEqYIRsZCMy['duration'])
				else: dq0kBrGuKXiP = qpFY4hAwolV3
				MepIvHBYNArkUOdV37shtJ = ddBxj51bhNtaK23lDyGMVw+'/video/'+i7nJwdLB5vqPRuVYfrKh9m2eg
				x3WSXnKyPhjqfHG2UrtQs(vdFpV06ByfWkqbnSueLR,wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,403,Sj7rMNYRuQPTtkBvpHKeDW3h,dq0kBrGuKXiP,WtgVhfrHisQOy0p9UjMDT)
	return
def qqIVKYoOZpdmHrz(search,i02wfPp5EM=qpFY4hAwolV3):
	if i02wfPp5EM==qpFY4hAwolV3: i02wfPp5EM = '1'
	AMbRf4XTpQNvio6J5GELducy0k = '''{"operationName":"SEARCH_QUERY","variables":{"query":"mysearchwords","shouldIncludeChannels":false,"shouldIncludePlaylists":false,"shouldIncludeHashtags":true,"shouldIncludeVideos":false,"shouldIncludeLives":false,"page":mypagenumber,"limit":mypagelimit},"query":"fragment VIDEO_BASE_FRAGMENT on Video {  id  xid  title  createdAt  duration  aspectRatio  thumbnail(height: PORTRAIT_240) {    id    url    __typename  }  creator {    id    xid    name    displayName    accountType    avatar(height: SQUARE_60) {      id      url      __typename    }    __typename  }  __typename}fragment CHANNEL_BASE_FRAG on Channel {  id  xid  name  displayName  accountType  isFollowed  avatar(height: SQUARE_120) {    id    url    __typename  }  followerEngagement {    id    followDate    __typename  }  metrics {    id    engagement {      id      followers {        edges {          node {            id            total            __typename          }          __typename        }        __typename      }      __typename    }    __typename  }  __typename}fragment PLAYLIST_BASE_FRAG on Collection {  id  xid  name  description  thumbnail(height: PORTRAIT_240) {    id    url    __typename  }  creator {    id    xid    name    displayName    accountType    avatar(height: SQUARE_60) {      id      url      __typename    }    __typename  }  metrics {    id    engagement {      id      videos(filter: {visibility: {eq: PUBLIC}}) {        edges {          node {            id            total            __typename          }          __typename        }        __typename      }      __typename    }    __typename  }  __typename}fragment HASHTAG_BASE_FRAG on Hashtag {  id  xid  name  metrics {    id    engagement {      id      videos {        edges {          node {            id            total            __typename          }          __typename        }        __typename      }      __typename    }    __typename  }  __typename}fragment LIVE_BASE_FRAGMENT on Live {  id  xid  title  audienceCount  aspectRatio  isOnAir  thumbnail(height: PORTRAIT_240) {    id    url    __typename  }  creator {    id    xid    name    displayName    accountType    avatar(height: SQUARE_60) {      id      url      __typename    }    __typename  }  __typename}query SEARCH_QUERY($query: String!, $shouldIncludeVideos: Boolean!, $shouldIncludeChannels: Boolean!, $shouldIncludePlaylists: Boolean!, $shouldIncludeHashtags: Boolean!, $shouldIncludeLives: Boolean!, $page: Int, $limit: Int, $sortByVideos: SearchVideoSort, $durationMinVideos: Int, $durationMaxVideos: Int, $createdAfterVideos: DateTime) {  search {    id    videos(      query: $query      first: $limit      page: $page      sort: $sortByVideos      durationMin: $durationMinVideos      durationMax: $durationMaxVideos      createdAfter: $createdAfterVideos    ) @include(if: $shouldIncludeVideos) {      metadata {        id        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      edges {        node {          id          ...VIDEO_BASE_FRAGMENT          __typename        }        __typename      }      __typename    }    lives(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeLives) {      metadata {        id        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      edges {        node {          id          ...LIVE_BASE_FRAGMENT          __typename        }        __typename      }      __typename    }    channels(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeChannels) {      metadata {        id        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      edges {        node {          id          ...CHANNEL_BASE_FRAG          __typename        }        __typename      }      __typename    }    playlists: collections(query: $query, first: $limit, page: $page) @include(if: $shouldIncludePlaylists) {      metadata {        id        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      edges {        node {          id          ...PLAYLIST_BASE_FRAG          __typename        }        __typename      }      __typename    }    hashtags(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeHashtags) {      metadata {        id        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      edges {        node {          id          ...HASHTAG_BASE_FRAG          __typename        }        __typename      }      __typename    }    __typename  }}"}'''
	AMbRf4XTpQNvio6J5GELducy0k = AMbRf4XTpQNvio6J5GELducy0k.replace('mysearchwords',search)
	AMbRf4XTpQNvio6J5GELducy0k = AMbRf4XTpQNvio6J5GELducy0k.replace('mypagelimit','40')
	AMbRf4XTpQNvio6J5GELducy0k = AMbRf4XTpQNvio6J5GELducy0k.replace('mypagenumber',i02wfPp5EM)
	url = ddBxj51bhNtaK23lDyGMVw+'/search/'+search+'/hashtags'
	ppHs9AECcZ8 = pLVAohQrUi2JePNxzmDHC9Ru(AMbRf4XTpQNvio6J5GELducy0k,search)
	if ppHs9AECcZ8:
		UuoQtlfEkaicdLWY50ZOj = wB8NUAidPbqjIr9CFasXvYnxOQpL0g('dict',ppHs9AECcZ8)
		try: llM5hBSovHuxIWLXYtUiRTFVj3J9 = UuoQtlfEkaicdLWY50ZOj['data']['search']['hashtags']['edges']
		except: llM5hBSovHuxIWLXYtUiRTFVj3J9 = []
		for gIleHBFXDq in llM5hBSovHuxIWLXYtUiRTFVj3J9:
			name = gIleHBFXDq['node']['name']
			name = N8E37XwL6iQbmBY(name)
			MepIvHBYNArkUOdV37shtJ = ddBxj51bhNtaK23lDyGMVw+'/hashtag/'+name[1:]
			x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+'HSHTG: '+name,MepIvHBYNArkUOdV37shtJ,417)
		if '"hasNextPage":true' in ppHs9AECcZ8:
			i02wfPp5EM = str(int(i02wfPp5EM)+1)
			x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+'صفحة '+i02wfPp5EM,url,416,qpFY4hAwolV3,i02wfPp5EM,search)
	return
def sdBe1SxHAZ(url,i02wfPp5EM=qpFY4hAwolV3):
	if i02wfPp5EM==qpFY4hAwolV3: i02wfPp5EM = '1'
	name = url.split(ShynO8pN9idCE3)[-1]
	AMbRf4XTpQNvio6J5GELducy0k = '''{"operationName":"HASHTAG_VIDEOS_QUERY","variables":{"hashtag_name":"#myhashtagname","page":mypagenumber},"query":"fragment FRAG_VIDEO_BASE on Video {  id  xid  title  description  thumbnail: thumbnailURL(size: \\"x240\\")  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx360: thumbnailURL(size: \\"x360\\")  thumbnailx480: thumbnailURL(size: \\"x480\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  bestAvailableQuality  duration  createdAt  viewerEngagement {    id    liked    favorited    __typename  }  isExplicit  canDisplayAds  aspectRatio  stats {    id    views {      id      total      __typename    }    __typename  }  language {    id    codeAlpha2    __typename  }  videoHeight: height  videoWidth: width  __typename}fragment CHANNEL_BASE_FRAG on Channel {  id  xid  name  displayName  description  logoURL(size: \\"x25\\")  logoURLx60: logoURL(size: \\"x60\\")  coverURL(size: \\"x200\\")  coverURLx1024: coverURL(size: \\"1024x\\")  isFollowed  isArtist  accountType  __typename}fragment VIDEO_FRAG on Video {  id  ...FRAG_VIDEO_BASE  channel {    id    ...CHANNEL_BASE_FRAG    __typename  }  __typename}query HASHTAG_VIDEOS_QUERY($hashtag_name: String!, $page: Int!) {  contentFeed(    name: HASHTAG    filter: {name: {eq: $hashtag_name}, post: {eq: VIDEO}}    sort: {create: DESC}    page: $page    first: 30  ) {    totalCount    pageInfo {      hasNextPage      nextPage      __typename    }    edges {      node {        post {          ...VIDEO_FRAG          __typename        }        featured        __typename      }      __typename    }    __typename  }}"}'''
	AMbRf4XTpQNvio6J5GELducy0k = AMbRf4XTpQNvio6J5GELducy0k.replace('myhashtagname',name)
	AMbRf4XTpQNvio6J5GELducy0k = AMbRf4XTpQNvio6J5GELducy0k.replace('mypagenumber',i02wfPp5EM)
	ppHs9AECcZ8 = pLVAohQrUi2JePNxzmDHC9Ru(AMbRf4XTpQNvio6J5GELducy0k)
	if ppHs9AECcZ8:
		UuoQtlfEkaicdLWY50ZOj = wB8NUAidPbqjIr9CFasXvYnxOQpL0g('dict',ppHs9AECcZ8)
		llM5hBSovHuxIWLXYtUiRTFVj3J9 = UuoQtlfEkaicdLWY50ZOj['data']['contentFeed']['edges']
		for gIleHBFXDq in llM5hBSovHuxIWLXYtUiRTFVj3J9:
			dq0kBrGuKXiP = str(gIleHBFXDq['node']['post']['duration'])
			title = N8E37XwL6iQbmBY(gIleHBFXDq['node']['post']['title'])
			title = title.replace('\/',ShynO8pN9idCE3)
			i7nJwdLB5vqPRuVYfrKh9m2eg = gIleHBFXDq['node']['post']['xid']
			Sj7rMNYRuQPTtkBvpHKeDW3h = gIleHBFXDq['node']['post']['thumbnailx480']
			Sj7rMNYRuQPTtkBvpHKeDW3h = Sj7rMNYRuQPTtkBvpHKeDW3h.replace('\/',ShynO8pN9idCE3)
			MepIvHBYNArkUOdV37shtJ = ddBxj51bhNtaK23lDyGMVw+'/video/'+i7nJwdLB5vqPRuVYfrKh9m2eg
			x3WSXnKyPhjqfHG2UrtQs('video',wwSFijdVJn1QgHW+title,MepIvHBYNArkUOdV37shtJ,403,Sj7rMNYRuQPTtkBvpHKeDW3h,dq0kBrGuKXiP)
		if '"hasNextPage":true' in ppHs9AECcZ8:
			i02wfPp5EM = str(int(i02wfPp5EM)+1)
			x3WSXnKyPhjqfHG2UrtQs('folder',wwSFijdVJn1QgHW+'صفحة '+i02wfPp5EM,url,416,qpFY4hAwolV3,i02wfPp5EM)
	return
def pLVAohQrUi2JePNxzmDHC9Ru(AMbRf4XTpQNvio6J5GELducy0k,search=qpFY4hAwolV3):
	if DLod2Of8CkRrtzJynev: AMbRf4XTpQNvio6J5GELducy0k = AMbRf4XTpQNvio6J5GELducy0k.encode(nV3Tip6XsH1rJw79DPOU)
	mVXq5NwsSnMKhv0Yz2 = srRO705p1oFlJfP()
	headers = {"Authorization":mVXq5NwsSnMKhv0Yz2,"Origin":ddBxj51bhNtaK23lDyGMVw}
	if search:
		iipsGz2LKq = ecyzJ5qXfBnOiMHRLShmw
		headers.update({'Content-Type':'application/json','Referer':ddBxj51bhNtaK23lDyGMVw+ShynO8pN9idCE3,'X-DM-AppInfo-Id':'com.dailymotion.neon'})
	else:
		iipsGz2LKq = WsvFbLApfU
		headers.update({'Content-Type':'text/plain; charset=utf-8'})
	IAW0sh6So3NpqM = WWrExJZS3Bj4anOAkpv7(rGY36xBwT1bLZAngSfcWEIeXdQVNij,'POST',WsvFbLApfU,AMbRf4XTpQNvio6J5GELducy0k,headers,qpFY4hAwolV3,qpFY4hAwolV3,'DAILYMOTION-GET_PAGEDATA-1st')
	cmWl9dOKHPIy41iaXuxrY = IAW0sh6So3NpqM.content
	return cmWl9dOKHPIy41iaXuxrY
def srRO705p1oFlJfP():
	IAW0sh6So3NpqM = WWrExJZS3Bj4anOAkpv7(rGY36xBwT1bLZAngSfcWEIeXdQVNij,'GET',ddBxj51bhNtaK23lDyGMVw,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,qpFY4hAwolV3,'DAILYMOTION-GET_AUTHINTICATION-1st')
	cmWl9dOKHPIy41iaXuxrY = IAW0sh6So3NpqM.content
	iiFR3agJPQlTBZKomWc = ePhmG1jLD6.findall('apiClientId.*?return"(.*?)"',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	iiFR3agJPQlTBZKomWc = iiFR3agJPQlTBZKomWc[vvXoMLlg513]
	oYpsvkmuD86 = ePhmG1jLD6.findall('apiClientSecret.*?return"(.*?)"',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	oYpsvkmuD86 = oYpsvkmuD86[vvXoMLlg513]
	V29VPYiCoXbNBWLUj = 'https://graphql.api.dailymotion.com/oauth/token'
	ygs0cvFADuYXQwUp76M4xP23nTHjCr = 'client_credentials'
	data = {'client_id':iiFR3agJPQlTBZKomWc,'client_secret':oYpsvkmuD86,'grant_type':ygs0cvFADuYXQwUp76M4xP23nTHjCr}
	headers = {'Content-Type':'application/x-www-form-urlencoded'}
	IAW0sh6So3NpqM = WWrExJZS3Bj4anOAkpv7(rGY36xBwT1bLZAngSfcWEIeXdQVNij,'POST',V29VPYiCoXbNBWLUj,data,headers,qpFY4hAwolV3,qpFY4hAwolV3,'DAILYMOTION-GET_AUTHINTICATION-2nd')
	cmWl9dOKHPIy41iaXuxrY = IAW0sh6So3NpqM.content
	n3YAKgzuWCSq = ePhmG1jLD6.findall('"access_token": *"(.*?)".*?"token_type": *"(.*?)"',cmWl9dOKHPIy41iaXuxrY,ePhmG1jLD6.DOTALL)
	P9jMVWZN6qdu85Lr1UY7oXBvAcKy,SMa5P9gphH = n3YAKgzuWCSq[0]
	mVXq5NwsSnMKhv0Yz2 = SMa5P9gphH+" "+P9jMVWZN6qdu85Lr1UY7oXBvAcKy
	return mVXq5NwsSnMKhv0Yz2
def PPqUACSE3VcGLTvw05jHy9JrFNW(search,kJ358BIeXtYvzn=qpFY4hAwolV3):
	search,LBylNhMdH6OV1qGk0tWiXFg3,showDialogs = LLm3sBXHPcnTDxdE5gt6hz0Wkp(search)
	if not kJ358BIeXtYvzn and showDialogs:
		RFC0rmvlxsqMhAGtynLYDJX5W12SgP = ['بحث عن فيديوهات','بحث عن آخر الفيديوهات','بحث عن الفيديوهات الاكثر مشاهدة','(جيد للمسلسلات) بحث عن قوائم تشغيل','بحث عن مستخدم','بحث عن بث حي','بحث عن هاشتاك']
		ndm6kKswPpgGHNEbtB = xVzqWbrFXJ('موقع ديلي موشن - اختر البحث',RFC0rmvlxsqMhAGtynLYDJX5W12SgP)
		if ndm6kKswPpgGHNEbtB==-1: return
		elif ndm6kKswPpgGHNEbtB==0: kJ358BIeXtYvzn = 'videos?sortBy='
		elif ndm6kKswPpgGHNEbtB==1: kJ358BIeXtYvzn = 'videos?sortBy=RECENT'
		elif ndm6kKswPpgGHNEbtB==2: kJ358BIeXtYvzn = 'videos?sortBy=VIEW_COUNT'
		elif ndm6kKswPpgGHNEbtB==3: kJ358BIeXtYvzn = 'playlists'
		elif ndm6kKswPpgGHNEbtB==4: kJ358BIeXtYvzn = 'channels'
		elif ndm6kKswPpgGHNEbtB==5: kJ358BIeXtYvzn = 'lives'
		elif ndm6kKswPpgGHNEbtB==6: kJ358BIeXtYvzn = 'hashtags'
	elif '_DAILYMOTION-VIDEOS_' in LBylNhMdH6OV1qGk0tWiXFg3: kJ358BIeXtYvzn = 'videos?sortBy='
	elif '_DAILYMOTION-PLAYLISTS_' in LBylNhMdH6OV1qGk0tWiXFg3: kJ358BIeXtYvzn = 'playlists'
	elif '_DAILYMOTION-CHANNELS_' in LBylNhMdH6OV1qGk0tWiXFg3: kJ358BIeXtYvzn = 'channels'
	elif '_DAILYMOTION-LIVES_' in LBylNhMdH6OV1qGk0tWiXFg3: kJ358BIeXtYvzn = 'lives'
	elif '_DAILYMOTION-HASHTAGS_' in LBylNhMdH6OV1qGk0tWiXFg3: kJ358BIeXtYvzn = 'hashtags'
	elif not kJ358BIeXtYvzn: kJ358BIeXtYvzn = 'videos?sortBy='
	if not search:
		search = jXgARlWMLVFUBnvmZwI2o5()
		if not search: return
	if 'videos' in kJ358BIeXtYvzn: jhzd07SxafLVucJ8v6(search+ShynO8pN9idCE3+kJ358BIeXtYvzn)
	elif 'playlists' in kJ358BIeXtYvzn: GTbUZS3fv64MRAO2P9F17(search)
	elif 'channels' in kJ358BIeXtYvzn: rMtdiKkEmsnXc7BxhDwbO8JaQ5R9qy(search)
	elif 'lives' in kJ358BIeXtYvzn: c0IaUs6OEor7LhqHiu1NfVmAd(search)
	elif 'hashtags' in kJ358BIeXtYvzn: qqIVKYoOZpdmHrz(search)
	return