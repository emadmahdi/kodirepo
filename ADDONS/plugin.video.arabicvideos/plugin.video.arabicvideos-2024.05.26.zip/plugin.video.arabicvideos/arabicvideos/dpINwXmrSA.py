# -*- coding: utf-8 -*-
from j3x780FpaM import *
ll6f2wvU4FdqL3MJyDxORESCK197i = 'BOKRA'
W74fAyGxODoLPs5vMX2l8C93R = '_BKR_'
JJTrn6SEtYZV31eyR97 = uReHcEzxkTm6pN4Q[ll6f2wvU4FdqL3MJyDxORESCK197i][0]
headers = {'User-Agent':''}
SmgoEYJ7uyL = ['افلام للكبار','بكرا TV']
def OVQIAezo6U1NSTl4L(mode,url,text):
	if   mode==370: HkKfQCS7RIa4xi3houjvl = oMUN5hPpTkxVZG12Qiva8BKnyw6()
	elif mode==371: HkKfQCS7RIa4xi3houjvl = RxAy5lEFQ1chv0BrdU4p6Pt2(url,text)
	elif mode==372: HkKfQCS7RIa4xi3houjvl = jXYwiO9D056pkrzRh1y8tfWJxQoaI3(url)
	elif mode==374: HkKfQCS7RIa4xi3houjvl = KmzIYkGJT4DxRL69OSwvc1Vj3bX(url)
	elif mode==375: HkKfQCS7RIa4xi3houjvl = Tak6DpBXVYEKm(url)
	elif mode==376: HkKfQCS7RIa4xi3houjvl = x5VYu1HgWtm3RwrlezTG(0,url)
	elif mode==377: HkKfQCS7RIa4xi3houjvl = x5VYu1HgWtm3RwrlezTG(1,url)
	elif mode==379: HkKfQCS7RIa4xi3houjvl = F6OgHwYPRiX10tJEv8r(text)
	else: HkKfQCS7RIa4xi3houjvl = False
	return HkKfQCS7RIa4xi3houjvl
def oMUN5hPpTkxVZG12Qiva8BKnyw6():
	wpFmEA3z8JR = A6F71g3cqN4(JNsoWV1CXc4xy,'GET',JJTrn6SEtYZV31eyR97,'','','','','BOKRA-MENU-1st')
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+'بحث في الموقع','',379,'','','_REMEMBERRESULTS_')
	Tca7NsYPkIRWtBpFgxLZbSmCi('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	QstumvzTIEUMXCcx06aD4y8nSqH = wpFmEA3z8JR.content
	IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('right-side(.*?)</ul>',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	if IZGcQbePXxwAoyYR1n:
		bdq4e6Wr2gslnSiA38 = IZGcQbePXxwAoyYR1n[0]
		items = ZXFs0mEPR8qI2zj.findall('href="(.*?)">(.*?)<',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
		for RRucmYBaXegTtNOdGHMQ,title in items:
			RRucmYBaXegTtNOdGHMQ = JJTrn6SEtYZV31eyR97+RRucmYBaXegTtNOdGHMQ
			if not any(AARNPWHjQU9dEmDI in title for AARNPWHjQU9dEmDI in SmgoEYJ7uyL):
				Tca7NsYPkIRWtBpFgxLZbSmCi('folder',ll6f2wvU4FdqL3MJyDxORESCK197i+'_SCRIPT_'+W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,371)
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder',ll6f2wvU4FdqL3MJyDxORESCK197i+'_SCRIPT_'+W74fAyGxODoLPs5vMX2l8C93R+'المميزة',JJTrn6SEtYZV31eyR97,375)
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder',ll6f2wvU4FdqL3MJyDxORESCK197i+'_SCRIPT_'+W74fAyGxODoLPs5vMX2l8C93R+'الأحدث',JJTrn6SEtYZV31eyR97,376)
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder',ll6f2wvU4FdqL3MJyDxORESCK197i+'_SCRIPT_'+W74fAyGxODoLPs5vMX2l8C93R+'قائمة الممثلين',JJTrn6SEtYZV31eyR97,374)
	Tca7NsYPkIRWtBpFgxLZbSmCi('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('class="container"(.*?)top-menu',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	if IZGcQbePXxwAoyYR1n:
		bdq4e6Wr2gslnSiA38 = IZGcQbePXxwAoyYR1n[0]
		items = ZXFs0mEPR8qI2zj.findall('href="(.*?)">(.*?)<',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
		for RRucmYBaXegTtNOdGHMQ,title in items[7:]:
			title = title.strip(' ')
			RRucmYBaXegTtNOdGHMQ = JJTrn6SEtYZV31eyR97+RRucmYBaXegTtNOdGHMQ
			if not any(AARNPWHjQU9dEmDI in title for AARNPWHjQU9dEmDI in SmgoEYJ7uyL):
				Tca7NsYPkIRWtBpFgxLZbSmCi('folder',ll6f2wvU4FdqL3MJyDxORESCK197i+'_SCRIPT_'+W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,371)
		for RRucmYBaXegTtNOdGHMQ,title in items[0:7]:
			title = title.strip(' ')
			RRucmYBaXegTtNOdGHMQ = JJTrn6SEtYZV31eyR97+RRucmYBaXegTtNOdGHMQ
			if not any(AARNPWHjQU9dEmDI in title for AARNPWHjQU9dEmDI in SmgoEYJ7uyL):
				Tca7NsYPkIRWtBpFgxLZbSmCi('folder',ll6f2wvU4FdqL3MJyDxORESCK197i+'_SCRIPT_'+W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,371)
	return
def KmzIYkGJT4DxRL69OSwvc1Vj3bX(website=''):
	wpFmEA3z8JR = A6F71g3cqN4(JNsoWV1CXc4xy,'GET',JJTrn6SEtYZV31eyR97,'','','','','BOKRA-ACTORSMENU-1st')
	QstumvzTIEUMXCcx06aD4y8nSqH = wpFmEA3z8JR.content
	IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('class="row cat Tags"(.*?)</div>',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	if IZGcQbePXxwAoyYR1n:
		bdq4e6Wr2gslnSiA38 = IZGcQbePXxwAoyYR1n[0]
		items = ZXFs0mEPR8qI2zj.findall('href="(.*?)" title="(.*?)"',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
		for RRucmYBaXegTtNOdGHMQ,title in items:
			if 'http' in RRucmYBaXegTtNOdGHMQ: continue
			else: RRucmYBaXegTtNOdGHMQ = JJTrn6SEtYZV31eyR97+RRucmYBaXegTtNOdGHMQ
			if not any(AARNPWHjQU9dEmDI in title for AARNPWHjQU9dEmDI in SmgoEYJ7uyL):
				Tca7NsYPkIRWtBpFgxLZbSmCi('folder',ll6f2wvU4FdqL3MJyDxORESCK197i+'_SCRIPT_'+W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,371)
	return
def Tak6DpBXVYEKm(website=''):
	wpFmEA3z8JR = A6F71g3cqN4(dALVaOWB4jKN3Tbt0Cm1ns9k5u,'GET',JJTrn6SEtYZV31eyR97,'','','','','BOKRA-FEATURED-1st')
	QstumvzTIEUMXCcx06aD4y8nSqH = wpFmEA3z8JR.content
	IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('"MainContent"(.*?)main-title2',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	if IZGcQbePXxwAoyYR1n:
		bdq4e6Wr2gslnSiA38 = IZGcQbePXxwAoyYR1n[0]
		items = ZXFs0mEPR8qI2zj.findall('href="(/vidpage_.*?)".*? src="(.*?)".*?<h3>(.*?)</h3>',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
		for RRucmYBaXegTtNOdGHMQ,CrGO63LT7j2UxniW,title in items:
			RRucmYBaXegTtNOdGHMQ = JJTrn6SEtYZV31eyR97+RRucmYBaXegTtNOdGHMQ
			if not any(AARNPWHjQU9dEmDI in title for AARNPWHjQU9dEmDI in SmgoEYJ7uyL):
				CrGO63LT7j2UxniW = CrGO63LT7j2UxniW.replace('://',':///').replace('//','/').replace(' ','%20')
				Tca7NsYPkIRWtBpFgxLZbSmCi('video',ll6f2wvU4FdqL3MJyDxORESCK197i+'_SCRIPT_'+W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,372,CrGO63LT7j2UxniW)
	return
def x5VYu1HgWtm3RwrlezTG(id,website=''):
	wpFmEA3z8JR = A6F71g3cqN4(dALVaOWB4jKN3Tbt0Cm1ns9k5u,'GET',JJTrn6SEtYZV31eyR97,'','','','','BOKRA-WATCHINGNOW-1st')
	QstumvzTIEUMXCcx06aD4y8nSqH = wpFmEA3z8JR.content
	IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('main-title2(.*?)class="row',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	if IZGcQbePXxwAoyYR1n:
		bdq4e6Wr2gslnSiA38 = IZGcQbePXxwAoyYR1n[id]
		items = ZXFs0mEPR8qI2zj.findall('href="(.*?)".*? src="(.*?)".*?<h4>(.*?)</h4>',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
		for RRucmYBaXegTtNOdGHMQ,CrGO63LT7j2UxniW,title in items:
			RRucmYBaXegTtNOdGHMQ = JJTrn6SEtYZV31eyR97+RRucmYBaXegTtNOdGHMQ
			if not any(AARNPWHjQU9dEmDI in title for AARNPWHjQU9dEmDI in SmgoEYJ7uyL):
				CrGO63LT7j2UxniW = CrGO63LT7j2UxniW.replace('://',':///').replace('//','/').replace(' ','%20')
				Tca7NsYPkIRWtBpFgxLZbSmCi('video',ll6f2wvU4FdqL3MJyDxORESCK197i+'_SCRIPT_'+W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,372,CrGO63LT7j2UxniW)
	return
def RxAy5lEFQ1chv0BrdU4p6Pt2(url,kpM5lOCec20mrw6hV7ILBd=''):
	wpFmEA3z8JR = A6F71g3cqN4(Z7uFdWIRv9ybj0,'GET',url,'','','','','BOKRA-TITLES-1st')
	QstumvzTIEUMXCcx06aD4y8nSqH = wpFmEA3z8JR.content
	if 'vidpage_' in url:
		RRucmYBaXegTtNOdGHMQ = ZXFs0mEPR8qI2zj.findall('href="(/Album-.*?)"',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
		if RRucmYBaXegTtNOdGHMQ:
			RRucmYBaXegTtNOdGHMQ = JJTrn6SEtYZV31eyR97+RRucmYBaXegTtNOdGHMQ[0]
			RxAy5lEFQ1chv0BrdU4p6Pt2(RRucmYBaXegTtNOdGHMQ)
			return
	IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('class=" subcats"(.*?)class="col-md-3',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	if kpM5lOCec20mrw6hV7ILBd=='' and IZGcQbePXxwAoyYR1n and IZGcQbePXxwAoyYR1n[0].count('href')>1:
		Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+'الجميع',url,371,'','','titles')
		bdq4e6Wr2gslnSiA38 = IZGcQbePXxwAoyYR1n[0]
		items = ZXFs0mEPR8qI2zj.findall('href="(.*?)" title="(.*?)"',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
		for RRucmYBaXegTtNOdGHMQ,title in items:
			RRucmYBaXegTtNOdGHMQ = JJTrn6SEtYZV31eyR97+'/'+RRucmYBaXegTtNOdGHMQ
			title = title.strip(' ')
			Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,371)
	else:
		FF1TYf6O5KENr8R72LUVievClmudxD = []
		IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('class="col-md-3(.*?)col-xs-12',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
		if not IZGcQbePXxwAoyYR1n: IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('class="col-sm-8"(.*?)col-xs-12',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
		if IZGcQbePXxwAoyYR1n:
			bdq4e6Wr2gslnSiA38 = IZGcQbePXxwAoyYR1n[0]
			items = ZXFs0mEPR8qI2zj.findall('href="(.*?)".*?src="(.*?)".*?<h4>(.*?)</h4>',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
			for RRucmYBaXegTtNOdGHMQ,CrGO63LT7j2UxniW,title in items:
				RRucmYBaXegTtNOdGHMQ = JJTrn6SEtYZV31eyR97+RRucmYBaXegTtNOdGHMQ
				title = title.strip(' ')
				CrGO63LT7j2UxniW = CrGO63LT7j2UxniW.replace('://',':///').replace('//','/').replace(' ','%20')
				if '/al_' in RRucmYBaXegTtNOdGHMQ:
					Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,371,CrGO63LT7j2UxniW)
				elif 'الحلقة' in title and ('/Cat-' in url or '/Search/' in url):
					LqYKJ36CBG = ZXFs0mEPR8qI2zj.findall('(.*?) - +الحلقة +\d+',title,ZXFs0mEPR8qI2zj.DOTALL)
					if LqYKJ36CBG: title = '_MOD_مسلسل '+LqYKJ36CBG[0]
					if title not in FF1TYf6O5KENr8R72LUVievClmudxD:
						FF1TYf6O5KENr8R72LUVievClmudxD.append(title)
						Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,371,CrGO63LT7j2UxniW)
				else: Tca7NsYPkIRWtBpFgxLZbSmCi('video',W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,372,CrGO63LT7j2UxniW)
		IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('class="pagination(.*?)</div>',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
		if IZGcQbePXxwAoyYR1n:
			bdq4e6Wr2gslnSiA38 = IZGcQbePXxwAoyYR1n[0]
			items = ZXFs0mEPR8qI2zj.findall('class="".*?href="(.*?)">(.*?)<',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
			for RRucmYBaXegTtNOdGHMQ,title in items:
				RRucmYBaXegTtNOdGHMQ = JJTrn6SEtYZV31eyR97+RRucmYBaXegTtNOdGHMQ
				title = 'صفحة '+qpob7TvxHSs4fEzO6(title)
				Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,371,'','','titles')
	return
def jXYwiO9D056pkrzRh1y8tfWJxQoaI3(url):
	wpFmEA3z8JR = A6F71g3cqN4(dALVaOWB4jKN3Tbt0Cm1ns9k5u,'GET',url,'','','','','BOKRA-PLAY-1st')
	QstumvzTIEUMXCcx06aD4y8nSqH = wpFmEA3z8JR.content
	z4O2HXsQyg = ZXFs0mEPR8qI2zj.findall('label-success mrg-btm-5 ">(.*?)<',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	if z4O2HXsQyg and GBC7yanr9WNYIKXSHRxgP(ll6f2wvU4FdqL3MJyDxORESCK197i,url,z4O2HXsQyg): return
	aaIn3XlQKJ6zSfkmjuCyM = ''
	lQHXdV9Nzf6BLqS8D = ZXFs0mEPR8qI2zj.findall('var url = "(.*?)"',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	if lQHXdV9Nzf6BLqS8D: lQHXdV9Nzf6BLqS8D = lQHXdV9Nzf6BLqS8D[0]
	else: lQHXdV9Nzf6BLqS8D = url.replace('/vidpage_','/Play/')
	if 'http' not in lQHXdV9Nzf6BLqS8D: lQHXdV9Nzf6BLqS8D = JJTrn6SEtYZV31eyR97+lQHXdV9Nzf6BLqS8D
	lQHXdV9Nzf6BLqS8D = lQHXdV9Nzf6BLqS8D.strip('-')
	wpFmEA3z8JR = A6F71g3cqN4(dALVaOWB4jKN3Tbt0Cm1ns9k5u,'GET',lQHXdV9Nzf6BLqS8D,'','','','','BOKRA-PLAY-2nd')
	XgMyLUkfvP4uKVpQsY8RiWZz6N50O = wpFmEA3z8JR.content
	aaIn3XlQKJ6zSfkmjuCyM = ZXFs0mEPR8qI2zj.findall('src="(.*?)"',XgMyLUkfvP4uKVpQsY8RiWZz6N50O,ZXFs0mEPR8qI2zj.DOTALL)
	if aaIn3XlQKJ6zSfkmjuCyM:
		aaIn3XlQKJ6zSfkmjuCyM = aaIn3XlQKJ6zSfkmjuCyM[-1]
		if 'http' not in aaIn3XlQKJ6zSfkmjuCyM: aaIn3XlQKJ6zSfkmjuCyM = 'http:'+aaIn3XlQKJ6zSfkmjuCyM
		if '/PLAY/' not in lQHXdV9Nzf6BLqS8D:
			if 'embed.min.js' in aaIn3XlQKJ6zSfkmjuCyM:
				NgDX7Ppith3O9TB5dluG04 = ZXFs0mEPR8qI2zj.findall('data-publisher-id="(.*?)" data-video-id="(.*?)"',XgMyLUkfvP4uKVpQsY8RiWZz6N50O,ZXFs0mEPR8qI2zj.DOTALL)
				if NgDX7Ppith3O9TB5dluG04:
					gltjLKBXnoYpw8xd3cuINDrfM, DefwVzIiaBKt81gUl0ZdPOkLQu = NgDX7Ppith3O9TB5dluG04[0]
					aaIn3XlQKJ6zSfkmjuCyM = d78KRnJmBWscGua0XMk(aaIn3XlQKJ6zSfkmjuCyM,'url')+'/v2/'+gltjLKBXnoYpw8xd3cuINDrfM+'/config/'+DefwVzIiaBKt81gUl0ZdPOkLQu+'.json'
		import fnxsZbk2Fm
		fnxsZbk2Fm.n2h4SBIzxbgJD3K7rtVej01EuGcHPs([aaIn3XlQKJ6zSfkmjuCyM],ll6f2wvU4FdqL3MJyDxORESCK197i,'video',url)
	return
def F6OgHwYPRiX10tJEv8r(search):
	search,Y9RKmgsxBefkFcuIj2GULDHy3,showDialogs = XDzpr8RxgZhT(search)
	if search=='': search = CjyEnpfQ23o0PYwDtLId()
	if search=='': return
	search = search.replace(' ','+')
	url = JJTrn6SEtYZV31eyR97+'/Search/'+search
	RxAy5lEFQ1chv0BrdU4p6Pt2(url)
	return