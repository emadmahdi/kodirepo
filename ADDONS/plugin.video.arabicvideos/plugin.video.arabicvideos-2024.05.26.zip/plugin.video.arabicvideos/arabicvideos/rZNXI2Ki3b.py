# -*- coding: utf-8 -*-
from j3x780FpaM import *
ll6f2wvU4FdqL3MJyDxORESCK197i = 'LODYNET'
W74fAyGxODoLPs5vMX2l8C93R = '_LDN_'
JJTrn6SEtYZV31eyR97 = uReHcEzxkTm6pN4Q[ll6f2wvU4FdqL3MJyDxORESCK197i][0]
SmgoEYJ7uyL = ['الرئيسية','استفسارتكم و الطلبات']
def OVQIAezo6U1NSTl4L(mode,url,text):
	if   mode==450: HkKfQCS7RIa4xi3houjvl = oMUN5hPpTkxVZG12Qiva8BKnyw6()
	elif mode==451: HkKfQCS7RIa4xi3houjvl = RxAy5lEFQ1chv0BrdU4p6Pt2(url,text)
	elif mode==452: HkKfQCS7RIa4xi3houjvl = jXYwiO9D056pkrzRh1y8tfWJxQoaI3(url)
	elif mode==453: HkKfQCS7RIa4xi3houjvl = ix3SPh5KmdgfFrtHRk4QqwInAlC8(url)
	elif mode==454: HkKfQCS7RIa4xi3houjvl = pqx0gStI9ojGFP2rWhwRfkVCNX(url)
	elif mode==459: HkKfQCS7RIa4xi3houjvl = F6OgHwYPRiX10tJEv8r(text)
	else: HkKfQCS7RIa4xi3houjvl = False
	return HkKfQCS7RIa4xi3houjvl
def oMUN5hPpTkxVZG12Qiva8BKnyw6():
	wpFmEA3z8JR = A6F71g3cqN4(Z7uFdWIRv9ybj0,'GET',JJTrn6SEtYZV31eyR97,'','','','','LODYNET-MENU-1st')
	QstumvzTIEUMXCcx06aD4y8nSqH = wpFmEA3z8JR.content
	pp5vX2CWHBtwOPzdq0Junij7 = d78KRnJmBWscGua0XMk(JJTrn6SEtYZV31eyR97,'url')
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+'بحث في الموقع','',459,'','','_REMEMBERRESULTS_')
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder',ll6f2wvU4FdqL3MJyDxORESCK197i+'_SCRIPT_'+W74fAyGxODoLPs5vMX2l8C93R+'مثبتات لودي نت',pp5vX2CWHBtwOPzdq0Junij7,451,'','','featured')
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder',ll6f2wvU4FdqL3MJyDxORESCK197i+'_SCRIPT_'+W74fAyGxODoLPs5vMX2l8C93R+'المضاف حديثا',pp5vX2CWHBtwOPzdq0Junij7,451,'','','latest')
	Tca7NsYPkIRWtBpFgxLZbSmCi('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('"MainMenu"(.*?)"SiteSlider"',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	if IZGcQbePXxwAoyYR1n:
		bdq4e6Wr2gslnSiA38 = IZGcQbePXxwAoyYR1n[0]
		items = ZXFs0mEPR8qI2zj.findall('href="(.*?)">(.*?)<',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
		for RRucmYBaXegTtNOdGHMQ,title in items:
			if RRucmYBaXegTtNOdGHMQ=='#': continue
			if title in SmgoEYJ7uyL: continue
			Tca7NsYPkIRWtBpFgxLZbSmCi('folder',ll6f2wvU4FdqL3MJyDxORESCK197i+'_SCRIPT_'+W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,451)
	return
def RxAy5lEFQ1chv0BrdU4p6Pt2(url,qzTpS3aBcFGiM=''):
	items = []
	wpFmEA3z8JR = A6F71g3cqN4(Z7uFdWIRv9ybj0,'GET',url,'','','','','LODYNET-TITLES-1st')
	QstumvzTIEUMXCcx06aD4y8nSqH = wpFmEA3z8JR.content
	if qzTpS3aBcFGiM=='featured':
		IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('"SiteSlider"(.*?)"waves"',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
		bdq4e6Wr2gslnSiA38 = IZGcQbePXxwAoyYR1n[0]
	elif qzTpS3aBcFGiM=='latest':
		IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('"RecentPosts"(.*?)"pagination"',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
		bdq4e6Wr2gslnSiA38 = IZGcQbePXxwAoyYR1n[0]
	elif '"ActorsList"' in QstumvzTIEUMXCcx06aD4y8nSqH:
		IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('"ActorsList"(.*?)"text/javascript"',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
		bdq4e6Wr2gslnSiA38 = IZGcQbePXxwAoyYR1n[0]
		items = ZXFs0mEPR8qI2zj.findall('href="(.*?)"(.*?)"ActorName">(.*?)<',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
	elif qzTpS3aBcFGiM in ['0','1','2']:
		IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('"Section"(.*?)</li></ul>',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
		bdq4e6Wr2gslnSiA38 = IZGcQbePXxwAoyYR1n[int(qzTpS3aBcFGiM)]
	else:
		IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('"BlocksArea"(.*?)"text/javascript"',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
		bdq4e6Wr2gslnSiA38 = IZGcQbePXxwAoyYR1n[0]
	if not items: items = ZXFs0mEPR8qI2zj.findall('href="(.*?)".*?src="(.*?)".*?<h2>(.*?)</h2>',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
	FF1TYf6O5KENr8R72LUVievClmudxD = []
	QK2N8Bn0lLVdsURIgufJ = ['مشاهدة','فيلم','اغنية','أغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم']
	for RRucmYBaXegTtNOdGHMQ,CrGO63LT7j2UxniW,title in items:
		if '"ActorsList"' in QstumvzTIEUMXCcx06aD4y8nSqH and 'src=' in CrGO63LT7j2UxniW:
			CrGO63LT7j2UxniW = ZXFs0mEPR8qI2zj.findall('src="(.*?)"',CrGO63LT7j2UxniW,ZXFs0mEPR8qI2zj.DOTALL)
			CrGO63LT7j2UxniW = CrGO63LT7j2UxniW[0]
		RRucmYBaXegTtNOdGHMQ = ejBOu2WXwvb4YpITdsLF16(RRucmYBaXegTtNOdGHMQ).strip('/')
		LqYKJ36CBG = ZXFs0mEPR8qI2zj.findall('(.*?) حلقة \d+',title,ZXFs0mEPR8qI2zj.DOTALL)
		if not LqYKJ36CBG: LqYKJ36CBG = ZXFs0mEPR8qI2zj.findall('(.*?) الحلقة \d+',title,ZXFs0mEPR8qI2zj.DOTALL)
		if set(title.split()) & set(QK2N8Bn0lLVdsURIgufJ) and 'مسلسل' not in title:
			Tca7NsYPkIRWtBpFgxLZbSmCi('video',W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,452,CrGO63LT7j2UxniW)
		elif LqYKJ36CBG and 'حلقة' in title:
			title = '_MOD_' + LqYKJ36CBG[0]
			if title not in FF1TYf6O5KENr8R72LUVievClmudxD:
				Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,453,CrGO63LT7j2UxniW)
				FF1TYf6O5KENr8R72LUVievClmudxD.append(title)
		else: Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,453,CrGO63LT7j2UxniW)
	if qzTpS3aBcFGiM in ['','latest']:
		IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('"pagination"(.*?)</ul>',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
		if IZGcQbePXxwAoyYR1n:
			bdq4e6Wr2gslnSiA38 = IZGcQbePXxwAoyYR1n[0]
			items = ZXFs0mEPR8qI2zj.findall('href="(.*?)".*?>(.*?)<',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
			for RRucmYBaXegTtNOdGHMQ,title in items:
				title = qpob7TvxHSs4fEzO6(title)
				Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+'صفحة '+title,RRucmYBaXegTtNOdGHMQ,451)
	return
def ix3SPh5KmdgfFrtHRk4QqwInAlC8(url):
	wpFmEA3z8JR = A6F71g3cqN4(Z7uFdWIRv9ybj0,'GET',url,'','','','','LODYNET-SEASONS-1st')
	QstumvzTIEUMXCcx06aD4y8nSqH = wpFmEA3z8JR.content
	Wgapb9wyGrVHo0 = ZXFs0mEPR8qI2zj.findall('"CategorySubLinks"(.*?)</div>',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	if Wgapb9wyGrVHo0 and 'href=' in str(Wgapb9wyGrVHo0):
		title = ZXFs0mEPR8qI2zj.findall('<title>(.*?)-',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
		title = title[0].strip(' ')
		Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+title,url,454)
		bdq4e6Wr2gslnSiA38 = Wgapb9wyGrVHo0[0]
		items = ZXFs0mEPR8qI2zj.findall('href="(.*?)">(.*?)<',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
		for RRucmYBaXegTtNOdGHMQ,title in items:
			Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,454)
	else: pqx0gStI9ojGFP2rWhwRfkVCNX(url)
	return
def pqx0gStI9ojGFP2rWhwRfkVCNX(url):
	wpFmEA3z8JR = A6F71g3cqN4(Z7uFdWIRv9ybj0,'GET',url,'','','','','LODYNET-EPISODES-1st')
	QstumvzTIEUMXCcx06aD4y8nSqH = wpFmEA3z8JR.content
	CCqaV18lM0OL = ZXFs0mEPR8qI2zj.findall('"BlocksArea"(.*?)"text/javascript"',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	if CCqaV18lM0OL:
		bdq4e6Wr2gslnSiA38 = CCqaV18lM0OL[0]
		items = ZXFs0mEPR8qI2zj.findall('href="(.*?)".*?src="(.*?)".*?<h2>(.*?)</h2>',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
		for RRucmYBaXegTtNOdGHMQ,CrGO63LT7j2UxniW,title in items:
			Tca7NsYPkIRWtBpFgxLZbSmCi('video',W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,452,CrGO63LT7j2UxniW)
		IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('"pagination"(.*?)</ul>',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
		if IZGcQbePXxwAoyYR1n:
			bdq4e6Wr2gslnSiA38 = IZGcQbePXxwAoyYR1n[0]
			items = ZXFs0mEPR8qI2zj.findall('href="(.*?)".*?>(.*?)<',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
			for RRucmYBaXegTtNOdGHMQ,title in items:
				title = qpob7TvxHSs4fEzO6(title)
				Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+'صفحة '+title,RRucmYBaXegTtNOdGHMQ,454)
	return
def jXYwiO9D056pkrzRh1y8tfWJxQoaI3(url):
	lQHXdV9Nzf6BLqS8D = url.replace('/movies/','/watch_movies/')
	lQHXdV9Nzf6BLqS8D = lQHXdV9Nzf6BLqS8D.replace('/episodes/','/watch_episodes/')
	wpFmEA3z8JR = A6F71g3cqN4(Z7uFdWIRv9ybj0,'GET',lQHXdV9Nzf6BLqS8D,'','','','','LODYNET-PLAY-1st')
	QstumvzTIEUMXCcx06aD4y8nSqH = wpFmEA3z8JR.content
	pp5vX2CWHBtwOPzdq0Junij7 = d78KRnJmBWscGua0XMk(lQHXdV9Nzf6BLqS8D,'url')
	YYmyQXglbEewzL3IA2Sd = []
	IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('"WatchTitle"(.*?)</aside>',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	if IZGcQbePXxwAoyYR1n:
		bdq4e6Wr2gslnSiA38 = IZGcQbePXxwAoyYR1n[0]
		items = ZXFs0mEPR8qI2zj.findall('data-embed="(.*?)">(.*?)</li>',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
		for RRucmYBaXegTtNOdGHMQ,title in items:
			RRucmYBaXegTtNOdGHMQ = RRucmYBaXegTtNOdGHMQ+'?named='+title+'__watch'
			YYmyQXglbEewzL3IA2Sd.append(RRucmYBaXegTtNOdGHMQ)
	IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('"DownloadLinks"(.*?)"selary"',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	if IZGcQbePXxwAoyYR1n:
		bdq4e6Wr2gslnSiA38 = IZGcQbePXxwAoyYR1n[0]
		items = ZXFs0mEPR8qI2zj.findall('href="(.*?)".*?<span>(.*?)</span>',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
		for RRucmYBaXegTtNOdGHMQ,name in items:
			name = qpob7TvxHSs4fEzO6(name)
			PHUqTNVJ0ErRSwibn5gD = ZXFs0mEPR8qI2zj.findall('\d\d\d+',name,ZXFs0mEPR8qI2zj.DOTALL)
			if PHUqTNVJ0ErRSwibn5gD:
				PHUqTNVJ0ErRSwibn5gD = '____'+PHUqTNVJ0ErRSwibn5gD[0]
				name = ''
			else: PHUqTNVJ0ErRSwibn5gD = ''
			RRucmYBaXegTtNOdGHMQ = RRucmYBaXegTtNOdGHMQ+'?named='+name+'__download'+PHUqTNVJ0ErRSwibn5gD
			YYmyQXglbEewzL3IA2Sd.append(RRucmYBaXegTtNOdGHMQ)
	import fnxsZbk2Fm
	fnxsZbk2Fm.n2h4SBIzxbgJD3K7rtVej01EuGcHPs(YYmyQXglbEewzL3IA2Sd,ll6f2wvU4FdqL3MJyDxORESCK197i,'video',url)
	return
def F6OgHwYPRiX10tJEv8r(search):
	search,Y9RKmgsxBefkFcuIj2GULDHy3,showDialogs = XDzpr8RxgZhT(search)
	if search=='': search = CjyEnpfQ23o0PYwDtLId()
	if search=='': return
	search = search.replace(' ','+')
	url = JJTrn6SEtYZV31eyR97+'/search/'+search
	RxAy5lEFQ1chv0BrdU4p6Pt2(url)
	return