# -*- coding: utf-8 -*-
from j3x780FpaM import *
ll6f2wvU4FdqL3MJyDxORESCK197i = 'MYCIMA'
headers = {'User-Agent':''}
W74fAyGxODoLPs5vMX2l8C93R = '_MCM_'
JJTrn6SEtYZV31eyR97 = uReHcEzxkTm6pN4Q[ll6f2wvU4FdqL3MJyDxORESCK197i][0]
SmgoEYJ7uyL = ['مصارعة حرة','wwe']
def OVQIAezo6U1NSTl4L(mode,url,text):
	if   mode==360: HkKfQCS7RIa4xi3houjvl = oMUN5hPpTkxVZG12Qiva8BKnyw6()
	elif mode==361: HkKfQCS7RIa4xi3houjvl = RxAy5lEFQ1chv0BrdU4p6Pt2(url,text)
	elif mode==362: HkKfQCS7RIa4xi3houjvl = jXYwiO9D056pkrzRh1y8tfWJxQoaI3(url)
	elif mode==363: HkKfQCS7RIa4xi3houjvl = pqx0gStI9ojGFP2rWhwRfkVCNX(url,text)
	elif mode==364: HkKfQCS7RIa4xi3houjvl = nvzlr8m5JEsbaqKd6YTuHCIfX9kLR(url,'CATEGORIES___'+text)
	elif mode==365: HkKfQCS7RIa4xi3houjvl = nvzlr8m5JEsbaqKd6YTuHCIfX9kLR(url,'FILTERS___'+text)
	elif mode==366: HkKfQCS7RIa4xi3houjvl = yPzYJU5Wup8(url)
	elif mode==369: HkKfQCS7RIa4xi3houjvl = F6OgHwYPRiX10tJEv8r(text,url)
	else: HkKfQCS7RIa4xi3houjvl = False
	return HkKfQCS7RIa4xi3houjvl
def oMUN5hPpTkxVZG12Qiva8BKnyw6():
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+'بحث في الموقع',JJTrn6SEtYZV31eyR97,369,'','','_REMEMBERRESULTS_')
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+'فلتر محدد',JJTrn6SEtYZV31eyR97+'/AjaxCenter/RightBar',364)
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+'فلتر كامل',JJTrn6SEtYZV31eyR97+'/AjaxCenter/RightBar',365)
	Tca7NsYPkIRWtBpFgxLZbSmCi('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	wpFmEA3z8JR = A6F71g3cqN4(JNsoWV1CXc4xy,'GET',JJTrn6SEtYZV31eyR97,'','','','','MYCIMA-MENU-2nd')
	QstumvzTIEUMXCcx06aD4y8nSqH = wpFmEA3z8JR.content
	IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('class="NavigationMenu"(.*?)class="ProductionsListButton"',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	if IZGcQbePXxwAoyYR1n:
		bdq4e6Wr2gslnSiA38 = IZGcQbePXxwAoyYR1n[0]
		items = ZXFs0mEPR8qI2zj.findall('class="menu-item.*?href="(.*?)">(.*?)<',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
		for RRucmYBaXegTtNOdGHMQ,title in items:
			if title=='': continue
			if any(AARNPWHjQU9dEmDI in title.lower() for AARNPWHjQU9dEmDI in SmgoEYJ7uyL): continue
			Tca7NsYPkIRWtBpFgxLZbSmCi('folder',ll6f2wvU4FdqL3MJyDxORESCK197i+'_SCRIPT_'+W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,366)
		Tca7NsYPkIRWtBpFgxLZbSmCi('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('hoverable activable(.*?)hoverable activable',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	if IZGcQbePXxwAoyYR1n:
		bdq4e6Wr2gslnSiA38 = IZGcQbePXxwAoyYR1n[0]
		items = ZXFs0mEPR8qI2zj.findall('href="(.*?)".*?url\((.*?)\).*?span>(.*?)<',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
		for RRucmYBaXegTtNOdGHMQ,CrGO63LT7j2UxniW,title in items:
			Tca7NsYPkIRWtBpFgxLZbSmCi('folder',ll6f2wvU4FdqL3MJyDxORESCK197i+'_SCRIPT_'+W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,366,CrGO63LT7j2UxniW)
	return QstumvzTIEUMXCcx06aD4y8nSqH
def yPzYJU5Wup8(url):
	wpFmEA3z8JR = A6F71g3cqN4(JNsoWV1CXc4xy,'GET',url,'','','','','MYCIMA-SUBMENU-1st')
	QstumvzTIEUMXCcx06aD4y8nSqH = wpFmEA3z8JR.content
	if 'class="Slider--Grid"' in QstumvzTIEUMXCcx06aD4y8nSqH:
		Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+'المميزة',url,361,'','','featured')
	IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('class="list--Tabsui"(.*?)div',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	if IZGcQbePXxwAoyYR1n:
		bdq4e6Wr2gslnSiA38 = IZGcQbePXxwAoyYR1n[0]
		items = ZXFs0mEPR8qI2zj.findall('href="(.*?)".*?i>(.*?)<',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
		for RRucmYBaXegTtNOdGHMQ,title in items:
			Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,361)
	return
def RxAy5lEFQ1chv0BrdU4p6Pt2(roRCK9UjVn5LJfuesZlxywh,type=''):
	if '::' in roRCK9UjVn5LJfuesZlxywh:
		aaIn3XlQKJ6zSfkmjuCyM,url = roRCK9UjVn5LJfuesZlxywh.split('::')
		NGmuWwXdLQ6nMltx39FYECohJ = d78KRnJmBWscGua0XMk(aaIn3XlQKJ6zSfkmjuCyM,'url')
		url = NGmuWwXdLQ6nMltx39FYECohJ+url
	else: url,aaIn3XlQKJ6zSfkmjuCyM = roRCK9UjVn5LJfuesZlxywh,roRCK9UjVn5LJfuesZlxywh
	wpFmEA3z8JR = A6F71g3cqN4(Z7uFdWIRv9ybj0,'GET',url,'','','','','MYCIMA-TITLES-1st')
	QstumvzTIEUMXCcx06aD4y8nSqH = wpFmEA3z8JR.content
	if type=='featured':
		IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('class="Slider--Grid"(.*?)class="list--Tabsui"',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	elif type=='filters':
		IZGcQbePXxwAoyYR1n = [QstumvzTIEUMXCcx06aD4y8nSqH.replace('\\/','/').replace('\\"','"')]
	else:
		IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('class="Grid--MycimaPosts"(.*?)</li></ul></div></div>',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	FF1TYf6O5KENr8R72LUVievClmudxD = []
	if IZGcQbePXxwAoyYR1n:
		bdq4e6Wr2gslnSiA38 = IZGcQbePXxwAoyYR1n[0]
		items = ZXFs0mEPR8qI2zj.findall('GridItem"><a href="(.*?)" title="(.*?)".*?url\((.*?)\)',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
		for RRucmYBaXegTtNOdGHMQ,title,CrGO63LT7j2UxniW in items:
			if any(AARNPWHjQU9dEmDI in title.lower() for AARNPWHjQU9dEmDI in SmgoEYJ7uyL): continue
			CrGO63LT7j2UxniW = WhJe7bGx5XackTwOIZVLC8ut(CrGO63LT7j2UxniW)
			title = qpob7TvxHSs4fEzO6(title)
			title = WhJe7bGx5XackTwOIZVLC8ut(title)
			title = title.replace('مشاهدة ','')
			if '/series/' in RRucmYBaXegTtNOdGHMQ: Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,363,CrGO63LT7j2UxniW)
			elif 'حلقة' in title:
				LqYKJ36CBG = ZXFs0mEPR8qI2zj.findall('(.*?) +حلقة +\d+',title,ZXFs0mEPR8qI2zj.DOTALL)
				if LqYKJ36CBG: title = '_MOD_' + LqYKJ36CBG[0]
				if title not in FF1TYf6O5KENr8R72LUVievClmudxD:
					FF1TYf6O5KENr8R72LUVievClmudxD.append(title)
					Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,363,CrGO63LT7j2UxniW)
			else:
				Tca7NsYPkIRWtBpFgxLZbSmCi('video',W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,362,CrGO63LT7j2UxniW)
		if type=='filters':
			jMD8RBfTGUlQwJCk = ZXFs0mEPR8qI2zj.findall('"more_button_page":(.*?),',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
			if jMD8RBfTGUlQwJCk:
				count = jMD8RBfTGUlQwJCk[0]
				RRucmYBaXegTtNOdGHMQ = url+'/offset/'+count
				Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+'صفحة أخرى',RRucmYBaXegTtNOdGHMQ,361,'','','filters')
		elif type=='':
			IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('class="pagination(.*?)</div>',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
			if IZGcQbePXxwAoyYR1n:
				bdq4e6Wr2gslnSiA38 = IZGcQbePXxwAoyYR1n[0]
				items = ZXFs0mEPR8qI2zj.findall('href="(.*?)">(.*?)<',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
				for RRucmYBaXegTtNOdGHMQ,title in items:
					title = 'صفحة '+qpob7TvxHSs4fEzO6(title)
					Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,361)
	return
def pqx0gStI9ojGFP2rWhwRfkVCNX(url,type=''):
	wpFmEA3z8JR = A6F71g3cqN4(Z7uFdWIRv9ybj0,'GET',url,'','','','','MYCIMA-EPISODES-1st')
	QstumvzTIEUMXCcx06aD4y8nSqH = wpFmEA3z8JR.content
	QstumvzTIEUMXCcx06aD4y8nSqH = ejBOu2WXwvb4YpITdsLF16(QstumvzTIEUMXCcx06aD4y8nSqH)
	name = ZXFs0mEPR8qI2zj.findall('itemprop="item" href=".*?/series/(.*?)"',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	if name: name = name[-1].replace('-',' ').strip('/')
	if 'موسم' in name and type=='':
		name = name.split('موسم')[0]
		name = name.replace('مشاهدة','').strip(' ')
	elif 'حلقة' in name:
		name = name.split('حلقة')[0]
		name = name.replace('مشاهدة','').strip(' ')
	else: name = name
	IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('class="Seasons--Episodes"(.*?)</singlesection',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	if IZGcQbePXxwAoyYR1n:
		bdq4e6Wr2gslnSiA38 = IZGcQbePXxwAoyYR1n[0]
		if type=='':
			items = ZXFs0mEPR8qI2zj.findall('href="(.*?)">(.*?)</a>',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
			for RRucmYBaXegTtNOdGHMQ,title in items:
				if 'class' in title: continue
				if 'episode' in title: continue
				title = name+' - '+title
				Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,363,'','','episodes')
		if len(OWasmQ27g3Dbljpo)==0:
			i9jtofq4JrV = ZXFs0mEPR8qI2zj.findall('class="Episodes--Seasons--Episodes"(.*?)&&',bdq4e6Wr2gslnSiA38+'&&',ZXFs0mEPR8qI2zj.DOTALL)
			if i9jtofq4JrV: bdq4e6Wr2gslnSiA38 = i9jtofq4JrV[0]
			items = ZXFs0mEPR8qI2zj.findall('href="(.*?)".*?<episodeTitle>(.*?)<',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
			for RRucmYBaXegTtNOdGHMQ,title in items:
				title = title.strip(' ')
				title = name+' - '+title
				Tca7NsYPkIRWtBpFgxLZbSmCi('video',W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,362)
	if len(OWasmQ27g3Dbljpo)==0:
		title = ZXFs0mEPR8qI2zj.findall('<title>(.*?)<',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
		if title: title = title[0].replace(' - ماي سيما','').replace('مشاهدة ','')
		else: title = 'ملف التشغيل'
		Tca7NsYPkIRWtBpFgxLZbSmCi('video',W74fAyGxODoLPs5vMX2l8C93R+title,url,362)
	return
def jXYwiO9D056pkrzRh1y8tfWJxQoaI3(url):
	YYmyQXglbEewzL3IA2Sd = []
	wpFmEA3z8JR = A6F71g3cqN4(dALVaOWB4jKN3Tbt0Cm1ns9k5u,'GET',url,'','','','','MYCIMA-PLAY-1st')
	QstumvzTIEUMXCcx06aD4y8nSqH = wpFmEA3z8JR.content
	z4O2HXsQyg = ZXFs0mEPR8qI2zj.findall('<span>التصنيف<.*?<a.*?">(.*?)<.*?">(.*?)<',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	if z4O2HXsQyg:
		z4O2HXsQyg = [z4O2HXsQyg[0][0],z4O2HXsQyg[0][1]]
		if z4O2HXsQyg and GBC7yanr9WNYIKXSHRxgP(ll6f2wvU4FdqL3MJyDxORESCK197i,url,z4O2HXsQyg): return
	IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('class="WatchServersList"(.*?)class="WatchServersEmbed"',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	if IZGcQbePXxwAoyYR1n:
		bdq4e6Wr2gslnSiA38 = IZGcQbePXxwAoyYR1n[0]
		items = ZXFs0mEPR8qI2zj.findall('data-url="(.*?)".*?strong>(.*?)<',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
		for RRucmYBaXegTtNOdGHMQ,name in items:
			if 'http' not in RRucmYBaXegTtNOdGHMQ: RRucmYBaXegTtNOdGHMQ = JJTrn6SEtYZV31eyR97+RRucmYBaXegTtNOdGHMQ
			if name=='سيرفر ماي سيما': name = 'mycima'
			RRucmYBaXegTtNOdGHMQ = RRucmYBaXegTtNOdGHMQ+'?named='+name+'__watch'
			YYmyQXglbEewzL3IA2Sd.append(RRucmYBaXegTtNOdGHMQ)
	IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('class="List--Download(.*?)</div>',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	if IZGcQbePXxwAoyYR1n:
		bdq4e6Wr2gslnSiA38 = IZGcQbePXxwAoyYR1n[0]
		items = ZXFs0mEPR8qI2zj.findall('href="(.*?)".*?</i>(.*?)<',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
		for RRucmYBaXegTtNOdGHMQ,PHUqTNVJ0ErRSwibn5gD in items:
			if 'http' not in RRucmYBaXegTtNOdGHMQ: RRucmYBaXegTtNOdGHMQ = JJTrn6SEtYZV31eyR97+RRucmYBaXegTtNOdGHMQ
			PHUqTNVJ0ErRSwibn5gD = ZXFs0mEPR8qI2zj.findall('\d\d\d+',PHUqTNVJ0ErRSwibn5gD,ZXFs0mEPR8qI2zj.DOTALL)
			if PHUqTNVJ0ErRSwibn5gD: PHUqTNVJ0ErRSwibn5gD = '____'+PHUqTNVJ0ErRSwibn5gD[0]
			else: PHUqTNVJ0ErRSwibn5gD = ''
			RRucmYBaXegTtNOdGHMQ = RRucmYBaXegTtNOdGHMQ+'?named=mycima'+'__download'+PHUqTNVJ0ErRSwibn5gD
			YYmyQXglbEewzL3IA2Sd.append(RRucmYBaXegTtNOdGHMQ)
	import fnxsZbk2Fm
	fnxsZbk2Fm.n2h4SBIzxbgJD3K7rtVej01EuGcHPs(YYmyQXglbEewzL3IA2Sd,ll6f2wvU4FdqL3MJyDxORESCK197i,'video',url)
	return
def F6OgHwYPRiX10tJEv8r(search,C6GzBa2KvmX3PRSypYMIE51cu=''):
	search,Y9RKmgsxBefkFcuIj2GULDHy3,showDialogs = XDzpr8RxgZhT(search)
	if search=='': search = CjyEnpfQ23o0PYwDtLId()
	if search=='': return
	search = search.replace(' ','+')
	YYmyQXglbEewzL3IA2Sd = ['/list','/','/list/series','/list/anime','/list/tv']
	Y4yxdBjU2Tm = ['الكل','الأفلام','المسلسلات','الانيمي و الكرتون','البرامج تليفزيونية']
	if showDialogs:
		jQ6w8xOrgYhSHIRpUqzL = F2yZPukcUh09sqCI8nYw7e('اختر النوع المطلوب:', Y4yxdBjU2Tm)
		if jQ6w8xOrgYhSHIRpUqzL==-1: return
	else: jQ6w8xOrgYhSHIRpUqzL = 0
	if C6GzBa2KvmX3PRSypYMIE51cu=='':
		wpFmEA3z8JR = A6F71g3cqN4(dALVaOWB4jKN3Tbt0Cm1ns9k5u,'GET',JJTrn6SEtYZV31eyR97,'','',False,'','MYCIMA-SEARCH-1st')
		C6GzBa2KvmX3PRSypYMIE51cu = wpFmEA3z8JR.headers['Location']
		C6GzBa2KvmX3PRSypYMIE51cu = C6GzBa2KvmX3PRSypYMIE51cu.strip('/')
	lQHXdV9Nzf6BLqS8D = C6GzBa2KvmX3PRSypYMIE51cu+'/search/'+search+YYmyQXglbEewzL3IA2Sd[jQ6w8xOrgYhSHIRpUqzL]
	RxAy5lEFQ1chv0BrdU4p6Pt2(lQHXdV9Nzf6BLqS8D)
	return
def nvzlr8m5JEsbaqKd6YTuHCIfX9kLR(roRCK9UjVn5LJfuesZlxywh,filter):
	if '??' in roRCK9UjVn5LJfuesZlxywh: url = roRCK9UjVn5LJfuesZlxywh.split('//getposts??')[0]
	else: url = roRCK9UjVn5LJfuesZlxywh
	filter = filter.replace('_FORGETRESULTS_','')
	type,filter = filter.split('___',1)
	if filter=='': SFbYEzoech4wU1,kXR5NJaOcQUd47zugHqCAvjGoLmW = '',''
	else: SFbYEzoech4wU1,kXR5NJaOcQUd47zugHqCAvjGoLmW = filter.split('___')
	if type=='CATEGORIES':
		if g8MUskbACOmpZncvSW5QPr9zyTaJ[0]+'==' not in SFbYEzoech4wU1: p8pgXONsjY = g8MUskbACOmpZncvSW5QPr9zyTaJ[0]
		for xxFhvt275i8MdUVuPkSXzmbT in range(len(g8MUskbACOmpZncvSW5QPr9zyTaJ[0:-1])):
			if g8MUskbACOmpZncvSW5QPr9zyTaJ[xxFhvt275i8MdUVuPkSXzmbT]+'==' in SFbYEzoech4wU1: p8pgXONsjY = g8MUskbACOmpZncvSW5QPr9zyTaJ[xxFhvt275i8MdUVuPkSXzmbT+1]
		vX5qmpr1hSAszGE = SFbYEzoech4wU1+'&&'+p8pgXONsjY+'==0'
		t9NhYxrZKcBf4u = kXR5NJaOcQUd47zugHqCAvjGoLmW+'&&'+p8pgXONsjY+'==0'
		tt6AbxYRgQ3aC4O = vX5qmpr1hSAszGE.strip('&&')+'___'+t9NhYxrZKcBf4u.strip('&&')
		KMUEN9cD1OByji = l0mO1GdhAtb(kXR5NJaOcQUd47zugHqCAvjGoLmW,'modified_filters')
		lQHXdV9Nzf6BLqS8D = url+'//getposts??'+KMUEN9cD1OByji
	elif type=='FILTERS':
		cOM2mQXqbrRyiKasDz = l0mO1GdhAtb(SFbYEzoech4wU1,'modified_values')
		cOM2mQXqbrRyiKasDz = ejBOu2WXwvb4YpITdsLF16(cOM2mQXqbrRyiKasDz)
		if kXR5NJaOcQUd47zugHqCAvjGoLmW!='': kXR5NJaOcQUd47zugHqCAvjGoLmW = l0mO1GdhAtb(kXR5NJaOcQUd47zugHqCAvjGoLmW,'modified_filters')
		if kXR5NJaOcQUd47zugHqCAvjGoLmW=='': lQHXdV9Nzf6BLqS8D = url
		else: lQHXdV9Nzf6BLqS8D = url+'//getposts??'+kXR5NJaOcQUd47zugHqCAvjGoLmW
		pqrfNVvo8H = opOK7W82fQ3HNJeFZkXqzndUCS(lQHXdV9Nzf6BLqS8D,roRCK9UjVn5LJfuesZlxywh)
		Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+'أظهار قائمة الفيديو التي تم اختيارها ',pqrfNVvo8H,361,'','','filters')
		Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+' [[   '+cOM2mQXqbrRyiKasDz+'   ]]',pqrfNVvo8H,361,'','','filters')
		Tca7NsYPkIRWtBpFgxLZbSmCi('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	wpFmEA3z8JR = A6F71g3cqN4(JNsoWV1CXc4xy,'GET',url,'','','','','MYCIMA-FILTERS_MENU-1st')
	QstumvzTIEUMXCcx06aD4y8nSqH = wpFmEA3z8JR.content
	QstumvzTIEUMXCcx06aD4y8nSqH = QstumvzTIEUMXCcx06aD4y8nSqH.replace('\\"','"').replace('\\/','/')
	IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('<mycima--filter(.*?)</mycima--filter>',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	if not IZGcQbePXxwAoyYR1n: return
	bdq4e6Wr2gslnSiA38 = IZGcQbePXxwAoyYR1n[0]
	jNFqoOewYB2mG = ZXFs0mEPR8qI2zj.findall('taxonomy="(.*?)".*?<span>(.*?)<(.*?)<filterbox',bdq4e6Wr2gslnSiA38+'<filterbox',ZXFs0mEPR8qI2zj.DOTALL)
	dict = {}
	for Lm4n6ZMXPrWpo,name,bdq4e6Wr2gslnSiA38 in jNFqoOewYB2mG:
		name = WhJe7bGx5XackTwOIZVLC8ut(name)
		if 'interest' in Lm4n6ZMXPrWpo: continue
		items = ZXFs0mEPR8qI2zj.findall('data-term="(.*?)".*?<txt>(.*?)</txt>',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
		if '==' not in lQHXdV9Nzf6BLqS8D: lQHXdV9Nzf6BLqS8D = url
		if type=='CATEGORIES':
			if p8pgXONsjY!=Lm4n6ZMXPrWpo: continue
			elif len(items)<=1:
				if Lm4n6ZMXPrWpo==g8MUskbACOmpZncvSW5QPr9zyTaJ[-1]: RxAy5lEFQ1chv0BrdU4p6Pt2(lQHXdV9Nzf6BLqS8D)
				else: nvzlr8m5JEsbaqKd6YTuHCIfX9kLR(lQHXdV9Nzf6BLqS8D,'CATEGORIES___'+tt6AbxYRgQ3aC4O)
				return
			else:
				pqrfNVvo8H = opOK7W82fQ3HNJeFZkXqzndUCS(lQHXdV9Nzf6BLqS8D,roRCK9UjVn5LJfuesZlxywh)
				if Lm4n6ZMXPrWpo==g8MUskbACOmpZncvSW5QPr9zyTaJ[-1]:
					Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+'الجميع',pqrfNVvo8H,361,'','','filters')
				else: Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+'الجميع',lQHXdV9Nzf6BLqS8D,364,'','',tt6AbxYRgQ3aC4O)
		elif type=='FILTERS':
			vX5qmpr1hSAszGE = SFbYEzoech4wU1+'&&'+Lm4n6ZMXPrWpo+'==0'
			t9NhYxrZKcBf4u = kXR5NJaOcQUd47zugHqCAvjGoLmW+'&&'+Lm4n6ZMXPrWpo+'==0'
			tt6AbxYRgQ3aC4O = vX5qmpr1hSAszGE+'___'+t9NhYxrZKcBf4u
			Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+name+': الجميع',lQHXdV9Nzf6BLqS8D,365,'','',tt6AbxYRgQ3aC4O+'_FORGETRESULTS_')
		dict[Lm4n6ZMXPrWpo] = {}
		for AARNPWHjQU9dEmDI,Z7ZzgCTMBsNlVi9 in items:
			name = WhJe7bGx5XackTwOIZVLC8ut(name)
			Z7ZzgCTMBsNlVi9 = WhJe7bGx5XackTwOIZVLC8ut(Z7ZzgCTMBsNlVi9)
			if AARNPWHjQU9dEmDI=='r' or AARNPWHjQU9dEmDI=='nc-17': continue
			if any(AARNPWHjQU9dEmDI in Z7ZzgCTMBsNlVi9.lower() for AARNPWHjQU9dEmDI in SmgoEYJ7uyL): continue
			if 'http' in Z7ZzgCTMBsNlVi9: continue
			if 'الكل' in Z7ZzgCTMBsNlVi9: continue
			if 'n-a' in AARNPWHjQU9dEmDI: continue
			if Z7ZzgCTMBsNlVi9=='': Z7ZzgCTMBsNlVi9 = AARNPWHjQU9dEmDI
			QCDVzPGHj6IxMA = Z7ZzgCTMBsNlVi9
			Isp16k7xRZa0lYD5vdmA = ZXFs0mEPR8qI2zj.findall('<name>(.*?)</name>',Z7ZzgCTMBsNlVi9,ZXFs0mEPR8qI2zj.DOTALL)
			if Isp16k7xRZa0lYD5vdmA: QCDVzPGHj6IxMA = Isp16k7xRZa0lYD5vdmA[0]
			Wu4CadwRTJfkbXMUVxO3jQ2 = name+': '+QCDVzPGHj6IxMA
			dict[Lm4n6ZMXPrWpo][AARNPWHjQU9dEmDI] = Wu4CadwRTJfkbXMUVxO3jQ2
			vX5qmpr1hSAszGE = SFbYEzoech4wU1+'&&'+Lm4n6ZMXPrWpo+'=='+QCDVzPGHj6IxMA
			t9NhYxrZKcBf4u = kXR5NJaOcQUd47zugHqCAvjGoLmW+'&&'+Lm4n6ZMXPrWpo+'=='+AARNPWHjQU9dEmDI
			WYXmvw9l3jToq6rui1SCs = vX5qmpr1hSAszGE+'___'+t9NhYxrZKcBf4u
			if type=='FILTERS':
				Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+Wu4CadwRTJfkbXMUVxO3jQ2,url,365,'','',WYXmvw9l3jToq6rui1SCs+'_FORGETRESULTS_')
			elif type=='CATEGORIES' and g8MUskbACOmpZncvSW5QPr9zyTaJ[-2]+'==' in SFbYEzoech4wU1:
				KMUEN9cD1OByji = l0mO1GdhAtb(t9NhYxrZKcBf4u,'modified_filters')
				aaIn3XlQKJ6zSfkmjuCyM = url+'//getposts??'+KMUEN9cD1OByji
				pqrfNVvo8H = opOK7W82fQ3HNJeFZkXqzndUCS(aaIn3XlQKJ6zSfkmjuCyM,roRCK9UjVn5LJfuesZlxywh)
				Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+Wu4CadwRTJfkbXMUVxO3jQ2,pqrfNVvo8H,361,'','','filters')
			else: Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+Wu4CadwRTJfkbXMUVxO3jQ2,url,364,'','',WYXmvw9l3jToq6rui1SCs)
	return
g8MUskbACOmpZncvSW5QPr9zyTaJ = ['genre','release-year','nation']
hU5JTpKRjbCGL2 = ['mpaa','genre','release-year','category','Quality','interest','nation','language']
def opOK7W82fQ3HNJeFZkXqzndUCS(lQHXdV9Nzf6BLqS8D,aaIn3XlQKJ6zSfkmjuCyM):
	if '/AjaxCenter/RightBar' in lQHXdV9Nzf6BLqS8D: lQHXdV9Nzf6BLqS8D = lQHXdV9Nzf6BLqS8D.replace('/AjaxCenter/RightBar','/AjaxCenter/Filtering')
	lQHXdV9Nzf6BLqS8D = lQHXdV9Nzf6BLqS8D.replace('//getposts??','::/AjaxCenter/Filtering/')
	lQHXdV9Nzf6BLqS8D = lQHXdV9Nzf6BLqS8D.replace('==','/')
	lQHXdV9Nzf6BLqS8D = lQHXdV9Nzf6BLqS8D.replace('&&','/')
	return lQHXdV9Nzf6BLqS8D
def l0mO1GdhAtb(zIpQyOG78Nvreijwa,mode):
	zIpQyOG78Nvreijwa = zIpQyOG78Nvreijwa.strip('&&')
	JhV0ZrwmLIcOaHfQDK9qNsEGPzF83p,rXLaWluDjvi4xMwpOSF91JB7 = {},''
	if '==' in zIpQyOG78Nvreijwa:
		items = zIpQyOG78Nvreijwa.split('&&')
		for q8BXZlN9sU1fP2JAxH7W in items:
			cfMR9TgeL2hx6Wnq4liDX,AARNPWHjQU9dEmDI = q8BXZlN9sU1fP2JAxH7W.split('==')
			JhV0ZrwmLIcOaHfQDK9qNsEGPzF83p[cfMR9TgeL2hx6Wnq4liDX] = AARNPWHjQU9dEmDI
	for key in hU5JTpKRjbCGL2:
		if key in list(JhV0ZrwmLIcOaHfQDK9qNsEGPzF83p.keys()): AARNPWHjQU9dEmDI = JhV0ZrwmLIcOaHfQDK9qNsEGPzF83p[key]
		else: AARNPWHjQU9dEmDI = '0'
		if '%' not in AARNPWHjQU9dEmDI: AARNPWHjQU9dEmDI = cD1AgYCl0qZI8(AARNPWHjQU9dEmDI)
		if mode=='modified_values' and AARNPWHjQU9dEmDI!='0': rXLaWluDjvi4xMwpOSF91JB7 = rXLaWluDjvi4xMwpOSF91JB7+' + '+AARNPWHjQU9dEmDI
		elif mode=='modified_filters' and AARNPWHjQU9dEmDI!='0': rXLaWluDjvi4xMwpOSF91JB7 = rXLaWluDjvi4xMwpOSF91JB7+'&&'+key+'=='+AARNPWHjQU9dEmDI
		elif mode=='all': rXLaWluDjvi4xMwpOSF91JB7 = rXLaWluDjvi4xMwpOSF91JB7+'&&'+key+'=='+AARNPWHjQU9dEmDI
	rXLaWluDjvi4xMwpOSF91JB7 = rXLaWluDjvi4xMwpOSF91JB7.strip(' + ')
	rXLaWluDjvi4xMwpOSF91JB7 = rXLaWluDjvi4xMwpOSF91JB7.strip('&&')
	return rXLaWluDjvi4xMwpOSF91JB7