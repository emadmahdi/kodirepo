# -*- coding: utf-8 -*-
from j3x780FpaM import *
headers = { 'User-Agent' : '' }
ll6f2wvU4FdqL3MJyDxORESCK197i = 'AKOAMCAM'
W74fAyGxODoLPs5vMX2l8C93R = '_AKC_'
JJTrn6SEtYZV31eyR97 = uReHcEzxkTm6pN4Q[ll6f2wvU4FdqL3MJyDxORESCK197i][0]
SmgoEYJ7uyL = ['مصارعة']
def OVQIAezo6U1NSTl4L(mode,url,text):
	if   mode==350: HkKfQCS7RIa4xi3houjvl = oMUN5hPpTkxVZG12Qiva8BKnyw6()
	elif mode==351: HkKfQCS7RIa4xi3houjvl = RxAy5lEFQ1chv0BrdU4p6Pt2(url,text)
	elif mode==352: HkKfQCS7RIa4xi3houjvl = pqx0gStI9ojGFP2rWhwRfkVCNX(url)
	elif mode==353: HkKfQCS7RIa4xi3houjvl = jXYwiO9D056pkrzRh1y8tfWJxQoaI3(url)
	elif mode==354: HkKfQCS7RIa4xi3houjvl = nvzlr8m5JEsbaqKd6YTuHCIfX9kLR(url,'FILTERS___'+text)
	elif mode==355: HkKfQCS7RIa4xi3houjvl = nvzlr8m5JEsbaqKd6YTuHCIfX9kLR(url,'CATEGORIES___'+text)
	elif mode==356: HkKfQCS7RIa4xi3houjvl = UUprLCclRFPe53Snu2qZEYGkfj(url)
	elif mode==357: HkKfQCS7RIa4xi3houjvl = jXF0fB4GeQa(url)
	elif mode==359: HkKfQCS7RIa4xi3houjvl = F6OgHwYPRiX10tJEv8r(text)
	else: HkKfQCS7RIa4xi3houjvl = False
	return HkKfQCS7RIa4xi3houjvl
def oMUN5hPpTkxVZG12Qiva8BKnyw6():
	Tca7NsYPkIRWtBpFgxLZbSmCi('link',W74fAyGxODoLPs5vMX2l8C93R+'[COLOR FFFFFF00]هذا الموقع مغلق[/COLOR]','',8)
	Tca7NsYPkIRWtBpFgxLZbSmCi('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+'بحث في الموقع','',359,'','','_REMEMBERRESULTS_')
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+'فلتر محدد',JJTrn6SEtYZV31eyR97,356)
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+'فلتر كامل',JJTrn6SEtYZV31eyR97,357)
	Tca7NsYPkIRWtBpFgxLZbSmCi('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	QstumvzTIEUMXCcx06aD4y8nSqH = QuWA3hsmIvockZDiy2rLg(Z7uFdWIRv9ybj0,JJTrn6SEtYZV31eyR97,'',headers,'','AKOAMCAM-MENU-1st')
	lQHXdV9Nzf6BLqS8D = ZXFs0mEPR8qI2zj.findall('recently-container.*?href="(.*?)"',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	if lQHXdV9Nzf6BLqS8D: lQHXdV9Nzf6BLqS8D = lQHXdV9Nzf6BLqS8D[0]
	else: lQHXdV9Nzf6BLqS8D = JJTrn6SEtYZV31eyR97
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder',ll6f2wvU4FdqL3MJyDxORESCK197i+'_SCRIPT_'+W74fAyGxODoLPs5vMX2l8C93R+'اضيف حديثا',lQHXdV9Nzf6BLqS8D,351)
	lQHXdV9Nzf6BLqS8D = ZXFs0mEPR8qI2zj.findall('@id":"(.*?)"',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	if lQHXdV9Nzf6BLqS8D: lQHXdV9Nzf6BLqS8D = lQHXdV9Nzf6BLqS8D[0]
	else: lQHXdV9Nzf6BLqS8D = JJTrn6SEtYZV31eyR97
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder',ll6f2wvU4FdqL3MJyDxORESCK197i+'_SCRIPT_'+W74fAyGxODoLPs5vMX2l8C93R+'المميزة',lQHXdV9Nzf6BLqS8D,351,'','','featured')
	IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('main-categories-list(.*?)main-categories-list',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	if IZGcQbePXxwAoyYR1n:
		bdq4e6Wr2gslnSiA38 = IZGcQbePXxwAoyYR1n[0]
		items = ZXFs0mEPR8qI2zj.findall('href="(.*?)".*?class="font.*?>(.*?)<',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
		for RRucmYBaXegTtNOdGHMQ,title in items:
			if title not in SmgoEYJ7uyL: Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,351)
		Tca7NsYPkIRWtBpFgxLZbSmCi('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('class="categories-box(.*?)<footer',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	if IZGcQbePXxwAoyYR1n:
		bdq4e6Wr2gslnSiA38 = IZGcQbePXxwAoyYR1n[0]
		items = ZXFs0mEPR8qI2zj.findall('href="(.*?)".*?">(.*?)<',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
		for RRucmYBaXegTtNOdGHMQ,title in items:
			RRucmYBaXegTtNOdGHMQ = qpob7TvxHSs4fEzO6(RRucmYBaXegTtNOdGHMQ)
			if title not in SmgoEYJ7uyL: Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,351)
	return QstumvzTIEUMXCcx06aD4y8nSqH
def UUprLCclRFPe53Snu2qZEYGkfj(website=''):
	QstumvzTIEUMXCcx06aD4y8nSqH = QuWA3hsmIvockZDiy2rLg(JNsoWV1CXc4xy,JJTrn6SEtYZV31eyR97,'',headers,'','AKOAMCAM-MENU-1st')
	IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('class="menu(.*?)<nav',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	if IZGcQbePXxwAoyYR1n:
		bdq4e6Wr2gslnSiA38 = IZGcQbePXxwAoyYR1n[0]
		items = ZXFs0mEPR8qI2zj.findall('href="(.*?)".*?text">(.*?)<',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
		for RRucmYBaXegTtNOdGHMQ,title in items:
			if title not in SmgoEYJ7uyL:
				title = title+' مصنفة'
				Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,355)
		if website=='': Tca7NsYPkIRWtBpFgxLZbSmCi('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	return QstumvzTIEUMXCcx06aD4y8nSqH
def jXF0fB4GeQa(website=''):
	QstumvzTIEUMXCcx06aD4y8nSqH = QuWA3hsmIvockZDiy2rLg(JNsoWV1CXc4xy,JJTrn6SEtYZV31eyR97,'',headers,'','AKOAMCAM-MENU-1st')
	IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('class="menu(.*?)<nav',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	if IZGcQbePXxwAoyYR1n:
		bdq4e6Wr2gslnSiA38 = IZGcQbePXxwAoyYR1n[0]
		items = ZXFs0mEPR8qI2zj.findall('href="(.*?)".*?text">(.*?)<',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
		for RRucmYBaXegTtNOdGHMQ,title in items:
			if title not in SmgoEYJ7uyL:
				title = title+' مفلترة'
				Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,354)
		if website=='': Tca7NsYPkIRWtBpFgxLZbSmCi('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	return QstumvzTIEUMXCcx06aD4y8nSqH
def RxAy5lEFQ1chv0BrdU4p6Pt2(url,type=''):
	QstumvzTIEUMXCcx06aD4y8nSqH = QuWA3hsmIvockZDiy2rLg(KxirmCLT6Gw,url,'',headers,True,'AKOAMCAM-TITLES-1st')
	if type=='featured': IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('swiper-container(.*?)swiper-button-prev',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	else: IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('class="container"(.*?)main-footer',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	if IZGcQbePXxwAoyYR1n:
		bdq4e6Wr2gslnSiA38 = IZGcQbePXxwAoyYR1n[0]
		items = ZXFs0mEPR8qI2zj.findall('xlink:href="(.*?)".*?href="(.*?)".*?text-white">(.*?)<',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
		FF1TYf6O5KENr8R72LUVievClmudxD = []
		for CrGO63LT7j2UxniW,RRucmYBaXegTtNOdGHMQ,title in items:
			title = qpob7TvxHSs4fEzO6(title)
			if 'الحلقة' in title or 'الحلقه' in title:
				LqYKJ36CBG = ZXFs0mEPR8qI2zj.findall('(.*?) (الحلقة|الحلقه) \d+',title,ZXFs0mEPR8qI2zj.DOTALL)
				if LqYKJ36CBG:
					title = '_MOD_' + LqYKJ36CBG[0][0]
					if title not in FF1TYf6O5KENr8R72LUVievClmudxD:
						Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,352,CrGO63LT7j2UxniW)
						FF1TYf6O5KENr8R72LUVievClmudxD.append(title)
			elif 'مسلسل' in title:
				Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,352,CrGO63LT7j2UxniW)
			else: Tca7NsYPkIRWtBpFgxLZbSmCi('video',W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,353,CrGO63LT7j2UxniW)
	IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('pagination(.*?)</div>',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	if IZGcQbePXxwAoyYR1n:
		bdq4e6Wr2gslnSiA38 = IZGcQbePXxwAoyYR1n[0]
		items = ZXFs0mEPR8qI2zj.findall('href=["\'](.*?)["\'].*?>(.*?)<',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
		for RRucmYBaXegTtNOdGHMQ,title in items:
			RRucmYBaXegTtNOdGHMQ = qpob7TvxHSs4fEzO6(RRucmYBaXegTtNOdGHMQ)
			title = qpob7TvxHSs4fEzO6(title)
			Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+'صفحة '+title,RRucmYBaXegTtNOdGHMQ,351)
	return
def F6OgHwYPRiX10tJEv8r(search):
	search,Y9RKmgsxBefkFcuIj2GULDHy3,showDialogs = XDzpr8RxgZhT(search)
	if search=='': search = CjyEnpfQ23o0PYwDtLId()
	if search=='': return
	H9IMP4eTVW8dji3EXnS7w = search.replace(' ','+')
	url = JJTrn6SEtYZV31eyR97 + '/?s='+H9IMP4eTVW8dji3EXnS7w
	HkKfQCS7RIa4xi3houjvl = RxAy5lEFQ1chv0BrdU4p6Pt2(url)
	return
def pqx0gStI9ojGFP2rWhwRfkVCNX(url):
	QstumvzTIEUMXCcx06aD4y8nSqH = QuWA3hsmIvockZDiy2rLg(Z7uFdWIRv9ybj0,url,'',headers,True,'AKOAMCAM-EPISODES-1st')
	IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('text-white">الحلقات(.*?)<header',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	if IZGcQbePXxwAoyYR1n:
		bdq4e6Wr2gslnSiA38 = IZGcQbePXxwAoyYR1n[0]
		xvWJR3VCAcyLZ = ZXFs0mEPR8qI2zj.findall('href="(http.*?)".*?src="(.*?)".*?alt="(.*?)"',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
		for RRucmYBaXegTtNOdGHMQ,CrGO63LT7j2UxniW,title in xvWJR3VCAcyLZ:
			if 'الحلقة' in title or 'الحلقه' in title: Tca7NsYPkIRWtBpFgxLZbSmCi('video',W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,353,CrGO63LT7j2UxniW)
	else:
		CrGO63LT7j2UxniW = cPwDBuG4HVTCdQ9JmMeoWjNY2hX.getInfoLabel('ListItem.Icon')
		if QstumvzTIEUMXCcx06aD4y8nSqH.count('<title>')>1: title = ZXFs0mEPR8qI2zj.findall('<title>(.*?)<',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)[1]
		else: title = 'رابط التشغيل'
		Tca7NsYPkIRWtBpFgxLZbSmCi('video',W74fAyGxODoLPs5vMX2l8C93R+title,url,353,CrGO63LT7j2UxniW)
	return
def jXYwiO9D056pkrzRh1y8tfWJxQoaI3(url):
	YYmyQXglbEewzL3IA2Sd,xCLQK8kh39sjyi5DXSZAVeI = [],[]
	VmzXiGxpC91s7QgAykIHl0 = A6F71g3cqN4(JNsoWV1CXc4xy,'GET',url,'','','','','AKOAMCAM-PLAY-1st')
	QstumvzTIEUMXCcx06aD4y8nSqH = VmzXiGxpC91s7QgAykIHl0.content
	mnt96JHiPpI = ZXFs0mEPR8qI2zj.findall('post_id=(.*?)"',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	if mnt96JHiPpI:
		mnt96JHiPpI = mnt96JHiPpI[0]
		headers = {'User-Agent':'','Content-Type':'application/x-www-form-urlencoded'}
		data = {'post_id':mnt96JHiPpI}
		lQHXdV9Nzf6BLqS8D = JJTrn6SEtYZV31eyR97+'/wp-content/themes/aflam8kkk/Inc/Ajax/Single/Watch.php'
		zgYJmb376OZay4VEwNRuFrqv0kCs = A6F71g3cqN4(JNsoWV1CXc4xy,'POST',lQHXdV9Nzf6BLqS8D,data,headers,'','','AKOAMCAM-PLAY-1st')
		XgMyLUkfvP4uKVpQsY8RiWZz6N50O = zgYJmb376OZay4VEwNRuFrqv0kCs.content
		items = ZXFs0mEPR8qI2zj.findall('data-server="(.*?)".*?class="text">(.*?)<',XgMyLUkfvP4uKVpQsY8RiWZz6N50O,ZXFs0mEPR8qI2zj.DOTALL)
		for uu2AypHEw6lW,name in items:
			RRucmYBaXegTtNOdGHMQ = 'https://w.akoam.cam/wp-content/themes/aflam8kkk/Inc/Ajax/Single/Server.php'
			RRucmYBaXegTtNOdGHMQ = RRucmYBaXegTtNOdGHMQ+'?postid='+mnt96JHiPpI+'&serverid='+uu2AypHEw6lW+'?named='+name+'__watch'
			YYmyQXglbEewzL3IA2Sd.append(RRucmYBaXegTtNOdGHMQ)
			xCLQK8kh39sjyi5DXSZAVeI.append(name)
		lQHXdV9Nzf6BLqS8D = JJTrn6SEtYZV31eyR97+'/wp-content/themes/aflam8kkk/Inc/Ajax/Single/Download.php'
		zgYJmb376OZay4VEwNRuFrqv0kCs = A6F71g3cqN4(JNsoWV1CXc4xy,'POST',lQHXdV9Nzf6BLqS8D,data,headers,'','','AKOAMCAM-PLAY-1st')
		XgMyLUkfvP4uKVpQsY8RiWZz6N50O = zgYJmb376OZay4VEwNRuFrqv0kCs.content
		items = ZXFs0mEPR8qI2zj.findall('href="(.*?)".*?class="text">(.*?)<',XgMyLUkfvP4uKVpQsY8RiWZz6N50O,ZXFs0mEPR8qI2zj.DOTALL)
		for RRucmYBaXegTtNOdGHMQ,title in items:
			RRucmYBaXegTtNOdGHMQ = RRucmYBaXegTtNOdGHMQ.strip(' ')
			RRucmYBaXegTtNOdGHMQ = RRucmYBaXegTtNOdGHMQ+'?named='+title+'__download'
			YYmyQXglbEewzL3IA2Sd.append(RRucmYBaXegTtNOdGHMQ)
			xCLQK8kh39sjyi5DXSZAVeI.append(title)
	import fnxsZbk2Fm
	fnxsZbk2Fm.n2h4SBIzxbgJD3K7rtVej01EuGcHPs(YYmyQXglbEewzL3IA2Sd,ll6f2wvU4FdqL3MJyDxORESCK197i,'video',url)
	return
def nvzlr8m5JEsbaqKd6YTuHCIfX9kLR(url,filter):
	E0tDmCreab3BWYTcdIupkU46v = ['cat','genre','release-year','quality','orderby']
	if '?' in url: url = url.split('?')[0]
	type,filter = filter.split('___',1)
	if filter=='': SFbYEzoech4wU1,kXR5NJaOcQUd47zugHqCAvjGoLmW = '',''
	else: SFbYEzoech4wU1,kXR5NJaOcQUd47zugHqCAvjGoLmW = filter.split('___')
	if type=='CATEGORIES':
		if E0tDmCreab3BWYTcdIupkU46v[0]+'=' not in SFbYEzoech4wU1: p8pgXONsjY = E0tDmCreab3BWYTcdIupkU46v[0]
		for xxFhvt275i8MdUVuPkSXzmbT in range(len(E0tDmCreab3BWYTcdIupkU46v[0:-1])):
			if E0tDmCreab3BWYTcdIupkU46v[xxFhvt275i8MdUVuPkSXzmbT]+'=' in SFbYEzoech4wU1: p8pgXONsjY = E0tDmCreab3BWYTcdIupkU46v[xxFhvt275i8MdUVuPkSXzmbT+1]
		vX5qmpr1hSAszGE = SFbYEzoech4wU1+'&'+p8pgXONsjY+'=0'
		t9NhYxrZKcBf4u = kXR5NJaOcQUd47zugHqCAvjGoLmW+'&'+p8pgXONsjY+'=0'
		tt6AbxYRgQ3aC4O = vX5qmpr1hSAszGE.strip('&')+'___'+t9NhYxrZKcBf4u.strip('&')
		KMUEN9cD1OByji = l0mO1GdhAtb(kXR5NJaOcQUd47zugHqCAvjGoLmW,'all')
		lQHXdV9Nzf6BLqS8D = url+'?'+KMUEN9cD1OByji
	elif type=='FILTERS':
		cOM2mQXqbrRyiKasDz = l0mO1GdhAtb(SFbYEzoech4wU1,'modified_values')
		cOM2mQXqbrRyiKasDz = ejBOu2WXwvb4YpITdsLF16(cOM2mQXqbrRyiKasDz)
		if kXR5NJaOcQUd47zugHqCAvjGoLmW!='': kXR5NJaOcQUd47zugHqCAvjGoLmW = l0mO1GdhAtb(kXR5NJaOcQUd47zugHqCAvjGoLmW,'all')
		if kXR5NJaOcQUd47zugHqCAvjGoLmW=='': lQHXdV9Nzf6BLqS8D = url
		else: lQHXdV9Nzf6BLqS8D = url+'?'+kXR5NJaOcQUd47zugHqCAvjGoLmW
		Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+'أظهار قائمة الفيديو التي تم اختيارها',lQHXdV9Nzf6BLqS8D,351,'','1')
		Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+' [[   '+cOM2mQXqbrRyiKasDz+'   ]]',lQHXdV9Nzf6BLqS8D,351,'','1')
		Tca7NsYPkIRWtBpFgxLZbSmCi('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	QstumvzTIEUMXCcx06aD4y8nSqH = QuWA3hsmIvockZDiy2rLg(JNsoWV1CXc4xy,url,'',headers,True,'AKOAMCAM-FILTERS_MENU-1st')
	IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('<form id(.*?)</form>',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	bdq4e6Wr2gslnSiA38 = IZGcQbePXxwAoyYR1n[0]
	jNFqoOewYB2mG = ZXFs0mEPR8qI2zj.findall('<select.*?name="(.*?)".*?">(.*?)<(.*?)</select>',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
	dict = {}
	for Lm4n6ZMXPrWpo,name,bdq4e6Wr2gslnSiA38 in jNFqoOewYB2mG:
		items = ZXFs0mEPR8qI2zj.findall('<option(.*?)>(.*?)<',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
		if '=' not in lQHXdV9Nzf6BLqS8D: lQHXdV9Nzf6BLqS8D = url
		if type=='CATEGORIES':
			if p8pgXONsjY!=Lm4n6ZMXPrWpo: continue
			elif len(items)<=1:
				if Lm4n6ZMXPrWpo==E0tDmCreab3BWYTcdIupkU46v[-1]: RxAy5lEFQ1chv0BrdU4p6Pt2(lQHXdV9Nzf6BLqS8D)
				else: nvzlr8m5JEsbaqKd6YTuHCIfX9kLR(lQHXdV9Nzf6BLqS8D,'CATEGORIES___'+tt6AbxYRgQ3aC4O)
				return
			else:
				if Lm4n6ZMXPrWpo==E0tDmCreab3BWYTcdIupkU46v[-1]: Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+'الجميع',lQHXdV9Nzf6BLqS8D,351,'','1')
				else: Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+'الجميع',lQHXdV9Nzf6BLqS8D,355,'','',tt6AbxYRgQ3aC4O)
		elif type=='FILTERS':
			vX5qmpr1hSAszGE = SFbYEzoech4wU1+'&'+Lm4n6ZMXPrWpo+'=0'
			t9NhYxrZKcBf4u = kXR5NJaOcQUd47zugHqCAvjGoLmW+'&'+Lm4n6ZMXPrWpo+'=0'
			tt6AbxYRgQ3aC4O = vX5qmpr1hSAszGE+'___'+t9NhYxrZKcBf4u
			Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+'الجميع : '+name,lQHXdV9Nzf6BLqS8D,354,'','',tt6AbxYRgQ3aC4O)
		dict[Lm4n6ZMXPrWpo] = {}
		for AARNPWHjQU9dEmDI,Z7ZzgCTMBsNlVi9 in items:
			if Z7ZzgCTMBsNlVi9 in SmgoEYJ7uyL: continue
			if 'value' not in AARNPWHjQU9dEmDI: AARNPWHjQU9dEmDI = Z7ZzgCTMBsNlVi9
			else: AARNPWHjQU9dEmDI = ZXFs0mEPR8qI2zj.findall('"(.*?)"',AARNPWHjQU9dEmDI,ZXFs0mEPR8qI2zj.DOTALL)[0]
			dict[Lm4n6ZMXPrWpo][AARNPWHjQU9dEmDI] = Z7ZzgCTMBsNlVi9
			vX5qmpr1hSAszGE = SFbYEzoech4wU1+'&'+Lm4n6ZMXPrWpo+'='+Z7ZzgCTMBsNlVi9
			t9NhYxrZKcBf4u = kXR5NJaOcQUd47zugHqCAvjGoLmW+'&'+Lm4n6ZMXPrWpo+'='+AARNPWHjQU9dEmDI
			WYXmvw9l3jToq6rui1SCs = vX5qmpr1hSAszGE+'___'+t9NhYxrZKcBf4u
			title = Z7ZzgCTMBsNlVi9+' : '#+dict[Lm4n6ZMXPrWpo]['0']
			title = Z7ZzgCTMBsNlVi9+' : '+name
			if type=='FILTERS': Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+title,url,354,'','',WYXmvw9l3jToq6rui1SCs)
			elif type=='CATEGORIES' and E0tDmCreab3BWYTcdIupkU46v[-2]+'=' in SFbYEzoech4wU1:
				KMUEN9cD1OByji = l0mO1GdhAtb(t9NhYxrZKcBf4u,'all')
				aaIn3XlQKJ6zSfkmjuCyM = url+'?'+KMUEN9cD1OByji
				Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+title,aaIn3XlQKJ6zSfkmjuCyM,351,'','1')
			else: Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+title,url,355,'','',WYXmvw9l3jToq6rui1SCs)
	return
def l0mO1GdhAtb(zIpQyOG78Nvreijwa,mode):
	zIpQyOG78Nvreijwa = zIpQyOG78Nvreijwa.strip('&')
	JhV0ZrwmLIcOaHfQDK9qNsEGPzF83p = {}
	if '=' in zIpQyOG78Nvreijwa:
		items = zIpQyOG78Nvreijwa.split('&')
		for q8BXZlN9sU1fP2JAxH7W in items:
			cfMR9TgeL2hx6Wnq4liDX,AARNPWHjQU9dEmDI = q8BXZlN9sU1fP2JAxH7W.split('=')
			JhV0ZrwmLIcOaHfQDK9qNsEGPzF83p[cfMR9TgeL2hx6Wnq4liDX] = AARNPWHjQU9dEmDI
	rXLaWluDjvi4xMwpOSF91JB7 = ''
	t1tvAd5EPXM = ['cat','genre','release-year','quality','orderby']
	for key in t1tvAd5EPXM:
		if key in list(JhV0ZrwmLIcOaHfQDK9qNsEGPzF83p.keys()): AARNPWHjQU9dEmDI = JhV0ZrwmLIcOaHfQDK9qNsEGPzF83p[key]
		else: AARNPWHjQU9dEmDI = '0'
		if mode=='modified_values' and AARNPWHjQU9dEmDI!='0': rXLaWluDjvi4xMwpOSF91JB7 = rXLaWluDjvi4xMwpOSF91JB7+' + '+AARNPWHjQU9dEmDI
		elif mode=='modified_filters' and AARNPWHjQU9dEmDI!='0': rXLaWluDjvi4xMwpOSF91JB7 = rXLaWluDjvi4xMwpOSF91JB7+'&'+key+'='+AARNPWHjQU9dEmDI
		elif mode=='all': rXLaWluDjvi4xMwpOSF91JB7 = rXLaWluDjvi4xMwpOSF91JB7+'&'+key+'='+AARNPWHjQU9dEmDI
	rXLaWluDjvi4xMwpOSF91JB7 = rXLaWluDjvi4xMwpOSF91JB7.strip(' + ')
	rXLaWluDjvi4xMwpOSF91JB7 = rXLaWluDjvi4xMwpOSF91JB7.strip('&')
	return rXLaWluDjvi4xMwpOSF91JB7