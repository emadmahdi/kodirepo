# -*- coding: utf-8 -*-
from j3x780FpaM import *
LBtjHDg8yZz69QOp = 'IPTV'
oYkzVLIgyjNpsiTbZSBQ = '_IPT_'
FJLMxd8alBC7QbDKU9Onu2fw = [
		 'IGNORED'
		,'LIVE_UNKNOWN_GROUPED','LIVE_UNKNOWN_GROUPED_SORTED'
		,'VOD_UNKNOWN_GROUPED','VOD_UNKNOWN_GROUPED_SORTED'
		,'LIVE_ARCHIVED_GROUPED_SORTED','LIVE_EPG_GROUPED_SORTED','LIVE_TIMESHIFT_GROUPED_SORTED'
		,'LIVE_GROUPED','LIVE_GROUPED_SORTED'
		,'LIVE_ORIGINAL_GROUPED','LIVE_FROM_GROUP_SORTED','LIVE_FROM_NAME_SORTED'
		,'VOD_MOVIES_GROUPED','VOD_MOVIES_GROUPED_SORTED'
		,'VOD_SERIES_GROUPED','VOD_SERIES_GROUPED_SORTED'
		,'VOD_ORIGINAL_GROUPED','VOD_FROM_GROUP_SORTED','VOD_FROM_NAME_SORTED'
		]
def EXgQe7mIMsxD8kcOZ(nnPsf4XLIJ7RWF,gC2hO80boRyM7TBGqD,uHGMxiZfcoErOyXghvnWUK,RGDQbxHAi1UpIuNveqTFXSw9gZjc4,NznapDvCteQPx,WtmwkIxcKOZ3rB6PuSHCFL5vGqVo):
	global oYkzVLIgyjNpsiTbZSBQ
	try:
		fTLHoIGS2JMYV3jKh7DuW0ke = str(WtmwkIxcKOZ3rB6PuSHCFL5vGqVo['folder'])
		oYkzVLIgyjNpsiTbZSBQ = '_IP'+fTLHoIGS2JMYV3jKh7DuW0ke+'_'
	except: fTLHoIGS2JMYV3jKh7DuW0ke = ''
	if   nnPsf4XLIJ7RWF==230: RqIMxSdNAFb7P = u0M6dB3x9cNVDpYiztshXySWfv()
	elif nnPsf4XLIJ7RWF==231: RqIMxSdNAFb7P = gmfoXnU7hlQ5qL9euC(fTLHoIGS2JMYV3jKh7DuW0ke)
	elif nnPsf4XLIJ7RWF==232: RqIMxSdNAFb7P = OERZgyI3M0aDAXLvSiTpdjh1Q(fTLHoIGS2JMYV3jKh7DuW0ke)
	elif nnPsf4XLIJ7RWF==233: RqIMxSdNAFb7P = Ovdoig1sAc(fTLHoIGS2JMYV3jKh7DuW0ke,gC2hO80boRyM7TBGqD,uHGMxiZfcoErOyXghvnWUK,NznapDvCteQPx)
	elif nnPsf4XLIJ7RWF==234: RqIMxSdNAFb7P = J2K0qdYZMhG(fTLHoIGS2JMYV3jKh7DuW0ke,gC2hO80boRyM7TBGqD,uHGMxiZfcoErOyXghvnWUK,NznapDvCteQPx)
	elif nnPsf4XLIJ7RWF==235: RqIMxSdNAFb7P = jXYwiO9D056pkrzRh1y8tfWJxQoaI3(fTLHoIGS2JMYV3jKh7DuW0ke,gC2hO80boRyM7TBGqD,RGDQbxHAi1UpIuNveqTFXSw9gZjc4)
	elif nnPsf4XLIJ7RWF==236: RqIMxSdNAFb7P = FhYAZG1ur2sQRtTX9DlOcx3WILv(fTLHoIGS2JMYV3jKh7DuW0ke,True)
	elif nnPsf4XLIJ7RWF==237: RqIMxSdNAFb7P = Xjs93SRJtwqc(fTLHoIGS2JMYV3jKh7DuW0ke,True)
	elif nnPsf4XLIJ7RWF==238: RqIMxSdNAFb7P = saV3z5bE1LJF0moyeYikrnjgIH(fTLHoIGS2JMYV3jKh7DuW0ke,gC2hO80boRyM7TBGqD,uHGMxiZfcoErOyXghvnWUK)
	elif nnPsf4XLIJ7RWF==239: RqIMxSdNAFb7P = ZQTkpw4se6EOaIrgNLn(uHGMxiZfcoErOyXghvnWUK,fTLHoIGS2JMYV3jKh7DuW0ke,gC2hO80boRyM7TBGqD,NznapDvCteQPx)
	elif nnPsf4XLIJ7RWF==280: RqIMxSdNAFb7P = rUedtQkCXJq(fTLHoIGS2JMYV3jKh7DuW0ke,True)
	elif nnPsf4XLIJ7RWF==281: RqIMxSdNAFb7P = KcRikAv9Zbmerd4W6Pp7j5TQ(fTLHoIGS2JMYV3jKh7DuW0ke)
	elif nnPsf4XLIJ7RWF==282: RqIMxSdNAFb7P = UMPvFx2RpQTh3LfNYlqSyZz(fTLHoIGS2JMYV3jKh7DuW0ke)
	elif nnPsf4XLIJ7RWF==283: RqIMxSdNAFb7P = MQ0WAOIYobmyxS6akuziJG(fTLHoIGS2JMYV3jKh7DuW0ke)
	elif nnPsf4XLIJ7RWF==285: RqIMxSdNAFb7P = dWbgAVm2Tv5tID4XP9q(fTLHoIGS2JMYV3jKh7DuW0ke,gC2hO80boRyM7TBGqD,uHGMxiZfcoErOyXghvnWUK)
	elif nnPsf4XLIJ7RWF==286: RqIMxSdNAFb7P = sYyPU0CzeIgLmG7pjBq4uDJO(fTLHoIGS2JMYV3jKh7DuW0ke)
	elif nnPsf4XLIJ7RWF==289: RqIMxSdNAFb7P = NBoCjHK6ITwgY5OxeuALPlZ(uHGMxiZfcoErOyXghvnWUK,fTLHoIGS2JMYV3jKh7DuW0ke,gC2hO80boRyM7TBGqD,NznapDvCteQPx)
	else: RqIMxSdNAFb7P = False
	return RqIMxSdNAFb7P
def u0M6dB3x9cNVDpYiztshXySWfv():
	for fTLHoIGS2JMYV3jKh7DuW0ke in range(1,SS2ZAHCRpu8QxIao7BMq+1):
		oYkzVLIgyjNpsiTbZSBQ = '_IP'+str(fTLHoIGS2JMYV3jKh7DuW0ke)+'_'
		Tca7NsYPkIRWtBpFgxLZbSmCi('folder',oYkzVLIgyjNpsiTbZSBQ+'قائمة مجلد '+KnGrOQsDgfB8Raj9C2AZJuYcTxP[fTLHoIGS2JMYV3jKh7DuW0ke],'',280,'','','','',{'folder':fTLHoIGS2JMYV3jKh7DuW0ke})
	return
def rUedtQkCXJq(fTLHoIGS2JMYV3jKh7DuW0ke='',CaiGWx9HlMhRznyFDm1=''):
	if fTLHoIGS2JMYV3jKh7DuW0ke:
		TTaZ1xuBDtY6ldoyr3kE85QWUjb = {'folder':fTLHoIGS2JMYV3jKh7DuW0ke}
		r0djYXtTGD6HhniSkCp = ''
	else:
		TTaZ1xuBDtY6ldoyr3kE85QWUjb = ''
		r0djYXtTGD6HhniSkCp = ''
	JYEjR3wTduF = KHWOFrzptwybYx(fTLHoIGS2JMYV3jKh7DuW0ke,CaiGWx9HlMhRznyFDm1)
	if not JYEjR3wTduF:
		Tca7NsYPkIRWtBpFgxLZbSmCi('link',oYkzVLIgyjNpsiTbZSBQ+'[COLOR FFFFFF00] إضافة أو تغيير اشتراك'+r0djYXtTGD6HhniSkCp+' [/COLOR]','',231,'','','','',TTaZ1xuBDtY6ldoyr3kE85QWUjb)
		Tca7NsYPkIRWtBpFgxLZbSmCi('link',oYkzVLIgyjNpsiTbZSBQ+'[COLOR FFFFFF00] جلب ملفات'+r0djYXtTGD6HhniSkCp+' [/COLOR]','',232,'','','','',TTaZ1xuBDtY6ldoyr3kE85QWUjb)
		Tca7NsYPkIRWtBpFgxLZbSmCi('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	else:
		Tca7NsYPkIRWtBpFgxLZbSmCi('folder',oYkzVLIgyjNpsiTbZSBQ+'بحث في الملفات'+r0djYXtTGD6HhniSkCp,'',289,'','','_REMEMBERRESULTS_','',TTaZ1xuBDtY6ldoyr3kE85QWUjb)
		Tca7NsYPkIRWtBpFgxLZbSmCi('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
		Tca7NsYPkIRWtBpFgxLZbSmCi('folder',oYkzVLIgyjNpsiTbZSBQ+'قنوات بدون جلب ملفات','XTREAM_LIVE_GROUPS',285,'','','','',TTaZ1xuBDtY6ldoyr3kE85QWUjb)
		Tca7NsYPkIRWtBpFgxLZbSmCi('folder',oYkzVLIgyjNpsiTbZSBQ+'قنوات مصنفة مرتبة'+r0djYXtTGD6HhniSkCp,'LIVE_GROUPED_SORTED',233,'','','','',TTaZ1xuBDtY6ldoyr3kE85QWUjb)
		Tca7NsYPkIRWtBpFgxLZbSmCi('folder',oYkzVLIgyjNpsiTbZSBQ+'قنوات مصنفة من القسم'+r0djYXtTGD6HhniSkCp,'LIVE_FROM_GROUP_SORTED',233,'','','','',TTaZ1xuBDtY6ldoyr3kE85QWUjb)
		Tca7NsYPkIRWtBpFgxLZbSmCi('folder',oYkzVLIgyjNpsiTbZSBQ+'قنوات مصنفة من الاسم'+r0djYXtTGD6HhniSkCp,'LIVE_FROM_NAME_SORTED',233,'','','','',TTaZ1xuBDtY6ldoyr3kE85QWUjb)
		Tca7NsYPkIRWtBpFgxLZbSmCi('folder',oYkzVLIgyjNpsiTbZSBQ+'قنوات مصنفة بلا ترتيب'+r0djYXtTGD6HhniSkCp,'LIVE_GROUPED',233,'','','','',TTaZ1xuBDtY6ldoyr3kE85QWUjb)
		Tca7NsYPkIRWtBpFgxLZbSmCi('folder',oYkzVLIgyjNpsiTbZSBQ+'قنوات بلا ترتيب'+r0djYXtTGD6HhniSkCp,'LIVE_ORIGINAL_GROUPED',233,'','','','',TTaZ1xuBDtY6ldoyr3kE85QWUjb)
		Tca7NsYPkIRWtBpFgxLZbSmCi('folder',oYkzVLIgyjNpsiTbZSBQ+'قنوات مجهولة مرتبة'+r0djYXtTGD6HhniSkCp,'LIVE_UNKNOWN_GROUPED_SORTED',233,'','','','',TTaZ1xuBDtY6ldoyr3kE85QWUjb)
		Tca7NsYPkIRWtBpFgxLZbSmCi('folder',oYkzVLIgyjNpsiTbZSBQ+'قنوات مجهولة بلا ترتيب'+r0djYXtTGD6HhniSkCp,'LIVE_UNKNOWN_GROUPED',233,'','','','',TTaZ1xuBDtY6ldoyr3kE85QWUjb)
		Tca7NsYPkIRWtBpFgxLZbSmCi('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
		Tca7NsYPkIRWtBpFgxLZbSmCi('folder',oYkzVLIgyjNpsiTbZSBQ+'أفلام بدون جلب ملفات','XTREAM_VOD_GROUPS',285,'','','','',TTaZ1xuBDtY6ldoyr3kE85QWUjb)
		Tca7NsYPkIRWtBpFgxLZbSmCi('folder',oYkzVLIgyjNpsiTbZSBQ+'أفلام مصنفة بلا ترتيب'+r0djYXtTGD6HhniSkCp,'VOD_MOVIES_GROUPED',233,'','','','',TTaZ1xuBDtY6ldoyr3kE85QWUjb)
		Tca7NsYPkIRWtBpFgxLZbSmCi('folder',oYkzVLIgyjNpsiTbZSBQ+'أفلام مصنفة مرتبة'+r0djYXtTGD6HhniSkCp,'VOD_MOVIES_GROUPED_SORTED',233,'','','','',TTaZ1xuBDtY6ldoyr3kE85QWUjb)
		Tca7NsYPkIRWtBpFgxLZbSmCi('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
		Tca7NsYPkIRWtBpFgxLZbSmCi('folder',oYkzVLIgyjNpsiTbZSBQ+'مسلسلات بدون جلب ملفات','XTREAM_SERIES_GROUPS',285,'','','','',TTaZ1xuBDtY6ldoyr3kE85QWUjb)
		Tca7NsYPkIRWtBpFgxLZbSmCi('folder',oYkzVLIgyjNpsiTbZSBQ+'مسلسلات مصنفة بلا ترتيب'+r0djYXtTGD6HhniSkCp,'VOD_SERIES_GROUPED',233,'','','','',TTaZ1xuBDtY6ldoyr3kE85QWUjb)
		Tca7NsYPkIRWtBpFgxLZbSmCi('folder',oYkzVLIgyjNpsiTbZSBQ+'مسلسلات مصنفة مرتبة'+r0djYXtTGD6HhniSkCp,'VOD_SERIES_GROUPED_SORTED',233,'','','','',TTaZ1xuBDtY6ldoyr3kE85QWUjb)
		Tca7NsYPkIRWtBpFgxLZbSmCi('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
		Tca7NsYPkIRWtBpFgxLZbSmCi('folder',oYkzVLIgyjNpsiTbZSBQ+'فيديوهات بلا ترتيب'+r0djYXtTGD6HhniSkCp,'VOD_ORIGINAL_GROUPED',233,'','','','',TTaZ1xuBDtY6ldoyr3kE85QWUjb)
		Tca7NsYPkIRWtBpFgxLZbSmCi('folder',oYkzVLIgyjNpsiTbZSBQ+'فيديوهات مصنفة من القسم'+r0djYXtTGD6HhniSkCp,'VOD_FROM_GROUP_SORTED',233,'','','','',TTaZ1xuBDtY6ldoyr3kE85QWUjb)
		Tca7NsYPkIRWtBpFgxLZbSmCi('folder',oYkzVLIgyjNpsiTbZSBQ+'فيديوهات مصنفة من الاسم'+r0djYXtTGD6HhniSkCp,'VOD_FROM_NAME_SORTED',233,'','','','',TTaZ1xuBDtY6ldoyr3kE85QWUjb)
		Tca7NsYPkIRWtBpFgxLZbSmCi('folder',oYkzVLIgyjNpsiTbZSBQ+'فيديوهات مجهولة بلا ترتيب'+r0djYXtTGD6HhniSkCp,'VOD_UNKNOWN_GROUPED',233,'','','','',TTaZ1xuBDtY6ldoyr3kE85QWUjb)
		Tca7NsYPkIRWtBpFgxLZbSmCi('folder',oYkzVLIgyjNpsiTbZSBQ+'فيديوهات مجهولة مرتبة'+r0djYXtTGD6HhniSkCp,'VOD_UNKNOWN_GROUPED_SORTED',233,'','','','',TTaZ1xuBDtY6ldoyr3kE85QWUjb)
		Tca7NsYPkIRWtBpFgxLZbSmCi('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
		Tca7NsYPkIRWtBpFgxLZbSmCi('folder',oYkzVLIgyjNpsiTbZSBQ+'برامج القنوات (جدول فقط)'+r0djYXtTGD6HhniSkCp,'LIVE_EPG_GROUPED_SORTED',233,'','','','',TTaZ1xuBDtY6ldoyr3kE85QWUjb)
		Tca7NsYPkIRWtBpFgxLZbSmCi('folder',oYkzVLIgyjNpsiTbZSBQ+'أرشيف القنوات للأيام الماضية'+r0djYXtTGD6HhniSkCp,'LIVE_TIMESHIFT_GROUPED_SORTED',233,'','','','',TTaZ1xuBDtY6ldoyr3kE85QWUjb)
		Tca7NsYPkIRWtBpFgxLZbSmCi('folder',oYkzVLIgyjNpsiTbZSBQ+'أرشيف برامج القنوات للأيام الماضية'+r0djYXtTGD6HhniSkCp,'LIVE_ARCHIVED_GROUPED_SORTED',233,'','','','',TTaZ1xuBDtY6ldoyr3kE85QWUjb)
		Tca7NsYPkIRWtBpFgxLZbSmCi('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	Tca7NsYPkIRWtBpFgxLZbSmCi('link',oYkzVLIgyjNpsiTbZSBQ+'إضافة أو تغيير اشتراك'+r0djYXtTGD6HhniSkCp,'',231,'','','','',TTaZ1xuBDtY6ldoyr3kE85QWUjb)
	Tca7NsYPkIRWtBpFgxLZbSmCi('link',oYkzVLIgyjNpsiTbZSBQ+'جلب ملفات'+r0djYXtTGD6HhniSkCp,'',232,'','','','',TTaZ1xuBDtY6ldoyr3kE85QWUjb)
	Tca7NsYPkIRWtBpFgxLZbSmCi('link',oYkzVLIgyjNpsiTbZSBQ+'مسح ملفات'+r0djYXtTGD6HhniSkCp,'',237,'','','','',TTaZ1xuBDtY6ldoyr3kE85QWUjb)
	Tca7NsYPkIRWtBpFgxLZbSmCi('link',oYkzVLIgyjNpsiTbZSBQ+'فحص اشتراك'+r0djYXtTGD6HhniSkCp,'',236,'','','','',TTaZ1xuBDtY6ldoyr3kE85QWUjb)
	Tca7NsYPkIRWtBpFgxLZbSmCi('link',oYkzVLIgyjNpsiTbZSBQ+'عدد فيديوهات'+r0djYXtTGD6HhniSkCp,'',281,'','','','',TTaZ1xuBDtY6ldoyr3kE85QWUjb)
	Tca7NsYPkIRWtBpFgxLZbSmCi('link',oYkzVLIgyjNpsiTbZSBQ+'Referer تغيير'+r0djYXtTGD6HhniSkCp,'',286,'','','','',TTaZ1xuBDtY6ldoyr3kE85QWUjb)
	Tca7NsYPkIRWtBpFgxLZbSmCi('link',oYkzVLIgyjNpsiTbZSBQ+'User-Agent تغيير'+r0djYXtTGD6HhniSkCp,'',283,'','','','',TTaZ1xuBDtY6ldoyr3kE85QWUjb)
	Tca7NsYPkIRWtBpFgxLZbSmCi('link',oYkzVLIgyjNpsiTbZSBQ+'استخدم السيرفر الأسرع'+r0djYXtTGD6HhniSkCp,'',282,'','','','',TTaZ1xuBDtY6ldoyr3kE85QWUjb)
	return
def FhYAZG1ur2sQRtTX9DlOcx3WILv(fTLHoIGS2JMYV3jKh7DuW0ke,CaiGWx9HlMhRznyFDm1=True):
	D7OijMIzyKWUTpQF1ECnZJcqBRxed,FdjY1QbmG6y = False,''
	VzPym8fW6lKD1bpeZGnRCBs,MnAvyj3DZthLSIo = '',''
	LLmOgfvERFwWp9DQMoBHS36rd,fUSnuQTRBwOtFhZz36k9y,lBeGVXTt0qD,v1IzDVTBhweb3tRr6YCyoNK,LX35qsjfcIWaDT8S462 = gmcELYbTJS(fTLHoIGS2JMYV3jKh7DuW0ke)
	if v1IzDVTBhweb3tRr6YCyoNK=='': return False,'',''
	Mm7XCRohg3iUSfJKdWsIqx = poTRFiyNCYwsO8dhMBHZ2lAIvL1(fTLHoIGS2JMYV3jKh7DuW0ke)
	if LLmOgfvERFwWp9DQMoBHS36rd:
		Ba3qhge51Hynsz8mcoW = A6F71g3cqN4(KxirmCLT6Gw,'GET',LLmOgfvERFwWp9DQMoBHS36rd,'',Mm7XCRohg3iUSfJKdWsIqx,False,'','IPTV-CHECK_ACCOUNT-1st')
		BRufE2IykDCOaNAv9iU = Ba3qhge51Hynsz8mcoW.content
		if Ba3qhge51Hynsz8mcoW.succeeded:
			T1TmhxAtY5qeJ28ywXBL,kb3SMugt0LQCmD2dwFHRapPNI4,c6coXJrbRVSiEQG4tDxkM1d5uz,DeSVN9RM7W,bVRiuYAeDM9NnSfxdHI = 0,0,'','',''
			try:
				JxuZ9wqO1Fbm6sQNU5raoA8PjW = NL0JIkbrEWqTYj61vVKGCnBw37MsOF('dict',BRufE2IykDCOaNAv9iU)
				FdjY1QbmG6y = JxuZ9wqO1Fbm6sQNU5raoA8PjW['user_info']['status']
				D7OijMIzyKWUTpQF1ECnZJcqBRxed = True
				c6coXJrbRVSiEQG4tDxkM1d5uz = JxuZ9wqO1Fbm6sQNU5raoA8PjW['server_info']['time_now']
			except: pass
			if c6coXJrbRVSiEQG4tDxkM1d5uz:
				try:
					nHbv7QFEXlKGotj4BAeLdYJ = luMHeSgCBaPrb9KvUjNFqcR.strptime(c6coXJrbRVSiEQG4tDxkM1d5uz,'%Y.%m.%d %H:%M:%S')
					T1TmhxAtY5qeJ28ywXBL = int(luMHeSgCBaPrb9KvUjNFqcR.mktime(nHbv7QFEXlKGotj4BAeLdYJ))
					kb3SMugt0LQCmD2dwFHRapPNI4 = int(F5I1VZzxkXenKuEAYO-T1TmhxAtY5qeJ28ywXBL)
					kb3SMugt0LQCmD2dwFHRapPNI4 = int((kb3SMugt0LQCmD2dwFHRapPNI4+900)/1800)*1800
				except: pass
				try:
					nHbv7QFEXlKGotj4BAeLdYJ = luMHeSgCBaPrb9KvUjNFqcR.localtime(int(JxuZ9wqO1Fbm6sQNU5raoA8PjW['user_info']['created_at']))
					DeSVN9RM7W = luMHeSgCBaPrb9KvUjNFqcR.strftime('%Y.%m.%d %H:%M:%S',nHbv7QFEXlKGotj4BAeLdYJ)
				except: pass
				try:
					nHbv7QFEXlKGotj4BAeLdYJ = luMHeSgCBaPrb9KvUjNFqcR.localtime(int(JxuZ9wqO1Fbm6sQNU5raoA8PjW['user_info']['exp_date']))
					bVRiuYAeDM9NnSfxdHI = luMHeSgCBaPrb9KvUjNFqcR.strftime('%Y.%m.%d %H:%M:%S',nHbv7QFEXlKGotj4BAeLdYJ)
				except: pass
			j2agIU0xsLS6c7T.setSetting('av.iptv.timestamp_'+fTLHoIGS2JMYV3jKh7DuW0ke,str(F5I1VZzxkXenKuEAYO))
			j2agIU0xsLS6c7T.setSetting('av.iptv.timediff_'+fTLHoIGS2JMYV3jKh7DuW0ke,str(kb3SMugt0LQCmD2dwFHRapPNI4))
			try:
				JgsehvZt1BlxyQF = '"server_info":'+BRufE2IykDCOaNAv9iU.split('"server_info":')[1]
				JgsehvZt1BlxyQF = JgsehvZt1BlxyQF.replace(':',': ').replace(',',', ').replace('}}','}')
				WWeS01piHaDk2EhtyIqYVncXPBCRf = ZXFs0mEPR8qI2zj.findall('"url": "(.*?)", "port": "(.*?)"',JgsehvZt1BlxyQF,ZXFs0mEPR8qI2zj.DOTALL)
				VzPym8fW6lKD1bpeZGnRCBs,MnAvyj3DZthLSIo = WWeS01piHaDk2EhtyIqYVncXPBCRf[0]
			except: D7OijMIzyKWUTpQF1ECnZJcqBRxed = False
			if D7OijMIzyKWUTpQF1ECnZJcqBRxed and CaiGWx9HlMhRznyFDm1:
				max = JxuZ9wqO1Fbm6sQNU5raoA8PjW['user_info']['max_connections']
				KF4o6hpsOVix0Ljd9 = JxuZ9wqO1Fbm6sQNU5raoA8PjW['user_info']['active_cons']
				g1MNEeO6riAypnm8qQ4tYxW = JxuZ9wqO1Fbm6sQNU5raoA8PjW['user_info']['is_trial']
				RkXi8unALUVC5 = LLmOgfvERFwWp9DQMoBHS36rd.split('?',1)
				LaX1QCyeIJ = 'URL:  [COLOR FFC89008]'+LLmOgfvERFwWp9DQMoBHS36rd+'[/COLOR]'
				LaX1QCyeIJ += '\n\nStatus:  '+'[COLOR FFC89008]'+FdjY1QbmG6y+'[/COLOR]'
				LaX1QCyeIJ += '\nTrial:    '+'[COLOR FFC89008]'+str(g1MNEeO6riAypnm8qQ4tYxW=='1')+'[/COLOR]'
				LaX1QCyeIJ += '\nCreated  At:  '+'[COLOR FFC89008]'+DeSVN9RM7W+'[/COLOR]'
				LaX1QCyeIJ += '\nExpiry Date:  '+'[COLOR FFC89008]'+bVRiuYAeDM9NnSfxdHI+'[/COLOR]'
				LaX1QCyeIJ += '\nConnections   ( Active / Maximum ) :  '+'[COLOR FFC89008]'+KF4o6hpsOVix0Ljd9+' / '+max+'[/COLOR]'
				LaX1QCyeIJ += '\nAllowed Outputs:   '+'[COLOR FFC89008]'+" , ".join(JxuZ9wqO1Fbm6sQNU5raoA8PjW['user_info']['allowed_output_formats'])+'[/COLOR]'
				LaX1QCyeIJ += '\n\n'+JgsehvZt1BlxyQF
				if FdjY1QbmG6y=='Active': JATO6o8EHKZLIsaQV('الاشتراك يعمل بدون مشاكل',LaX1QCyeIJ)
				else: JATO6o8EHKZLIsaQV('يبدو أن هناك مشكلة في الاشتراك',LaX1QCyeIJ)
	if LLmOgfvERFwWp9DQMoBHS36rd and D7OijMIzyKWUTpQF1ECnZJcqBRxed and FdjY1QbmG6y=='Active':
		tr24ZoudmqvxfYCw('NOTICE','.  Checking IPTV URL   [ IPTV account is OK ]   [ '+LLmOgfvERFwWp9DQMoBHS36rd+' ]')
		Q4o2IDnNJzcYe = True
	else:
		tr24ZoudmqvxfYCw('ERROR_LINES','Checking IPTV URL   [ Does not work ]   [ '+LLmOgfvERFwWp9DQMoBHS36rd+' ]')
		if CaiGWx9HlMhRznyFDm1: HHTzVhiY079bvdluNkFQ4wCMpe('','','فحص اشتراك ـIPTV','رابط اشتراك ـIPTV الذي قمت انت بإضافته إلى البرنامج لا يعمل أو الرابط غير موجود في البرنامج . أذهب إلى قائمة اشتراك ـIPTV وقم بإضافة رابط ـIPTV جديد أو قم بإصلاح الرابط القديم')
		Q4o2IDnNJzcYe = False
	return Q4o2IDnNJzcYe,VzPym8fW6lKD1bpeZGnRCBs,MnAvyj3DZthLSIo
def J2K0qdYZMhG(fTLHoIGS2JMYV3jKh7DuW0ke,dMu4F8L5Azo6IJ2aleywBmb,kUxyZMQ2Svz9A4JNBYtHn5sbDRr,uVGD6ZCHboELna3i7hKM4YPNS,CaiGWx9HlMhRznyFDm1=True):
	if not uVGD6ZCHboELna3i7hKM4YPNS: uVGD6ZCHboELna3i7hKM4YPNS = '1'
	if not KHWOFrzptwybYx(fTLHoIGS2JMYV3jKh7DuW0ke,CaiGWx9HlMhRznyFDm1): return
	sEyDZTBxj9l = cHa5JRAQ3ZKku7(fTLHoIGS2JMYV3jKh7DuW0ke,dMu4F8L5Azo6IJ2aleywBmb)
	bb2Wi1TrnXpSA4wgfszMvcxd0O3mL = NUauTXxKLAoqQtJkglSFRWE(sEyDZTBxj9l,'list',dMu4F8L5Azo6IJ2aleywBmb,kUxyZMQ2Svz9A4JNBYtHn5sbDRr)
	PZg0OBKQyfwR3uFp = int(uVGD6ZCHboELna3i7hKM4YPNS)*100
	qzWuPiXcUV3I7D1jGB2R = PZg0OBKQyfwR3uFp-100
	for dGlmU8JqW5yFAtcsg,yHAD9oVfdieMNhC,gC2hO80boRyM7TBGqD,EoMKR2biY0 in bb2Wi1TrnXpSA4wgfszMvcxd0O3mL[qzWuPiXcUV3I7D1jGB2R:PZg0OBKQyfwR3uFp]:
		wjNixHdgWLyZS59I = ('GROUPED' in dMu4F8L5Azo6IJ2aleywBmb or dMu4F8L5Azo6IJ2aleywBmb=='ALL')
		p2pHPMV4sadmf8qJBOZb0 = ('GROUPED' not in dMu4F8L5Azo6IJ2aleywBmb and dMu4F8L5Azo6IJ2aleywBmb!='ALL')
		if wjNixHdgWLyZS59I or p2pHPMV4sadmf8qJBOZb0:
			if   'ARCHIVED'  in dMu4F8L5Azo6IJ2aleywBmb: OWasmQ27g3Dbljpo.append(['folder',oYkzVLIgyjNpsiTbZSBQ+yHAD9oVfdieMNhC,gC2hO80boRyM7TBGqD,238,EoMKR2biY0,'','ARCHIVED','',{'folder':fTLHoIGS2JMYV3jKh7DuW0ke}])
			elif 'EPG' 		 in dMu4F8L5Azo6IJ2aleywBmb: OWasmQ27g3Dbljpo.append(['folder',oYkzVLIgyjNpsiTbZSBQ+yHAD9oVfdieMNhC,gC2hO80boRyM7TBGqD,238,EoMKR2biY0,'','FULL_EPG','',{'folder':fTLHoIGS2JMYV3jKh7DuW0ke}])
			elif 'TIMESHIFT' in dMu4F8L5Azo6IJ2aleywBmb: OWasmQ27g3Dbljpo.append(['folder',oYkzVLIgyjNpsiTbZSBQ+yHAD9oVfdieMNhC,gC2hO80boRyM7TBGqD,238,EoMKR2biY0,'','TIMESHIFT','',{'folder':fTLHoIGS2JMYV3jKh7DuW0ke}])
			elif 'LIVE' 	 in dMu4F8L5Azo6IJ2aleywBmb: OWasmQ27g3Dbljpo.append(['live',oYkzVLIgyjNpsiTbZSBQ+yHAD9oVfdieMNhC,gC2hO80boRyM7TBGqD,235,EoMKR2biY0,'','',dGlmU8JqW5yFAtcsg,{'folder':fTLHoIGS2JMYV3jKh7DuW0ke}])
			else: OWasmQ27g3Dbljpo.append(['video',oYkzVLIgyjNpsiTbZSBQ+yHAD9oVfdieMNhC,gC2hO80boRyM7TBGqD,235,EoMKR2biY0,'','','',{'folder':fTLHoIGS2JMYV3jKh7DuW0ke}])
	Nkx1U6BAd2ClyzDqW0noOPj3h = len(bb2Wi1TrnXpSA4wgfszMvcxd0O3mL)
	dlU0EksuLjrBaq(fTLHoIGS2JMYV3jKh7DuW0ke,uVGD6ZCHboELna3i7hKM4YPNS,dMu4F8L5Azo6IJ2aleywBmb,234,Nkx1U6BAd2ClyzDqW0noOPj3h,kUxyZMQ2Svz9A4JNBYtHn5sbDRr)
	return
def nFVKo4raOPWfjIJ1LDRh2d3g(na6F4zgxAjdZ):
	Tca7NsYPkIRWtBpFgxLZbSmCi('link',na6F4zgxAjdZ+'هذه القائمة إما فارغة أو غير موجودة','',9999)
	Tca7NsYPkIRWtBpFgxLZbSmCi('link',na6F4zgxAjdZ+'أو الخدمة غير موجودة في اشتراكك','',9999)
	Tca7NsYPkIRWtBpFgxLZbSmCi('link',na6F4zgxAjdZ+'أو رابط IPTVـ الذي أنت أضفته غير صحيح','',9999)
	return
def Ovdoig1sAc(fTLHoIGS2JMYV3jKh7DuW0ke,dMu4F8L5Azo6IJ2aleywBmb,kUxyZMQ2Svz9A4JNBYtHn5sbDRr,uVGD6ZCHboELna3i7hKM4YPNS,qh15WZ4Gdcbv='',CaiGWx9HlMhRznyFDm1=True):
	if not uVGD6ZCHboELna3i7hKM4YPNS: uVGD6ZCHboELna3i7hKM4YPNS = '1'
	na6F4zgxAjdZ = oYkzVLIgyjNpsiTbZSBQ
	if not KHWOFrzptwybYx(fTLHoIGS2JMYV3jKh7DuW0ke,CaiGWx9HlMhRznyFDm1): return False
	if '__SERIES__' in kUxyZMQ2Svz9A4JNBYtHn5sbDRr: Tf1EBxvRyIzcNk,coXV1en2GfJPYKsLT8MECx0 = kUxyZMQ2Svz9A4JNBYtHn5sbDRr.split('__SERIES__')
	else: Tf1EBxvRyIzcNk,coXV1en2GfJPYKsLT8MECx0 = kUxyZMQ2Svz9A4JNBYtHn5sbDRr,''
	sEyDZTBxj9l = cHa5JRAQ3ZKku7(fTLHoIGS2JMYV3jKh7DuW0ke,dMu4F8L5Azo6IJ2aleywBmb)
	O5YIZ7asToB1lfpeVrRE4bW = NUauTXxKLAoqQtJkglSFRWE(sEyDZTBxj9l,'list',dMu4F8L5Azo6IJ2aleywBmb,'__GROUPS__')
	if not O5YIZ7asToB1lfpeVrRE4bW: return False
	uQkZILtf5X6Kp = []
	for aBXgWuYGwdyS8k0jF4efM5QOcDL,EoMKR2biY0 in O5YIZ7asToB1lfpeVrRE4bW:
		if qh15WZ4Gdcbv:
			if '__SERIES__' in aBXgWuYGwdyS8k0jF4efM5QOcDL: na6F4zgxAjdZ = 'SERIES'
			elif '!!__UNKNOWN__!!' in aBXgWuYGwdyS8k0jF4efM5QOcDL: na6F4zgxAjdZ = 'UNKNOWN'
			elif 'LIVE' in dMu4F8L5Azo6IJ2aleywBmb: na6F4zgxAjdZ = 'LIVE'
			else: na6F4zgxAjdZ = 'VIDEOS'
			na6F4zgxAjdZ = ',[COLOR FFC89008]'+na6F4zgxAjdZ+': [/COLOR]'
		if '__SERIES__' in aBXgWuYGwdyS8k0jF4efM5QOcDL: Tu82Ar7n6YRQmGw1xze95jdKXy,O8o4wEI93GfiX7qCyKbe0BUF2 = aBXgWuYGwdyS8k0jF4efM5QOcDL.split('__SERIES__')
		else: Tu82Ar7n6YRQmGw1xze95jdKXy,O8o4wEI93GfiX7qCyKbe0BUF2 = aBXgWuYGwdyS8k0jF4efM5QOcDL,''
		if not kUxyZMQ2Svz9A4JNBYtHn5sbDRr:
			if Tu82Ar7n6YRQmGw1xze95jdKXy in uQkZILtf5X6Kp: continue
			uQkZILtf5X6Kp.append(Tu82Ar7n6YRQmGw1xze95jdKXy)
			if 'RANDOM' in qh15WZ4Gdcbv: Tca7NsYPkIRWtBpFgxLZbSmCi('folder',na6F4zgxAjdZ+Tu82Ar7n6YRQmGw1xze95jdKXy,dMu4F8L5Azo6IJ2aleywBmb,167,'','1',aBXgWuYGwdyS8k0jF4efM5QOcDL,'',{'folder':fTLHoIGS2JMYV3jKh7DuW0ke})
			elif '__SERIES__' in aBXgWuYGwdyS8k0jF4efM5QOcDL: Tca7NsYPkIRWtBpFgxLZbSmCi('folder',na6F4zgxAjdZ+Tu82Ar7n6YRQmGw1xze95jdKXy,dMu4F8L5Azo6IJ2aleywBmb,233,'','1',aBXgWuYGwdyS8k0jF4efM5QOcDL,'',{'folder':fTLHoIGS2JMYV3jKh7DuW0ke})
			else: Tca7NsYPkIRWtBpFgxLZbSmCi('folder',na6F4zgxAjdZ+Tu82Ar7n6YRQmGw1xze95jdKXy,dMu4F8L5Azo6IJ2aleywBmb,234,'','1',aBXgWuYGwdyS8k0jF4efM5QOcDL,'',{'folder':fTLHoIGS2JMYV3jKh7DuW0ke})
		elif '__SERIES__' in aBXgWuYGwdyS8k0jF4efM5QOcDL and Tu82Ar7n6YRQmGw1xze95jdKXy==Tf1EBxvRyIzcNk:
			if O8o4wEI93GfiX7qCyKbe0BUF2 in uQkZILtf5X6Kp: continue
			uQkZILtf5X6Kp.append(O8o4wEI93GfiX7qCyKbe0BUF2)
			if 'RANDOM' in qh15WZ4Gdcbv: Tca7NsYPkIRWtBpFgxLZbSmCi('folder',na6F4zgxAjdZ+O8o4wEI93GfiX7qCyKbe0BUF2,dMu4F8L5Azo6IJ2aleywBmb,167,'','1',aBXgWuYGwdyS8k0jF4efM5QOcDL,'',{'folder':fTLHoIGS2JMYV3jKh7DuW0ke})
			else: Tca7NsYPkIRWtBpFgxLZbSmCi('folder',na6F4zgxAjdZ+O8o4wEI93GfiX7qCyKbe0BUF2,dMu4F8L5Azo6IJ2aleywBmb,234,EoMKR2biY0,'1',aBXgWuYGwdyS8k0jF4efM5QOcDL,'',{'folder':fTLHoIGS2JMYV3jKh7DuW0ke})
	OWasmQ27g3Dbljpo[:] = sorted(OWasmQ27g3Dbljpo,reverse=False,key=lambda JDv1uYxBEPcFGwrmlfzSOC: JDv1uYxBEPcFGwrmlfzSOC[1].lower())
	if not qh15WZ4Gdcbv:
		PZg0OBKQyfwR3uFp = int(uVGD6ZCHboELna3i7hKM4YPNS)*100
		qzWuPiXcUV3I7D1jGB2R = PZg0OBKQyfwR3uFp-100
		Nkx1U6BAd2ClyzDqW0noOPj3h = len(OWasmQ27g3Dbljpo)
		OWasmQ27g3Dbljpo[:] = OWasmQ27g3Dbljpo[qzWuPiXcUV3I7D1jGB2R:PZg0OBKQyfwR3uFp]
		dlU0EksuLjrBaq(fTLHoIGS2JMYV3jKh7DuW0ke,uVGD6ZCHboELna3i7hKM4YPNS,dMu4F8L5Azo6IJ2aleywBmb,233,Nkx1U6BAd2ClyzDqW0noOPj3h,kUxyZMQ2Svz9A4JNBYtHn5sbDRr)
	return True
def saV3z5bE1LJF0moyeYikrnjgIH(fTLHoIGS2JMYV3jKh7DuW0ke,gC2hO80boRyM7TBGqD,ItpjaAnZOhUEluJQiMm9zGo2v8Dw):
	if not KHWOFrzptwybYx(fTLHoIGS2JMYV3jKh7DuW0ke,True): return
	Mm7XCRohg3iUSfJKdWsIqx = poTRFiyNCYwsO8dhMBHZ2lAIvL1(fTLHoIGS2JMYV3jKh7DuW0ke)
	T1TmhxAtY5qeJ28ywXBL = j2agIU0xsLS6c7T.getSetting('av.iptv.timestamp_'+fTLHoIGS2JMYV3jKh7DuW0ke)
	if not T1TmhxAtY5qeJ28ywXBL or F5I1VZzxkXenKuEAYO-int(T1TmhxAtY5qeJ28ywXBL)>24*sGOne0xWA5:
		Q4o2IDnNJzcYe,VzPym8fW6lKD1bpeZGnRCBs,MnAvyj3DZthLSIo = FhYAZG1ur2sQRtTX9DlOcx3WILv(fTLHoIGS2JMYV3jKh7DuW0ke,False)
		if not Q4o2IDnNJzcYe: return
	kb3SMugt0LQCmD2dwFHRapPNI4 = int(j2agIU0xsLS6c7T.getSetting('av.iptv.timediff_'+fTLHoIGS2JMYV3jKh7DuW0ke))
	lBeGVXTt0qD = j2agIU0xsLS6c7T.getSetting('av.iptv.server_'+fTLHoIGS2JMYV3jKh7DuW0ke)
	v1IzDVTBhweb3tRr6YCyoNK = j2agIU0xsLS6c7T.getSetting('av.iptv.username_'+fTLHoIGS2JMYV3jKh7DuW0ke)
	LX35qsjfcIWaDT8S462 = j2agIU0xsLS6c7T.getSetting('av.iptv.password_'+fTLHoIGS2JMYV3jKh7DuW0ke)
	UGWsYP1KNJHfr5I9O36AEC7oTljLt = gC2hO80boRyM7TBGqD.split('/')
	jsINZ1EbOvtS7o0 = UGWsYP1KNJHfr5I9O36AEC7oTljLt[-1].replace('.ts','').replace('.m3u8','')
	if ItpjaAnZOhUEluJQiMm9zGo2v8Dw=='SHORT_EPG': cYPzbseokvViBH4a8lO2p = 'get_short_epg'
	else: cYPzbseokvViBH4a8lO2p = 'get_simple_data_table'
	LLmOgfvERFwWp9DQMoBHS36rd,fUSnuQTRBwOtFhZz36k9y,lBeGVXTt0qD,v1IzDVTBhweb3tRr6YCyoNK,LX35qsjfcIWaDT8S462 = gmcELYbTJS(fTLHoIGS2JMYV3jKh7DuW0ke)
	if not v1IzDVTBhweb3tRr6YCyoNK: return
	AR5qiolctwvpLKXsSh6nVx = LLmOgfvERFwWp9DQMoBHS36rd+'&action='+cYPzbseokvViBH4a8lO2p+'&stream_id='+jsINZ1EbOvtS7o0
	BRufE2IykDCOaNAv9iU = WHFUa0fegZpJshClji9KzRVDoA8Xrt(KxirmCLT6Gw,AR5qiolctwvpLKXsSh6nVx,'',Mm7XCRohg3iUSfJKdWsIqx,'','IPTV-EPG_ITEMS-2nd')
	i54QjcV2tWB0d = NL0JIkbrEWqTYj61vVKGCnBw37MsOF('dict',BRufE2IykDCOaNAv9iU)
	ZfTwrusDx3UeXqbtCla = i54QjcV2tWB0d['epg_listings']
	niJKWcmRgwo7D8012bx36IO = []
	if ItpjaAnZOhUEluJQiMm9zGo2v8Dw in ['ARCHIVED','TIMESHIFT']:
		for JxuZ9wqO1Fbm6sQNU5raoA8PjW in ZfTwrusDx3UeXqbtCla:
			if JxuZ9wqO1Fbm6sQNU5raoA8PjW['has_archive']==1:
				niJKWcmRgwo7D8012bx36IO.append(JxuZ9wqO1Fbm6sQNU5raoA8PjW)
				if ItpjaAnZOhUEluJQiMm9zGo2v8Dw in ['TIMESHIFT']: break
		if not niJKWcmRgwo7D8012bx36IO: return
		Tca7NsYPkIRWtBpFgxLZbSmCi('link',oYkzVLIgyjNpsiTbZSBQ+'[COLOR FFC89008]الملفات الأولي بهذه القائمة قد لا تعمل[/COLOR]','',9999)
		if ItpjaAnZOhUEluJQiMm9zGo2v8Dw in ['TIMESHIFT']:
			Mmp2hxGFv1Lo5Jb = 2
			w8lmdARKWLovTMPjrC = Mmp2hxGFv1Lo5Jb*sGOne0xWA5
			niJKWcmRgwo7D8012bx36IO = []
			rhTsY3DS9bojgKOz = int(int(JxuZ9wqO1Fbm6sQNU5raoA8PjW['start_timestamp'])/w8lmdARKWLovTMPjrC)*w8lmdARKWLovTMPjrC
			St9hoc5FMNfDOvEI6A7QamsJVWwBz = F5I1VZzxkXenKuEAYO+w8lmdARKWLovTMPjrC
			V8kFyJt0g1hoY6zRuMQ = int((St9hoc5FMNfDOvEI6A7QamsJVWwBz-rhTsY3DS9bojgKOz)/sGOne0xWA5)
			for AiP7CnItTsZS02c4vogWrVw in range(V8kFyJt0g1hoY6zRuMQ):
				if AiP7CnItTsZS02c4vogWrVw>=6:
					if AiP7CnItTsZS02c4vogWrVw%Mmp2hxGFv1Lo5Jb!=0: continue
					nntqkTFQdC4JgeKWbvj0sORHVz = w8lmdARKWLovTMPjrC
				else: nntqkTFQdC4JgeKWbvj0sORHVz = w8lmdARKWLovTMPjrC//2
				iZfU32pPy0lA5dDrWxCEnuIk6j8HM = rhTsY3DS9bojgKOz+AiP7CnItTsZS02c4vogWrVw*sGOne0xWA5
				JxuZ9wqO1Fbm6sQNU5raoA8PjW = {}
				JxuZ9wqO1Fbm6sQNU5raoA8PjW['title'] = ''
				nHbv7QFEXlKGotj4BAeLdYJ = luMHeSgCBaPrb9KvUjNFqcR.localtime(iZfU32pPy0lA5dDrWxCEnuIk6j8HM-kb3SMugt0LQCmD2dwFHRapPNI4-sGOne0xWA5)
				JxuZ9wqO1Fbm6sQNU5raoA8PjW['start'] = luMHeSgCBaPrb9KvUjNFqcR.strftime('%Y.%m.%d %H:%M:%S',nHbv7QFEXlKGotj4BAeLdYJ)
				JxuZ9wqO1Fbm6sQNU5raoA8PjW['start_timestamp'] = str(iZfU32pPy0lA5dDrWxCEnuIk6j8HM)
				JxuZ9wqO1Fbm6sQNU5raoA8PjW['stop_timestamp'] = str(iZfU32pPy0lA5dDrWxCEnuIk6j8HM+nntqkTFQdC4JgeKWbvj0sORHVz)
				niJKWcmRgwo7D8012bx36IO.append(JxuZ9wqO1Fbm6sQNU5raoA8PjW)
	elif ItpjaAnZOhUEluJQiMm9zGo2v8Dw in ['SHORT_EPG','FULL_EPG']: niJKWcmRgwo7D8012bx36IO = ZfTwrusDx3UeXqbtCla
	if ItpjaAnZOhUEluJQiMm9zGo2v8Dw=='FULL_EPG' and len(niJKWcmRgwo7D8012bx36IO)>0:
		Tca7NsYPkIRWtBpFgxLZbSmCi('link',oYkzVLIgyjNpsiTbZSBQ+'[COLOR FFC89008]هذه قائمة برامج القنوات (جدول فقط)ـ[/COLOR]','',9999)
	ttCaYMOIjP = []
	EoMKR2biY0 = cPwDBuG4HVTCdQ9JmMeoWjNY2hX.getInfoLabel('ListItem.Icon')
	for JxuZ9wqO1Fbm6sQNU5raoA8PjW in niJKWcmRgwo7D8012bx36IO:
		yHAD9oVfdieMNhC = EGTVgQoSu6ZsD.b64decode(JxuZ9wqO1Fbm6sQNU5raoA8PjW['title'])
		if VYMZsxRpcQHPgkaiDKjyoh: yHAD9oVfdieMNhC = yHAD9oVfdieMNhC.decode('utf8')
		iZfU32pPy0lA5dDrWxCEnuIk6j8HM = int(JxuZ9wqO1Fbm6sQNU5raoA8PjW['start_timestamp'])
		aalDH3jwJQ9cT0goYz4 = int(JxuZ9wqO1Fbm6sQNU5raoA8PjW['stop_timestamp'])
		KgpWFY29JRedEjiOfHaUGn = str(int((aalDH3jwJQ9cT0goYz4-iZfU32pPy0lA5dDrWxCEnuIk6j8HM+59)/60))
		ud6Pjcnt2MxWEQ7Z5ySpimI = JxuZ9wqO1Fbm6sQNU5raoA8PjW['start'].replace(' ',':')
		nHbv7QFEXlKGotj4BAeLdYJ = luMHeSgCBaPrb9KvUjNFqcR.localtime(iZfU32pPy0lA5dDrWxCEnuIk6j8HM-sGOne0xWA5)
		PYEiUvRX1D7O2hzCKIcHjqxgS3edpN = luMHeSgCBaPrb9KvUjNFqcR.strftime('%H:%M',nHbv7QFEXlKGotj4BAeLdYJ)
		gxV1zLTsPYfd7eOXi596k = luMHeSgCBaPrb9KvUjNFqcR.strftime('%a',nHbv7QFEXlKGotj4BAeLdYJ)
		if ItpjaAnZOhUEluJQiMm9zGo2v8Dw=='SHORT_EPG': yHAD9oVfdieMNhC = '[COLOR FFFFFF00]'+PYEiUvRX1D7O2hzCKIcHjqxgS3edpN+' ـ '+yHAD9oVfdieMNhC+'[/COLOR]'
		elif ItpjaAnZOhUEluJQiMm9zGo2v8Dw=='TIMESHIFT': yHAD9oVfdieMNhC = gxV1zLTsPYfd7eOXi596k+' '+PYEiUvRX1D7O2hzCKIcHjqxgS3edpN+' ('+KgpWFY29JRedEjiOfHaUGn+'min)'
		else: yHAD9oVfdieMNhC = gxV1zLTsPYfd7eOXi596k+' '+PYEiUvRX1D7O2hzCKIcHjqxgS3edpN+' ('+KgpWFY29JRedEjiOfHaUGn+'min)   '+yHAD9oVfdieMNhC+' ـ'
		if ItpjaAnZOhUEluJQiMm9zGo2v8Dw in ['ARCHIVED','FULL_EPG','TIMESHIFT']:
			gvWBYqV3zbRahrCO5IcUs = lBeGVXTt0qD+'/timeshift/'+v1IzDVTBhweb3tRr6YCyoNK+'/'+LX35qsjfcIWaDT8S462+'/'+KgpWFY29JRedEjiOfHaUGn+'/'+ud6Pjcnt2MxWEQ7Z5ySpimI+'/'+jsINZ1EbOvtS7o0+'.m3u8'
			if ItpjaAnZOhUEluJQiMm9zGo2v8Dw=='FULL_EPG': Tca7NsYPkIRWtBpFgxLZbSmCi('link',oYkzVLIgyjNpsiTbZSBQ+yHAD9oVfdieMNhC,gvWBYqV3zbRahrCO5IcUs,9999,EoMKR2biY0,'','','',{'folder':fTLHoIGS2JMYV3jKh7DuW0ke})
			else: Tca7NsYPkIRWtBpFgxLZbSmCi('video',oYkzVLIgyjNpsiTbZSBQ+yHAD9oVfdieMNhC,gvWBYqV3zbRahrCO5IcUs,235,EoMKR2biY0,'','','',{'folder':fTLHoIGS2JMYV3jKh7DuW0ke})
		ttCaYMOIjP.append(yHAD9oVfdieMNhC)
	if ItpjaAnZOhUEluJQiMm9zGo2v8Dw=='SHORT_EPG' and ttCaYMOIjP: ftK9bQvj7XPpZclWN3Ua5eM = JZ83rVRIumz4KGT(ttCaYMOIjP)
	return ttCaYMOIjP
def UMPvFx2RpQTh3LfNYlqSyZz(fTLHoIGS2JMYV3jKh7DuW0ke):
	if not KHWOFrzptwybYx(fTLHoIGS2JMYV3jKh7DuW0ke,True): return
	lBeGVXTt0qD,oNtZdsy79vzERYi4,rrxJeOaK4dA = '',0,0
	Q4o2IDnNJzcYe,VzPym8fW6lKD1bpeZGnRCBs,MnAvyj3DZthLSIo = FhYAZG1ur2sQRtTX9DlOcx3WILv(fTLHoIGS2JMYV3jKh7DuW0ke,False)
	if Q4o2IDnNJzcYe:
		lLmqPQIs0MX5b2t9Bfo = W2wvbMy1zCOsHLnoX4BSJfq9(VzPym8fW6lKD1bpeZGnRCBs)
		oNtZdsy79vzERYi4 = eLsVYNQShdAc0mapgIFbu34l(lLmqPQIs0MX5b2t9Bfo[0],int(MnAvyj3DZthLSIo))
		sEyDZTBxj9l = cHa5JRAQ3ZKku7(fTLHoIGS2JMYV3jKh7DuW0ke,'LIVE_GROUPED')
		EETCAlxZ1nfYG4DjKkVBReU8pFu2yX = NUauTXxKLAoqQtJkglSFRWE(sEyDZTBxj9l,'list','LIVE_GROUPED')
		bb2Wi1TrnXpSA4wgfszMvcxd0O3mL = NUauTXxKLAoqQtJkglSFRWE(sEyDZTBxj9l,'list','LIVE_GROUPED',EETCAlxZ1nfYG4DjKkVBReU8pFu2yX[1])
		gC2hO80boRyM7TBGqD = bb2Wi1TrnXpSA4wgfszMvcxd0O3mL[0][2]
		YNH1Vsv7MuA9cpTjRzox = ZXFs0mEPR8qI2zj.findall('://(.*?)/',gC2hO80boRyM7TBGqD,ZXFs0mEPR8qI2zj.DOTALL)
		YNH1Vsv7MuA9cpTjRzox = YNH1Vsv7MuA9cpTjRzox[0]
		if ':' in YNH1Vsv7MuA9cpTjRzox: Fnjfv2NXGMk15sQmeDAZxKc0Tzq,BDvMt1r7xFXOWa = YNH1Vsv7MuA9cpTjRzox.split(':')
		else: Fnjfv2NXGMk15sQmeDAZxKc0Tzq,BDvMt1r7xFXOWa = YNH1Vsv7MuA9cpTjRzox,'80'
		w80J6USRmacdgtb = W2wvbMy1zCOsHLnoX4BSJfq9(Fnjfv2NXGMk15sQmeDAZxKc0Tzq)
		rrxJeOaK4dA = eLsVYNQShdAc0mapgIFbu34l(w80J6USRmacdgtb[0],int(BDvMt1r7xFXOWa))
	if oNtZdsy79vzERYi4 and rrxJeOaK4dA:
		LaX1QCyeIJ = 'هل تريد استخدام السيرفر الأصلي أم السيرفر الأسرع ؟!!'
		LaX1QCyeIJ += '\n\n'+'وقت ضائع في السيرفر الأصلي'+'\n'+str(int(rrxJeOaK4dA*1000))+' ملي ثانية'
		LaX1QCyeIJ += '\n\n'+'وقت ضائع في السيرفر البديل'+'\n'+str(int(oNtZdsy79vzERYi4*1000))+' ملي ثانية'
		Bkab1Avo3fYG9s6lZcOITDXd4MFi = OxCB4medn1('center','السيرفر الأصلي','السيرفر الأسرع','رسالة من المبرمج',LaX1QCyeIJ)
		if Bkab1Avo3fYG9s6lZcOITDXd4MFi==1 and oNtZdsy79vzERYi4<rrxJeOaK4dA: lBeGVXTt0qD = VzPym8fW6lKD1bpeZGnRCBs+':'+MnAvyj3DZthLSIo
	else: HHTzVhiY079bvdluNkFQ4wCMpe('','','رسالة من المبرمج','البرنامج لم يجد السيرفر البديل')
	j2agIU0xsLS6c7T.setSetting('av.iptv.server_'+fTLHoIGS2JMYV3jKh7DuW0ke,lBeGVXTt0qD)
	return
def jXYwiO9D056pkrzRh1y8tfWJxQoaI3(fTLHoIGS2JMYV3jKh7DuW0ke,gC2hO80boRyM7TBGqD,RGDQbxHAi1UpIuNveqTFXSw9gZjc4):
	u5b39JYiNdS8ejFzt4ch = j2agIU0xsLS6c7T.getSetting('av.iptv.useragent_'+fTLHoIGS2JMYV3jKh7DuW0ke)
	vvePnQc9hCHO6zKwpjk1byRSF = j2agIU0xsLS6c7T.getSetting('av.iptv.referer_'+fTLHoIGS2JMYV3jKh7DuW0ke)
	if u5b39JYiNdS8ejFzt4ch or vvePnQc9hCHO6zKwpjk1byRSF:
		gC2hO80boRyM7TBGqD += '|'
		if u5b39JYiNdS8ejFzt4ch: gC2hO80boRyM7TBGqD += '&User-Agent='+u5b39JYiNdS8ejFzt4ch
		if vvePnQc9hCHO6zKwpjk1byRSF: gC2hO80boRyM7TBGqD += '&Referer='+vvePnQc9hCHO6zKwpjk1byRSF
		gC2hO80boRyM7TBGqD = gC2hO80boRyM7TBGqD.replace('|&','|')
	FmyXZnI51UO0 = j2agIU0xsLS6c7T.getSetting('av.iptv.server_'+fTLHoIGS2JMYV3jKh7DuW0ke)
	if FmyXZnI51UO0:
		QCPtb4FAdqu9sE = ZXFs0mEPR8qI2zj.findall('://(.*?)/',gC2hO80boRyM7TBGqD,ZXFs0mEPR8qI2zj.DOTALL)
		gC2hO80boRyM7TBGqD = gC2hO80boRyM7TBGqD.replace(QCPtb4FAdqu9sE[0],FmyXZnI51UO0)
	w3hq0Xp8D9rZJ(gC2hO80boRyM7TBGqD,LBtjHDg8yZz69QOp,RGDQbxHAi1UpIuNveqTFXSw9gZjc4)
	return
def MQ0WAOIYobmyxS6akuziJG(fTLHoIGS2JMYV3jKh7DuW0ke):
	HHTzVhiY079bvdluNkFQ4wCMpe('','','رسالة من المبرمج','تحذير مهم وهام جدا . يرجى عدم تغييره إذا كنت لا تعرف ما هو .  وعدم تغييره إلا عند الضرورة القصوى . الحاجة لهذا التغيير هي فقط إذا طلبت منك شركة ـIPTV أن تعمل هذا التغيير . وفقط عندما تستخدم خدمة ـIPTV تحتاج ـUser-Agent خاص')
	u5b39JYiNdS8ejFzt4ch = j2agIU0xsLS6c7T.getSetting('av.iptv.useragent_'+fTLHoIGS2JMYV3jKh7DuW0ke)
	klxDtdGLjS2Qv0ymBXMeziC = OxCB4medn1('center','استخدام الأصلي','تعديل القديم',u5b39JYiNdS8ejFzt4ch,'هذا هو ـUser-Agent المستخدم حاليا مع ـIPTV الذي في هذا البرنامج . هل تريد تعديله أم تريد إعادته إلى وضعية التثبيت الأصلي والتي تقريبا تناسب جميع شركات ـIPTV ؟!')
	if klxDtdGLjS2Qv0ymBXMeziC==1: u5b39JYiNdS8ejFzt4ch = CjyEnpfQ23o0PYwDtLId('أكتب ـIPTV User-Agent جديد',u5b39JYiNdS8ejFzt4ch,True)
	else: u5b39JYiNdS8ejFzt4ch = 'Unknown'
	if u5b39JYiNdS8ejFzt4ch==' ':
		HHTzVhiY079bvdluNkFQ4wCMpe('','','رسالة من المبرمج','غير مسموح أستخدام فراغ لوحده أو عدة فراغات لوحدها ... يجب إما تركه فارغ تماما أو إضافة حرف أو أي شي آخر معها')
		return
	klxDtdGLjS2Qv0ymBXMeziC = OxCB4medn1('center','','',u5b39JYiNdS8ejFzt4ch,'هل تريد استخدام هذا ـUser-Agent بدلا من  القديم ؟')
	if klxDtdGLjS2Qv0ymBXMeziC!=1:
		HHTzVhiY079bvdluNkFQ4wCMpe('','','رسالة من المبرمج','تم الإلغاء')
		return
	j2agIU0xsLS6c7T.setSetting('av.iptv.useragent_'+fTLHoIGS2JMYV3jKh7DuW0ke,u5b39JYiNdS8ejFzt4ch)
	m8mDHu2eZKoJCMXw3bPrUz(fTLHoIGS2JMYV3jKh7DuW0ke)
	return
def sYyPU0CzeIgLmG7pjBq4uDJO(fTLHoIGS2JMYV3jKh7DuW0ke):
	HHTzVhiY079bvdluNkFQ4wCMpe('','','رسالة من المبرمج','تحذير مهم وهام جدا . يرجى عدم تغييره إذا كنت لا تعرف ما هو .  وعدم تغييره إلا عند الضرورة القصوى . الحاجة لهذا التغيير هي فقط إذا طلبت منك شركة ـIPTV أن تعمل هذا التغيير . وفقط عندما تستخدم خدمة ـIPTV تحتاج ـReferer خاص')
	vvePnQc9hCHO6zKwpjk1byRSF = j2agIU0xsLS6c7T.getSetting('av.iptv.referer_'+fTLHoIGS2JMYV3jKh7DuW0ke)
	klxDtdGLjS2Qv0ymBXMeziC = OxCB4medn1('center','استخدام الأصلي','تعديل القديم',vvePnQc9hCHO6zKwpjk1byRSF,'هذا هو ـReferer المستخدم حاليا مع ـIPTV الذي في هذا البرنامج . هل تريد تعديله أم تريد إعادته إلى وضعية التثبيت الأصلي والتي تقريبا تناسب جميع شركات ـIPTV ؟!')
	if klxDtdGLjS2Qv0ymBXMeziC==1: vvePnQc9hCHO6zKwpjk1byRSF = CjyEnpfQ23o0PYwDtLId('أكتب ـIPTV Referer جديد',vvePnQc9hCHO6zKwpjk1byRSF,True)
	else: vvePnQc9hCHO6zKwpjk1byRSF = ''
	if vvePnQc9hCHO6zKwpjk1byRSF==' ':
		HHTzVhiY079bvdluNkFQ4wCMpe('','','رسالة من المبرمج','غير مسموح أستخدام فراغ لوحده أو عدة فراغات لوحدها ... يجب إما تركه فارغ تماما أو إضافة حرف أو أي شي آخر معها')
		return
	klxDtdGLjS2Qv0ymBXMeziC = OxCB4medn1('center','','',vvePnQc9hCHO6zKwpjk1byRSF,'هل تريد استخدام هذا ـReferer بدلا من  القديم ؟')
	if klxDtdGLjS2Qv0ymBXMeziC!=1:
		HHTzVhiY079bvdluNkFQ4wCMpe('','','رسالة من المبرمج','تم الإلغاء')
		return
	j2agIU0xsLS6c7T.setSetting('av.iptv.referer_'+fTLHoIGS2JMYV3jKh7DuW0ke,vvePnQc9hCHO6zKwpjk1byRSF)
	m8mDHu2eZKoJCMXw3bPrUz(fTLHoIGS2JMYV3jKh7DuW0ke)
	return
def gmcELYbTJS(fTLHoIGS2JMYV3jKh7DuW0ke,FYaj2tyOXLokih=''):
	if not FYaj2tyOXLokih: FYaj2tyOXLokih = j2agIU0xsLS6c7T.getSetting('av.iptv.url_'+fTLHoIGS2JMYV3jKh7DuW0ke)
	lBeGVXTt0qD = d78KRnJmBWscGua0XMk(FYaj2tyOXLokih,'url')
	v1IzDVTBhweb3tRr6YCyoNK = ZXFs0mEPR8qI2zj.findall('username=(.*?)&',FYaj2tyOXLokih+'&',ZXFs0mEPR8qI2zj.DOTALL)
	LX35qsjfcIWaDT8S462 = ZXFs0mEPR8qI2zj.findall('password=(.*?)&',FYaj2tyOXLokih+'&',ZXFs0mEPR8qI2zj.DOTALL)
	if not v1IzDVTBhweb3tRr6YCyoNK or not LX35qsjfcIWaDT8S462:
		HHTzVhiY079bvdluNkFQ4wCMpe('','','فحص اشتراك ـIPTV','رابط اشتراك ـIPTV الذي قمت انت بإضافته إلى البرنامج لا يعمل أو الرابط غير موجود في البرنامج . أذهب إلى قائمة اشتراك ـIPTV وقم بإضافة رابط ـIPTV جديد أو قم بإصلاح الرابط القديم')
		return '','','','',''
	v1IzDVTBhweb3tRr6YCyoNK = v1IzDVTBhweb3tRr6YCyoNK[0]
	LX35qsjfcIWaDT8S462 = LX35qsjfcIWaDT8S462[0]
	LLmOgfvERFwWp9DQMoBHS36rd = lBeGVXTt0qD+'/player_api.php?username='+v1IzDVTBhweb3tRr6YCyoNK+'&password='+LX35qsjfcIWaDT8S462
	fUSnuQTRBwOtFhZz36k9y = lBeGVXTt0qD+'/get.php?username='+v1IzDVTBhweb3tRr6YCyoNK+'&password='+LX35qsjfcIWaDT8S462+'&type=m3u_plus'
	return LLmOgfvERFwWp9DQMoBHS36rd,fUSnuQTRBwOtFhZz36k9y,lBeGVXTt0qD,v1IzDVTBhweb3tRr6YCyoNK,LX35qsjfcIWaDT8S462
def Dmvykqd62HxYAFnOE359U(fTLHoIGS2JMYV3jKh7DuW0ke,bilOMVBfCKYU0a4Fqs3HX9hA=''):
	L69Ll5ObZkDPewd = bilOMVBfCKYU0a4Fqs3HX9hA.replace('/','_').replace(':','_').replace('.','_')
	L69Ll5ObZkDPewd = L69Ll5ObZkDPewd.replace('?','_').replace('=','_').replace('&','_')
	L69Ll5ObZkDPewd = hhHq8m5vauKG9dl.path.join(mATvU6VbxOXNFhz8lK5WGrfQ,L69Ll5ObZkDPewd).strip('.m3u')+'.m3u'
	return L69Ll5ObZkDPewd
def gmfoXnU7hlQ5qL9euC(fTLHoIGS2JMYV3jKh7DuW0ke):
	mOYxwokQAF = j2agIU0xsLS6c7T.getSetting('av.iptv.url_'+fTLHoIGS2JMYV3jKh7DuW0ke)
	wBC16NmY2nRFuctZJxAGTEl0 = True
	if mOYxwokQAF:
		klxDtdGLjS2Qv0ymBXMeziC = A0iaw7hK4Qmc2EeHXZB('center','كتابة جديد','تعديل القديم','مسح القديم','الرابط الحالي هو:','[COLOR FFC89008]'+mOYxwokQAF+'[/COLOR]'+'\n\n هذا هو رابط ـIPTV المسجل في البرنامج ... هل تريد تعديله أم تريد كتابة رابط جديد ؟!')
		if klxDtdGLjS2Qv0ymBXMeziC==-1: return
		elif klxDtdGLjS2Qv0ymBXMeziC==0: mOYxwokQAF = ''
		elif klxDtdGLjS2Qv0ymBXMeziC==2:
			klxDtdGLjS2Qv0ymBXMeziC = OxCB4medn1('center','','','رسالة من المبرمج','هل تريد مسح الرابط المسجل في البرنامج ؟!')
			if klxDtdGLjS2Qv0ymBXMeziC in [-1,0]: return
			HHTzVhiY079bvdluNkFQ4wCMpe('','','رسالة من المبرمج','تم مسح الرابط')
			wBC16NmY2nRFuctZJxAGTEl0 = False
			QAEmT521BwXp4aKNniFURcgqVb = ''
	if wBC16NmY2nRFuctZJxAGTEl0:
		QAEmT521BwXp4aKNniFURcgqVb = CjyEnpfQ23o0PYwDtLId('اكتب رابط ـIPTV كاملا',mOYxwokQAF)
		QAEmT521BwXp4aKNniFURcgqVb = QAEmT521BwXp4aKNniFURcgqVb.strip(' ')
		if not QAEmT521BwXp4aKNniFURcgqVb:
			klxDtdGLjS2Qv0ymBXMeziC = OxCB4medn1('center','','','رسالة من المبرمج','لقد قمت بإدخال رابط فارغ .. هل تريد مسح الرابط المسجل في البرنامج ؟!')
			if klxDtdGLjS2Qv0ymBXMeziC in [-1,0]: return
			HHTzVhiY079bvdluNkFQ4wCMpe('','','رسالة من المبرمج','تم مسح الرابط')
	else:
		LLmOgfvERFwWp9DQMoBHS36rd,fUSnuQTRBwOtFhZz36k9y,lBeGVXTt0qD,v1IzDVTBhweb3tRr6YCyoNK,LX35qsjfcIWaDT8S462 = gmcELYbTJS(fTLHoIGS2JMYV3jKh7DuW0ke,QAEmT521BwXp4aKNniFURcgqVb)
		if not v1IzDVTBhweb3tRr6YCyoNK: return
		LaX1QCyeIJ = 'هذه المعلومات تم أخذها من رابط ـIPTV الذي انت كتبته . هل تريد استخدامها ؟!\n'
		LaX1QCyeIJ += '\n[COLOR FFFFFF00]'+lBeGVXTt0qD+'[/COLOR]عنوان السيرفر: '
		LaX1QCyeIJ += '\n[COLOR FFFFFF00]'+v1IzDVTBhweb3tRr6YCyoNK+'[/COLOR]اسم المستخدم: '
		LaX1QCyeIJ += '\n[COLOR FFFFFF00]'+LX35qsjfcIWaDT8S462+'[/COLOR]كلمة السر: '
		klxDtdGLjS2Qv0ymBXMeziC = OxCB4medn1('right','','','الرابط الجديد هو:','[COLOR FFC89008]'+QAEmT521BwXp4aKNniFURcgqVb+'[/COLOR]'+'\n\n'+LaX1QCyeIJ)
		if klxDtdGLjS2Qv0ymBXMeziC!=1:
			HHTzVhiY079bvdluNkFQ4wCMpe('','','رسالة من المبرمج','تم الإلغاء')
			return
	j2agIU0xsLS6c7T.setSetting('av.iptv.url_'+fTLHoIGS2JMYV3jKh7DuW0ke,QAEmT521BwXp4aKNniFURcgqVb)
	j2agIU0xsLS6c7T.setSetting('av.iptv.timestamp_'+fTLHoIGS2JMYV3jKh7DuW0ke,'')
	j2agIU0xsLS6c7T.setSetting('av.iptv.timediff_'+fTLHoIGS2JMYV3jKh7DuW0ke,'')
	u5b39JYiNdS8ejFzt4ch = j2agIU0xsLS6c7T.getSetting('av.iptv.useragent_'+fTLHoIGS2JMYV3jKh7DuW0ke)
	if not u5b39JYiNdS8ejFzt4ch: j2agIU0xsLS6c7T.setSetting('av.iptv.useragent_'+fTLHoIGS2JMYV3jKh7DuW0ke,'Unknown')
	gyYqvWU6RaZVS9zoFGE = OxCB4medn1('center','','','',QAEmT521BwXp4aKNniFURcgqVb+'\n\nتم تغير رابط اشتراك ـIPTV إلى هذا الرابط الجديد ... هل تريد فحص هذا الرابط الآن ؟')
	if gyYqvWU6RaZVS9zoFGE==1: Q4o2IDnNJzcYe,VzPym8fW6lKD1bpeZGnRCBs,MnAvyj3DZthLSIo = FhYAZG1ur2sQRtTX9DlOcx3WILv(fTLHoIGS2JMYV3jKh7DuW0ke,True)
	m8mDHu2eZKoJCMXw3bPrUz(fTLHoIGS2JMYV3jKh7DuW0ke)
	return
def Wc9NgOYMzATtBHIGyQKswJj(dUkqersWvMoJ964,DG5RtsncgN,Czpk8MuF2DoYdHfLb,jTG1aFtB8HM4zLXoUQygVu0RcOhv,D1kz5HhyWldovxibLINCm4603,ood6Gh9mLZIcrSUO0zVERjsikg7x,fUSnuQTRBwOtFhZz36k9y):
	bb2Wi1TrnXpSA4wgfszMvcxd0O3mL,HqPjEyicVxGJ7QuvaT = [],[]
	YUdNZBwpuE0AC8grQ57mj2 = ['.avi','.mp4','.mkv','.mp3','.webm','.aac']
	for FFhKw05es4jgM in dUkqersWvMoJ964:
		if ood6Gh9mLZIcrSUO0zVERjsikg7x%473==0:
			b8bEl0XjyR4hACKcYkJVP2oBavnGm1(jTG1aFtB8HM4zLXoUQygVu0RcOhv,40+int(10*ood6Gh9mLZIcrSUO0zVERjsikg7x/D1kz5HhyWldovxibLINCm4603),'قراءة الفيديوهات','الفيديو رقم:-',str(ood6Gh9mLZIcrSUO0zVERjsikg7x)+' / '+str(D1kz5HhyWldovxibLINCm4603))
			if jTG1aFtB8HM4zLXoUQygVu0RcOhv.iscanceled():
				jTG1aFtB8HM4zLXoUQygVu0RcOhv.close()
				return None,None,None
		gC2hO80boRyM7TBGqD = ZXFs0mEPR8qI2zj.findall('^(.*?)\n+((http|https|rtmp).*?)$',FFhKw05es4jgM,ZXFs0mEPR8qI2zj.DOTALL)
		if gC2hO80boRyM7TBGqD:
			FFhKw05es4jgM,gC2hO80boRyM7TBGqD,vWK3cmrB9SsT4dLwU = gC2hO80boRyM7TBGqD[0]
			gC2hO80boRyM7TBGqD = gC2hO80boRyM7TBGqD.replace('\n','')
			FFhKw05es4jgM = FFhKw05es4jgM.replace('\n','')
		else:
			HqPjEyicVxGJ7QuvaT.append({'line':FFhKw05es4jgM})
			continue
		BLjVTYG6NodRPI3ZJtSWrCEaxHqh9y,dGlmU8JqW5yFAtcsg,aBXgWuYGwdyS8k0jF4efM5QOcDL,yHAD9oVfdieMNhC,RGDQbxHAi1UpIuNveqTFXSw9gZjc4,HtQJpWPblFaZ92EwsGkYoIVD70KBrm = {},'','','','',False
		try:
			FFhKw05es4jgM,yHAD9oVfdieMNhC = FFhKw05es4jgM.rsplit('",',1)
			FFhKw05es4jgM = FFhKw05es4jgM+'"'
		except:
			try: FFhKw05es4jgM,yHAD9oVfdieMNhC = FFhKw05es4jgM.rsplit('1,',1)
			except: yHAD9oVfdieMNhC = ''
		BLjVTYG6NodRPI3ZJtSWrCEaxHqh9y['url'] = gC2hO80boRyM7TBGqD
		jHuDViB2aPTFc9UOn3m7foJyER = ZXFs0mEPR8qI2zj.findall(' (.*?)="(.*?)"',FFhKw05es4jgM,ZXFs0mEPR8qI2zj.DOTALL)
		for JDv1uYxBEPcFGwrmlfzSOC,pnhqzFt6AOer1xoR4jUJ in jHuDViB2aPTFc9UOn3m7foJyER:
			JDv1uYxBEPcFGwrmlfzSOC = JDv1uYxBEPcFGwrmlfzSOC.replace('"','').strip(' ')
			BLjVTYG6NodRPI3ZJtSWrCEaxHqh9y[JDv1uYxBEPcFGwrmlfzSOC] = pnhqzFt6AOer1xoR4jUJ.strip(' ')
		ELVFhdrW0OgAu94cJXl = list(BLjVTYG6NodRPI3ZJtSWrCEaxHqh9y.keys())
		if not yHAD9oVfdieMNhC:
			if 'name' in ELVFhdrW0OgAu94cJXl and BLjVTYG6NodRPI3ZJtSWrCEaxHqh9y['name']: yHAD9oVfdieMNhC = BLjVTYG6NodRPI3ZJtSWrCEaxHqh9y['name']
		BLjVTYG6NodRPI3ZJtSWrCEaxHqh9y['title'] = yHAD9oVfdieMNhC.strip(' ').replace('  ',' ').replace('  ',' ')
		if 'logo' in ELVFhdrW0OgAu94cJXl:
			BLjVTYG6NodRPI3ZJtSWrCEaxHqh9y['img'] = BLjVTYG6NodRPI3ZJtSWrCEaxHqh9y['logo']
			del BLjVTYG6NodRPI3ZJtSWrCEaxHqh9y['logo']
		else: BLjVTYG6NodRPI3ZJtSWrCEaxHqh9y['img'] = ''
		if 'group' in ELVFhdrW0OgAu94cJXl and BLjVTYG6NodRPI3ZJtSWrCEaxHqh9y['group']: aBXgWuYGwdyS8k0jF4efM5QOcDL = BLjVTYG6NodRPI3ZJtSWrCEaxHqh9y['group']
		if any(AARNPWHjQU9dEmDI in gC2hO80boRyM7TBGqD.lower() for AARNPWHjQU9dEmDI in YUdNZBwpuE0AC8grQ57mj2):
			HtQJpWPblFaZ92EwsGkYoIVD70KBrm = True if 'm3u' not in gC2hO80boRyM7TBGqD else False
		if HtQJpWPblFaZ92EwsGkYoIVD70KBrm or '__SERIES__' in aBXgWuYGwdyS8k0jF4efM5QOcDL or '__MOVIES__' in aBXgWuYGwdyS8k0jF4efM5QOcDL:
			RGDQbxHAi1UpIuNveqTFXSw9gZjc4 = 'VOD'
			if '__SERIES__' in aBXgWuYGwdyS8k0jF4efM5QOcDL: RGDQbxHAi1UpIuNveqTFXSw9gZjc4 = RGDQbxHAi1UpIuNveqTFXSw9gZjc4+'_SERIES'
			elif '__MOVIES__' in aBXgWuYGwdyS8k0jF4efM5QOcDL: RGDQbxHAi1UpIuNveqTFXSw9gZjc4 = RGDQbxHAi1UpIuNveqTFXSw9gZjc4+'_MOVIES'
			else: RGDQbxHAi1UpIuNveqTFXSw9gZjc4 = RGDQbxHAi1UpIuNveqTFXSw9gZjc4+'_UNKNOWN'
			aBXgWuYGwdyS8k0jF4efM5QOcDL = aBXgWuYGwdyS8k0jF4efM5QOcDL.replace('__SERIES__','').replace('__MOVIES__','')
		else:
			RGDQbxHAi1UpIuNveqTFXSw9gZjc4 = 'LIVE'
			if yHAD9oVfdieMNhC in DG5RtsncgN: dGlmU8JqW5yFAtcsg = dGlmU8JqW5yFAtcsg+'_EPG'
			if yHAD9oVfdieMNhC in Czpk8MuF2DoYdHfLb: dGlmU8JqW5yFAtcsg = dGlmU8JqW5yFAtcsg+'_ARCHIVED'
			if not aBXgWuYGwdyS8k0jF4efM5QOcDL: RGDQbxHAi1UpIuNveqTFXSw9gZjc4 = RGDQbxHAi1UpIuNveqTFXSw9gZjc4+'_UNKNOWN'
			else: RGDQbxHAi1UpIuNveqTFXSw9gZjc4 = RGDQbxHAi1UpIuNveqTFXSw9gZjc4+dGlmU8JqW5yFAtcsg
		aBXgWuYGwdyS8k0jF4efM5QOcDL = aBXgWuYGwdyS8k0jF4efM5QOcDL.strip(' ').replace('  ',' ').replace('  ',' ')
		if 'LIVE_UNKNOWN' in RGDQbxHAi1UpIuNveqTFXSw9gZjc4: aBXgWuYGwdyS8k0jF4efM5QOcDL = '!!__UNKNOWN_LIVE__!!'
		elif 'VOD_UNKNOWN' in RGDQbxHAi1UpIuNveqTFXSw9gZjc4: aBXgWuYGwdyS8k0jF4efM5QOcDL = '!!__UNKNOWN_VOD__!!'
		elif 'VOD_SERIES' in RGDQbxHAi1UpIuNveqTFXSw9gZjc4:
			w9wrRhtS84cAoKGx735W = ZXFs0mEPR8qI2zj.findall('(.*?) [Ss]\d+ +[Ee]\d+',BLjVTYG6NodRPI3ZJtSWrCEaxHqh9y['title'],ZXFs0mEPR8qI2zj.DOTALL)
			if w9wrRhtS84cAoKGx735W: w9wrRhtS84cAoKGx735W = w9wrRhtS84cAoKGx735W[0]
			else: w9wrRhtS84cAoKGx735W = '!!__UNKNOWN_SERIES__!!'
			aBXgWuYGwdyS8k0jF4efM5QOcDL = aBXgWuYGwdyS8k0jF4efM5QOcDL+'__SERIES__'+w9wrRhtS84cAoKGx735W
		if 'id' in ELVFhdrW0OgAu94cJXl: del BLjVTYG6NodRPI3ZJtSWrCEaxHqh9y['id']
		if 'ID' in ELVFhdrW0OgAu94cJXl: del BLjVTYG6NodRPI3ZJtSWrCEaxHqh9y['ID']
		if 'name' in ELVFhdrW0OgAu94cJXl: del BLjVTYG6NodRPI3ZJtSWrCEaxHqh9y['name']
		yHAD9oVfdieMNhC = BLjVTYG6NodRPI3ZJtSWrCEaxHqh9y['title']
		yHAD9oVfdieMNhC = WhJe7bGx5XackTwOIZVLC8ut(yHAD9oVfdieMNhC)
		yHAD9oVfdieMNhC = lCTNoZzaXywGWeLQ(yHAD9oVfdieMNhC)
		KfCRA3emhxGI4YTNBl98pUju21,aBXgWuYGwdyS8k0jF4efM5QOcDL = EliFfhxjYr37VyDC(aBXgWuYGwdyS8k0jF4efM5QOcDL)
		yAS92Iz54TLMZagtYjd,yHAD9oVfdieMNhC = EliFfhxjYr37VyDC(yHAD9oVfdieMNhC)
		BLjVTYG6NodRPI3ZJtSWrCEaxHqh9y['type'] = RGDQbxHAi1UpIuNveqTFXSw9gZjc4
		BLjVTYG6NodRPI3ZJtSWrCEaxHqh9y['context'] = dGlmU8JqW5yFAtcsg
		BLjVTYG6NodRPI3ZJtSWrCEaxHqh9y['group'] = aBXgWuYGwdyS8k0jF4efM5QOcDL.upper()
		BLjVTYG6NodRPI3ZJtSWrCEaxHqh9y['title'] = yHAD9oVfdieMNhC.upper()
		BLjVTYG6NodRPI3ZJtSWrCEaxHqh9y['country'] = yAS92Iz54TLMZagtYjd.upper()
		BLjVTYG6NodRPI3ZJtSWrCEaxHqh9y['language'] = KfCRA3emhxGI4YTNBl98pUju21.upper()
		bb2Wi1TrnXpSA4wgfszMvcxd0O3mL.append(BLjVTYG6NodRPI3ZJtSWrCEaxHqh9y)
		ood6Gh9mLZIcrSUO0zVERjsikg7x += 1
	return bb2Wi1TrnXpSA4wgfszMvcxd0O3mL,ood6Gh9mLZIcrSUO0zVERjsikg7x,HqPjEyicVxGJ7QuvaT
def lCTNoZzaXywGWeLQ(yHAD9oVfdieMNhC):
	yHAD9oVfdieMNhC = yHAD9oVfdieMNhC.replace('  ',' ').replace('  ',' ').replace('  ',' ')
	yHAD9oVfdieMNhC = yHAD9oVfdieMNhC.replace('||','|').replace('___',':').replace('--','-')
	yHAD9oVfdieMNhC = yHAD9oVfdieMNhC.replace('[[','[').replace(']]',']')
	yHAD9oVfdieMNhC = yHAD9oVfdieMNhC.replace('((','(').replace('))',')')
	yHAD9oVfdieMNhC = yHAD9oVfdieMNhC.replace('<<','<').replace('>>','>')
	yHAD9oVfdieMNhC = yHAD9oVfdieMNhC.strip(' ')
	return yHAD9oVfdieMNhC
def a1djBECx0zOTRkKAtI(TuVNhRcQHgtwDbMqE53FJz,jTG1aFtB8HM4zLXoUQygVu0RcOhv):
	ggVZAItpXbPW6cq = {}
	for ffaXcwQevDRLGm2 in FJLMxd8alBC7QbDKU9Onu2fw: ggVZAItpXbPW6cq[ffaXcwQevDRLGm2] = []
	D1kz5HhyWldovxibLINCm4603 = len(TuVNhRcQHgtwDbMqE53FJz)
	GpFnKA1stoN = str(D1kz5HhyWldovxibLINCm4603)
	ood6Gh9mLZIcrSUO0zVERjsikg7x = 0
	HqPjEyicVxGJ7QuvaT = []
	for BLjVTYG6NodRPI3ZJtSWrCEaxHqh9y in TuVNhRcQHgtwDbMqE53FJz:
		if ood6Gh9mLZIcrSUO0zVERjsikg7x%873==0:
			b8bEl0XjyR4hACKcYkJVP2oBavnGm1(jTG1aFtB8HM4zLXoUQygVu0RcOhv,50+int(5*ood6Gh9mLZIcrSUO0zVERjsikg7x/D1kz5HhyWldovxibLINCm4603),'تصنيف الفيديوهات الغير مرتبة','الفيديو رقم:-',str(ood6Gh9mLZIcrSUO0zVERjsikg7x)+' / '+GpFnKA1stoN)
			if jTG1aFtB8HM4zLXoUQygVu0RcOhv.iscanceled():
				jTG1aFtB8HM4zLXoUQygVu0RcOhv.close()
				return None,None
		aBXgWuYGwdyS8k0jF4efM5QOcDL,dGlmU8JqW5yFAtcsg,yHAD9oVfdieMNhC,gC2hO80boRyM7TBGqD,EoMKR2biY0 = BLjVTYG6NodRPI3ZJtSWrCEaxHqh9y['group'],BLjVTYG6NodRPI3ZJtSWrCEaxHqh9y['context'],BLjVTYG6NodRPI3ZJtSWrCEaxHqh9y['title'],BLjVTYG6NodRPI3ZJtSWrCEaxHqh9y['url'],BLjVTYG6NodRPI3ZJtSWrCEaxHqh9y['img']
		yAS92Iz54TLMZagtYjd,KfCRA3emhxGI4YTNBl98pUju21,ffaXcwQevDRLGm2 = BLjVTYG6NodRPI3ZJtSWrCEaxHqh9y['country'],BLjVTYG6NodRPI3ZJtSWrCEaxHqh9y['language'],BLjVTYG6NodRPI3ZJtSWrCEaxHqh9y['type']
		IY8dOXtURSM5Eb23mW7vK = (aBXgWuYGwdyS8k0jF4efM5QOcDL,dGlmU8JqW5yFAtcsg,yHAD9oVfdieMNhC,gC2hO80boRyM7TBGqD,EoMKR2biY0)
		pUCIzcEWGZJy = False
		if 'LIVE' in ffaXcwQevDRLGm2:
			if 'UNKNOWN' in ffaXcwQevDRLGm2: ggVZAItpXbPW6cq['LIVE_UNKNOWN_GROUPED'].append(IY8dOXtURSM5Eb23mW7vK)
			elif 'LIVE' in ffaXcwQevDRLGm2: ggVZAItpXbPW6cq['LIVE_GROUPED'].append(IY8dOXtURSM5Eb23mW7vK)
			else: pUCIzcEWGZJy = True
			ggVZAItpXbPW6cq['LIVE_ORIGINAL_GROUPED'].append(IY8dOXtURSM5Eb23mW7vK)
		elif 'VOD' in ffaXcwQevDRLGm2:
			if 'UNKNOWN' in ffaXcwQevDRLGm2: ggVZAItpXbPW6cq['VOD_UNKNOWN_GROUPED'].append(IY8dOXtURSM5Eb23mW7vK)
			elif 'MOVIES' in ffaXcwQevDRLGm2: ggVZAItpXbPW6cq['VOD_MOVIES_GROUPED'].append(IY8dOXtURSM5Eb23mW7vK)
			elif 'SERIES' in ffaXcwQevDRLGm2: ggVZAItpXbPW6cq['VOD_SERIES_GROUPED'].append(IY8dOXtURSM5Eb23mW7vK)
			else: pUCIzcEWGZJy = True
			ggVZAItpXbPW6cq['VOD_ORIGINAL_GROUPED'].append(IY8dOXtURSM5Eb23mW7vK)
		else: pUCIzcEWGZJy = True
		if pUCIzcEWGZJy: HqPjEyicVxGJ7QuvaT.append(BLjVTYG6NodRPI3ZJtSWrCEaxHqh9y)
		ood6Gh9mLZIcrSUO0zVERjsikg7x += 1
	GA5F6vnyTmDV0YkQihUexNH9a7 = sorted(TuVNhRcQHgtwDbMqE53FJz,reverse=False,key=lambda JDv1uYxBEPcFGwrmlfzSOC: JDv1uYxBEPcFGwrmlfzSOC['title'].lower())
	del TuVNhRcQHgtwDbMqE53FJz
	GpFnKA1stoN = str(D1kz5HhyWldovxibLINCm4603)
	ood6Gh9mLZIcrSUO0zVERjsikg7x = 0
	for BLjVTYG6NodRPI3ZJtSWrCEaxHqh9y in GA5F6vnyTmDV0YkQihUexNH9a7:
		ood6Gh9mLZIcrSUO0zVERjsikg7x += 1
		if ood6Gh9mLZIcrSUO0zVERjsikg7x%873==0:
			b8bEl0XjyR4hACKcYkJVP2oBavnGm1(jTG1aFtB8HM4zLXoUQygVu0RcOhv,55+int(5*ood6Gh9mLZIcrSUO0zVERjsikg7x/D1kz5HhyWldovxibLINCm4603),'تصنيف الفيديوهات المرتبة','الفيديو رقم:-',str(ood6Gh9mLZIcrSUO0zVERjsikg7x)+' / '+GpFnKA1stoN)
			if jTG1aFtB8HM4zLXoUQygVu0RcOhv.iscanceled():
				jTG1aFtB8HM4zLXoUQygVu0RcOhv.close()
				return None,None
		ffaXcwQevDRLGm2 = BLjVTYG6NodRPI3ZJtSWrCEaxHqh9y['type']
		aBXgWuYGwdyS8k0jF4efM5QOcDL,dGlmU8JqW5yFAtcsg,yHAD9oVfdieMNhC,gC2hO80boRyM7TBGqD,EoMKR2biY0 = BLjVTYG6NodRPI3ZJtSWrCEaxHqh9y['group'],BLjVTYG6NodRPI3ZJtSWrCEaxHqh9y['context'],BLjVTYG6NodRPI3ZJtSWrCEaxHqh9y['title'],BLjVTYG6NodRPI3ZJtSWrCEaxHqh9y['url'],BLjVTYG6NodRPI3ZJtSWrCEaxHqh9y['img']
		yAS92Iz54TLMZagtYjd,KfCRA3emhxGI4YTNBl98pUju21 = BLjVTYG6NodRPI3ZJtSWrCEaxHqh9y['country'],BLjVTYG6NodRPI3ZJtSWrCEaxHqh9y['language']
		bVn51h8cWPYdlgUEX7x0F = (aBXgWuYGwdyS8k0jF4efM5QOcDL,dGlmU8JqW5yFAtcsg+'_TIMESHIFT',yHAD9oVfdieMNhC,gC2hO80boRyM7TBGqD,EoMKR2biY0)
		IY8dOXtURSM5Eb23mW7vK = (aBXgWuYGwdyS8k0jF4efM5QOcDL,dGlmU8JqW5yFAtcsg,yHAD9oVfdieMNhC,gC2hO80boRyM7TBGqD,EoMKR2biY0)
		JZDK54z8nWILhONyiamXbMcRAu = (yAS92Iz54TLMZagtYjd,dGlmU8JqW5yFAtcsg,yHAD9oVfdieMNhC,gC2hO80boRyM7TBGqD,EoMKR2biY0)
		RSoIZcnu3Ah8HWw4QeJ1ytpNlm = (KfCRA3emhxGI4YTNBl98pUju21,dGlmU8JqW5yFAtcsg,yHAD9oVfdieMNhC,gC2hO80boRyM7TBGqD,EoMKR2biY0)
		if 'LIVE' in ffaXcwQevDRLGm2:
			if 'UNKNOWN' in ffaXcwQevDRLGm2: ggVZAItpXbPW6cq['LIVE_UNKNOWN_GROUPED_SORTED'].append(IY8dOXtURSM5Eb23mW7vK)
			else: ggVZAItpXbPW6cq['LIVE_GROUPED_SORTED'].append(IY8dOXtURSM5Eb23mW7vK)
			if 'EPG'		in ffaXcwQevDRLGm2: ggVZAItpXbPW6cq['LIVE_EPG_GROUPED_SORTED'].append(IY8dOXtURSM5Eb23mW7vK)
			if 'ARCHIVED'	in ffaXcwQevDRLGm2: ggVZAItpXbPW6cq['LIVE_ARCHIVED_GROUPED_SORTED'].append(IY8dOXtURSM5Eb23mW7vK)
			if 'ARCHIVED'	in ffaXcwQevDRLGm2: ggVZAItpXbPW6cq['LIVE_TIMESHIFT_GROUPED_SORTED'].append(bVn51h8cWPYdlgUEX7x0F)
			ggVZAItpXbPW6cq['LIVE_FROM_NAME_SORTED'].append(JZDK54z8nWILhONyiamXbMcRAu)
			ggVZAItpXbPW6cq['LIVE_FROM_GROUP_SORTED'].append(RSoIZcnu3Ah8HWw4QeJ1ytpNlm)
		elif 'VOD' in ffaXcwQevDRLGm2:
			if   'UNKNOWN'	in ffaXcwQevDRLGm2: ggVZAItpXbPW6cq['VOD_UNKNOWN_GROUPED_SORTED'].append(IY8dOXtURSM5Eb23mW7vK)
			elif 'MOVIES'	in ffaXcwQevDRLGm2: ggVZAItpXbPW6cq['VOD_MOVIES_GROUPED_SORTED'].append(IY8dOXtURSM5Eb23mW7vK)
			elif 'SERIES'	in ffaXcwQevDRLGm2: ggVZAItpXbPW6cq['VOD_SERIES_GROUPED_SORTED'].append(IY8dOXtURSM5Eb23mW7vK)
			ggVZAItpXbPW6cq['VOD_FROM_NAME_SORTED'].append(JZDK54z8nWILhONyiamXbMcRAu)
			ggVZAItpXbPW6cq['VOD_FROM_GROUP_SORTED'].append(RSoIZcnu3Ah8HWw4QeJ1ytpNlm)
	return ggVZAItpXbPW6cq,HqPjEyicVxGJ7QuvaT
def EliFfhxjYr37VyDC(yHAD9oVfdieMNhC):
	if len(yHAD9oVfdieMNhC)<3: return yHAD9oVfdieMNhC,yHAD9oVfdieMNhC
	HcvA9eyxq5NFhmTbDQIrJkz,MfPyeLVc0xGvqmtHjSrQ3Xd = '',''
	ORxu01XoaQE = yHAD9oVfdieMNhC
	nWgflw9FRa8m6IbDqTExc0Kdp = yHAD9oVfdieMNhC[:1]
	IVJef2ab9yZmpPwkcLFsQKzju7MnCt = yHAD9oVfdieMNhC[1:]
	if   nWgflw9FRa8m6IbDqTExc0Kdp=='(': MfPyeLVc0xGvqmtHjSrQ3Xd = ')'
	elif nWgflw9FRa8m6IbDqTExc0Kdp=='[': MfPyeLVc0xGvqmtHjSrQ3Xd = ']'
	elif nWgflw9FRa8m6IbDqTExc0Kdp=='<': MfPyeLVc0xGvqmtHjSrQ3Xd = '>'
	elif nWgflw9FRa8m6IbDqTExc0Kdp=='|': MfPyeLVc0xGvqmtHjSrQ3Xd = '|'
	if MfPyeLVc0xGvqmtHjSrQ3Xd and (MfPyeLVc0xGvqmtHjSrQ3Xd in IVJef2ab9yZmpPwkcLFsQKzju7MnCt):
		jy4k3KNeqg,W4Ph97dVtuTblCI1ZEjLY = IVJef2ab9yZmpPwkcLFsQKzju7MnCt.split(MfPyeLVc0xGvqmtHjSrQ3Xd,1)
		HcvA9eyxq5NFhmTbDQIrJkz = jy4k3KNeqg
		ORxu01XoaQE = nWgflw9FRa8m6IbDqTExc0Kdp+jy4k3KNeqg+MfPyeLVc0xGvqmtHjSrQ3Xd+' '+W4Ph97dVtuTblCI1ZEjLY
	elif yHAD9oVfdieMNhC.count('|')>=2:
		jy4k3KNeqg,W4Ph97dVtuTblCI1ZEjLY = yHAD9oVfdieMNhC.split('|',1)
		HcvA9eyxq5NFhmTbDQIrJkz = jy4k3KNeqg
		ORxu01XoaQE = jy4k3KNeqg+' |'+W4Ph97dVtuTblCI1ZEjLY
	else:
		MfPyeLVc0xGvqmtHjSrQ3Xd = ZXFs0mEPR8qI2zj.findall('^\w{2}( |\:|\-|\||\]|\)|'+'#'+'|\.|\,|\$|\'|\!|\@|\%|\&|\*|\^)',yHAD9oVfdieMNhC,ZXFs0mEPR8qI2zj.DOTALL)
		if not MfPyeLVc0xGvqmtHjSrQ3Xd: MfPyeLVc0xGvqmtHjSrQ3Xd = ZXFs0mEPR8qI2zj.findall('^\w{3}( |\:|\-|\||\]|\)|'+'#'+'|\.|\,|\$|\'|\!|\@|\%|\&|\*|\^)',yHAD9oVfdieMNhC,ZXFs0mEPR8qI2zj.DOTALL)
		if not MfPyeLVc0xGvqmtHjSrQ3Xd: MfPyeLVc0xGvqmtHjSrQ3Xd = ZXFs0mEPR8qI2zj.findall('^\w{4}( |\:|\-|\||\]|\)|'+'#'+'|\.|\,|\$|\'|\!|\@|\%|\&|\*|\^)',yHAD9oVfdieMNhC,ZXFs0mEPR8qI2zj.DOTALL)
		if MfPyeLVc0xGvqmtHjSrQ3Xd:
			jy4k3KNeqg,W4Ph97dVtuTblCI1ZEjLY = yHAD9oVfdieMNhC.split(MfPyeLVc0xGvqmtHjSrQ3Xd[0],1)
			HcvA9eyxq5NFhmTbDQIrJkz = jy4k3KNeqg
			ORxu01XoaQE = jy4k3KNeqg+' '+MfPyeLVc0xGvqmtHjSrQ3Xd[0]+' '+W4Ph97dVtuTblCI1ZEjLY
	ORxu01XoaQE = ORxu01XoaQE.replace('   ',' ').replace('  ',' ')
	HcvA9eyxq5NFhmTbDQIrJkz = HcvA9eyxq5NFhmTbDQIrJkz.replace('  ',' ')
	if not HcvA9eyxq5NFhmTbDQIrJkz: HcvA9eyxq5NFhmTbDQIrJkz = '!!__UNKNOWN__!!'
	HcvA9eyxq5NFhmTbDQIrJkz = HcvA9eyxq5NFhmTbDQIrJkz.strip(' ')
	ORxu01XoaQE = ORxu01XoaQE.strip(' ')
	return HcvA9eyxq5NFhmTbDQIrJkz,ORxu01XoaQE
def poTRFiyNCYwsO8dhMBHZ2lAIvL1(fTLHoIGS2JMYV3jKh7DuW0ke):
	Mm7XCRohg3iUSfJKdWsIqx = {}
	u5b39JYiNdS8ejFzt4ch = j2agIU0xsLS6c7T.getSetting('av.iptv.useragent_'+fTLHoIGS2JMYV3jKh7DuW0ke)
	if u5b39JYiNdS8ejFzt4ch: Mm7XCRohg3iUSfJKdWsIqx['User-Agent'] = u5b39JYiNdS8ejFzt4ch
	vvePnQc9hCHO6zKwpjk1byRSF = j2agIU0xsLS6c7T.getSetting('av.iptv.referer_'+fTLHoIGS2JMYV3jKh7DuW0ke)
	if vvePnQc9hCHO6zKwpjk1byRSF: Mm7XCRohg3iUSfJKdWsIqx['Referer'] = vvePnQc9hCHO6zKwpjk1byRSF
	return Mm7XCRohg3iUSfJKdWsIqx
def OERZgyI3M0aDAXLvSiTpdjh1Q(fTLHoIGS2JMYV3jKh7DuW0ke):
	global jTG1aFtB8HM4zLXoUQygVu0RcOhv,ggVZAItpXbPW6cq,dybj5sgEH6RqTJYm2W0,mQtbwgnGcTakM2BZAvjNO907WRV,lnzB93tKLeDabv,EETCAlxZ1nfYG4DjKkVBReU8pFu2yX,VpnQLGFdJ07EIbDlaXi6,YEl7NKbSXQHT,xJLE9wZQa6
	LLmOgfvERFwWp9DQMoBHS36rd,fUSnuQTRBwOtFhZz36k9y,lBeGVXTt0qD,v1IzDVTBhweb3tRr6YCyoNK,LX35qsjfcIWaDT8S462 = gmcELYbTJS(fTLHoIGS2JMYV3jKh7DuW0ke)
	if not v1IzDVTBhweb3tRr6YCyoNK: return
	Mm7XCRohg3iUSfJKdWsIqx = poTRFiyNCYwsO8dhMBHZ2lAIvL1(fTLHoIGS2JMYV3jKh7DuW0ke)
	Bkab1Avo3fYG9s6lZcOITDXd4MFi = OxCB4medn1('center','','','رسالة من المبرمج','جلب ملفات ـIPTV جديدة قد تحتاج عدة دقائق . هل تريد أن تجلب الملفات الآن ؟')
	if Bkab1Avo3fYG9s6lZcOITDXd4MFi!=1: return
	L69Ll5ObZkDPewd = qqXYCDM3kcB7mNj6W2h8dwb.replace('___','_'+fTLHoIGS2JMYV3jKh7DuW0ke)
	if 1:
		Q4o2IDnNJzcYe,VzPym8fW6lKD1bpeZGnRCBs,MnAvyj3DZthLSIo = FhYAZG1ur2sQRtTX9DlOcx3WILv(fTLHoIGS2JMYV3jKh7DuW0ke,False)
		if not Q4o2IDnNJzcYe:
			HHTzVhiY079bvdluNkFQ4wCMpe('','','رسالة من المبرمج','فشل بسحب ملفات ـIPTV . أحتمال رابط ـIPTV غير صحيح أو قديم أو لا يعمل .. علما أن هذه الخدمة تحتاج اشتراك مدفوع وصحيح ويجب أن تضيف رابط الاشتراك بنفسك للبرنامج باستخدام قائمة ـIPTV الموجودة بهذا البرنامج')
			if not fUSnuQTRBwOtFhZz36k9y: tr24ZoudmqvxfYCw('ERROR_LINES',RGSFZ7ls3nO(LBtjHDg8yZz69QOp)+'   No IPTV URL found to download IPTV files')
			else: tr24ZoudmqvxfYCw('ERROR_LINES',RGSFZ7ls3nO(LBtjHDg8yZz69QOp)+'   Failed to download IPTV files')
			return
		LLGEyx4As9aCmlR6OwWcFqKtrphSkn = L41Ku9Nxqcsw(fUSnuQTRBwOtFhZz36k9y,Mm7XCRohg3iUSfJKdWsIqx,True)
		if not LLGEyx4As9aCmlR6OwWcFqKtrphSkn: return
		open(L69Ll5ObZkDPewd,'wb').write(LLGEyx4As9aCmlR6OwWcFqKtrphSkn)
	else: LLGEyx4As9aCmlR6OwWcFqKtrphSkn = open(L69Ll5ObZkDPewd,'rb').read()
	if VYMZsxRpcQHPgkaiDKjyoh and LLGEyx4As9aCmlR6OwWcFqKtrphSkn: LLGEyx4As9aCmlR6OwWcFqKtrphSkn = LLGEyx4As9aCmlR6OwWcFqKtrphSkn.decode('utf8')
	jTG1aFtB8HM4zLXoUQygVu0RcOhv = a6Nd4etSry0P1W()
	jTG1aFtB8HM4zLXoUQygVu0RcOhv.create('جلب ملفات ـIPTV جديدة','')
	b8bEl0XjyR4hACKcYkJVP2oBavnGm1(jTG1aFtB8HM4zLXoUQygVu0RcOhv,15,'تنظيف الملف الرئيسي','')
	LLGEyx4As9aCmlR6OwWcFqKtrphSkn = LLGEyx4As9aCmlR6OwWcFqKtrphSkn.replace('"tvg-','" tvg-')
	LLGEyx4As9aCmlR6OwWcFqKtrphSkn = LLGEyx4As9aCmlR6OwWcFqKtrphSkn.replace('َ','').replace('ً','').replace('ُ','').replace('ٌ','')
	LLGEyx4As9aCmlR6OwWcFqKtrphSkn = LLGEyx4As9aCmlR6OwWcFqKtrphSkn.replace('ّ','').replace('ِ','').replace('ٍ','').replace('ْ','')
	LLGEyx4As9aCmlR6OwWcFqKtrphSkn = LLGEyx4As9aCmlR6OwWcFqKtrphSkn.replace('group-title=','group=').replace('tvg-','')
	Czpk8MuF2DoYdHfLb,DG5RtsncgN = [],[]
	b8bEl0XjyR4hACKcYkJVP2oBavnGm1(jTG1aFtB8HM4zLXoUQygVu0RcOhv,20,'جلب الملفات الثانوية','الملف رقم:-','1 / 3')
	if jTG1aFtB8HM4zLXoUQygVu0RcOhv.iscanceled():
		jTG1aFtB8HM4zLXoUQygVu0RcOhv.close()
		return
	gC2hO80boRyM7TBGqD = LLmOgfvERFwWp9DQMoBHS36rd+'&action=get_series_categories'
	Ba3qhge51Hynsz8mcoW = A6F71g3cqN4(Z7uFdWIRv9ybj0,'GET',gC2hO80boRyM7TBGqD,'',Mm7XCRohg3iUSfJKdWsIqx,'','','IPTV-CREATE_STREAMS-1st')
	BRufE2IykDCOaNAv9iU = Ba3qhge51Hynsz8mcoW.content
	BRufE2IykDCOaNAv9iU = WhJe7bGx5XackTwOIZVLC8ut(BRufE2IykDCOaNAv9iU)
	NZOG4UrpRXDfyF5hAaIL0TlPj9EHC = ZXFs0mEPR8qI2zj.findall('category_name":"(.*?)"',BRufE2IykDCOaNAv9iU,ZXFs0mEPR8qI2zj.DOTALL)
	del BRufE2IykDCOaNAv9iU
	for aBXgWuYGwdyS8k0jF4efM5QOcDL in NZOG4UrpRXDfyF5hAaIL0TlPj9EHC:
		aBXgWuYGwdyS8k0jF4efM5QOcDL = aBXgWuYGwdyS8k0jF4efM5QOcDL.replace('\/','/')
		if Yd6t3PjlLKk: aBXgWuYGwdyS8k0jF4efM5QOcDL = aBXgWuYGwdyS8k0jF4efM5QOcDL.decode('utf8').encode('utf8')
		LLGEyx4As9aCmlR6OwWcFqKtrphSkn = LLGEyx4As9aCmlR6OwWcFqKtrphSkn.replace('group="'+aBXgWuYGwdyS8k0jF4efM5QOcDL+'"','group="__SERIES__'+aBXgWuYGwdyS8k0jF4efM5QOcDL+'"')
	del NZOG4UrpRXDfyF5hAaIL0TlPj9EHC
	b8bEl0XjyR4hACKcYkJVP2oBavnGm1(jTG1aFtB8HM4zLXoUQygVu0RcOhv,25,'جلب الملفات الثانوية','الملف رقم:-','2 / 3')
	if jTG1aFtB8HM4zLXoUQygVu0RcOhv.iscanceled():
		jTG1aFtB8HM4zLXoUQygVu0RcOhv.close()
		return
	gC2hO80boRyM7TBGqD = LLmOgfvERFwWp9DQMoBHS36rd+'&action=get_vod_categories'
	Ba3qhge51Hynsz8mcoW = A6F71g3cqN4(Z7uFdWIRv9ybj0,'GET',gC2hO80boRyM7TBGqD,'',Mm7XCRohg3iUSfJKdWsIqx,'','','IPTV-CREATE_STREAMS-2nd')
	BRufE2IykDCOaNAv9iU = Ba3qhge51Hynsz8mcoW.content
	BRufE2IykDCOaNAv9iU = WhJe7bGx5XackTwOIZVLC8ut(BRufE2IykDCOaNAv9iU)
	zwr5RhgyuXt6lv4QA7D3PoJ = ZXFs0mEPR8qI2zj.findall('category_name":"(.*?)"',BRufE2IykDCOaNAv9iU,ZXFs0mEPR8qI2zj.DOTALL)
	del BRufE2IykDCOaNAv9iU
	for aBXgWuYGwdyS8k0jF4efM5QOcDL in zwr5RhgyuXt6lv4QA7D3PoJ:
		aBXgWuYGwdyS8k0jF4efM5QOcDL = aBXgWuYGwdyS8k0jF4efM5QOcDL.replace('\/','/')
		if Yd6t3PjlLKk: aBXgWuYGwdyS8k0jF4efM5QOcDL = aBXgWuYGwdyS8k0jF4efM5QOcDL.decode('utf8').encode('utf8')
		LLGEyx4As9aCmlR6OwWcFqKtrphSkn = LLGEyx4As9aCmlR6OwWcFqKtrphSkn.replace('group="'+aBXgWuYGwdyS8k0jF4efM5QOcDL+'"','group="__MOVIES__'+aBXgWuYGwdyS8k0jF4efM5QOcDL+'"')
	del zwr5RhgyuXt6lv4QA7D3PoJ
	b8bEl0XjyR4hACKcYkJVP2oBavnGm1(jTG1aFtB8HM4zLXoUQygVu0RcOhv,30,'جلب الملفات الثانوية','الملف رقم:-','3 / 3')
	if jTG1aFtB8HM4zLXoUQygVu0RcOhv.iscanceled():
		jTG1aFtB8HM4zLXoUQygVu0RcOhv.close()
		return
	gC2hO80boRyM7TBGqD = LLmOgfvERFwWp9DQMoBHS36rd+'&action=get_live_streams'
	Ba3qhge51Hynsz8mcoW = A6F71g3cqN4(Z7uFdWIRv9ybj0,'GET',gC2hO80boRyM7TBGqD,'',Mm7XCRohg3iUSfJKdWsIqx,'','','IPTV-CREATE_STREAMS-3rd')
	BRufE2IykDCOaNAv9iU = Ba3qhge51Hynsz8mcoW.content
	BRufE2IykDCOaNAv9iU = WhJe7bGx5XackTwOIZVLC8ut(BRufE2IykDCOaNAv9iU)
	JVNguq7C4EsXnDR6ISdPTGMk = ZXFs0mEPR8qI2zj.findall('"name":"(.*?)".*?"tv_archive":(.*?),',BRufE2IykDCOaNAv9iU,ZXFs0mEPR8qI2zj.DOTALL)
	for aaYDh2EzJ5ky,zMhdEFIXWixqTO97PvYUDmfBasG in JVNguq7C4EsXnDR6ISdPTGMk:
		if zMhdEFIXWixqTO97PvYUDmfBasG=='1': Czpk8MuF2DoYdHfLb.append(aaYDh2EzJ5ky)
	del JVNguq7C4EsXnDR6ISdPTGMk
	dSBtrGIM3cT4ziYJfsNnD0 = ZXFs0mEPR8qI2zj.findall('"name":"(.*?)".*?"epg_channel_id":(.*?),',BRufE2IykDCOaNAv9iU,ZXFs0mEPR8qI2zj.DOTALL)
	del BRufE2IykDCOaNAv9iU
	for aaYDh2EzJ5ky,VkUO1B8I2nsKRhtSdQ3J7rbmw in dSBtrGIM3cT4ziYJfsNnD0:
		if VkUO1B8I2nsKRhtSdQ3J7rbmw!='null': DG5RtsncgN.append(aaYDh2EzJ5ky)
	del dSBtrGIM3cT4ziYJfsNnD0
	LLGEyx4As9aCmlR6OwWcFqKtrphSkn = LLGEyx4As9aCmlR6OwWcFqKtrphSkn.replace('\r','\n')
	dUkqersWvMoJ964 = ZXFs0mEPR8qI2zj.findall('NF:(.+?)'+'#'+'EXTI',LLGEyx4As9aCmlR6OwWcFqKtrphSkn+'\n+'+'#'+'EXTINF:',ZXFs0mEPR8qI2zj.DOTALL)
	if not dUkqersWvMoJ964:
		tr24ZoudmqvxfYCw('ERROR_LINES',RGSFZ7ls3nO(LBtjHDg8yZz69QOp)+'   Folder:'+fTLHoIGS2JMYV3jKh7DuW0ke+'   No video links found in IPTV file')
		HHTzVhiY079bvdluNkFQ4wCMpe('','','رسالة من المبرمج','رابط ـIPTV الذي أنت أضفته لا توجد فيه فيديوهات .. احتمال رابط ـIPTV غير صحيح'+'\n'+'[COLOR FFFFFF00]'+'مجلد رقم '+fTLHoIGS2JMYV3jKh7DuW0ke)
		jTG1aFtB8HM4zLXoUQygVu0RcOhv.close()
		return
	JDPKM4T1dGiLCyfbhlUHQ0Nanc8 = []
	for FFhKw05es4jgM in dUkqersWvMoJ964:
		JAGqcTbInBXvLtCpWaV = FFhKw05es4jgM.lower()
		if 'adult' in JAGqcTbInBXvLtCpWaV: continue
		if 'xxx' in JAGqcTbInBXvLtCpWaV: continue
		JDPKM4T1dGiLCyfbhlUHQ0Nanc8.append(FFhKw05es4jgM)
	dUkqersWvMoJ964 = JDPKM4T1dGiLCyfbhlUHQ0Nanc8
	del JDPKM4T1dGiLCyfbhlUHQ0Nanc8
	vvRNy2W0HAbgqdI8SzXuKpa = 1024*1024
	WWwaUpEfzidu3H9APtLcT = 1+len(LLGEyx4As9aCmlR6OwWcFqKtrphSkn)//vvRNy2W0HAbgqdI8SzXuKpa//10
	del LLGEyx4As9aCmlR6OwWcFqKtrphSkn
	cc8fs6kiRnpx7VIU = len(dUkqersWvMoJ964)
	Qkub8aVJqdcjxn9h4lFO3PH1 = UUG3k64wyPDtOszK728Vx1Ql(dUkqersWvMoJ964,WWwaUpEfzidu3H9APtLcT)
	del dUkqersWvMoJ964
	for tdpTaMcz6ZfOUAvx0ByPnLrJob in range(WWwaUpEfzidu3H9APtLcT):
		b8bEl0XjyR4hACKcYkJVP2oBavnGm1(jTG1aFtB8HM4zLXoUQygVu0RcOhv,35+int(5*tdpTaMcz6ZfOUAvx0ByPnLrJob/WWwaUpEfzidu3H9APtLcT),'تقطيع الملف الرئيسي','الجزء رقم:-',str(tdpTaMcz6ZfOUAvx0ByPnLrJob+1)+' / '+str(WWwaUpEfzidu3H9APtLcT))
		if jTG1aFtB8HM4zLXoUQygVu0RcOhv.iscanceled():
			jTG1aFtB8HM4zLXoUQygVu0RcOhv.close()
			return
		fqbcTAz7ngSu2 = str(Qkub8aVJqdcjxn9h4lFO3PH1[tdpTaMcz6ZfOUAvx0ByPnLrJob])
		if VYMZsxRpcQHPgkaiDKjyoh: fqbcTAz7ngSu2 = fqbcTAz7ngSu2.encode('utf8')
		open(L69Ll5ObZkDPewd+'.00'+str(tdpTaMcz6ZfOUAvx0ByPnLrJob),'wb').write(fqbcTAz7ngSu2)
	del Qkub8aVJqdcjxn9h4lFO3PH1,fqbcTAz7ngSu2
	xTWV5UvXqpMD7yO,TuVNhRcQHgtwDbMqE53FJz,ood6Gh9mLZIcrSUO0zVERjsikg7x = [],[],0
	for tdpTaMcz6ZfOUAvx0ByPnLrJob in range(WWwaUpEfzidu3H9APtLcT):
		if jTG1aFtB8HM4zLXoUQygVu0RcOhv.iscanceled():
			jTG1aFtB8HM4zLXoUQygVu0RcOhv.close()
			return
		fqbcTAz7ngSu2 = open(L69Ll5ObZkDPewd+'.00'+str(tdpTaMcz6ZfOUAvx0ByPnLrJob),'rb').read()
		luMHeSgCBaPrb9KvUjNFqcR.sleep(1)
		try: hhHq8m5vauKG9dl.remove(L69Ll5ObZkDPewd+'.00'+str(tdpTaMcz6ZfOUAvx0ByPnLrJob))
		except: pass
		if VYMZsxRpcQHPgkaiDKjyoh: fqbcTAz7ngSu2 = fqbcTAz7ngSu2.decode('utf8')
		Xs4IR3fzvBN1mkSPpgiEhG7btFJd = NL0JIkbrEWqTYj61vVKGCnBw37MsOF('list',fqbcTAz7ngSu2)
		del fqbcTAz7ngSu2
		bb2Wi1TrnXpSA4wgfszMvcxd0O3mL,ood6Gh9mLZIcrSUO0zVERjsikg7x,HqPjEyicVxGJ7QuvaT = Wc9NgOYMzATtBHIGyQKswJj(Xs4IR3fzvBN1mkSPpgiEhG7btFJd,DG5RtsncgN,Czpk8MuF2DoYdHfLb,jTG1aFtB8HM4zLXoUQygVu0RcOhv,cc8fs6kiRnpx7VIU,ood6Gh9mLZIcrSUO0zVERjsikg7x,fUSnuQTRBwOtFhZz36k9y)
		if jTG1aFtB8HM4zLXoUQygVu0RcOhv.iscanceled():
			jTG1aFtB8HM4zLXoUQygVu0RcOhv.close()
			return
		if not bb2Wi1TrnXpSA4wgfszMvcxd0O3mL:
			jTG1aFtB8HM4zLXoUQygVu0RcOhv.close()
			return
		TuVNhRcQHgtwDbMqE53FJz += bb2Wi1TrnXpSA4wgfszMvcxd0O3mL
		xTWV5UvXqpMD7yO += HqPjEyicVxGJ7QuvaT
	del Xs4IR3fzvBN1mkSPpgiEhG7btFJd,bb2Wi1TrnXpSA4wgfszMvcxd0O3mL
	ggVZAItpXbPW6cq,HqPjEyicVxGJ7QuvaT = a1djBECx0zOTRkKAtI(TuVNhRcQHgtwDbMqE53FJz,jTG1aFtB8HM4zLXoUQygVu0RcOhv)
	if jTG1aFtB8HM4zLXoUQygVu0RcOhv.iscanceled():
		jTG1aFtB8HM4zLXoUQygVu0RcOhv.close()
		return
	xTWV5UvXqpMD7yO += HqPjEyicVxGJ7QuvaT
	del TuVNhRcQHgtwDbMqE53FJz,HqPjEyicVxGJ7QuvaT
	mQtbwgnGcTakM2BZAvjNO907WRV,lnzB93tKLeDabv,EETCAlxZ1nfYG4DjKkVBReU8pFu2yX,VpnQLGFdJ07EIbDlaXi6,YEl7NKbSXQHT = {},{},{},0,0
	ZvbkCIpHAMOPDy0mBSVsxE = list(ggVZAItpXbPW6cq.keys())
	xJLE9wZQa6 = len(ZvbkCIpHAMOPDy0mBSVsxE)*3
	if 1:
		pYszTMCOeWg = {}
		for dMu4F8L5Azo6IJ2aleywBmb in ZvbkCIpHAMOPDy0mBSVsxE:
			pYszTMCOeWg[dMu4F8L5Azo6IJ2aleywBmb] = c3cgVjNv1rde.Thread(target=km43rqTRescAwyH89,args=(dMu4F8L5Azo6IJ2aleywBmb,))
			pYszTMCOeWg[dMu4F8L5Azo6IJ2aleywBmb].start()
		for dMu4F8L5Azo6IJ2aleywBmb in ZvbkCIpHAMOPDy0mBSVsxE:
			pYszTMCOeWg[dMu4F8L5Azo6IJ2aleywBmb].join()
		if jTG1aFtB8HM4zLXoUQygVu0RcOhv.iscanceled():
			jTG1aFtB8HM4zLXoUQygVu0RcOhv.close()
			return
	else:
		for dMu4F8L5Azo6IJ2aleywBmb in ZvbkCIpHAMOPDy0mBSVsxE:
			km43rqTRescAwyH89(dMu4F8L5Azo6IJ2aleywBmb)
			if jTG1aFtB8HM4zLXoUQygVu0RcOhv.iscanceled():
				jTG1aFtB8HM4zLXoUQygVu0RcOhv.close()
				return
	Xjs93SRJtwqc(fTLHoIGS2JMYV3jKh7DuW0ke,False)
	ZvbkCIpHAMOPDy0mBSVsxE = list(mQtbwgnGcTakM2BZAvjNO907WRV.keys())
	dybj5sgEH6RqTJYm2W0 = 0
	if 1:
		pYszTMCOeWg = {}
		for dMu4F8L5Azo6IJ2aleywBmb in ZvbkCIpHAMOPDy0mBSVsxE:
			pYszTMCOeWg[dMu4F8L5Azo6IJ2aleywBmb] = c3cgVjNv1rde.Thread(target=IIkGRs2DZjSTwozNq739adpAgy8bOJ,args=(fTLHoIGS2JMYV3jKh7DuW0ke,dMu4F8L5Azo6IJ2aleywBmb))
			pYszTMCOeWg[dMu4F8L5Azo6IJ2aleywBmb].start()
		for dMu4F8L5Azo6IJ2aleywBmb in ZvbkCIpHAMOPDy0mBSVsxE:
			pYszTMCOeWg[dMu4F8L5Azo6IJ2aleywBmb].join()
		if jTG1aFtB8HM4zLXoUQygVu0RcOhv.iscanceled():
			jTG1aFtB8HM4zLXoUQygVu0RcOhv.close()
			return
	else:
		for dMu4F8L5Azo6IJ2aleywBmb in ZvbkCIpHAMOPDy0mBSVsxE:
			IIkGRs2DZjSTwozNq739adpAgy8bOJ(fTLHoIGS2JMYV3jKh7DuW0ke,dMu4F8L5Azo6IJ2aleywBmb)
			if jTG1aFtB8HM4zLXoUQygVu0RcOhv.iscanceled():
				jTG1aFtB8HM4zLXoUQygVu0RcOhv.close()
				return
	tdpTaMcz6ZfOUAvx0ByPnLrJob = 0
	RIpkMOAGTFo4tdSCw5c2NV = len(xTWV5UvXqpMD7yO)
	sEyDZTBxj9l = cHa5JRAQ3ZKku7(fTLHoIGS2JMYV3jKh7DuW0ke,'IGNORED')
	for ZzT9UxXGbMAm2OSdgcNBet in xTWV5UvXqpMD7yO:
		if tdpTaMcz6ZfOUAvx0ByPnLrJob%27==0:
			b8bEl0XjyR4hACKcYkJVP2oBavnGm1(jTG1aFtB8HM4zLXoUQygVu0RcOhv,95+int(5*tdpTaMcz6ZfOUAvx0ByPnLrJob//RIpkMOAGTFo4tdSCw5c2NV),'تخزين المهملة','الفيديو رقم:-',str(tdpTaMcz6ZfOUAvx0ByPnLrJob)+' / '+str(RIpkMOAGTFo4tdSCw5c2NV))
			if jTG1aFtB8HM4zLXoUQygVu0RcOhv.iscanceled():
				jTG1aFtB8HM4zLXoUQygVu0RcOhv.close()
				return
		Qc96YoCZJOsKUB8yImw034(sEyDZTBxj9l,'IGNORED',str(ZzT9UxXGbMAm2OSdgcNBet),'',iKYM8NdkGHmBcr)
		tdpTaMcz6ZfOUAvx0ByPnLrJob += 1
	Qc96YoCZJOsKUB8yImw034(sEyDZTBxj9l,'IGNORED','__COUNT__',str(RIpkMOAGTFo4tdSCw5c2NV),iKYM8NdkGHmBcr)
	Qc96YoCZJOsKUB8yImw034(sEyDZTBxj9l,'DUMMY','__DUMMY__','1',iKYM8NdkGHmBcr)
	jTG1aFtB8HM4zLXoUQygVu0RcOhv.close()
	luMHeSgCBaPrb9KvUjNFqcR.sleep(1)
	GNjM8ZTxXRayUKe6qQ013p = KcRikAv9Zbmerd4W6Pp7j5TQ(fTLHoIGS2JMYV3jKh7DuW0ke,False)
	HHTzVhiY079bvdluNkFQ4wCMpe('','','رسالة من المبرمج','[COLOR FFFFFF00]'+'تم جلب ملفات ـIPTV جديدة'+'[/COLOR]'+'\n\n'+GNjM8ZTxXRayUKe6qQ013p)
	cPwDBuG4HVTCdQ9JmMeoWjNY2hX.executebuiltin('Container.Refresh')
	m8mDHu2eZKoJCMXw3bPrUz(fTLHoIGS2JMYV3jKh7DuW0ke)
	return
def km43rqTRescAwyH89(dMu4F8L5Azo6IJ2aleywBmb):
	global jTG1aFtB8HM4zLXoUQygVu0RcOhv,ggVZAItpXbPW6cq,dybj5sgEH6RqTJYm2W0,mQtbwgnGcTakM2BZAvjNO907WRV,lnzB93tKLeDabv,EETCAlxZ1nfYG4DjKkVBReU8pFu2yX,VpnQLGFdJ07EIbDlaXi6,YEl7NKbSXQHT,xJLE9wZQa6
	mQtbwgnGcTakM2BZAvjNO907WRV[dMu4F8L5Azo6IJ2aleywBmb] = {}
	Byw52HLiV0Udkbv,yAV0WlZbRGt2I6frq = {},[]
	KUfLbM1cG3qgQri8duHCemWwyVth = len(ggVZAItpXbPW6cq[dMu4F8L5Azo6IJ2aleywBmb])
	mQtbwgnGcTakM2BZAvjNO907WRV[dMu4F8L5Azo6IJ2aleywBmb]['__COUNT__'] = KUfLbM1cG3qgQri8duHCemWwyVth
	if KUfLbM1cG3qgQri8duHCemWwyVth>0:
		lWDe5hsb1S7YncVG9XdI,SA6DdjwRMGgV2bY8B7,HaNDwlWYbucd3P0Vptisqg,tPZ6I7v5Lc8gMRN4EGkQA1JKuf,EATmh7WH4cQzjZdiRyVUG3g = zip(*ggVZAItpXbPW6cq[dMu4F8L5Azo6IJ2aleywBmb])
		del SA6DdjwRMGgV2bY8B7,HaNDwlWYbucd3P0Vptisqg,tPZ6I7v5Lc8gMRN4EGkQA1JKuf
		K4uRaScPJY7I5W1tGpUf = list(set(lWDe5hsb1S7YncVG9XdI))
		for aBXgWuYGwdyS8k0jF4efM5QOcDL in K4uRaScPJY7I5W1tGpUf:
			Byw52HLiV0Udkbv[aBXgWuYGwdyS8k0jF4efM5QOcDL] = ''
			mQtbwgnGcTakM2BZAvjNO907WRV[dMu4F8L5Azo6IJ2aleywBmb][aBXgWuYGwdyS8k0jF4efM5QOcDL] = []
		b8bEl0XjyR4hACKcYkJVP2oBavnGm1(jTG1aFtB8HM4zLXoUQygVu0RcOhv,60+int(15*YEl7NKbSXQHT//xJLE9wZQa6),'تصنيع القوائم','الجزء رقم:-',str(YEl7NKbSXQHT)+' / '+str(xJLE9wZQa6))
		if jTG1aFtB8HM4zLXoUQygVu0RcOhv.iscanceled(): return
		YEl7NKbSXQHT += 1
		dCZ2MWGRFUpjQo5 = len(K4uRaScPJY7I5W1tGpUf)
		del K4uRaScPJY7I5W1tGpUf
		yAV0WlZbRGt2I6frq = list(set(zip(lWDe5hsb1S7YncVG9XdI,EATmh7WH4cQzjZdiRyVUG3g)))
		del lWDe5hsb1S7YncVG9XdI,EATmh7WH4cQzjZdiRyVUG3g
		for aBXgWuYGwdyS8k0jF4efM5QOcDL,ggOIGYi4nEAJ2c8hvFufLRBq in yAV0WlZbRGt2I6frq:
			if not Byw52HLiV0Udkbv[aBXgWuYGwdyS8k0jF4efM5QOcDL] and ggOIGYi4nEAJ2c8hvFufLRBq: Byw52HLiV0Udkbv[aBXgWuYGwdyS8k0jF4efM5QOcDL] = ggOIGYi4nEAJ2c8hvFufLRBq
		b8bEl0XjyR4hACKcYkJVP2oBavnGm1(jTG1aFtB8HM4zLXoUQygVu0RcOhv,60+int(15*YEl7NKbSXQHT//xJLE9wZQa6),'تصنيع القوائم','الجزء رقم:-',str(YEl7NKbSXQHT)+' / '+str(xJLE9wZQa6))
		if jTG1aFtB8HM4zLXoUQygVu0RcOhv.iscanceled(): return
		YEl7NKbSXQHT += 1
		Kvt7yrA3i2ZaFPJgISGhndxfl = list(Byw52HLiV0Udkbv.keys())
		i3iT2QvqWcfHxoMbrykj = list(Byw52HLiV0Udkbv.values())
		del Byw52HLiV0Udkbv
		yAV0WlZbRGt2I6frq = list(zip(Kvt7yrA3i2ZaFPJgISGhndxfl,i3iT2QvqWcfHxoMbrykj))
		del Kvt7yrA3i2ZaFPJgISGhndxfl,i3iT2QvqWcfHxoMbrykj
		yAV0WlZbRGt2I6frq = sorted(yAV0WlZbRGt2I6frq)
	else: YEl7NKbSXQHT += 2
	mQtbwgnGcTakM2BZAvjNO907WRV[dMu4F8L5Azo6IJ2aleywBmb]['__GROUPS__'] = yAV0WlZbRGt2I6frq
	del yAV0WlZbRGt2I6frq
	for aBXgWuYGwdyS8k0jF4efM5QOcDL,dGlmU8JqW5yFAtcsg,yHAD9oVfdieMNhC,gC2hO80boRyM7TBGqD,EoMKR2biY0 in ggVZAItpXbPW6cq[dMu4F8L5Azo6IJ2aleywBmb]:
		mQtbwgnGcTakM2BZAvjNO907WRV[dMu4F8L5Azo6IJ2aleywBmb][aBXgWuYGwdyS8k0jF4efM5QOcDL].append((dGlmU8JqW5yFAtcsg,yHAD9oVfdieMNhC,gC2hO80boRyM7TBGqD,EoMKR2biY0))
	b8bEl0XjyR4hACKcYkJVP2oBavnGm1(jTG1aFtB8HM4zLXoUQygVu0RcOhv,60+int(15*YEl7NKbSXQHT//xJLE9wZQa6),'تصنيع القوائم','الجزء رقم:-',str(YEl7NKbSXQHT)+' / '+str(xJLE9wZQa6))
	if jTG1aFtB8HM4zLXoUQygVu0RcOhv.iscanceled(): return
	YEl7NKbSXQHT += 1
	del ggVZAItpXbPW6cq[dMu4F8L5Azo6IJ2aleywBmb]
	EETCAlxZ1nfYG4DjKkVBReU8pFu2yX[dMu4F8L5Azo6IJ2aleywBmb] = list(mQtbwgnGcTakM2BZAvjNO907WRV[dMu4F8L5Azo6IJ2aleywBmb].keys())
	lnzB93tKLeDabv[dMu4F8L5Azo6IJ2aleywBmb] = len(EETCAlxZ1nfYG4DjKkVBReU8pFu2yX[dMu4F8L5Azo6IJ2aleywBmb])
	VpnQLGFdJ07EIbDlaXi6 += lnzB93tKLeDabv[dMu4F8L5Azo6IJ2aleywBmb]
	return
def IIkGRs2DZjSTwozNq739adpAgy8bOJ(fTLHoIGS2JMYV3jKh7DuW0ke,dMu4F8L5Azo6IJ2aleywBmb):
	global jTG1aFtB8HM4zLXoUQygVu0RcOhv,ggVZAItpXbPW6cq,dybj5sgEH6RqTJYm2W0,mQtbwgnGcTakM2BZAvjNO907WRV,lnzB93tKLeDabv,EETCAlxZ1nfYG4DjKkVBReU8pFu2yX,VpnQLGFdJ07EIbDlaXi6,YEl7NKbSXQHT,xJLE9wZQa6
	sEyDZTBxj9l = cHa5JRAQ3ZKku7(fTLHoIGS2JMYV3jKh7DuW0ke,dMu4F8L5Azo6IJ2aleywBmb)
	for ood6Gh9mLZIcrSUO0zVERjsikg7x in range(1+lnzB93tKLeDabv[dMu4F8L5Azo6IJ2aleywBmb]//273):
		ym2HqhLuGcgRr = []
		eI0DEGAQmw3MspaUNdY7 = EETCAlxZ1nfYG4DjKkVBReU8pFu2yX[dMu4F8L5Azo6IJ2aleywBmb][0:273]
		for aBXgWuYGwdyS8k0jF4efM5QOcDL in eI0DEGAQmw3MspaUNdY7:
			ym2HqhLuGcgRr.append(mQtbwgnGcTakM2BZAvjNO907WRV[dMu4F8L5Azo6IJ2aleywBmb][aBXgWuYGwdyS8k0jF4efM5QOcDL])
		Qc96YoCZJOsKUB8yImw034(sEyDZTBxj9l,dMu4F8L5Azo6IJ2aleywBmb,eI0DEGAQmw3MspaUNdY7,ym2HqhLuGcgRr,iKYM8NdkGHmBcr,True)
		dybj5sgEH6RqTJYm2W0 += len(eI0DEGAQmw3MspaUNdY7)
		b8bEl0XjyR4hACKcYkJVP2oBavnGm1(jTG1aFtB8HM4zLXoUQygVu0RcOhv,75+int(20*dybj5sgEH6RqTJYm2W0//VpnQLGFdJ07EIbDlaXi6),'تخزين القوائم','القائمة رقم:-',str(dybj5sgEH6RqTJYm2W0)+' / '+str(VpnQLGFdJ07EIbDlaXi6))
		if jTG1aFtB8HM4zLXoUQygVu0RcOhv.iscanceled(): return
		del EETCAlxZ1nfYG4DjKkVBReU8pFu2yX[dMu4F8L5Azo6IJ2aleywBmb][0:273]
	del mQtbwgnGcTakM2BZAvjNO907WRV[dMu4F8L5Azo6IJ2aleywBmb],EETCAlxZ1nfYG4DjKkVBReU8pFu2yX[dMu4F8L5Azo6IJ2aleywBmb],lnzB93tKLeDabv[dMu4F8L5Azo6IJ2aleywBmb]
	return
def KcRikAv9Zbmerd4W6Pp7j5TQ(fTLHoIGS2JMYV3jKh7DuW0ke,CaiGWx9HlMhRznyFDm1=True):
	if not KHWOFrzptwybYx(fTLHoIGS2JMYV3jKh7DuW0ke,CaiGWx9HlMhRznyFDm1): return
	v5OBhbICnwmWA8J2MzX7D = 'رسالة من المبرمج'
	to9lNhTbJRyLfzwv21Yina7sZrPC = cHa5JRAQ3ZKku7(fTLHoIGS2JMYV3jKh7DuW0ke,'LIVE_ORIGINAL_GROUPED')
	ezcN4709H8LoyRfIv2mb = cHa5JRAQ3ZKku7(fTLHoIGS2JMYV3jKh7DuW0ke,'VOD_ORIGINAL_GROUPED')
	RIpkMOAGTFo4tdSCw5c2NV = NUauTXxKLAoqQtJkglSFRWE(to9lNhTbJRyLfzwv21Yina7sZrPC,'int','IGNORED','__COUNT__')
	bRNq9uInalF82HKkweQfzs = NUauTXxKLAoqQtJkglSFRWE(to9lNhTbJRyLfzwv21Yina7sZrPC,'int','LIVE_ORIGINAL_GROUPED','__COUNT__')
	vnIcKWtFLACM4OHBalRuZmpX5P = NUauTXxKLAoqQtJkglSFRWE(ezcN4709H8LoyRfIv2mb,'int','VOD_ORIGINAL_GROUPED','__COUNT__')
	l5EGTb7pWO8BjvhCFaZK = NUauTXxKLAoqQtJkglSFRWE(to9lNhTbJRyLfzwv21Yina7sZrPC,'int','LIVE_GROUPED','__COUNT__')
	awQnMZS7z4Ed2 = NUauTXxKLAoqQtJkglSFRWE(to9lNhTbJRyLfzwv21Yina7sZrPC,'int','LIVE_UNKNOWN_GROUPED','__COUNT__')
	k0NjVb59KEIFxqCW4twTSgp = NUauTXxKLAoqQtJkglSFRWE(to9lNhTbJRyLfzwv21Yina7sZrPC,'int','VOD_MOVIES_GROUPED','__COUNT__')
	WLVxGpM6g3dk2vhq7fu4OrHnNsKP = NUauTXxKLAoqQtJkglSFRWE(ezcN4709H8LoyRfIv2mb,'int','VOD_SERIES_GROUPED','__COUNT__')
	EwGZL0Q7YhWNmdoO3MCfIjVK = NUauTXxKLAoqQtJkglSFRWE(to9lNhTbJRyLfzwv21Yina7sZrPC,'int','VOD_UNKNOWN_GROUPED','__COUNT__')
	EETCAlxZ1nfYG4DjKkVBReU8pFu2yX = NUauTXxKLAoqQtJkglSFRWE(ezcN4709H8LoyRfIv2mb,'list','VOD_SERIES_GROUPED','__GROUPS__')
	RQdB3OJPA7w1oT2i068Yb = []
	for aBXgWuYGwdyS8k0jF4efM5QOcDL,EoMKR2biY0 in EETCAlxZ1nfYG4DjKkVBReU8pFu2yX:
		VHDr1lgxBdwSPJy3KaTzRWcAhF = aBXgWuYGwdyS8k0jF4efM5QOcDL.split('__SERIES__')[1]
		RQdB3OJPA7w1oT2i068Yb.append(VHDr1lgxBdwSPJy3KaTzRWcAhF)
	fcDINanAQd2Lg = len(RQdB3OJPA7w1oT2i068Yb)
	Nkx1U6BAd2ClyzDqW0noOPj3h = int(k0NjVb59KEIFxqCW4twTSgp)+int(WLVxGpM6g3dk2vhq7fu4OrHnNsKP)+int(EwGZL0Q7YhWNmdoO3MCfIjVK)+int(awQnMZS7z4Ed2)+int(l5EGTb7pWO8BjvhCFaZK)
	GNjM8ZTxXRayUKe6qQ013p = ''
	GNjM8ZTxXRayUKe6qQ013p += 'قنوات: '+str(l5EGTb7pWO8BjvhCFaZK)
	GNjM8ZTxXRayUKe6qQ013p += '   .   أفلام: '+str(k0NjVb59KEIFxqCW4twTSgp)
	GNjM8ZTxXRayUKe6qQ013p += '\nمسلسلات: '+str(fcDINanAQd2Lg)
	GNjM8ZTxXRayUKe6qQ013p += '   .   حلقات: '+str(WLVxGpM6g3dk2vhq7fu4OrHnNsKP)
	GNjM8ZTxXRayUKe6qQ013p += '\nقنوات مجهولة: '+str(awQnMZS7z4Ed2)
	GNjM8ZTxXRayUKe6qQ013p += '   .   فيدوهات مجهولة: '+str(EwGZL0Q7YhWNmdoO3MCfIjVK)
	GNjM8ZTxXRayUKe6qQ013p += '\nمجموع القنوات: '+str(bRNq9uInalF82HKkweQfzs)
	GNjM8ZTxXRayUKe6qQ013p += '   .   مجموع الفيديوهات: '+str(vnIcKWtFLACM4OHBalRuZmpX5P)
	GNjM8ZTxXRayUKe6qQ013p += '\n\nمجموع المضافة: '+str(Nkx1U6BAd2ClyzDqW0noOPj3h)
	GNjM8ZTxXRayUKe6qQ013p += '   .   مجموع المهملة: '+str(RIpkMOAGTFo4tdSCw5c2NV)
	if CaiGWx9HlMhRznyFDm1: HHTzVhiY079bvdluNkFQ4wCMpe('center','',v5OBhbICnwmWA8J2MzX7D,GNjM8ZTxXRayUKe6qQ013p)
	eFfsirVWaXjT0EY21hG3 = GNjM8ZTxXRayUKe6qQ013p.replace('\n\n','\n')
	tr24ZoudmqvxfYCw('NOTICE','.  Counts of IPTV videos   Folder: '+fTLHoIGS2JMYV3jKh7DuW0ke+'\n'+eFfsirVWaXjT0EY21hG3)
	return GNjM8ZTxXRayUKe6qQ013p
def Xjs93SRJtwqc(fTLHoIGS2JMYV3jKh7DuW0ke,CaiGWx9HlMhRznyFDm1=True):
	if CaiGWx9HlMhRznyFDm1:
		Bkab1Avo3fYG9s6lZcOITDXd4MFi = OxCB4medn1('center','','','مسح ملفات ـIPTV','تستطيع في أي وقت الدخول إلى قائمة ـIPTV وجلب ملفات ـIPTV جديدة .. هل تريد الآن مسح الملفات القديمة المخزنة في البرنامج ؟!')
		if Bkab1Avo3fYG9s6lZcOITDXd4MFi!=1: return
		Rt4WbmOnQpL = qqXYCDM3kcB7mNj6W2h8dwb.replace('___','_'+fTLHoIGS2JMYV3jKh7DuW0ke)
		try: hhHq8m5vauKG9dl.remove(Rt4WbmOnQpL)
		except: pass
	Rt4WbmOnQpL = zIB8rhRY234a.replace('___','_'+fTLHoIGS2JMYV3jKh7DuW0ke)
	try: hhHq8m5vauKG9dl.remove(Rt4WbmOnQpL)
	except: pass
	Rt4WbmOnQpL = k1dRDmf9BNME6UcoVQeO7P3Y.replace('___','_'+fTLHoIGS2JMYV3jKh7DuW0ke)
	try: hhHq8m5vauKG9dl.remove(Rt4WbmOnQpL)
	except: pass
	ibdKZ0sMlyrDcaJgPFV(hosgCj2byWvuVT,'SECTIONS_IPTV','SECTIONS_IPTV_'+fTLHoIGS2JMYV3jKh7DuW0ke)
	ibdKZ0sMlyrDcaJgPFV(hosgCj2byWvuVT,'SECTIONS_IPTV','SECTIONS_IPTV_ALL')
	MCAInGyaz6mZwUx4gjqBb(False)
	m8mDHu2eZKoJCMXw3bPrUz(fTLHoIGS2JMYV3jKh7DuW0ke)
	if CaiGWx9HlMhRznyFDm1:
		HHTzVhiY079bvdluNkFQ4wCMpe('','','رسالة من المبرمج','تم مسح جميع ملفات ـIPTV')
		cPwDBuG4HVTCdQ9JmMeoWjNY2hX.executebuiltin('Container.Refresh')
	return
def KHWOFrzptwybYx(fTLHoIGS2JMYV3jKh7DuW0ke='',CaiGWx9HlMhRznyFDm1=True):
	if fTLHoIGS2JMYV3jKh7DuW0ke:
		sEyDZTBxj9l = cHa5JRAQ3ZKku7(str(fTLHoIGS2JMYV3jKh7DuW0ke),'DUMMY')
		vWK3cmrB9SsT4dLwU = NUauTXxKLAoqQtJkglSFRWE(sEyDZTBxj9l,'str','DUMMY','__DUMMY__')
		if vWK3cmrB9SsT4dLwU: return True
	else:
		fTLHoIGS2JMYV3jKh7DuW0ke = '1'
		for r0djYXtTGD6HhniSkCp in range(1,SS2ZAHCRpu8QxIao7BMq+1):
			sEyDZTBxj9l = cHa5JRAQ3ZKku7(str(r0djYXtTGD6HhniSkCp),'DUMMY')
			vWK3cmrB9SsT4dLwU = NUauTXxKLAoqQtJkglSFRWE(sEyDZTBxj9l,'str','DUMMY','__DUMMY__')
			if vWK3cmrB9SsT4dLwU: return True
	if CaiGWx9HlMhRznyFDm1:
		HHTzVhiY079bvdluNkFQ4wCMpe('','','رسالة من المبرمج','هذا الجزء من البرنامج يحتاج اشتراك IPTV مدفوع من شركة IPTV .. ونوع الرابط المطلوب هو  m3u .. وهذا مثال لتوضيح شكل الرابط المطلوب في هذا البرنامج  [COLOR FFC89008] \n\nhttp://xyz.xyz/get.php?username=xyz&password=xyz&type=m3u_plus [/COLOR]')
		v5OBhbICnwmWA8J2MzX7D = 'إضافة وتغيير رابط '+KnGrOQsDgfB8Raj9C2AZJuYcTxP[1]+' (مجلد '+KnGrOQsDgfB8Raj9C2AZJuYcTxP[int(fTLHoIGS2JMYV3jKh7DuW0ke)]+')'
		Bkab1Avo3fYG9s6lZcOITDXd4MFi = OxCB4medn1('','','',v5OBhbICnwmWA8J2MzX7D,'لإضافة رابط IPTV .. أولا أفتح قائمة IPTV .. وثانيا أنقر على إضافة رابط أو اشتراك ـIPTV .. وثالثا أنقر على جلب ملفات ـIPTV \n\n هل تريد إضافة أو تغيير رابط IPTV الآن ؟!')
		if Bkab1Avo3fYG9s6lZcOITDXd4MFi==1: gmfoXnU7hlQ5qL9euC(fTLHoIGS2JMYV3jKh7DuW0ke)
	return False
def ZQTkpw4se6EOaIrgNLn(roQvPeSDl4p,fTLHoIGS2JMYV3jKh7DuW0ke='',dMu4F8L5Azo6IJ2aleywBmb='',uVGD6ZCHboELna3i7hKM4YPNS=''):
	if not uVGD6ZCHboELna3i7hKM4YPNS: uVGD6ZCHboELna3i7hKM4YPNS = '1'
	GlveBZnj3sLDrPIpJ64oi2aYW,xdWIA3KvVbtMaszgNPyZEn9fQ,CaiGWx9HlMhRznyFDm1 = XDzpr8RxgZhT(roQvPeSDl4p)
	if not KHWOFrzptwybYx(fTLHoIGS2JMYV3jKh7DuW0ke,CaiGWx9HlMhRznyFDm1): return
	if not GlveBZnj3sLDrPIpJ64oi2aYW:
		GlveBZnj3sLDrPIpJ64oi2aYW = CjyEnpfQ23o0PYwDtLId()
		if not GlveBZnj3sLDrPIpJ64oi2aYW: return
	JMrSWYaUBF = ['','LIVE_GROUPED_SORTED','VOD_MOVIES_GROUPED_SORTED','VOD_SERIES_GROUPED_SORTED','VOD_UNKNOWN_GROUPED_SORTED','LIVE_UNKNOWN_GROUPED_SORTED']
	if not dMu4F8L5Azo6IJ2aleywBmb:
		if not CaiGWx9HlMhRznyFDm1:
			if   '_IPTV-LIVE_' in xdWIA3KvVbtMaszgNPyZEn9fQ: dMu4F8L5Azo6IJ2aleywBmb = JMrSWYaUBF[1]
			elif '_IPTV-MOVIES' in xdWIA3KvVbtMaszgNPyZEn9fQ: dMu4F8L5Azo6IJ2aleywBmb = JMrSWYaUBF[2]
			elif '_IPTV-SERIES' in xdWIA3KvVbtMaszgNPyZEn9fQ: dMu4F8L5Azo6IJ2aleywBmb = JMrSWYaUBF[3]
			else: dMu4F8L5Azo6IJ2aleywBmb = JMrSWYaUBF[0]
		else:
			LhCbIcgYFi7 = ['الكل','قنوات','أفلام','مسلسلات','فيديوهات مجهولة','قنوات مجهولة']
			PTQimzWJpkrt6H = F2yZPukcUh09sqCI8nYw7e('أختر البحث المناسب', LhCbIcgYFi7)
			if PTQimzWJpkrt6H==-1: return
			dMu4F8L5Azo6IJ2aleywBmb = JMrSWYaUBF[PTQimzWJpkrt6H]
	GlveBZnj3sLDrPIpJ64oi2aYW = GlveBZnj3sLDrPIpJ64oi2aYW+'_NODIALOGS_'
	if fTLHoIGS2JMYV3jKh7DuW0ke: NBoCjHK6ITwgY5OxeuALPlZ(GlveBZnj3sLDrPIpJ64oi2aYW,fTLHoIGS2JMYV3jKh7DuW0ke,dMu4F8L5Azo6IJ2aleywBmb,uVGD6ZCHboELna3i7hKM4YPNS)
	else:
		for fTLHoIGS2JMYV3jKh7DuW0ke in range(1,SS2ZAHCRpu8QxIao7BMq+1):
			NBoCjHK6ITwgY5OxeuALPlZ(GlveBZnj3sLDrPIpJ64oi2aYW,str(fTLHoIGS2JMYV3jKh7DuW0ke),dMu4F8L5Azo6IJ2aleywBmb,uVGD6ZCHboELna3i7hKM4YPNS)
		OWasmQ27g3Dbljpo[:] = sorted(OWasmQ27g3Dbljpo,reverse=False,key=lambda JDv1uYxBEPcFGwrmlfzSOC: JDv1uYxBEPcFGwrmlfzSOC[1].lower())
	return
def NBoCjHK6ITwgY5OxeuALPlZ(roQvPeSDl4p,fTLHoIGS2JMYV3jKh7DuW0ke,dMu4F8L5Azo6IJ2aleywBmb='',uVGD6ZCHboELna3i7hKM4YPNS=''):
	if not uVGD6ZCHboELna3i7hKM4YPNS: uVGD6ZCHboELna3i7hKM4YPNS = '1'
	GlveBZnj3sLDrPIpJ64oi2aYW,xdWIA3KvVbtMaszgNPyZEn9fQ,CaiGWx9HlMhRznyFDm1 = XDzpr8RxgZhT(roQvPeSDl4p)
	if not fTLHoIGS2JMYV3jKh7DuW0ke: return
	if not KHWOFrzptwybYx(fTLHoIGS2JMYV3jKh7DuW0ke,CaiGWx9HlMhRznyFDm1): return
	if not GlveBZnj3sLDrPIpJ64oi2aYW:
		GlveBZnj3sLDrPIpJ64oi2aYW = CjyEnpfQ23o0PYwDtLId()
		if not GlveBZnj3sLDrPIpJ64oi2aYW: return
	JMrSWYaUBF = ['','LIVE_GROUPED_SORTED','VOD_MOVIES_GROUPED_SORTED','VOD_SERIES_GROUPED_SORTED','VOD_UNKNOWN_GROUPED_SORTED','LIVE_UNKNOWN_GROUPED_SORTED']
	if not dMu4F8L5Azo6IJ2aleywBmb:
		if not CaiGWx9HlMhRznyFDm1:
			if   '_IPTV-LIVE_' in xdWIA3KvVbtMaszgNPyZEn9fQ: dMu4F8L5Azo6IJ2aleywBmb = JMrSWYaUBF[1]
			elif '_IPTV-MOVIES' in xdWIA3KvVbtMaszgNPyZEn9fQ: dMu4F8L5Azo6IJ2aleywBmb = JMrSWYaUBF[2]
			elif '_IPTV-SERIES' in xdWIA3KvVbtMaszgNPyZEn9fQ: dMu4F8L5Azo6IJ2aleywBmb = JMrSWYaUBF[3]
			else: dMu4F8L5Azo6IJ2aleywBmb = JMrSWYaUBF[0]
		else:
			LhCbIcgYFi7 = ['الكل','قنوات','أفلام','مسلسلات','فيديوهات مجهولة','قنوات مجهولة']
			PTQimzWJpkrt6H = F2yZPukcUh09sqCI8nYw7e('أختر البحث المناسب', LhCbIcgYFi7)
			if PTQimzWJpkrt6H==-1: return
			dMu4F8L5Azo6IJ2aleywBmb = JMrSWYaUBF[PTQimzWJpkrt6H]
	MMdlOKoGAkNF1itxR = GlveBZnj3sLDrPIpJ64oi2aYW.lower()
	sEyDZTBxj9l = cHa5JRAQ3ZKku7(fTLHoIGS2JMYV3jKh7DuW0ke,'SEARCH')
	RqIMxSdNAFb7P = NUauTXxKLAoqQtJkglSFRWE(sEyDZTBxj9l,'list','SEARCH',(dMu4F8L5Azo6IJ2aleywBmb,MMdlOKoGAkNF1itxR))
	if not RqIMxSdNAFb7P:
		FFaATEPXyBgc1HGjhsfxu6pvRo9iQ2,W62w1knf98T43jsRYliCxr7q = [],[]
		if not dMu4F8L5Azo6IJ2aleywBmb: KocR8xBazfgkq = [1,2,3,4,5]
		else: KocR8xBazfgkq = [JMrSWYaUBF.index(dMu4F8L5Azo6IJ2aleywBmb)]
		for tdpTaMcz6ZfOUAvx0ByPnLrJob in KocR8xBazfgkq:
			sEyDZTBxj9l = cHa5JRAQ3ZKku7(fTLHoIGS2JMYV3jKh7DuW0ke,JMrSWYaUBF[tdpTaMcz6ZfOUAvx0ByPnLrJob])
			if tdpTaMcz6ZfOUAvx0ByPnLrJob!=3:
				bb2Wi1TrnXpSA4wgfszMvcxd0O3mL = NUauTXxKLAoqQtJkglSFRWE(sEyDZTBxj9l,'dict',JMrSWYaUBF[tdpTaMcz6ZfOUAvx0ByPnLrJob])
				del bb2Wi1TrnXpSA4wgfszMvcxd0O3mL['__COUNT__']
				del bb2Wi1TrnXpSA4wgfszMvcxd0O3mL['__GROUPS__']
				del bb2Wi1TrnXpSA4wgfszMvcxd0O3mL['__SEQUENCED_COLUMNS__']
				EETCAlxZ1nfYG4DjKkVBReU8pFu2yX = list(bb2Wi1TrnXpSA4wgfszMvcxd0O3mL.keys())
				for aBXgWuYGwdyS8k0jF4efM5QOcDL in EETCAlxZ1nfYG4DjKkVBReU8pFu2yX:
					for dGlmU8JqW5yFAtcsg,yHAD9oVfdieMNhC,gC2hO80boRyM7TBGqD,EoMKR2biY0 in bb2Wi1TrnXpSA4wgfszMvcxd0O3mL[aBXgWuYGwdyS8k0jF4efM5QOcDL]:
						if MMdlOKoGAkNF1itxR in yHAD9oVfdieMNhC.lower(): W62w1knf98T43jsRYliCxr7q.append((yHAD9oVfdieMNhC,gC2hO80boRyM7TBGqD,EoMKR2biY0))
					del bb2Wi1TrnXpSA4wgfszMvcxd0O3mL[aBXgWuYGwdyS8k0jF4efM5QOcDL]
				del bb2Wi1TrnXpSA4wgfszMvcxd0O3mL
			else: EETCAlxZ1nfYG4DjKkVBReU8pFu2yX = NUauTXxKLAoqQtJkglSFRWE(sEyDZTBxj9l,'list',JMrSWYaUBF[tdpTaMcz6ZfOUAvx0ByPnLrJob],'__GROUPS__')
			for aBXgWuYGwdyS8k0jF4efM5QOcDL in EETCAlxZ1nfYG4DjKkVBReU8pFu2yX:
				try: aBXgWuYGwdyS8k0jF4efM5QOcDL,EoMKR2biY0 = aBXgWuYGwdyS8k0jF4efM5QOcDL
				except: EoMKR2biY0 = ''
				if MMdlOKoGAkNF1itxR in aBXgWuYGwdyS8k0jF4efM5QOcDL.lower():
					if tdpTaMcz6ZfOUAvx0ByPnLrJob!=3: uk96yvYDlRS7nMt0WeQ = aBXgWuYGwdyS8k0jF4efM5QOcDL
					else:
						Tu82Ar7n6YRQmGw1xze95jdKXy,O8o4wEI93GfiX7qCyKbe0BUF2 = aBXgWuYGwdyS8k0jF4efM5QOcDL.split('__SERIES__')
						if MMdlOKoGAkNF1itxR in Tu82Ar7n6YRQmGw1xze95jdKXy.lower(): uk96yvYDlRS7nMt0WeQ = Tu82Ar7n6YRQmGw1xze95jdKXy
						else: uk96yvYDlRS7nMt0WeQ = O8o4wEI93GfiX7qCyKbe0BUF2
					FFaATEPXyBgc1HGjhsfxu6pvRo9iQ2.append((aBXgWuYGwdyS8k0jF4efM5QOcDL,uk96yvYDlRS7nMt0WeQ,JMrSWYaUBF[tdpTaMcz6ZfOUAvx0ByPnLrJob],EoMKR2biY0))
			del EETCAlxZ1nfYG4DjKkVBReU8pFu2yX
		FFaATEPXyBgc1HGjhsfxu6pvRo9iQ2 = set(FFaATEPXyBgc1HGjhsfxu6pvRo9iQ2)
		W62w1knf98T43jsRYliCxr7q = set(W62w1knf98T43jsRYliCxr7q)
		FFaATEPXyBgc1HGjhsfxu6pvRo9iQ2 = sorted(FFaATEPXyBgc1HGjhsfxu6pvRo9iQ2,reverse=False,key=lambda JDv1uYxBEPcFGwrmlfzSOC: JDv1uYxBEPcFGwrmlfzSOC[1])
		W62w1knf98T43jsRYliCxr7q = sorted(W62w1knf98T43jsRYliCxr7q,reverse=False,key=lambda JDv1uYxBEPcFGwrmlfzSOC: JDv1uYxBEPcFGwrmlfzSOC[0])
		Qc96YoCZJOsKUB8yImw034(sEyDZTBxj9l,'SEARCH',(dMu4F8L5Azo6IJ2aleywBmb,MMdlOKoGAkNF1itxR),(FFaATEPXyBgc1HGjhsfxu6pvRo9iQ2,W62w1knf98T43jsRYliCxr7q),iKYM8NdkGHmBcr)
	else: FFaATEPXyBgc1HGjhsfxu6pvRo9iQ2,W62w1knf98T43jsRYliCxr7q = RqIMxSdNAFb7P
	EETCAlxZ1nfYG4DjKkVBReU8pFu2yX = len(FFaATEPXyBgc1HGjhsfxu6pvRo9iQ2)
	gBRxQhWFMtC7e6IHkAzG = len(W62w1knf98T43jsRYliCxr7q)
	NznapDvCteQPx = int(uVGD6ZCHboELna3i7hKM4YPNS)
	Q26QEy7iFXO = max(0,(NznapDvCteQPx-1)*100)
	uue4azx0AkgOTZH7hCItNbGVo = max(0,NznapDvCteQPx*100)
	vTOM0LeKpio8Sh5t = max(0,Q26QEy7iFXO-EETCAlxZ1nfYG4DjKkVBReU8pFu2yX)
	S7ysGgp0hKaqn2bWF = max(0,uue4azx0AkgOTZH7hCItNbGVo-EETCAlxZ1nfYG4DjKkVBReU8pFu2yX)
	for aBXgWuYGwdyS8k0jF4efM5QOcDL,uk96yvYDlRS7nMt0WeQ,aCQ7VGjZ6q5ry1ek,EoMKR2biY0 in FFaATEPXyBgc1HGjhsfxu6pvRo9iQ2[Q26QEy7iFXO:uue4azx0AkgOTZH7hCItNbGVo]:
		Tca7NsYPkIRWtBpFgxLZbSmCi('folder',oYkzVLIgyjNpsiTbZSBQ+uk96yvYDlRS7nMt0WeQ,aCQ7VGjZ6q5ry1ek,234,EoMKR2biY0,'1',aBXgWuYGwdyS8k0jF4efM5QOcDL,'',{'folder':fTLHoIGS2JMYV3jKh7DuW0ke})
	del FFaATEPXyBgc1HGjhsfxu6pvRo9iQ2
	for yHAD9oVfdieMNhC,gC2hO80boRyM7TBGqD,EoMKR2biY0 in W62w1knf98T43jsRYliCxr7q[vTOM0LeKpio8Sh5t:S7ysGgp0hKaqn2bWF]:
		RRftazgYLTOxoBsZlhrwWq8 = fDEdQSsq1uPoU(gC2hO80boRyM7TBGqD)
		RGDQbxHAi1UpIuNveqTFXSw9gZjc4 = 'live'
		if '.mkv' in RRftazgYLTOxoBsZlhrwWq8 or 'VOD' in dMu4F8L5Azo6IJ2aleywBmb: RGDQbxHAi1UpIuNveqTFXSw9gZjc4 = 'video'
		Tca7NsYPkIRWtBpFgxLZbSmCi(RGDQbxHAi1UpIuNveqTFXSw9gZjc4,oYkzVLIgyjNpsiTbZSBQ+yHAD9oVfdieMNhC,gC2hO80boRyM7TBGqD,235,EoMKR2biY0,'','','',{'folder':fTLHoIGS2JMYV3jKh7DuW0ke})
	del W62w1knf98T43jsRYliCxr7q
	dlU0EksuLjrBaq(fTLHoIGS2JMYV3jKh7DuW0ke,uVGD6ZCHboELna3i7hKM4YPNS,dMu4F8L5Azo6IJ2aleywBmb,239,EETCAlxZ1nfYG4DjKkVBReU8pFu2yX+gBRxQhWFMtC7e6IHkAzG,GlveBZnj3sLDrPIpJ64oi2aYW+'_NODIALOGS_')
	return
def dlU0EksuLjrBaq(fTLHoIGS2JMYV3jKh7DuW0ke,uVGD6ZCHboELna3i7hKM4YPNS,dMu4F8L5Azo6IJ2aleywBmb,nnPsf4XLIJ7RWF,Nkx1U6BAd2ClyzDqW0noOPj3h,uHGMxiZfcoErOyXghvnWUK):
	if uVGD6ZCHboELna3i7hKM4YPNS!='1': Tca7NsYPkIRWtBpFgxLZbSmCi('folder',oYkzVLIgyjNpsiTbZSBQ+'صفحة '+str(1),dMu4F8L5Azo6IJ2aleywBmb,nnPsf4XLIJ7RWF,'',str(1),uHGMxiZfcoErOyXghvnWUK,'',{'folder':fTLHoIGS2JMYV3jKh7DuW0ke})
	if not Nkx1U6BAd2ClyzDqW0noOPj3h: Nkx1U6BAd2ClyzDqW0noOPj3h = 0
	Ivhba2zeGcCo5NBDn7Fm0Zk9xY = int(Nkx1U6BAd2ClyzDqW0noOPj3h/100)+1
	for NznapDvCteQPx in range(2,Ivhba2zeGcCo5NBDn7Fm0Zk9xY):
		wjNixHdgWLyZS59I = (NznapDvCteQPx%10==0 or int(uVGD6ZCHboELna3i7hKM4YPNS)-4<NznapDvCteQPx<int(uVGD6ZCHboELna3i7hKM4YPNS)+4)
		p2pHPMV4sadmf8qJBOZb0 = (wjNixHdgWLyZS59I and int(uVGD6ZCHboELna3i7hKM4YPNS)-40<NznapDvCteQPx<int(uVGD6ZCHboELna3i7hKM4YPNS)+40)
		if str(NznapDvCteQPx)!=uVGD6ZCHboELna3i7hKM4YPNS and (NznapDvCteQPx%100==0 or p2pHPMV4sadmf8qJBOZb0):
			Tca7NsYPkIRWtBpFgxLZbSmCi('folder',oYkzVLIgyjNpsiTbZSBQ+'صفحة '+str(NznapDvCteQPx),dMu4F8L5Azo6IJ2aleywBmb,nnPsf4XLIJ7RWF,'',str(NznapDvCteQPx),uHGMxiZfcoErOyXghvnWUK,'',{'folder':fTLHoIGS2JMYV3jKh7DuW0ke})
	if str(Ivhba2zeGcCo5NBDn7Fm0Zk9xY)!=uVGD6ZCHboELna3i7hKM4YPNS: Tca7NsYPkIRWtBpFgxLZbSmCi('folder',oYkzVLIgyjNpsiTbZSBQ+'أخر صفحة '+str(Ivhba2zeGcCo5NBDn7Fm0Zk9xY),dMu4F8L5Azo6IJ2aleywBmb,nnPsf4XLIJ7RWF,'',str(Ivhba2zeGcCo5NBDn7Fm0Zk9xY),uHGMxiZfcoErOyXghvnWUK,'',{'folder':fTLHoIGS2JMYV3jKh7DuW0ke})
	return
def cHa5JRAQ3ZKku7(fTLHoIGS2JMYV3jKh7DuW0ke,dMu4F8L5Azo6IJ2aleywBmb):
	if 'SERIES' in dMu4F8L5Azo6IJ2aleywBmb or 'VOD_ORIGINAL' in dMu4F8L5Azo6IJ2aleywBmb: sEyDZTBxj9l = k1dRDmf9BNME6UcoVQeO7P3Y
	else: sEyDZTBxj9l = zIB8rhRY234a
	sEyDZTBxj9l = sEyDZTBxj9l.replace('___','_'+fTLHoIGS2JMYV3jKh7DuW0ke)
	return sEyDZTBxj9l
def dWbgAVm2Tv5tID4XP9q(fTLHoIGS2JMYV3jKh7DuW0ke,dMu4F8L5Azo6IJ2aleywBmb,kUxyZMQ2Svz9A4JNBYtHn5sbDRr):
	LLmOgfvERFwWp9DQMoBHS36rd,fUSnuQTRBwOtFhZz36k9y,lBeGVXTt0qD,v1IzDVTBhweb3tRr6YCyoNK,LX35qsjfcIWaDT8S462 = gmcELYbTJS(fTLHoIGS2JMYV3jKh7DuW0ke)
	if not v1IzDVTBhweb3tRr6YCyoNK: return
	Mm7XCRohg3iUSfJKdWsIqx = poTRFiyNCYwsO8dhMBHZ2lAIvL1(fTLHoIGS2JMYV3jKh7DuW0ke)
	if   dMu4F8L5Azo6IJ2aleywBmb=='XTREAM_LIVE_GROUPS': gC2hO80boRyM7TBGqD = LLmOgfvERFwWp9DQMoBHS36rd+'&action=get_live_categories'
	elif dMu4F8L5Azo6IJ2aleywBmb=='XTREAM_VOD_GROUPS': gC2hO80boRyM7TBGqD = LLmOgfvERFwWp9DQMoBHS36rd+'&action=get_vod_categories'
	elif dMu4F8L5Azo6IJ2aleywBmb=='XTREAM_SERIES_GROUPS': gC2hO80boRyM7TBGqD = LLmOgfvERFwWp9DQMoBHS36rd+'&action=get_series_categories'
	elif dMu4F8L5Azo6IJ2aleywBmb=='XTREAM_LIVE_ITEMS': gC2hO80boRyM7TBGqD = LLmOgfvERFwWp9DQMoBHS36rd+'&action=get_live_streams&category_id='+kUxyZMQ2Svz9A4JNBYtHn5sbDRr
	elif dMu4F8L5Azo6IJ2aleywBmb=='XTREAM_VOD_ITEMS': gC2hO80boRyM7TBGqD = LLmOgfvERFwWp9DQMoBHS36rd+'&action=get_vod_streams&category_id='+kUxyZMQ2Svz9A4JNBYtHn5sbDRr
	elif dMu4F8L5Azo6IJ2aleywBmb=='XTREAM_SERIES_ITEMS': gC2hO80boRyM7TBGqD = LLmOgfvERFwWp9DQMoBHS36rd+'&action=get_series&category_id='+kUxyZMQ2Svz9A4JNBYtHn5sbDRr
	elif dMu4F8L5Azo6IJ2aleywBmb=='XTREAM_EPISODES': gC2hO80boRyM7TBGqD = LLmOgfvERFwWp9DQMoBHS36rd+'&action=get_series_info&series_id='+kUxyZMQ2Svz9A4JNBYtHn5sbDRr
	else: return
	Ba3qhge51Hynsz8mcoW = A6F71g3cqN4(Z7uFdWIRv9ybj0,'GET',gC2hO80boRyM7TBGqD,'',Mm7XCRohg3iUSfJKdWsIqx,'','','IPTV-XTREAM_MENUS-1st')
	BRufE2IykDCOaNAv9iU = Ba3qhge51Hynsz8mcoW.content
	if Yd6t3PjlLKk: BRufE2IykDCOaNAv9iU = BRufE2IykDCOaNAv9iU.decode('utf8').encode('utf8')
	t9uDI3ihm4EOLgTdCbnk = NL0JIkbrEWqTYj61vVKGCnBw37MsOF('list',BRufE2IykDCOaNAv9iU)
	if 'GROUPS' in dMu4F8L5Azo6IJ2aleywBmb:
		dMu4F8L5Azo6IJ2aleywBmb = dMu4F8L5Azo6IJ2aleywBmb.replace('_GROUPS','_ITEMS')
		t9uDI3ihm4EOLgTdCbnk = sorted(t9uDI3ihm4EOLgTdCbnk,reverse=False,key=lambda JDv1uYxBEPcFGwrmlfzSOC: JDv1uYxBEPcFGwrmlfzSOC['category_name'].lower())
		for aBXgWuYGwdyS8k0jF4efM5QOcDL in t9uDI3ihm4EOLgTdCbnk:
			ry3BRqwNOLSVizQegC91MvnElk = aBXgWuYGwdyS8k0jF4efM5QOcDL['category_id']
			yHAD9oVfdieMNhC = aBXgWuYGwdyS8k0jF4efM5QOcDL['category_name']
			Tca7NsYPkIRWtBpFgxLZbSmCi('folder',oYkzVLIgyjNpsiTbZSBQ+yHAD9oVfdieMNhC,dMu4F8L5Azo6IJ2aleywBmb,285,'','',str(ry3BRqwNOLSVizQegC91MvnElk),'',{'folder':fTLHoIGS2JMYV3jKh7DuW0ke})
	elif dMu4F8L5Azo6IJ2aleywBmb=='XTREAM_SERIES_ITEMS':
		t9uDI3ihm4EOLgTdCbnk = sorted(t9uDI3ihm4EOLgTdCbnk,reverse=False,key=lambda JDv1uYxBEPcFGwrmlfzSOC: JDv1uYxBEPcFGwrmlfzSOC['name'].lower())
		for tpMOXaTvdiI in t9uDI3ihm4EOLgTdCbnk:
			yHAD9oVfdieMNhC = tpMOXaTvdiI['name']
			ggOIGYi4nEAJ2c8hvFufLRBq = tpMOXaTvdiI['cover']
			ry3BRqwNOLSVizQegC91MvnElk = tpMOXaTvdiI['series_id']
			Tca7NsYPkIRWtBpFgxLZbSmCi('folder',oYkzVLIgyjNpsiTbZSBQ+yHAD9oVfdieMNhC,'XTREAM_EPISODES',285,ggOIGYi4nEAJ2c8hvFufLRBq,'',str(ry3BRqwNOLSVizQegC91MvnElk),'',{'folder':fTLHoIGS2JMYV3jKh7DuW0ke})
	elif dMu4F8L5Azo6IJ2aleywBmb=='XTREAM_EPISODES':
		ggOIGYi4nEAJ2c8hvFufLRBq = t9uDI3ihm4EOLgTdCbnk['info']['cover']
		aaYDh2EzJ5ky = t9uDI3ihm4EOLgTdCbnk['info']['name']
		wwc3a0DdlkGOVhjQA = t9uDI3ihm4EOLgTdCbnk['episodes']
		for f9blZaF2RVHCWs4xyNcu5i in wwc3a0DdlkGOVhjQA:
			Qt437oNCMeqvhnygkH = wwc3a0DdlkGOVhjQA[f9blZaF2RVHCWs4xyNcu5i]
			for TTeH1KIjy4RaSnqPJpw in Qt437oNCMeqvhnygkH:
				yHAD9oVfdieMNhC = TTeH1KIjy4RaSnqPJpw['title']
				fwdL5DAnv6gJxMK = ZXFs0mEPR8qI2zj.findall('\d+.(S\d+E\d+)',yHAD9oVfdieMNhC,ZXFs0mEPR8qI2zj.DOTALL)
				if fwdL5DAnv6gJxMK: yHAD9oVfdieMNhC = aaYDh2EzJ5ky+' '+fwdL5DAnv6gJxMK[0]
				ry3BRqwNOLSVizQegC91MvnElk = TTeH1KIjy4RaSnqPJpw['id']
				N6WmODoxlZC = TTeH1KIjy4RaSnqPJpw['container_extension']
				gC2hO80boRyM7TBGqD = LLmOgfvERFwWp9DQMoBHS36rd.split('/player_api.php')[0]+'/series/'+v1IzDVTBhweb3tRr6YCyoNK+'/'+LX35qsjfcIWaDT8S462+'/'+str(ry3BRqwNOLSVizQegC91MvnElk)+'.'+N6WmODoxlZC
				Tca7NsYPkIRWtBpFgxLZbSmCi('video',oYkzVLIgyjNpsiTbZSBQ+yHAD9oVfdieMNhC,gC2hO80boRyM7TBGqD,235,ggOIGYi4nEAJ2c8hvFufLRBq,'','','',{'folder':fTLHoIGS2JMYV3jKh7DuW0ke})
	elif 'ITEMS' in dMu4F8L5Azo6IJ2aleywBmb:
		RGDQbxHAi1UpIuNveqTFXSw9gZjc4 = 'live' if 'LIVE' in dMu4F8L5Azo6IJ2aleywBmb else 'video'
		t9uDI3ihm4EOLgTdCbnk = sorted(t9uDI3ihm4EOLgTdCbnk,reverse=False,key=lambda JDv1uYxBEPcFGwrmlfzSOC: JDv1uYxBEPcFGwrmlfzSOC['name'].lower())
		for OcfsABlYMo2QwIm01Gaqph in t9uDI3ihm4EOLgTdCbnk:
			yHAD9oVfdieMNhC = OcfsABlYMo2QwIm01Gaqph['name']
			ggOIGYi4nEAJ2c8hvFufLRBq = OcfsABlYMo2QwIm01Gaqph['stream_icon']
			ry3BRqwNOLSVizQegC91MvnElk = OcfsABlYMo2QwIm01Gaqph['stream_id']
			try:
				N6WmODoxlZC = OcfsABlYMo2QwIm01Gaqph['container_extension']
				if N6WmODoxlZC: N6WmODoxlZC = '.'+N6WmODoxlZC
			except: N6WmODoxlZC = ''
			if OcfsABlYMo2QwIm01Gaqph['stream_type']=='live': ffaXcwQevDRLGm2,jTiMKWYxJDaOpzotgLq9 = '','live'
			elif OcfsABlYMo2QwIm01Gaqph['stream_type']=='movie': ffaXcwQevDRLGm2,jTiMKWYxJDaOpzotgLq9 = 'movie/','video'
			gC2hO80boRyM7TBGqD = LLmOgfvERFwWp9DQMoBHS36rd.split('/player_api.php')[0]+'/'+ffaXcwQevDRLGm2+v1IzDVTBhweb3tRr6YCyoNK+'/'+LX35qsjfcIWaDT8S462+'/'+str(ry3BRqwNOLSVizQegC91MvnElk)+N6WmODoxlZC
			Tca7NsYPkIRWtBpFgxLZbSmCi(RGDQbxHAi1UpIuNveqTFXSw9gZjc4,oYkzVLIgyjNpsiTbZSBQ+yHAD9oVfdieMNhC,gC2hO80boRyM7TBGqD,235,ggOIGYi4nEAJ2c8hvFufLRBq,'','','',{'folder':fTLHoIGS2JMYV3jKh7DuW0ke})
	return
def m8mDHu2eZKoJCMXw3bPrUz(fTLHoIGS2JMYV3jKh7DuW0ke):
	EE27SGLBYTbWeywqmkVl61Hj = j2agIU0xsLS6c7T.getSetting('av.language.provider')
	OdLxAVyvHi5X1kq = j2agIU0xsLS6c7T.getSetting('av.language.code')
	ibdKZ0sMlyrDcaJgPFV(hosgCj2byWvuVT,'MENUS_CACHE_'+EE27SGLBYTbWeywqmkVl61Hj+'_'+OdLxAVyvHi5X1kq,'%_IP'+fTLHoIGS2JMYV3jKh7DuW0ke+'_%')
	return