# -*- coding: utf-8 -*-
from j3x780FpaM import *
ll6f2wvU4FdqL3MJyDxORESCK197i = 'ARABICTOONS'
W74fAyGxODoLPs5vMX2l8C93R = '_ART_'
JJTrn6SEtYZV31eyR97 = uReHcEzxkTm6pN4Q[ll6f2wvU4FdqL3MJyDxORESCK197i][0]
def OVQIAezo6U1NSTl4L(mode,url,text):
	if   mode==730: HkKfQCS7RIa4xi3houjvl = oMUN5hPpTkxVZG12Qiva8BKnyw6()
	elif mode==731: HkKfQCS7RIa4xi3houjvl = RxAy5lEFQ1chv0BrdU4p6Pt2(url)
	elif mode==732: HkKfQCS7RIa4xi3houjvl = jXYwiO9D056pkrzRh1y8tfWJxQoaI3(url)
	elif mode==733: HkKfQCS7RIa4xi3houjvl = pqx0gStI9ojGFP2rWhwRfkVCNX(url)
	elif mode==734: HkKfQCS7RIa4xi3houjvl = oqAEIFjXMy(url)
	elif mode==735: HkKfQCS7RIa4xi3houjvl = fQSos0RMyqNvC3g6BYJVZez2Ujr(url)
	elif mode==739: HkKfQCS7RIa4xi3houjvl = F6OgHwYPRiX10tJEv8r(text)
	else: HkKfQCS7RIa4xi3houjvl = False
	return HkKfQCS7RIa4xi3houjvl
def oMUN5hPpTkxVZG12Qiva8BKnyw6():
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+'بحث في الموقع','',739,'','','_REMEMBERRESULTS_')
	Tca7NsYPkIRWtBpFgxLZbSmCi('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder',ll6f2wvU4FdqL3MJyDxORESCK197i+'_SCRIPT_'+W74fAyGxODoLPs5vMX2l8C93R+'مسلسلات مميزة',JJTrn6SEtYZV31eyR97+'/top.php',735)
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder',ll6f2wvU4FdqL3MJyDxORESCK197i+'_SCRIPT_'+W74fAyGxODoLPs5vMX2l8C93R+'مسلسلات',JJTrn6SEtYZV31eyR97+'/cartoon.php',734)
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder',ll6f2wvU4FdqL3MJyDxORESCK197i+'_SCRIPT_'+W74fAyGxODoLPs5vMX2l8C93R+'افلام',JJTrn6SEtYZV31eyR97+'/movies.php',731)
	return
def oqAEIFjXMy(url):
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+'الكل',url,731)
	wpFmEA3z8JR = A6F71g3cqN4(Z7uFdWIRv9ybj0,'GET',url,'','','','','ARABICTOONS-SERIES_SUBMENU-1st')
	QstumvzTIEUMXCcx06aD4y8nSqH = wpFmEA3z8JR.content
	IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('label="navigation"(.*?)</ul>',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	if IZGcQbePXxwAoyYR1n:
		bdq4e6Wr2gslnSiA38 = IZGcQbePXxwAoyYR1n[0]
		items = ZXFs0mEPR8qI2zj.findall("href='(.*?)'>(.*?)</a>",bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
		for RRucmYBaXegTtNOdGHMQ,title in items:
			RRucmYBaXegTtNOdGHMQ = JJTrn6SEtYZV31eyR97+'/'+RRucmYBaXegTtNOdGHMQ
			title = 'حرف '+title
			Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,731)
	return
def fQSos0RMyqNvC3g6BYJVZez2Ujr(url):
	wpFmEA3z8JR = A6F71g3cqN4(Z7uFdWIRv9ybj0,'GET',url,'','','','','ARABICTOONS-SERIES_FEATURED-2nd')
	QstumvzTIEUMXCcx06aD4y8nSqH = wpFmEA3z8JR.content
	IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('class="slider"(.*?)</ul>',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	if IZGcQbePXxwAoyYR1n:
		bdq4e6Wr2gslnSiA38 = IZGcQbePXxwAoyYR1n[0]
		items = ZXFs0mEPR8qI2zj.findall('title="(.*?)" href="(.*?)".*?src="(.*?)"',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
		for title,RRucmYBaXegTtNOdGHMQ,CrGO63LT7j2UxniW in items:
			RRucmYBaXegTtNOdGHMQ = JJTrn6SEtYZV31eyR97+'/'+RRucmYBaXegTtNOdGHMQ
			CrGO63LT7j2UxniW = JJTrn6SEtYZV31eyR97+'/'+CrGO63LT7j2UxniW
			title = title.strip(' ')
			Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,733,CrGO63LT7j2UxniW)
	return
def RxAy5lEFQ1chv0BrdU4p6Pt2(url):
	wpFmEA3z8JR = A6F71g3cqN4(Z7uFdWIRv9ybj0,'GET',url,'','','','','ARABICTOONS-TITLES-1st')
	QstumvzTIEUMXCcx06aD4y8nSqH = wpFmEA3z8JR.content
	IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall("class='moviesBlocks(.*?)navigation",QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	bdq4e6Wr2gslnSiA38 = IZGcQbePXxwAoyYR1n[0]
	items = ZXFs0mEPR8qI2zj.findall('class="movie".*?href="(.*?)".*?src="(.*?)".*?<b>(.*?)</b>',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
	for RRucmYBaXegTtNOdGHMQ,CrGO63LT7j2UxniW,title in items:
		RRucmYBaXegTtNOdGHMQ = JJTrn6SEtYZV31eyR97+'/'+RRucmYBaXegTtNOdGHMQ
		CrGO63LT7j2UxniW = JJTrn6SEtYZV31eyR97+'/'+CrGO63LT7j2UxniW
		title = title.strip(' ')
		if 'movies.php' in url: Tca7NsYPkIRWtBpFgxLZbSmCi('video',W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,732,CrGO63LT7j2UxniW)
		else: Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,733,CrGO63LT7j2UxniW)
	IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('"pagination(.*?)</ul>',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	if IZGcQbePXxwAoyYR1n:
		bdq4e6Wr2gslnSiA38 = IZGcQbePXxwAoyYR1n[-1]
		items = ZXFs0mEPR8qI2zj.findall('href="(.*?)".*?>(.*?)</a>',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
		for RRucmYBaXegTtNOdGHMQ,title in items:
			RRucmYBaXegTtNOdGHMQ = JJTrn6SEtYZV31eyR97+'/'+RRucmYBaXegTtNOdGHMQ
			title = title.strip(' ')
			title = qpob7TvxHSs4fEzO6(title)
			Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+'صفحة '+title,RRucmYBaXegTtNOdGHMQ,731)
	return
def pqx0gStI9ojGFP2rWhwRfkVCNX(url):
	wpFmEA3z8JR = A6F71g3cqN4(Z7uFdWIRv9ybj0,'GET',url,'','','','','ARABICTOONS-EPISODES-1st')
	QstumvzTIEUMXCcx06aD4y8nSqH = wpFmEA3z8JR.content
	IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall("class='moviesBlocks(.*?)script",QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	if IZGcQbePXxwAoyYR1n:
		bdq4e6Wr2gslnSiA38 = IZGcQbePXxwAoyYR1n[0]
		items = ZXFs0mEPR8qI2zj.findall('class="movie".*?title="(.*?)".*?href="(.*?)".*?src="(.*?)".*?<b>(.*?)</b>',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
		for title,RRucmYBaXegTtNOdGHMQ,CrGO63LT7j2UxniW,YYKqgSAxOPurGvWT0QDwZeRHpiN3c in items:
			RRucmYBaXegTtNOdGHMQ = JJTrn6SEtYZV31eyR97+'/'+RRucmYBaXegTtNOdGHMQ
			CrGO63LT7j2UxniW = JJTrn6SEtYZV31eyR97+'/'+CrGO63LT7j2UxniW
			title = title.strip(' ')
			title = title+' '+YYKqgSAxOPurGvWT0QDwZeRHpiN3c.strip(' ')
			Tca7NsYPkIRWtBpFgxLZbSmCi('video',W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,732,CrGO63LT7j2UxniW)
	return
def jXYwiO9D056pkrzRh1y8tfWJxQoaI3(url):
	yf608hE5KeRG1DscunvrU = []
	wpFmEA3z8JR = A6F71g3cqN4(Z7uFdWIRv9ybj0,'GET',url,'','','','','ARABICTOONS-PLAY-1st')
	QstumvzTIEUMXCcx06aD4y8nSqH = wpFmEA3z8JR.content
	R28S4pFmAojEW7CGnx = ZXFs0mEPR8qI2zj.findall('source src="(.*?)"',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	if R28S4pFmAojEW7CGnx:
		RRucmYBaXegTtNOdGHMQ = R28S4pFmAojEW7CGnx[0]
		if 'Referer=' not in RRucmYBaXegTtNOdGHMQ: RRucmYBaXegTtNOdGHMQ = RRucmYBaXegTtNOdGHMQ+'|Referer=https://www.arabic-toons.com'
		yf608hE5KeRG1DscunvrU.append(RRucmYBaXegTtNOdGHMQ+'?named=__embed')
	import fnxsZbk2Fm
	fnxsZbk2Fm.n2h4SBIzxbgJD3K7rtVej01EuGcHPs(yf608hE5KeRG1DscunvrU,ll6f2wvU4FdqL3MJyDxORESCK197i,'video',url)
	return
def F6OgHwYPRiX10tJEv8r(search):
	search,Y9RKmgsxBefkFcuIj2GULDHy3,showDialogs = XDzpr8RxgZhT(search)
	if search=='': search = CjyEnpfQ23o0PYwDtLId()
	if search=='': return
	search = search.replace(' ','%20')
	YYmyQXglbEewzL3IA2Sd = ['','m']
	Y4yxdBjU2Tm = ['مسلسلات','افلام']
	if showDialogs:
		jQ6w8xOrgYhSHIRpUqzL = F2yZPukcUh09sqCI8nYw7e('اختر النوع المطلوب:', Y4yxdBjU2Tm)
		if jQ6w8xOrgYhSHIRpUqzL==-1: return
	else: jQ6w8xOrgYhSHIRpUqzL = 0
	type = YYmyQXglbEewzL3IA2Sd[jQ6w8xOrgYhSHIRpUqzL]
	url = JJTrn6SEtYZV31eyR97+'/livesearch.php?'+type+'&q='+search
	wpFmEA3z8JR = A6F71g3cqN4(Z7uFdWIRv9ybj0,'GET',url,'','','','','ARABICTOONS-SEARCH-1st')
	QstumvzTIEUMXCcx06aD4y8nSqH = wpFmEA3z8JR.content
	items = ZXFs0mEPR8qI2zj.findall('href="(.*?)">(.*?)<',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	for RRucmYBaXegTtNOdGHMQ,title in items:
		RRucmYBaXegTtNOdGHMQ = JJTrn6SEtYZV31eyR97+'/'+RRucmYBaXegTtNOdGHMQ
		title = title.strip(' ')
		if type=='m': Tca7NsYPkIRWtBpFgxLZbSmCi('video',W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,732)
		else: Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,733)
	return