# -*- coding: utf-8 -*-
from j3x780FpaM import *
ll6f2wvU4FdqL3MJyDxORESCK197i = 'MOVIZLAND'
headers = { 'User-Agent' : '' }
W74fAyGxODoLPs5vMX2l8C93R = '_MVZ_'
JJTrn6SEtYZV31eyR97 = uReHcEzxkTm6pN4Q[ll6f2wvU4FdqL3MJyDxORESCK197i][0]
dJSW5LrBmHfxeu = uReHcEzxkTm6pN4Q[ll6f2wvU4FdqL3MJyDxORESCK197i][1]
def OVQIAezo6U1NSTl4L(mode,url,text):
	if   mode==180: HkKfQCS7RIa4xi3houjvl = oMUN5hPpTkxVZG12Qiva8BKnyw6()
	elif mode==181: HkKfQCS7RIa4xi3houjvl = RxAy5lEFQ1chv0BrdU4p6Pt2(url,text)
	elif mode==182: HkKfQCS7RIa4xi3houjvl = jXYwiO9D056pkrzRh1y8tfWJxQoaI3(url)
	elif mode==183: HkKfQCS7RIa4xi3houjvl = pqx0gStI9ojGFP2rWhwRfkVCNX(url)
	elif mode==188: HkKfQCS7RIa4xi3houjvl = uhyI3UPNRv1ACT()
	elif mode==189: HkKfQCS7RIa4xi3houjvl = F6OgHwYPRiX10tJEv8r(text)
	else: HkKfQCS7RIa4xi3houjvl = False
	return HkKfQCS7RIa4xi3houjvl
def uhyI3UPNRv1ACT():
	message = 'هذا الموقع تغير بالكامل ... وبحاجة الى اعادة برمجة من الصفر ... والمبرمج حاليا مشغول ويعاني من وعكة صحية ... ولهذا سوف يبقى الموقع مغلق الى ما شاء الله'
	HHTzVhiY079bvdluNkFQ4wCMpe('','','رسالة من المبرمج',message)
	return
def oMUN5hPpTkxVZG12Qiva8BKnyw6():
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+'بحث في الموقع','',189,'','','_REMEMBERRESULTS_')
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder',ll6f2wvU4FdqL3MJyDxORESCK197i+'_SCRIPT_'+W74fAyGxODoLPs5vMX2l8C93R+'بوكس اوفيس موفيز لاند',JJTrn6SEtYZV31eyR97,181,'','','box-office')
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder',ll6f2wvU4FdqL3MJyDxORESCK197i+'_SCRIPT_'+W74fAyGxODoLPs5vMX2l8C93R+'أحدث الافلام',JJTrn6SEtYZV31eyR97,181,'','','latest-movies')
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder',ll6f2wvU4FdqL3MJyDxORESCK197i+'_SCRIPT_'+W74fAyGxODoLPs5vMX2l8C93R+'تليفزيون موفيز لاند',JJTrn6SEtYZV31eyR97,181,'','','tv')
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder',ll6f2wvU4FdqL3MJyDxORESCK197i+'_SCRIPT_'+W74fAyGxODoLPs5vMX2l8C93R+'الاكثر مشاهدة',JJTrn6SEtYZV31eyR97,181,'','','top-views')
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder',ll6f2wvU4FdqL3MJyDxORESCK197i+'_SCRIPT_'+W74fAyGxODoLPs5vMX2l8C93R+'أقوى الافلام الحالية',JJTrn6SEtYZV31eyR97,181,'','','top-movies')
	QstumvzTIEUMXCcx06aD4y8nSqH = QuWA3hsmIvockZDiy2rLg(JNsoWV1CXc4xy,JJTrn6SEtYZV31eyR97,'',headers,'','MOVIZLAND-MENU-1st')
	items = ZXFs0mEPR8qI2zj.findall('<h2><a href="(.*?)".*?">(.*?)<',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	for RRucmYBaXegTtNOdGHMQ,title in items:
		Tca7NsYPkIRWtBpFgxLZbSmCi('folder',ll6f2wvU4FdqL3MJyDxORESCK197i+'_SCRIPT_'+W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,181)
	return QstumvzTIEUMXCcx06aD4y8nSqH
def RxAy5lEFQ1chv0BrdU4p6Pt2(url,type=''):
	QstumvzTIEUMXCcx06aD4y8nSqH = QuWA3hsmIvockZDiy2rLg(Z7uFdWIRv9ybj0,url,'',headers,'','MOVIZLAND-ITEMS-1st')
	if type=='latest-movies': bdq4e6Wr2gslnSiA38 = ZXFs0mEPR8qI2zj.findall('class="titleSection">أحدث الأفلام</h1>(.*?)<h1',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)[0]
	elif type=='box-office': bdq4e6Wr2gslnSiA38 = ZXFs0mEPR8qI2zj.findall('class="titleSection">بوكس اوفيس موفيز لاند</h1>(.*?)<h1',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)[0]
	elif type=='top-movies': bdq4e6Wr2gslnSiA38 = ZXFs0mEPR8qI2zj.findall('btn-2-overlay(.*?)<style>',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)[0]
	elif type=='top-views': bdq4e6Wr2gslnSiA38 = ZXFs0mEPR8qI2zj.findall('btn-1 btn-absoly(.*?)btn-2 btn-absoly',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)[0]
	elif type=='tv': bdq4e6Wr2gslnSiA38 = ZXFs0mEPR8qI2zj.findall('class="titleSection">تليفزيون موفيز لاند</h1>(.*?)class="paging"',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)[0]
	else: bdq4e6Wr2gslnSiA38 = QstumvzTIEUMXCcx06aD4y8nSqH
	if type in ['top-views','top-movies']:
		items = ZXFs0mEPR8qI2zj.findall('style="background-image:url\(\'(.*?)\'.*?href="(.*?)".*?href="(.*?)".*?bottom-title.*?>(.*?)<',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
	else: items = ZXFs0mEPR8qI2zj.findall('height="3[0-9]+" src="(.*?)".*?bottom-title.*?href=.*?>(.*?)<.*?href="(.*?)".*?href="(.*?)"',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
	FF1TYf6O5KENr8R72LUVievClmudxD = []
	OVKupw4tFexi6JMykj3lNhW1 = ['فيلم','الحلقة','الحلقه','عرض','Raw','SmackDown','اعلان','اجزاء']
	for CrGO63LT7j2UxniW,ssMt96muVHx,umJRt83OTfvgsBzNi2V5L,IfVB6TCcAkG1tJ5sprlROyP0MFK in items:
		if type in ['top-views','top-movies']:
			CrGO63LT7j2UxniW,RRucmYBaXegTtNOdGHMQ,oKqQr8Ij0btxZ9SDm6h3Nd,title = CrGO63LT7j2UxniW,ssMt96muVHx,umJRt83OTfvgsBzNi2V5L,IfVB6TCcAkG1tJ5sprlROyP0MFK
		else: CrGO63LT7j2UxniW,title,RRucmYBaXegTtNOdGHMQ,oKqQr8Ij0btxZ9SDm6h3Nd = CrGO63LT7j2UxniW,ssMt96muVHx,umJRt83OTfvgsBzNi2V5L,IfVB6TCcAkG1tJ5sprlROyP0MFK
		RRucmYBaXegTtNOdGHMQ = ejBOu2WXwvb4YpITdsLF16(RRucmYBaXegTtNOdGHMQ)
		RRucmYBaXegTtNOdGHMQ = RRucmYBaXegTtNOdGHMQ.replace('?view=true','')
		title = qpob7TvxHSs4fEzO6(title)
		if 'بجودة ' in title or 'بجوده ' in title:
			title = '_MOD_' + title.replace('بجودة ','').replace('بجوده ','')
		title = title.strip(' ')
		if 'الحلقة' in title or 'الحلقه' in title:
			LqYKJ36CBG = ZXFs0mEPR8qI2zj.findall('(.*?) (الحلقة|الحلقه) \d+',title,ZXFs0mEPR8qI2zj.DOTALL)
			if LqYKJ36CBG:
				title = '_MOD_' + LqYKJ36CBG[0][0]
				if title not in FF1TYf6O5KENr8R72LUVievClmudxD:
					Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,183,CrGO63LT7j2UxniW)
					FF1TYf6O5KENr8R72LUVievClmudxD.append(title)
		elif any(AARNPWHjQU9dEmDI in title for AARNPWHjQU9dEmDI in OVKupw4tFexi6JMykj3lNhW1):
			RRucmYBaXegTtNOdGHMQ = RRucmYBaXegTtNOdGHMQ + '?servers=' + oKqQr8Ij0btxZ9SDm6h3Nd
			Tca7NsYPkIRWtBpFgxLZbSmCi('video',W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,182,CrGO63LT7j2UxniW)
		else:
			RRucmYBaXegTtNOdGHMQ = RRucmYBaXegTtNOdGHMQ + '?servers=' + oKqQr8Ij0btxZ9SDm6h3Nd
			Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,183,CrGO63LT7j2UxniW)
	if type=='':
		items = ZXFs0mEPR8qI2zj.findall('\n<li><a href="(.*?)".*?>(.*?)<',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
		for RRucmYBaXegTtNOdGHMQ,title in items:
			title = qpob7TvxHSs4fEzO6(title)
			title = title.replace('الصفحة ','')
			if title!='':
				Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+'صفحة '+title,RRucmYBaXegTtNOdGHMQ,181)
	return
def pqx0gStI9ojGFP2rWhwRfkVCNX(url):
	lQHXdV9Nzf6BLqS8D = url.split('?servers=')[0]
	QstumvzTIEUMXCcx06aD4y8nSqH = QuWA3hsmIvockZDiy2rLg(Z7uFdWIRv9ybj0,lQHXdV9Nzf6BLqS8D,'',headers,'','MOVIZLAND-EPISODES-1st')
	bdq4e6Wr2gslnSiA38 = ZXFs0mEPR8qI2zj.findall('<title>(.*?)</title>.*?height="([0-9]+)" src="(.*?)"',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	title,vfLGDU1N0e8c,CrGO63LT7j2UxniW = bdq4e6Wr2gslnSiA38[0]
	name = ZXFs0mEPR8qI2zj.findall('(.*?) (الحلقة|الحلقه) [0-9]+',title,ZXFs0mEPR8qI2zj.DOTALL)
	if name: name = '_MOD_' + name[0][0]
	else: name = title
	items = []
	IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('class="episodesNumbers"(.*?)</div>',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	if IZGcQbePXxwAoyYR1n:
		bdq4e6Wr2gslnSiA38 = IZGcQbePXxwAoyYR1n[0]
		items = ZXFs0mEPR8qI2zj.findall('href="(.*?)"',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
		for RRucmYBaXegTtNOdGHMQ in items:
			RRucmYBaXegTtNOdGHMQ = ejBOu2WXwvb4YpITdsLF16(RRucmYBaXegTtNOdGHMQ)
			title = ZXFs0mEPR8qI2zj.findall('(الحلقة|الحلقه)-([0-9]+)',RRucmYBaXegTtNOdGHMQ.split('/')[-2],ZXFs0mEPR8qI2zj.DOTALL)
			if not title: title = ZXFs0mEPR8qI2zj.findall('()-([0-9]+)',RRucmYBaXegTtNOdGHMQ.split('/')[-2],ZXFs0mEPR8qI2zj.DOTALL)
			if title: title = ' ' + title[0][1]
			else: title = ''
			title = name + ' - ' + 'الحلقة' + title
			title = qpob7TvxHSs4fEzO6(title)
			Tca7NsYPkIRWtBpFgxLZbSmCi('video',W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,182,CrGO63LT7j2UxniW)
	if not items:
		title = qpob7TvxHSs4fEzO6(title)
		if 'بجودة ' in title or 'بجوده ' in title:
			title = '_MOD_' + title.replace('بجودة ','').replace('بجوده ','')
		Tca7NsYPkIRWtBpFgxLZbSmCi('video',W74fAyGxODoLPs5vMX2l8C93R+title,url,182,CrGO63LT7j2UxniW)
	return
def jXYwiO9D056pkrzRh1y8tfWJxQoaI3(url):
	L5k0oWzXR7TPl3 = url.split('?servers=')
	lQHXdV9Nzf6BLqS8D = L5k0oWzXR7TPl3[0]
	del L5k0oWzXR7TPl3[0]
	QstumvzTIEUMXCcx06aD4y8nSqH = QuWA3hsmIvockZDiy2rLg(JNsoWV1CXc4xy,lQHXdV9Nzf6BLqS8D,'',headers,'','MOVIZLAND-PLAY-1st')
	RRucmYBaXegTtNOdGHMQ = ZXFs0mEPR8qI2zj.findall('font-size: 25px;" href="(.*?)"',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)[0]
	if RRucmYBaXegTtNOdGHMQ not in L5k0oWzXR7TPl3: L5k0oWzXR7TPl3.append(RRucmYBaXegTtNOdGHMQ)
	YYmyQXglbEewzL3IA2Sd = []
	for RRucmYBaXegTtNOdGHMQ in L5k0oWzXR7TPl3:
		if '://moshahda.' in RRucmYBaXegTtNOdGHMQ:
			kvj8wuoSNXyUALbKY6iQfIFGHhzPl = RRucmYBaXegTtNOdGHMQ
			YYmyQXglbEewzL3IA2Sd.append(kvj8wuoSNXyUALbKY6iQfIFGHhzPl+'?named=Main')
	for RRucmYBaXegTtNOdGHMQ in L5k0oWzXR7TPl3:
		if '://vb.movizland.' in RRucmYBaXegTtNOdGHMQ:
			QstumvzTIEUMXCcx06aD4y8nSqH = QuWA3hsmIvockZDiy2rLg(JNsoWV1CXc4xy,RRucmYBaXegTtNOdGHMQ,'',headers,'','MOVIZLAND-PLAY-2nd')
			QstumvzTIEUMXCcx06aD4y8nSqH = QstumvzTIEUMXCcx06aD4y8nSqH.decode('windows-1256').encode('utf8')
			QstumvzTIEUMXCcx06aD4y8nSqH = QstumvzTIEUMXCcx06aD4y8nSqH.replace('src="http://up.movizland.com/uploads/13721411411.png"','src="/uploads/13721411411.png"  \n  src="/uploads/13721411411.png"')
			QstumvzTIEUMXCcx06aD4y8nSqH = QstumvzTIEUMXCcx06aD4y8nSqH.replace('src="http://up.movizland.online/uploads/13721411411.png"','src="/uploads/13721411411.png"  \n  src="/uploads/13721411411.png"')
			QstumvzTIEUMXCcx06aD4y8nSqH = QstumvzTIEUMXCcx06aD4y8nSqH.replace('</a></div><br /><div align="center">','src="/uploads/13721411411.png"')
			QstumvzTIEUMXCcx06aD4y8nSqH = QstumvzTIEUMXCcx06aD4y8nSqH.replace('class="tborder" align="center"','src="/uploads/13721411411.png"')
			IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('(src="/uploads/13721411411.png".*?href="http://moshahda\..*?/\w+.html".*?src="/uploads/13721411411.png")',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
			if IZGcQbePXxwAoyYR1n:
				FNylha5WkeAxi3r0G4QPqwRZMY,bFEOBVfxy7nPvCdgta1U = [],[]
				if len(IZGcQbePXxwAoyYR1n)==1:
					title = ''
					bdq4e6Wr2gslnSiA38 = QstumvzTIEUMXCcx06aD4y8nSqH
				else:
					for bdq4e6Wr2gslnSiA38 in IZGcQbePXxwAoyYR1n:
						i9jtofq4JrV = ZXFs0mEPR8qI2zj.findall('src="/uploads/13721411411.png".*?http://up.movizland.(online|com)/uploads/.*?\*\*\*\*\*\*\*+(.*?src="/uploads/13721411411.png")',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
						if i9jtofq4JrV: bdq4e6Wr2gslnSiA38 = 'src="/uploads/13721411411.png"  \n  ' + i9jtofq4JrV[0][1]
						i9jtofq4JrV = ZXFs0mEPR8qI2zj.findall('src="/uploads/13721411411.png".*?<hr size="1" style="color:'+'#'+'333; background-color:'+'#'+'333" />(.*?href="http://moshahda\..*?/\w+.html".*?src="/uploads/13721411411.png")',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
						if i9jtofq4JrV: bdq4e6Wr2gslnSiA38 = 'src="/uploads/13721411411.png"  \n  ' + i9jtofq4JrV[0]
						i9jtofq4JrV = ZXFs0mEPR8qI2zj.findall('(src="/uploads/13721411411.png".*?href="http://moshahda\..*?/\w+.html".*?)<hr size="1" style="color:'+'#'+'333; background-color:'+'#'+'333" />.*?src="/uploads/13721411411.png"',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
						if i9jtofq4JrV: bdq4e6Wr2gslnSiA38 = i9jtofq4JrV[0] + '  \n  src="/uploads/13721411411.png"'
						DD2czm4EtsUYipRgw = ZXFs0mEPR8qI2zj.findall('<(.*?)http://up.movizland.(online|com)/uploads/',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
						title = ZXFs0mEPR8qI2zj.findall('> *([^<>]+) *<',DD2czm4EtsUYipRgw[0][0],ZXFs0mEPR8qI2zj.DOTALL)
						title = ' '.join(title)
						title = title.strip(' ')
						title = title.replace('  ',' ').replace('  ',' ').replace('  ',' ').replace('  ',' ').replace('  ',' ')
						FNylha5WkeAxi3r0G4QPqwRZMY.append(title)
					jQ6w8xOrgYhSHIRpUqzL = F2yZPukcUh09sqCI8nYw7e('أختر الفيديو المطلوب:', FNylha5WkeAxi3r0G4QPqwRZMY)
					if jQ6w8xOrgYhSHIRpUqzL == -1 : return
					title = FNylha5WkeAxi3r0G4QPqwRZMY[jQ6w8xOrgYhSHIRpUqzL]
					bdq4e6Wr2gslnSiA38 = IZGcQbePXxwAoyYR1n[jQ6w8xOrgYhSHIRpUqzL]
				RRucmYBaXegTtNOdGHMQ = ZXFs0mEPR8qI2zj.findall('href="(http://moshahda\..*?/\w+.html)"',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
				fI9hWzDtYSNi = RRucmYBaXegTtNOdGHMQ[0]
				YYmyQXglbEewzL3IA2Sd.append(fI9hWzDtYSNi+'?named=Forum')
				bdq4e6Wr2gslnSiA38 = bdq4e6Wr2gslnSiA38.replace('ـ','')
				bdq4e6Wr2gslnSiA38 = bdq4e6Wr2gslnSiA38.replace('src="http://up.movizland.online/uploads/1517412175296.png"','src="/uploads/13721411411.png"  \n  src="/uploads/13721411411.png"  \n  typetype="both"  \n  ')
				bdq4e6Wr2gslnSiA38 = bdq4e6Wr2gslnSiA38.replace('src="http://up.movizland.com/uploads/1517412175296.png"','src="/uploads/13721411411.png"  \n  src="/uploads/13721411411.png"  \n  typetype="both"  \n  ')
				bdq4e6Wr2gslnSiA38 = bdq4e6Wr2gslnSiA38.replace('سيرفرات التحميل','src="/uploads/13721411411.png"  \n  src="/uploads/13721411411.png"  \n  typetype="download"  \n  ')
				bdq4e6Wr2gslnSiA38 = bdq4e6Wr2gslnSiA38.replace('روابط التحميل','src="/uploads/13721411411.png"  \n  src="/uploads/13721411411.png"  \n  typetype="download"  \n  ')
				bdq4e6Wr2gslnSiA38 = bdq4e6Wr2gslnSiA38.replace('سيرفرات المشاهد','src="/uploads/13721411411.png"  \n  src="/uploads/13721411411.png"  \n  typetype="watch"  \n  ')
				bdq4e6Wr2gslnSiA38 = bdq4e6Wr2gslnSiA38.replace('روابط المشاهد','src="/uploads/13721411411.png"  \n  src="/uploads/13721411411.png"  \n  typetype="watch"  \n  ')
				Gq4iXapwNL2oYQyPDMx8n = ZXFs0mEPR8qI2zj.findall('(src="/uploads/13721411411.png".*?href="http://e5tsar.com/\d+".*?src="/uploads/13721411411.png")',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
				for kq3aiuE960pWL in Gq4iXapwNL2oYQyPDMx8n:
					type = ZXFs0mEPR8qI2zj.findall(' typetype="(.*?)" ',kq3aiuE960pWL)
					if type:
						if type[0]!='both': type = '__'+type[0]
						else: type = ''
					items = ZXFs0mEPR8qI2zj.findall('(?<!http://e5tsar.com/)(\w+[ \w]*</font>.*?|\w+[ \w]*<br />.*?)href="(http://e5tsar.com/.*?)"',kq3aiuE960pWL,ZXFs0mEPR8qI2zj.DOTALL)
					for oX2VzB4MTHY15DkN,RRucmYBaXegTtNOdGHMQ in items:
						title = ZXFs0mEPR8qI2zj.findall('(\w+[ \w]*)<',oX2VzB4MTHY15DkN)
						title = title[-1]
						RRucmYBaXegTtNOdGHMQ = RRucmYBaXegTtNOdGHMQ + '?named=' + title + type
						YYmyQXglbEewzL3IA2Sd.append(RRucmYBaXegTtNOdGHMQ)
	aaIn3XlQKJ6zSfkmjuCyM = lQHXdV9Nzf6BLqS8D.replace(JJTrn6SEtYZV31eyR97,dJSW5LrBmHfxeu)
	QstumvzTIEUMXCcx06aD4y8nSqH = QuWA3hsmIvockZDiy2rLg(JNsoWV1CXc4xy,aaIn3XlQKJ6zSfkmjuCyM,'',headers,'','MOVIZLAND-PLAY-3rd')
	items = ZXFs0mEPR8qI2zj.findall('" href="(.*?)"',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	if items:
		nQSum3GKwHMxRqBVitT9f4 = items[-1]
		YYmyQXglbEewzL3IA2Sd.append(nQSum3GKwHMxRqBVitT9f4+'?named=Mobile')
	import fnxsZbk2Fm
	fnxsZbk2Fm.n2h4SBIzxbgJD3K7rtVej01EuGcHPs(YYmyQXglbEewzL3IA2Sd,ll6f2wvU4FdqL3MJyDxORESCK197i,'video',url)
	return
def F6OgHwYPRiX10tJEv8r(search):
	search,Y9RKmgsxBefkFcuIj2GULDHy3,showDialogs = XDzpr8RxgZhT(search)
	if search=='': search = CjyEnpfQ23o0PYwDtLId()
	if search=='': return
	search = search.replace(' ','+')
	QstumvzTIEUMXCcx06aD4y8nSqH = QuWA3hsmIvockZDiy2rLg(Z7uFdWIRv9ybj0,JJTrn6SEtYZV31eyR97,'',headers,'','MOVIZLAND-SEARCH-1st')
	items = ZXFs0mEPR8qI2zj.findall('<option value="(.*?)">(.*?)</option>',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	UTZAg38PWk7aM1fthHLIlq6DB = [ '' ]
	T9kVgUrWnHusiQFbBaYE = [ 'الكل وبدون فلتر' ]
	for p8pgXONsjY,title in items:
		UTZAg38PWk7aM1fthHLIlq6DB.append(p8pgXONsjY)
		T9kVgUrWnHusiQFbBaYE.append(title)
	if p8pgXONsjY:
		jQ6w8xOrgYhSHIRpUqzL = F2yZPukcUh09sqCI8nYw7e('اختر الفلتر المناسب:', T9kVgUrWnHusiQFbBaYE)
		if jQ6w8xOrgYhSHIRpUqzL == -1 : return
		p8pgXONsjY = UTZAg38PWk7aM1fthHLIlq6DB[jQ6w8xOrgYhSHIRpUqzL]
	else: p8pgXONsjY = ''
	url = JJTrn6SEtYZV31eyR97 + '/?s='+search+'&mcat='+p8pgXONsjY
	RxAy5lEFQ1chv0BrdU4p6Pt2(url)
	return