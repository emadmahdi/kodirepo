# -*- coding: utf-8 -*-
from j3x780FpaM import *
ll6f2wvU4FdqL3MJyDxORESCK197i = 'CIMAFANS'
headers = { 'User-Agent' : '' }
W74fAyGxODoLPs5vMX2l8C93R = '_CMF_'
JJTrn6SEtYZV31eyR97 = uReHcEzxkTm6pN4Q[ll6f2wvU4FdqL3MJyDxORESCK197i][0]
def OVQIAezo6U1NSTl4L(mode,url,text):
	if   mode==90: HkKfQCS7RIa4xi3houjvl = oMUN5hPpTkxVZG12Qiva8BKnyw6()
	elif mode==91: HkKfQCS7RIa4xi3houjvl = J2K0qdYZMhG(url)
	elif mode==92: HkKfQCS7RIa4xi3houjvl = jXYwiO9D056pkrzRh1y8tfWJxQoaI3(url)
	elif mode==94: HkKfQCS7RIa4xi3houjvl = vyM5CbgVYS()
	elif mode==95: HkKfQCS7RIa4xi3houjvl = pqx0gStI9ojGFP2rWhwRfkVCNX(url)
	elif mode==99: HkKfQCS7RIa4xi3houjvl = F6OgHwYPRiX10tJEv8r(text)
	else: HkKfQCS7RIa4xi3houjvl = False
	return HkKfQCS7RIa4xi3houjvl
def oMUN5hPpTkxVZG12Qiva8BKnyw6():
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+'بحث في الموقع','',99,'','','_REMEMBERRESULTS_')
	Tca7NsYPkIRWtBpFgxLZbSmCi('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder',ll6f2wvU4FdqL3MJyDxORESCK197i+'_SCRIPT_'+W74fAyGxODoLPs5vMX2l8C93R+'المضاف حديثا','',94)
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder',ll6f2wvU4FdqL3MJyDxORESCK197i+'_SCRIPT_'+W74fAyGxODoLPs5vMX2l8C93R+'الأحدث',JJTrn6SEtYZV31eyR97+'/?type=latest',91)
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder',ll6f2wvU4FdqL3MJyDxORESCK197i+'_SCRIPT_'+W74fAyGxODoLPs5vMX2l8C93R+'الأعلى تقيماً',JJTrn6SEtYZV31eyR97+'/?type=imdb',91)
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder',ll6f2wvU4FdqL3MJyDxORESCK197i+'_SCRIPT_'+W74fAyGxODoLPs5vMX2l8C93R+'الأكثر مشاهدة',JJTrn6SEtYZV31eyR97+'/?type=view',91)
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder',ll6f2wvU4FdqL3MJyDxORESCK197i+'_SCRIPT_'+W74fAyGxODoLPs5vMX2l8C93R+'المثبت',JJTrn6SEtYZV31eyR97+'/?type=pin',91)
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder',ll6f2wvU4FdqL3MJyDxORESCK197i+'_SCRIPT_'+W74fAyGxODoLPs5vMX2l8C93R+'جديد الأفلام',JJTrn6SEtYZV31eyR97+'/?type=newMovies',91)
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder',ll6f2wvU4FdqL3MJyDxORESCK197i+'_SCRIPT_'+W74fAyGxODoLPs5vMX2l8C93R+'جديد الحلقات',JJTrn6SEtYZV31eyR97+'/?type=newEpisodes',91)
	Tca7NsYPkIRWtBpFgxLZbSmCi('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	QstumvzTIEUMXCcx06aD4y8nSqH = QuWA3hsmIvockZDiy2rLg(JNsoWV1CXc4xy,JJTrn6SEtYZV31eyR97,'',headers,'','CIMAFANS-MENU-1st')
	IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('class="mainmenu(.*?)nav',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	bdq4e6Wr2gslnSiA38 = IZGcQbePXxwAoyYR1n[0]
	items = ZXFs0mEPR8qI2zj.findall('<li><a href="(.*?)".*?>(.*?)<',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
	SmgoEYJ7uyL = ['افلام للكبار فقط']
	for RRucmYBaXegTtNOdGHMQ,title in items:
		title = title.strip(' ')
		if not any(AARNPWHjQU9dEmDI in title for AARNPWHjQU9dEmDI in SmgoEYJ7uyL):
			Tca7NsYPkIRWtBpFgxLZbSmCi('folder',ll6f2wvU4FdqL3MJyDxORESCK197i+'_SCRIPT_'+W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,91)
	Tca7NsYPkIRWtBpFgxLZbSmCi('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('class="f-cats"(.*?)</ul>',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	bdq4e6Wr2gslnSiA38 = IZGcQbePXxwAoyYR1n[0]
	items = ZXFs0mEPR8qI2zj.findall('<li><a href="(.*?)".*?>(.*?)<',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
	for RRucmYBaXegTtNOdGHMQ,title in items:
		title = title.strip(' ')
		if not any(AARNPWHjQU9dEmDI in title for AARNPWHjQU9dEmDI in SmgoEYJ7uyL):
			Tca7NsYPkIRWtBpFgxLZbSmCi('folder',ll6f2wvU4FdqL3MJyDxORESCK197i+'_SCRIPT_'+W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,91)
	return QstumvzTIEUMXCcx06aD4y8nSqH
def J2K0qdYZMhG(url):
	if '/search.php' in url:
		url,search = url.split('?t=')
		headers = { 'User-Agent' : '' , 'Content-Type' : 'application/x-www-form-urlencoded' }
		data = { 't' : search }
		wpFmEA3z8JR = A6F71g3cqN4(Z7uFdWIRv9ybj0,'POST',url,data,headers,'','','CIMAFANS-ITEMS-1st')
		QstumvzTIEUMXCcx06aD4y8nSqH = wpFmEA3z8JR.content
	else:
		headers = { 'User-Agent' : '' }
		QstumvzTIEUMXCcx06aD4y8nSqH = QuWA3hsmIvockZDiy2rLg(Z7uFdWIRv9ybj0,url,'',headers,'','CIMAFANS-ITEMS-2nd')
	IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('id="movies-items(.*?)class="listfoot"',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	if IZGcQbePXxwAoyYR1n: bdq4e6Wr2gslnSiA38 = IZGcQbePXxwAoyYR1n[0]
	else: bdq4e6Wr2gslnSiA38 = ''
	items = ZXFs0mEPR8qI2zj.findall('background-image:url\((.*?)\).*?href="(.*?)".*?movie-title">(.*?)<',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
	FF1TYf6O5KENr8R72LUVievClmudxD = []
	for CrGO63LT7j2UxniW,RRucmYBaXegTtNOdGHMQ,title in items:
		if 'الحلقة' in title and '/c/' not in url and '/cat/' not in url:
			LqYKJ36CBG = ZXFs0mEPR8qI2zj.findall('(.*?) الحلقة [0-9]+',title,ZXFs0mEPR8qI2zj.DOTALL)
			if LqYKJ36CBG:
				title = '_MOD_'+LqYKJ36CBG[0]
				if title not in FF1TYf6O5KENr8R72LUVievClmudxD:
					Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,95,CrGO63LT7j2UxniW)
					FF1TYf6O5KENr8R72LUVievClmudxD.append(title)
		elif '/video/' in RRucmYBaXegTtNOdGHMQ: Tca7NsYPkIRWtBpFgxLZbSmCi('video',W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,92,CrGO63LT7j2UxniW)
		else: Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,91,CrGO63LT7j2UxniW)
	IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('class="pagination(.*?)div',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	if IZGcQbePXxwAoyYR1n:
		bdq4e6Wr2gslnSiA38 = IZGcQbePXxwAoyYR1n[0]
		items = ZXFs0mEPR8qI2zj.findall('<a href="(.*?)".*?>(.*?)<',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
		for RRucmYBaXegTtNOdGHMQ,title in items:
			title = qpob7TvxHSs4fEzO6(title)
			title = title.replace('الصفحة ','')
			Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+'صفحة '+title,RRucmYBaXegTtNOdGHMQ,91)
	return
def pqx0gStI9ojGFP2rWhwRfkVCNX(url):
	QstumvzTIEUMXCcx06aD4y8nSqH = QuWA3hsmIvockZDiy2rLg(Z7uFdWIRv9ybj0,url,'',headers,'','CIMAFANS-EPISODES-1st')
	CrGO63LT7j2UxniW = ZXFs0mEPR8qI2zj.findall('img src="(.*?)"',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	CrGO63LT7j2UxniW = CrGO63LT7j2UxniW[0]
	IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('id="episodes-panel(.*?)div',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	if IZGcQbePXxwAoyYR1n:
		name = ZXFs0mEPR8qI2zj.findall('itemprop="title">(.*?)<',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
		if name: name = name[1]
		else:
			name = cPwDBuG4HVTCdQ9JmMeoWjNY2hX.getInfoLabel('ListItem.Label')
			if '[/COLOR]' in name: name = name.split('[/COLOR]',1)[1]
		bdq4e6Wr2gslnSiA38 = IZGcQbePXxwAoyYR1n[0]
		items = ZXFs0mEPR8qI2zj.findall('href="(.*?)".*?name">(.*?)<',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
		for RRucmYBaXegTtNOdGHMQ,title in items:
			Tca7NsYPkIRWtBpFgxLZbSmCi('video',W74fAyGxODoLPs5vMX2l8C93R+name+' - '+title,RRucmYBaXegTtNOdGHMQ,92,CrGO63LT7j2UxniW)
	else:
		p3pw6HeVfqXcFnT = ZXFs0mEPR8qI2zj.findall('class="movietitle"><a href="(.*?)">(.*?)<',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
		if p3pw6HeVfqXcFnT: RRucmYBaXegTtNOdGHMQ,title = p3pw6HeVfqXcFnT[0]
		else: RRucmYBaXegTtNOdGHMQ,title = url,name
		Tca7NsYPkIRWtBpFgxLZbSmCi('video',W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,92,CrGO63LT7j2UxniW)
	return
def jXYwiO9D056pkrzRh1y8tfWJxQoaI3(url):
	YYmyQXglbEewzL3IA2Sd,OrdItJUQGKR0iexz8Eok4l1ymvn7 = [],[]
	QstumvzTIEUMXCcx06aD4y8nSqH = QuWA3hsmIvockZDiy2rLg(Z7uFdWIRv9ybj0,url,'',headers,'','CIMAFANS-PLAY-1st')
	z4O2HXsQyg = ZXFs0mEPR8qI2zj.findall('text-shadow: none;">(.*?)<',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	if z4O2HXsQyg and GBC7yanr9WNYIKXSHRxgP(ll6f2wvU4FdqL3MJyDxORESCK197i,url,z4O2HXsQyg): return
	IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('id="links-panel(.*?)div',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	if IZGcQbePXxwAoyYR1n:
		bdq4e6Wr2gslnSiA38 = IZGcQbePXxwAoyYR1n[0]
		items = ZXFs0mEPR8qI2zj.findall('href="(.*?)"',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
		for RRucmYBaXegTtNOdGHMQ in items:
			RRucmYBaXegTtNOdGHMQ = RRucmYBaXegTtNOdGHMQ+'?__download'
			YYmyQXglbEewzL3IA2Sd.append(RRucmYBaXegTtNOdGHMQ)
	IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('nav-tabs"(.*?)video-panel-more',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	if IZGcQbePXxwAoyYR1n:
		bdq4e6Wr2gslnSiA38 = IZGcQbePXxwAoyYR1n[0]
		items = ZXFs0mEPR8qI2zj.findall('id="(.*?)".*?embed src="(.*?)"',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
		for id,RRucmYBaXegTtNOdGHMQ in items:
			title = 'سيرفر '+id
			RRucmYBaXegTtNOdGHMQ = RRucmYBaXegTtNOdGHMQ+'?named='+title+'__watch'
			YYmyQXglbEewzL3IA2Sd.append(RRucmYBaXegTtNOdGHMQ)
		items = ZXFs0mEPR8qI2zj.findall('data-server-src="(.*?)"',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
		for RRucmYBaXegTtNOdGHMQ in items:
			if 'http' not in RRucmYBaXegTtNOdGHMQ: RRucmYBaXegTtNOdGHMQ = 'http:'+RRucmYBaXegTtNOdGHMQ
			RRucmYBaXegTtNOdGHMQ = ejBOu2WXwvb4YpITdsLF16(RRucmYBaXegTtNOdGHMQ)
			YYmyQXglbEewzL3IA2Sd.append(RRucmYBaXegTtNOdGHMQ)
	import fnxsZbk2Fm
	fnxsZbk2Fm.n2h4SBIzxbgJD3K7rtVej01EuGcHPs(YYmyQXglbEewzL3IA2Sd,ll6f2wvU4FdqL3MJyDxORESCK197i,'video',url)
	return
def vyM5CbgVYS():
	QstumvzTIEUMXCcx06aD4y8nSqH = QuWA3hsmIvockZDiy2rLg(Z7uFdWIRv9ybj0,JJTrn6SEtYZV31eyR97,'',headers,'','CIMAFANS-LATEST-1st')
	IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('id="index-last-movie(.*?)id="index-slider-movie',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	bdq4e6Wr2gslnSiA38 = IZGcQbePXxwAoyYR1n[0]
	items = ZXFs0mEPR8qI2zj.findall('src="(.*?)".*?href="(.*?)" title="(.*?)"',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
	for CrGO63LT7j2UxniW,RRucmYBaXegTtNOdGHMQ,title in items:
		if '/video/' in RRucmYBaXegTtNOdGHMQ: Tca7NsYPkIRWtBpFgxLZbSmCi('video',W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,92,CrGO63LT7j2UxniW)
		else: Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,91,CrGO63LT7j2UxniW)
	return
def F6OgHwYPRiX10tJEv8r(search):
	search,Y9RKmgsxBefkFcuIj2GULDHy3,showDialogs = XDzpr8RxgZhT(search)
	if search=='': search = CjyEnpfQ23o0PYwDtLId()
	if search=='': return
	search = search.replace(' ','+')
	url = JJTrn6SEtYZV31eyR97 + '/search.php?t='+search
	J2K0qdYZMhG(url)
	return