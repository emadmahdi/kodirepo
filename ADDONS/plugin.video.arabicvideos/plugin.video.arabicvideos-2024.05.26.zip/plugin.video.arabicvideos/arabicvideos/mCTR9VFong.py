# -*- coding: utf-8 -*-
from j3x780FpaM import *
headers = { 'User-Agent' : '' }
ll6f2wvU4FdqL3MJyDxORESCK197i = 'AKOAM'
W74fAyGxODoLPs5vMX2l8C93R = '_AKO_'
JJTrn6SEtYZV31eyR97 = uReHcEzxkTm6pN4Q[ll6f2wvU4FdqL3MJyDxORESCK197i][0]
iiQf3Mp6T19gjIx7YuV0bU = ['فيلم','كليب','العرض الاسبوعي','مسرحية','مسرحيه','اغنية','اعلان','لقاء']
def OVQIAezo6U1NSTl4L(mode,url,text):
	if   mode==70: HkKfQCS7RIa4xi3houjvl = oMUN5hPpTkxVZG12Qiva8BKnyw6()
	elif mode==71: HkKfQCS7RIa4xi3houjvl = XNtmUjAERdQZ9s2S4vWwlOq5(url)
	elif mode==72: HkKfQCS7RIa4xi3houjvl = RxAy5lEFQ1chv0BrdU4p6Pt2(url,text)
	elif mode==73: HkKfQCS7RIa4xi3houjvl = mYswqlzULgOWPxuXNJFjr(url)
	elif mode==74: HkKfQCS7RIa4xi3houjvl = jXYwiO9D056pkrzRh1y8tfWJxQoaI3(url)
	elif mode==79: HkKfQCS7RIa4xi3houjvl = F6OgHwYPRiX10tJEv8r(text)
	else: HkKfQCS7RIa4xi3houjvl = False
	return HkKfQCS7RIa4xi3houjvl
def oMUN5hPpTkxVZG12Qiva8BKnyw6():
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+'بحث في الموقع','',79,'','','_REMEMBERRESULTS_')
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder',ll6f2wvU4FdqL3MJyDxORESCK197i+'_SCRIPT_'+W74fAyGxODoLPs5vMX2l8C93R+'سلسلة افلام','',79,'','','سلسلة افلام')
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder',ll6f2wvU4FdqL3MJyDxORESCK197i+'_SCRIPT_'+W74fAyGxODoLPs5vMX2l8C93R+'سلاسل منوعة','',79,'','','سلسلة')
	Tca7NsYPkIRWtBpFgxLZbSmCi('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	SmgoEYJ7uyL = ['الكتب و الابحاث','الكورسات التعليمية','الألعاب','البرامج','الاجهزة اللوحية','الصور و الخلفيات','المصارعة الحرة']
	QstumvzTIEUMXCcx06aD4y8nSqH = QuWA3hsmIvockZDiy2rLg(JNsoWV1CXc4xy,JJTrn6SEtYZV31eyR97,'',headers,'','AKOAM-MENU-1st')
	IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('class="partions"(.*?)</ul>',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	if IZGcQbePXxwAoyYR1n:
		bdq4e6Wr2gslnSiA38 = IZGcQbePXxwAoyYR1n[0]
		items = ZXFs0mEPR8qI2zj.findall('href="(.*?)">(.*?)<',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
		for RRucmYBaXegTtNOdGHMQ,title in items:
			if title not in SmgoEYJ7uyL:
				Tca7NsYPkIRWtBpFgxLZbSmCi('folder',ll6f2wvU4FdqL3MJyDxORESCK197i+'_SCRIPT_'+W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,71)
	return QstumvzTIEUMXCcx06aD4y8nSqH
def XNtmUjAERdQZ9s2S4vWwlOq5(url):
	QstumvzTIEUMXCcx06aD4y8nSqH = QuWA3hsmIvockZDiy2rLg(JNsoWV1CXc4xy,url,'',headers,'','AKOAM-CATEGORIES-1st')
	IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('sect_parts(.*?)</div>',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	if IZGcQbePXxwAoyYR1n:
		bdq4e6Wr2gslnSiA38 = IZGcQbePXxwAoyYR1n[0]
		items = ZXFs0mEPR8qI2zj.findall('href="(.*?)".*?>(.*?)<',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
		for RRucmYBaXegTtNOdGHMQ,title in items:
			title = title.strip(' ')
			Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,72)
		Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+'جميع الفروع',url,72)
	else: RxAy5lEFQ1chv0BrdU4p6Pt2(url,'')
	return
def RxAy5lEFQ1chv0BrdU4p6Pt2(url,type):
	QstumvzTIEUMXCcx06aD4y8nSqH = QuWA3hsmIvockZDiy2rLg(Z7uFdWIRv9ybj0,url,'',headers,True,'AKOAM-TITLES-1st')
	items = []
	if type=='featured':
		IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('section_title featured_title(.*?)subjects-crousel',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
		bdq4e6Wr2gslnSiA38 = IZGcQbePXxwAoyYR1n[0]
		items = ZXFs0mEPR8qI2zj.findall('href="(.*?)"><div class="subject_box.*?src="(.*?)".*?<h3.*?>(.*?)</h3>',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
	elif type=='search':
		IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('akoam_result(.*?)<script',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
		bdq4e6Wr2gslnSiA38 = IZGcQbePXxwAoyYR1n[0]
		items = ZXFs0mEPR8qI2zj.findall('href="(.*?)".*?background-image: url\((.*?)\).*?<h1>(.*?)</h1>',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
	elif type=='more':
		IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('section_title more_title(.*?)footer_bottom_services',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	else:
		IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('navigation(.*?)<script',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	if not items and IZGcQbePXxwAoyYR1n:
		bdq4e6Wr2gslnSiA38 = IZGcQbePXxwAoyYR1n[0]
		items = ZXFs0mEPR8qI2zj.findall('div class="subject_box.*?href="(.*?)".*?src="(.*?)".*?<h3.*?>(.*?)</h3>',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
	for RRucmYBaXegTtNOdGHMQ,CrGO63LT7j2UxniW,title in items:
		if 'توضيح هام' in title: continue
		title = title.replace('\n','').strip(' ')
		title = qpob7TvxHSs4fEzO6(title)
		if any(AARNPWHjQU9dEmDI in title for AARNPWHjQU9dEmDI in iiQf3Mp6T19gjIx7YuV0bU): Tca7NsYPkIRWtBpFgxLZbSmCi('video',W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,73,CrGO63LT7j2UxniW)
		else: Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,73,CrGO63LT7j2UxniW)
	IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('class="pagination"(.*?)</ul>',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	if IZGcQbePXxwAoyYR1n:
		bdq4e6Wr2gslnSiA38 = IZGcQbePXxwAoyYR1n[0]
		items = ZXFs0mEPR8qI2zj.findall("</li><li >.*?href='(.*?)'>(.*?)<",bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
		for RRucmYBaXegTtNOdGHMQ,title in items:
			Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+'صفحة '+title,RRucmYBaXegTtNOdGHMQ,72,'','',type)
	return
def XhUHQMDGmTktc3oV2lbJNF(url):
	QstumvzTIEUMXCcx06aD4y8nSqH = QuWA3hsmIvockZDiy2rLg(JNsoWV1CXc4xy,url,'',headers,True,'AKOAM-SECTIONS-2nd')
	lQHXdV9Nzf6BLqS8D = ZXFs0mEPR8qI2zj.findall('"href","(.*?)"',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	lQHXdV9Nzf6BLqS8D = lQHXdV9Nzf6BLqS8D[1]
	return lQHXdV9Nzf6BLqS8D
def mYswqlzULgOWPxuXNJFjr(url):
	QstumvzTIEUMXCcx06aD4y8nSqH = QuWA3hsmIvockZDiy2rLg(Z7uFdWIRv9ybj0,url,'',headers,True,'AKOAM-SECTIONS-1st')
	nqowBLmH7rejtcpI = ZXFs0mEPR8qI2zj.findall('"(https*://akwam.net/\w+.*?)"',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	BVPu2FqoxSg8YrLXZaK3Uez0fG95h = ZXFs0mEPR8qI2zj.findall('"(https*://underurl.com/\w+.*?)"',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	if nqowBLmH7rejtcpI or BVPu2FqoxSg8YrLXZaK3Uez0fG95h:
		if nqowBLmH7rejtcpI: aaIn3XlQKJ6zSfkmjuCyM = nqowBLmH7rejtcpI[0]
		elif BVPu2FqoxSg8YrLXZaK3Uez0fG95h: aaIn3XlQKJ6zSfkmjuCyM = XhUHQMDGmTktc3oV2lbJNF(BVPu2FqoxSg8YrLXZaK3Uez0fG95h[0])
		aaIn3XlQKJ6zSfkmjuCyM = ejBOu2WXwvb4YpITdsLF16(aaIn3XlQKJ6zSfkmjuCyM)
		import FN6uzHvdbp
		if '/series/' in aaIn3XlQKJ6zSfkmjuCyM or '/shows/' in aaIn3XlQKJ6zSfkmjuCyM: FN6uzHvdbp.pqx0gStI9ojGFP2rWhwRfkVCNX(aaIn3XlQKJ6zSfkmjuCyM)
		else: FN6uzHvdbp.jXYwiO9D056pkrzRh1y8tfWJxQoaI3(aaIn3XlQKJ6zSfkmjuCyM)
		return
	z4O2HXsQyg = ZXFs0mEPR8qI2zj.findall('محتوى الفيلم.*?>.*?(\w*?)\W*?<',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	if z4O2HXsQyg and GBC7yanr9WNYIKXSHRxgP(ll6f2wvU4FdqL3MJyDxORESCK197i,url,z4O2HXsQyg): return
	items = ZXFs0mEPR8qI2zj.findall('<br />\n<a href="(.*?)".*?<span style="color:.*?">(.*?)</span>',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	for RRucmYBaXegTtNOdGHMQ,title in items:
		title = qpob7TvxHSs4fEzO6(title)
		Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,73)
	IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('class="sub_title".*?<h1.*?>(.*?)</h1>.*?class="main_img".*?src="(.*?)".*?ad-300-250(.*?)ako-feedback',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	if not IZGcQbePXxwAoyYR1n:
		NLVM3HAtxQOSvJf6kd78K1o('خطأ خارجي','لا يوجد ملف فيديو')
		return
	name,CrGO63LT7j2UxniW,bdq4e6Wr2gslnSiA38 = IZGcQbePXxwAoyYR1n[0]
	name = name.strip(' ')
	if 'sub_epsiode_title' in bdq4e6Wr2gslnSiA38:
		items = ZXFs0mEPR8qI2zj.findall('sub_epsiode_title">(.*?)</h2>.*?sub_file_title.*?>(.*?)<',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
	else:
		YhAfHtdkN5bePL3iQKBznlCSw = ZXFs0mEPR8qI2zj.findall('sub_file_title\'>(.*?) - <i>',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
		items = []
		for filename in YhAfHtdkN5bePL3iQKBznlCSw:
			items.append( ('رابط التشغيل',filename) )
	if not items: items = [ ('رابط التشغيل','') ]
	count = 0
	xCLQK8kh39sjyi5DXSZAVeI,kv3IdPiFlGO = [],[]
	size = len(items)
	for title,filename in items:
		P1ajYzT8sKCx6tMl = ''
		if ' - ' in filename: filename = filename.split(' - ')[0]
		else: filename = 'dummy.zip'
		if '.' in filename: P1ajYzT8sKCx6tMl = filename.split('.')[-1]
		title = title.replace('\n','').strip(' ')
		xCLQK8kh39sjyi5DXSZAVeI.append(title)
		kv3IdPiFlGO.append(count)
		count += 1
	if size>0:
		if any(AARNPWHjQU9dEmDI in name for AARNPWHjQU9dEmDI in iiQf3Mp6T19gjIx7YuV0bU):
			if size==1:
				jQ6w8xOrgYhSHIRpUqzL = 0
			else:
				jQ6w8xOrgYhSHIRpUqzL = F2yZPukcUh09sqCI8nYw7e('اختر الفيديو المناسب:', xCLQK8kh39sjyi5DXSZAVeI)
				if jQ6w8xOrgYhSHIRpUqzL == -1: return
			jXYwiO9D056pkrzRh1y8tfWJxQoaI3(url+'?section='+str(1+kv3IdPiFlGO[size-jQ6w8xOrgYhSHIRpUqzL-1]))
		else:
			for xxFhvt275i8MdUVuPkSXzmbT in reversed(range(size)):
				title = name + ' - ' + xCLQK8kh39sjyi5DXSZAVeI[xxFhvt275i8MdUVuPkSXzmbT]
				title = title.replace('\n','').strip(' ')
				RRucmYBaXegTtNOdGHMQ = url + '?section='+str(size-xxFhvt275i8MdUVuPkSXzmbT)
				Tca7NsYPkIRWtBpFgxLZbSmCi('video',W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,74,CrGO63LT7j2UxniW)
	else:
		Tca7NsYPkIRWtBpFgxLZbSmCi('video',W74fAyGxODoLPs5vMX2l8C93R+'الرابط ليس فيديو','',9999,CrGO63LT7j2UxniW)
	return
def jXYwiO9D056pkrzRh1y8tfWJxQoaI3(url):
	lQHXdV9Nzf6BLqS8D,LqYKJ36CBG = url.split('?section=')
	wpFmEA3z8JR = A6F71g3cqN4(Z7uFdWIRv9ybj0,'GET',lQHXdV9Nzf6BLqS8D,'',headers,True,'','AKOAM-PLAY_AKOAM-1st')
	QstumvzTIEUMXCcx06aD4y8nSqH = wpFmEA3z8JR.content
	IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('ad-300-250.*?ad-300-250(.*?)ako-feedback',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	a8eYhCst53SARyjU = IZGcQbePXxwAoyYR1n[0].replace("'direct_link_box",'"direct_link_box epsoide_box')
	a8eYhCst53SARyjU = a8eYhCst53SARyjU + 'direct_link_box'
	n5nyDgxTuHbY0LNV4cWvoBtp = ZXFs0mEPR8qI2zj.findall('epsoide_box(.*?)direct_link_box',a8eYhCst53SARyjU,ZXFs0mEPR8qI2zj.DOTALL)
	LqYKJ36CBG = len(n5nyDgxTuHbY0LNV4cWvoBtp)-int(LqYKJ36CBG)
	bdq4e6Wr2gslnSiA38 = n5nyDgxTuHbY0LNV4cWvoBtp[LqYKJ36CBG]
	yf608hE5KeRG1DscunvrU = []
	eA8rdVRHUnlLODfajsb7mtgWGFCkYc = {'1423075862':'dailymotion','1477487601':'estream','1505328404':'streamango',
		'1423080015':'flashx','1458117295':'openload','1423079306':'vimple','1430052371':'ok.ru',
		'1477488213':'thevid','1558278006':'uqload','1477487990':'vidtodo'}
	items = ZXFs0mEPR8qI2zj.findall("class='download_btn.*?href='(.*?)'",bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
	for RRucmYBaXegTtNOdGHMQ in items:
		yf608hE5KeRG1DscunvrU.append(RRucmYBaXegTtNOdGHMQ+'?named=________akoam')
	items = ZXFs0mEPR8qI2zj.findall('background-image: url\((.*?)\).*?href=\'(.*?)\'',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
	for v0T89GnmUEs,RRucmYBaXegTtNOdGHMQ in items:
		v0T89GnmUEs = v0T89GnmUEs.split('/')[-1]
		v0T89GnmUEs = v0T89GnmUEs.split('.')[0]
		if v0T89GnmUEs in eA8rdVRHUnlLODfajsb7mtgWGFCkYc:
			yf608hE5KeRG1DscunvrU.append(RRucmYBaXegTtNOdGHMQ+'?named='+eA8rdVRHUnlLODfajsb7mtgWGFCkYc[v0T89GnmUEs]+'________akoam')
		else: yf608hE5KeRG1DscunvrU.append(RRucmYBaXegTtNOdGHMQ+'?named='+v0T89GnmUEs+'________akoam')
	if not yf608hE5KeRG1DscunvrU:
		message = ZXFs0mEPR8qI2zj.findall('sub-no-file.*?\n(.*?)\n',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
		if message: HHTzVhiY079bvdluNkFQ4wCMpe('','','رسالة من الموقع الاصلي',message[0])
	else:
		import fnxsZbk2Fm
		fnxsZbk2Fm.n2h4SBIzxbgJD3K7rtVej01EuGcHPs(yf608hE5KeRG1DscunvrU,ll6f2wvU4FdqL3MJyDxORESCK197i,'video',url)
	return
def F6OgHwYPRiX10tJEv8r(search):
	search,Y9RKmgsxBefkFcuIj2GULDHy3,showDialogs = XDzpr8RxgZhT(search)
	if search=='': search = CjyEnpfQ23o0PYwDtLId()
	if search=='': return
	H9IMP4eTVW8dji3EXnS7w = search.replace(' ','%20')
	url = JJTrn6SEtYZV31eyR97 + '/search/'+H9IMP4eTVW8dji3EXnS7w
	HkKfQCS7RIa4xi3houjvl = RxAy5lEFQ1chv0BrdU4p6Pt2(url,'search')
	return