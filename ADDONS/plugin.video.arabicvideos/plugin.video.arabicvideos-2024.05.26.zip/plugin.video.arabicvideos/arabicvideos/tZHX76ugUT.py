# -*- coding: utf-8 -*-
from j3x780FpaM import *
ll6f2wvU4FdqL3MJyDxORESCK197i = 'ALFATIMI'
W74fAyGxODoLPs5vMX2l8C93R = '_FTM_'
JJTrn6SEtYZV31eyR97 = uReHcEzxkTm6pN4Q[ll6f2wvU4FdqL3MJyDxORESCK197i][0]
MMaHbSgFIhAsqLtUyfPXNQT4znCuRB = ['1239','1250','1245','20','1259','218','485','1238','1258','292']
VVMJ45I62KT9SfycPgECBQzAitlw = ['3030','628']
def OVQIAezo6U1NSTl4L(mode,url,text):
	if   mode==60: HkKfQCS7RIa4xi3houjvl = oMUN5hPpTkxVZG12Qiva8BKnyw6()
	elif mode==61: HkKfQCS7RIa4xi3houjvl = RxAy5lEFQ1chv0BrdU4p6Pt2(url,text)
	elif mode==62: HkKfQCS7RIa4xi3houjvl = pqx0gStI9ojGFP2rWhwRfkVCNX(url)
	elif mode==63: HkKfQCS7RIa4xi3houjvl = jXYwiO9D056pkrzRh1y8tfWJxQoaI3(url)
	elif mode==64: HkKfQCS7RIa4xi3houjvl = PnVudvc3sC4xNhqwHJDZgz(text)
	elif mode==69: HkKfQCS7RIa4xi3houjvl = F6OgHwYPRiX10tJEv8r(text)
	else: HkKfQCS7RIa4xi3houjvl = False
	return HkKfQCS7RIa4xi3houjvl
def oMUN5hPpTkxVZG12Qiva8BKnyw6():
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+'بحث في الموقع','',69,'','','_REMEMBERRESULTS_')
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder',ll6f2wvU4FdqL3MJyDxORESCK197i+'_SCRIPT_'+W74fAyGxODoLPs5vMX2l8C93R+'ما يتم مشاهدته الان',JJTrn6SEtYZV31eyR97,64,'','','recent_viewed_vids')
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder',ll6f2wvU4FdqL3MJyDxORESCK197i+'_SCRIPT_'+W74fAyGxODoLPs5vMX2l8C93R+'الاكثر مشاهدة',JJTrn6SEtYZV31eyR97,64,'','','most_viewed_vids')
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder',ll6f2wvU4FdqL3MJyDxORESCK197i+'_SCRIPT_'+W74fAyGxODoLPs5vMX2l8C93R+'اضيفت مؤخرا',JJTrn6SEtYZV31eyR97,64,'','','recently_added_vids')
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder',ll6f2wvU4FdqL3MJyDxORESCK197i+'_SCRIPT_'+W74fAyGxODoLPs5vMX2l8C93R+'فيديو عشوائي',JJTrn6SEtYZV31eyR97,64,'','','random_vids')
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder',ll6f2wvU4FdqL3MJyDxORESCK197i+'_SCRIPT_'+W74fAyGxODoLPs5vMX2l8C93R+'افلام ومسلسلات',JJTrn6SEtYZV31eyR97,61,'','','-1')
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder',ll6f2wvU4FdqL3MJyDxORESCK197i+'_SCRIPT_'+W74fAyGxODoLPs5vMX2l8C93R+'البرامج الدينية',JJTrn6SEtYZV31eyR97,61,'','','-2')
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder',ll6f2wvU4FdqL3MJyDxORESCK197i+'_SCRIPT_'+W74fAyGxODoLPs5vMX2l8C93R+'English Videos',JJTrn6SEtYZV31eyR97,61,'','','-3')
	return ''
def RxAy5lEFQ1chv0BrdU4p6Pt2(url,p8pgXONsjY):
	puIXjKCJxFEUHneaq48dPGNYTS7 = ''
	if p8pgXONsjY not in ['-1','-2','-3']: puIXjKCJxFEUHneaq48dPGNYTS7 = '?cat='+p8pgXONsjY
	lQHXdV9Nzf6BLqS8D = JJTrn6SEtYZV31eyR97+'/menu_level.php'+puIXjKCJxFEUHneaq48dPGNYTS7
	QstumvzTIEUMXCcx06aD4y8nSqH = QuWA3hsmIvockZDiy2rLg(Z7uFdWIRv9ybj0,lQHXdV9Nzf6BLqS8D,'','','','ALFATIMI-TITLES-1st')
	items = ZXFs0mEPR8qI2zj.findall('href=\'(.*?)\'.*?>(.*?)<.*?>(.*?)</span>',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	RRKnVY4UHMa3XmWkJOEBtihds72D9G,CTQlmBkHVz6JioRW = False,False
	for RRucmYBaXegTtNOdGHMQ,title,count in items:
		title = qpob7TvxHSs4fEzO6(title)
		title = title.strip(' ')
		if 'http' not in RRucmYBaXegTtNOdGHMQ: RRucmYBaXegTtNOdGHMQ = 'http:'+RRucmYBaXegTtNOdGHMQ
		puIXjKCJxFEUHneaq48dPGNYTS7 = ZXFs0mEPR8qI2zj.findall('cat=(.*?)&',RRucmYBaXegTtNOdGHMQ,ZXFs0mEPR8qI2zj.DOTALL)[0]
		if p8pgXONsjY==puIXjKCJxFEUHneaq48dPGNYTS7: RRKnVY4UHMa3XmWkJOEBtihds72D9G = True
		elif RRKnVY4UHMa3XmWkJOEBtihds72D9G 	or (p8pgXONsjY=='-1' and puIXjKCJxFEUHneaq48dPGNYTS7 in MMaHbSgFIhAsqLtUyfPXNQT4znCuRB)  						or (p8pgXONsjY=='-2' and puIXjKCJxFEUHneaq48dPGNYTS7 not in VVMJ45I62KT9SfycPgECBQzAitlw and puIXjKCJxFEUHneaq48dPGNYTS7 not in MMaHbSgFIhAsqLtUyfPXNQT4znCuRB)  						or (p8pgXONsjY=='-3' and puIXjKCJxFEUHneaq48dPGNYTS7 in VVMJ45I62KT9SfycPgECBQzAitlw):
							if count=='1': Tca7NsYPkIRWtBpFgxLZbSmCi('video',W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,63)
							else: Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,61,'','',puIXjKCJxFEUHneaq48dPGNYTS7)
							CTQlmBkHVz6JioRW = True
	if not CTQlmBkHVz6JioRW: pqx0gStI9ojGFP2rWhwRfkVCNX(url)
	return
def pqx0gStI9ojGFP2rWhwRfkVCNX(url):
	QstumvzTIEUMXCcx06aD4y8nSqH = QuWA3hsmIvockZDiy2rLg(Z7uFdWIRv9ybj0,url,'','',True,'ALFATIMI-EPISODES-1st')
	IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('pagination(.*?)id="footer',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	bdq4e6Wr2gslnSiA38 = IZGcQbePXxwAoyYR1n[0]
	items = ZXFs0mEPR8qI2zj.findall('grid_view.*?src="(.*?)".*?title="(.*?)".*?<h2.*?href="(.*?)"',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
	RRucmYBaXegTtNOdGHMQ = ''
	for CrGO63LT7j2UxniW,title,RRucmYBaXegTtNOdGHMQ in items:
		title = title.replace('Add','').replace('to Quicklist','').strip(' ')
		if 'http' not in RRucmYBaXegTtNOdGHMQ: RRucmYBaXegTtNOdGHMQ = 'http:'+RRucmYBaXegTtNOdGHMQ
		Tca7NsYPkIRWtBpFgxLZbSmCi('video',W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,63,CrGO63LT7j2UxniW)
	IZGcQbePXxwAoyYR1n=ZXFs0mEPR8qI2zj.findall('(.*?)div',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
	bdq4e6Wr2gslnSiA38=IZGcQbePXxwAoyYR1n[0]
	bdq4e6Wr2gslnSiA38=ZXFs0mEPR8qI2zj.findall('pagination(.*?)</div>',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)[0]
	items=ZXFs0mEPR8qI2zj.findall('href="(.*?)".*?>(.*?)<',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
	lQHXdV9Nzf6BLqS8D = url.split('?')[0]
	for RRucmYBaXegTtNOdGHMQ,BbEFSkYKicqaW in items:
		RRucmYBaXegTtNOdGHMQ = lQHXdV9Nzf6BLqS8D + RRucmYBaXegTtNOdGHMQ
		title = qpob7TvxHSs4fEzO6(BbEFSkYKicqaW)
		title = 'صفحة ' + title
		Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,62)
	return RRucmYBaXegTtNOdGHMQ
def jXYwiO9D056pkrzRh1y8tfWJxQoaI3(url):
	if 'videos.php' in url: url = pqx0gStI9ojGFP2rWhwRfkVCNX(url)
	QstumvzTIEUMXCcx06aD4y8nSqH = QuWA3hsmIvockZDiy2rLg(JNsoWV1CXc4xy,url,'','',True,'ALFATIMI-PLAY-1st')
	items = ZXFs0mEPR8qI2zj.findall('playlistfile:"(.*?)"',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	url = items[0]
	if 'http' not in url: url = 'http:'+url
	w3hq0Xp8D9rZJ(url,ll6f2wvU4FdqL3MJyDxORESCK197i,'video')
	return
def PnVudvc3sC4xNhqwHJDZgz(p8pgXONsjY):
	VbZ1Pig043uIGYQ = { 'mode' : p8pgXONsjY }
	url = 'http://alfatimi.tv/ajax.php'
	headers = { 'Content-Type' : 'application/x-www-form-urlencoded' }
	data = XapnozmJWluEb8fdYye0SR6QxqZL(VbZ1Pig043uIGYQ)
	QstumvzTIEUMXCcx06aD4y8nSqH = QuWA3hsmIvockZDiy2rLg(dALVaOWB4jKN3Tbt0Cm1ns9k5u,url,data,headers,True,'ALFATIMI-MOSTS-1st')
	items = ZXFs0mEPR8qI2zj.findall('href="(.*?)".*?title="(.*?)".*?src="(.*?)".*?href',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	for RRucmYBaXegTtNOdGHMQ,title,CrGO63LT7j2UxniW in items:
		title = title.strip(' ')
		if 'http' not in RRucmYBaXegTtNOdGHMQ: RRucmYBaXegTtNOdGHMQ = 'http:'+RRucmYBaXegTtNOdGHMQ
		Tca7NsYPkIRWtBpFgxLZbSmCi('video',W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,63,CrGO63LT7j2UxniW)
	return
def F6OgHwYPRiX10tJEv8r(search):
	search,Y9RKmgsxBefkFcuIj2GULDHy3,showDialogs = XDzpr8RxgZhT(search)
	if search=='': search = CjyEnpfQ23o0PYwDtLId()
	if search=='': return
	H9IMP4eTVW8dji3EXnS7w = search.replace(' ','+')
	url = JJTrn6SEtYZV31eyR97 + '/search_result.php?query=' + H9IMP4eTVW8dji3EXnS7w
	pqx0gStI9ojGFP2rWhwRfkVCNX(url)
	return