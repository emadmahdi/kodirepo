# -*- coding: utf-8 -*-
from j3x780FpaM import *
ll6f2wvU4FdqL3MJyDxORESCK197i = 'MOVS4U'
W74fAyGxODoLPs5vMX2l8C93R = '_M4U_'
JJTrn6SEtYZV31eyR97 = uReHcEzxkTm6pN4Q[ll6f2wvU4FdqL3MJyDxORESCK197i][0]
SmgoEYJ7uyL = ['انواع افلام','جودات افلام']
def OVQIAezo6U1NSTl4L(mode,url,text):
	if   mode==380: HkKfQCS7RIa4xi3houjvl = oMUN5hPpTkxVZG12Qiva8BKnyw6()
	elif mode==381: HkKfQCS7RIa4xi3houjvl = RxAy5lEFQ1chv0BrdU4p6Pt2(url,text)
	elif mode==382: HkKfQCS7RIa4xi3houjvl = jXYwiO9D056pkrzRh1y8tfWJxQoaI3(url)
	elif mode==383: HkKfQCS7RIa4xi3houjvl = pqx0gStI9ojGFP2rWhwRfkVCNX(url)
	elif mode==389: HkKfQCS7RIa4xi3houjvl = F6OgHwYPRiX10tJEv8r(text)
	else: HkKfQCS7RIa4xi3houjvl = False
	return HkKfQCS7RIa4xi3houjvl
def oMUN5hPpTkxVZG12Qiva8BKnyw6():
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+'بحث في الموقع','',389,'','','_REMEMBERRESULTS_')
	Tca7NsYPkIRWtBpFgxLZbSmCi('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder',ll6f2wvU4FdqL3MJyDxORESCK197i+'_SCRIPT_'+W74fAyGxODoLPs5vMX2l8C93R+'المميزة',JJTrn6SEtYZV31eyR97,381,'','','featured')
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder',ll6f2wvU4FdqL3MJyDxORESCK197i+'_SCRIPT_'+W74fAyGxODoLPs5vMX2l8C93R+'الجانبية',JJTrn6SEtYZV31eyR97,381,'','','sider')
	wpFmEA3z8JR = A6F71g3cqN4(JNsoWV1CXc4xy,'GET',JJTrn6SEtYZV31eyR97,'','','','','MOVS4U-MENU-1st')
	QstumvzTIEUMXCcx06aD4y8nSqH = wpFmEA3z8JR.content
	items = ZXFs0mEPR8qI2zj.findall('<header>.*?<h2>(.*?)<',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	for bznBHAX7xt6 in range(len(items)):
		title = items[bznBHAX7xt6]
		Tca7NsYPkIRWtBpFgxLZbSmCi('folder',ll6f2wvU4FdqL3MJyDxORESCK197i+'_SCRIPT_'+W74fAyGxODoLPs5vMX2l8C93R+title,JJTrn6SEtYZV31eyR97,381,'','','latest'+str(bznBHAX7xt6))
	bdq4e6Wr2gslnSiA38 = ''
	IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('class="menu"(.*?)id="contenedor"',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	if IZGcQbePXxwAoyYR1n: bdq4e6Wr2gslnSiA38 += IZGcQbePXxwAoyYR1n[0]
	IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('class="sidebar(.*?)aside',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	if IZGcQbePXxwAoyYR1n: bdq4e6Wr2gslnSiA38 += IZGcQbePXxwAoyYR1n[0]
	items = ZXFs0mEPR8qI2zj.findall('href="(.*?)">(.*?)<',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
	Tca7NsYPkIRWtBpFgxLZbSmCi('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	Fl9VDzobcU = True
	for RRucmYBaXegTtNOdGHMQ,title in items:
		title = qpob7TvxHSs4fEzO6(title)
		if title=='الأعلى مشاهدة':
			if Fl9VDzobcU:
				title = 'الافلام '+title
				Fl9VDzobcU = False
			else: title = 'المسلسلات '+title
		if title not in SmgoEYJ7uyL:
			Tca7NsYPkIRWtBpFgxLZbSmCi('folder',ll6f2wvU4FdqL3MJyDxORESCK197i+'_SCRIPT_'+W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,381)
	return QstumvzTIEUMXCcx06aD4y8nSqH
def RxAy5lEFQ1chv0BrdU4p6Pt2(url,type):
	bdq4e6Wr2gslnSiA38,items = [],[]
	wpFmEA3z8JR = A6F71g3cqN4(Z7uFdWIRv9ybj0,'GET',url,'','','','','MOVS4U-TITLES-1st')
	QstumvzTIEUMXCcx06aD4y8nSqH = wpFmEA3z8JR.content
	if type=='search':
		IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('class="search-page"(.*?)class="sidebar',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
		if IZGcQbePXxwAoyYR1n:
			bdq4e6Wr2gslnSiA38 = IZGcQbePXxwAoyYR1n[0]
			items = ZXFs0mEPR8qI2zj.findall('img src="(.*?)".*?href="(.*?)">(.*?)<',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
	elif type=='sider':
		IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('class="widget(.*?)class="widget',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
		bdq4e6Wr2gslnSiA38 = IZGcQbePXxwAoyYR1n[0]
		U7zPDek3rsaj2u9tTAK = ZXFs0mEPR8qI2zj.findall('href="(.*?)".*?img src="(.*?)".*?<h3>(.*?)<',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
		YYmyQXglbEewzL3IA2Sd,JcSzrjHL0lVwM,xCLQK8kh39sjyi5DXSZAVeI = zip(*U7zPDek3rsaj2u9tTAK)
		items = zip(JcSzrjHL0lVwM,YYmyQXglbEewzL3IA2Sd,xCLQK8kh39sjyi5DXSZAVeI)
	elif type=='featured':
		IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('id="slider-movies-tvshows"(.*?)<header>',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
		bdq4e6Wr2gslnSiA38 = IZGcQbePXxwAoyYR1n[0]
		items = ZXFs0mEPR8qI2zj.findall('img src="(.*?)".*?href="(.*?)".*?"title">(.*?)<',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
	elif 'latest' in type:
		bznBHAX7xt6 = int(type[-1:])
		QstumvzTIEUMXCcx06aD4y8nSqH = QstumvzTIEUMXCcx06aD4y8nSqH.replace('<header>','<end><start>')
		QstumvzTIEUMXCcx06aD4y8nSqH = QstumvzTIEUMXCcx06aD4y8nSqH.replace('<div class="sidebar','<end><div class="sidebar')
		IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('<start>(.*?)<end>',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
		bdq4e6Wr2gslnSiA38 = IZGcQbePXxwAoyYR1n[bznBHAX7xt6]
		if bznBHAX7xt6==2: items = ZXFs0mEPR8qI2zj.findall('img src="(.*?)".*?href="(.*?)">(.*?)<',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
	else:
		IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('class="content"(.*?)class="(pagination|sidebar)',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
		if IZGcQbePXxwAoyYR1n:
			bdq4e6Wr2gslnSiA38 = IZGcQbePXxwAoyYR1n[0][0]
			if '/collection/' in url:
				items = ZXFs0mEPR8qI2zj.findall('img src="(.*?)".*?href="(.*?)">(.*?)<',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
			elif '/quality/' in url:
				items = ZXFs0mEPR8qI2zj.findall('img src="(.*?)".*?href="(.*?)".*?"title">(.*?)<',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
	if not items and bdq4e6Wr2gslnSiA38:
		items = ZXFs0mEPR8qI2zj.findall('img src="(.*?)".*?href=.*?href="(.*?)">(.*?)</div>',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
	FF1TYf6O5KENr8R72LUVievClmudxD = []
	for CrGO63LT7j2UxniW,RRucmYBaXegTtNOdGHMQ,title in items:
		if 'serie' in title:
			title = ZXFs0mEPR8qI2zj.findall('^(.*?)<.*?serie">(.*?)<',title,ZXFs0mEPR8qI2zj.DOTALL)
			title = title[0][1]
			if title in FF1TYf6O5KENr8R72LUVievClmudxD: continue
			FF1TYf6O5KENr8R72LUVievClmudxD.append(title)
			title = '_MOD_'+title
		Wu4CadwRTJfkbXMUVxO3jQ2 = ZXFs0mEPR8qI2zj.findall('^(.*?)<',title,ZXFs0mEPR8qI2zj.DOTALL)
		if Wu4CadwRTJfkbXMUVxO3jQ2: title = Wu4CadwRTJfkbXMUVxO3jQ2[0]
		title = qpob7TvxHSs4fEzO6(title)
		if '/tvshows/' in RRucmYBaXegTtNOdGHMQ: Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,383,CrGO63LT7j2UxniW)
		elif '/episodes/' in RRucmYBaXegTtNOdGHMQ: Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,383,CrGO63LT7j2UxniW)
		elif '/seasons/' in RRucmYBaXegTtNOdGHMQ: Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,383,CrGO63LT7j2UxniW)
		elif '/collection/' in RRucmYBaXegTtNOdGHMQ: Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,381,CrGO63LT7j2UxniW)
		else: Tca7NsYPkIRWtBpFgxLZbSmCi('video',W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,382,CrGO63LT7j2UxniW)
	IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('class="pagination".*?Page (.*?) of (.*?)<(.*?)</div>',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	if IZGcQbePXxwAoyYR1n:
		X9i6TInyMAwj4ZdDgbrkzU = IZGcQbePXxwAoyYR1n[0][0]
		HHWp591alRmr4UdBfV2O = IZGcQbePXxwAoyYR1n[0][1]
		bdq4e6Wr2gslnSiA38 = IZGcQbePXxwAoyYR1n[0][2]
		items = ZXFs0mEPR8qI2zj.findall("href='(.*?)'.*?>(.*?)<",bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
		for RRucmYBaXegTtNOdGHMQ,title in items:
			if title=='' or title==HHWp591alRmr4UdBfV2O: continue
			Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+'صفحة '+title,RRucmYBaXegTtNOdGHMQ,381,'','',type)
		RRucmYBaXegTtNOdGHMQ = RRucmYBaXegTtNOdGHMQ.replace('/page/'+title+'/','/page/'+HHWp591alRmr4UdBfV2O+'/')
		Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+'اخر صفحة '+HHWp591alRmr4UdBfV2O,RRucmYBaXegTtNOdGHMQ,381,'','',type)
	return
def pqx0gStI9ojGFP2rWhwRfkVCNX(url):
	wpFmEA3z8JR = A6F71g3cqN4(Z7uFdWIRv9ybj0,'GET',url,'','','','','MOVS4U-EPISODES-1st')
	QstumvzTIEUMXCcx06aD4y8nSqH = wpFmEA3z8JR.content
	z4O2HXsQyg = ZXFs0mEPR8qI2zj.findall('class="C rated".*?>(.*?)<',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	if z4O2HXsQyg and GBC7yanr9WNYIKXSHRxgP(ll6f2wvU4FdqL3MJyDxORESCK197i,url,z4O2HXsQyg,False):
		Tca7NsYPkIRWtBpFgxLZbSmCi('link',W74fAyGxODoLPs5vMX2l8C93R+'المسلسل للكبار والمبرمج منعه','',9999)
		return
	if '/episodes/' in url or '/tvshows/' in url:
		lQHXdV9Nzf6BLqS8D = ZXFs0mEPR8qI2zj.findall('''class='item'><a href="(.*?)"''',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
		if lQHXdV9Nzf6BLqS8D:
			lQHXdV9Nzf6BLqS8D = lQHXdV9Nzf6BLqS8D[1]
			pqx0gStI9ojGFP2rWhwRfkVCNX(lQHXdV9Nzf6BLqS8D)
			return
	IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('''class='episodios'(.*?)id="cast"''',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	if IZGcQbePXxwAoyYR1n:
		bdq4e6Wr2gslnSiA38 = IZGcQbePXxwAoyYR1n[0]
		items = ZXFs0mEPR8qI2zj.findall('''src='(.*?)'.*?class='numerando'>(.*?)<.*?href='(.*?)'>(.*?)<''',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
		for CrGO63LT7j2UxniW,LqYKJ36CBG,RRucmYBaXegTtNOdGHMQ,name in items:
			title = LqYKJ36CBG+' : '+name+' الحلقة'
			Tca7NsYPkIRWtBpFgxLZbSmCi('video',W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,382)
	return
def jXYwiO9D056pkrzRh1y8tfWJxQoaI3(url):
	wpFmEA3z8JR = A6F71g3cqN4(Z7uFdWIRv9ybj0,'GET',url,'','','','','MOVS4U-PLAY-1st')
	QstumvzTIEUMXCcx06aD4y8nSqH = wpFmEA3z8JR.content
	z4O2HXsQyg = ZXFs0mEPR8qI2zj.findall('class="C rated".*?>(.*?)<',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	if z4O2HXsQyg and GBC7yanr9WNYIKXSHRxgP(ll6f2wvU4FdqL3MJyDxORESCK197i,url,z4O2HXsQyg): return
	YYmyQXglbEewzL3IA2Sd = []
	IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('''id='player-option-1'(.*?)class=("sheader"|'pag_episodes')''',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	if IZGcQbePXxwAoyYR1n:
		bdq4e6Wr2gslnSiA38 = IZGcQbePXxwAoyYR1n[0][0]
		items = ZXFs0mEPR8qI2zj.findall("data-url='(.*?)'.*?class='server'>(.*?)<",bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
		for RRucmYBaXegTtNOdGHMQ,title in items:
			RRucmYBaXegTtNOdGHMQ = RRucmYBaXegTtNOdGHMQ+'?named='+title+'__watch'
			YYmyQXglbEewzL3IA2Sd.append(RRucmYBaXegTtNOdGHMQ)
	IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('class="remodal"(.*?)class="remodal-close"',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	if IZGcQbePXxwAoyYR1n:
		bdq4e6Wr2gslnSiA38 = IZGcQbePXxwAoyYR1n[0]
		items = ZXFs0mEPR8qI2zj.findall('class="___dl_gdrive.*?href="(.*?)".*?">(.*?)<',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
		for RRucmYBaXegTtNOdGHMQ,title in items:
			RRucmYBaXegTtNOdGHMQ = JJTrn6SEtYZV31eyR97+RRucmYBaXegTtNOdGHMQ
			RRucmYBaXegTtNOdGHMQ = RRucmYBaXegTtNOdGHMQ+'?named='+title+'__download'
			YYmyQXglbEewzL3IA2Sd.append(RRucmYBaXegTtNOdGHMQ)
	import fnxsZbk2Fm
	fnxsZbk2Fm.n2h4SBIzxbgJD3K7rtVej01EuGcHPs(YYmyQXglbEewzL3IA2Sd,ll6f2wvU4FdqL3MJyDxORESCK197i,'video',url)
	return
def F6OgHwYPRiX10tJEv8r(search):
	search,Y9RKmgsxBefkFcuIj2GULDHy3,showDialogs = XDzpr8RxgZhT(search)
	if search=='': search = CjyEnpfQ23o0PYwDtLId()
	if search=='': return
	search = search.replace(' ','+')
	url = JJTrn6SEtYZV31eyR97+'/?s='+search
	RxAy5lEFQ1chv0BrdU4p6Pt2(url,'search')
	return