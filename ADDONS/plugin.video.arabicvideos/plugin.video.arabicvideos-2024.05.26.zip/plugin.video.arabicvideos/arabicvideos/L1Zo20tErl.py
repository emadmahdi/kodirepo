# -*- coding: utf-8 -*-
import sys as ddABnr3K9Xv8e71CzcN0Pxt
NLQaPokgt7Zi = ddABnr3K9Xv8e71CzcN0Pxt.version_info [0] == 2
QzcRNkipwA1WPJu6ZoTnxrjBlqe2 = 2048
Y07K8pBzWtXncO9rUdsw1MTgAyFS = 7
def pFM6HfGd7Urbxto45vSNLniWA (gKVwro2lTJQEp):
	global AUQrTjaXt8K
	UUhFMplXo8RaCwxnEz5Hm7r = ord (gKVwro2lTJQEp [-1])
	slDu7whZzrU2b3oCYREig1L65F9HK = gKVwro2lTJQEp [:-1]
	Ha7jrvByPJYSIiRoXm5ThCOWc = UUhFMplXo8RaCwxnEz5Hm7r % len (slDu7whZzrU2b3oCYREig1L65F9HK)
	E5JVTBFqvjCN2Sc = slDu7whZzrU2b3oCYREig1L65F9HK [:Ha7jrvByPJYSIiRoXm5ThCOWc] + slDu7whZzrU2b3oCYREig1L65F9HK [Ha7jrvByPJYSIiRoXm5ThCOWc:]
	if NLQaPokgt7Zi:
		lK9D8U71rY = unicode () .join ([unichr (ord (ysjIJ8PTAQv5copxFkLUXrRwf) - QzcRNkipwA1WPJu6ZoTnxrjBlqe2 - (WutIpGj5YChbO + UUhFMplXo8RaCwxnEz5Hm7r) % Y07K8pBzWtXncO9rUdsw1MTgAyFS) for WutIpGj5YChbO, ysjIJ8PTAQv5copxFkLUXrRwf in enumerate (E5JVTBFqvjCN2Sc)])
	else:
		lK9D8U71rY = str () .join ([chr (ord (ysjIJ8PTAQv5copxFkLUXrRwf) - QzcRNkipwA1WPJu6ZoTnxrjBlqe2 - (WutIpGj5YChbO + UUhFMplXo8RaCwxnEz5Hm7r) % Y07K8pBzWtXncO9rUdsw1MTgAyFS) for WutIpGj5YChbO, ysjIJ8PTAQv5copxFkLUXrRwf in enumerate (E5JVTBFqvjCN2Sc)])
	return eval (lK9D8U71rY)
OVmSuf8tpd,LmcNhzY6fQPd2JyCGslkSr,J3OCAmZVcn=pFM6HfGd7Urbxto45vSNLniWA,pFM6HfGd7Urbxto45vSNLniWA,pFM6HfGd7Urbxto45vSNLniWA
eeIL1TfgFQJaKqVD8hGNPEZ,aFQoGfmYKyqLU6X8libw9k3ncW5,m6b7CoBk4EQ=J3OCAmZVcn,LmcNhzY6fQPd2JyCGslkSr,OVmSuf8tpd
ZSJVq5XDrRot,yTMWeCgUROcvtsblfK85L62xPk,AAgpHN0nMZ=m6b7CoBk4EQ,aFQoGfmYKyqLU6X8libw9k3ncW5,eeIL1TfgFQJaKqVD8hGNPEZ
XogUJZEijT7KWbxeO6,FhcnOB9t3frzvXb,aVLSn1xw5cK=AAgpHN0nMZ,yTMWeCgUROcvtsblfK85L62xPk,ZSJVq5XDrRot
ffCSGrTJYPsxgVQWKLtHU3iMwB,EDPaWgMt1SwNn8o,PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg=aVLSn1xw5cK,FhcnOB9t3frzvXb,XogUJZEijT7KWbxeO6
Ej67fFyoqW8kbV2HdSK,kmdSKeBIwViM9t3,fR68jBGWCzUsFXdlTKPOScugm=PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg,EDPaWgMt1SwNn8o,ffCSGrTJYPsxgVQWKLtHU3iMwB
bdhQDyjm3nPwToFHkprvCzBLUGR,JcDaEHuiS8TqBbOhWe4ZgwknoC1L3r,wwyUWMFAsO=fR68jBGWCzUsFXdlTKPOScugm,kmdSKeBIwViM9t3,Ej67fFyoqW8kbV2HdSK
kRYWcNuAazr4jtmBoxFVS19Z6,pEo8g7riWVL014KaRtzQ,sArCMRngQNmXkBoKv=wwyUWMFAsO,JcDaEHuiS8TqBbOhWe4ZgwknoC1L3r,bdhQDyjm3nPwToFHkprvCzBLUGR
JMLhEyaBWmskovGHTrVCxQ08,MM2BQ7xrAfNivgenXPytGYOs0DEHRC,hjNP5w9srJz2QpVISxBfndbD4CkXvl=sArCMRngQNmXkBoKv,pEo8g7riWVL014KaRtzQ,kRYWcNuAazr4jtmBoxFVS19Z6
xuYvdJpOEyQKTLNwb,jYaM5vilgZdFx6QHbApwVXO8et,DLSVmlyBbCK=hjNP5w9srJz2QpVISxBfndbD4CkXvl,MM2BQ7xrAfNivgenXPytGYOs0DEHRC,JMLhEyaBWmskovGHTrVCxQ08
gnfv8UtZ3daGqpjzk,gSmqZU0plur2xKPJwQA,c4QSTnPiWUCjhrLlwGB=DLSVmlyBbCK,jYaM5vilgZdFx6QHbApwVXO8et,xuYvdJpOEyQKTLNwb
from j3x780FpaM import *
ll6f2wvU4FdqL3MJyDxORESCK197i = yTMWeCgUROcvtsblfK85L62xPk(u"ࠨࡆࡒ࡛ࡓࡒࡏࡂࡆࠪज")
def OVQIAezo6U1NSTl4L(nnPsf4XLIJ7RWF,gC2hO80boRyM7TBGqD):
	if   nnPsf4XLIJ7RWF==aVLSn1xw5cK(u"࠷࠸࠶৪"): HkKfQCS7RIa4xi3houjvl = JgP7UElSiQHs6OmWFeAcYaMLzx()
	elif nnPsf4XLIJ7RWF==Ej67fFyoqW8kbV2HdSK(u"࠸࠹࠱৫"): HkKfQCS7RIa4xi3houjvl = jXYwiO9D056pkrzRh1y8tfWJxQoaI3(gC2hO80boRyM7TBGqD)
	elif nnPsf4XLIJ7RWF==JcDaEHuiS8TqBbOhWe4ZgwknoC1L3r(u"࠹࠳࠳৬"): HkKfQCS7RIa4xi3houjvl = pxauNDWEUz7MX9Y()
	elif nnPsf4XLIJ7RWF==wwyUWMFAsO(u"࠳࠴࠵৭"): HkKfQCS7RIa4xi3houjvl = hnGKNgrLH9ZtxFSBfi6uD()
	elif nnPsf4XLIJ7RWF==xuYvdJpOEyQKTLNwb(u"࠴࠵࠷৮"): HkKfQCS7RIa4xi3houjvl = lLw9xF0vuYsQGS1VJdz2yMgUTfbXC5(gC2hO80boRyM7TBGqD)
	else: HkKfQCS7RIa4xi3houjvl = LmcNhzY6fQPd2JyCGslkSr(u"ࡋࡧ࡬ࡴࡧਜ")
	return HkKfQCS7RIa4xi3houjvl
def lLw9xF0vuYsQGS1VJdz2yMgUTfbXC5(WOUocN0wPpg27BISn):
	try: hhHq8m5vauKG9dl.remove(WOUocN0wPpg27BISn.decode(aFQoGfmYKyqLU6X8libw9k3ncW5(u"ࠩࡸࡸ࡫࠾ࠧझ")))
	except: hhHq8m5vauKG9dl.remove(WOUocN0wPpg27BISn)
	return
def jXYwiO9D056pkrzRh1y8tfWJxQoaI3(gC2hO80boRyM7TBGqD):
	w3hq0Xp8D9rZJ(gC2hO80boRyM7TBGqD,ll6f2wvU4FdqL3MJyDxORESCK197i,gnfv8UtZ3daGqpjzk(u"ࠪࡺ࡮ࡪࡥࡰࠩञ"))
	return
def hnGKNgrLH9ZtxFSBfi6uD():
	LaX1QCyeIJ = LmcNhzY6fQPd2JyCGslkSr(u"ࠫศึ็ษࠢศ่๎ࠦัศสฺࠤฬ๊แ๋ัํ์ࠥษ่ࠡษ็ูํะࠠโ์ࠣห้๋่ใ฻ࠣห้๋ืๅ๊หࠤะ๋ࠠฤุ฽฻ࠥ฿ไ๊ࠢีีࠥอไใษษ้ฮࠦวๅ์่๎๋ࠦหๆࠢฦาฯอัࠡࠤอั๊๐ไࠡ็็ๅฬะࠠโ์า๎ํࠨࠠฬ็ࠣหำะวาࠢาๆฮࠦวๅื๋ีฮ่ࠦศะอหึࠦๆ้฻้้ࠣ็ࠠศๆุ์ึฯ้ࠠส฼ำ์อࠠิ๊ไࠤ๏ฮฯฤࠢส่ฯำๅ๋ๆࠪट")
	HHTzVhiY079bvdluNkFQ4wCMpe(EDPaWgMt1SwNn8o(u"ࠬ࠭ठ"),ZSJVq5XDrRot(u"࠭ࠧड"),pEo8g7riWVL014KaRtzQ(u"ุࠧำํๆฮࠦสฮ็ํ่ࠥอไๆๆไหฯ࠭ढ"),LaX1QCyeIJ)
	return
def JgP7UElSiQHs6OmWFeAcYaMLzx():
	Tca7NsYPkIRWtBpFgxLZbSmCi(kRYWcNuAazr4jtmBoxFVS19Z6(u"ࠨ࡮࡬ࡲࡰ࠭ण"),OVmSuf8tpd(u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡ฼ื๊ใหࠣฮา๋๊ๅ่่ࠢๆอสࠡษ็ๅ๏ี๊้࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪत"),pEo8g7riWVL014KaRtzQ(u"ࠪࠫथ"),ZSJVq5XDrRot(u"࠵࠶࠷৯"))
	Tca7NsYPkIRWtBpFgxLZbSmCi(aVLSn1xw5cK(u"ࠫࡱ࡯࡮࡬ࠩद"),AAgpHN0nMZ(u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ห฼ํ๎ึࠦๅไษ้ࠤฯำๅ๋ๆࠣห้็๊ะ์๋๋ฬะ࡛࠰ࡅࡒࡐࡔࡘ࡝ࠨध"),kRYWcNuAazr4jtmBoxFVS19Z6(u"࠭ࠧन"),MM2BQ7xrAfNivgenXPytGYOs0DEHRC(u"࠶࠷࠷ৰ"))
	Tca7NsYPkIRWtBpFgxLZbSmCi(DLSVmlyBbCK(u"ࠧ࡭࡫ࡱ࡯ࠬऩ"),AAgpHN0nMZ(u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪप"),bdhQDyjm3nPwToFHkprvCzBLUGR(u"ࠩࠪफ"),ffCSGrTJYPsxgVQWKLtHU3iMwB(u"࠽࠾࠿࠹ৱ"))
	QbhVCTMLaWiYp = XIhYWKowsaCqdQNM8()
	wwEXJ0K695RzI4aF7NGypqMx = hhHq8m5vauKG9dl.stat(QbhVCTMLaWiYp).st_mtime
	NN0VnHzeD4flhcFUot = []
	if VYMZsxRpcQHPgkaiDKjyoh: HiEOWDjldc9qA1sRy74TkL = hhHq8m5vauKG9dl.listdir(QbhVCTMLaWiYp.encode(OVmSuf8tpd(u"ࠪࡹࡹ࡬࠸ࠨब")))
	else: HiEOWDjldc9qA1sRy74TkL = hhHq8m5vauKG9dl.listdir(QbhVCTMLaWiYp.decode(J3OCAmZVcn(u"ࠫࡺࡺࡦ࠹ࠩभ")))
	for SSkZRKCX07 in HiEOWDjldc9qA1sRy74TkL:
		if VYMZsxRpcQHPgkaiDKjyoh: SSkZRKCX07 = SSkZRKCX07.decode(pEo8g7riWVL014KaRtzQ(u"ࠬࡻࡴࡧ࠺ࠪम"))
		if not SSkZRKCX07.startswith(DLSVmlyBbCK(u"࠭ࡦࡪ࡮ࡨࡣࠬय")): continue
		bmjnZkXJlvC5GMyKPA4h = hhHq8m5vauKG9dl.path.join(QbhVCTMLaWiYp,SSkZRKCX07)
		wwEXJ0K695RzI4aF7NGypqMx = hhHq8m5vauKG9dl.path.getmtime(bmjnZkXJlvC5GMyKPA4h)
		NN0VnHzeD4flhcFUot.append([SSkZRKCX07,wwEXJ0K695RzI4aF7NGypqMx])
	NN0VnHzeD4flhcFUot = sorted(NN0VnHzeD4flhcFUot,reverse=J3OCAmZVcn(u"࡚ࡲࡶࡧਝ"),key=lambda key: key[J3OCAmZVcn(u"࠶৲")])
	for SSkZRKCX07,wwEXJ0K695RzI4aF7NGypqMx in NN0VnHzeD4flhcFUot:
		if Yd6t3PjlLKk:
			try: SSkZRKCX07 = SSkZRKCX07.decode(bdhQDyjm3nPwToFHkprvCzBLUGR(u"ࠧࡶࡶࡩ࠼ࠬर"))
			except: pass
			SSkZRKCX07 = SSkZRKCX07.encode(m6b7CoBk4EQ(u"ࠨࡷࡷࡪ࠽࠭ऱ"))
		bmjnZkXJlvC5GMyKPA4h = hhHq8m5vauKG9dl.path.join(QbhVCTMLaWiYp,SSkZRKCX07)
		Tca7NsYPkIRWtBpFgxLZbSmCi(OVmSuf8tpd(u"ࠩࡹ࡭ࡩ࡫࡯ࠨल"),SSkZRKCX07,bmjnZkXJlvC5GMyKPA4h,EDPaWgMt1SwNn8o(u"࠹࠳࠲৳"))
	return
def XIhYWKowsaCqdQNM8():
	QbhVCTMLaWiYp = j2agIU0xsLS6c7T.getSetting(ZSJVq5XDrRot(u"ࠪࡥࡻ࠴ࡤࡰࡹࡱࡰࡴࡧࡤ࠯ࡲࡤࡸ࡭࠭ळ"))
	if QbhVCTMLaWiYp: return QbhVCTMLaWiYp
	j2agIU0xsLS6c7T.setSetting(gSmqZU0plur2xKPJwQA(u"ࠫࡦࡼ࠮ࡥࡱࡺࡲࡱࡵࡡࡥ࠰ࡳࡥࡹ࡮ࠧऴ"),mATvU6VbxOXNFhz8lK5WGrfQ)
	return mATvU6VbxOXNFhz8lK5WGrfQ
def pxauNDWEUz7MX9Y():
	QbhVCTMLaWiYp = XIhYWKowsaCqdQNM8()
	V4seFqr0EmgNAkUL8WzfD2nl = OxCB4medn1(AAgpHN0nMZ(u"ࠬࡩࡥ࡯ࡶࡨࡶࠬव"),pEo8g7riWVL014KaRtzQ(u"࠭ࠧश"),AAgpHN0nMZ(u"ࠧࠨष"),xuYvdJpOEyQKTLNwb(u"ࠨ็ๆห๋ࠦสฯิํ๊๋ࠥไโษอࠤฬ๊สฮ็ํ่ࠬस"),m6b7CoBk4EQ(u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡋࡌࡆࡇ࠲࠳ࡡࠬह")+QbhVCTMLaWiYp+MM2BQ7xrAfNivgenXPytGYOs0DEHRC(u"ࠪ࡟࠴ࡉࡏࡍࡑࡕࡡࡡࡴ࡜࡯้ำหࠥํ่ࠡ็ๆห๋ࠦสฯิํ๊๋ࠥไโษอࠤฬ๊แ๋ัํ์ࠥอไห์ࠣฮา๋ไ่ษࠣห๋ะࠠษษึฮำีวๆ๊ࠢิฬࠦวๅสิ๊ฬ๋ฬࠡ࠰๋้ࠣࠦสา์าࠤฯเ๊๋ำࠣห้๋ใศ่ࠣรࠬऺ"))
	if V4seFqr0EmgNAkUL8WzfD2nl==xuYvdJpOEyQKTLNwb(u"࠱৴"):
		vp0fX5rkDnEgamIqLwhlO2jSzFi8UG = AeZ3q6sbXHJ5w1(jYaM5vilgZdFx6QHbApwVXO8et(u"࠴৵"),FhcnOB9t3frzvXb(u"๊้ࠫว็ࠢอั๊๐ไࠡ็็ๅฬะࠠศๆไ๎ิ๐่ࠨऻ"),XogUJZEijT7KWbxeO6(u"ࠬࡲ࡯ࡤࡣ࡯़ࠫ"),gnfv8UtZ3daGqpjzk(u"࠭ࠧऽ"),eeIL1TfgFQJaKqVD8hGNPEZ(u"ࡇࡣ࡯ࡷࡪਟ"),ZSJVq5XDrRot(u"ࡔࡳࡷࡨਞ"),QbhVCTMLaWiYp)
		YYkEu4IL0sTa = OxCB4medn1(JMLhEyaBWmskovGHTrVCxQ08(u"ࠧࡤࡧࡱࡸࡪࡸࠧा"),gSmqZU0plur2xKPJwQA(u"ࠨࠩि"),pEo8g7riWVL014KaRtzQ(u"ࠩࠪी"),bdhQDyjm3nPwToFHkprvCzBLUGR(u"้่ࠪอๆࠡฬัึ๏์ࠠๆๆไหฯࠦวๅฬะ้๏๊ࠧु"),fR68jBGWCzUsFXdlTKPOScugm(u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡆࡇࡈࡉ࠴࠵ࡣࠧू")+QbhVCTMLaWiYp+DLSVmlyBbCK(u"ࠬࡡ࠯ࡄࡑࡏࡓࡗࡣ࡜࡯࡞ࡱ๋ีอ่๊ࠠࠣห้๋ใศ่ࠣห้าฯ๋ั่ࠣฯิา๋่้้ࠣ็วหࠢส่ๆ๐ฯ๋๊ࠣห้ะ๊ࠡฬะ้้ํวࠡษ้ฮࠥฮวิฬัำฬ๋่ࠠาสࠤฬ๊ศา่ส้ัࠦ࠮้ࠡ็ࠤฯื๊ะࠢสืฯิฯศ็๊ࠤอีไศ่๊ࠢࠥอไๆๅส๊ࠥอไใัํ้ࠥลࠧृ"))
		if YYkEu4IL0sTa==gSmqZU0plur2xKPJwQA(u"࠳৶"):
			j2agIU0xsLS6c7T.setSetting(hjNP5w9srJz2QpVISxBfndbD4CkXvl(u"࠭ࡡࡷ࠰ࡧࡳࡼࡴ࡬ࡰࡣࡧ࠲ࡵࡧࡴࡩࠩॄ"),vp0fX5rkDnEgamIqLwhlO2jSzFi8UG)
			HHTzVhiY079bvdluNkFQ4wCMpe(m6b7CoBk4EQ(u"ࠧࠨॅ"),yTMWeCgUROcvtsblfK85L62xPk(u"ࠨࠩॆ"),wwyUWMFAsO(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬे"),MM2BQ7xrAfNivgenXPytGYOs0DEHRC(u"ࠪฮ๊ࠦส฻์ํี๋ࠥใศ่ࠣฮำุ๊็ࠢส่๊๊แศฬࠣห้๋อๆๆฬࠫै"))
	return
def YYGwvozNbHknlU4(gC2hO80boRyM7TBGqD,n2wpUdA6KX4kLjJGxZWVieycPg=EDPaWgMt1SwNn8o(u"ࠫࠬॉ"),website=ZSJVq5XDrRot(u"ࠬ࠭ॊ")):
	tr24ZoudmqvxfYCw(yTMWeCgUROcvtsblfK85L62xPk(u"࠭ࡎࡐࡖࡌࡇࡊ࠭ो"),RGSFZ7ls3nO(ll6f2wvU4FdqL3MJyDxORESCK197i)+Ej67fFyoqW8kbV2HdSK(u"ࠧࠡࠢࠣࡔࡷ࡫ࡰࡢࡴ࡬ࡲ࡬ࠦࡴࡰࠢࡧࡳࡼࡴ࡬ࡰࡣࡧࠤࠥࠦࡕࡓࡎ࠽ࠤࡠࠦࠧौ")+gC2hO80boRyM7TBGqD+JMLhEyaBWmskovGHTrVCxQ08(u"ࠨࠢࡠ्ࠫ"))
	if not n2wpUdA6KX4kLjJGxZWVieycPg: n2wpUdA6KX4kLjJGxZWVieycPg = fDEdQSsq1uPoU(gC2hO80boRyM7TBGqD)
	QbhVCTMLaWiYp = XIhYWKowsaCqdQNM8()
	nnUZQ3KaPgjcv6CuF = YqFHx5cX8apMkfeB()
	SSkZRKCX07 = nnUZQ3KaPgjcv6CuF.replace(yTMWeCgUROcvtsblfK85L62xPk(u"ࠩࠣࠫॎ"),pEo8g7riWVL014KaRtzQ(u"ࠪࡣࠬॏ"))
	SSkZRKCX07 = qWMK324ghvjprnZelCTPwFoEIDc(SSkZRKCX07)
	SSkZRKCX07 = gnfv8UtZ3daGqpjzk(u"ࠫ࡫࡯࡬ࡦࡡࠪॐ")+str(int(F5I1VZzxkXenKuEAYO))[-MM2BQ7xrAfNivgenXPytGYOs0DEHRC(u"࠷৷"):]+jYaM5vilgZdFx6QHbApwVXO8et(u"ࠬࡥࠧ॑")+SSkZRKCX07+n2wpUdA6KX4kLjJGxZWVieycPg
	QQ90mpKANUJ2sZ1DSiHtXLxhEw = hhHq8m5vauKG9dl.path.join(QbhVCTMLaWiYp,SSkZRKCX07)
	Mm7XCRohg3iUSfJKdWsIqx = {}
	Mm7XCRohg3iUSfJKdWsIqx[FhcnOB9t3frzvXb(u"࠭ࡁࡤࡥࡨࡴࡹ࠳ࡅ࡯ࡥࡲࡨ࡮ࡴࡧࠨ॒")] = LmcNhzY6fQPd2JyCGslkSr(u"ࠧࠨ॓")
	Mm7XCRohg3iUSfJKdWsIqx[gSmqZU0plur2xKPJwQA(u"ࠨࡃࡦࡧࡪࡶࡴࠨ॔")] = ZSJVq5XDrRot(u"ࠩ࠭࠳࠯࠭ॕ")
	gC2hO80boRyM7TBGqD = gC2hO80boRyM7TBGqD.replace(EDPaWgMt1SwNn8o(u"ࠪࡺࡪࡸࡩࡧࡻࡳࡩࡪࡸ࠽ࡧࡣ࡯ࡷࡪ࠭ॖ"),PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"ࠫࠬॗ"))
	if bdhQDyjm3nPwToFHkprvCzBLUGR(u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵ࠿ࠪक़") in gC2hO80boRyM7TBGqD:
		lQHXdV9Nzf6BLqS8D,k0kUAjI76Erhgf = gC2hO80boRyM7TBGqD.rsplit(c4QSTnPiWUCjhrLlwGB(u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࡀࠫख़"),ZSJVq5XDrRot(u"࠵৸"))
		k0kUAjI76Erhgf = k0kUAjI76Erhgf.replace(pEo8g7riWVL014KaRtzQ(u"ࠧࡽࠩग़"),eeIL1TfgFQJaKqVD8hGNPEZ(u"ࠨࠩज़")).replace(kRYWcNuAazr4jtmBoxFVS19Z6(u"ࠩࠩࠫड़"),c4QSTnPiWUCjhrLlwGB(u"ࠪࠫढ़"))
	else: lQHXdV9Nzf6BLqS8D,k0kUAjI76Erhgf = gC2hO80boRyM7TBGqD,None
	if not k0kUAjI76Erhgf: k0kUAjI76Erhgf = SjMG7CYyUqbPVso0DErhXROvkl()
	if k0kUAjI76Erhgf: Mm7XCRohg3iUSfJKdWsIqx[PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨफ़")] = k0kUAjI76Erhgf
	if LmcNhzY6fQPd2JyCGslkSr(u"ࠬࡘࡥࡧࡧࡵࡩࡷࡃࠧय़") in lQHXdV9Nzf6BLqS8D: lQHXdV9Nzf6BLqS8D,qBKDxcalp4QdXitguWhSHwo2Zy9E = lQHXdV9Nzf6BLqS8D.rsplit(XogUJZEijT7KWbxeO6(u"࠭ࡒࡦࡨࡨࡶࡪࡸ࠽ࠨॠ"),ZSJVq5XDrRot(u"࠶৹"))
	else: lQHXdV9Nzf6BLqS8D,qBKDxcalp4QdXitguWhSHwo2Zy9E = lQHXdV9Nzf6BLqS8D,jYaM5vilgZdFx6QHbApwVXO8et(u"ࠧࠨॡ")
	lQHXdV9Nzf6BLqS8D = lQHXdV9Nzf6BLqS8D.strip(gSmqZU0plur2xKPJwQA(u"ࠨࡾࠪॢ")).strip(FhcnOB9t3frzvXb(u"ࠩࠩࠫॣ")).strip(jYaM5vilgZdFx6QHbApwVXO8et(u"ࠪࢀࠬ।")).strip(sArCMRngQNmXkBoKv(u"ࠫࠫ࠭॥"))
	qBKDxcalp4QdXitguWhSHwo2Zy9E = qBKDxcalp4QdXitguWhSHwo2Zy9E.replace(yTMWeCgUROcvtsblfK85L62xPk(u"ࠬࢂࠧ०"),eeIL1TfgFQJaKqVD8hGNPEZ(u"࠭ࠧ१")).replace(JcDaEHuiS8TqBbOhWe4ZgwknoC1L3r(u"ࠧࠧࠩ२"),sArCMRngQNmXkBoKv(u"ࠨࠩ३"))
	if qBKDxcalp4QdXitguWhSHwo2Zy9E:	Mm7XCRohg3iUSfJKdWsIqx[Ej67fFyoqW8kbV2HdSK(u"ࠩࡕࡩ࡫࡫ࡲࡦࡴࠪ४")] = qBKDxcalp4QdXitguWhSHwo2Zy9E
	tr24ZoudmqvxfYCw(MM2BQ7xrAfNivgenXPytGYOs0DEHRC(u"ࠪࡒࡔ࡚ࡉࡄࡇࠪ५"),RGSFZ7ls3nO(ll6f2wvU4FdqL3MJyDxORESCK197i)+yTMWeCgUROcvtsblfK85L62xPk(u"ࠫࠥࠦࠠࡅࡱࡺࡲࡱࡵࡡࡥ࡫ࡱ࡫ࠥࡼࡩࡥࡧࡲࠤ࡫࡯࡬ࡦࠢࠣࠤ࡚ࡘࡌ࠻ࠢ࡞ࠤࠬ६")+lQHXdV9Nzf6BLqS8D+bdhQDyjm3nPwToFHkprvCzBLUGR(u"ࠬࠦ࡝ࠡࠢࠣࡌࡪࡧࡤࡦࡴࡶ࠾ࠥࡡࠠࠨ७")+str(Mm7XCRohg3iUSfJKdWsIqx)+aVLSn1xw5cK(u"࠭ࠠ࡞ࠢࠣࠤࡋ࡯࡬ࡦ࠼ࠣ࡟ࠥ࠭८")+QQ90mpKANUJ2sZ1DSiHtXLxhEw+pEo8g7riWVL014KaRtzQ(u"ࠧࠡ࡟ࠪ९"))
	y2yDWXiNdze7 = OVmSuf8tpd(u"࠷࠰࠳࠶৺")*OVmSuf8tpd(u"࠷࠰࠳࠶৺")
	cYJVRyu4KnPegp = DLSVmlyBbCK(u"࠰৻")
	try:
		TTglEWX685y =	cPwDBuG4HVTCdQ9JmMeoWjNY2hX.getInfoLabel(FhcnOB9t3frzvXb(u"ࠨࡕࡼࡷࡹ࡫࡭࠯ࡈࡵࡩࡪ࡙ࡰࡢࡥࡨࠫ॰"))
		TTglEWX685y = ZXFs0mEPR8qI2zj.findall(pEo8g7riWVL014KaRtzQ(u"ࠩ࡟ࡨ࠰࠭ॱ"),TTglEWX685y)
		cYJVRyu4KnPegp = int(TTglEWX685y[OVmSuf8tpd(u"࠱ৼ")])
	except: pass
	if not cYJVRyu4KnPegp:
		try:
			CG5N36Z0evkFy2WTsVh9xr = hhHq8m5vauKG9dl.statvfs(QbhVCTMLaWiYp)
			cYJVRyu4KnPegp = CG5N36Z0evkFy2WTsVh9xr.f_frsize*CG5N36Z0evkFy2WTsVh9xr.f_bavail//y2yDWXiNdze7
		except: pass
	if not cYJVRyu4KnPegp:
		try:
			CG5N36Z0evkFy2WTsVh9xr = hhHq8m5vauKG9dl.fstatvfs(QbhVCTMLaWiYp)
			cYJVRyu4KnPegp = CG5N36Z0evkFy2WTsVh9xr.f_frsize*CG5N36Z0evkFy2WTsVh9xr.f_bavail//y2yDWXiNdze7
		except: pass
	if not cYJVRyu4KnPegp:
		try:
			import shutil as DD1NqfjlgVJa2sCK3ncvHei7mEAr
			aS2hsq8FUxkgN9reRot7iZ,ch9kDaMZiIJSdoN3eUrjYv,lunszNcQipFag7XS459jfevwtm = DD1NqfjlgVJa2sCK3ncvHei7mEAr.disk_usage(QbhVCTMLaWiYp)
			cYJVRyu4KnPegp = lunszNcQipFag7XS459jfevwtm//y2yDWXiNdze7
		except: pass
	if not cYJVRyu4KnPegp:
		FD5mbRq2ypcA6QOUE8hG(gnfv8UtZ3daGqpjzk(u"ࠪࡶ࡮࡭ࡨࡵࠩॲ"),aFQoGfmYKyqLU6X8libw9k3ncW5(u"ู๊ࠫวฮหࠣห้ะฮำ์้ࠤ๊า็้ๆฬࠫॳ"),hjNP5w9srJz2QpVISxBfndbD4CkXvl(u"๊ࠬไฤีไࠤฬ๊ศา่ส้ัฺ๋ࠦำࠣๆฬีัࠡล้ࠤ๏ำฯะ่ࠢๆิอัࠡ็ึหาฯࠠศๆอาื๐ๆࠡษ็ๅฬืฺสࠢไ๎ࠥา็ศิๆࠤํ฿ไ๋้ࠣๅฬ์ࠠหฯ่๎้ࠦวๅใํำ๏๎็ศฬฺ่๋๊ࠣࠦ็็ࠤ฾์ฯไࠢศ่๎ࠦร็ࠢํๆํ๋ࠠๆสิ้ั๐ࠠษำ้ห๊าࠠไ๊า๎ࠥฮอๅ๊ࠢิ์ࠦวๅ็ื็้ฯࠠๅษ้ࠤฯำๅ๋ๆࠣห้็๊ะ์๋๋ฬะࠠใัࠣ๎ุฮศࠡษ่ฮ้อมࠡฮ๊หื้ࠠษษ็้้็วห๋๋ࠢีอࠠโ์๊ࠤำ฽่าหࠣ฽้๏ฺࠠ็็ࠤัํวำๅࠣฬฺ๎ัสุࠢั๏ำษ๊ࠡ็๋ีอࠠศๆึฬอࠦโศ็ࠣห้๋ศา็ฯࠤ๊สโหษࠣฬ๊์ูࠡษ็ฬึ์วๆฮ้๋ࠣࠦสฮ็ํ่ࠥอไโ์า๎ํํวหࠩॴ"),bdhQDyjm3nPwToFHkprvCzBLUGR(u"࠭ࡴࡦࡺࡷࡺ࡮࡫ࡷࡠࡤ࡬࡫࡫ࡵ࡮ࡵࠩॵ"))
		tr24ZoudmqvxfYCw(kmdSKeBIwViM9t3(u"ࠧࡆࡔࡕࡓࡗࡥࡌࡊࡐࡈࡗࠬॶ"),RGSFZ7ls3nO(ll6f2wvU4FdqL3MJyDxORESCK197i)+J3OCAmZVcn(u"ࠨࠢࠣࠤ࡚ࡴࡡࡣ࡮ࡨࠤࡹࡵࠠࡥࡧࡷࡩࡷࡳࡩ࡯ࡧࠣࡸ࡭࡫ࠠࡥ࡫ࡶ࡯ࠥ࡬ࡲࡦࡧࠣࡷࡵࡧࡣࡦࠩॷ"))
		return c4QSTnPiWUCjhrLlwGB(u"ࡈࡤࡰࡸ࡫ਠ")
	if n2wpUdA6KX4kLjJGxZWVieycPg==DLSVmlyBbCK(u"ࠩ࠱ࡱ࠸ࡻ࠸ࠨॸ"):
		xCLQK8kh39sjyi5DXSZAVeI,YYmyQXglbEewzL3IA2Sd = c8T0X52CGk9UZ71q(lQHXdV9Nzf6BLqS8D,Mm7XCRohg3iUSfJKdWsIqx)
		if len(xCLQK8kh39sjyi5DXSZAVeI)==LmcNhzY6fQPd2JyCGslkSr(u"࠲৽"):
			NLVM3HAtxQOSvJf6kd78K1o(m6b7CoBk4EQ(u"ࠪๅู๊ࠠโ์ࠣษ๏าวะ่่ࠢๆࠦวๅฬะ้๏๊ࠧॹ"),ZSJVq5XDrRot(u"ࠫࠬॺ"))
			return MM2BQ7xrAfNivgenXPytGYOs0DEHRC(u"ࡉࡥࡱࡹࡥਡ")
		elif len(xCLQK8kh39sjyi5DXSZAVeI)==kRYWcNuAazr4jtmBoxFVS19Z6(u"࠴৾"): jQ6w8xOrgYhSHIRpUqzL = PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"࠴৿")
		elif len(xCLQK8kh39sjyi5DXSZAVeI)>sArCMRngQNmXkBoKv(u"࠶਀"):
			jQ6w8xOrgYhSHIRpUqzL = F2yZPukcUh09sqCI8nYw7e(sArCMRngQNmXkBoKv(u"ࠬอฮหำࠣห้๋ไโࠢส่๊์วิสࠪॻ"), xCLQK8kh39sjyi5DXSZAVeI)
			if jQ6w8xOrgYhSHIRpUqzL == -pEo8g7riWVL014KaRtzQ(u"࠷ਁ") :
				NLVM3HAtxQOSvJf6kd78K1o(ffCSGrTJYPsxgVQWKLtHU3iMwB(u"࠭สๆࠢศ่฿อมࠡษ็ฮา๋๊ๅࠩॼ"),gnfv8UtZ3daGqpjzk(u"ࠧࠨॽ"))
				return xuYvdJpOEyQKTLNwb(u"ࡊࡦࡲࡳࡦਢ")
		lQHXdV9Nzf6BLqS8D = YYmyQXglbEewzL3IA2Sd[jQ6w8xOrgYhSHIRpUqzL]
	X065d1pKyHwrBV7zlcZ = PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"࠰ਂ")
	if n2wpUdA6KX4kLjJGxZWVieycPg==JMLhEyaBWmskovGHTrVCxQ08(u"ࠨ࠰ࡰ࠷ࡺ࠾ࠧॾ"):
		QQ90mpKANUJ2sZ1DSiHtXLxhEw = QQ90mpKANUJ2sZ1DSiHtXLxhEw.rsplit(J3OCAmZVcn(u"ࠩ࠱ࡱ࠸ࡻ࠸ࠨॿ"))[kmdSKeBIwViM9t3(u"࠱ਃ")]+XogUJZEijT7KWbxeO6(u"ࠪ࠲ࡲࡶ࠴ࠨঀ")
		Ba3qhge51Hynsz8mcoW = A6F71g3cqN4(dALVaOWB4jKN3Tbt0Cm1ns9k5u,jYaM5vilgZdFx6QHbApwVXO8et(u"ࠫࡌࡋࡔࠨঁ"),lQHXdV9Nzf6BLqS8D,OVmSuf8tpd(u"ࠬ࠭ং"),Mm7XCRohg3iUSfJKdWsIqx,gSmqZU0plur2xKPJwQA(u"࠭ࠧঃ"),gnfv8UtZ3daGqpjzk(u"ࠧࠨ঄"),xuYvdJpOEyQKTLNwb(u"ࠨࡆࡒ࡛ࡓࡒࡏࡂࡆ࠰ࡈࡔ࡝ࡎࡍࡑࡄࡈࡤ࡜ࡉࡅࡇࡒ࠱࠶ࡹࡴࠨঅ"))
		D1ivbGa6dRqphr7Km3Nl8PQ20Bzs = Ba3qhge51Hynsz8mcoW.content
		R28S4pFmAojEW7CGnx = ZXFs0mEPR8qI2zj.findall(PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"ࠩࠦࡉ࡝࡚ࡉࡏࡈ࠽࠲࠯ࡅ࡛࡝ࡰ࡟ࡶࡢ࠮࠮ࠫࡁࠬ࡟ࡡࡴ࡜ࡳ࡟ࠪআ"),D1ivbGa6dRqphr7Km3Nl8PQ20Bzs+kRYWcNuAazr4jtmBoxFVS19Z6(u"ࠪࡠࡳࡢࡲࠨই"),ZXFs0mEPR8qI2zj.DOTALL)
		if not R28S4pFmAojEW7CGnx:
			tr24ZoudmqvxfYCw(m6b7CoBk4EQ(u"ࠫࡊࡘࡒࡐࡔࡢࡐࡎࡔࡅࡔࠩঈ"),RGSFZ7ls3nO(ll6f2wvU4FdqL3MJyDxORESCK197i)+hjNP5w9srJz2QpVISxBfndbD4CkXvl(u"ࠬࠦࠠࠡࡖ࡫ࡩࠥࡳ࠳ࡶ࠺ࠣࡪ࡮ࡲࡥࠡࡦ࡬ࡨࠥࡴ࡯ࡵࠢ࡫ࡥࡻ࡫ࠠࡵࡪࡨࠤࡷ࡫ࡱࡶ࡫ࡵࡩࡩࠦ࡬ࡪࡰ࡮ࡷࠥࠦࠠࡖࡔࡏ࠾ࠥࡡࠠࠨউ")+lQHXdV9Nzf6BLqS8D+jYaM5vilgZdFx6QHbApwVXO8et(u"࠭ࠠ࡞ࠩঊ"))
			return PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"ࡋࡧ࡬ࡴࡧਣ")
		RRucmYBaXegTtNOdGHMQ = R28S4pFmAojEW7CGnx[J3OCAmZVcn(u"࠲਄")]
		if not RRucmYBaXegTtNOdGHMQ.startswith(PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"ࠧࡩࡶࡷࡴࠬঋ")):
			if RRucmYBaXegTtNOdGHMQ.startswith(c4QSTnPiWUCjhrLlwGB(u"ࠨ࠱࠲ࠫঌ")): RRucmYBaXegTtNOdGHMQ = lQHXdV9Nzf6BLqS8D.split(aVLSn1xw5cK(u"ࠩ࠽ࠫ঍"),LmcNhzY6fQPd2JyCGslkSr(u"࠴ਅ"))[c4QSTnPiWUCjhrLlwGB(u"࠴ਆ")]+jYaM5vilgZdFx6QHbApwVXO8et(u"ࠪ࠾ࠬ঎")+RRucmYBaXegTtNOdGHMQ
			elif RRucmYBaXegTtNOdGHMQ.startswith(MM2BQ7xrAfNivgenXPytGYOs0DEHRC(u"ࠫ࠴࠭এ")): RRucmYBaXegTtNOdGHMQ = d78KRnJmBWscGua0XMk(lQHXdV9Nzf6BLqS8D,DLSVmlyBbCK(u"ࠬࡻࡲ࡭ࠩঐ"))+RRucmYBaXegTtNOdGHMQ
			else: RRucmYBaXegTtNOdGHMQ = lQHXdV9Nzf6BLqS8D.rsplit(gSmqZU0plur2xKPJwQA(u"࠭࠯ࠨ঑"),JMLhEyaBWmskovGHTrVCxQ08(u"࠶ਇ"))[yTMWeCgUROcvtsblfK85L62xPk(u"࠶ਈ")]+aFQoGfmYKyqLU6X8libw9k3ncW5(u"ࠧ࠰ࠩ঒")+RRucmYBaXegTtNOdGHMQ
		Ba3qhge51Hynsz8mcoW = EfD78uCdxyZSO.request(gnfv8UtZ3daGqpjzk(u"ࠨࡉࡈࡘࠬও"),RRucmYBaXegTtNOdGHMQ,headers=Mm7XCRohg3iUSfJKdWsIqx,verify=gnfv8UtZ3daGqpjzk(u"ࡌࡡ࡭ࡵࡨਤ"))
		rlpUmnGBIvX938QO = Ba3qhge51Hynsz8mcoW.content
		vaFmVyOW1icTb8 = len(rlpUmnGBIvX938QO)
		vdiIm5tSoyQBwMCNFr6fJGAz3xp = len(R28S4pFmAojEW7CGnx)
		X065d1pKyHwrBV7zlcZ = vaFmVyOW1icTb8*vdiIm5tSoyQBwMCNFr6fJGAz3xp
	else:
		vaFmVyOW1icTb8 = kmdSKeBIwViM9t3(u"࠱ਉ")*y2yDWXiNdze7
		Ba3qhge51Hynsz8mcoW = EfD78uCdxyZSO.request(XogUJZEijT7KWbxeO6(u"ࠩࡊࡉ࡙࠭ঔ"),lQHXdV9Nzf6BLqS8D,headers=Mm7XCRohg3iUSfJKdWsIqx,verify=hjNP5w9srJz2QpVISxBfndbD4CkXvl(u"ࡇࡣ࡯ࡷࡪਦ"),stream=J3OCAmZVcn(u"ࡔࡳࡷࡨਥ"))
		if JMLhEyaBWmskovGHTrVCxQ08(u"ࠪࡇࡴࡴࡴࡦࡰࡷ࠱ࡑ࡫࡮ࡨࡶ࡫ࠫক") in Ba3qhge51Hynsz8mcoW.headers: X065d1pKyHwrBV7zlcZ = int(Ba3qhge51Hynsz8mcoW.headers[yTMWeCgUROcvtsblfK85L62xPk(u"ࠫࡈࡵ࡮ࡵࡧࡱࡸ࠲ࡒࡥ࡯ࡩࡷ࡬ࠬখ")])
		vdiIm5tSoyQBwMCNFr6fJGAz3xp = int(X065d1pKyHwrBV7zlcZ//vaFmVyOW1icTb8)
	ssqAVJzkogUCnH2P1Tc9BpI0GOx = int(X065d1pKyHwrBV7zlcZ//y2yDWXiNdze7)+yTMWeCgUROcvtsblfK85L62xPk(u"࠲ਊ")
	if X065d1pKyHwrBV7zlcZ<PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"࠴࠴࠴࠵࠶਋"):
		tr24ZoudmqvxfYCw(EDPaWgMt1SwNn8o(u"ࠬࡋࡒࡓࡑࡕࡣࡑࡏࡎࡆࡕࠪগ"),RGSFZ7ls3nO(ll6f2wvU4FdqL3MJyDxORESCK197i)+PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"࡙࠭ࠠࠡࠢ࡭ࡩ࡫࡯ࠡࡨ࡬ࡰࡪࠦࡩࡴࠢࡷࡳࡴࠦࡳ࡮ࡣ࡯ࡰࠥࡵࡲࠡ࡫ࡷࠤ࡮ࡹࠠ࡮࠵ࡸ࠼ࠥࠦࠠࡖࡔࡏ࠾ࠥࡡࠠࠨঘ")+lQHXdV9Nzf6BLqS8D+aFQoGfmYKyqLU6X8libw9k3ncW5(u"ࠧࠡ࡟ࠣࠤࠥ࡜ࡩࡥࡧࡲࠤ࡫࡯࡬ࡦࠢࡶ࡭ࡿ࡫࠺ࠡ࡝ࠣࠫঙ")+str(ssqAVJzkogUCnH2P1Tc9BpI0GOx)+OVmSuf8tpd(u"ࠨࠢࡐࡆࠥࡣࠠࠡࠢࡄࡺࡦ࡯࡬ࡢࡤ࡯ࡩࠥࡹࡩࡻࡧ࠽ࠤࡠࠦࠧচ")+str(cYJVRyu4KnPegp)+hjNP5w9srJz2QpVISxBfndbD4CkXvl(u"ࠩࠣࡑࡇࠦ࡝ࠡࠢࠣࡊ࡮ࡲࡥ࠻ࠢ࡞ࠤࠬছ")+QQ90mpKANUJ2sZ1DSiHtXLxhEw+Ej67fFyoqW8kbV2HdSK(u"ࠪࠤࡢ࠭জ"))
		HHTzVhiY079bvdluNkFQ4wCMpe(MM2BQ7xrAfNivgenXPytGYOs0DEHRC(u"ࠫࠬঝ"),fR68jBGWCzUsFXdlTKPOScugm(u"ࠬ࠭ঞ"),XogUJZEijT7KWbxeO6(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩট"),eeIL1TfgFQJaKqVD8hGNPEZ(u"ࠧโึ็ࠤๆ๐ࠠๆ฻ิๅฮࠦออ็้้ࠣ็ࠠศๆไ๎ิ๐่ࠡล๋ࠤฬ๊ๅๅใูࠣ฿๐ัࠡฮาหࠥ๎ไ่าสࠤ้อ๋ࠠ็ๆ๊๊ࠥไษำ้ห๊าࠠหฯ่๎้ࠦ็ัษࠣห้๋ไโࠩঠ"))
		return c4QSTnPiWUCjhrLlwGB(u"ࡈࡤࡰࡸ࡫ਧ")
	RxV2l30gj94uW1ZiSDAbGC = jYaM5vilgZdFx6QHbApwVXO8et(u"࠷࠴࠵਌")
	mYxiFMyzTZpQPjE = cYJVRyu4KnPegp-ssqAVJzkogUCnH2P1Tc9BpI0GOx
	if mYxiFMyzTZpQPjE<RxV2l30gj94uW1ZiSDAbGC:
		tr24ZoudmqvxfYCw(DLSVmlyBbCK(u"ࠨࡇࡕࡖࡔࡘ࡟ࡍࡋࡑࡉࡘ࠭ড"),RGSFZ7ls3nO(ll6f2wvU4FdqL3MJyDxORESCK197i)+ZSJVq5XDrRot(u"ࠩࠣࠤࠥࡔ࡯ࡵࠢࡨࡲࡴࡻࡧࡩࠢࡧ࡭ࡸࡱࠠࡴࡲࡤࡧࡪࠦࡴࡰࠢࡧࡳࡼࡴ࡬ࡰࡣࡧࠤࡹ࡮ࡥࠡࡸ࡬ࡨࡪࡵࠠࡧ࡫࡯ࡩࠥࠦࠠࡖࡔࡏ࠾ࠥࡡࠠࠨঢ")+lQHXdV9Nzf6BLqS8D+PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"ࠪࠤࡢࠦࠠࠡࡘ࡬ࡨࡪࡵࠠࡧ࡫࡯ࡩࠥࡹࡩࡻࡧ࠽ࠤࡠࠦࠧণ")+str(ssqAVJzkogUCnH2P1Tc9BpI0GOx)+MM2BQ7xrAfNivgenXPytGYOs0DEHRC(u"ࠫࠥࡓࡂࠡ࡟ࠣࠤࠥࡇࡶࡢ࡫࡯ࡥࡧࡲࡥࠡࡵ࡬ࡾࡪࡀࠠ࡜ࠢࠪত")+str(cYJVRyu4KnPegp)+DLSVmlyBbCK(u"ࠬࠦࡍࡃࠢ࠰ࠤࠬথ")+str(RxV2l30gj94uW1ZiSDAbGC)+hjNP5w9srJz2QpVISxBfndbD4CkXvl(u"࠭ࠠࡎࡄࠣࡡࠥࠦࠠࡇ࡫࡯ࡩ࠿࡛ࠦࠡࠩদ")+QQ90mpKANUJ2sZ1DSiHtXLxhEw+ffCSGrTJYPsxgVQWKLtHU3iMwB(u"ࠧࠡ࡟ࠪধ"))
		HHTzVhiY079bvdluNkFQ4wCMpe(gSmqZU0plur2xKPJwQA(u"ࠨࠩন"),bdhQDyjm3nPwToFHkprvCzBLUGR(u"ࠩࠪ঩"),hjNP5w9srJz2QpVISxBfndbD4CkXvl(u"่ࠪฬ๊้ࠦฮาࠤู๊วฮหࠣ็ฬ็๊สࠢ็่ฯำๅ๋ๆࠪপ"),JcDaEHuiS8TqBbOhWe4ZgwknoC1L3r(u"ࠫฬ๊ๅๅใࠣห้๋ืๅ๊หࠤฯำๅ๋ๆ๊ࠤาาๅ่ࠢࠪফ")+str(ssqAVJzkogUCnH2P1Tc9BpI0GOx)+XogUJZEijT7KWbxeO6(u"ࠬࠦๅ๋฼สฬฬ๐ส๊ࠡฯ๋ฬุใࠡใํ๋๋ࠥำศฯฬࠤๆอั฻หࠣࠫব")+str(cYJVRyu4KnPegp)+pEo8g7riWVL014KaRtzQ(u"࠭ࠠๆ์฽หออ๊ห๋่้๋ࠢอศใ฻อࠥ฿ไ๊ࠢ฼้้ࠦฬ่ษี็ࠥฮฯู้่้ࠣอใๅࠢํะอࠦลษไสลࠥ࠭ভ")+str(RxV2l30gj94uW1ZiSDAbGC)+yTMWeCgUROcvtsblfK85L62xPk(u"ࠧࠡ็ํ฾ฬฮว๋ฬࠣๅฬืฺสࠢาหห๋ว๊๊ࠡิฬࠦๅฺ่ส๋ࠥษๆࠡฮ๊หื้ࠠๅษࠣฮําฯࠡใํ๋๋ࠥำศฯฬࠤ่อแ๋ห่ࠣฯำๅ๋ๆ้้ࠣ็ࠠศๆไ๎ิ๐่ࠡษ็้฼๊่ษࠩম"))
		return eeIL1TfgFQJaKqVD8hGNPEZ(u"ࡉࡥࡱࡹࡥਨ")
	YYkEu4IL0sTa = OxCB4medn1(kRYWcNuAazr4jtmBoxFVS19Z6(u"ࠨࡥࡨࡲࡹ࡫ࡲࠨয"),PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"ࠩࠪর"),kRYWcNuAazr4jtmBoxFVS19Z6(u"ࠪࠫ঱"),PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"ࠫ์๊ࠠหำํำࠥะอๆ์็ࠤฬ๊ๅๅใࠣรࠬল"),gSmqZU0plur2xKPJwQA(u"ࠬอไๆๆไࠤฬ๊ๅุๆ๋ฬࠥำฬๆ้ࠣฮ็ื๊ษษࠣࠫ঳")+str(ssqAVJzkogUCnH2P1Tc9BpI0GOx)+gSmqZU0plur2xKPJwQA(u"࠭ࠠๆ์฽หออ๊ห๋ࠢะ์อาไࠢไ๎์ࠦๅิษะอࠥ็วา฼ฬࠤฯ่ั๋สสࠤࠬ঴")+str(cYJVRyu4KnPegp)+aFQoGfmYKyqLU6X8libw9k3ncW5(u"ࠧࠡ็ํ฾ฬฮว๋ฬࠣ์์ึวࠡษ็้้็ࠠใัࠣ๎าะวอࠢห฽฻ࠦวๅ๊ๅฮ๊ࠥไหฯ่๎้ࠦๅ็ࠢส่ส์สา่อࠤส๊้ࠡฮ๊หื้ࠠ࠯๊่ࠢࠥอๆห่ࠢฮศ้ฯ๊ࠡอี๏ีࠠศๆสืฯ๋ัศำࠣฬฯำๅ๋ๆ้้ࠣ็ࠠศๆไ๎ิ๐่ࠡมࠪ঵"))
	if YYkEu4IL0sTa!=eeIL1TfgFQJaKqVD8hGNPEZ(u"࠵਍"):
		HHTzVhiY079bvdluNkFQ4wCMpe(JMLhEyaBWmskovGHTrVCxQ08(u"ࠨࠩশ"),gSmqZU0plur2xKPJwQA(u"ࠩࠪষ"),JMLhEyaBWmskovGHTrVCxQ08(u"ࠪࠫস"),wwyUWMFAsO(u"ࠫฯ๋ࠠฦๆ฽หฦูࠦๆๆํอࠥะอๆ์็ࠤ๊๊แࠡษ็ๅ๏ี๊้ࠩহ"))
		tr24ZoudmqvxfYCw(xuYvdJpOEyQKTLNwb(u"ࠬࡔࡏࡕࡋࡆࡉࠬ঺"),RGSFZ7ls3nO(ll6f2wvU4FdqL3MJyDxORESCK197i)+OVmSuf8tpd(u"࠭ࠠࠡࠢࡘࡷࡪࡸࠠࡤࡣࡱࡧࡪࡲࡥࡥࠢࡷ࡬ࡪࠦࡤࡰࡹࡱࡰࡴࡧࡤࠡࡱࡩࠤࡹ࡮ࡥࠡࡸ࡬ࡨࡪࡵࠠࡧ࡫࡯ࡩࠥࠦࠠࡖࡔࡏ࠾ࠥࡡࠠࠨ঻")+lQHXdV9Nzf6BLqS8D+eeIL1TfgFQJaKqVD8hGNPEZ(u"ࠧࠡ࡟ࠣࠤࠥࡌࡩ࡭ࡧ࠽ࠤࡠ়ࠦࠧ")+QQ90mpKANUJ2sZ1DSiHtXLxhEw+eeIL1TfgFQJaKqVD8hGNPEZ(u"ࠨࠢࡠࠫঽ"))
		return FhcnOB9t3frzvXb(u"ࡊࡦࡲࡳࡦ਩")
	tr24ZoudmqvxfYCw(ffCSGrTJYPsxgVQWKLtHU3iMwB(u"ࠩࡑࡓ࡙ࡏࡃࡆࠩা"),RGSFZ7ls3nO(ll6f2wvU4FdqL3MJyDxORESCK197i)+xuYvdJpOEyQKTLNwb(u"ࠪࠤࠥࠦࡄࡰࡹࡱࡰࡴࡧࡤࠡࡵࡷࡥࡷࡺࡥࡥࠢࡶࡹࡨࡩࡥࡴࡵࡩࡹࡱࡲࡹࠨি"))
	EEA7qzwV381eifP = a6Nd4etSry0P1W()
	EEA7qzwV381eifP.create(QQ90mpKANUJ2sZ1DSiHtXLxhEw,aVLSn1xw5cK(u"ࠫฬ๊ำุำࠣๅํ่่๊้่ࠠࠣอๆࠡฬัึ๏์ࠠๆๆไࠤฬ๊แ๋ัํ์ࠬী"))
	P3kmhMuD5iVaJEYT = pEo8g7riWVL014KaRtzQ(u"࡙ࡸࡵࡦਪ")
	BkeMNv4iXH3 = luMHeSgCBaPrb9KvUjNFqcR.time()
	if VYMZsxRpcQHPgkaiDKjyoh: Rt4WbmOnQpL = open(QQ90mpKANUJ2sZ1DSiHtXLxhEw,MM2BQ7xrAfNivgenXPytGYOs0DEHRC(u"ࠬࡽࡢࠨু"))
	else: Rt4WbmOnQpL = open(QQ90mpKANUJ2sZ1DSiHtXLxhEw.decode(wwyUWMFAsO(u"࠭ࡵࡵࡨ࠻ࠫূ")),jYaM5vilgZdFx6QHbApwVXO8et(u"ࠧࡸࡤࠪৃ"))
	if n2wpUdA6KX4kLjJGxZWVieycPg==ffCSGrTJYPsxgVQWKLtHU3iMwB(u"ࠨ࠰ࡰ࠷ࡺ࠾ࠧৄ"):
		for OeT2Jo0sp6h1mGdqfFw in range(yTMWeCgUROcvtsblfK85L62xPk(u"࠶਎"),vdiIm5tSoyQBwMCNFr6fJGAz3xp+yTMWeCgUROcvtsblfK85L62xPk(u"࠶਎")):
			RRucmYBaXegTtNOdGHMQ = R28S4pFmAojEW7CGnx[OeT2Jo0sp6h1mGdqfFw-aVLSn1xw5cK(u"࠷ਏ")]
			if not RRucmYBaXegTtNOdGHMQ.startswith(wwyUWMFAsO(u"ࠩ࡫ࡸࡹࡶࠧ৅")):
				if RRucmYBaXegTtNOdGHMQ.startswith(yTMWeCgUROcvtsblfK85L62xPk(u"ࠪ࠳࠴࠭৆")): RRucmYBaXegTtNOdGHMQ = lQHXdV9Nzf6BLqS8D.split(EDPaWgMt1SwNn8o(u"ࠫ࠿࠭ে"),aFQoGfmYKyqLU6X8libw9k3ncW5(u"࠱ਐ"))[ffCSGrTJYPsxgVQWKLtHU3iMwB(u"࠱਑")]+gSmqZU0plur2xKPJwQA(u"ࠬࡀࠧৈ")+RRucmYBaXegTtNOdGHMQ
				elif RRucmYBaXegTtNOdGHMQ.startswith(gSmqZU0plur2xKPJwQA(u"࠭࠯ࠨ৉")): RRucmYBaXegTtNOdGHMQ = d78KRnJmBWscGua0XMk(lQHXdV9Nzf6BLqS8D,sArCMRngQNmXkBoKv(u"ࠧࡶࡴ࡯ࠫ৊"))+RRucmYBaXegTtNOdGHMQ
				else: RRucmYBaXegTtNOdGHMQ = lQHXdV9Nzf6BLqS8D.rsplit(yTMWeCgUROcvtsblfK85L62xPk(u"ࠨ࠱ࠪো"),EDPaWgMt1SwNn8o(u"࠳਒"))[kRYWcNuAazr4jtmBoxFVS19Z6(u"࠳ਓ")]+JcDaEHuiS8TqBbOhWe4ZgwknoC1L3r(u"ࠩ࠲ࠫৌ")+RRucmYBaXegTtNOdGHMQ
			Ba3qhge51Hynsz8mcoW = EfD78uCdxyZSO.request(ZSJVq5XDrRot(u"ࠪࡋࡊ্࡚ࠧ"),RRucmYBaXegTtNOdGHMQ,headers=Mm7XCRohg3iUSfJKdWsIqx,verify=FhcnOB9t3frzvXb(u"ࡌࡡ࡭ࡵࡨਫ"))
			rlpUmnGBIvX938QO = Ba3qhge51Hynsz8mcoW.content
			Ba3qhge51Hynsz8mcoW.close()
			Rt4WbmOnQpL.write(rlpUmnGBIvX938QO)
			lwf2tjLc6WER5pY91HVTKya8MU = luMHeSgCBaPrb9KvUjNFqcR.time()
			MMYxZjmADtWqgSeE5zPBQ = lwf2tjLc6WER5pY91HVTKya8MU-BkeMNv4iXH3
			YYKwe9IghiB2DCrfHTvsLOdqaF = MMYxZjmADtWqgSeE5zPBQ//OeT2Jo0sp6h1mGdqfFw
			N5NJ9CrcVBWGsgSYDAjZQqbO = YYKwe9IghiB2DCrfHTvsLOdqaF*(vdiIm5tSoyQBwMCNFr6fJGAz3xp+yTMWeCgUROcvtsblfK85L62xPk(u"࠵ਔ"))
			IIeD1fgQNWUpk6n8q3LVcwuPd9 = N5NJ9CrcVBWGsgSYDAjZQqbO-MMYxZjmADtWqgSeE5zPBQ
			b8bEl0XjyR4hACKcYkJVP2oBavnGm1(EEA7qzwV381eifP,int(DLSVmlyBbCK(u"࠷࠰࠱ਖ")*OeT2Jo0sp6h1mGdqfFw//(vdiIm5tSoyQBwMCNFr6fJGAz3xp+kmdSKeBIwViM9t3(u"࠶ਕ"))),AAgpHN0nMZ(u"ࠫฬ๊ำุำࠣๅํ่่๊้่ࠠࠣอๆࠡฬัึ๏์ࠠๆๆไࠤฬ๊แ๋ัํ์ࠬৎ"),xuYvdJpOEyQKTLNwb(u"ࠬาไษ่่ࠢๆࠦวๅใํำ๏๎࠺࠮ࠢส่ัุมࠡำๅ้ࠬ৏"),str(OeT2Jo0sp6h1mGdqfFw*vaFmVyOW1icTb8//y2yDWXiNdze7)+sArCMRngQNmXkBoKv(u"࠭࠯ࠨ৐")+str(ssqAVJzkogUCnH2P1Tc9BpI0GOx)+m6b7CoBk4EQ(u"ࠧࠡࡏࡅࠤ้ࠥࠦࠠไอࠤ๊ะศใ์࠽ࠤࠬ৑")+luMHeSgCBaPrb9KvUjNFqcR.strftime(wwyUWMFAsO(u"ࠣࠧࡋ࠾ࠪࡓ࠺ࠦࡕࠥ৒"),luMHeSgCBaPrb9KvUjNFqcR.gmtime(IIeD1fgQNWUpk6n8q3LVcwuPd9))+yTMWeCgUROcvtsblfK85L62xPk(u"ࠩࠣไࠬ৓"))
			if EEA7qzwV381eifP.iscanceled():
				P3kmhMuD5iVaJEYT = xuYvdJpOEyQKTLNwb(u"ࡆࡢ࡮ࡶࡩਬ")
				break
	else:
		OeT2Jo0sp6h1mGdqfFw = AAgpHN0nMZ(u"࠰ਗ")
		for rlpUmnGBIvX938QO in Ba3qhge51Hynsz8mcoW.iter_content(chunk_size=vaFmVyOW1icTb8):
			Rt4WbmOnQpL.write(rlpUmnGBIvX938QO)
			OeT2Jo0sp6h1mGdqfFw = OeT2Jo0sp6h1mGdqfFw+MM2BQ7xrAfNivgenXPytGYOs0DEHRC(u"࠲ਘ")
			lwf2tjLc6WER5pY91HVTKya8MU = luMHeSgCBaPrb9KvUjNFqcR.time()
			MMYxZjmADtWqgSeE5zPBQ = lwf2tjLc6WER5pY91HVTKya8MU-BkeMNv4iXH3
			YYKwe9IghiB2DCrfHTvsLOdqaF = MMYxZjmADtWqgSeE5zPBQ/OeT2Jo0sp6h1mGdqfFw
			N5NJ9CrcVBWGsgSYDAjZQqbO = YYKwe9IghiB2DCrfHTvsLOdqaF*(vdiIm5tSoyQBwMCNFr6fJGAz3xp+pEo8g7riWVL014KaRtzQ(u"࠳ਙ"))
			IIeD1fgQNWUpk6n8q3LVcwuPd9 = N5NJ9CrcVBWGsgSYDAjZQqbO-MMYxZjmADtWqgSeE5zPBQ
			b8bEl0XjyR4hACKcYkJVP2oBavnGm1(EEA7qzwV381eifP,int(wwyUWMFAsO(u"࠵࠵࠶ਛ")*OeT2Jo0sp6h1mGdqfFw/(vdiIm5tSoyQBwMCNFr6fJGAz3xp+gnfv8UtZ3daGqpjzk(u"࠴ਚ"))),sArCMRngQNmXkBoKv(u"ࠪหู้ืาࠢไ์็ࠦ็้่ࠢ็ฬ์ࠠหะี๎๋ࠦๅๅใࠣห้็๊ะ์๋ࠫ৔"),ffCSGrTJYPsxgVQWKLtHU3iMwB(u"ࠫั๊ศࠡ็็ๅࠥอไโ์า๎ํࡀ࠭ࠡษ็ะืวࠠาไ่ࠫ৕"),str(OeT2Jo0sp6h1mGdqfFw*vaFmVyOW1icTb8//y2yDWXiNdze7)+JcDaEHuiS8TqBbOhWe4ZgwknoC1L3r(u"ࠬ࠵ࠧ৖")+str(ssqAVJzkogUCnH2P1Tc9BpI0GOx)+bdhQDyjm3nPwToFHkprvCzBLUGR(u"࠭ࠠࡎࡄࠣࠤ่ࠥࠦใฬ้ࠣฯฮโ๋࠼ࠣࠫৗ")+luMHeSgCBaPrb9KvUjNFqcR.strftime(ZSJVq5XDrRot(u"ࠢࠦࡊ࠽ࠩࡒࡀࠥࡔࠤ৘"),luMHeSgCBaPrb9KvUjNFqcR.gmtime(IIeD1fgQNWUpk6n8q3LVcwuPd9))+gSmqZU0plur2xKPJwQA(u"ࠨࠢใࠫ৙"))
			if EEA7qzwV381eifP.iscanceled():
				P3kmhMuD5iVaJEYT = bdhQDyjm3nPwToFHkprvCzBLUGR(u"ࡇࡣ࡯ࡷࡪਭ")
				break
		Ba3qhge51Hynsz8mcoW.close()
	Rt4WbmOnQpL.close()
	EEA7qzwV381eifP.close()
	if not P3kmhMuD5iVaJEYT:
		tr24ZoudmqvxfYCw(J3OCAmZVcn(u"ࠩࡑࡓ࡙ࡏࡃࡆࠩ৚"),RGSFZ7ls3nO(ll6f2wvU4FdqL3MJyDxORESCK197i)+bdhQDyjm3nPwToFHkprvCzBLUGR(u"ࠪࠤࠥࠦࡕࡴࡧࡵࠤࡨࡧ࡮ࡤࡧ࡯ࡩࡩ࠵ࡩ࡯ࡶࡨࡶࡷࡻࡰࡵࡧࡧࠤࡹ࡮ࡥࠡࡦࡲࡻࡳࡲ࡯ࡢࡦࠣࡴࡷࡵࡣࡦࡵࡶࠤࠥࠦࡕࡓࡎ࠽ࠤࡠࠦࠧ৛")+lQHXdV9Nzf6BLqS8D+Ej67fFyoqW8kbV2HdSK(u"ࠫࠥࡣࠠࠡࠢࡉ࡭ࡱ࡫࠺ࠡ࡝ࠣࠫড়")+QQ90mpKANUJ2sZ1DSiHtXLxhEw+Ej67fFyoqW8kbV2HdSK(u"ࠬࠦ࡝ࠨঢ়"))
		HHTzVhiY079bvdluNkFQ4wCMpe(c4QSTnPiWUCjhrLlwGB(u"࠭ࠧ৞"),EDPaWgMt1SwNn8o(u"ࠧࠨয়"),aFQoGfmYKyqLU6X8libw9k3ncW5(u"ࠨࠩৠ"),XogUJZEijT7KWbxeO6(u"ࠩอ้ࠥหไ฻ษฤࠤ฾๋ไ๋หࠣฮา๋๊ๅ่่ࠢๆࠦวๅใํำ๏๎ࠧৡ"))
		return aVLSn1xw5cK(u"ࡖࡵࡹࡪਮ")
	tr24ZoudmqvxfYCw(bdhQDyjm3nPwToFHkprvCzBLUGR(u"ࠪࡒࡔ࡚ࡉࡄࡇࠪৢ"),RGSFZ7ls3nO(ll6f2wvU4FdqL3MJyDxORESCK197i)+EDPaWgMt1SwNn8o(u"ࠫࠥࠦࠠࡗ࡫ࡧࡩࡴࠦࡦࡪ࡮ࡨࠤࡩࡵࡷ࡯࡮ࡲࡥࡩ࡫ࡤࠡࡵࡸࡧࡨ࡫ࡳࡴࡨࡸࡰࡱࡿࠠࠡࠢࡘࡖࡑࡀࠠ࡜ࠢࠪৣ")+lQHXdV9Nzf6BLqS8D+ffCSGrTJYPsxgVQWKLtHU3iMwB(u"ࠬࠦ࡝ࠡࠢࠣࡊ࡮ࡲࡥ࠻ࠢ࡞ࠤࠬ৤")+QQ90mpKANUJ2sZ1DSiHtXLxhEw+AAgpHN0nMZ(u"࠭ࠠ࡞ࠩ৥"))
	HHTzVhiY079bvdluNkFQ4wCMpe(pEo8g7riWVL014KaRtzQ(u"ࠧࠨ০"),AAgpHN0nMZ(u"ࠨࠩ১"),J3OCAmZVcn(u"ࠩࠪ২"),kRYWcNuAazr4jtmBoxFVS19Z6(u"ࠪฮ๊ࠦสฮ็ํ่๋ࠥไโࠢส่ๆ๐ฯ๋๊ࠣฬ๋าวฮࠩ৩"))
	return EDPaWgMt1SwNn8o(u"ࡗࡶࡺ࡫ਯ")