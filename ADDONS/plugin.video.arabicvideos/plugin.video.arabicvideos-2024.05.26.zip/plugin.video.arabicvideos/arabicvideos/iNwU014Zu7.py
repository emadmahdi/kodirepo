# -*- coding: utf-8 -*-
from j3x780FpaM import *
ll6f2wvU4FdqL3MJyDxORESCK197i = 'CIMANOW'
W74fAyGxODoLPs5vMX2l8C93R = '_CMN_'
JJTrn6SEtYZV31eyR97 = uReHcEzxkTm6pN4Q[ll6f2wvU4FdqL3MJyDxORESCK197i][0]
SmgoEYJ7uyL = ['قائمتي']
def OVQIAezo6U1NSTl4L(mode,url,text):
	if   mode==300: HkKfQCS7RIa4xi3houjvl = oMUN5hPpTkxVZG12Qiva8BKnyw6()
	elif mode==301: HkKfQCS7RIa4xi3houjvl = yPzYJU5Wup8(url)
	elif mode==302: HkKfQCS7RIa4xi3houjvl = RxAy5lEFQ1chv0BrdU4p6Pt2(url)
	elif mode==303: HkKfQCS7RIa4xi3houjvl = ix3SPh5KmdgfFrtHRk4QqwInAlC8(url)
	elif mode==304: HkKfQCS7RIa4xi3houjvl = pqx0gStI9ojGFP2rWhwRfkVCNX(url)
	elif mode==305: HkKfQCS7RIa4xi3houjvl = jXYwiO9D056pkrzRh1y8tfWJxQoaI3(url)
	elif mode==306: HkKfQCS7RIa4xi3houjvl = O3KdfC9gol7()
	elif mode==309: HkKfQCS7RIa4xi3houjvl = F6OgHwYPRiX10tJEv8r(text)
	else: HkKfQCS7RIa4xi3houjvl = False
	return HkKfQCS7RIa4xi3houjvl
def oMUN5hPpTkxVZG12Qiva8BKnyw6():
	Tca7NsYPkIRWtBpFgxLZbSmCi('link',W74fAyGxODoLPs5vMX2l8C93R+'لماذا الموقع بطيء','',306)
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+'بحث في الموقع','',309,'','','_REMEMBERRESULTS_')
	Tca7NsYPkIRWtBpFgxLZbSmCi('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	wpFmEA3z8JR = A6F71g3cqN4(JNsoWV1CXc4xy,'GET',JJTrn6SEtYZV31eyR97+'/home','','','','','CIMANOW-MENU-1st')
	QstumvzTIEUMXCcx06aD4y8nSqH = wpFmEA3z8JR.content
	IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('<header>(.*?)</header>',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	bdq4e6Wr2gslnSiA38 = IZGcQbePXxwAoyYR1n[0]
	items = ZXFs0mEPR8qI2zj.findall('<li><a href="(.*?)">(.*?)<',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
	for RRucmYBaXegTtNOdGHMQ,title in items:
		title = title.strip(' ')
		if not any(AARNPWHjQU9dEmDI in title for AARNPWHjQU9dEmDI in SmgoEYJ7uyL):
			Tca7NsYPkIRWtBpFgxLZbSmCi('folder',ll6f2wvU4FdqL3MJyDxORESCK197i+'_SCRIPT_'+W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,301)
	Tca7NsYPkIRWtBpFgxLZbSmCi('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	yPzYJU5Wup8(JJTrn6SEtYZV31eyR97+'/home',QstumvzTIEUMXCcx06aD4y8nSqH)
	return QstumvzTIEUMXCcx06aD4y8nSqH
def O3KdfC9gol7():
	HHTzVhiY079bvdluNkFQ4wCMpe('','','رسالة من المبرمج','موقع سيما ناو بطيء من المصدر .. بسبب قيام أصحاب الموقع بتشفير محتويات جميع صفحات الموقع .. والوقت الضائع يذهب في معالجة تشفير الصفحات المشفرة قبل عرض محتوياتها في قوائم هذا البرنامج')
	return
def yPzYJU5Wup8(url,QstumvzTIEUMXCcx06aD4y8nSqH=''):
	if not QstumvzTIEUMXCcx06aD4y8nSqH:
		wpFmEA3z8JR = A6F71g3cqN4(JNsoWV1CXc4xy,'GET',url,'','','','','CIMANOW-SUBMENU-1st')
		QstumvzTIEUMXCcx06aD4y8nSqH = wpFmEA3z8JR.content
	bznBHAX7xt6 = 0
	IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('(<section>.*?</section>)',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	if IZGcQbePXxwAoyYR1n:
		for bdq4e6Wr2gslnSiA38 in IZGcQbePXxwAoyYR1n:
			bznBHAX7xt6 += 1
			items = ZXFs0mEPR8qI2zj.findall('<section>.<span>(.*?)<(.*?)href="(.*?)"',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
			for title,qZWDsejhyE0nmf,RRucmYBaXegTtNOdGHMQ in items:
				title = title.strip(' ')
				if title=='': title = 'بووووو'
				if 'em><a' not in qZWDsejhyE0nmf:
					if bdq4e6Wr2gslnSiA38.count('/category/')>0:
						r61opKn9hFObkY = ZXFs0mEPR8qI2zj.findall('href="(.*?)"',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
						for RRucmYBaXegTtNOdGHMQ in r61opKn9hFObkY:
							title = RRucmYBaXegTtNOdGHMQ.split('/')[-2]
							Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,301)
						continue
					else: RRucmYBaXegTtNOdGHMQ = url+'?sequence='+str(bznBHAX7xt6)
				if not any(AARNPWHjQU9dEmDI in title for AARNPWHjQU9dEmDI in SmgoEYJ7uyL):
					Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,302)
	else: RxAy5lEFQ1chv0BrdU4p6Pt2(url,QstumvzTIEUMXCcx06aD4y8nSqH)
	return
def RxAy5lEFQ1chv0BrdU4p6Pt2(url,QstumvzTIEUMXCcx06aD4y8nSqH=''):
	if QstumvzTIEUMXCcx06aD4y8nSqH=='':
		wpFmEA3z8JR = A6F71g3cqN4(Z7uFdWIRv9ybj0,'GET',url,'','','','','CIMANOW-TITLES-1st')
		QstumvzTIEUMXCcx06aD4y8nSqH = wpFmEA3z8JR.content
	if '?sequence=' in url:
		url,bznBHAX7xt6 = url.split('?sequence=')
		IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('(<section>.*?</section>)',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
		bdq4e6Wr2gslnSiA38 = IZGcQbePXxwAoyYR1n[int(bznBHAX7xt6)-1]
	else:
		IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('"posts"(.*?)</body>',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
		bdq4e6Wr2gslnSiA38 = IZGcQbePXxwAoyYR1n[0]
	items = ZXFs0mEPR8qI2zj.findall('<a.*?href="(.*?)"(.*?)data-src="(.*?)"',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
	FF1TYf6O5KENr8R72LUVievClmudxD = []
	for RRucmYBaXegTtNOdGHMQ,data,CrGO63LT7j2UxniW in items:
		title = ZXFs0mEPR8qI2zj.findall('<em>(.*?)</em>(.*?)</li>.*?</em>(.*?)<em>',data,ZXFs0mEPR8qI2zj.DOTALL)
		if title: title = title[0][2].replace('\n','').strip(' ')
		if not title or title=='':
			title = ZXFs0mEPR8qI2zj.findall('title">.*?</em>(.*?)<',data,ZXFs0mEPR8qI2zj.DOTALL)
			if title: title = title[0].replace('\n','').strip(' ')
			if not title or title=='':
				title = ZXFs0mEPR8qI2zj.findall('title">(.*?)<',data,ZXFs0mEPR8qI2zj.DOTALL)
				title = title[0].replace('\n','').strip(' ')
		title = qpob7TvxHSs4fEzO6(title)
		title = title.replace('  ',' ')
		if title not in FF1TYf6O5KENr8R72LUVievClmudxD:
			FF1TYf6O5KENr8R72LUVievClmudxD.append(title)
			i9jtofq4JrV = RRucmYBaXegTtNOdGHMQ+data+CrGO63LT7j2UxniW
			if '/selary/' in i9jtofq4JrV or 'مسلسل' in i9jtofq4JrV or '"episode"' in i9jtofq4JrV:
				if 'برامج' in data: title = 'برنامج '+title
				elif 'مسلسل' in data or 'موسم' in data: title = 'مسلسل '+title
				Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,303,CrGO63LT7j2UxniW)
			else: Tca7NsYPkIRWtBpFgxLZbSmCi('video',W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,305,CrGO63LT7j2UxniW)
	IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('"pagination"(.*?)</div>',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	if IZGcQbePXxwAoyYR1n:
		bdq4e6Wr2gslnSiA38 = IZGcQbePXxwAoyYR1n[0]
		items = ZXFs0mEPR8qI2zj.findall('<li><a href="(.*?)">(.*?)<',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
		for RRucmYBaXegTtNOdGHMQ,title in items:
			Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+'صفحة '+title,RRucmYBaXegTtNOdGHMQ,302)
	return
def ix3SPh5KmdgfFrtHRk4QqwInAlC8(url):
	wpFmEA3z8JR = A6F71g3cqN4(Z7uFdWIRv9ybj0,'GET',url,'','','','','CIMANOW-SEASONS-1st')
	QstumvzTIEUMXCcx06aD4y8nSqH = wpFmEA3z8JR.content
	name = ZXFs0mEPR8qI2zj.findall('<title>(.*?)</title>',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	name = name[0].replace('| سيما ناو','').replace('Cima Now','').strip(' ').replace('  ',' ')
	name = name.split('الحلقة')[0].strip(' ')
	IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('<section(.*?)</section>',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	if IZGcQbePXxwAoyYR1n:
		bdq4e6Wr2gslnSiA38 = IZGcQbePXxwAoyYR1n[0]
		items = ZXFs0mEPR8qI2zj.findall('href="(.*?)">(.*?)<',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
		if len(items)>1:
			for RRucmYBaXegTtNOdGHMQ,title in items:
				title = name+' - '+title.replace('\n','').strip(' ')
				Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,304)
		else: pqx0gStI9ojGFP2rWhwRfkVCNX(url)
	return
def pqx0gStI9ojGFP2rWhwRfkVCNX(url):
	if '/selary/' not in url: url = url.strip('/')+'/watching'
	wpFmEA3z8JR = A6F71g3cqN4(Z7uFdWIRv9ybj0,'GET',url,'','','','','CIMANOW-EPISODES-1st')
	QstumvzTIEUMXCcx06aD4y8nSqH = wpFmEA3z8JR.content
	if '/selary/' not in url:
		IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('"episodes"(.*?)</ul>',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
		bdq4e6Wr2gslnSiA38 = IZGcQbePXxwAoyYR1n[0]
		items = ZXFs0mEPR8qI2zj.findall('href="(.*?)">(.*?)</a>',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
		for RRucmYBaXegTtNOdGHMQ,title in items:
			title = title.replace('\n','').strip(' ')
			title = 'الحلقة '+title
			Tca7NsYPkIRWtBpFgxLZbSmCi('video',W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,305)
	else:
		IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('"details"(.*?)"related"',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
		bdq4e6Wr2gslnSiA38 = IZGcQbePXxwAoyYR1n[0]
		items = ZXFs0mEPR8qI2zj.findall('href="(.*?)".*?src=.*?src="(.*?)".*?alt="(.*?)"',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
		for RRucmYBaXegTtNOdGHMQ,CrGO63LT7j2UxniW,title in items:
			title = title.replace('\n','').strip(' ')
			Tca7NsYPkIRWtBpFgxLZbSmCi('video',W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,305,CrGO63LT7j2UxniW)
	return
def jXYwiO9D056pkrzRh1y8tfWJxQoaI3(url):
	lQHXdV9Nzf6BLqS8D = url+'watching/'
	wpFmEA3z8JR = A6F71g3cqN4(dALVaOWB4jKN3Tbt0Cm1ns9k5u,'GET',lQHXdV9Nzf6BLqS8D,'','','','','CIMANOW-PLAY-5th')
	QstumvzTIEUMXCcx06aD4y8nSqH = wpFmEA3z8JR.content
	YYmyQXglbEewzL3IA2Sd = []
	IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('"download"(.*?)</ul>',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	if IZGcQbePXxwAoyYR1n:
		bdq4e6Wr2gslnSiA38 = IZGcQbePXxwAoyYR1n[0]
		items = ZXFs0mEPR8qI2zj.findall('href="(.*?)".*?</i>(.*?)</a>',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
		for RRucmYBaXegTtNOdGHMQ,title in items:
			title = title.replace('\n','').strip(' ')
			PHUqTNVJ0ErRSwibn5gD = ZXFs0mEPR8qI2zj.findall('\d\d\d+',title,ZXFs0mEPR8qI2zj.DOTALL)
			if PHUqTNVJ0ErRSwibn5gD:
				PHUqTNVJ0ErRSwibn5gD = '____'+PHUqTNVJ0ErRSwibn5gD[0]
				title = d78KRnJmBWscGua0XMk(RRucmYBaXegTtNOdGHMQ,'name')
			else: PHUqTNVJ0ErRSwibn5gD = ''
			oKqQr8Ij0btxZ9SDm6h3Nd = RRucmYBaXegTtNOdGHMQ+'?named='+title+'__download'+PHUqTNVJ0ErRSwibn5gD
			YYmyQXglbEewzL3IA2Sd.append(oKqQr8Ij0btxZ9SDm6h3Nd)
	IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('"watch"(.*?)</ul>',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	if IZGcQbePXxwAoyYR1n:
		bdq4e6Wr2gslnSiA38 = IZGcQbePXxwAoyYR1n[0]
		R28S4pFmAojEW7CGnx = ZXFs0mEPR8qI2zj.findall('"embed".*?src="(.*?)"',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
		for RRucmYBaXegTtNOdGHMQ in R28S4pFmAojEW7CGnx:
			if 'http' not in RRucmYBaXegTtNOdGHMQ: RRucmYBaXegTtNOdGHMQ = 'http:'+RRucmYBaXegTtNOdGHMQ
			title = d78KRnJmBWscGua0XMk(RRucmYBaXegTtNOdGHMQ,'name')
			RRucmYBaXegTtNOdGHMQ = RRucmYBaXegTtNOdGHMQ+'?named='+title+'__embed'
			YYmyQXglbEewzL3IA2Sd.append(RRucmYBaXegTtNOdGHMQ)
		R28S4pFmAojEW7CGnx = [JJTrn6SEtYZV31eyR97+'/wp-content/themes/Cima%20Now%20New/core.php']
		if R28S4pFmAojEW7CGnx:
			items = ZXFs0mEPR8qI2zj.findall('data-index="(.*?)".*?data-id="(.*?)".*?>(.*?)</li>',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
			for LcnYtXvRpST3U,id,title in items:
				title = title.replace('\n','').strip(' ')
				RRucmYBaXegTtNOdGHMQ = R28S4pFmAojEW7CGnx[0]+'?action=switch&index='+LcnYtXvRpST3U+'&id='+id+'?named='+title+'__watch'
				YYmyQXglbEewzL3IA2Sd.append(RRucmYBaXegTtNOdGHMQ)
	import fnxsZbk2Fm
	fnxsZbk2Fm.n2h4SBIzxbgJD3K7rtVej01EuGcHPs(YYmyQXglbEewzL3IA2Sd,ll6f2wvU4FdqL3MJyDxORESCK197i,'video',url)
	return
def F6OgHwYPRiX10tJEv8r(search):
	search,Y9RKmgsxBefkFcuIj2GULDHy3,showDialogs = XDzpr8RxgZhT(search)
	if search=='': search = CjyEnpfQ23o0PYwDtLId()
	if search=='': return
	search = search.replace(' ','+')
	url = JJTrn6SEtYZV31eyR97 + '/?s='+search
	RxAy5lEFQ1chv0BrdU4p6Pt2(url)
	return