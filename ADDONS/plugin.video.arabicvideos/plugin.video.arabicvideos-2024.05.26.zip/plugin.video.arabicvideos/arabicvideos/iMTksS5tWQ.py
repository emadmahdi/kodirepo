# -*- coding: utf-8 -*-
from j3x780FpaM import *
from PIL import ImageDraw as ppq7nbP8zdkSt20aCVK3rY9,ImageFont as zIdYyOpmXEar2RLH,Image as MfgOeR2YHEWhp
from arabic_reshaper import ArabicReshaper as r2GOwLkB5Wmasb6EhogVCt1
LBtjHDg8yZz69QOp = 'EXCLUDES'
def oo1atgXlfxmTB2GA(aaYDh2EzJ5ky,hjTtuHAF3UPKfQSXEJ47pL0an):
	hjTtuHAF3UPKfQSXEJ47pL0an = hjTtuHAF3UPKfQSXEJ47pL0an.replace('[COLOR FFC89008]','').replace(' [/COLOR]','')[1:]
	GOBuJmLv5K4Sshx = ZXFs0mEPR8qI2zj.findall('[a-zA-Z]',aaYDh2EzJ5ky,ZXFs0mEPR8qI2zj.DOTALL)
	if 'بحث IPTV - ' in aaYDh2EzJ5ky: aaYDh2EzJ5ky = aaYDh2EzJ5ky.replace('بحث IPTV - ',PGLUYu7ySB5gD8b4ZJQq+'بحث IPTV - '+PGLUYu7ySB5gD8b4ZJQq)
	elif ' IPTV' in aaYDh2EzJ5ky and hjTtuHAF3UPKfQSXEJ47pL0an=='IPT': aaYDh2EzJ5ky = PGLUYu7ySB5gD8b4ZJQq+aaYDh2EzJ5ky
	elif 'بحث M3U - ' in aaYDh2EzJ5ky: aaYDh2EzJ5ky = aaYDh2EzJ5ky.replace('بحث M3U - ',PGLUYu7ySB5gD8b4ZJQq+'بحث M3U - '+PGLUYu7ySB5gD8b4ZJQq)
	elif ' M3U' in aaYDh2EzJ5ky and hjTtuHAF3UPKfQSXEJ47pL0an=='M3U': aaYDh2EzJ5ky = PGLUYu7ySB5gD8b4ZJQq+aaYDh2EzJ5ky
	elif 'بحث ' in aaYDh2EzJ5ky and ' - ' in aaYDh2EzJ5ky: aaYDh2EzJ5ky = PGLUYu7ySB5gD8b4ZJQq+aaYDh2EzJ5ky
	elif not GOBuJmLv5K4Sshx:
		d2Qlo6D4XbS0RfP9ArJ = ZXFs0mEPR8qI2zj.findall('^( *?)(.*?)( *?)$',aaYDh2EzJ5ky)
		HqpT8NSf6AxtuCV7nW42lZ,hSDfs0pHncodv,u0xKHbq9dVcMaU5j = d2Qlo6D4XbS0RfP9ArJ[0]
		ixvlpZDyHsVr593cf1agF = ZXFs0mEPR8qI2zj.findall('^([!-~])',hSDfs0pHncodv)
		if ixvlpZDyHsVr593cf1agF: aaYDh2EzJ5ky = HqpT8NSf6AxtuCV7nW42lZ+llDwesm6h4YkuLBCKQE8W0JIORoFS+hSDfs0pHncodv+u0xKHbq9dVcMaU5j
		else: aaYDh2EzJ5ky = u0xKHbq9dVcMaU5j+PGLUYu7ySB5gD8b4ZJQq+hSDfs0pHncodv+HqpT8NSf6AxtuCV7nW42lZ
	else:
		if 1:
			CguSYlhD7w0JEnbzy4f3A8xGN5T = aaYDh2EzJ5ky
			zztynvK6DP5iug = hBvy1ernIGgsxCc4bSJMEjQXuLU.get_display(aaYDh2EzJ5ky,base_dir='L')
			if Yd6t3PjlLKk: CguSYlhD7w0JEnbzy4f3A8xGN5T = CguSYlhD7w0JEnbzy4f3A8xGN5T.decode('utf8')
			if Yd6t3PjlLKk: zztynvK6DP5iug = zztynvK6DP5iug.decode('utf8')
			IVeQmqY7k1UaZ = CguSYlhD7w0JEnbzy4f3A8xGN5T.split(' ')
			DLKtyUGxiNsFR2gmVHzpfa4un6BES8 = zztynvK6DP5iug.split(' ')
			rmaPdJOwRFquMWh5s8SZvtc12NKY,u231uoEwmG9BxZ8NhJXsnp,Y9S7I5u4Ec81obTd,vc7OgFh2JmPf4naRQ0elTZMVb = [],[],'',''
			DT7jYPCJnh24QZG6wIduqe = zip(IVeQmqY7k1UaZ,DLKtyUGxiNsFR2gmVHzpfa4un6BES8)
			for ggPtXJuKIaeMA86BndFlLVib,lap6qwxNeh8 in DT7jYPCJnh24QZG6wIduqe:
				if ggPtXJuKIaeMA86BndFlLVib==lap6qwxNeh8=='' and vc7OgFh2JmPf4naRQ0elTZMVb:
					Y9S7I5u4Ec81obTd += ' '
					continue
				if ggPtXJuKIaeMA86BndFlLVib==lap6qwxNeh8:
					HcvA9eyxq5NFhmTbDQIrJkz = 'EN'
					if vc7OgFh2JmPf4naRQ0elTZMVb==HcvA9eyxq5NFhmTbDQIrJkz: Y9S7I5u4Ec81obTd += ' '+ggPtXJuKIaeMA86BndFlLVib
					elif ggPtXJuKIaeMA86BndFlLVib:
						if Y9S7I5u4Ec81obTd:
							u231uoEwmG9BxZ8NhJXsnp.append(Y9S7I5u4Ec81obTd)
							rmaPdJOwRFquMWh5s8SZvtc12NKY.append('')
						Y9S7I5u4Ec81obTd = ggPtXJuKIaeMA86BndFlLVib
				else:
					HcvA9eyxq5NFhmTbDQIrJkz = 'AR'
					if vc7OgFh2JmPf4naRQ0elTZMVb==HcvA9eyxq5NFhmTbDQIrJkz: Y9S7I5u4Ec81obTd += ' '+ggPtXJuKIaeMA86BndFlLVib
					elif ggPtXJuKIaeMA86BndFlLVib:
						if Y9S7I5u4Ec81obTd:
							rmaPdJOwRFquMWh5s8SZvtc12NKY.append(Y9S7I5u4Ec81obTd)
							u231uoEwmG9BxZ8NhJXsnp.append('')
						Y9S7I5u4Ec81obTd = ggPtXJuKIaeMA86BndFlLVib
				vc7OgFh2JmPf4naRQ0elTZMVb = HcvA9eyxq5NFhmTbDQIrJkz
			if HcvA9eyxq5NFhmTbDQIrJkz=='EN':
				rmaPdJOwRFquMWh5s8SZvtc12NKY.append(Y9S7I5u4Ec81obTd)
				u231uoEwmG9BxZ8NhJXsnp.append('')
			else:
				u231uoEwmG9BxZ8NhJXsnp.append(Y9S7I5u4Ec81obTd)
				rmaPdJOwRFquMWh5s8SZvtc12NKY.append('')
			NiyXzgRU7A8h = ''
			DT7jYPCJnh24QZG6wIduqe = zip(rmaPdJOwRFquMWh5s8SZvtc12NKY,u231uoEwmG9BxZ8NhJXsnp)
			for C9LTJePv1tMpx8fI,bPHa2yWdtpN0O4Jx in DT7jYPCJnh24QZG6wIduqe:
				if C9LTJePv1tMpx8fI: NiyXzgRU7A8h += ' '+C9LTJePv1tMpx8fI
				else:
					ixvlpZDyHsVr593cf1agF = ZXFs0mEPR8qI2zj.findall('([!-~]) *$',bPHa2yWdtpN0O4Jx)
					if ixvlpZDyHsVr593cf1agF:
						ixvlpZDyHsVr593cf1agF = ixvlpZDyHsVr593cf1agF[0]
						try:
							ux8caTiD4h7R1F05WjoEp6kYzNnbv = EEJlBFf5r4XdMUQiyhNR3uGs7.MIRRORED[ixvlpZDyHsVr593cf1agF]
							d2Qlo6D4XbS0RfP9ArJ = ZXFs0mEPR8qI2zj.findall('^( *?)(.*?)( *?)$',bPHa2yWdtpN0O4Jx)
							if d2Qlo6D4XbS0RfP9ArJ: HqpT8NSf6AxtuCV7nW42lZ,bPHa2yWdtpN0O4Jx,u0xKHbq9dVcMaU5j = d2Qlo6D4XbS0RfP9ArJ[0]
							bPHa2yWdtpN0O4Jx = HqpT8NSf6AxtuCV7nW42lZ+ux8caTiD4h7R1F05WjoEp6kYzNnbv+bPHa2yWdtpN0O4Jx[:-1]+u0xKHbq9dVcMaU5j
						except: pass
					NiyXzgRU7A8h += ' '+bPHa2yWdtpN0O4Jx
			aaYDh2EzJ5ky = NiyXzgRU7A8h[1:]
			if Yd6t3PjlLKk: aaYDh2EzJ5ky = aaYDh2EzJ5ky.encode('utf8')
		else:
			if Yd6t3PjlLKk: aaYDh2EzJ5ky = aaYDh2EzJ5ky.decode('utf8')
			aaYDh2EzJ5ky = hBvy1ernIGgsxCc4bSJMEjQXuLU.get_display(aaYDh2EzJ5ky)
			CguSYlhD7w0JEnbzy4f3A8xGN5T,zztynvK6DP5iug = aaYDh2EzJ5ky,aaYDh2EzJ5ky
			if 1:
				vc7OgFh2JmPf4naRQ0elTZMVb,xbw7U3T4gWleMLfKyJAvnSRDdX = '',[]
				OPnjIfGo52ZlrLAFpa = aaYDh2EzJ5ky.split(' ')
				for bL5JBxoVEmh1SIv in OPnjIfGo52ZlrLAFpa:
					if not bL5JBxoVEmh1SIv:
						if xbw7U3T4gWleMLfKyJAvnSRDdX: xbw7U3T4gWleMLfKyJAvnSRDdX[-1] += ' '
						else: xbw7U3T4gWleMLfKyJAvnSRDdX.append('')
						continue
					siUq95z6F3XvK = ZXFs0mEPR8qI2zj.findall('[!-~]',bL5JBxoVEmh1SIv[0])
					if siUq95z6F3XvK==vc7OgFh2JmPf4naRQ0elTZMVb and xbw7U3T4gWleMLfKyJAvnSRDdX: xbw7U3T4gWleMLfKyJAvnSRDdX[-1] += ' '+bL5JBxoVEmh1SIv
					else:
						if xbw7U3T4gWleMLfKyJAvnSRDdX:
							HfmPprxnDLNUy = ZXFs0mEPR8qI2zj.findall('[^!-~]',xbw7U3T4gWleMLfKyJAvnSRDdX[-1])
							if HfmPprxnDLNUy:
								xbw7U3T4gWleMLfKyJAvnSRDdX[-1] = hBvy1ernIGgsxCc4bSJMEjQXuLU.get_display(xbw7U3T4gWleMLfKyJAvnSRDdX[-1])
								URLI9vp2Ff = ZXFs0mEPR8qI2zj.findall('^ +',xbw7U3T4gWleMLfKyJAvnSRDdX[-1])
								if URLI9vp2Ff: xbw7U3T4gWleMLfKyJAvnSRDdX[-1] = xbw7U3T4gWleMLfKyJAvnSRDdX[-1].lstrip(' ')+URLI9vp2Ff[0]
						xbw7U3T4gWleMLfKyJAvnSRDdX.append(bL5JBxoVEmh1SIv)
					vc7OgFh2JmPf4naRQ0elTZMVb = siUq95z6F3XvK
				if xbw7U3T4gWleMLfKyJAvnSRDdX: xbw7U3T4gWleMLfKyJAvnSRDdX[-1] = hBvy1ernIGgsxCc4bSJMEjQXuLU.get_display(xbw7U3T4gWleMLfKyJAvnSRDdX[-1])
				aaYDh2EzJ5ky = ' '.join(xbw7U3T4gWleMLfKyJAvnSRDdX)
			if Yd6t3PjlLKk: aaYDh2EzJ5ky = aaYDh2EzJ5ky.encode('utf8')
	return aaYDh2EzJ5ky
def wwmUu7Mragt1QJeNhIiA4RZfB(llKa01dWnLzDMg,sPuTUEGV8YkKI9LzeJDAbd62731,yyeZD1RU93u):
	RGDQbxHAi1UpIuNveqTFXSw9gZjc4,aaYDh2EzJ5ky,gC2hO80boRyM7TBGqD,nnPsf4XLIJ7RWF,ggOIGYi4nEAJ2c8hvFufLRBq,gzSneRTPAqhv8txod3F,avOYHBRyL9k8WPXhSeK2c,dGlmU8JqW5yFAtcsg,WtmwkIxcKOZ3rB6PuSHCFL5vGqVo = llKa01dWnLzDMg
	nnPsf4XLIJ7RWF = int(nnPsf4XLIJ7RWF)
	BlbnqJPAO0eHi = ZXFs0mEPR8qI2zj.findall('(_(\d\d\.\d\d)_(\d\d\:\d\d)_)',aaYDh2EzJ5ky,ZXFs0mEPR8qI2zj.DOTALL)
	if BlbnqJPAO0eHi:
		BlbnqJPAO0eHi,L4A62wJoa19CrFgITeOdf,HQkVPr8RmTO9c6NICq71au = BlbnqJPAO0eHi[0]
		aaYDh2EzJ5ky = aaYDh2EzJ5ky.replace(BlbnqJPAO0eHi,'')
	rTz6YFxcgfv1DLI = aaYDh2EzJ5ky
	hjTtuHAF3UPKfQSXEJ47pL0an = ZXFs0mEPR8qI2zj.findall('^_(\w\w\w)_(.*?)$',aaYDh2EzJ5ky,ZXFs0mEPR8qI2zj.DOTALL)
	if hjTtuHAF3UPKfQSXEJ47pL0an:
		hjTtuHAF3UPKfQSXEJ47pL0an,aaYDh2EzJ5ky = hjTtuHAF3UPKfQSXEJ47pL0an[0]
		bsHg7zlVAoWP1UtNfqpMc5 = '_MOD_' in aaYDh2EzJ5ky
		fTLHoIGS2JMYV3jKh7DuW0ke = RGDQbxHAi1UpIuNveqTFXSw9gZjc4=='folder'
		if bsHg7zlVAoWP1UtNfqpMc5 and fTLHoIGS2JMYV3jKh7DuW0ke: qzWuPiXcUV3I7D1jGB2R = ';'
		elif bsHg7zlVAoWP1UtNfqpMc5 and not fTLHoIGS2JMYV3jKh7DuW0ke: qzWuPiXcUV3I7D1jGB2R = LLf6s3gMbn
		elif not bsHg7zlVAoWP1UtNfqpMc5 and fTLHoIGS2JMYV3jKh7DuW0ke: qzWuPiXcUV3I7D1jGB2R = ','
		elif not bsHg7zlVAoWP1UtNfqpMc5 and not fTLHoIGS2JMYV3jKh7DuW0ke: qzWuPiXcUV3I7D1jGB2R = ' '
		aaYDh2EzJ5ky = aaYDh2EzJ5ky.replace('_MOD_','')
		hjTtuHAF3UPKfQSXEJ47pL0an = qzWuPiXcUV3I7D1jGB2R+'[COLOR FFC89008]'+hjTtuHAF3UPKfQSXEJ47pL0an+' [/COLOR]'
	else: hjTtuHAF3UPKfQSXEJ47pL0an = ''
	if BlbnqJPAO0eHi:
		if Yd6t3PjlLKk:
			BlbnqJPAO0eHi = '[COLOR FFFFFF00]'+L4A62wJoa19CrFgITeOdf+' '+HQkVPr8RmTO9c6NICq71au+'[/COLOR]'
			if hjTtuHAF3UPKfQSXEJ47pL0an: aaYDh2EzJ5ky = BlbnqJPAO0eHi+' '+PGLUYu7ySB5gD8b4ZJQq+hjTtuHAF3UPKfQSXEJ47pL0an+aaYDh2EzJ5ky
			else: aaYDh2EzJ5ky = BlbnqJPAO0eHi+PGLUYu7ySB5gD8b4ZJQq+aaYDh2EzJ5ky+' '
		elif VYMZsxRpcQHPgkaiDKjyoh:
			if hjTtuHAF3UPKfQSXEJ47pL0an:
				BlbnqJPAO0eHi = '[COLOR FFFFFF00]'+L4A62wJoa19CrFgITeOdf+' '+HQkVPr8RmTO9c6NICq71au+'[/COLOR]'
				aaYDh2EzJ5ky = BlbnqJPAO0eHi+' '+hjTtuHAF3UPKfQSXEJ47pL0an+aaYDh2EzJ5ky
			else:
				BlbnqJPAO0eHi = '[COLOR FFFFFF00]'+HQkVPr8RmTO9c6NICq71au+' '+L4A62wJoa19CrFgITeOdf+'[/COLOR]'
				aaYDh2EzJ5ky = aaYDh2EzJ5ky+' '+PGLUYu7ySB5gD8b4ZJQq+BlbnqJPAO0eHi
	elif hjTtuHAF3UPKfQSXEJ47pL0an:
		aaYDh2EzJ5ky = oo1atgXlfxmTB2GA(aaYDh2EzJ5ky,hjTtuHAF3UPKfQSXEJ47pL0an)
		aaYDh2EzJ5ky = hjTtuHAF3UPKfQSXEJ47pL0an+aaYDh2EzJ5ky
	llKa01dWnLzDMg = RGDQbxHAi1UpIuNveqTFXSw9gZjc4,rTz6YFxcgfv1DLI,gC2hO80boRyM7TBGqD,str(nnPsf4XLIJ7RWF),ggOIGYi4nEAJ2c8hvFufLRBq,gzSneRTPAqhv8txod3F,avOYHBRyL9k8WPXhSeK2c,dGlmU8JqW5yFAtcsg,WtmwkIxcKOZ3rB6PuSHCFL5vGqVo
	E5EhLzb4DToZOkKWpHBd = {'type':'','mode':'','url':'','text':'','page':'','name':'','image':'','context':'','infodict':''}
	E5EhLzb4DToZOkKWpHBd['name'] = cD1AgYCl0qZI8(rTz6YFxcgfv1DLI)
	E5EhLzb4DToZOkKWpHBd['type'] = RGDQbxHAi1UpIuNveqTFXSw9gZjc4.strip(' ')
	E5EhLzb4DToZOkKWpHBd['mode'] = str(nnPsf4XLIJ7RWF).strip(' ')
	if RGDQbxHAi1UpIuNveqTFXSw9gZjc4=='folder' and gzSneRTPAqhv8txod3F: E5EhLzb4DToZOkKWpHBd['page'] = cD1AgYCl0qZI8(gzSneRTPAqhv8txod3F.strip(' '))
	if dGlmU8JqW5yFAtcsg: E5EhLzb4DToZOkKWpHBd['context'] = dGlmU8JqW5yFAtcsg.strip(' ')
	if avOYHBRyL9k8WPXhSeK2c: E5EhLzb4DToZOkKWpHBd['text'] = cD1AgYCl0qZI8(avOYHBRyL9k8WPXhSeK2c.strip(' '))
	if ggOIGYi4nEAJ2c8hvFufLRBq: E5EhLzb4DToZOkKWpHBd['image'] = cD1AgYCl0qZI8(ggOIGYi4nEAJ2c8hvFufLRBq.strip(' '))
	if WtmwkIxcKOZ3rB6PuSHCFL5vGqVo:
		WtmwkIxcKOZ3rB6PuSHCFL5vGqVo = str(WtmwkIxcKOZ3rB6PuSHCFL5vGqVo)
		E5EhLzb4DToZOkKWpHBd['infodict'] = cD1AgYCl0qZI8(WtmwkIxcKOZ3rB6PuSHCFL5vGqVo.strip(' '))
		WtmwkIxcKOZ3rB6PuSHCFL5vGqVo = eval(WtmwkIxcKOZ3rB6PuSHCFL5vGqVo)
	else: WtmwkIxcKOZ3rB6PuSHCFL5vGqVo = {}
	if gC2hO80boRyM7TBGqD: E5EhLzb4DToZOkKWpHBd['url'] = cD1AgYCl0qZI8(gC2hO80boRyM7TBGqD.strip(' '))
	molgbGArRZv5IhqpjekiXFOtYuVKc = {'name':'','context_menu':'','plot':'','stars':'','image':'','type':'','isFolder':'','newpath':'','duration':''}
	PdXj3DIAag2oYJRiO8vmqut = []
	hFOHyplzZXc = 'plugin://'+ZK5gkAtjrCeEXYGD2bRQHOF3Moyc+'/?type='+E5EhLzb4DToZOkKWpHBd['type']+'&mode='+E5EhLzb4DToZOkKWpHBd['mode']
	if E5EhLzb4DToZOkKWpHBd['page']: hFOHyplzZXc += '&page='+E5EhLzb4DToZOkKWpHBd['page']
	if E5EhLzb4DToZOkKWpHBd['name']: hFOHyplzZXc += '&name='+E5EhLzb4DToZOkKWpHBd['name']
	if E5EhLzb4DToZOkKWpHBd['text']: hFOHyplzZXc += '&text='+E5EhLzb4DToZOkKWpHBd['text']
	if E5EhLzb4DToZOkKWpHBd['infodict']: hFOHyplzZXc += '&infodict='+E5EhLzb4DToZOkKWpHBd['infodict']
	if E5EhLzb4DToZOkKWpHBd['image']: hFOHyplzZXc += '&image='+E5EhLzb4DToZOkKWpHBd['image']
	if E5EhLzb4DToZOkKWpHBd['url']: hFOHyplzZXc += '&url='+E5EhLzb4DToZOkKWpHBd['url']
	if nnPsf4XLIJ7RWF!=265: molgbGArRZv5IhqpjekiXFOtYuVKc['favorites'] = True
	else: molgbGArRZv5IhqpjekiXFOtYuVKc['favorites'] = False
	if E5EhLzb4DToZOkKWpHBd['context']: hFOHyplzZXc += '&context='+E5EhLzb4DToZOkKWpHBd['context']
	if nnPsf4XLIJ7RWF in [235,238] and RGDQbxHAi1UpIuNveqTFXSw9gZjc4=='live' and 'EPG' in dGlmU8JqW5yFAtcsg:
		eS60BtwJxIfOK7i2y = 'plugin://'+ZK5gkAtjrCeEXYGD2bRQHOF3Moyc+'?mode=238&text=SHORT_EPG&url='+gC2hO80boRyM7TBGqD
		jjGgDkTOhCqfFLeyu6A5URK4dprlXW = '[COLOR FFFFFF00]البرامج القادمة[/COLOR]'
		G7rHSumkQcJUD05XK3jhna48xfBV = (jjGgDkTOhCqfFLeyu6A5URK4dprlXW,'RunPlugin('+eS60BtwJxIfOK7i2y+')')
		PdXj3DIAag2oYJRiO8vmqut.append(G7rHSumkQcJUD05XK3jhna48xfBV)
	if nnPsf4XLIJ7RWF==265:
		D1kz5HhyWldovxibLINCm4603 = sPuTUEGV8YkKI9LzeJDAbd62731(avOYHBRyL9k8WPXhSeK2c,True)
		if D1kz5HhyWldovxibLINCm4603>0:
			eS60BtwJxIfOK7i2y = 'plugin://'+ZK5gkAtjrCeEXYGD2bRQHOF3Moyc+'?mode=266&text='+avOYHBRyL9k8WPXhSeK2c
			jjGgDkTOhCqfFLeyu6A5URK4dprlXW = '[COLOR FFFFFF00]مسح قائمة آخر 50 '+Po4CyOusDaWq6pbIjYV(avOYHBRyL9k8WPXhSeK2c)+'[/COLOR]'
			G7rHSumkQcJUD05XK3jhna48xfBV = (jjGgDkTOhCqfFLeyu6A5URK4dprlXW,'RunPlugin('+eS60BtwJxIfOK7i2y+')')
			PdXj3DIAag2oYJRiO8vmqut.append(G7rHSumkQcJUD05XK3jhna48xfBV)
	if RGDQbxHAi1UpIuNveqTFXSw9gZjc4=='video' and nnPsf4XLIJ7RWF!=331:
		eS60BtwJxIfOK7i2y = hFOHyplzZXc+'&context=6_DOWNLOAD'
		jjGgDkTOhCqfFLeyu6A5URK4dprlXW = '[COLOR FFFFFF00]تحميل ملف الفيديو[/COLOR]'
		G7rHSumkQcJUD05XK3jhna48xfBV = (jjGgDkTOhCqfFLeyu6A5URK4dprlXW,'RunPlugin('+eS60BtwJxIfOK7i2y+')')
		PdXj3DIAag2oYJRiO8vmqut.append(G7rHSumkQcJUD05XK3jhna48xfBV)
	if nnPsf4XLIJ7RWF==331:
		eS60BtwJxIfOK7i2y = hFOHyplzZXc+'&context=6_DELETE'
		jjGgDkTOhCqfFLeyu6A5URK4dprlXW = '[COLOR FFFFFF00]حذف ملف الفيديو[/COLOR]'
		G7rHSumkQcJUD05XK3jhna48xfBV = (jjGgDkTOhCqfFLeyu6A5URK4dprlXW,'RunPlugin('+eS60BtwJxIfOK7i2y+')')
		PdXj3DIAag2oYJRiO8vmqut.append(G7rHSumkQcJUD05XK3jhna48xfBV)
	if RGDQbxHAi1UpIuNveqTFXSw9gZjc4=='folder' and nnPsf4XLIJ7RWF==540:
		cQ3elmkxuU7ayI4sR = NUauTXxKLAoqQtJkglSFRWE(hosgCj2byWvuVT,'list','GLOBALSEARCH_SITES')
		if cQ3elmkxuU7ayI4sR:
			eS60BtwJxIfOK7i2y = 'plugin://'+ZK5gkAtjrCeEXYGD2bRQHOF3Moyc+'?context=7'
			jjGgDkTOhCqfFLeyu6A5URK4dprlXW = '[COLOR FFFFFF00]مسح جميع كلمات البحث[/COLOR]'
			G7rHSumkQcJUD05XK3jhna48xfBV = (jjGgDkTOhCqfFLeyu6A5URK4dprlXW,'RunPlugin('+eS60BtwJxIfOK7i2y+')')
			PdXj3DIAag2oYJRiO8vmqut.append(G7rHSumkQcJUD05XK3jhna48xfBV)
	GGhklTBJ9KUdt58jmMeYwSvXEPWNgn = [9990,2,7,100,151,159,176,196,199,230,239,260,261,262,263,264,265,267,270,290,330,341,346,348,501,505,510,540,710,719,761,762]
	if nnPsf4XLIJ7RWF not in GGhklTBJ9KUdt58jmMeYwSvXEPWNgn:
		eS60BtwJxIfOK7i2y = 'plugin://'+ZK5gkAtjrCeEXYGD2bRQHOF3Moyc+'?context=8&mode=260'
		jjGgDkTOhCqfFLeyu6A5URK4dprlXW = '[COLOR FFFFFF00]القائمة الرئيسية[/COLOR]'
		G7rHSumkQcJUD05XK3jhna48xfBV = (jjGgDkTOhCqfFLeyu6A5URK4dprlXW,'RunPlugin('+eS60BtwJxIfOK7i2y+')')
		PdXj3DIAag2oYJRiO8vmqut.append(G7rHSumkQcJUD05XK3jhna48xfBV)
	qEgOVSWtRvj8ZGPhwoaIuFd = [0,150,160,170,190,260,280,330,340,410,500,520,530,560,760]
	if nnPsf4XLIJ7RWF%10 and nnPsf4XLIJ7RWF!=9990:
		vcjPSRElkx = nnPsf4XLIJ7RWF-nnPsf4XLIJ7RWF%10
		if vcjPSRElkx==280: vcjPSRElkx = 230
		if vcjPSRElkx==410: vcjPSRElkx = 400
		if vcjPSRElkx==520: vcjPSRElkx = 510
		if vcjPSRElkx not in qEgOVSWtRvj8ZGPhwoaIuFd:
			eS60BtwJxIfOK7i2y = 'plugin://'+ZK5gkAtjrCeEXYGD2bRQHOF3Moyc+'?context=8&mode='+str(vcjPSRElkx)
			jjGgDkTOhCqfFLeyu6A5URK4dprlXW = '[COLOR FFFFFF00]قائمة الموقع[/COLOR]'
			G7rHSumkQcJUD05XK3jhna48xfBV = (jjGgDkTOhCqfFLeyu6A5URK4dprlXW,'RunPlugin('+eS60BtwJxIfOK7i2y+')')
			PdXj3DIAag2oYJRiO8vmqut.append(G7rHSumkQcJUD05XK3jhna48xfBV)
	eS60BtwJxIfOK7i2y = hFOHyplzZXc+'&context=9'
	jjGgDkTOhCqfFLeyu6A5URK4dprlXW = '[COLOR FFFFFF00]تحديث القائمة[/COLOR]'
	G7rHSumkQcJUD05XK3jhna48xfBV = (jjGgDkTOhCqfFLeyu6A5URK4dprlXW,'RunPlugin('+eS60BtwJxIfOK7i2y+')')
	PdXj3DIAag2oYJRiO8vmqut.append(G7rHSumkQcJUD05XK3jhna48xfBV)
	if RGDQbxHAi1UpIuNveqTFXSw9gZjc4 in ['link','video','live']: NU0VGOPWdgM7wIj = False
	elif RGDQbxHAi1UpIuNveqTFXSw9gZjc4=='folder': NU0VGOPWdgM7wIj = True
	molgbGArRZv5IhqpjekiXFOtYuVKc['name'] = aaYDh2EzJ5ky
	molgbGArRZv5IhqpjekiXFOtYuVKc['context_menu'] = PdXj3DIAag2oYJRiO8vmqut
	if 'plot' in list(WtmwkIxcKOZ3rB6PuSHCFL5vGqVo.keys()): molgbGArRZv5IhqpjekiXFOtYuVKc['plot'] = WtmwkIxcKOZ3rB6PuSHCFL5vGqVo['plot']
	if 'stars' in list(WtmwkIxcKOZ3rB6PuSHCFL5vGqVo.keys()): molgbGArRZv5IhqpjekiXFOtYuVKc['stars'] = WtmwkIxcKOZ3rB6PuSHCFL5vGqVo['stars']
	if ggOIGYi4nEAJ2c8hvFufLRBq: molgbGArRZv5IhqpjekiXFOtYuVKc['image'] = ggOIGYi4nEAJ2c8hvFufLRBq
	if RGDQbxHAi1UpIuNveqTFXSw9gZjc4=='video' and gzSneRTPAqhv8txod3F:
		nntqkTFQdC4JgeKWbvj0sORHVz = ZXFs0mEPR8qI2zj.findall('[\d:]+',gzSneRTPAqhv8txod3F,ZXFs0mEPR8qI2zj.DOTALL)
		if nntqkTFQdC4JgeKWbvj0sORHVz:
			nntqkTFQdC4JgeKWbvj0sORHVz = '0:0:0:0:0:'+nntqkTFQdC4JgeKWbvj0sORHVz[0]
			vWK3cmrB9SsT4dLwU,gOCDmFlZutG1rNWy,tnRS96A75NXajWg4,D2FRUXIGefx,hHPGiucM98LAgWYvq = nntqkTFQdC4JgeKWbvj0sORHVz.rsplit(':',4)
			cJXBpTYfF3vjl2MrG401HQuPRW6oz = int(gOCDmFlZutG1rNWy)*24*sGOne0xWA5+int(tnRS96A75NXajWg4)*sGOne0xWA5+int(D2FRUXIGefx)*60+int(hHPGiucM98LAgWYvq)
			molgbGArRZv5IhqpjekiXFOtYuVKc['duration'] = cJXBpTYfF3vjl2MrG401HQuPRW6oz
	molgbGArRZv5IhqpjekiXFOtYuVKc['type'] = RGDQbxHAi1UpIuNveqTFXSw9gZjc4
	molgbGArRZv5IhqpjekiXFOtYuVKc['isFolder'] = NU0VGOPWdgM7wIj
	molgbGArRZv5IhqpjekiXFOtYuVKc['newpath'] = hFOHyplzZXc
	molgbGArRZv5IhqpjekiXFOtYuVKc['menuItem'] = llKa01dWnLzDMg
	molgbGArRZv5IhqpjekiXFOtYuVKc['mode'] = nnPsf4XLIJ7RWF
	return molgbGArRZv5IhqpjekiXFOtYuVKc
def QVm4NG9aLtX6Hn8fod0iRWwhsUyu(sPuTUEGV8YkKI9LzeJDAbd62731):
	PPVgD9EkhU5x71yvFmpLXuSTZq4 = []
	from bepC1A2Yfo import M83nAibIqYrhcdPvJl1aQExy,uwtI7SKjfJZYHzi5slFOebhc21qx
	yyeZD1RU93u = M83nAibIqYrhcdPvJl1aQExy()
	for llKa01dWnLzDMg in OWasmQ27g3Dbljpo:
		molgbGArRZv5IhqpjekiXFOtYuVKc = wwmUu7Mragt1QJeNhIiA4RZfB(llKa01dWnLzDMg,sPuTUEGV8YkKI9LzeJDAbd62731,yyeZD1RU93u)
		if molgbGArRZv5IhqpjekiXFOtYuVKc['favorites']:
			V2VsmKlLcnNGDdgXOj = uwtI7SKjfJZYHzi5slFOebhc21qx(yyeZD1RU93u,molgbGArRZv5IhqpjekiXFOtYuVKc['menuItem'],molgbGArRZv5IhqpjekiXFOtYuVKc['newpath'])
			molgbGArRZv5IhqpjekiXFOtYuVKc['context_menu'] = V2VsmKlLcnNGDdgXOj+molgbGArRZv5IhqpjekiXFOtYuVKc['context_menu']
		PPVgD9EkhU5x71yvFmpLXuSTZq4.append(molgbGArRZv5IhqpjekiXFOtYuVKc)
	return PPVgD9EkhU5x71yvFmpLXuSTZq4
def qWUNPoZtLSV8IiYwOCz7xuAeyBRdD6(dUkqersWvMoJ964):
	qzWuPiXcUV3I7D1jGB2R,OHCZwrpYvgaNy569ns7DkTt2Q8UV, = [],''
	for FFhKw05es4jgM in dUkqersWvMoJ964:
		if not FFhKw05es4jgM: qzWuPiXcUV3I7D1jGB2R.append('')
		else: break
	dUkqersWvMoJ964 = dUkqersWvMoJ964[len(qzWuPiXcUV3I7D1jGB2R):]
	uHGMxiZfcoErOyXghvnWUK = '\n\n\n\n'.join(dUkqersWvMoJ964)
	uHGMxiZfcoErOyXghvnWUK = uHGMxiZfcoErOyXghvnWUK.replace('===== ===== =====','000001')
	uHGMxiZfcoErOyXghvnWUK = uHGMxiZfcoErOyXghvnWUK.replace('[COLOR FFC89008]','000002')
	uHGMxiZfcoErOyXghvnWUK = uHGMxiZfcoErOyXghvnWUK.replace('[COLOR FFFFFF00]','000003')
	uHGMxiZfcoErOyXghvnWUK = uHGMxiZfcoErOyXghvnWUK.replace('[/COLOR]','000004')
	uHGMxiZfcoErOyXghvnWUK = uHGMxiZfcoErOyXghvnWUK.replace('[RIGHT]','000005')
	hcVjpT7mOqX = 100000
	ZhqpI0bfxwMYiTgs3kRr7ymKF1 = {}
	I7MDQvRiTZKcoE = ZXFs0mEPR8qI2zj.findall('http.*?[\r\n ]',uHGMxiZfcoErOyXghvnWUK,ZXFs0mEPR8qI2zj.DOTALL)
	for O2Pa3FWHuhns6Q0X in I7MDQvRiTZKcoE:
		hcVjpT7mOqX += 1
		uHGMxiZfcoErOyXghvnWUK = uHGMxiZfcoErOyXghvnWUK.replace(O2Pa3FWHuhns6Q0X,str(hcVjpT7mOqX))
		ZhqpI0bfxwMYiTgs3kRr7ymKF1[str(hcVjpT7mOqX)] = O2Pa3FWHuhns6Q0X
	for tdpTaMcz6ZfOUAvx0ByPnLrJob in range(0,len(uHGMxiZfcoErOyXghvnWUK),4800):
		hn2rAQMkSqf1woegbaYzuXIWUL4PC = uHGMxiZfcoErOyXghvnWUK[tdpTaMcz6ZfOUAvx0ByPnLrJob:tdpTaMcz6ZfOUAvx0ByPnLrJob+4800]
		OdLxAVyvHi5X1kq = j2agIU0xsLS6c7T.getSetting('av.language.code')
		gC2hO80boRyM7TBGqD = 'https://translator-api.glosbe.com/translateByLangDetect?sourceLang=ar&targetLang='+OdLxAVyvHi5X1kq
		Mm7XCRohg3iUSfJKdWsIqx = {'Content-Type':'text/plain'}
		qFgdexufDvw = hn2rAQMkSqf1woegbaYzuXIWUL4PC.encode('utf8')
		Ba3qhge51Hynsz8mcoW = A6F71g3cqN4(KxirmCLT6Gw,'POST',gC2hO80boRyM7TBGqD,qFgdexufDvw,Mm7XCRohg3iUSfJKdWsIqx,'','','LIBRARY-GLOSBE_TRANSLATE-1st')
		if Ba3qhge51Hynsz8mcoW.succeeded:
			BRufE2IykDCOaNAv9iU = Ba3qhge51Hynsz8mcoW.content
			s82cpRvA9uxDZljdO4 = NL0JIkbrEWqTYj61vVKGCnBw37MsOF('str',BRufE2IykDCOaNAv9iU)
			if s82cpRvA9uxDZljdO4:
				s82cpRvA9uxDZljdO4 = s82cpRvA9uxDZljdO4['translation']
				s82cpRvA9uxDZljdO4 = WhJe7bGx5XackTwOIZVLC8ut(s82cpRvA9uxDZljdO4)
				for ood6Gh9mLZIcrSUO0zVERjsikg7x in range(len(s82cpRvA9uxDZljdO4)):
					OHCZwrpYvgaNy569ns7DkTt2Q8UV += s82cpRvA9uxDZljdO4[ood6Gh9mLZIcrSUO0zVERjsikg7x][0]
	OHCZwrpYvgaNy569ns7DkTt2Q8UV = OHCZwrpYvgaNy569ns7DkTt2Q8UV.replace('000001','===== ===== =====')
	OHCZwrpYvgaNy569ns7DkTt2Q8UV = OHCZwrpYvgaNy569ns7DkTt2Q8UV.replace('000002','[COLOR FFC89008]')
	OHCZwrpYvgaNy569ns7DkTt2Q8UV = OHCZwrpYvgaNy569ns7DkTt2Q8UV.replace('000003','[COLOR FFFFFF00]')
	OHCZwrpYvgaNy569ns7DkTt2Q8UV = OHCZwrpYvgaNy569ns7DkTt2Q8UV.replace('000004','[/COLOR]')
	OHCZwrpYvgaNy569ns7DkTt2Q8UV = OHCZwrpYvgaNy569ns7DkTt2Q8UV.replace('000005','[RIGHT]')
	for hcVjpT7mOqX in list(ZhqpI0bfxwMYiTgs3kRr7ymKF1.keys()):
		O2Pa3FWHuhns6Q0X = ZhqpI0bfxwMYiTgs3kRr7ymKF1[hcVjpT7mOqX]
		OHCZwrpYvgaNy569ns7DkTt2Q8UV = OHCZwrpYvgaNy569ns7DkTt2Q8UV.replace(hcVjpT7mOqX,O2Pa3FWHuhns6Q0X)
	OHCZwrpYvgaNy569ns7DkTt2Q8UV = OHCZwrpYvgaNy569ns7DkTt2Q8UV.split('\n\n\n\n')
	return qzWuPiXcUV3I7D1jGB2R+OHCZwrpYvgaNy569ns7DkTt2Q8UV
def Hg5xKri8vUVQLz2ql(dUkqersWvMoJ964):
	qzWuPiXcUV3I7D1jGB2R,OHCZwrpYvgaNy569ns7DkTt2Q8UV, = [],''
	for FFhKw05es4jgM in dUkqersWvMoJ964:
		if not FFhKw05es4jgM: qzWuPiXcUV3I7D1jGB2R.append('')
		else: break
	dUkqersWvMoJ964 = dUkqersWvMoJ964[len(qzWuPiXcUV3I7D1jGB2R):]
	uHGMxiZfcoErOyXghvnWUK = '\\n\\n\\n\\n'.join(dUkqersWvMoJ964)
	uHGMxiZfcoErOyXghvnWUK = uHGMxiZfcoErOyXghvnWUK.replace('كلا','no')
	uHGMxiZfcoErOyXghvnWUK = uHGMxiZfcoErOyXghvnWUK.replace('استمرار','continue')
	uHGMxiZfcoErOyXghvnWUK = uHGMxiZfcoErOyXghvnWUK.replace('===== ===== =====','000001')
	uHGMxiZfcoErOyXghvnWUK = uHGMxiZfcoErOyXghvnWUK.replace('[COLOR FFC89008]','000002')
	uHGMxiZfcoErOyXghvnWUK = uHGMxiZfcoErOyXghvnWUK.replace('[COLOR FFFFFF00]','000003')
	uHGMxiZfcoErOyXghvnWUK = uHGMxiZfcoErOyXghvnWUK.replace('[/COLOR]','000004')
	uHGMxiZfcoErOyXghvnWUK = uHGMxiZfcoErOyXghvnWUK.replace('[RIGHT]','000005')
	uHGMxiZfcoErOyXghvnWUK = uHGMxiZfcoErOyXghvnWUK.replace('[CENTER]','000006')
	uHGMxiZfcoErOyXghvnWUK = uHGMxiZfcoErOyXghvnWUK.replace('[RTL]','000007')
	uHGMxiZfcoErOyXghvnWUK = uHGMxiZfcoErOyXghvnWUK.replace("'","\\\\\\'")
	uHGMxiZfcoErOyXghvnWUK = uHGMxiZfcoErOyXghvnWUK.replace('"','\\\\\\"')
	uHGMxiZfcoErOyXghvnWUK = uHGMxiZfcoErOyXghvnWUK.replace('\n','\\n')
	uHGMxiZfcoErOyXghvnWUK = uHGMxiZfcoErOyXghvnWUK.replace('\r','\\\\r')
	for tdpTaMcz6ZfOUAvx0ByPnLrJob in range(0,len(uHGMxiZfcoErOyXghvnWUK),4800):
		hn2rAQMkSqf1woegbaYzuXIWUL4PC = uHGMxiZfcoErOyXghvnWUK[tdpTaMcz6ZfOUAvx0ByPnLrJob:tdpTaMcz6ZfOUAvx0ByPnLrJob+4800]
		gC2hO80boRyM7TBGqD = 'https://translate.google.com/_/TranslateWebserverUi/data/batchexecute'
		Mm7XCRohg3iUSfJKdWsIqx = {'Content-Type':'application/x-www-form-urlencoded'}
		OdLxAVyvHi5X1kq = j2agIU0xsLS6c7T.getSetting('av.language.code')
		qFgdexufDvw = 'f.req='+cD1AgYCl0qZI8('[[["MkEWBc","[[\\"'+hn2rAQMkSqf1woegbaYzuXIWUL4PC+'\\",\\"ar\\",\\"'+OdLxAVyvHi5X1kq+'\\",1],[]]",null,"generic"]]]','')
		qFgdexufDvw = qFgdexufDvw.replace('%5Cn','%5C%5Cn')
		Ba3qhge51Hynsz8mcoW = A6F71g3cqN4(KxirmCLT6Gw,'POST',gC2hO80boRyM7TBGqD,qFgdexufDvw,Mm7XCRohg3iUSfJKdWsIqx,'','','LIBRARY-GOOGLE_TRANSLATE-1st')
		if Ba3qhge51Hynsz8mcoW.succeeded:
			BRufE2IykDCOaNAv9iU = Ba3qhge51Hynsz8mcoW.content
			BRufE2IykDCOaNAv9iU = BRufE2IykDCOaNAv9iU.split('\n')[-1]
			s82cpRvA9uxDZljdO4 = NL0JIkbrEWqTYj61vVKGCnBw37MsOF('str',BRufE2IykDCOaNAv9iU)[0][2]
			if s82cpRvA9uxDZljdO4:
				s82cpRvA9uxDZljdO4 = NL0JIkbrEWqTYj61vVKGCnBw37MsOF('str',s82cpRvA9uxDZljdO4)[1][0][0][5]
				s82cpRvA9uxDZljdO4 = WhJe7bGx5XackTwOIZVLC8ut(s82cpRvA9uxDZljdO4)
				for ood6Gh9mLZIcrSUO0zVERjsikg7x in range(len(s82cpRvA9uxDZljdO4)):
					OHCZwrpYvgaNy569ns7DkTt2Q8UV += s82cpRvA9uxDZljdO4[ood6Gh9mLZIcrSUO0zVERjsikg7x][0]
	OHCZwrpYvgaNy569ns7DkTt2Q8UV = OHCZwrpYvgaNy569ns7DkTt2Q8UV.replace('00000','0000').replace('0000','000')
	OHCZwrpYvgaNy569ns7DkTt2Q8UV = OHCZwrpYvgaNy569ns7DkTt2Q8UV.replace('0001','===== ===== =====')
	OHCZwrpYvgaNy569ns7DkTt2Q8UV = OHCZwrpYvgaNy569ns7DkTt2Q8UV.replace('0002','[COLOR FFC89008]')
	OHCZwrpYvgaNy569ns7DkTt2Q8UV = OHCZwrpYvgaNy569ns7DkTt2Q8UV.replace('0003','[COLOR FFFFFF00]')
	OHCZwrpYvgaNy569ns7DkTt2Q8UV = OHCZwrpYvgaNy569ns7DkTt2Q8UV.replace('0004','[/COLOR]')
	OHCZwrpYvgaNy569ns7DkTt2Q8UV = OHCZwrpYvgaNy569ns7DkTt2Q8UV.replace('0005','[RIGHT]')
	OHCZwrpYvgaNy569ns7DkTt2Q8UV = OHCZwrpYvgaNy569ns7DkTt2Q8UV.replace('0006','[CENTER]')
	OHCZwrpYvgaNy569ns7DkTt2Q8UV = OHCZwrpYvgaNy569ns7DkTt2Q8UV.replace('0007','[RTL]')
	OHCZwrpYvgaNy569ns7DkTt2Q8UV = OHCZwrpYvgaNy569ns7DkTt2Q8UV.split('\n\n\n\n')
	return qzWuPiXcUV3I7D1jGB2R+OHCZwrpYvgaNy569ns7DkTt2Q8UV
def JJ1Vb0RktIzZNq(dUkqersWvMoJ964):
	qzWuPiXcUV3I7D1jGB2R,Ek1042bBiwSLz7r6vmRTyJIa5 = [],[]
	for FFhKw05es4jgM in dUkqersWvMoJ964:
		if not FFhKw05es4jgM: qzWuPiXcUV3I7D1jGB2R.append('')
		else: break
	dUkqersWvMoJ964 = dUkqersWvMoJ964[len(qzWuPiXcUV3I7D1jGB2R):]
	uHGMxiZfcoErOyXghvnWUK = '\n\n\n\n'.join(dUkqersWvMoJ964)
	uHGMxiZfcoErOyXghvnWUK = uHGMxiZfcoErOyXghvnWUK.replace('كلا','no')
	uHGMxiZfcoErOyXghvnWUK = uHGMxiZfcoErOyXghvnWUK.replace('استمرار','continue')
	uHGMxiZfcoErOyXghvnWUK = uHGMxiZfcoErOyXghvnWUK.replace('أدناه','below')
	uHGMxiZfcoErOyXghvnWUK = uHGMxiZfcoErOyXghvnWUK.replace('[COLOR FFC89008]','00001')
	uHGMxiZfcoErOyXghvnWUK = uHGMxiZfcoErOyXghvnWUK.replace('[COLOR FFFFFF00]','00002')
	uHGMxiZfcoErOyXghvnWUK = uHGMxiZfcoErOyXghvnWUK.replace('[/COLOR]','00003')
	uHGMxiZfcoErOyXghvnWUK = uHGMxiZfcoErOyXghvnWUK.replace('=====','00004')
	uHGMxiZfcoErOyXghvnWUK = uHGMxiZfcoErOyXghvnWUK.replace(',','00005')
	uHGMxiZfcoErOyXghvnWUK = uHGMxiZfcoErOyXghvnWUK.replace('[RTL]','00009')
	uHGMxiZfcoErOyXghvnWUK = uHGMxiZfcoErOyXghvnWUK.replace('[CENTER]','0000A')
	uHGMxiZfcoErOyXghvnWUK = uHGMxiZfcoErOyXghvnWUK.replace('\r','0000B')
	dUkqersWvMoJ964 = uHGMxiZfcoErOyXghvnWUK.split('\n')
	uHGMxiZfcoErOyXghvnWUK,OHCZwrpYvgaNy569ns7DkTt2Q8UV = '',''
	for FFhKw05es4jgM in dUkqersWvMoJ964:
		if len(uHGMxiZfcoErOyXghvnWUK+FFhKw05es4jgM)<1800: uHGMxiZfcoErOyXghvnWUK += '\n'+FFhKw05es4jgM
		else:
			Ek1042bBiwSLz7r6vmRTyJIa5.append(uHGMxiZfcoErOyXghvnWUK)
			uHGMxiZfcoErOyXghvnWUK = FFhKw05es4jgM
	Ek1042bBiwSLz7r6vmRTyJIa5.append(uHGMxiZfcoErOyXghvnWUK)
	from json import dumps as d3Dny8apiLb27shEwS
	for FFhKw05es4jgM in Ek1042bBiwSLz7r6vmRTyJIa5:
		Mm7XCRohg3iUSfJKdWsIqx = {'Content-Type':'application/json','User-Agent':''}
		gC2hO80boRyM7TBGqD = 'https://api.reverso.net/translate/v1/translation'
		OdLxAVyvHi5X1kq = j2agIU0xsLS6c7T.getSetting('av.language.code')
		qFgdexufDvw = {"format":"text","from":"ara","to":OdLxAVyvHi5X1kq,"input":FFhKw05es4jgM,"options":{"sentenceSplitter":True,"origin":"translation.web","contextResults":False,"languageDetection":False}}
		qFgdexufDvw = d3Dny8apiLb27shEwS(qFgdexufDvw)
		Ba3qhge51Hynsz8mcoW = A6F71g3cqN4(KxirmCLT6Gw,'POST',gC2hO80boRyM7TBGqD,qFgdexufDvw,Mm7XCRohg3iUSfJKdWsIqx,'','','LIBRARY-REVERSO_TRANSLATE-1st')
		if Ba3qhge51Hynsz8mcoW.succeeded:
			BRufE2IykDCOaNAv9iU = Ba3qhge51Hynsz8mcoW.content
			BRufE2IykDCOaNAv9iU = NL0JIkbrEWqTYj61vVKGCnBw37MsOF('dict',BRufE2IykDCOaNAv9iU)
			OHCZwrpYvgaNy569ns7DkTt2Q8UV += '\n'+''.join(BRufE2IykDCOaNAv9iU['translation'])
	OHCZwrpYvgaNy569ns7DkTt2Q8UV = OHCZwrpYvgaNy569ns7DkTt2Q8UV[2:]
	OHCZwrpYvgaNy569ns7DkTt2Q8UV = OHCZwrpYvgaNy569ns7DkTt2Q8UV.replace('000000','00000').replace('00000','0000').replace('0000','000')
	OHCZwrpYvgaNy569ns7DkTt2Q8UV = OHCZwrpYvgaNy569ns7DkTt2Q8UV.replace('0001','[COLOR FFC89008]')
	OHCZwrpYvgaNy569ns7DkTt2Q8UV = OHCZwrpYvgaNy569ns7DkTt2Q8UV.replace('0002','[COLOR FFFFFF00]')
	OHCZwrpYvgaNy569ns7DkTt2Q8UV = OHCZwrpYvgaNy569ns7DkTt2Q8UV.replace('0003','[/COLOR]')
	OHCZwrpYvgaNy569ns7DkTt2Q8UV = OHCZwrpYvgaNy569ns7DkTt2Q8UV.replace('0004','=====')
	OHCZwrpYvgaNy569ns7DkTt2Q8UV = OHCZwrpYvgaNy569ns7DkTt2Q8UV.replace('0005',',')
	OHCZwrpYvgaNy569ns7DkTt2Q8UV = OHCZwrpYvgaNy569ns7DkTt2Q8UV.replace('0009','[RTL]')
	OHCZwrpYvgaNy569ns7DkTt2Q8UV = OHCZwrpYvgaNy569ns7DkTt2Q8UV.replace('000A','[CENTER]')
	OHCZwrpYvgaNy569ns7DkTt2Q8UV = OHCZwrpYvgaNy569ns7DkTt2Q8UV.replace('000B','\r')
	OHCZwrpYvgaNy569ns7DkTt2Q8UV = OHCZwrpYvgaNy569ns7DkTt2Q8UV.split('\n\n\n\n')
	return qzWuPiXcUV3I7D1jGB2R+OHCZwrpYvgaNy569ns7DkTt2Q8UV
def picuFCj4o85h0x2VEDt(dUkqersWvMoJ964):
	htWEqFMyIHD7zPed3T6xm = j2agIU0xsLS6c7T.getSetting('av.language.translate')
	if not htWEqFMyIHD7zPed3T6xm or not dUkqersWvMoJ964: return dUkqersWvMoJ964
	EE27SGLBYTbWeywqmkVl61Hj = j2agIU0xsLS6c7T.getSetting('av.language.provider')
	OdLxAVyvHi5X1kq = j2agIU0xsLS6c7T.getSetting('av.language.code')
	m8aRer5GsWKYjikv9ulcD4M3 = OdLxAVyvHi5X1kq+'__'+str(dUkqersWvMoJ964)
	j2agIU0xsLS6c7T.setSetting('av.language.translate','')
	OHCZwrpYvgaNy569ns7DkTt2Q8UV = NUauTXxKLAoqQtJkglSFRWE(hosgCj2byWvuVT,'list','TRANSLATE_'+EE27SGLBYTbWeywqmkVl61Hj,m8aRer5GsWKYjikv9ulcD4M3)
	if not OHCZwrpYvgaNy569ns7DkTt2Q8UV:
		if EE27SGLBYTbWeywqmkVl61Hj=='GOOGLE': OHCZwrpYvgaNy569ns7DkTt2Q8UV = Hg5xKri8vUVQLz2ql(dUkqersWvMoJ964)
		elif EE27SGLBYTbWeywqmkVl61Hj=='REVERSO': OHCZwrpYvgaNy569ns7DkTt2Q8UV = JJ1Vb0RktIzZNq(dUkqersWvMoJ964)
		elif EE27SGLBYTbWeywqmkVl61Hj=='GLOSBE': OHCZwrpYvgaNy569ns7DkTt2Q8UV = qWUNPoZtLSV8IiYwOCz7xuAeyBRdD6(dUkqersWvMoJ964)
		if len(dUkqersWvMoJ964)==len(OHCZwrpYvgaNy569ns7DkTt2Q8UV):
			Qc96YoCZJOsKUB8yImw034(hosgCj2byWvuVT,'TRANSLATE_'+EE27SGLBYTbWeywqmkVl61Hj,m8aRer5GsWKYjikv9ulcD4M3,OHCZwrpYvgaNy569ns7DkTt2Q8UV,tteHTjUArw)
		else:
			OHCZwrpYvgaNy569ns7DkTt2Q8UV = dUkqersWvMoJ964
			NLVM3HAtxQOSvJf6kd78K1o('الترجمة فشلت','Translation Failed')
	j2agIU0xsLS6c7T.setSetting('av.language.translate','1')
	return OHCZwrpYvgaNy569ns7DkTt2Q8UV
def TT81k0Wa2MmLfiN5ZjCEIqlGB6(llKa01dWnLzDMg,PPVgD9EkhU5x71yvFmpLXuSTZq4,Q4o2IDnNJzcYe,rnsMp6fOH5jxoYVTJQS94adZiCDwc,X9Enu3k5ytGA0Bmxgr1WJjcbv):
	RGDQbxHAi1UpIuNveqTFXSw9gZjc4,aaYDh2EzJ5ky,gC2hO80boRyM7TBGqD,nnPsf4XLIJ7RWF,ggOIGYi4nEAJ2c8hvFufLRBq,NznapDvCteQPx,uHGMxiZfcoErOyXghvnWUK,dGlmU8JqW5yFAtcsg,WtmwkIxcKOZ3rB6PuSHCFL5vGqVo = llKa01dWnLzDMg
	BfMagOvYeRXLbsN = []
	htWEqFMyIHD7zPed3T6xm = j2agIU0xsLS6c7T.getSetting('av.language.translate')
	if htWEqFMyIHD7zPed3T6xm:
		uEpxdOS8BmUv9M3YeiRn,d7d1gqtesRlySZ2hKx,wpZWmc7dzBqLXatS0uI4f = [],[],[]
		if not BfMagOvYeRXLbsN:
			for molgbGArRZv5IhqpjekiXFOtYuVKc in PPVgD9EkhU5x71yvFmpLXuSTZq4:
				aaYDh2EzJ5ky = molgbGArRZv5IhqpjekiXFOtYuVKc['name'].replace(PGLUYu7ySB5gD8b4ZJQq,'').replace(llDwesm6h4YkuLBCKQE8W0JIORoFS,'')
				BlbnqJPAO0eHi = ZXFs0mEPR8qI2zj.findall('^(\[COLOR FFFFFF00\])(\d\d.\d\d) (\d\d.\d\d)(\[/COLOR\]) (.*?)$',aaYDh2EzJ5ky,ZXFs0mEPR8qI2zj.DOTALL)
				if BlbnqJPAO0eHi:
					qzWuPiXcUV3I7D1jGB2R,L4A62wJoa19CrFgITeOdf,HQkVPr8RmTO9c6NICq71au,PZg0OBKQyfwR3uFp,aaYDh2EzJ5ky = BlbnqJPAO0eHi[0]
					BlbnqJPAO0eHi = qzWuPiXcUV3I7D1jGB2R+L4A62wJoa19CrFgITeOdf+' '+HQkVPr8RmTO9c6NICq71au+PZg0OBKQyfwR3uFp+' '
				else:
					BlbnqJPAO0eHi = ZXFs0mEPR8qI2zj.findall('^(.*?) (\[COLOR FFFFFF00\])(\d\d.\d\d) (\d\d.\d\d)(\[/COLOR\])$',aaYDh2EzJ5ky,ZXFs0mEPR8qI2zj.DOTALL)
					if BlbnqJPAO0eHi:
						aaYDh2EzJ5ky,qzWuPiXcUV3I7D1jGB2R,HQkVPr8RmTO9c6NICq71au,L4A62wJoa19CrFgITeOdf,PZg0OBKQyfwR3uFp = BlbnqJPAO0eHi[0]
						BlbnqJPAO0eHi = qzWuPiXcUV3I7D1jGB2R+L4A62wJoa19CrFgITeOdf+' '+HQkVPr8RmTO9c6NICq71au+PZg0OBKQyfwR3uFp+' '
					else: BlbnqJPAO0eHi = ''
				hjTtuHAF3UPKfQSXEJ47pL0an = ZXFs0mEPR8qI2zj.findall('^(.\[COLOR FFC89008\]\w\w\w \[/COLOR\])(.*?)$',aaYDh2EzJ5ky,ZXFs0mEPR8qI2zj.DOTALL)
				if hjTtuHAF3UPKfQSXEJ47pL0an: hjTtuHAF3UPKfQSXEJ47pL0an,aaYDh2EzJ5ky = hjTtuHAF3UPKfQSXEJ47pL0an[0]
				else: hjTtuHAF3UPKfQSXEJ47pL0an = ''
				uEpxdOS8BmUv9M3YeiRn.append(BlbnqJPAO0eHi+hjTtuHAF3UPKfQSXEJ47pL0an)
				d7d1gqtesRlySZ2hKx.append(aaYDh2EzJ5ky)
			wpZWmc7dzBqLXatS0uI4f = picuFCj4o85h0x2VEDt(d7d1gqtesRlySZ2hKx)
			if wpZWmc7dzBqLXatS0uI4f:
				for tdpTaMcz6ZfOUAvx0ByPnLrJob in range(len(PPVgD9EkhU5x71yvFmpLXuSTZq4)):
					molgbGArRZv5IhqpjekiXFOtYuVKc = PPVgD9EkhU5x71yvFmpLXuSTZq4[tdpTaMcz6ZfOUAvx0ByPnLrJob]
					molgbGArRZv5IhqpjekiXFOtYuVKc['name'] = uEpxdOS8BmUv9M3YeiRn[tdpTaMcz6ZfOUAvx0ByPnLrJob]+wpZWmc7dzBqLXatS0uI4f[tdpTaMcz6ZfOUAvx0ByPnLrJob]
					BfMagOvYeRXLbsN.append(molgbGArRZv5IhqpjekiXFOtYuVKc)
	if BfMagOvYeRXLbsN: PPVgD9EkhU5x71yvFmpLXuSTZq4 = BfMagOvYeRXLbsN
	hkIwTLGDSuQjVyC4H0,zQG2Hg95RIJvAPlXBi7Wrb3k,LqWN1d6MnJtROkhpUsIV09e5rfTcK = [],0,0
	eMGc1VHv3yE5bWBrlDOf8a2UnudA = hhHq8m5vauKG9dl.path.join(Po8NVKEkyc30eCS,nnPsf4XLIJ7RWF)
	try: uZFyDcdAh182H0Pxag3In9 = hhHq8m5vauKG9dl.listdir(eMGc1VHv3yE5bWBrlDOf8a2UnudA)
	except:
		try: hhHq8m5vauKG9dl.makedirs(eMGc1VHv3yE5bWBrlDOf8a2UnudA)
		except: pass
		uZFyDcdAh182H0Pxag3In9 = []
	nswXlav41q78pBhD5CEefdG = PVFHCuvJkgdtrsqme('menu_item')
	for molgbGArRZv5IhqpjekiXFOtYuVKc in PPVgD9EkhU5x71yvFmpLXuSTZq4:
		aaYDh2EzJ5ky = molgbGArRZv5IhqpjekiXFOtYuVKc['name']
		PdXj3DIAag2oYJRiO8vmqut = molgbGArRZv5IhqpjekiXFOtYuVKc['context_menu']
		sU4ElPg0XNiJrf9znmcL6vZtK8hdk = molgbGArRZv5IhqpjekiXFOtYuVKc['plot']
		TKQ2HcN1wJ0BLGlgziUrOE8da5p = molgbGArRZv5IhqpjekiXFOtYuVKc['stars']
		ggOIGYi4nEAJ2c8hvFufLRBq = molgbGArRZv5IhqpjekiXFOtYuVKc['image']
		RGDQbxHAi1UpIuNveqTFXSw9gZjc4 = molgbGArRZv5IhqpjekiXFOtYuVKc['type']
		nntqkTFQdC4JgeKWbvj0sORHVz = molgbGArRZv5IhqpjekiXFOtYuVKc['duration']
		NU0VGOPWdgM7wIj = molgbGArRZv5IhqpjekiXFOtYuVKc['isFolder']
		hFOHyplzZXc = molgbGArRZv5IhqpjekiXFOtYuVKc['newpath']
		P8qXJ7lDiyZ3 = kGEPsyxKnHDJ.ListItem(aaYDh2EzJ5ky)
		P8qXJ7lDiyZ3.addContextMenuItems(PdXj3DIAag2oYJRiO8vmqut)
		if ggOIGYi4nEAJ2c8hvFufLRBq: P8qXJ7lDiyZ3.setArt({'icon':ggOIGYi4nEAJ2c8hvFufLRBq,'thumb':ggOIGYi4nEAJ2c8hvFufLRBq,'fanart':ggOIGYi4nEAJ2c8hvFufLRBq,'banner':ggOIGYi4nEAJ2c8hvFufLRBq,'clearart':ggOIGYi4nEAJ2c8hvFufLRBq,'poster':ggOIGYi4nEAJ2c8hvFufLRBq,'clearlogo':ggOIGYi4nEAJ2c8hvFufLRBq,'landscape':ggOIGYi4nEAJ2c8hvFufLRBq})
		else:
			aaYDh2EzJ5ky = YqFHx5cX8apMkfeB(aaYDh2EzJ5ky)
			aaYDh2EzJ5ky = qWMK324ghvjprnZelCTPwFoEIDc(aaYDh2EzJ5ky)
			Asc764JdQnVWNXjyIEh = aaYDh2EzJ5ky+'.png'
			yj4nE0cZHBgXfbT2xM5ovmF3AJN = True
			if Asc764JdQnVWNXjyIEh in uZFyDcdAh182H0Pxag3In9:
				ppoUHyj5cwZdO63W9S = hhHq8m5vauKG9dl.path.join(eMGc1VHv3yE5bWBrlDOf8a2UnudA,Asc764JdQnVWNXjyIEh)
				P8qXJ7lDiyZ3.setArt({'icon':ppoUHyj5cwZdO63W9S,'thumb':ppoUHyj5cwZdO63W9S,'fanart':ppoUHyj5cwZdO63W9S,'banner':ppoUHyj5cwZdO63W9S,'clearart':ppoUHyj5cwZdO63W9S,'poster':ppoUHyj5cwZdO63W9S,'clearlogo':ppoUHyj5cwZdO63W9S,'landscape':ppoUHyj5cwZdO63W9S})
				yj4nE0cZHBgXfbT2xM5ovmF3AJN = False
			elif zQG2Hg95RIJvAPlXBi7Wrb3k<60 and LqWN1d6MnJtROkhpUsIV09e5rfTcK<5:
				ppoUHyj5cwZdO63W9S = hhHq8m5vauKG9dl.path.join(eMGc1VHv3yE5bWBrlDOf8a2UnudA,Asc764JdQnVWNXjyIEh)
				try:
					aFusBSfLRKCeY1gX0tk34d = ccHTfjxq18N2GivAwrUFCK(nswXlav41q78pBhD5CEefdG,'','','','',aaYDh2EzJ5ky,'menu_item','center',False,ppoUHyj5cwZdO63W9S)
					P8qXJ7lDiyZ3.setArt({'icon':ppoUHyj5cwZdO63W9S,'thumb':ppoUHyj5cwZdO63W9S,'fanart':ppoUHyj5cwZdO63W9S,'banner':ppoUHyj5cwZdO63W9S,'clearart':ppoUHyj5cwZdO63W9S,'poster':ppoUHyj5cwZdO63W9S,'clearlogo':ppoUHyj5cwZdO63W9S,'landscape':ppoUHyj5cwZdO63W9S})
					zQG2Hg95RIJvAPlXBi7Wrb3k += 1
					yj4nE0cZHBgXfbT2xM5ovmF3AJN = False
				except: LqWN1d6MnJtROkhpUsIV09e5rfTcK += 1
			if yj4nE0cZHBgXfbT2xM5ovmF3AJN: P8qXJ7lDiyZ3.setArt({'icon':pw80MbNXAgc1s2,'thumb':H8KRdpbwzNPJ6tL,'fanart':lcSEbP6kx5NhfoITZLyq91,'banner':zzqcLFIrpZTvySm9Qkj2YeX8Da3nx,'clearart':SaFiHAzn1JMkLDbvrK,'poster':rJm3aq4Fpj2ZnU0sNMS9wHQf1,'clearlogo':eXGEtqBJ06TCuw,'landscape':iALf3heBoQVRwpg7})
		if V8US2yZAg0QXJebWIHKD5xFa<20:
			if sU4ElPg0XNiJrf9znmcL6vZtK8hdk: P8qXJ7lDiyZ3.setInfo('video',{'Plot':sU4ElPg0XNiJrf9znmcL6vZtK8hdk,'PlotOutline':sU4ElPg0XNiJrf9znmcL6vZtK8hdk})
			if TKQ2HcN1wJ0BLGlgziUrOE8da5p: P8qXJ7lDiyZ3.setInfo('video',{'Rating':TKQ2HcN1wJ0BLGlgziUrOE8da5p})
			if not ggOIGYi4nEAJ2c8hvFufLRBq:
				P8qXJ7lDiyZ3.setInfo('video',{'Title':aaYDh2EzJ5ky})
			if RGDQbxHAi1UpIuNveqTFXSw9gZjc4=='video':
				P8qXJ7lDiyZ3.setInfo('video',{'mediatype':'movie'})
				if nntqkTFQdC4JgeKWbvj0sORHVz: P8qXJ7lDiyZ3.setInfo('video',{'duration':nntqkTFQdC4JgeKWbvj0sORHVz})
				P8qXJ7lDiyZ3.setProperty('IsPlayable','true')
		else:
			AjQmn4lXsTP7Gg1H9FWzdy5qSwO = P8qXJ7lDiyZ3.getVideoInfoTag()
			if TKQ2HcN1wJ0BLGlgziUrOE8da5p: AjQmn4lXsTP7Gg1H9FWzdy5qSwO.setRating(float(TKQ2HcN1wJ0BLGlgziUrOE8da5p))
			if not ggOIGYi4nEAJ2c8hvFufLRBq:
				AjQmn4lXsTP7Gg1H9FWzdy5qSwO.setTitle(aaYDh2EzJ5ky)
			if RGDQbxHAi1UpIuNveqTFXSw9gZjc4=='video':
				AjQmn4lXsTP7Gg1H9FWzdy5qSwO.setMediaType('tvshow')
				if nntqkTFQdC4JgeKWbvj0sORHVz: AjQmn4lXsTP7Gg1H9FWzdy5qSwO.setDuration(nntqkTFQdC4JgeKWbvj0sORHVz)
				P8qXJ7lDiyZ3.setProperty('IsPlayable','true')
		hkIwTLGDSuQjVyC4H0.append((hFOHyplzZXc,P8qXJ7lDiyZ3,NU0VGOPWdgM7wIj))
	pZrEWcFVmiNCjozM.setContent(jVGRimgPZeu9l0dsUoHJ1a,'tvshows')
	TjMnk9Cdc7t = pZrEWcFVmiNCjozM.addDirectoryItems(jVGRimgPZeu9l0dsUoHJ1a,hkIwTLGDSuQjVyC4H0)
	pZrEWcFVmiNCjozM.endOfDirectory(jVGRimgPZeu9l0dsUoHJ1a,Q4o2IDnNJzcYe,rnsMp6fOH5jxoYVTJQS94adZiCDwc,X9Enu3k5ytGA0Bmxgr1WJjcbv)
	return TjMnk9Cdc7t
def Tca7NsYPkIRWtBpFgxLZbSmCi(RGDQbxHAi1UpIuNveqTFXSw9gZjc4,aaYDh2EzJ5ky,gC2hO80boRyM7TBGqD,nnPsf4XLIJ7RWF,ggOIGYi4nEAJ2c8hvFufLRBq='',NznapDvCteQPx='',uHGMxiZfcoErOyXghvnWUK='',dGlmU8JqW5yFAtcsg='',WtmwkIxcKOZ3rB6PuSHCFL5vGqVo={}):
	aaYDh2EzJ5ky = aaYDh2EzJ5ky.replace('\r','').replace('\n','').replace('\t','')
	gC2hO80boRyM7TBGqD = gC2hO80boRyM7TBGqD.replace('\r','').replace('\n','').replace('\t','')
	if '_SCRIPT_' in aaYDh2EzJ5ky: LBtjHDg8yZz69QOp,aaYDh2EzJ5ky = aaYDh2EzJ5ky.split('_SCRIPT_',1)
	else: LBtjHDg8yZz69QOp,aaYDh2EzJ5ky = '',aaYDh2EzJ5ky
	if LBtjHDg8yZz69QOp:
		AUrHYKvByjP = aaYDh2EzJ5ky
		if not AUrHYKvByjP: AUrHYKvByjP = '....'
		elif AUrHYKvByjP.count('_')>1: AUrHYKvByjP = AUrHYKvByjP.split('_',2)[2]
		AUrHYKvByjP = AUrHYKvByjP.replace(' ','')
		AUrHYKvByjP = AUrHYKvByjP.replace('ـ','').replace('ة','ه').replace('ؤ','و')
		AUrHYKvByjP = AUrHYKvByjP.replace('أ','ا').replace('إ','ا').replace('آ','ا')
		AUrHYKvByjP = AUrHYKvByjP.replace('لأ','لا').replace('لإ','لا').replace('لآ','لا')
		AUrHYKvByjP = AUrHYKvByjP.replace('َ','').replace('ً','').replace('ُ','').replace('ٌ','')
		AUrHYKvByjP = AUrHYKvByjP.replace('ِ','').replace('ٍ','').replace('ْ','').replace('ّ','')
		AUrHYKvByjP = AUrHYKvByjP.replace('|','').replace('~','')
		AUrHYKvByjP = AUrHYKvByjP.replace('اون لاين','').replace('سيما لايت','')
		K93GaQpgNEuZfTtykBxICbFM = ['العاب','خيال','البوم','الان','اطفال','حاليه','الغاز','صالح','الدين','مواليد','العالم','اعمال']
		if not any(pnhqzFt6AOer1xoR4jUJ in AUrHYKvByjP for pnhqzFt6AOer1xoR4jUJ in K93GaQpgNEuZfTtykBxICbFM): AUrHYKvByjP = AUrHYKvByjP.replace('ال','')
		AUrHYKvByjP = AUrHYKvByjP.replace('اخري','اخرى').replace('اجنبى','اجنبي').replace('عائليه','عائلي')
		AUrHYKvByjP = AUrHYKvByjP.replace('اجنبيه','اجنبي').replace('عربيه','عربي').replace('رومانسيه','رومانسي')
		AUrHYKvByjP = AUrHYKvByjP.replace('غربيه','غربي').replace('و مسلسلات','مسلسلات').replace('اغانى','اغاني')
		AUrHYKvByjP = AUrHYKvByjP.replace('تاريخي','تاريخ').replace('خيال علمي','خيال').replace('موسيقيه','موسيقى')
		AUrHYKvByjP = AUrHYKvByjP.replace('هندى','هندي').replace('هنديه','هندي').replace('وثائقيه','وثائقي')
		AUrHYKvByjP = AUrHYKvByjP.replace('تليفزيونيه','تلفزيون').replace('تلفزيونيه','تلفزيون').replace('و كرتون','وكرتون')
		AUrHYKvByjP = AUrHYKvByjP.replace('الحاليه','حاليه').replace('موسیقي','موسيقى').replace('الانمي','انمي')
		AUrHYKvByjP = AUrHYKvByjP.replace('المسلسلات','مسلسلات').replace('البرامج','برامج').replace('كارتون','كرتون')
		AUrHYKvByjP = AUrHYKvByjP.replace('حروب','حرب').replace('الاناشيد','اناشيد').replace('اسيويه','اسيوي')
		AUrHYKvByjP = AUrHYKvByjP.replace('عربى','عربي').replace('تركى','تركي').replace('تركيه','تركي')
		AUrHYKvByjP = AUrHYKvByjP.replace('رياضي','رياضة').replace('رياضه','رياضة').replace('اسيويه','اسيوي')
		AUrHYKvByjP = AUrHYKvByjP.replace('كوميدى','كوميدي').replace('كوميديه','كوميدي').replace('انيمي','انمي')
		AUrHYKvByjP = AUrHYKvByjP.replace('انيميشن','انميشن').replace('انمى','انميشن').replace('انمي','انميشن')
		AUrHYKvByjP = AUrHYKvByjP.replace('انميشنشن','انميشن').replace('الانميشن','انميشن').replace('افلام مسلسلات','افلام ومسلسلات')
		AUrHYKvByjP = AUrHYKvByjP.replace('  ',' ').strip(' ')
		LBtjHDg8yZz69QOp = '_LST_'+Po4CyOusDaWq6pbIjYV(LBtjHDg8yZz69QOp)
		if AUrHYKvByjP not in list(YLg3diKrRb61pkP08hJBZNEsXlvA.keys()): YLg3diKrRb61pkP08hJBZNEsXlvA[AUrHYKvByjP] = {}
		YLg3diKrRb61pkP08hJBZNEsXlvA[AUrHYKvByjP][LBtjHDg8yZz69QOp] = [RGDQbxHAi1UpIuNveqTFXSw9gZjc4,aaYDh2EzJ5ky,gC2hO80boRyM7TBGqD,nnPsf4XLIJ7RWF,ggOIGYi4nEAJ2c8hvFufLRBq,NznapDvCteQPx,uHGMxiZfcoErOyXghvnWUK,dGlmU8JqW5yFAtcsg,WtmwkIxcKOZ3rB6PuSHCFL5vGqVo]
	OWasmQ27g3Dbljpo.append([RGDQbxHAi1UpIuNveqTFXSw9gZjc4,aaYDh2EzJ5ky,gC2hO80boRyM7TBGqD,nnPsf4XLIJ7RWF,ggOIGYi4nEAJ2c8hvFufLRBq,NznapDvCteQPx,uHGMxiZfcoErOyXghvnWUK,dGlmU8JqW5yFAtcsg,WtmwkIxcKOZ3rB6PuSHCFL5vGqVo])
	return
def qpob7TvxHSs4fEzO6(qHyVMt2d6YfTzixS):
	if VYMZsxRpcQHPgkaiDKjyoh: from html import unescape as _VmdfNezCATwcKhO9P1G
	else:
		from HTMLParser import HTMLParser as CIGUx8HO3FTXQ5M
		_VmdfNezCATwcKhO9P1G = CIGUx8HO3FTXQ5M().unescape
	if '&' in qHyVMt2d6YfTzixS and ';' in qHyVMt2d6YfTzixS:
		if Yd6t3PjlLKk: qHyVMt2d6YfTzixS = qHyVMt2d6YfTzixS.decode('utf8')
		qHyVMt2d6YfTzixS = _VmdfNezCATwcKhO9P1G(qHyVMt2d6YfTzixS)
		if Yd6t3PjlLKk: qHyVMt2d6YfTzixS = qHyVMt2d6YfTzixS.encode('utf8')
	return qHyVMt2d6YfTzixS
def WhJe7bGx5XackTwOIZVLC8ut(qHyVMt2d6YfTzixS):
	if '\\u' in qHyVMt2d6YfTzixS:
		if Yd6t3PjlLKk: qHyVMt2d6YfTzixS = qHyVMt2d6YfTzixS.decode('unicode_escape','ignore').encode('utf8')
		elif VYMZsxRpcQHPgkaiDKjyoh: qHyVMt2d6YfTzixS = qHyVMt2d6YfTzixS.encode('utf8').decode('unicode_escape','ignore')
	return qHyVMt2d6YfTzixS
def MFGPCcLwzSV(RAqmWvstLXUTFoKlI6,BBy2EGjbrXVwY,SL8kjKMb5xp4QOutz,HOh4beAYoDiC5TSv,uHGMxiZfcoErOyXghvnWUK,LlXhYevk6WFCyqgPui84d,mmn6210JSBzyVRsTLPMtHGircQFEC,rAVPCBezxQiFof4S73dcLtKIj,WrQZLoxGPTIKfv94Blyk73VdwhR):
	kamRKz49pb6d8cE = PVFHCuvJkgdtrsqme(LlXhYevk6WFCyqgPui84d)
	aFusBSfLRKCeY1gX0tk34d = ccHTfjxq18N2GivAwrUFCK(kamRKz49pb6d8cE,RAqmWvstLXUTFoKlI6,BBy2EGjbrXVwY,SL8kjKMb5xp4QOutz,HOh4beAYoDiC5TSv,uHGMxiZfcoErOyXghvnWUK,LlXhYevk6WFCyqgPui84d,mmn6210JSBzyVRsTLPMtHGircQFEC,rAVPCBezxQiFof4S73dcLtKIj,WrQZLoxGPTIKfv94Blyk73VdwhR)
	return aFusBSfLRKCeY1gX0tk34d
def PVFHCuvJkgdtrsqme(LlXhYevk6WFCyqgPui84d):
	ssVGq6CEDlket9j1oUZXMWrA = 5
	SQIWwn945ZKb7N3Akm = 20
	L9mb4velwpujaQdJhqVP6RK = 20
	Flf6gWoGhBXynM97bmT8eNZOD5uE = 0
	avkU4zlCXcLwAxW2JoiRtENqP = 'center'
	l9PULAQv1aXbim4Er = 0
	IGzEH649xZwh8Mq5CejAuOQkD = 19
	k1bi40YKwN = 30
	ZcQpsEDfeG5 = 8
	qpn1yJcY9AIVGR3aN2E6HW5Pk = True
	LNuQgA8DtmIKSsW30wP = 375
	dKTJz7ARGLw3bEPVtNe2Hqav5p = 410
	PA8ON7cUiTBItEmkdX9SF1D64ar5KL = 50
	bTkNe2B4Kf = 280
	E3NAOfeckTyo0i2WB7tFD8dK = 28
	llC5EIaR4YjdKnDbJwhp7P2 = 5
	ihC6OBoenFkwVL53Xzb = 0
	ru67ZVDkdWi1XzeybgB3qNAv0oL = 31
	F2C5jUTlZyIK3isHPJgqzRf = [36,32,28]
	if LlXhYevk6WFCyqgPui84d in ['notification','notification_twohalfs']:
		if LlXhYevk6WFCyqgPui84d=='notification_twohalfs':
			ClyH3eLNbgij1r5aYE9IZ4,UNgpwAhkrvRW21HE5DzT7li = 'UPPER',720
			avkU4zlCXcLwAxW2JoiRtENqP = 'right'
			qpn1yJcY9AIVGR3aN2E6HW5Pk = True
			Flf6gWoGhBXynM97bmT8eNZOD5uE = 10
		else:
			ClyH3eLNbgij1r5aYE9IZ4,UNgpwAhkrvRW21HE5DzT7li = 97+20,720
			avkU4zlCXcLwAxW2JoiRtENqP = 'left'
			qpn1yJcY9AIVGR3aN2E6HW5Pk = False
		F2C5jUTlZyIK3isHPJgqzRf = [33,33,33]
		L9mb4velwpujaQdJhqVP6RK = 20
		SQIWwn945ZKb7N3Akm = 0
		k1bi40YKwN = 20
		IGzEH649xZwh8Mq5CejAuOQkD = 25+10
	elif LlXhYevk6WFCyqgPui84d=='menu_item':
		F2C5jUTlZyIK3isHPJgqzRf,ClyH3eLNbgij1r5aYE9IZ4,UNgpwAhkrvRW21HE5DzT7li = [48,44,40],200,400
		k1bi40YKwN,IGzEH649xZwh8Mq5CejAuOQkD,SQIWwn945ZKb7N3Akm = 0,0,-16
		eH1tbCELifusKYrOIpPxGXwZTacl = MfgOeR2YHEWhp.open(vhILp70VsMPBjG3Wb1OiZqCT)
		j189CMmbgVAZYRdo6TSlEfK4N = MfgOeR2YHEWhp.new('RGBA',(200,200),(255,0,0,255))
	elif LlXhYevk6WFCyqgPui84d=='confirm_smallfont': F2C5jUTlZyIK3isHPJgqzRf,ClyH3eLNbgij1r5aYE9IZ4,UNgpwAhkrvRW21HE5DzT7li = [28,24,20],500,900
	elif LlXhYevk6WFCyqgPui84d=='confirm_mediumfont': F2C5jUTlZyIK3isHPJgqzRf,ClyH3eLNbgij1r5aYE9IZ4,UNgpwAhkrvRW21HE5DzT7li = [32,28,24],500,900
	elif LlXhYevk6WFCyqgPui84d=='confirm_bigfont': F2C5jUTlZyIK3isHPJgqzRf,ClyH3eLNbgij1r5aYE9IZ4,UNgpwAhkrvRW21HE5DzT7li = [36,32,28],500,900
	elif LlXhYevk6WFCyqgPui84d=='textview_bigfont': ClyH3eLNbgij1r5aYE9IZ4,UNgpwAhkrvRW21HE5DzT7li = 740,1270
	elif LlXhYevk6WFCyqgPui84d=='textview_bigfont_long': ClyH3eLNbgij1r5aYE9IZ4,UNgpwAhkrvRW21HE5DzT7li = 'UPPER',1270
	elif LlXhYevk6WFCyqgPui84d=='textview_smallfont': F2C5jUTlZyIK3isHPJgqzRf,ClyH3eLNbgij1r5aYE9IZ4,UNgpwAhkrvRW21HE5DzT7li = [28,23,18],740,1270
	elif LlXhYevk6WFCyqgPui84d=='textview_smallfont_long': F2C5jUTlZyIK3isHPJgqzRf,ClyH3eLNbgij1r5aYE9IZ4,UNgpwAhkrvRW21HE5DzT7li = [28,23,18],'UPPER',1270
	bVqp1jDudval = F2C5jUTlZyIK3isHPJgqzRf[0]
	gunD5bKZeWJqvcHmMNRCjih = F2C5jUTlZyIK3isHPJgqzRf[1]
	CCOGT1o8WlwhI = F2C5jUTlZyIK3isHPJgqzRf[2]
	w9iKh03A8vV = zIdYyOpmXEar2RLH.truetype(I0kWLGvRgTPyNq75uaKxB6eDC9,size=bVqp1jDudval)
	J0rZVNxABk3loLDCdG = zIdYyOpmXEar2RLH.truetype(I0kWLGvRgTPyNq75uaKxB6eDC9,size=gunD5bKZeWJqvcHmMNRCjih)
	ZZylHvkjmMNLJtgr3n2uVT = zIdYyOpmXEar2RLH.truetype(I0kWLGvRgTPyNq75uaKxB6eDC9,size=CCOGT1o8WlwhI)
	qq2T3pO68V7syISu = MfgOeR2YHEWhp.new('RGBA',(100,100),(255,255,255,0))
	CGgJ1b9m83BAkorRX62I = ppq7nbP8zdkSt20aCVK3rY9.Draw(qq2T3pO68V7syISu)
	IejOpnNz28ERPuQxqFB4m0tobM5Ld,si8AGTB7yU3rdzth2 = CGgJ1b9m83BAkorRX62I.textsize('HHH BBB 888 000',font=J0rZVNxABk3loLDCdG)
	JpDQCkauPctLh,GfBMnDTVkvoNXRzmE3 = CGgJ1b9m83BAkorRX62I.textsize('HHH BBB 888 000',font=w9iKh03A8vV)
	CO4elrd2AcpRsG5VZH70UMP = {'delete_harakat':False,'support_ligatures':True,'ARABIC LIGATURE ALLAH':False}
	PxQfShXI7Z9KvLq3Vlt68 = r2GOwLkB5Wmasb6EhogVCt1(configuration=CO4elrd2AcpRsG5VZH70UMP)
	kamRKz49pb6d8cE = {}
	qJod17tKgBpYaGHbIjPlCxzSZ = locals()
	for JDv1uYxBEPcFGwrmlfzSOC in qJod17tKgBpYaGHbIjPlCxzSZ: kamRKz49pb6d8cE[JDv1uYxBEPcFGwrmlfzSOC] = qJod17tKgBpYaGHbIjPlCxzSZ[JDv1uYxBEPcFGwrmlfzSOC]
	return kamRKz49pb6d8cE
def ccHTfjxq18N2GivAwrUFCK(kamRKz49pb6d8cE,RAqmWvstLXUTFoKlI6,BBy2EGjbrXVwY,SL8kjKMb5xp4QOutz,HOh4beAYoDiC5TSv,uHGMxiZfcoErOyXghvnWUK,LlXhYevk6WFCyqgPui84d,mmn6210JSBzyVRsTLPMtHGircQFEC,rAVPCBezxQiFof4S73dcLtKIj,WrQZLoxGPTIKfv94Blyk73VdwhR):
	for JDv1uYxBEPcFGwrmlfzSOC in kamRKz49pb6d8cE: globals()[JDv1uYxBEPcFGwrmlfzSOC] = kamRKz49pb6d8cE[JDv1uYxBEPcFGwrmlfzSOC]
	global E3NAOfeckTyo0i2WB7tFD8dK,llC5EIaR4YjdKnDbJwhp7P2
	htWEqFMyIHD7zPed3T6xm = j2agIU0xsLS6c7T.getSetting('av.language.translate')
	if htWEqFMyIHD7zPed3T6xm:
		if RAqmWvstLXUTFoKlI6=='نعم  Yes': RAqmWvstLXUTFoKlI6 = 'Yes'
		elif RAqmWvstLXUTFoKlI6=='كلا  No': RAqmWvstLXUTFoKlI6 = 'No'
		if BBy2EGjbrXVwY=='نعم  Yes': BBy2EGjbrXVwY = 'Yes'
		elif BBy2EGjbrXVwY=='كلا  No': BBy2EGjbrXVwY = 'No'
		if SL8kjKMb5xp4QOutz=='نعم  Yes': SL8kjKMb5xp4QOutz = 'Yes'
		elif SL8kjKMb5xp4QOutz=='كلا  No': SL8kjKMb5xp4QOutz = 'No'
		RqIMxSdNAFb7P = picuFCj4o85h0x2VEDt([RAqmWvstLXUTFoKlI6,BBy2EGjbrXVwY,SL8kjKMb5xp4QOutz,HOh4beAYoDiC5TSv,uHGMxiZfcoErOyXghvnWUK])
		if RqIMxSdNAFb7P: RAqmWvstLXUTFoKlI6,BBy2EGjbrXVwY,SL8kjKMb5xp4QOutz,HOh4beAYoDiC5TSv,uHGMxiZfcoErOyXghvnWUK = RqIMxSdNAFb7P
	if Yd6t3PjlLKk:
		uHGMxiZfcoErOyXghvnWUK = uHGMxiZfcoErOyXghvnWUK.decode('utf8')
		HOh4beAYoDiC5TSv = HOh4beAYoDiC5TSv.decode('utf8')
		RAqmWvstLXUTFoKlI6 = RAqmWvstLXUTFoKlI6.decode('utf8')
		BBy2EGjbrXVwY = BBy2EGjbrXVwY.decode('utf8')
		SL8kjKMb5xp4QOutz = SL8kjKMb5xp4QOutz.decode('utf8')
	oM4ehwpRXnOEDB1xscTNvLy9K = HOh4beAYoDiC5TSv.count('\n')+1
	f6A5at7rDivT8YCN0dpKqcyJL1wOB = SQIWwn945ZKb7N3Akm+oM4ehwpRXnOEDB1xscTNvLy9K*(GfBMnDTVkvoNXRzmE3+Flf6gWoGhBXynM97bmT8eNZOD5uE)-Flf6gWoGhBXynM97bmT8eNZOD5uE
	if uHGMxiZfcoErOyXghvnWUK:
		mDBs9je6frkuPHx = UNgpwAhkrvRW21HE5DzT7li-k1bi40YKwN*2
		xLiBD6WZcIUf5gkq8G31zmHbl = si8AGTB7yU3rdzth2+ZcQpsEDfeG5
		JJytrHURDYugXoKEZB74QWF = PxQfShXI7Z9KvLq3Vlt68.reshape(uHGMxiZfcoErOyXghvnWUK)
		if qpn1yJcY9AIVGR3aN2E6HW5Pk:
			HS2mIoztnqA7jb46pPvfuaL3FkD = Gh6b42sgaTK(JJytrHURDYugXoKEZB74QWF,gunD5bKZeWJqvcHmMNRCjih,mDBs9je6frkuPHx,xLiBD6WZcIUf5gkq8G31zmHbl)
			DGwObQZFU2eYvgK6km5tHIaLoBR = vU7CRs6grqktaJzOW2n(HS2mIoztnqA7jb46pPvfuaL3FkD)
			tjk3n4eODAx8PoB1f5zrmbNHFd = DGwObQZFU2eYvgK6km5tHIaLoBR.count('\n')+1
			if tjk3n4eODAx8PoB1f5zrmbNHFd<6:
				doX76SNKAIgwUZLzjkcW4RaO8JHyt = mDBs9je6frkuPHx
				HS2mIoztnqA7jb46pPvfuaL3FkD = Gh6b42sgaTK(JJytrHURDYugXoKEZB74QWF,gunD5bKZeWJqvcHmMNRCjih,doX76SNKAIgwUZLzjkcW4RaO8JHyt,xLiBD6WZcIUf5gkq8G31zmHbl)
				DGwObQZFU2eYvgK6km5tHIaLoBR = vU7CRs6grqktaJzOW2n(HS2mIoztnqA7jb46pPvfuaL3FkD)
				tjk3n4eODAx8PoB1f5zrmbNHFd = DGwObQZFU2eYvgK6km5tHIaLoBR.count('\n')+1
			IvDzaF923JZBUxy = IGzEH649xZwh8Mq5CejAuOQkD+tjk3n4eODAx8PoB1f5zrmbNHFd*xLiBD6WZcIUf5gkq8G31zmHbl-ZcQpsEDfeG5
		else:
			IvDzaF923JZBUxy = IGzEH649xZwh8Mq5CejAuOQkD+si8AGTB7yU3rdzth2
			DGwObQZFU2eYvgK6km5tHIaLoBR = JJytrHURDYugXoKEZB74QWF.split('\n')[0]
			HS2mIoztnqA7jb46pPvfuaL3FkD = JJytrHURDYugXoKEZB74QWF.split('\n')[0]
	else: IvDzaF923JZBUxy = IGzEH649xZwh8Mq5CejAuOQkD
	PM5xuoX4CzWHI9Ty = ihC6OBoenFkwVL53Xzb+ru67ZVDkdWi1XzeybgB3qNAv0oL
	if rAVPCBezxQiFof4S73dcLtKIj:
		Mm9ZQaRs1I = dKTJz7ARGLw3bEPVtNe2Hqav5p-LNuQgA8DtmIKSsW30wP
		PM5xuoX4CzWHI9Ty += Mm9ZQaRs1I
	else: Mm9ZQaRs1I = 0
	if RAqmWvstLXUTFoKlI6 or BBy2EGjbrXVwY or SL8kjKMb5xp4QOutz: PM5xuoX4CzWHI9Ty += PA8ON7cUiTBItEmkdX9SF1D64ar5KL
	if ClyH3eLNbgij1r5aYE9IZ4!='UPPER': aFusBSfLRKCeY1gX0tk34d = ClyH3eLNbgij1r5aYE9IZ4
	else: aFusBSfLRKCeY1gX0tk34d = f6A5at7rDivT8YCN0dpKqcyJL1wOB+IvDzaF923JZBUxy+PM5xuoX4CzWHI9Ty
	WK2gBe0Vcj = aFusBSfLRKCeY1gX0tk34d-f6A5at7rDivT8YCN0dpKqcyJL1wOB-PM5xuoX4CzWHI9Ty-IGzEH649xZwh8Mq5CejAuOQkD
	qq2T3pO68V7syISu = MfgOeR2YHEWhp.new('RGBA',(UNgpwAhkrvRW21HE5DzT7li,aFusBSfLRKCeY1gX0tk34d),(255,255,255,0))
	CGgJ1b9m83BAkorRX62I = ppq7nbP8zdkSt20aCVK3rY9.Draw(qq2T3pO68V7syISu)
	if not BBy2EGjbrXVwY and RAqmWvstLXUTFoKlI6 and SL8kjKMb5xp4QOutz:
		E3NAOfeckTyo0i2WB7tFD8dK += 105
		llC5EIaR4YjdKnDbJwhp7P2 -= 110
	if HOh4beAYoDiC5TSv:
		VVUhWyQ8RNZzFfocY0gM4mKHJ = SQIWwn945ZKb7N3Akm
		HOh4beAYoDiC5TSv = hBvy1ernIGgsxCc4bSJMEjQXuLU.get_display(PxQfShXI7Z9KvLq3Vlt68.reshape(HOh4beAYoDiC5TSv))
		dUkqersWvMoJ964 = HOh4beAYoDiC5TSv.splitlines()
		for FFhKw05es4jgM in dUkqersWvMoJ964:
			if FFhKw05es4jgM:
				YYpKqfFxb290n,YWUZV6tyBsqdPbCfj4Q = CGgJ1b9m83BAkorRX62I.textsize(FFhKw05es4jgM,font=w9iKh03A8vV)
				if avkU4zlCXcLwAxW2JoiRtENqP=='center': Rvqxk8NIEd5Y01frt2gD9lGa6AMUBW = ssVGq6CEDlket9j1oUZXMWrA+(UNgpwAhkrvRW21HE5DzT7li-YYpKqfFxb290n)/2
				elif avkU4zlCXcLwAxW2JoiRtENqP=='right': Rvqxk8NIEd5Y01frt2gD9lGa6AMUBW = ssVGq6CEDlket9j1oUZXMWrA+UNgpwAhkrvRW21HE5DzT7li-YYpKqfFxb290n-L9mb4velwpujaQdJhqVP6RK
				elif avkU4zlCXcLwAxW2JoiRtENqP=='left': Rvqxk8NIEd5Y01frt2gD9lGa6AMUBW = ssVGq6CEDlket9j1oUZXMWrA+L9mb4velwpujaQdJhqVP6RK
				CGgJ1b9m83BAkorRX62I.text((Rvqxk8NIEd5Y01frt2gD9lGa6AMUBW,VVUhWyQ8RNZzFfocY0gM4mKHJ),FFhKw05es4jgM,font=w9iKh03A8vV,fill='yellow')
			VVUhWyQ8RNZzFfocY0gM4mKHJ += bVqp1jDudval+Flf6gWoGhBXynM97bmT8eNZOD5uE
	if RAqmWvstLXUTFoKlI6 or BBy2EGjbrXVwY or SL8kjKMb5xp4QOutz:
		xwYS3bRPTfEmZBAyMHU8FW2kN = f6A5at7rDivT8YCN0dpKqcyJL1wOB+WK2gBe0Vcj+IGzEH649xZwh8Mq5CejAuOQkD+Mm9ZQaRs1I+ihC6OBoenFkwVL53Xzb
		if RAqmWvstLXUTFoKlI6:
			RAqmWvstLXUTFoKlI6 = hBvy1ernIGgsxCc4bSJMEjQXuLU.get_display(PxQfShXI7Z9KvLq3Vlt68.reshape(RAqmWvstLXUTFoKlI6))
			vvMTQFLndCa4pBGmZ2W6ocxE,KKnyvPdA362HfCEmlkaDQG = CGgJ1b9m83BAkorRX62I.textsize(RAqmWvstLXUTFoKlI6,font=ZZylHvkjmMNLJtgr3n2uVT)
			MGA9F6HnOp4vsJZ = E3NAOfeckTyo0i2WB7tFD8dK+0*(llC5EIaR4YjdKnDbJwhp7P2+bTkNe2B4Kf)+(bTkNe2B4Kf-vvMTQFLndCa4pBGmZ2W6ocxE)/2
			CGgJ1b9m83BAkorRX62I.text((MGA9F6HnOp4vsJZ,xwYS3bRPTfEmZBAyMHU8FW2kN),RAqmWvstLXUTFoKlI6,font=ZZylHvkjmMNLJtgr3n2uVT,fill='yellow')
		if BBy2EGjbrXVwY:
			BBy2EGjbrXVwY = hBvy1ernIGgsxCc4bSJMEjQXuLU.get_display(PxQfShXI7Z9KvLq3Vlt68.reshape(BBy2EGjbrXVwY))
			QTXzJAI4MFkd5jltnBPY,Y8gVADIKpcOHiQel5 = CGgJ1b9m83BAkorRX62I.textsize(BBy2EGjbrXVwY,font=ZZylHvkjmMNLJtgr3n2uVT)
			klbu2Nio65atHT = E3NAOfeckTyo0i2WB7tFD8dK+1*(llC5EIaR4YjdKnDbJwhp7P2+bTkNe2B4Kf)+(bTkNe2B4Kf-QTXzJAI4MFkd5jltnBPY)/2
			CGgJ1b9m83BAkorRX62I.text((klbu2Nio65atHT,xwYS3bRPTfEmZBAyMHU8FW2kN),BBy2EGjbrXVwY,font=ZZylHvkjmMNLJtgr3n2uVT,fill='yellow')
		if SL8kjKMb5xp4QOutz:
			SL8kjKMb5xp4QOutz = hBvy1ernIGgsxCc4bSJMEjQXuLU.get_display(PxQfShXI7Z9KvLq3Vlt68.reshape(SL8kjKMb5xp4QOutz))
			SXypLFs187,K0Wl2tjEcT1meorbYRwiuOLpkC = CGgJ1b9m83BAkorRX62I.textsize(SL8kjKMb5xp4QOutz,font=ZZylHvkjmMNLJtgr3n2uVT)
			s9PZAQWM3v5Bz = E3NAOfeckTyo0i2WB7tFD8dK+2*(llC5EIaR4YjdKnDbJwhp7P2+bTkNe2B4Kf)+(bTkNe2B4Kf-SXypLFs187)/2
			CGgJ1b9m83BAkorRX62I.text((s9PZAQWM3v5Bz,xwYS3bRPTfEmZBAyMHU8FW2kN),SL8kjKMb5xp4QOutz,font=ZZylHvkjmMNLJtgr3n2uVT,fill='yellow')
	if uHGMxiZfcoErOyXghvnWUK:
		ygB5ZwC6q4leXzAIJi,rDWjPpockF4tCMVmGSxnbf2lX7A = [],[]
		HS2mIoztnqA7jb46pPvfuaL3FkD = XRcrTbQ5hPspnol6YOe0j(HS2mIoztnqA7jb46pPvfuaL3FkD)
		SUGnAz5wOi = HS2mIoztnqA7jb46pPvfuaL3FkD.split('_sss__newline_')
		for dd5oIxecpOlt1VszSawbJMihq in SUGnAz5wOi:
			unTbpsg9cR = mmn6210JSBzyVRsTLPMtHGircQFEC
			if   '_sss__lineleft_' in dd5oIxecpOlt1VszSawbJMihq: unTbpsg9cR = 'left'
			elif '_sss__lineright_' in dd5oIxecpOlt1VszSawbJMihq: unTbpsg9cR = 'right'
			elif '_sss__linecenter_' in dd5oIxecpOlt1VszSawbJMihq: unTbpsg9cR = 'center'
			eerDMURGAOKFvwh6s23uXdtIW = dd5oIxecpOlt1VszSawbJMihq
			YU3Z8dKf0uNjSwE4 = ZXFs0mEPR8qI2zj.findall('_sss__.*?_',dd5oIxecpOlt1VszSawbJMihq,ZXFs0mEPR8qI2zj.DOTALL)
			for AAxKJH3sp2NUZmiOSTfIBdcFl1btP in YU3Z8dKf0uNjSwE4: eerDMURGAOKFvwh6s23uXdtIW = eerDMURGAOKFvwh6s23uXdtIW.replace(AAxKJH3sp2NUZmiOSTfIBdcFl1btP,'')
			if eerDMURGAOKFvwh6s23uXdtIW=='': YYpKqfFxb290n,YWUZV6tyBsqdPbCfj4Q = 0,xLiBD6WZcIUf5gkq8G31zmHbl
			else: YYpKqfFxb290n,YWUZV6tyBsqdPbCfj4Q = CGgJ1b9m83BAkorRX62I.textsize(eerDMURGAOKFvwh6s23uXdtIW,font=J0rZVNxABk3loLDCdG)
			if   unTbpsg9cR=='left': re2qFupHnDyJf4z6dPZjSKB8 = l9PULAQv1aXbim4Er+k1bi40YKwN
			elif unTbpsg9cR=='right': re2qFupHnDyJf4z6dPZjSKB8 = l9PULAQv1aXbim4Er+k1bi40YKwN+mDBs9je6frkuPHx-YYpKqfFxb290n
			elif unTbpsg9cR=='center': re2qFupHnDyJf4z6dPZjSKB8 = l9PULAQv1aXbim4Er+k1bi40YKwN+(mDBs9je6frkuPHx-YYpKqfFxb290n)/2
			if re2qFupHnDyJf4z6dPZjSKB8<k1bi40YKwN: re2qFupHnDyJf4z6dPZjSKB8 = l9PULAQv1aXbim4Er+k1bi40YKwN
			ygB5ZwC6q4leXzAIJi.append(re2qFupHnDyJf4z6dPZjSKB8)
			rDWjPpockF4tCMVmGSxnbf2lX7A.append(YYpKqfFxb290n)
		re2qFupHnDyJf4z6dPZjSKB8 = ygB5ZwC6q4leXzAIJi[0]
		Uzv5NIV7OGpWDE = HS2mIoztnqA7jb46pPvfuaL3FkD.split('_sss_')
		FAlc16afK7J9xdHYEsGthv3T5p = (255,255,255,255)
		KHnUIzyoAmcfZs9hNRg8JuXQ0Yxrb7 = FAlc16afK7J9xdHYEsGthv3T5p
		H3HSFTGrqXbBLKfOMYWEwvhul,W3TDs4fGNQlAItMk2oCx = 0,0
		UD8PrkcZunAKXb0Ew6zqh75FYSyTCo = False
		XIxP1SdcJiTH2OZA0Dvk8EM = 0
		J0hqPiLxBXw7MjdmFEk3Uybt2C1l = f6A5at7rDivT8YCN0dpKqcyJL1wOB+IGzEH649xZwh8Mq5CejAuOQkD/2
		if IvDzaF923JZBUxy<(WK2gBe0Vcj+IGzEH649xZwh8Mq5CejAuOQkD):
			ZWdMyxkcCz4OYwsqUvJIHa6 = (WK2gBe0Vcj+IGzEH649xZwh8Mq5CejAuOQkD-IvDzaF923JZBUxy)/2
			J0hqPiLxBXw7MjdmFEk3Uybt2C1l = f6A5at7rDivT8YCN0dpKqcyJL1wOB+IGzEH649xZwh8Mq5CejAuOQkD+ZWdMyxkcCz4OYwsqUvJIHa6-si8AGTB7yU3rdzth2/2
		for FFhKw05es4jgM in Uzv5NIV7OGpWDE:
			if not FFhKw05es4jgM or (FFhKw05es4jgM and ord(FFhKw05es4jgM[0])==65279): continue
			kX7eFZfU5umlvDS9M = FFhKw05es4jgM.split('_newline_',1)
			T31rQV9BRJc5HYUleCEMdO = FFhKw05es4jgM.split('_newcolor',1)
			L3PylF4MxS1 = FFhKw05es4jgM.split('_endcolor_',1)
			eD7CoQRJH0E = FFhKw05es4jgM.split('_linertl_',1)
			gz2AwSkrNW = FFhKw05es4jgM.split('_lineleft_',1)
			qLbSP5NUcrtwnT7xsHJ9 = FFhKw05es4jgM.split('_lineright_',1)
			dDrI1uMW57q6ASz8vy = FFhKw05es4jgM.split('_linecenter_',1)
			if len(kX7eFZfU5umlvDS9M)>1:
				XIxP1SdcJiTH2OZA0Dvk8EM += 1
				FFhKw05es4jgM = kX7eFZfU5umlvDS9M[1]
				H3HSFTGrqXbBLKfOMYWEwvhul = 0
				re2qFupHnDyJf4z6dPZjSKB8 = ygB5ZwC6q4leXzAIJi[XIxP1SdcJiTH2OZA0Dvk8EM]
				W3TDs4fGNQlAItMk2oCx += xLiBD6WZcIUf5gkq8G31zmHbl
				UD8PrkcZunAKXb0Ew6zqh75FYSyTCo = False
			elif len(T31rQV9BRJc5HYUleCEMdO)>1:
				FFhKw05es4jgM = T31rQV9BRJc5HYUleCEMdO[1]
				KHnUIzyoAmcfZs9hNRg8JuXQ0Yxrb7 = FFhKw05es4jgM[0:8]
				KHnUIzyoAmcfZs9hNRg8JuXQ0Yxrb7 = '#'+KHnUIzyoAmcfZs9hNRg8JuXQ0Yxrb7[2:]
				FFhKw05es4jgM = FFhKw05es4jgM[9:]
			elif len(L3PylF4MxS1)>1:
				FFhKw05es4jgM = L3PylF4MxS1[1]
				KHnUIzyoAmcfZs9hNRg8JuXQ0Yxrb7 = FAlc16afK7J9xdHYEsGthv3T5p
			elif len(eD7CoQRJH0E)>1:
				FFhKw05es4jgM = eD7CoQRJH0E[1]
				UD8PrkcZunAKXb0Ew6zqh75FYSyTCo = True
				H3HSFTGrqXbBLKfOMYWEwvhul = rDWjPpockF4tCMVmGSxnbf2lX7A[XIxP1SdcJiTH2OZA0Dvk8EM]
			elif len(gz2AwSkrNW)>1: FFhKw05es4jgM = gz2AwSkrNW[1]
			elif len(qLbSP5NUcrtwnT7xsHJ9)>1: FFhKw05es4jgM = qLbSP5NUcrtwnT7xsHJ9[1]
			elif len(dDrI1uMW57q6ASz8vy)>1: FFhKw05es4jgM = dDrI1uMW57q6ASz8vy[1]
			if FFhKw05es4jgM:
				Mxe2H5cYKSDXQzTj0snELfG = J0hqPiLxBXw7MjdmFEk3Uybt2C1l+W3TDs4fGNQlAItMk2oCx
				FFhKw05es4jgM = hBvy1ernIGgsxCc4bSJMEjQXuLU.get_display(FFhKw05es4jgM)
				YYpKqfFxb290n,YWUZV6tyBsqdPbCfj4Q = CGgJ1b9m83BAkorRX62I.textsize(FFhKw05es4jgM,font=J0rZVNxABk3loLDCdG)
				if UD8PrkcZunAKXb0Ew6zqh75FYSyTCo: H3HSFTGrqXbBLKfOMYWEwvhul -= YYpKqfFxb290n
				pFg3ovZTfMe9i5ncUqkEYPlQsHB = re2qFupHnDyJf4z6dPZjSKB8+H3HSFTGrqXbBLKfOMYWEwvhul
				CGgJ1b9m83BAkorRX62I.text((pFg3ovZTfMe9i5ncUqkEYPlQsHB,Mxe2H5cYKSDXQzTj0snELfG),FFhKw05es4jgM,font=J0rZVNxABk3loLDCdG,fill=KHnUIzyoAmcfZs9hNRg8JuXQ0Yxrb7)
				if LlXhYevk6WFCyqgPui84d=='menu_item':
					CGgJ1b9m83BAkorRX62I.text((pFg3ovZTfMe9i5ncUqkEYPlQsHB+1,Mxe2H5cYKSDXQzTj0snELfG+1),FFhKw05es4jgM,font=J0rZVNxABk3loLDCdG,fill=KHnUIzyoAmcfZs9hNRg8JuXQ0Yxrb7)
				if not UD8PrkcZunAKXb0Ew6zqh75FYSyTCo: H3HSFTGrqXbBLKfOMYWEwvhul += YYpKqfFxb290n
				if Mxe2H5cYKSDXQzTj0snELfG>WK2gBe0Vcj+xLiBD6WZcIUf5gkq8G31zmHbl: break
	if LlXhYevk6WFCyqgPui84d=='menu_item':
		qq2T3pO68V7syISu = qq2T3pO68V7syISu.resize((200,200))
		L7RXrlEusm = eH1tbCELifusKYrOIpPxGXwZTacl.copy()
		L7RXrlEusm.paste(j189CMmbgVAZYRdo6TSlEfK4N,(0,0),mask=qq2T3pO68V7syISu)
	else: L7RXrlEusm = qq2T3pO68V7syISu
	if Yd6t3PjlLKk: WrQZLoxGPTIKfv94Blyk73VdwhR = WrQZLoxGPTIKfv94Blyk73VdwhR.decode('utf8')
	try: L7RXrlEusm.save(WrQZLoxGPTIKfv94Blyk73VdwhR)
	except:
		DVatrSh8RyAT1eP9ZbXF32UqKcHfOo = hhHq8m5vauKG9dl.path.dirname(WrQZLoxGPTIKfv94Blyk73VdwhR)
		try: hhHq8m5vauKG9dl.makedirs(DVatrSh8RyAT1eP9ZbXF32UqKcHfOo)
		except: pass
		L7RXrlEusm.save(WrQZLoxGPTIKfv94Blyk73VdwhR)
	return aFusBSfLRKCeY1gX0tk34d
def Gh6b42sgaTK(n0pKCzlGWImh,r5zuJg42pHeTx8E6SX3QlwKiWI0m,gf8ptUvPIyY5lm,GgJ6lSb5j32trm):
	S9ShH7YPWaEOs,Kf6ds9xhHajiZkTR0wF5V1YnvOmy,RDQJCjlnm4cgiLWrEYdqHZ1TNyVuok = '',0,15000
	n0pKCzlGWImh = n0pKCzlGWImh.replace('[COLOR ','[COLOR:::')
	kMScQze5lNCB4hALyWjD = zIdYyOpmXEar2RLH.truetype(I0kWLGvRgTPyNq75uaKxB6eDC9,size=r5zuJg42pHeTx8E6SX3QlwKiWI0m)
	gf8ptUvPIyY5lm -= r5zuJg42pHeTx8E6SX3QlwKiWI0m*2
	qq2T3pO68V7syISu = MfgOeR2YHEWhp.new('RGBA',(gf8ptUvPIyY5lm,99),(255,255,255,0))
	CGgJ1b9m83BAkorRX62I = ppq7nbP8zdkSt20aCVK3rY9.Draw(qq2T3pO68V7syISu)
	for jrKF9vMiJq7VIHudz2NpcT6aoRY4tm in n0pKCzlGWImh.splitlines():
		Kf6ds9xhHajiZkTR0wF5V1YnvOmy += GgJ6lSb5j32trm
		F1t6IQmZidRv72cBlDMbL4ChzeUTnx,MMGk8enLbuJqfPavKC4H = 0,''
		for bL5JBxoVEmh1SIv in jrKF9vMiJq7VIHudz2NpcT6aoRY4tm.split(' '):
			bXogmrIAW4vjdp1a7nsckJwf = vU7CRs6grqktaJzOW2n(' '+bL5JBxoVEmh1SIv)
			gg0KUHwIAZj4Wf3NpoYvFSkm6,s6qCzahlTDxbIOJGKLWQc = CGgJ1b9m83BAkorRX62I.textsize(bXogmrIAW4vjdp1a7nsckJwf,font=kMScQze5lNCB4hALyWjD)
			if F1t6IQmZidRv72cBlDMbL4ChzeUTnx+gg0KUHwIAZj4Wf3NpoYvFSkm6<gf8ptUvPIyY5lm:
				if not MMGk8enLbuJqfPavKC4H: MMGk8enLbuJqfPavKC4H += bL5JBxoVEmh1SIv
				else: MMGk8enLbuJqfPavKC4H += ' '+bL5JBxoVEmh1SIv
				F1t6IQmZidRv72cBlDMbL4ChzeUTnx += gg0KUHwIAZj4Wf3NpoYvFSkm6
			else:
				if gg0KUHwIAZj4Wf3NpoYvFSkm6<gf8ptUvPIyY5lm:
					MMGk8enLbuJqfPavKC4H += '\n '+bL5JBxoVEmh1SIv
					Kf6ds9xhHajiZkTR0wF5V1YnvOmy += GgJ6lSb5j32trm
					F1t6IQmZidRv72cBlDMbL4ChzeUTnx = gg0KUHwIAZj4Wf3NpoYvFSkm6
				else:
					while gg0KUHwIAZj4Wf3NpoYvFSkm6>gf8ptUvPIyY5lm:
						for tdpTaMcz6ZfOUAvx0ByPnLrJob in range(1,len(' '+bL5JBxoVEmh1SIv),1):
							qu1O08FBCm32N76bzSvIiGRMwPncA = ' '+bL5JBxoVEmh1SIv[:tdpTaMcz6ZfOUAvx0ByPnLrJob]
							pbRvfTaMiGY = bL5JBxoVEmh1SIv[tdpTaMcz6ZfOUAvx0ByPnLrJob:]
							a5hCAiSfYNBxU4cvRwdpoJM = vU7CRs6grqktaJzOW2n(qu1O08FBCm32N76bzSvIiGRMwPncA)
							CWPnFdGwy4sqYaI6O9eBkS7KH,KfNWcglvU2ToS = CGgJ1b9m83BAkorRX62I.textsize(a5hCAiSfYNBxU4cvRwdpoJM,font=kMScQze5lNCB4hALyWjD)
							if F1t6IQmZidRv72cBlDMbL4ChzeUTnx+CWPnFdGwy4sqYaI6O9eBkS7KH>gf8ptUvPIyY5lm:
								IIE56wT2Vro9FeBP = gg0KUHwIAZj4Wf3NpoYvFSkm6-CWPnFdGwy4sqYaI6O9eBkS7KH
								MMGk8enLbuJqfPavKC4H += qu1O08FBCm32N76bzSvIiGRMwPncA+'\n'
								Kf6ds9xhHajiZkTR0wF5V1YnvOmy += GgJ6lSb5j32trm
								gg0KUHwIAZj4Wf3NpoYvFSkm6 = IIE56wT2Vro9FeBP
								if IIE56wT2Vro9FeBP>gf8ptUvPIyY5lm:
									F1t6IQmZidRv72cBlDMbL4ChzeUTnx = 0
									bL5JBxoVEmh1SIv = pbRvfTaMiGY
								else:
									F1t6IQmZidRv72cBlDMbL4ChzeUTnx = IIE56wT2Vro9FeBP
									MMGk8enLbuJqfPavKC4H += pbRvfTaMiGY
								break
				if Kf6ds9xhHajiZkTR0wF5V1YnvOmy>RDQJCjlnm4cgiLWrEYdqHZ1TNyVuok: break
		S9ShH7YPWaEOs += '\n'+MMGk8enLbuJqfPavKC4H
		if Kf6ds9xhHajiZkTR0wF5V1YnvOmy>RDQJCjlnm4cgiLWrEYdqHZ1TNyVuok: break
	S9ShH7YPWaEOs = S9ShH7YPWaEOs[1:]
	S9ShH7YPWaEOs = S9ShH7YPWaEOs.replace('[COLOR:::','[COLOR ')
	return S9ShH7YPWaEOs
def vU7CRs6grqktaJzOW2n(bL5JBxoVEmh1SIv):
	if '[' in bL5JBxoVEmh1SIv and ']' in bL5JBxoVEmh1SIv:
		YU3Z8dKf0uNjSwE4 = ['[/COLOR]','[/RTL]','[/LEFT]','[/RIGHT]','[/CENTER]','[RTL]','[LEFT]','[RIGHT]','[CENTER]']
		rZ4DqGs0vdn2YogJwE9AmiO8eBhW = ZXFs0mEPR8qI2zj.findall('\[COLOR .*?\]',bL5JBxoVEmh1SIv,ZXFs0mEPR8qI2zj.DOTALL)
		ipDnbxSNMaHXumt0WYy5 = ZXFs0mEPR8qI2zj.findall('\[COLOR:::.*?\]',bL5JBxoVEmh1SIv,ZXFs0mEPR8qI2zj.DOTALL)
		EA4VCXtBU7a1JIuxoGed = YU3Z8dKf0uNjSwE4+rZ4DqGs0vdn2YogJwE9AmiO8eBhW+ipDnbxSNMaHXumt0WYy5
		for AAxKJH3sp2NUZmiOSTfIBdcFl1btP in EA4VCXtBU7a1JIuxoGed: bL5JBxoVEmh1SIv = bL5JBxoVEmh1SIv.replace(AAxKJH3sp2NUZmiOSTfIBdcFl1btP,'')
	return bL5JBxoVEmh1SIv
def XRcrTbQ5hPspnol6YOe0j(uHGMxiZfcoErOyXghvnWUK):
	uHGMxiZfcoErOyXghvnWUK = uHGMxiZfcoErOyXghvnWUK.replace('\n','_sss__newline_')
	uHGMxiZfcoErOyXghvnWUK = uHGMxiZfcoErOyXghvnWUK.replace('[RTL]','_sss__linertl_')
	uHGMxiZfcoErOyXghvnWUK = uHGMxiZfcoErOyXghvnWUK.replace('[LEFT]','_sss__lineleft_')
	uHGMxiZfcoErOyXghvnWUK = uHGMxiZfcoErOyXghvnWUK.replace('[RIGHT]','_sss__lineright_')
	uHGMxiZfcoErOyXghvnWUK = uHGMxiZfcoErOyXghvnWUK.replace('[CENTER]','_sss__linecenter_')
	uHGMxiZfcoErOyXghvnWUK = uHGMxiZfcoErOyXghvnWUK.replace('[/COLOR]','_sss__endcolor_')
	ZE0hOfqmzg = ZXFs0mEPR8qI2zj.findall('\[COLOR (.*?)\]',uHGMxiZfcoErOyXghvnWUK,ZXFs0mEPR8qI2zj.DOTALL)
	for hzKWNQacisLGo0OHUI73C in ZE0hOfqmzg: uHGMxiZfcoErOyXghvnWUK = uHGMxiZfcoErOyXghvnWUK.replace('[COLOR '+hzKWNQacisLGo0OHUI73C+']','_sss__newcolor'+hzKWNQacisLGo0OHUI73C+'_')
	return uHGMxiZfcoErOyXghvnWUK
def YqFHx5cX8apMkfeB(aaYDh2EzJ5ky=''):
	if not aaYDh2EzJ5ky: aaYDh2EzJ5ky = cPwDBuG4HVTCdQ9JmMeoWjNY2hX.getInfoLabel('ListItem.Label')
	aaYDh2EzJ5ky = aaYDh2EzJ5ky.replace('[/COLOR]','')
	aaYDh2EzJ5ky = aaYDh2EzJ5ky.replace('    ',' ').replace('   ',' ').replace('  ',' ').strip(' ')
	aaYDh2EzJ5ky = aaYDh2EzJ5ky.replace('[COLOR FFFFFF00]','').replace('[COLOR FFC89008]','')
	fwdL5DAnv6gJxMK = ZXFs0mEPR8qI2zj.findall('\d\d:\d\d ',aaYDh2EzJ5ky,ZXFs0mEPR8qI2zj.DOTALL)
	if fwdL5DAnv6gJxMK: aaYDh2EzJ5ky = aaYDh2EzJ5ky.split(fwdL5DAnv6gJxMK[0],1)[1]
	if not aaYDh2EzJ5ky: aaYDh2EzJ5ky = 'Main Menu'
	return aaYDh2EzJ5ky
def qWMK324ghvjprnZelCTPwFoEIDc(SSkZRKCX07):
	zUWJw8YvC1h4Qp76lATtya = ''.join(tdpTaMcz6ZfOUAvx0ByPnLrJob for tdpTaMcz6ZfOUAvx0ByPnLrJob in SSkZRKCX07 if tdpTaMcz6ZfOUAvx0ByPnLrJob not in '\/":*?<>|'+LLf6s3gMbn)
	return zUWJw8YvC1h4Qp76lATtya
def Aq4xzQOb5ISuiC9JWnPtavj0gXlh(NznapDvCteQPx):
	qFgdexufDvw = ZXFs0mEPR8qI2zj.findall("adilbo_HTML_encoder(.*?)/g.....(.*?)\)",NznapDvCteQPx,ZXFs0mEPR8qI2zj.S)
	if qFgdexufDvw:
		UU38E0uyiO5,WUbBi90vgLd34FAuIJcsMh6HzoDN = qFgdexufDvw[0]
		UU38E0uyiO5 = ZXFs0mEPR8qI2zj.findall("=[\r\n\s\t]+'(.*?)';", UU38E0uyiO5, ZXFs0mEPR8qI2zj.S)[0]
		if UU38E0uyiO5 and WUbBi90vgLd34FAuIJcsMh6HzoDN:
			lfXJWEvIHRGVP0uTjCe8sN = UU38E0uyiO5.replace("'",'').replace("+",'').replace("\n",'').replace("\r",'')
			Uh6Ml9EN5fzHO = lfXJWEvIHRGVP0uTjCe8sN.split('.')
			NznapDvCteQPx = ''
			for MgKtsEBxQTGDa3w5O0SrW6pVq in Uh6Ml9EN5fzHO:
				Xng4wUKezYFpbJGZucTA0omfly = EGTVgQoSu6ZsD.b64decode(MgKtsEBxQTGDa3w5O0SrW6pVq+'==').decode('utf8')
				UUfzh4FT2KELjapN = ZXFs0mEPR8qI2zj.findall('\d+', Xng4wUKezYFpbJGZucTA0omfly, ZXFs0mEPR8qI2zj.S)
				if UUfzh4FT2KELjapN:
					fnSKOJl8ghyA3YUr7Pwpo = int(UUfzh4FT2KELjapN[0])
					fnSKOJl8ghyA3YUr7Pwpo += int(WUbBi90vgLd34FAuIJcsMh6HzoDN)
					NznapDvCteQPx = NznapDvCteQPx + chr(fnSKOJl8ghyA3YUr7Pwpo)
			if VYMZsxRpcQHPgkaiDKjyoh: NznapDvCteQPx = NznapDvCteQPx.encode('iso-8859-1').decode('utf8')
	return NznapDvCteQPx