# -*- coding: utf-8 -*-
import sys as ddABnr3K9Xv8e71CzcN0Pxt
NLQaPokgt7Zi = ddABnr3K9Xv8e71CzcN0Pxt.version_info [0] == 2
QzcRNkipwA1WPJu6ZoTnxrjBlqe2 = 2048
Y07K8pBzWtXncO9rUdsw1MTgAyFS = 7
def pFM6HfGd7Urbxto45vSNLniWA (gKVwro2lTJQEp):
	global AUQrTjaXt8K
	UUhFMplXo8RaCwxnEz5Hm7r = ord (gKVwro2lTJQEp [-1])
	slDu7whZzrU2b3oCYREig1L65F9HK = gKVwro2lTJQEp [:-1]
	Ha7jrvByPJYSIiRoXm5ThCOWc = UUhFMplXo8RaCwxnEz5Hm7r % len (slDu7whZzrU2b3oCYREig1L65F9HK)
	E5JVTBFqvjCN2Sc = slDu7whZzrU2b3oCYREig1L65F9HK [:Ha7jrvByPJYSIiRoXm5ThCOWc] + slDu7whZzrU2b3oCYREig1L65F9HK [Ha7jrvByPJYSIiRoXm5ThCOWc:]
	if NLQaPokgt7Zi:
		lK9D8U71rY = unicode () .join ([unichr (ord (ysjIJ8PTAQv5copxFkLUXrRwf) - QzcRNkipwA1WPJu6ZoTnxrjBlqe2 - (WutIpGj5YChbO + UUhFMplXo8RaCwxnEz5Hm7r) % Y07K8pBzWtXncO9rUdsw1MTgAyFS) for WutIpGj5YChbO, ysjIJ8PTAQv5copxFkLUXrRwf in enumerate (E5JVTBFqvjCN2Sc)])
	else:
		lK9D8U71rY = str () .join ([chr (ord (ysjIJ8PTAQv5copxFkLUXrRwf) - QzcRNkipwA1WPJu6ZoTnxrjBlqe2 - (WutIpGj5YChbO + UUhFMplXo8RaCwxnEz5Hm7r) % Y07K8pBzWtXncO9rUdsw1MTgAyFS) for WutIpGj5YChbO, ysjIJ8PTAQv5copxFkLUXrRwf in enumerate (E5JVTBFqvjCN2Sc)])
	return eval (lK9D8U71rY)
OVmSuf8tpd,LmcNhzY6fQPd2JyCGslkSr,J3OCAmZVcn=pFM6HfGd7Urbxto45vSNLniWA,pFM6HfGd7Urbxto45vSNLniWA,pFM6HfGd7Urbxto45vSNLniWA
eeIL1TfgFQJaKqVD8hGNPEZ,aFQoGfmYKyqLU6X8libw9k3ncW5,m6b7CoBk4EQ=J3OCAmZVcn,LmcNhzY6fQPd2JyCGslkSr,OVmSuf8tpd
ZSJVq5XDrRot,yTMWeCgUROcvtsblfK85L62xPk,AAgpHN0nMZ=m6b7CoBk4EQ,aFQoGfmYKyqLU6X8libw9k3ncW5,eeIL1TfgFQJaKqVD8hGNPEZ
XogUJZEijT7KWbxeO6,FhcnOB9t3frzvXb,aVLSn1xw5cK=AAgpHN0nMZ,yTMWeCgUROcvtsblfK85L62xPk,ZSJVq5XDrRot
ffCSGrTJYPsxgVQWKLtHU3iMwB,EDPaWgMt1SwNn8o,PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg=aVLSn1xw5cK,FhcnOB9t3frzvXb,XogUJZEijT7KWbxeO6
Ej67fFyoqW8kbV2HdSK,kmdSKeBIwViM9t3,fR68jBGWCzUsFXdlTKPOScugm=PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg,EDPaWgMt1SwNn8o,ffCSGrTJYPsxgVQWKLtHU3iMwB
bdhQDyjm3nPwToFHkprvCzBLUGR,JcDaEHuiS8TqBbOhWe4ZgwknoC1L3r,wwyUWMFAsO=fR68jBGWCzUsFXdlTKPOScugm,kmdSKeBIwViM9t3,Ej67fFyoqW8kbV2HdSK
kRYWcNuAazr4jtmBoxFVS19Z6,pEo8g7riWVL014KaRtzQ,sArCMRngQNmXkBoKv=wwyUWMFAsO,JcDaEHuiS8TqBbOhWe4ZgwknoC1L3r,bdhQDyjm3nPwToFHkprvCzBLUGR
JMLhEyaBWmskovGHTrVCxQ08,MM2BQ7xrAfNivgenXPytGYOs0DEHRC,hjNP5w9srJz2QpVISxBfndbD4CkXvl=sArCMRngQNmXkBoKv,pEo8g7riWVL014KaRtzQ,kRYWcNuAazr4jtmBoxFVS19Z6
xuYvdJpOEyQKTLNwb,jYaM5vilgZdFx6QHbApwVXO8et,DLSVmlyBbCK=hjNP5w9srJz2QpVISxBfndbD4CkXvl,MM2BQ7xrAfNivgenXPytGYOs0DEHRC,JMLhEyaBWmskovGHTrVCxQ08
gnfv8UtZ3daGqpjzk,gSmqZU0plur2xKPJwQA,c4QSTnPiWUCjhrLlwGB=DLSVmlyBbCK,jYaM5vilgZdFx6QHbApwVXO8et,xuYvdJpOEyQKTLNwb
from j3x780FpaM import *
ll6f2wvU4FdqL3MJyDxORESCK197i = J3OCAmZVcn(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫṍ")
WOczbIGhLMPB8k30 = []
headers = {wwyUWMFAsO(u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭Ṏ"):fR68jBGWCzUsFXdlTKPOScugm(u"ࠪࠫṏ")}
ygd3w7bvQVa5DiSx4rY = [ffCSGrTJYPsxgVQWKLtHU3iMwB(u"ࠫࡆࡑࡗࡂࡏࠪṐ"),LmcNhzY6fQPd2JyCGslkSr(u"࡙ࠬࡈࡐࡑࡉࡑࡆ࡞ࠧṑ"),kmdSKeBIwViM9t3(u"࠭ࡉࡇࡋࡏࡑࠬṒ"),yTMWeCgUROcvtsblfK85L62xPk(u"ࠧࡌࡃࡕࡆࡆࡒࡁࡕࡘࠪṓ"),aVLSn1xw5cK(u"ࠨࡃࡏࡑࡆࡇࡒࡆࡈࠪṔ"),J3OCAmZVcn(u"ࠩࡖࡌࡎࡇࡖࡐࡋࡆࡉࠬṕ"),m6b7CoBk4EQ(u"ࠪࡍࡕ࡚ࡖࠨṖ"),OVmSuf8tpd(u"ࠫࡒ࠹ࡕࠨṗ")]
def n2h4SBIzxbgJD3K7rtVej01EuGcHPs(yf608hE5KeRG1DscunvrU,source,type,url):
	if not yf608hE5KeRG1DscunvrU:
		tr24ZoudmqvxfYCw(xuYvdJpOEyQKTLNwb(u"ࠬࡋࡒࡓࡑࡕࡣࡑࡏࡎࡆࡕࠪṘ"),RGSFZ7ls3nO(ll6f2wvU4FdqL3MJyDxORESCK197i)+yTMWeCgUROcvtsblfK85L62xPk(u"࠭ࠠࠡࠢࡉࡥ࡮ࡲࡥࡥࠢࡩ࡭ࡳࡪࡩ࡯ࡩࠣࡺ࡮ࡪࡥࡰࠢࡩ࡭ࡱ࡫ࡳࠡࠢࠣࠤࡘ࡯ࡴࡦ࠼ࠣ࡟ࠥ࠭ṙ")+source+JMLhEyaBWmskovGHTrVCxQ08(u"ࠧࠡ࡟ࠣࠤࠥࠦࡔࡺࡲࡨ࠾ࠥࡡࠠࠨṚ")+type+J3OCAmZVcn(u"ࠨࠢࡠࠫṛ"))
		SgTvtRyJ5cx9WkmfLHOCb6Vn = NUauTXxKLAoqQtJkglSFRWE(hosgCj2byWvuVT,wwyUWMFAsO(u"ࠩࡧ࡭ࡨࡺࠧṜ"),bdhQDyjm3nPwToFHkprvCzBLUGR(u"ࠪࡑࡎ࡙ࡃࡠࡒࡈࡖࡒ࠭ṝ"),OVmSuf8tpd(u"ࠫࡘࡏࡔࡆࡕࡢࡉࡗࡘࡏࡓࡕࠪṞ"))
		Vzo6GaySHCx = luMHeSgCBaPrb9KvUjNFqcR.strftime(ffCSGrTJYPsxgVQWKLtHU3iMwB(u"࡙ࠬࠫ࠯ࠧࡰ࠲ࠪࡪࠠࠦࡊ࠽ࠩࡒ࠭ṟ"),luMHeSgCBaPrb9KvUjNFqcR.gmtime(F5I1VZzxkXenKuEAYO))
		yJzVl8aho4tDk65mAsT3N = Vzo6GaySHCx,url
		key = source+gnfv8UtZ3daGqpjzk(u"࠭ࠠࠡࠢࠣࠫṠ")+i69DxzEZSwmuY5Il+JcDaEHuiS8TqBbOhWe4ZgwknoC1L3r(u"ࠧࠡࠢࠣࠤࠬṡ")+str(V8US2yZAg0QXJebWIHKD5xFa)
		LaX1QCyeIJ = JMLhEyaBWmskovGHTrVCxQ08(u"ࠨࠩṢ")
		if key not in list(SgTvtRyJ5cx9WkmfLHOCb6Vn.keys()): SgTvtRyJ5cx9WkmfLHOCb6Vn[key] = [yJzVl8aho4tDk65mAsT3N]
		else:
			if url not in str(SgTvtRyJ5cx9WkmfLHOCb6Vn[key]): SgTvtRyJ5cx9WkmfLHOCb6Vn[key].append(yJzVl8aho4tDk65mAsT3N)
			else: LaX1QCyeIJ = ffCSGrTJYPsxgVQWKLtHU3iMwB(u"ࠩ࡟ࡲࠥํะศࠢส่ๆ๐ฯ๋๊้ࠣํา่ะࠢไ๎่ࠥวว็ฬࠤฬ๊แ๋ัํ์์อสࠡษ็ฮ๏ࠦไๆࠢอ฽๊๊ࠧṣ")
		aS2hsq8FUxkgN9reRot7iZ = XogUJZEijT7KWbxeO6(u"࠰ྈ")
		for key in list(SgTvtRyJ5cx9WkmfLHOCb6Vn.keys()):
			SgTvtRyJ5cx9WkmfLHOCb6Vn[key] = list(set(SgTvtRyJ5cx9WkmfLHOCb6Vn[key]))
			aS2hsq8FUxkgN9reRot7iZ += len(SgTvtRyJ5cx9WkmfLHOCb6Vn[key])
		HHTzVhiY079bvdluNkFQ4wCMpe(ZSJVq5XDrRot(u"ࠪࠫṤ"),gnfv8UtZ3daGqpjzk(u"ࠫࠬṥ"),J3OCAmZVcn(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨṦ"),LmcNhzY6fQPd2JyCGslkSr(u"࠭ไๅลึๅࠥอไษำ้ห๊าࠠๅ็ࠣ๎ัีࠠๆๆไหฯࠦวๅใํำ๏๎ࠧṧ")+LaX1QCyeIJ+FhcnOB9t3frzvXb(u"ࠧ࡝ࡰ࡟ࡲ๊ࠥไฺๆ่ࠤฬ๊ศา่ส้ั๊ࠦใ๊่ࠤอาๅฺࠢๅหห๋ษࠡสส่ๆ๐ฯ๋๊๊หฯࠦวๅฬํࠤ้๋๋ࠠฮาࠤ้ํวࠡ็็ๅฬะࠠโ์า๎ํ่ࠦิ๊ไࠤ๏฿ัืࠢ฼่๏้ࠠศๆหี๋อๅอࠢฦ๊ࠥะัิๆ๋ࠣีํࠠศๆๅหห๋ษࠡว็ํࠥอไๆสิ้ัูࠦ็ั่หࠥ๐ีษฯࠣ฽ิี็ศࠢ࠸ࠤๆ๐ฯ๋๊๊หฯ࠭Ṩ")+EDPaWgMt1SwNn8o(u"ࠨ࡞ࡱࡠࡳ࠭ṩ")+bdhQDyjm3nPwToFHkprvCzBLUGR(u"ࠩ฼ำิࠦวๅใํำ๏๎็ศฬࠣๅ๏ࠦวๅไสส๊ฯࠠศๆล๊ࠥํ่ࠡ࠼ࠣࠤࠬṪ")+str(aS2hsq8FUxkgN9reRot7iZ))
		if aS2hsq8FUxkgN9reRot7iZ>=J3OCAmZVcn(u"࠶ྉ"):
			YYkEu4IL0sTa = OxCB4medn1(LmcNhzY6fQPd2JyCGslkSr(u"ࠪࠫṫ"),XogUJZEijT7KWbxeO6(u"ࠫࠬṬ"),sArCMRngQNmXkBoKv(u"ࠬ࠭ṭ"),J3OCAmZVcn(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩṮ"),LmcNhzY6fQPd2JyCGslkSr(u"ࠧศๆหี๋อๅอࠢฯ้฾ࠦโศศ่อࠥ็๊่ษࠣ࠹ࠥ็๊ะ์๋๋ฬะࠠๅ็ࠣ๎ัีࠠศๆหี๋อๅอࠢ็๋ฬࠦๅๅใสฮࠥ็๊ะ์๋ࠤ࠳࠴ࠠิ๊ไࠤ๏่่ๆࠢส่อืๆศ็ฯࠤฬ๊ย็ࠢหุ้ำ่ࠠา๊ࠤฬ๊โศศ่อࠥࡢ࡮࡝ࡰ๋้ࠣࠦสา์าࠤสืำศๆ๋ࠣีํࠠศๆๅหห๋ษࠡไห่๋ࠥำฮ้สࠤส๊้ࠡษ็้อืๅอࠢ็็๏๊ࠦใ๊่ࠤฬ๊ๅษำ่ะࠥฮแฮื๋ࠣีํࠠศๆไ๎ิ๐่่ษอࠤฤࠧࠡࠨṯ"))
			if YYkEu4IL0sTa==FhcnOB9t3frzvXb(u"࠳ྊ"):
				a4BAuzi56OETxFSj3YtoZGU8k7 = AAgpHN0nMZ(u"ࠨࠩṰ")
				for key in list(SgTvtRyJ5cx9WkmfLHOCb6Vn.keys()):
					a4BAuzi56OETxFSj3YtoZGU8k7 += Ej67fFyoqW8kbV2HdSK(u"ࠩ࡟ࡲࠬṱ")+key
					A1qtUWaFCmOTpNPIEx6nViHyQJ = sorted(SgTvtRyJ5cx9WkmfLHOCb6Vn[key],reverse=LmcNhzY6fQPd2JyCGslkSr(u"ࡋࡧ࡬ࡴࡧᄜ"),key=lambda g8K3wQ7TtEO4jSvHMZDNP2pxui0bzA: g8K3wQ7TtEO4jSvHMZDNP2pxui0bzA[fR68jBGWCzUsFXdlTKPOScugm(u"࠳ྋ")])
					for Vzo6GaySHCx,url in A1qtUWaFCmOTpNPIEx6nViHyQJ:
						a4BAuzi56OETxFSj3YtoZGU8k7 += EDPaWgMt1SwNn8o(u"ࠪࡠࡳ࠭Ṳ")+Vzo6GaySHCx+fR68jBGWCzUsFXdlTKPOScugm(u"ࠫࠥࠦࠠࠡࠩṳ")+ejBOu2WXwvb4YpITdsLF16(url)
					a4BAuzi56OETxFSj3YtoZGU8k7 += EDPaWgMt1SwNn8o(u"ࠬࡢ࡮࡝ࡰࠪṴ")
				import bYGAkzJECs
				ybf3Qo7isaYVr = bYGAkzJECs.lkRNq72CIhOaXQWb(aVLSn1xw5cK(u"࠭ࡖࡪࡦࡨࡳࡸ࠭ṵ"),yTMWeCgUROcvtsblfK85L62xPk(u"ࠧࠨṶ"),Ej67fFyoqW8kbV2HdSK(u"ࡌࡡ࡭ࡵࡨᄝ"),xuYvdJpOEyQKTLNwb(u"ࠨࠩṷ"),MM2BQ7xrAfNivgenXPytGYOs0DEHRC(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡖࡌࡂ࡛ࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭Ṹ"),jYaM5vilgZdFx6QHbApwVXO8et(u"ࠪࠫṹ"),a4BAuzi56OETxFSj3YtoZGU8k7)
				if ybf3Qo7isaYVr: HHTzVhiY079bvdluNkFQ4wCMpe(AAgpHN0nMZ(u"ࠫࠬṺ"),aFQoGfmYKyqLU6X8libw9k3ncW5(u"ࠬ࠭ṻ"),ZSJVq5XDrRot(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩṼ"),wwyUWMFAsO(u"ࠧห็ࠣห้หัิษ็ࠤอ์ฬศฯࠪṽ"))
				else: HHTzVhiY079bvdluNkFQ4wCMpe(aVLSn1xw5cK(u"ࠨࠩṾ"),bdhQDyjm3nPwToFHkprvCzBLUGR(u"ࠩࠪṿ"),yTMWeCgUROcvtsblfK85L62xPk(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭Ẁ"),J3OCAmZVcn(u"ࠫๆฺไหࠢ฼้้๐ษࠡษ็ษึูวๅࠩẁ"))
			if YYkEu4IL0sTa!=-ZSJVq5XDrRot(u"࠵ྌ"):
				SgTvtRyJ5cx9WkmfLHOCb6Vn = {}
				ibdKZ0sMlyrDcaJgPFV(hosgCj2byWvuVT,jYaM5vilgZdFx6QHbApwVXO8et(u"ࠬࡓࡉࡔࡅࡢࡔࡊࡘࡍࠨẂ"),aFQoGfmYKyqLU6X8libw9k3ncW5(u"࠭ࡓࡊࡖࡈࡗࡤࡋࡒࡓࡑࡕࡗࠬẃ"))
		if SgTvtRyJ5cx9WkmfLHOCb6Vn: Qc96YoCZJOsKUB8yImw034(hosgCj2byWvuVT,EDPaWgMt1SwNn8o(u"ࠧࡎࡋࡖࡇࡤࡖࡅࡓࡏࠪẄ"),aFQoGfmYKyqLU6X8libw9k3ncW5(u"ࠨࡕࡌࡘࡊ࡙࡟ࡆࡔࡕࡓࡗ࡙ࠧẅ"),SgTvtRyJ5cx9WkmfLHOCb6Vn,iKYM8NdkGHmBcr)
		return
	yf608hE5KeRG1DscunvrU = list(set(yf608hE5KeRG1DscunvrU))
	xCLQK8kh39sjyi5DXSZAVeI,YYmyQXglbEewzL3IA2Sd = kjxV7u5PmHhrTy9SlncaMIsR1WULpw(yf608hE5KeRG1DscunvrU,source)
	EEnCuD1PvpGXxwRyMTJi3oW = str(YYmyQXglbEewzL3IA2Sd).count(kmdSKeBIwViM9t3(u"ࠩࡢࡣࡼࡧࡴࡤࡪࠪẆ"))
	q8x4zI3QdKgEnr = str(YYmyQXglbEewzL3IA2Sd).count(eeIL1TfgFQJaKqVD8hGNPEZ(u"ࠪࡣࡤࡪ࡯ࡸࡰ࡯ࡳࡦࡪࠧẇ"))
	UUWX9ueFtCIri16QEs5nA = len(YYmyQXglbEewzL3IA2Sd)-EEnCuD1PvpGXxwRyMTJi3oW-q8x4zI3QdKgEnr
	GAVmjiQp5cHfZDCTaOyxr7l6kJ = XogUJZEijT7KWbxeO6(u"ฺ๊ࠫว่ัฬ࠾ࠬẈ")+str(EEnCuD1PvpGXxwRyMTJi3oW)+gSmqZU0plur2xKPJwQA(u"ࠬࠦࠠࠡࠢอั๊๐ไ࠻ࠩẉ")+str(q8x4zI3QdKgEnr)+jYaM5vilgZdFx6QHbApwVXO8et(u"࠭ࠠࠡࠢࠣวำื้࠻ࠩẊ")+str(UUWX9ueFtCIri16QEs5nA)
	if not YYmyQXglbEewzL3IA2Sd: FaLTw4gN9ZCSkJeqObQPu870o,svA3Xnq5GbkTcZPHd = c4QSTnPiWUCjhrLlwGB(u"ࠧࡶࡰࡵࡩࡸࡵ࡬ࡷࡧࡧࠫẋ"),eeIL1TfgFQJaKqVD8hGNPEZ(u"ࠨࠩẌ")
	else:
		add = c4QSTnPiWUCjhrLlwGB(u"࠵ྍ")
		if not any(AARNPWHjQU9dEmDI in source for AARNPWHjQU9dEmDI in ygd3w7bvQVa5DiSx4rY):
			add = gnfv8UtZ3daGqpjzk(u"࠷ྎ")
			YYmyQXglbEewzL3IA2Sd = [xuYvdJpOEyQKTLNwb(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡢࡅࡑࡒ࡟ࡍࡋࡑࡏࡘ࠭ẍ")]+list(YYmyQXglbEewzL3IA2Sd)
			xCLQK8kh39sjyi5DXSZAVeI = [fR68jBGWCzUsFXdlTKPOScugm(u"ࠪๅา฻ࠠอ็ํ฽ࠥอไิ์ิๅึอสࠨẎ")]+list(xCLQK8kh39sjyi5DXSZAVeI)
		while ffCSGrTJYPsxgVQWKLtHU3iMwB(u"ࡔࡳࡷࡨᄞ"):
			svA3Xnq5GbkTcZPHd,FaLTw4gN9ZCSkJeqObQPu870o = J3OCAmZVcn(u"ࠫࠬẏ"),ffCSGrTJYPsxgVQWKLtHU3iMwB(u"ࠬ࠭Ẑ")
			if add and len(YYmyQXglbEewzL3IA2Sd)==pEo8g7riWVL014KaRtzQ(u"࠳ྐ"): jQ6w8xOrgYhSHIRpUqzL = FhcnOB9t3frzvXb(u"࠱ྏ")
			else: jQ6w8xOrgYhSHIRpUqzL = F2yZPukcUh09sqCI8nYw7e(GAVmjiQp5cHfZDCTaOyxr7l6kJ,xCLQK8kh39sjyi5DXSZAVeI)
			if jQ6w8xOrgYhSHIRpUqzL==-gSmqZU0plur2xKPJwQA(u"࠳ྑ"): FaLTw4gN9ZCSkJeqObQPu870o = jYaM5vilgZdFx6QHbApwVXO8et(u"࠭ࡣࡢࡰࡦࡩࡱ࡫ࡤࡠ࠳ࡶࡸࡤࡳࡥ࡯ࡷࠪẑ")
			elif add and jQ6w8xOrgYhSHIRpUqzL==aFQoGfmYKyqLU6X8libw9k3ncW5(u"࠳ྒ"):
				FaLTw4gN9ZCSkJeqObQPu870o = MM2BQ7xrAfNivgenXPytGYOs0DEHRC(u"ࠧࡤࡣࡱࡧࡪࡲࡥࡥࡡ࠵ࡲࡩࡥ࡭ࡦࡰࡸࠫẒ")
				HkKfQCS7RIa4xi3houjvl = vvRMnSOBLNrq3wuGyC2I0V(xCLQK8kh39sjyi5DXSZAVeI[add:],YYmyQXglbEewzL3IA2Sd[add:],source)
				if HkKfQCS7RIa4xi3houjvl:
					GhNvef7swV5m0W4lJiF8yMTazDAoB = []
					for IIa6whCNrJmkRXeMqTb23lgB,hiyL1a8Adr30sbTv65WNKtlYGmwnj,DHijR2cKeTM3xmyQuZG9A17ChYws,t1tOk0ovJxh2,nnf9218kDJzH0sGjBKZhAalQyR6q in HkKfQCS7RIa4xi3houjvl:
						if nnf9218kDJzH0sGjBKZhAalQyR6q: GhNvef7swV5m0W4lJiF8yMTazDAoB.append((IIa6whCNrJmkRXeMqTb23lgB,hiyL1a8Adr30sbTv65WNKtlYGmwnj,DHijR2cKeTM3xmyQuZG9A17ChYws,t1tOk0ovJxh2,nnf9218kDJzH0sGjBKZhAalQyR6q))
					if GhNvef7swV5m0W4lJiF8yMTazDAoB: xCLQK8kh39sjyi5DXSZAVeI,YYmyQXglbEewzL3IA2Sd,errors,mwXy4HaY1uWtlvbZVcN7,R28S4pFmAojEW7CGnx = zip(*GhNvef7swV5m0W4lJiF8yMTazDAoB)
					else:
						HHTzVhiY079bvdluNkFQ4wCMpe(MM2BQ7xrAfNivgenXPytGYOs0DEHRC(u"ࠨࠩẓ"),gnfv8UtZ3daGqpjzk(u"ࠩࠪẔ"),bdhQDyjm3nPwToFHkprvCzBLUGR(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭ẕ"),JMLhEyaBWmskovGHTrVCxQ08(u"้๊ࠫริใ่๊๊ࠣࠦห็ࠣษ๏าวะࠢึ๎ึ็ัศฬࠣะ๏ีษࠡใํࠤ์ึวࠡษ็ๅ๏ี๊้ࠢ࠱࠲ࠥำว้ๆࠣว๋ࠦสษฯฮࠤ฾์่ࠠาสࠤฬ๊แ๋ัํ์ࠥ็๊ࠡ็๋ห็฿ࠠฤะิํࠬẖ"))
						FaLTw4gN9ZCSkJeqObQPu870o = sArCMRngQNmXkBoKv(u"ࠬ࡬ࡡࡪ࡮ࡨࡨࠬẗ")
						break
					GAVmjiQp5cHfZDCTaOyxr7l6kJ = fR68jBGWCzUsFXdlTKPOScugm(u"࠭วๅีํีๆืวหࠢส่ั๐ฯสࠢࠫࠤࠬẘ")+str(len(YYmyQXglbEewzL3IA2Sd))+hjNP5w9srJz2QpVISxBfndbD4CkXvl(u"ࠧࠡࠫࠪẙ")
					add = XogUJZEijT7KWbxeO6(u"࠴ྒྷ")
					continue
			else:
				HkKfQCS7RIa4xi3houjvl = vvRMnSOBLNrq3wuGyC2I0V([xCLQK8kh39sjyi5DXSZAVeI[jQ6w8xOrgYhSHIRpUqzL]],[YYmyQXglbEewzL3IA2Sd[jQ6w8xOrgYhSHIRpUqzL]],source)
				if HkKfQCS7RIa4xi3houjvl:
					title,RRucmYBaXegTtNOdGHMQ,errors,mwXy4HaY1uWtlvbZVcN7,R28S4pFmAojEW7CGnx = HkKfQCS7RIa4xi3houjvl[m6b7CoBk4EQ(u"࠵ྔ")]
					if not R28S4pFmAojEW7CGnx and not any(AARNPWHjQU9dEmDI in source for AARNPWHjQU9dEmDI in ygd3w7bvQVa5DiSx4rY):
						errors,mwXy4HaY1uWtlvbZVcN7,R28S4pFmAojEW7CGnx = weXLxcuNIUC7kS1m0T35jAMoO2Ptl(title,RRucmYBaXegTtNOdGHMQ,source,JcDaEHuiS8TqBbOhWe4ZgwknoC1L3r(u"࠶ྕ"))
						if errors==xuYvdJpOEyQKTLNwb(u"ࠨࡇ࡛ࡍ࡙ࡥࡁࡍࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭ẚ"): return errors
					if ZSJVq5XDrRot(u"ࠩึ๎ึ็ัࠨẛ") in title and J3OCAmZVcn(u"ࠪ࠶๊า็้ๆ࠵ࠫẜ") in title:
						tr24ZoudmqvxfYCw(wwyUWMFAsO(u"ࠫࡊࡘࡒࡐࡔࡢࡐࡎࡔࡅࡔࠩẝ"),RGSFZ7ls3nO(ll6f2wvU4FdqL3MJyDxORESCK197i)+fR68jBGWCzUsFXdlTKPOScugm(u"ࠬࠦࠠࠡࡗࡱ࡯ࡳࡵࡷ࡯ࠢࡶࡩࡱ࡫ࡣࡵࡧࡧࠤࡸ࡫ࡲࡷࡧࡵࠤࠥࠦࡓࡦࡴࡹࡩࡷࡀࠠ࡜ࠢࠪẞ")+title+gSmqZU0plur2xKPJwQA(u"࠭ࠠ࡞ࠢࠣࠤࡔࡸࡩࡨ࡫ࡱࡥࡱࡀࠠ࡜ࠢࠪẟ")+RRucmYBaXegTtNOdGHMQ+bdhQDyjm3nPwToFHkprvCzBLUGR(u"ࠧࠡ࡟ࠪẠ"))
						import bYGAkzJECs
						bYGAkzJECs.kYU2LCfAKQ8qxmupz09cbrEojya()
						FaLTw4gN9ZCSkJeqObQPu870o = AAgpHN0nMZ(u"ࠨࡷࡱࡶࡪࡹ࡯࡭ࡸࡨࡨࠬạ")
					else:
						FaLTw4gN9ZCSkJeqObQPu870o,svA3Xnq5GbkTcZPHd,bFEOBVfxy7nPvCdgta1U = ll24tYOSK5cFCuG8M(title,RRucmYBaXegTtNOdGHMQ,errors,mwXy4HaY1uWtlvbZVcN7,R28S4pFmAojEW7CGnx,source,type)
			if FaLTw4gN9ZCSkJeqObQPu870o in [kmdSKeBIwViM9t3(u"ࠩࡈ࡜ࡎ࡚࡟ࡂࡎࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧẢ"),FhcnOB9t3frzvXb(u"ࠪࡨࡴࡽ࡮࡭ࡱࡤࡨࠬả"),FhcnOB9t3frzvXb(u"ࠫࡵࡲࡡࡺ࡫ࡱ࡫ࠬẤ"),kRYWcNuAazr4jtmBoxFVS19Z6(u"ࠬࡺࡥࡴࡶ࡬ࡲ࡬࠭ấ"),hjNP5w9srJz2QpVISxBfndbD4CkXvl(u"࠭ࡣࡢࡰࡦࡩࡱ࡫ࡤࡠ࠳ࡶࡸࡤࡳࡥ࡯ࡷࠪẦ")] or len(YYmyQXglbEewzL3IA2Sd)==DLSVmlyBbCK(u"࠱ྖ")+add: break
			elif FaLTw4gN9ZCSkJeqObQPu870o in [Ej67fFyoqW8kbV2HdSK(u"ࠧࡧࡣ࡬ࡰࡪࡪࠧầ"),MM2BQ7xrAfNivgenXPytGYOs0DEHRC(u"ࠨࡶ࡬ࡱࡪࡵࡵࡵࠩẨ"),kRYWcNuAazr4jtmBoxFVS19Z6(u"ࠩࡷࡶ࡮࡫ࡤࠨẩ")]: break
			elif FaLTw4gN9ZCSkJeqObQPu870o not in [gSmqZU0plur2xKPJwQA(u"ࠪࡧࡦࡴࡣࡦ࡮ࡨࡨࡤ࠸࡮ࡥࡡࡰࡩࡳࡻࠧẪ"),gSmqZU0plur2xKPJwQA(u"ࠫ࡭ࡺࡴࡱࡵࠪẫ")]:
				if c4QSTnPiWUCjhrLlwGB(u"ࠬࡢ࡮ࠨẬ") in svA3Xnq5GbkTcZPHd: svA3Xnq5GbkTcZPHd = aVLSn1xw5cK(u"࡛࠭ࡍࡇࡉࡘࡢࠦࠠࠨậ")+svA3Xnq5GbkTcZPHd.replace(XogUJZEijT7KWbxeO6(u"ࠧ࡝ࡰࠪẮ"),yTMWeCgUROcvtsblfK85L62xPk(u"ࠨ࡞ࡱ࡟ࡑࡋࡆࡕ࡟ࠣࠤࠬắ"))
				HHTzVhiY079bvdluNkFQ4wCMpe(JcDaEHuiS8TqBbOhWe4ZgwknoC1L3r(u"ࠩࠪẰ"),MM2BQ7xrAfNivgenXPytGYOs0DEHRC(u"ࠪࠫằ"),gSmqZU0plur2xKPJwQA(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧẲ"),aVLSn1xw5cK(u"ࠬอไิ์ิๅึࠦไๆࠢํ฽๊๊ࠠอำหࠤุ๐ัโำࠣ฾๏ื็ࠨẳ")+m6b7CoBk4EQ(u"࠭࡜࡯ࠩẴ")+svA3Xnq5GbkTcZPHd,profile=pEo8g7riWVL014KaRtzQ(u"ࠧࡤࡱࡱࡪ࡮ࡸ࡭ࡠ࡯ࡨࡨ࡮ࡻ࡭ࡧࡱࡱࡸࠬẵ"))
	if FaLTw4gN9ZCSkJeqObQPu870o==JMLhEyaBWmskovGHTrVCxQ08(u"ࠨࡷࡱࡶࡪࡹ࡯࡭ࡸࡨࡨࠬẶ") and len(xCLQK8kh39sjyi5DXSZAVeI)>aFQoGfmYKyqLU6X8libw9k3ncW5(u"࠱ྗ"): HHTzVhiY079bvdluNkFQ4wCMpe(PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"ࠩࠪặ"),MM2BQ7xrAfNivgenXPytGYOs0DEHRC(u"ࠪࠫẸ"),kRYWcNuAazr4jtmBoxFVS19Z6(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧẹ"),FhcnOB9t3frzvXb(u"ู๊ࠬาใิࠤ์ึวࠡษ็ๅ๏ี๊้ࠢ็้ࠥ๐ูๆๆࠣะึฮࠠโ์า๎ํฺ๋ࠦำ๊ࠫẺ")+eeIL1TfgFQJaKqVD8hGNPEZ(u"࠭࡜࡯ࠩẻ")+svA3Xnq5GbkTcZPHd,profile=OVmSuf8tpd(u"ࠧࡤࡱࡱࡪ࡮ࡸ࡭ࡠ࡯ࡨࡨ࡮ࡻ࡭ࡧࡱࡱࡸࠬẼ"))
	elif FaLTw4gN9ZCSkJeqObQPu870o in [J3OCAmZVcn(u"ࠨࡨࡤ࡭ࡱ࡫ࡤࠨẽ"),sArCMRngQNmXkBoKv(u"ࠩࡷ࡭ࡲ࡫࡯ࡶࡶࠪẾ")] and svA3Xnq5GbkTcZPHd!=sArCMRngQNmXkBoKv(u"ࠪࠫế"): HHTzVhiY079bvdluNkFQ4wCMpe(m6b7CoBk4EQ(u"ࠫࠬỀ"),MM2BQ7xrAfNivgenXPytGYOs0DEHRC(u"ࠬ࠭ề"),J3OCAmZVcn(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩỂ"),svA3Xnq5GbkTcZPHd,profile=Ej67fFyoqW8kbV2HdSK(u"ࠧࡤࡱࡱࡪ࡮ࡸ࡭ࡠ࡯ࡨࡨ࡮ࡻ࡭ࡧࡱࡱࡸࠬể"))
	return FaLTw4gN9ZCSkJeqObQPu870o
EiyV87pgJjI4U9loKunYws3Rbr1G6,lOSqboWDwFL2NdTPhzysxVXa4Em,LprUo5sYBzuS0RtqN4,tmOrhVs21Uil6J9HnxdWpE,XVm6dqQCG5wAkeb4gIJT3ScK7zjWZE = [],[],[],[],[]
def vvRMnSOBLNrq3wuGyC2I0V(AABKVNO3WiMUSe0,yf608hE5KeRG1DscunvrU,source):
	global EiyV87pgJjI4U9loKunYws3Rbr1G6,lOSqboWDwFL2NdTPhzysxVXa4Em,LprUo5sYBzuS0RtqN4,tmOrhVs21Uil6J9HnxdWpE,XVm6dqQCG5wAkeb4gIJT3ScK7zjWZE
	HkKfQCS7RIa4xi3houjvl,GrSnVDt8FPBom6Olk40,new = [],[],[]
	K18gduYeq29CsrQN(ZSJVq5XDrRot(u"ࡇࡣ࡯ࡷࡪᄟ"),ZSJVq5XDrRot(u"ࡇࡣ࡯ࡷࡪᄟ"),ZSJVq5XDrRot(u"ࡇࡣ࡯ࡷࡪᄟ"))
	count = len(yf608hE5KeRG1DscunvrU)
	for RB2MA1va7eYuCK in range(count):
		EiyV87pgJjI4U9loKunYws3Rbr1G6.append(None)
		lOSqboWDwFL2NdTPhzysxVXa4Em.append(None)
		LprUo5sYBzuS0RtqN4.append(None)
		tmOrhVs21Uil6J9HnxdWpE.append(None)
		XVm6dqQCG5wAkeb4gIJT3ScK7zjWZE.append(None)
		title = AABKVNO3WiMUSe0[RB2MA1va7eYuCK]
		RRucmYBaXegTtNOdGHMQ = yf608hE5KeRG1DscunvrU[RB2MA1va7eYuCK].strip(wwyUWMFAsO(u"ࠨࠢࠪỄ")).strip(XogUJZEijT7KWbxeO6(u"ࠩࠩࠫễ")).strip(XogUJZEijT7KWbxeO6(u"ࠪࡃࠬỆ")).strip(JcDaEHuiS8TqBbOhWe4ZgwknoC1L3r(u"ࠫ࠴࠭ệ"))
		if count>FhcnOB9t3frzvXb(u"࠳྘"): NLVM3HAtxQOSvJf6kd78K1o(c4QSTnPiWUCjhrLlwGB(u"ࠬ็อึࠢึ๎ึ็ัࠡำๅ้ࠥࠦࠧỈ")+str(RB2MA1va7eYuCK+FhcnOB9t3frzvXb(u"࠳྘")),title)
		jf6WwOlVDPvhRYtuAcokrQJ71n9ed4 = RRucmYBaXegTtNOdGHMQ.split(JMLhEyaBWmskovGHTrVCxQ08(u"࠭࠿࡯ࡣࡰࡩࡩࡃࠧỉ"),LmcNhzY6fQPd2JyCGslkSr(u"࠴ྙ"))[JcDaEHuiS8TqBbOhWe4ZgwknoC1L3r(u"࠴ྚ")]
		SflTQR0PHg4vjhdFXcb8kImqLA7an = NUauTXxKLAoqQtJkglSFRWE(hosgCj2byWvuVT,bdhQDyjm3nPwToFHkprvCzBLUGR(u"ࠧ࡭࡫ࡶࡸࠬỊ"),FhcnOB9t3frzvXb(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡆࠪị"),jf6WwOlVDPvhRYtuAcokrQJ71n9ed4)
		if SflTQR0PHg4vjhdFXcb8kImqLA7an and MM2BQ7xrAfNivgenXPytGYOs0DEHRC(u"ࠩࡄࡏ࡜ࡇࡍࠨỌ") not in source:
			EiyV87pgJjI4U9loKunYws3Rbr1G6[RB2MA1va7eYuCK] = SflTQR0PHg4vjhdFXcb8kImqLA7an
		else:
			yzMVBXiAYokh7b5nJF = c3cgVjNv1rde.Thread(target=weXLxcuNIUC7kS1m0T35jAMoO2Ptl,args=(title,RRucmYBaXegTtNOdGHMQ,source,RB2MA1va7eYuCK))
			yzMVBXiAYokh7b5nJF.start()
			GrSnVDt8FPBom6Olk40.append(yzMVBXiAYokh7b5nJF)
			new.append(RB2MA1va7eYuCK)
			luMHeSgCBaPrb9KvUjNFqcR.sleep(wwyUWMFAsO(u"࠵࠴࠷࠶ྛ"))
	timeout = Ej67fFyoqW8kbV2HdSK(u"࠼࠰ྜ") if source==AAgpHN0nMZ(u"ࠪࡅࡐ࡝ࡁࡎࠩọ") else wwyUWMFAsO(u"࠳࠱ྜྷ")
	for yzMVBXiAYokh7b5nJF in GrSnVDt8FPBom6Olk40: yzMVBXiAYokh7b5nJF.join(timeout)
	for RB2MA1va7eYuCK in range(count):
		title = AABKVNO3WiMUSe0[RB2MA1va7eYuCK]
		RRucmYBaXegTtNOdGHMQ = yf608hE5KeRG1DscunvrU[RB2MA1va7eYuCK].strip(OVmSuf8tpd(u"ࠫࠥ࠭Ỏ")).strip(jYaM5vilgZdFx6QHbApwVXO8et(u"ࠬࠬࠧỏ")).strip(LmcNhzY6fQPd2JyCGslkSr(u"࠭࠿ࠨỐ")).strip(kmdSKeBIwViM9t3(u"ࠧ࠰ࠩố"))
		if EiyV87pgJjI4U9loKunYws3Rbr1G6[RB2MA1va7eYuCK]: svA3Xnq5GbkTcZPHd,xCLQK8kh39sjyi5DXSZAVeI,YYmyQXglbEewzL3IA2Sd = EiyV87pgJjI4U9loKunYws3Rbr1G6[RB2MA1va7eYuCK]
		else: svA3Xnq5GbkTcZPHd,xCLQK8kh39sjyi5DXSZAVeI,YYmyQXglbEewzL3IA2Sd = wwyUWMFAsO(u"ࠨ࡞ࡱࡊࡦ࡯࡬ࡦࡦ࠽ࠤ࡚ࠥࡩ࡮ࡧࡲࡹࡹࠦࠨࠨỒ")+str(timeout)+sArCMRngQNmXkBoKv(u"ࠩࠣࡷࡪࡩ࡯࡯ࡦࡶ࠭ࠬồ"),[],[]
		HkKfQCS7RIa4xi3houjvl.append([title,RRucmYBaXegTtNOdGHMQ,svA3Xnq5GbkTcZPHd,xCLQK8kh39sjyi5DXSZAVeI,YYmyQXglbEewzL3IA2Sd])
		if RB2MA1va7eYuCK in new:
			jf6WwOlVDPvhRYtuAcokrQJ71n9ed4 = RRucmYBaXegTtNOdGHMQ.split(xuYvdJpOEyQKTLNwb(u"ࠪࡃࡳࡧ࡭ࡦࡦࡀࠫỔ"),ZSJVq5XDrRot(u"࠲ྞ"))[m6b7CoBk4EQ(u"࠲ྟ")]
			try: jqyKYGNlCu6k9RP71DpObUf,thGH9JMzL7SAueZbC8N21ofa,W7Je5Ru2YrosvmnzyiwBjhDTQH8O = YYmyQXglbEewzL3IA2Sd[gnfv8UtZ3daGqpjzk(u"࠳ྠ")]
			except: Qc96YoCZJOsKUB8yImw034(hosgCj2byWvuVT,Ej67fFyoqW8kbV2HdSK(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡉ࠭ổ"),jf6WwOlVDPvhRYtuAcokrQJ71n9ed4,[svA3Xnq5GbkTcZPHd,xCLQK8kh39sjyi5DXSZAVeI,YYmyQXglbEewzL3IA2Sd],Z7uFdWIRv9ybj0)
	K18gduYeq29CsrQN(J3OCAmZVcn(u"ࠬ࠭Ỗ"),wwyUWMFAsO(u"࠭ࠧỗ"),aVLSn1xw5cK(u"ࠧࠨỘ"))
	return HkKfQCS7RIa4xi3houjvl
def weXLxcuNIUC7kS1m0T35jAMoO2Ptl(NGmuWwXdLQ6nMltx39FYECohJ,url,source,hcVjpT7mOqX):
	global EiyV87pgJjI4U9loKunYws3Rbr1G6
	tr24ZoudmqvxfYCw(MM2BQ7xrAfNivgenXPytGYOs0DEHRC(u"ࠨࡐࡒࡘࡎࡉࡅࡠࡎࡌࡒࡊ࡙ࠧộ"),RGSFZ7ls3nO(ll6f2wvU4FdqL3MJyDxORESCK197i)+sArCMRngQNmXkBoKv(u"ࠩࠣࠤࠥࡘࡥࡴࡱ࡯ࡺ࡮ࡴࡧࠡࡵࡷࡥࡷࡺࡥࡥࠢࠣࠤࡘ࡫࡬ࡦࡥࡷࡩࡩࡀࠠ࡜ࠢࠪỚ")+NGmuWwXdLQ6nMltx39FYECohJ+XogUJZEijT7KWbxeO6(u"ࠪࠤࡢࠦࠠࠡࡑࡵ࡭࡬࡯࡮ࡢ࡮࠽ࠤࡠࠦࠧớ")+url+JcDaEHuiS8TqBbOhWe4ZgwknoC1L3r(u"ࠫࠥࡣࠧỜ"))
	RRucmYBaXegTtNOdGHMQ,Wnt7oIL4qyl3Mgzi0mCw9 = url,pEo8g7riWVL014KaRtzQ(u"ࠬ࠭ờ")
	Ay8QeFPhSboq6sgNm1H5Upiv47ulkX = EDPaWgMt1SwNn8o(u"࠭ࡉࡏࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࠪỞ")
	svA3Xnq5GbkTcZPHd,xCLQK8kh39sjyi5DXSZAVeI,YYmyQXglbEewzL3IA2Sd = IKTrJBPolmAX2Q5CqwR(url,source)
	if svA3Xnq5GbkTcZPHd==yTMWeCgUROcvtsblfK85L62xPk(u"ࠧࡆ࡚ࡌࡘࡤࡇࡌࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬở"):
		EiyV87pgJjI4U9loKunYws3Rbr1G6[hcVjpT7mOqX] = m6b7CoBk4EQ(u"ࠨࡇ࡛ࡍ࡙ࡥࡁࡍࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭Ỡ"),[],[]
		return EiyV87pgJjI4U9loKunYws3Rbr1G6[hcVjpT7mOqX]
	elif sArCMRngQNmXkBoKv(u"ࠩࡑࡉࡊࡊ࡟ࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬỡ") in svA3Xnq5GbkTcZPHd:
		Wnt7oIL4qyl3Mgzi0mCw9 = gnfv8UtZ3daGqpjzk(u"ࠪࡠࡳࡘࡥࡴࡱ࡯ࡺࡪࡸࠠ࠲࠼ࠣࠤࡓ࡫ࡥࡥࠢࡈࡼࡹ࡫ࡲ࡯ࡣ࡯ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷ࠭Ợ")
		RRucmYBaXegTtNOdGHMQ = IIiS4d67gwfan3hqzmYVs5opRKFZMb(YYmyQXglbEewzL3IA2Sd)[kmdSKeBIwViM9t3(u"࠴ྡ")]
		Ay8QeFPhSboq6sgNm1H5Upiv47ulkX,Wnt7oIL4qyl3Mgzi0mCw9,xCLQK8kh39sjyi5DXSZAVeI,YYmyQXglbEewzL3IA2Sd = D8vPke4ZbiQftlqS7IJwB(Wnt7oIL4qyl3Mgzi0mCw9,RRucmYBaXegTtNOdGHMQ,source,hcVjpT7mOqX)
		if Wnt7oIL4qyl3Mgzi0mCw9==eeIL1TfgFQJaKqVD8hGNPEZ(u"ࠫࡊ࡞ࡉࡕࡡࡄࡐࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩợ"): return Wnt7oIL4qyl3Mgzi0mCw9,xCLQK8kh39sjyi5DXSZAVeI,YYmyQXglbEewzL3IA2Sd
	elif svA3Xnq5GbkTcZPHd: Wnt7oIL4qyl3Mgzi0mCw9 = AAgpHN0nMZ(u"ࠬࡘࡥࡴࡱ࡯ࡺࡪࡸࠠ࠲࠼ࠣࠤࠬỤ")+svA3Xnq5GbkTcZPHd.replace(pEo8g7riWVL014KaRtzQ(u"࠭࡜࡯ࠩụ"),c4QSTnPiWUCjhrLlwGB(u"ࠧࠨỦ")).replace(MM2BQ7xrAfNivgenXPytGYOs0DEHRC(u"ࠨ࡞ࡵࠫủ"),m6b7CoBk4EQ(u"ࠩࠪỨ"))[:xuYvdJpOEyQKTLNwb(u"࠽࠶ྡྷ")]
	if YYmyQXglbEewzL3IA2Sd:
		YYmyQXglbEewzL3IA2Sd = IIiS4d67gwfan3hqzmYVs5opRKFZMb(YYmyQXglbEewzL3IA2Sd)
		tr24ZoudmqvxfYCw(XogUJZEijT7KWbxeO6(u"ࠪࡒࡔ࡚ࡉࡄࡇࡢࡐࡎࡔࡅࡔࠩứ"),RGSFZ7ls3nO(ll6f2wvU4FdqL3MJyDxORESCK197i)+pEo8g7riWVL014KaRtzQ(u"ࠫࠥࠦࠠࡓࡧࡶࡳࡱࡼࡩ࡯ࡩࠣࡷࡺࡩࡣࡦࡧࡧࡩࡩࠦࠠࠡࡕࡨࡰࡪࡩࡴࡦࡦ࠽ࠤࡠࠦࠧỪ")+NGmuWwXdLQ6nMltx39FYECohJ+MM2BQ7xrAfNivgenXPytGYOs0DEHRC(u"ࠬࠦ࡝ࠡࠢࠣࡖࡪࡹ࡯࡭ࡸࡨࡶ࠿࡛ࠦࠡࠩừ")+Ay8QeFPhSboq6sgNm1H5Upiv47ulkX+PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"࠭ࠠ࡞ࠢࠣࠤࡔࡸࡩࡨ࡫ࡱࡥࡱࡀࠠ࡜ࠢࠪỬ")+url+aFQoGfmYKyqLU6X8libw9k3ncW5(u"ࠧࠡ࡟ࠣࠤࠥࡒࡩ࡯࡭࠽ࠤࡠࠦࠧử")+RRucmYBaXegTtNOdGHMQ+pEo8g7riWVL014KaRtzQ(u"ࠨࠢࡠࠤࠥࠦࡖࡪࡦࡨࡳࡸࡀࠠ࡜ࠢࠪỮ")+str(YYmyQXglbEewzL3IA2Sd)+DLSVmlyBbCK(u"ࠩࠣࡡࠬữ"))
	else: tr24ZoudmqvxfYCw(kmdSKeBIwViM9t3(u"ࠪࡒࡔ࡚ࡉࡄࡇࡢࡐࡎࡔࡅࡔࠩỰ"),RGSFZ7ls3nO(ll6f2wvU4FdqL3MJyDxORESCK197i)+EDPaWgMt1SwNn8o(u"ࠫࠥࠦࠠࡓࡧࡶࡳࡱࡼࡩ࡯ࡩࠣࡪࡦ࡯࡬ࡦࡦࠣࠤ࡙ࠥࡥ࡭ࡧࡦࡸࡪࡪ࠺ࠡ࡝ࠣࠫự")+NGmuWwXdLQ6nMltx39FYECohJ+LmcNhzY6fQPd2JyCGslkSr(u"ࠬࠦ࡝ࠡࠢࠣࡓࡷ࡯ࡧࡪࡰࡤࡰ࠿࡛ࠦࠡࠩỲ")+url+jYaM5vilgZdFx6QHbApwVXO8et(u"࠭ࠠ࡞ࠢࠣࠤࡑ࡯࡮࡬࠼ࠣ࡟ࠥ࠭ỳ")+RRucmYBaXegTtNOdGHMQ+kmdSKeBIwViM9t3(u"ࠧࠡ࡟ࠣࠤࠥࡋࡲࡳࡱࡵࡷ࠿࡛ࠦࠡࠩỴ")+Wnt7oIL4qyl3Mgzi0mCw9+MM2BQ7xrAfNivgenXPytGYOs0DEHRC(u"ࠨࠢࡠࠫỵ"))
	Wnt7oIL4qyl3Mgzi0mCw9 = ejBOu2WXwvb4YpITdsLF16(Wnt7oIL4qyl3Mgzi0mCw9)
	EiyV87pgJjI4U9loKunYws3Rbr1G6[hcVjpT7mOqX] = Wnt7oIL4qyl3Mgzi0mCw9,xCLQK8kh39sjyi5DXSZAVeI,YYmyQXglbEewzL3IA2Sd
	return Wnt7oIL4qyl3Mgzi0mCw9,xCLQK8kh39sjyi5DXSZAVeI,YYmyQXglbEewzL3IA2Sd
def ll24tYOSK5cFCuG8M(title,RRucmYBaXegTtNOdGHMQ,svA3Xnq5GbkTcZPHd,xCLQK8kh39sjyi5DXSZAVeI,YYmyQXglbEewzL3IA2Sd,source,type=XogUJZEijT7KWbxeO6(u"ࠩࠪỶ")):
	if svA3Xnq5GbkTcZPHd==J3OCAmZVcn(u"ࠪࡉ࡝ࡏࡔࡠࡃࡏࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨỷ"): return svA3Xnq5GbkTcZPHd,xCLQK8kh39sjyi5DXSZAVeI,YYmyQXglbEewzL3IA2Sd
	elif YYmyQXglbEewzL3IA2Sd:
		while kRYWcNuAazr4jtmBoxFVS19Z6(u"ࡖࡵࡹࡪᄠ"):
			if len(YYmyQXglbEewzL3IA2Sd)==PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"࠷ྣ"): jQ6w8xOrgYhSHIRpUqzL = XogUJZEijT7KWbxeO6(u"࠰ྤ")
			else: jQ6w8xOrgYhSHIRpUqzL = F2yZPukcUh09sqCI8nYw7e(kmdSKeBIwViM9t3(u"ࠫฬิสาࠢส่๊๊แࠡษ็้๋อำษ࠼ࠪỸ"), xCLQK8kh39sjyi5DXSZAVeI)
			if jQ6w8xOrgYhSHIRpUqzL==-OVmSuf8tpd(u"࠲ྥ"): FaLTw4gN9ZCSkJeqObQPu870o = DLSVmlyBbCK(u"ࠬࡺࡲࡪࡧࡧࠫỹ")
			else:
				ZX1rPbxgm3HAJDFj0Qqh4 = YYmyQXglbEewzL3IA2Sd[jQ6w8xOrgYhSHIRpUqzL]
				tr24ZoudmqvxfYCw(kmdSKeBIwViM9t3(u"࠭ࡎࡐࡖࡌࡇࡊࡥࡌࡊࡐࡈࡗࠬỺ"),RGSFZ7ls3nO(ll6f2wvU4FdqL3MJyDxORESCK197i)+sArCMRngQNmXkBoKv(u"ࠧࠡࠢࠣࡔࡱࡧࡹࡪࡰࡪࠤࡸࡺࡡࡳࡶࡨࡨࠥࠦࠠࡔࡧ࡯ࡩࡨࡺࡥࡥ࠼ࠣ࡟ࠥ࠭ỻ")+title+OVmSuf8tpd(u"ࠨࠢࡠࠤࠥࠦࡏࡳ࡫ࡪ࡭ࡳࡧ࡬࠻ࠢ࡞ࠤࠬỼ")+RRucmYBaXegTtNOdGHMQ+JMLhEyaBWmskovGHTrVCxQ08(u"ࠩࠣࡡࠥࠦࠠࡗ࡫ࡧࡩࡴࡀࠠ࡜ࠢࠪỽ")+str(ZX1rPbxgm3HAJDFj0Qqh4)+AAgpHN0nMZ(u"ࠪࠤࡢ࠭Ỿ"))
				if ZSJVq5XDrRot(u"ࠫࡲࡵࡳࡩࡣ࡫ࡨࡦ࠴ࠧỿ") in ZX1rPbxgm3HAJDFj0Qqh4 and LmcNhzY6fQPd2JyCGslkSr(u"ࠬࡪ࡯ࡸࡰ࡯ࡳࡦࡪ࡟ࡰࡴ࡬࡫ࠬἀ") in ZX1rPbxgm3HAJDFj0Qqh4:
					AFjSCx0IlDr,FNylha5WkeAxi3r0G4QPqwRZMY,bFEOBVfxy7nPvCdgta1U = WW4JOYTltX53gcA2Uvbya0E6BIo(ZX1rPbxgm3HAJDFj0Qqh4)
					if bFEOBVfxy7nPvCdgta1U: ZX1rPbxgm3HAJDFj0Qqh4 = bFEOBVfxy7nPvCdgta1U[jYaM5vilgZdFx6QHbApwVXO8et(u"࠲ྦ")]
					else: ZX1rPbxgm3HAJDFj0Qqh4 = eeIL1TfgFQJaKqVD8hGNPEZ(u"࠭ࠧἁ")
				if not ZX1rPbxgm3HAJDFj0Qqh4: FaLTw4gN9ZCSkJeqObQPu870o = ZSJVq5XDrRot(u"ࠧࡶࡰࡵࡩࡸࡵ࡬ࡷࡧࡧࠫἂ")
				else: FaLTw4gN9ZCSkJeqObQPu870o = w3hq0Xp8D9rZJ(ZX1rPbxgm3HAJDFj0Qqh4,source,type)
			if FaLTw4gN9ZCSkJeqObQPu870o in [m6b7CoBk4EQ(u"ࠨࡲ࡯ࡥࡾ࡯࡮ࡨࠩἃ"),JcDaEHuiS8TqBbOhWe4ZgwknoC1L3r(u"ࠩࡷࡩࡸࡺࡩ࡯ࡩࠪἄ"),kmdSKeBIwViM9t3(u"ࠪࡧࡦࡴࡣࡦ࡮ࡨࡨࡤ࠸࡮ࡥࡡࡰࡩࡳࡻࠧἅ")] or len(YYmyQXglbEewzL3IA2Sd)==fR68jBGWCzUsFXdlTKPOScugm(u"࠴ྦྷ"): break
			elif FaLTw4gN9ZCSkJeqObQPu870o in [DLSVmlyBbCK(u"ࠫ࡫ࡧࡩ࡭ࡧࡧࠫἆ"),PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"ࠬࡺࡩ࡮ࡧࡲࡹࡹ࠭ἇ"),wwyUWMFAsO(u"࠭ࡴࡳ࡫ࡨࡨࠬἈ")]: break
			else: HHTzVhiY079bvdluNkFQ4wCMpe(PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"ࠧࠨἉ"),Ej67fFyoqW8kbV2HdSK(u"ࠨࠩἊ"),pEo8g7riWVL014KaRtzQ(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬἋ"),bdhQDyjm3nPwToFHkprvCzBLUGR(u"ࠪห้๋ไโࠢ็้ࠥ๐ูๆๆࠣะึฮࠠๆๆไࠤ฿๐ั่ࠩἌ"))
	else:
		FaLTw4gN9ZCSkJeqObQPu870o = eeIL1TfgFQJaKqVD8hGNPEZ(u"ࠫࡺࡴࡲࡦࡵࡲࡰࡻ࡫ࡤࠨἍ")
		if fDEdQSsq1uPoU(RRucmYBaXegTtNOdGHMQ): FaLTw4gN9ZCSkJeqObQPu870o = w3hq0Xp8D9rZJ(RRucmYBaXegTtNOdGHMQ,source,type)
	return FaLTw4gN9ZCSkJeqObQPu870o,svA3Xnq5GbkTcZPHd,YYmyQXglbEewzL3IA2Sd
def vTVEjhctuZKlWHA8sX9bGoO(url,source):
	lQHXdV9Nzf6BLqS8D,qqcZx7Q3omI152iSl,NGmuWwXdLQ6nMltx39FYECohJ,JIHk0bO8APsLMGFR,aaYDh2EzJ5ky,type,P1ajYzT8sKCx6tMl,PHUqTNVJ0ErRSwibn5gD,qBKDxcalp4QdXitguWhSHwo2Zy9E = url,fR68jBGWCzUsFXdlTKPOScugm(u"ࠬ࠭Ἆ"),xuYvdJpOEyQKTLNwb(u"࠭ࠧἏ"),AAgpHN0nMZ(u"ࠧࠨἐ"),LmcNhzY6fQPd2JyCGslkSr(u"ࠨࠩἑ"),PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"ࠩࠪἒ"),xuYvdJpOEyQKTLNwb(u"ࠪࠫἓ"),LmcNhzY6fQPd2JyCGslkSr(u"ࠫࠬἔ"),DLSVmlyBbCK(u"ࠬ࠭ἕ")
	if Ej67fFyoqW8kbV2HdSK(u"࠭࠿࡯ࡣࡰࡩࡩࡃࠧ἖") in url:
		lQHXdV9Nzf6BLqS8D,qqcZx7Q3omI152iSl = url.split(pEo8g7riWVL014KaRtzQ(u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࠨ἗"),ffCSGrTJYPsxgVQWKLtHU3iMwB(u"࠵ྨ"))
		qqcZx7Q3omI152iSl = qqcZx7Q3omI152iSl+xuYvdJpOEyQKTLNwb(u"ࠨࡡࡢࠫἘ")+DLSVmlyBbCK(u"ࠩࡢࡣࠬἙ")+kRYWcNuAazr4jtmBoxFVS19Z6(u"ࠪࡣࡤ࠭Ἒ")+kRYWcNuAazr4jtmBoxFVS19Z6(u"ࠫࡤࡥࠧἛ")+OVmSuf8tpd(u"ࠬࡥ࡟ࠨἜ")
		aaYDh2EzJ5ky,type,P1ajYzT8sKCx6tMl,PHUqTNVJ0ErRSwibn5gD,qBKDxcalp4QdXitguWhSHwo2Zy9E,MqBGmv53etuED, = qqcZx7Q3omI152iSl.split(sArCMRngQNmXkBoKv(u"࠭࡟ࡠࠩἝ"))[:EDPaWgMt1SwNn8o(u"࠻ྩ")]
	if not PHUqTNVJ0ErRSwibn5gD: PHUqTNVJ0ErRSwibn5gD = fR68jBGWCzUsFXdlTKPOScugm(u"ࠧ࠱ࠩ἞")
	else: PHUqTNVJ0ErRSwibn5gD = PHUqTNVJ0ErRSwibn5gD.replace(fR68jBGWCzUsFXdlTKPOScugm(u"ࠨࡲࠪ἟"),EDPaWgMt1SwNn8o(u"ࠩࠪἠ")).replace(PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"ࠪࠤࠬἡ"),hjNP5w9srJz2QpVISxBfndbD4CkXvl(u"ࠫࠬἢ"))
	lQHXdV9Nzf6BLqS8D = lQHXdV9Nzf6BLqS8D.strip(eeIL1TfgFQJaKqVD8hGNPEZ(u"ࠬࡅࠧἣ")).strip(Ej67fFyoqW8kbV2HdSK(u"࠭࠯ࠨἤ")).strip(eeIL1TfgFQJaKqVD8hGNPEZ(u"ࠧࠧࠩἥ"))
	NGmuWwXdLQ6nMltx39FYECohJ = d78KRnJmBWscGua0XMk(lQHXdV9Nzf6BLqS8D,gnfv8UtZ3daGqpjzk(u"ࠨࡪࡲࡷࡹ࠭ἦ"))
	if aaYDh2EzJ5ky: JIHk0bO8APsLMGFR = aaYDh2EzJ5ky
	else: JIHk0bO8APsLMGFR = NGmuWwXdLQ6nMltx39FYECohJ
	JIHk0bO8APsLMGFR = d78KRnJmBWscGua0XMk(JIHk0bO8APsLMGFR,LmcNhzY6fQPd2JyCGslkSr(u"ࠩࡱࡥࡲ࡫ࠧἧ"))
	aaYDh2EzJ5ky = aaYDh2EzJ5ky.replace(JMLhEyaBWmskovGHTrVCxQ08(u"้ࠪออิาࠩἨ"),c4QSTnPiWUCjhrLlwGB(u"ࠫࠬἩ")).replace(FhcnOB9t3frzvXb(u"ู๊ࠬาใิࠫἪ"),AAgpHN0nMZ(u"࠭ࠧἫ")).replace(Ej67fFyoqW8kbV2HdSK(u"ࠧศๆࠣࠫἬ"),kmdSKeBIwViM9t3(u"ࠨࠢࠪἭ")).replace(aFQoGfmYKyqLU6X8libw9k3ncW5(u"ࠩࠣࠤࠬἮ"),wwyUWMFAsO(u"ࠪࠤࠬἯ"))
	qqcZx7Q3omI152iSl = qqcZx7Q3omI152iSl.replace(J3OCAmZVcn(u"๊ࠫฮวีำࠪἰ"),EDPaWgMt1SwNn8o(u"ࠬ࠭ἱ")).replace(OVmSuf8tpd(u"࠭ำ๋ำไีࠬἲ"),OVmSuf8tpd(u"ࠧࠨἳ")).replace(aVLSn1xw5cK(u"ࠨษ็ࠤࠬἴ"),m6b7CoBk4EQ(u"ࠩࠣࠫἵ")).replace(bdhQDyjm3nPwToFHkprvCzBLUGR(u"ࠪࠤࠥ࠭ἶ"),ffCSGrTJYPsxgVQWKLtHU3iMwB(u"ࠫࠥ࠭ἷ"))
	JIHk0bO8APsLMGFR = JIHk0bO8APsLMGFR.replace(kmdSKeBIwViM9t3(u"๋ࠬศศึิࠫἸ"),pEo8g7riWVL014KaRtzQ(u"࠭ࠧἹ")).replace(JMLhEyaBWmskovGHTrVCxQ08(u"ࠧิ์ิๅึ࠭Ἲ"),XogUJZEijT7KWbxeO6(u"ࠨࠩἻ")).replace(gnfv8UtZ3daGqpjzk(u"ࠩส่ࠥ࠭Ἴ"),wwyUWMFAsO(u"ࠪࠤࠬἽ")).replace(gSmqZU0plur2xKPJwQA(u"ࠫࠥࠦࠧἾ"),FhcnOB9t3frzvXb(u"ࠬࠦࠧἿ"))
	return lQHXdV9Nzf6BLqS8D,qqcZx7Q3omI152iSl,NGmuWwXdLQ6nMltx39FYECohJ,JIHk0bO8APsLMGFR,aaYDh2EzJ5ky,type,P1ajYzT8sKCx6tMl,PHUqTNVJ0ErRSwibn5gD,qBKDxcalp4QdXitguWhSHwo2Zy9E
def vcXya3WtDK8IG(url,source):
	pp5VsHSlyY0J3R7akBve8bXh,aaYDh2EzJ5ky,vbYfzUgrlIPBTJA312n7dciSQx0Dq,HHwKY68MiJf1vPBptGjob3xkcmh5,JiwCb5Dhx9jLnoYNG3kqIX7vmHVP,GGk5QvoHeZuTVOWRMy6,Ay8QeFPhSboq6sgNm1H5Upiv47ulkX = yTMWeCgUROcvtsblfK85L62xPk(u"࠭ࠧὀ"),eeIL1TfgFQJaKqVD8hGNPEZ(u"ࠧࠨὁ"),None,None,None,None,None
	lQHXdV9Nzf6BLqS8D,qqcZx7Q3omI152iSl,NGmuWwXdLQ6nMltx39FYECohJ,JIHk0bO8APsLMGFR,aaYDh2EzJ5ky,type,P1ajYzT8sKCx6tMl,PHUqTNVJ0ErRSwibn5gD,qBKDxcalp4QdXitguWhSHwo2Zy9E = vTVEjhctuZKlWHA8sX9bGoO(url,source)
	if XogUJZEijT7KWbxeO6(u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࠩὂ") in url:
		if   type==aVLSn1xw5cK(u"ࠩࡨࡱࡧ࡫ࡤࠨὃ"): type = kmdSKeBIwViM9t3(u"ࠪࠤࠬὄ")+m6b7CoBk4EQ(u"๊ࠫ็ึๅࠩὅ")
		elif type==fR68jBGWCzUsFXdlTKPOScugm(u"ࠬࡽࡡࡵࡥ࡫ࠫ὆"): type = bdhQDyjm3nPwToFHkprvCzBLUGR(u"࠭ࠠࠨ὇")+gSmqZU0plur2xKPJwQA(u"ࠧࠦ็ืห์ีษࠨὈ")
		elif type==gnfv8UtZ3daGqpjzk(u"ࠨࡤࡲࡸ࡭࠭Ὁ"): type = bdhQDyjm3nPwToFHkprvCzBLUGR(u"ࠩࠣࠫὊ")+AAgpHN0nMZ(u"๋ࠪࠩࠪิศ้าอࠥ๎สฮ็ํ่ࠬὋ")
		elif type==DLSVmlyBbCK(u"ࠫࡩࡵࡷ࡯࡮ࡲࡥࡩ࠭Ὄ"): type = ZSJVq5XDrRot(u"ࠬࠦࠧὍ")+ffCSGrTJYPsxgVQWKLtHU3iMwB(u"࠭ࠥࠦࠧอั๊๐ไࠨ὎")
		elif type==yTMWeCgUROcvtsblfK85L62xPk(u"ࠧࠨ὏"): type = bdhQDyjm3nPwToFHkprvCzBLUGR(u"ࠨࠢࠪὐ")+wwyUWMFAsO(u"ࠩࠨࠩࠪࠫࠧὑ")
		if P1ajYzT8sKCx6tMl!=c4QSTnPiWUCjhrLlwGB(u"ࠪࠫὒ"):
			if m6b7CoBk4EQ(u"ࠫࡲࡶ࠴ࠨὓ") not in P1ajYzT8sKCx6tMl: P1ajYzT8sKCx6tMl = XogUJZEijT7KWbxeO6(u"ࠬࠫࠧὔ")+P1ajYzT8sKCx6tMl
			P1ajYzT8sKCx6tMl = Ej67fFyoqW8kbV2HdSK(u"࠭ࠠࠨὕ")+P1ajYzT8sKCx6tMl
		if PHUqTNVJ0ErRSwibn5gD!=JMLhEyaBWmskovGHTrVCxQ08(u"ࠧࠨὖ"):
			PHUqTNVJ0ErRSwibn5gD = jYaM5vilgZdFx6QHbApwVXO8et(u"ࠨࠧࠨࠩࠪࠫࠥࠦࠧࠨࠫὗ")+PHUqTNVJ0ErRSwibn5gD
			PHUqTNVJ0ErRSwibn5gD = EDPaWgMt1SwNn8o(u"ࠩࠣࠫ὘")+PHUqTNVJ0ErRSwibn5gD[-Ej67fFyoqW8kbV2HdSK(u"࠿ྪ"):]
	if   EDPaWgMt1SwNn8o(u"ࠪࡅࡐࡕࡁࡎࠩὙ")		in source: GGk5QvoHeZuTVOWRMy6	= JIHk0bO8APsLMGFR
	elif J3OCAmZVcn(u"ࠫࡆࡑࡗࡂࡏࠪ὚")		in source: vbYfzUgrlIPBTJA312n7dciSQx0Dq	= ZSJVq5XDrRot(u"ࠬࡧ࡫ࡸࡣࡰࠫὛ")
	elif jYaM5vilgZdFx6QHbApwVXO8et(u"࠭࡫ࡢࡶ࡮ࡳࡺࡺࡥࠨ὜")		in NGmuWwXdLQ6nMltx39FYECohJ: vbYfzUgrlIPBTJA312n7dciSQx0Dq	= JIHk0bO8APsLMGFR
	elif eeIL1TfgFQJaKqVD8hGNPEZ(u"ࠧࡱࡪࡲࡸࡴࡹ࠮ࡢࡲࡳ࠲࡬࠭Ὕ")	in NGmuWwXdLQ6nMltx39FYECohJ: vbYfzUgrlIPBTJA312n7dciSQx0Dq	= JIHk0bO8APsLMGFR
	elif aFQoGfmYKyqLU6X8libw9k3ncW5(u"ࠨࡣࡵࡥࡧࡹࡥࡦࡦࠪ὞")		in source: vbYfzUgrlIPBTJA312n7dciSQx0Dq	= JIHk0bO8APsLMGFR
	elif aFQoGfmYKyqLU6X8libw9k3ncW5(u"ࠩࡤࡰࡦࡸࡡࡣࠩὟ")		in NGmuWwXdLQ6nMltx39FYECohJ: vbYfzUgrlIPBTJA312n7dciSQx0Dq	= JIHk0bO8APsLMGFR
	elif Ej67fFyoqW8kbV2HdSK(u"ࠪࡪࡦࡹࡥ࡭ࠩὠ")		in NGmuWwXdLQ6nMltx39FYECohJ: vbYfzUgrlIPBTJA312n7dciSQx0Dq	= JIHk0bO8APsLMGFR
	elif pEo8g7riWVL014KaRtzQ(u"ࠫࡹ࠽࡭ࡦࡧ࡯ࠫὡ")		in NGmuWwXdLQ6nMltx39FYECohJ: vbYfzUgrlIPBTJA312n7dciSQx0Dq	= JIHk0bO8APsLMGFR
	elif aFQoGfmYKyqLU6X8libw9k3ncW5(u"ࠬࡳ࡯ࡷࡵ࠷ࡹࠬὢ")		in aaYDh2EzJ5ky:   vbYfzUgrlIPBTJA312n7dciSQx0Dq	= JIHk0bO8APsLMGFR
	elif jYaM5vilgZdFx6QHbApwVXO8et(u"࠭࡭ࡺࡧࡪࡽࡻ࡯ࡰࠨὣ")		in aaYDh2EzJ5ky:   vbYfzUgrlIPBTJA312n7dciSQx0Dq	= JIHk0bO8APsLMGFR
	elif MM2BQ7xrAfNivgenXPytGYOs0DEHRC(u"ࠧࡧࡣ࡭ࡩࡷ࠭ὤ")		in aaYDh2EzJ5ky:   vbYfzUgrlIPBTJA312n7dciSQx0Dq	= JIHk0bO8APsLMGFR
	elif c4QSTnPiWUCjhrLlwGB(u"ࠨใฯีࠬὥ")			in aaYDh2EzJ5ky:   vbYfzUgrlIPBTJA312n7dciSQx0Dq	= bdhQDyjm3nPwToFHkprvCzBLUGR(u"ࠩࡩࡥ࡯࡫ࡲࠨὦ")
	elif XogUJZEijT7KWbxeO6(u"ࠪๅู้ื๋่ࠪὧ")		in aaYDh2EzJ5ky:   vbYfzUgrlIPBTJA312n7dciSQx0Dq	= gnfv8UtZ3daGqpjzk(u"ࠫࡵࡧ࡬ࡦࡵࡷ࡭ࡳ࡫ࠧὨ")
	elif eeIL1TfgFQJaKqVD8hGNPEZ(u"ࠬ࡭ࡤࡳ࡫ࡹࡩࠬὩ")		in lQHXdV9Nzf6BLqS8D:   vbYfzUgrlIPBTJA312n7dciSQx0Dq	= aFQoGfmYKyqLU6X8libw9k3ncW5(u"࠭ࡧࡰࡱࡪࡰࡪ࠭Ὢ")
	elif AAgpHN0nMZ(u"ࠧ࡮ࡻࡦ࡭ࡲࡧࠧὫ")		in aaYDh2EzJ5ky:   vbYfzUgrlIPBTJA312n7dciSQx0Dq	= JIHk0bO8APsLMGFR
	elif XogUJZEijT7KWbxeO6(u"ࠨࡹࡨࡧ࡮ࡳࡡࠨὬ")		in aaYDh2EzJ5ky:   vbYfzUgrlIPBTJA312n7dciSQx0Dq	= JIHk0bO8APsLMGFR
	elif J3OCAmZVcn(u"ࠩࡦ࡭ࡲࡧ࡮ࡰࡹࠪὭ")		in aaYDh2EzJ5ky:   vbYfzUgrlIPBTJA312n7dciSQx0Dq	= JIHk0bO8APsLMGFR
	elif XogUJZEijT7KWbxeO6(u"ࠪࡲࡪࡽࡣࡪ࡯ࡤࠫὮ")		in aaYDh2EzJ5ky:   vbYfzUgrlIPBTJA312n7dciSQx0Dq	= JIHk0bO8APsLMGFR
	elif XogUJZEijT7KWbxeO6(u"ࠫࡩࡧࡩ࡭ࡻࡰࡳࡹ࡯࡯࡯ࠩὯ")	in NGmuWwXdLQ6nMltx39FYECohJ: vbYfzUgrlIPBTJA312n7dciSQx0Dq	= JIHk0bO8APsLMGFR
	elif Ej67fFyoqW8kbV2HdSK(u"ࠬࡨ࡯࡬ࡴࡤࠫὰ")		in NGmuWwXdLQ6nMltx39FYECohJ: vbYfzUgrlIPBTJA312n7dciSQx0Dq	= JIHk0bO8APsLMGFR
	elif pEo8g7riWVL014KaRtzQ(u"࠭ࡴࡷࡨࡸࡲࠬά")		in NGmuWwXdLQ6nMltx39FYECohJ: vbYfzUgrlIPBTJA312n7dciSQx0Dq	= JIHk0bO8APsLMGFR
	elif FhcnOB9t3frzvXb(u"ࠧࡵࡸ࡮ࡷࡦ࠭ὲ")		in NGmuWwXdLQ6nMltx39FYECohJ: vbYfzUgrlIPBTJA312n7dciSQx0Dq	= JIHk0bO8APsLMGFR
	elif kRYWcNuAazr4jtmBoxFVS19Z6(u"ࠨࡣࡱࡥࡻ࡯ࡤࡻࠩέ")		in NGmuWwXdLQ6nMltx39FYECohJ: vbYfzUgrlIPBTJA312n7dciSQx0Dq	= JIHk0bO8APsLMGFR
	elif yTMWeCgUROcvtsblfK85L62xPk(u"ࠩࡶ࡬ࡴࡵࡦࡱࡴࡲࠫὴ")		in NGmuWwXdLQ6nMltx39FYECohJ: vbYfzUgrlIPBTJA312n7dciSQx0Dq	= JIHk0bO8APsLMGFR
	elif EDPaWgMt1SwNn8o(u"ࠪࡷ࡭ࡧࡨࡪࡦ࠷ࡹࠬή")		in NGmuWwXdLQ6nMltx39FYECohJ: GGk5QvoHeZuTVOWRMy6	= JIHk0bO8APsLMGFR
	elif ffCSGrTJYPsxgVQWKLtHU3iMwB(u"ࠫࡸ࡮ࡡࡩࡧࡧ࠸ࡺ࠭ὶ")		in NGmuWwXdLQ6nMltx39FYECohJ: GGk5QvoHeZuTVOWRMy6	= JIHk0bO8APsLMGFR
	elif PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"ࠬࡩࡩ࡮ࡣ࠷ࡹࠬί")		in NGmuWwXdLQ6nMltx39FYECohJ: GGk5QvoHeZuTVOWRMy6	= JIHk0bO8APsLMGFR
	elif EDPaWgMt1SwNn8o(u"࠭ࡥࡨࡻࡱࡳࡼ࠭ὸ")		in NGmuWwXdLQ6nMltx39FYECohJ: GGk5QvoHeZuTVOWRMy6	= JIHk0bO8APsLMGFR
	elif JcDaEHuiS8TqBbOhWe4ZgwknoC1L3r(u"ࠧࡩࡣ࡯ࡥࡨ࡯࡭ࡢࠩό")		in NGmuWwXdLQ6nMltx39FYECohJ: GGk5QvoHeZuTVOWRMy6	= JIHk0bO8APsLMGFR
	elif bdhQDyjm3nPwToFHkprvCzBLUGR(u"ࠨࡥ࡬ࡱࡦࡧࡢࡥࡱࠪὺ")		in NGmuWwXdLQ6nMltx39FYECohJ: GGk5QvoHeZuTVOWRMy6	= JIHk0bO8APsLMGFR
	elif gnfv8UtZ3daGqpjzk(u"ࠩࡼࡳࡺࡺࡵࠨύ")	 	in NGmuWwXdLQ6nMltx39FYECohJ: vbYfzUgrlIPBTJA312n7dciSQx0Dq	= sArCMRngQNmXkBoKv(u"ࠪࡽࡴࡻࡴࡶࡤࡨࠫὼ")
	elif AAgpHN0nMZ(u"ࠫࡾ࠸ࡵ࠯ࡤࡨࠫώ")	 	in NGmuWwXdLQ6nMltx39FYECohJ: vbYfzUgrlIPBTJA312n7dciSQx0Dq	= xuYvdJpOEyQKTLNwb(u"ࠬࡿ࡯ࡶࡶࡸࡦࡪ࠭὾")
	elif m6b7CoBk4EQ(u"࠭ࡤ࠯ࡧࡪࡽࡧ࡫ࡳࡵ࠰ࡧࠫ὿")	in NGmuWwXdLQ6nMltx39FYECohJ: vbYfzUgrlIPBTJA312n7dciSQx0Dq	= aFQoGfmYKyqLU6X8libw9k3ncW5(u"ࠧࡦࡩࡼࡦࡪࡹࡴࡷ࡫ࡳࠫᾀ")
	elif ZSJVq5XDrRot(u"ࠨࡧࡪࡽ࠳ࡨࡥࡴࡶࠪᾁ")		in NGmuWwXdLQ6nMltx39FYECohJ: vbYfzUgrlIPBTJA312n7dciSQx0Dq	= xuYvdJpOEyQKTLNwb(u"ࠩࡨ࡫ࡾࡨࡥࡴࡶ࠴ࠫᾂ")
	elif aVLSn1xw5cK(u"ࠪࡩ࡬ࡿࡢࡦࡵࡷࠫᾃ")		in NGmuWwXdLQ6nMltx39FYECohJ: vbYfzUgrlIPBTJA312n7dciSQx0Dq	= hjNP5w9srJz2QpVISxBfndbD4CkXvl(u"ࠫࡪ࡭ࡹࡣࡧࡶࡸ࠸࠭ᾄ")
	elif jYaM5vilgZdFx6QHbApwVXO8et(u"ࠬࡳ࡯ࡴࡪࡤ࡬ࡩࡧࠧᾅ")		in NGmuWwXdLQ6nMltx39FYECohJ: vbYfzUgrlIPBTJA312n7dciSQx0Dq	= c4QSTnPiWUCjhrLlwGB(u"࠭࡭ࡰࡵ࡫ࡥ࡭ࡪࡡࠨᾆ")
	elif yTMWeCgUROcvtsblfK85L62xPk(u"ࠧࡧࡣࡦࡹࡱࡺࡹࡣࡱࡲ࡯ࡸ࠭ᾇ")	in NGmuWwXdLQ6nMltx39FYECohJ: vbYfzUgrlIPBTJA312n7dciSQx0Dq	= bdhQDyjm3nPwToFHkprvCzBLUGR(u"ࠨࡨࡤࡧࡺࡲࡴࡺࡤࡲࡳࡰࡹࠧᾈ")
	elif MM2BQ7xrAfNivgenXPytGYOs0DEHRC(u"ࠩ࡬ࡲ࡫ࡲࡡ࡮࠰ࡦࡧࠬᾉ")	in NGmuWwXdLQ6nMltx39FYECohJ: vbYfzUgrlIPBTJA312n7dciSQx0Dq	= xuYvdJpOEyQKTLNwb(u"ࠪ࡭ࡳ࡬࡬ࡢ࡯ࠪᾊ")
	elif JcDaEHuiS8TqBbOhWe4ZgwknoC1L3r(u"ࠫࡧࡻࡺࡻࡸࡵࡰࠬᾋ")		in NGmuWwXdLQ6nMltx39FYECohJ: vbYfzUgrlIPBTJA312n7dciSQx0Dq	= FhcnOB9t3frzvXb(u"ࠬࡨࡵࡻࡼࡹࡶࡱ࠭ᾌ")
	elif eeIL1TfgFQJaKqVD8hGNPEZ(u"࠭ࡡࡳࡣࡥࡰࡴࡧࡤࡴࠩᾍ")	in NGmuWwXdLQ6nMltx39FYECohJ: HHwKY68MiJf1vPBptGjob3xkcmh5	= yTMWeCgUROcvtsblfK85L62xPk(u"ࠧࡢࡴࡤࡦࡱࡵࡡࡥࡵࠪᾎ")
	elif LmcNhzY6fQPd2JyCGslkSr(u"ࠨࡣࡵࡧ࡭࡯ࡶࡦࠩᾏ")		in NGmuWwXdLQ6nMltx39FYECohJ: HHwKY68MiJf1vPBptGjob3xkcmh5	= ZSJVq5XDrRot(u"ࠩࡤࡶࡨ࡮ࡩࡷࡧࠪᾐ")
	elif pEo8g7riWVL014KaRtzQ(u"ࠪࡧࡦࡺࡣࡩ࠰࡬ࡷࠬᾑ")	 	in NGmuWwXdLQ6nMltx39FYECohJ: HHwKY68MiJf1vPBptGjob3xkcmh5	= OVmSuf8tpd(u"ࠫࡨࡧࡴࡤࡪࠪᾒ")
	elif OVmSuf8tpd(u"ࠬ࡬ࡩ࡭ࡧࡵ࡭ࡴ࠭ᾓ")		in NGmuWwXdLQ6nMltx39FYECohJ: HHwKY68MiJf1vPBptGjob3xkcmh5	= JcDaEHuiS8TqBbOhWe4ZgwknoC1L3r(u"࠭ࡦࡪ࡮ࡨࡶ࡮ࡵࠧᾔ")
	elif XogUJZEijT7KWbxeO6(u"ࠧࡷ࡫ࡧࡦࡲ࠭ᾕ")		in NGmuWwXdLQ6nMltx39FYECohJ: HHwKY68MiJf1vPBptGjob3xkcmh5	= MM2BQ7xrAfNivgenXPytGYOs0DEHRC(u"ࠨࡸ࡬ࡨࡧࡳࠧᾖ")
	elif hjNP5w9srJz2QpVISxBfndbD4CkXvl(u"ࠩࡹ࡭ࡩ࡮ࡤࠨᾗ")		in NGmuWwXdLQ6nMltx39FYECohJ: GGk5QvoHeZuTVOWRMy6	= JIHk0bO8APsLMGFR
	elif PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"ࠪࡱࡾࡼࡩࡥࠩᾘ")		in NGmuWwXdLQ6nMltx39FYECohJ: GGk5QvoHeZuTVOWRMy6	= JIHk0bO8APsLMGFR
	elif jYaM5vilgZdFx6QHbApwVXO8et(u"ࠫࡲࡿࡶࡪ࡫ࡧࠫᾙ")		in NGmuWwXdLQ6nMltx39FYECohJ: GGk5QvoHeZuTVOWRMy6	= JIHk0bO8APsLMGFR
	elif kRYWcNuAazr4jtmBoxFVS19Z6(u"ࠬࡼࡩࡥࡧࡲࡦ࡮ࡴࠧᾚ")		in NGmuWwXdLQ6nMltx39FYECohJ: HHwKY68MiJf1vPBptGjob3xkcmh5	= JcDaEHuiS8TqBbOhWe4ZgwknoC1L3r(u"࠭ࡶࡪࡦࡨࡳࡧ࡯࡮ࠨᾛ")
	elif wwyUWMFAsO(u"ࠧࡨࡱࡹ࡭ࡩ࠭ᾜ")		in NGmuWwXdLQ6nMltx39FYECohJ: HHwKY68MiJf1vPBptGjob3xkcmh5	= gSmqZU0plur2xKPJwQA(u"ࠨࡩࡲࡺ࡮ࡪࠧᾝ")
	elif kmdSKeBIwViM9t3(u"ࠩ࡯࡭࡮ࡼࡩࡥࡧࡲࠫᾞ") 	in NGmuWwXdLQ6nMltx39FYECohJ: HHwKY68MiJf1vPBptGjob3xkcmh5	= xuYvdJpOEyQKTLNwb(u"ࠪࡰ࡮࡯ࡶࡪࡦࡨࡳࠬᾟ")
	elif jYaM5vilgZdFx6QHbApwVXO8et(u"ࠫࡲࡶ࠴ࡶࡲ࡯ࡳࡦࡪࠧᾠ")	in NGmuWwXdLQ6nMltx39FYECohJ: HHwKY68MiJf1vPBptGjob3xkcmh5	= bdhQDyjm3nPwToFHkprvCzBLUGR(u"ࠬࡳࡰ࠵ࡷࡳࡰࡴࡧࡤࠨᾡ")
	elif aFQoGfmYKyqLU6X8libw9k3ncW5(u"࠭ࡰࡶࡤ࡯࡭ࡨࡼࡩࡥࡧࡲࠫᾢ")	in NGmuWwXdLQ6nMltx39FYECohJ: HHwKY68MiJf1vPBptGjob3xkcmh5	= bdhQDyjm3nPwToFHkprvCzBLUGR(u"ࠧࡱࡷࡥࡰ࡮ࡩࡶࡪࡦࡨࡳࠬᾣ")
	elif c4QSTnPiWUCjhrLlwGB(u"ࠨࡴࡤࡴ࡮ࡪࡶࡪࡦࡨࡳࠬᾤ") 	in NGmuWwXdLQ6nMltx39FYECohJ: HHwKY68MiJf1vPBptGjob3xkcmh5	= JcDaEHuiS8TqBbOhWe4ZgwknoC1L3r(u"ࠩࡵࡥࡵ࡯ࡤࡷ࡫ࡧࡩࡴ࠭ᾥ")
	elif bdhQDyjm3nPwToFHkprvCzBLUGR(u"ࠪࡸࡴࡶ࠴ࡵࡱࡳࠫᾦ")		in NGmuWwXdLQ6nMltx39FYECohJ: HHwKY68MiJf1vPBptGjob3xkcmh5	= XogUJZEijT7KWbxeO6(u"ࠫࡹࡵࡰ࠵ࡶࡲࡴࠬᾧ")
	elif OVmSuf8tpd(u"ࠬࡻࡰࡱࠩᾨ") 			in NGmuWwXdLQ6nMltx39FYECohJ: HHwKY68MiJf1vPBptGjob3xkcmh5	= kRYWcNuAazr4jtmBoxFVS19Z6(u"࠭ࡵࡱࡤࡲࡱࠬᾩ")
	elif gSmqZU0plur2xKPJwQA(u"ࠧࡶࡲࡥࠫᾪ") 			in NGmuWwXdLQ6nMltx39FYECohJ: HHwKY68MiJf1vPBptGjob3xkcmh5	= LmcNhzY6fQPd2JyCGslkSr(u"ࠨࡷࡳࡦࡴࡳࠧᾫ")
	elif wwyUWMFAsO(u"ࠩࡸࡵࡱࡵࡡࡥࠩᾬ") 		in NGmuWwXdLQ6nMltx39FYECohJ: HHwKY68MiJf1vPBptGjob3xkcmh5	= kRYWcNuAazr4jtmBoxFVS19Z6(u"ࠪࡹࡶࡲ࡯ࡢࡦࠪᾭ")
	elif wwyUWMFAsO(u"ࠫࡻࡩࡳࡵࡴࡨࡥࡲ࠭ᾮ") 	in NGmuWwXdLQ6nMltx39FYECohJ: HHwKY68MiJf1vPBptGjob3xkcmh5	= AAgpHN0nMZ(u"ࠬࡼࡣࡴࡶࡵࡩࡦࡳࠧᾯ")
	elif J3OCAmZVcn(u"࠭ࡶࡪࡦࡥࡳࡧ࠭ᾰ")		in NGmuWwXdLQ6nMltx39FYECohJ: HHwKY68MiJf1vPBptGjob3xkcmh5	= AAgpHN0nMZ(u"ࠧࡷ࡫ࡧࡦࡴࡨࠧᾱ")
	elif XogUJZEijT7KWbxeO6(u"ࠨࡸ࡬ࡨࡴࢀࡡࠨᾲ") 		in NGmuWwXdLQ6nMltx39FYECohJ: HHwKY68MiJf1vPBptGjob3xkcmh5	= xuYvdJpOEyQKTLNwb(u"ࠩࡹ࡭ࡩࡵࡺࡢࠩᾳ")
	elif JcDaEHuiS8TqBbOhWe4ZgwknoC1L3r(u"ࠪࡻࡦࡺࡣࡩࡸ࡬ࡨࡪࡵࠧᾴ") 	in NGmuWwXdLQ6nMltx39FYECohJ: HHwKY68MiJf1vPBptGjob3xkcmh5	= aVLSn1xw5cK(u"ࠫࡼࡧࡴࡤࡪࡹ࡭ࡩ࡫࡯ࠨ᾵")
	elif kmdSKeBIwViM9t3(u"ࠬࡽࡩ࡯ࡶࡹ࠲ࡱ࡯ࡶࡦࠩᾶ")	in NGmuWwXdLQ6nMltx39FYECohJ: HHwKY68MiJf1vPBptGjob3xkcmh5	= fR68jBGWCzUsFXdlTKPOScugm(u"࠭ࡷࡪࡰࡷࡺ࠳ࡲࡩࡷࡧࠪᾷ")
	elif PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"ࠧࡻ࡫ࡳࡴࡾࡹࡨࡢࡴࡨࠫᾸ")	in NGmuWwXdLQ6nMltx39FYECohJ: HHwKY68MiJf1vPBptGjob3xkcmh5	= DLSVmlyBbCK(u"ࠨࡼ࡬ࡴࡵࡿࡳࡩࡣࡵࡩࠬᾹ")
	elif kmdSKeBIwViM9t3(u"ࠩ࡫ࡨ࠲ࡩࡤ࡯ࠩᾺ")		in NGmuWwXdLQ6nMltx39FYECohJ: HHwKY68MiJf1vPBptGjob3xkcmh5	= kmdSKeBIwViM9t3(u"ࠪ࡬ࡩ࠳ࡣࡥࡰࠪΆ")
	if   vbYfzUgrlIPBTJA312n7dciSQx0Dq:	pp5VsHSlyY0J3R7akBve8bXh,aaYDh2EzJ5ky = EDPaWgMt1SwNn8o(u"ࠫำอีࠨᾼ"),vbYfzUgrlIPBTJA312n7dciSQx0Dq
	elif GGk5QvoHeZuTVOWRMy6:		pp5VsHSlyY0J3R7akBve8bXh,aaYDh2EzJ5ky = AAgpHN0nMZ(u"ࠬࠫๅฮัาࠫ᾽"),GGk5QvoHeZuTVOWRMy6
	elif HHwKY68MiJf1vPBptGjob3xkcmh5:		pp5VsHSlyY0J3R7akBve8bXh,aaYDh2EzJ5ky = wwyUWMFAsO(u"࠭ࠥࠦ฻สู้๋ࠥา๊ไࠫι"),HHwKY68MiJf1vPBptGjob3xkcmh5
	elif JiwCb5Dhx9jLnoYNG3kqIX7vmHVP:	pp5VsHSlyY0J3R7akBve8bXh,aaYDh2EzJ5ky = fR68jBGWCzUsFXdlTKPOScugm(u"ࠧࠦࠧࠨ฽ฬ๋ࠠฯษิะ๏࠭᾿"),JiwCb5Dhx9jLnoYNG3kqIX7vmHVP
	elif Ay8QeFPhSboq6sgNm1H5Upiv47ulkX:	pp5VsHSlyY0J3R7akBve8bXh,aaYDh2EzJ5ky = gnfv8UtZ3daGqpjzk(u"ࠨࠧࠨࠩࠪ฿วๆࠢัหึา๊ࠨ῀"),JIHk0bO8APsLMGFR
	else:			pp5VsHSlyY0J3R7akBve8bXh,aaYDh2EzJ5ky = xuYvdJpOEyQKTLNwb(u"ࠩࠨฺࠩࠪࠫࠥษ่ࠤ๊า็้ๆࠪ῁"),JIHk0bO8APsLMGFR
	return pp5VsHSlyY0J3R7akBve8bXh,aaYDh2EzJ5ky,type,P1ajYzT8sKCx6tMl,PHUqTNVJ0ErRSwibn5gD
def IKTrJBPolmAX2Q5CqwR(url,source):
	lQHXdV9Nzf6BLqS8D,GGk5QvoHeZuTVOWRMy6,NGmuWwXdLQ6nMltx39FYECohJ,JIHk0bO8APsLMGFR,aaYDh2EzJ5ky,type,P1ajYzT8sKCx6tMl,PHUqTNVJ0ErRSwibn5gD,qBKDxcalp4QdXitguWhSHwo2Zy9E = vTVEjhctuZKlWHA8sX9bGoO(url,source)
	if   xuYvdJpOEyQKTLNwb(u"ࠪࡅࡐࡕࡁࡎࠩῂ")		in source: svA3Xnq5GbkTcZPHd,xCLQK8kh39sjyi5DXSZAVeI,YYmyQXglbEewzL3IA2Sd = mCTR9VFong(lQHXdV9Nzf6BLqS8D,aaYDh2EzJ5ky)
	elif JcDaEHuiS8TqBbOhWe4ZgwknoC1L3r(u"ࠫࡆࡑࡗࡂࡏࠪῃ")		in source: svA3Xnq5GbkTcZPHd,xCLQK8kh39sjyi5DXSZAVeI,YYmyQXglbEewzL3IA2Sd = FN6uzHvdbp(lQHXdV9Nzf6BLqS8D,type,PHUqTNVJ0ErRSwibn5gD)
	elif kmdSKeBIwViM9t3(u"ࠬࡌࡁࡔࡇࡏࡌࡉ࠷ࠧῄ")		in source: svA3Xnq5GbkTcZPHd,xCLQK8kh39sjyi5DXSZAVeI,YYmyQXglbEewzL3IA2Sd = L5Wip7lPhd(lQHXdV9Nzf6BLqS8D)
	elif DLSVmlyBbCK(u"࠭ࡃࡊࡏࡄ࠸࡚࠭῅")		in source: svA3Xnq5GbkTcZPHd,xCLQK8kh39sjyi5DXSZAVeI,YYmyQXglbEewzL3IA2Sd = jrfTYWXZnv(lQHXdV9Nzf6BLqS8D)
	elif c4QSTnPiWUCjhrLlwGB(u"ࠧࡄࡋࡐࡅࡈࡒࡕࡃࠩῆ")		in source: svA3Xnq5GbkTcZPHd,xCLQK8kh39sjyi5DXSZAVeI,YYmyQXglbEewzL3IA2Sd = u2APxIQdlD(lQHXdV9Nzf6BLqS8D)
	elif sArCMRngQNmXkBoKv(u"ࠨࡃࡕࡅࡇ࡙ࡅࡆࡆࠪῇ")		in source: svA3Xnq5GbkTcZPHd,xCLQK8kh39sjyi5DXSZAVeI,YYmyQXglbEewzL3IA2Sd = iRzsfUmpP7(lQHXdV9Nzf6BLqS8D)
	elif gSmqZU0plur2xKPJwQA(u"ࠩࡆࡍࡒࡇࡁࡃࡆࡒࠫῈ")		in source: svA3Xnq5GbkTcZPHd,xCLQK8kh39sjyi5DXSZAVeI,YYmyQXglbEewzL3IA2Sd = BMiW1qeG8b(lQHXdV9Nzf6BLqS8D)
	elif jYaM5vilgZdFx6QHbApwVXO8et(u"ࠪࡗࡍࡕࡆࡉࡃࠪΈ")		in source: svA3Xnq5GbkTcZPHd,xCLQK8kh39sjyi5DXSZAVeI,YYmyQXglbEewzL3IA2Sd = E2RU1x6hfF(lQHXdV9Nzf6BLqS8D)
	elif DLSVmlyBbCK(u"ࠫࡊࡍ࡙ࡃࡇࡖࡘ࠶࠭Ὴ")		in source: svA3Xnq5GbkTcZPHd,xCLQK8kh39sjyi5DXSZAVeI,YYmyQXglbEewzL3IA2Sd = jRx1tlqX0z(lQHXdV9Nzf6BLqS8D,qBKDxcalp4QdXitguWhSHwo2Zy9E)
	elif Ej67fFyoqW8kbV2HdSK(u"ࠬࡱࡡࡵ࡭ࡲࡹࡹ࡫ࠧΉ")		in NGmuWwXdLQ6nMltx39FYECohJ: svA3Xnq5GbkTcZPHd,xCLQK8kh39sjyi5DXSZAVeI,YYmyQXglbEewzL3IA2Sd = U0UaVBJHgY(lQHXdV9Nzf6BLqS8D)
	elif Ej67fFyoqW8kbV2HdSK(u"࠭ࡡ࡬ࡱࡤࡱ࠳ࡩࡡ࡮ࠩῌ")	in NGmuWwXdLQ6nMltx39FYECohJ: svA3Xnq5GbkTcZPHd,xCLQK8kh39sjyi5DXSZAVeI,YYmyQXglbEewzL3IA2Sd = oV8DHKQf25(lQHXdV9Nzf6BLqS8D)
	elif kmdSKeBIwViM9t3(u"ࠧࡢ࡮ࡤࡶࡦࡨࠧ῍")		in NGmuWwXdLQ6nMltx39FYECohJ: svA3Xnq5GbkTcZPHd,xCLQK8kh39sjyi5DXSZAVeI,YYmyQXglbEewzL3IA2Sd = LHQrCUdfa0t4PYce7xNGJbSDRnvIX(lQHXdV9Nzf6BLqS8D)
	elif yTMWeCgUROcvtsblfK85L62xPk(u"ࠨࡵ࡫ࡥ࡭࡯ࡤ࠵ࡷࠪ῎")		in NGmuWwXdLQ6nMltx39FYECohJ: svA3Xnq5GbkTcZPHd,xCLQK8kh39sjyi5DXSZAVeI,YYmyQXglbEewzL3IA2Sd = epWEGAh8dK(lQHXdV9Nzf6BLqS8D)
	elif aVLSn1xw5cK(u"ࠩࡶ࡬ࡦ࡮ࡥࡥ࠶ࡸࠫ῏")		in NGmuWwXdLQ6nMltx39FYECohJ: svA3Xnq5GbkTcZPHd,xCLQK8kh39sjyi5DXSZAVeI,YYmyQXglbEewzL3IA2Sd = epWEGAh8dK(lQHXdV9Nzf6BLqS8D)
	elif OVmSuf8tpd(u"ࠪࡩ࡬ࡿ࡮ࡰࡹࠪῐ")		in NGmuWwXdLQ6nMltx39FYECohJ: svA3Xnq5GbkTcZPHd,xCLQK8kh39sjyi5DXSZAVeI,YYmyQXglbEewzL3IA2Sd = rr8BvkwspK(lQHXdV9Nzf6BLqS8D)
	elif wwyUWMFAsO(u"ࠫࡹࡼࡦࡶࡰࠪῑ")		in NGmuWwXdLQ6nMltx39FYECohJ: svA3Xnq5GbkTcZPHd,xCLQK8kh39sjyi5DXSZAVeI,YYmyQXglbEewzL3IA2Sd = tjAQk8gwul(lQHXdV9Nzf6BLqS8D)
	elif FhcnOB9t3frzvXb(u"ࠬࡺࡶ࡬ࡵࡤࠫῒ")		in NGmuWwXdLQ6nMltx39FYECohJ: svA3Xnq5GbkTcZPHd,xCLQK8kh39sjyi5DXSZAVeI,YYmyQXglbEewzL3IA2Sd = tjAQk8gwul(lQHXdV9Nzf6BLqS8D)
	elif jYaM5vilgZdFx6QHbApwVXO8et(u"࠭ࡴࡷ࠯ࡩ࠲ࡨࡵ࡭ࠨΐ")		in NGmuWwXdLQ6nMltx39FYECohJ: svA3Xnq5GbkTcZPHd,xCLQK8kh39sjyi5DXSZAVeI,YYmyQXglbEewzL3IA2Sd = tjAQk8gwul(lQHXdV9Nzf6BLqS8D)
	elif hjNP5w9srJz2QpVISxBfndbD4CkXvl(u"ࠧࡩࡣ࡯ࡥࡨ࡯࡭ࡢࠩ῔")		in NGmuWwXdLQ6nMltx39FYECohJ: svA3Xnq5GbkTcZPHd,xCLQK8kh39sjyi5DXSZAVeI,YYmyQXglbEewzL3IA2Sd = zzRXnV0x6N(lQHXdV9Nzf6BLqS8D)
	elif gSmqZU0plur2xKPJwQA(u"ࠨࡵ࡫ࡳࡴ࡬ࡰࡳࡱࠪ῕")		in NGmuWwXdLQ6nMltx39FYECohJ: svA3Xnq5GbkTcZPHd,xCLQK8kh39sjyi5DXSZAVeI,YYmyQXglbEewzL3IA2Sd = yLKZ3U5T8o(lQHXdV9Nzf6BLqS8D)
	elif ZSJVq5XDrRot(u"ࠩࡰࡽࡪ࡭ࡹࡷ࡫ࡳࠫῖ")		in NGmuWwXdLQ6nMltx39FYECohJ: svA3Xnq5GbkTcZPHd,xCLQK8kh39sjyi5DXSZAVeI,YYmyQXglbEewzL3IA2Sd = cnLUO2AkRQwXT1jhF5r(lQHXdV9Nzf6BLqS8D)
	elif aFQoGfmYKyqLU6X8libw9k3ncW5(u"ࠪࡺࡸ࠺ࡵࠨῗ")			in NGmuWwXdLQ6nMltx39FYECohJ: svA3Xnq5GbkTcZPHd,xCLQK8kh39sjyi5DXSZAVeI,YYmyQXglbEewzL3IA2Sd = D2DLOUb5Qx(lQHXdV9Nzf6BLqS8D)
	elif pEo8g7riWVL014KaRtzQ(u"ࠫ࡫ࡧࡪࡦࡴࠪῘ")		in NGmuWwXdLQ6nMltx39FYECohJ: svA3Xnq5GbkTcZPHd,xCLQK8kh39sjyi5DXSZAVeI,YYmyQXglbEewzL3IA2Sd = RaP18ex9yp(lQHXdV9Nzf6BLqS8D)
	elif EDPaWgMt1SwNn8o(u"ࠬࡩࡩ࡮ࡣࡱࡳࡼ࠭Ῑ")		in NGmuWwXdLQ6nMltx39FYECohJ: svA3Xnq5GbkTcZPHd,xCLQK8kh39sjyi5DXSZAVeI,YYmyQXglbEewzL3IA2Sd = iNwU014Zu7(lQHXdV9Nzf6BLqS8D)
	elif ZSJVq5XDrRot(u"࠭࡮ࡦࡹࡦ࡭ࡲࡧࠧῚ")		in NGmuWwXdLQ6nMltx39FYECohJ: svA3Xnq5GbkTcZPHd,xCLQK8kh39sjyi5DXSZAVeI,YYmyQXglbEewzL3IA2Sd = iNwU014Zu7(lQHXdV9Nzf6BLqS8D)
	elif ffCSGrTJYPsxgVQWKLtHU3iMwB(u"ࠧࡤ࡫ࡰࡥ࠲ࡲࡩࡨࡪࡷࠫΊ")	in NGmuWwXdLQ6nMltx39FYECohJ: svA3Xnq5GbkTcZPHd,xCLQK8kh39sjyi5DXSZAVeI,YYmyQXglbEewzL3IA2Sd = zeHi9kbLcZ(lQHXdV9Nzf6BLqS8D)
	elif FhcnOB9t3frzvXb(u"ࠨࡥ࡬ࡱࡦࡲࡩࡨࡪࡷࠫ῜")	in NGmuWwXdLQ6nMltx39FYECohJ: svA3Xnq5GbkTcZPHd,xCLQK8kh39sjyi5DXSZAVeI,YYmyQXglbEewzL3IA2Sd = zeHi9kbLcZ(lQHXdV9Nzf6BLqS8D)
	elif m6b7CoBk4EQ(u"ࠩࡰࡽࡨ࡯࡭ࡢࠩ῝")		in NGmuWwXdLQ6nMltx39FYECohJ: svA3Xnq5GbkTcZPHd,xCLQK8kh39sjyi5DXSZAVeI,YYmyQXglbEewzL3IA2Sd = z8zlcAXu7D(lQHXdV9Nzf6BLqS8D)
	elif AAgpHN0nMZ(u"ࠪࡻࡪࡩࡩ࡮ࡣࠪ῞")		in NGmuWwXdLQ6nMltx39FYECohJ: svA3Xnq5GbkTcZPHd,xCLQK8kh39sjyi5DXSZAVeI,YYmyQXglbEewzL3IA2Sd = GAOBVmq23j(lQHXdV9Nzf6BLqS8D)
	elif sArCMRngQNmXkBoKv(u"ࠫࡧࡵ࡫ࡳࡣࠪ῟")		in NGmuWwXdLQ6nMltx39FYECohJ: svA3Xnq5GbkTcZPHd,xCLQK8kh39sjyi5DXSZAVeI,YYmyQXglbEewzL3IA2Sd = dpINwXmrSA(lQHXdV9Nzf6BLqS8D)
	elif fR68jBGWCzUsFXdlTKPOScugm(u"ࠬࡪࡡࡪ࡮ࡼࡱࡴࡺࡩࡰࡰࠪῠ")	in NGmuWwXdLQ6nMltx39FYECohJ: svA3Xnq5GbkTcZPHd,xCLQK8kh39sjyi5DXSZAVeI,YYmyQXglbEewzL3IA2Sd = hyzijIU4w3(lQHXdV9Nzf6BLqS8D)
	elif Ej67fFyoqW8kbV2HdSK(u"࠭ࡡࡳࡤ࡯࡭ࡴࡴࡺࠨῡ")		in NGmuWwXdLQ6nMltx39FYECohJ: svA3Xnq5GbkTcZPHd,xCLQK8kh39sjyi5DXSZAVeI,YYmyQXglbEewzL3IA2Sd = eL6whX7imV(lQHXdV9Nzf6BLqS8D)
	elif OVmSuf8tpd(u"ࠧࡥ࠰ࡨ࡫ࡾࡨࡥࡴࡶ࠱ࡨࠬῢ")	in NGmuWwXdLQ6nMltx39FYECohJ: svA3Xnq5GbkTcZPHd,xCLQK8kh39sjyi5DXSZAVeI,YYmyQXglbEewzL3IA2Sd = kmdSKeBIwViM9t3(u"ࠨࠩΰ"),[ZSJVq5XDrRot(u"ࠩࠪῤ")],[lQHXdV9Nzf6BLqS8D]
	elif sArCMRngQNmXkBoKv(u"ࠪࡩ࡬ࡿࡢࡦࡵࡷࠫῥ")		in NGmuWwXdLQ6nMltx39FYECohJ: svA3Xnq5GbkTcZPHd,xCLQK8kh39sjyi5DXSZAVeI,YYmyQXglbEewzL3IA2Sd = KK7JZeE4GP(lQHXdV9Nzf6BLqS8D)
	elif AAgpHN0nMZ(u"ࠫࡸ࡫ࡲࡪࡧࡶ࠸ࡼࡧࡴࡤࡪࠪῦ")	in NGmuWwXdLQ6nMltx39FYECohJ: svA3Xnq5GbkTcZPHd,xCLQK8kh39sjyi5DXSZAVeI,YYmyQXglbEewzL3IA2Sd = NpYuwRIMtG(lQHXdV9Nzf6BLqS8D)
	elif OVmSuf8tpd(u"ࠬࡻࡰࡣࡣࡰࠫῧ") 		in NGmuWwXdLQ6nMltx39FYECohJ: svA3Xnq5GbkTcZPHd,xCLQK8kh39sjyi5DXSZAVeI,YYmyQXglbEewzL3IA2Sd = JcDaEHuiS8TqBbOhWe4ZgwknoC1L3r(u"࠭ࠧῨ"),[m6b7CoBk4EQ(u"ࠧࠨῩ")],[lQHXdV9Nzf6BLqS8D]
	else: svA3Xnq5GbkTcZPHd,xCLQK8kh39sjyi5DXSZAVeI,YYmyQXglbEewzL3IA2Sd = J3OCAmZVcn(u"ࠨࡐࡈࡉࡉࡥࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫῪ"),[kRYWcNuAazr4jtmBoxFVS19Z6(u"ࠩࠪΎ")],[lQHXdV9Nzf6BLqS8D]
	if svA3Xnq5GbkTcZPHd!=m6b7CoBk4EQ(u"ࠪࡉ࡝ࡏࡔࡠࡃࡏࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨῬ"): svA3Xnq5GbkTcZPHd = XogUJZEijT7KWbxeO6(u"ࠫࡋࡧࡩ࡭ࡧࡧ࠾ࠥࠦࠧ῭")+svA3Xnq5GbkTcZPHd
	return svA3Xnq5GbkTcZPHd,xCLQK8kh39sjyi5DXSZAVeI,YYmyQXglbEewzL3IA2Sd
def VWiyE8MKoehknCIp9Ng(svA3Xnq5GbkTcZPHd,xCLQK8kh39sjyi5DXSZAVeI,YYmyQXglbEewzL3IA2Sd):
	mwXy4HaY1uWtlvbZVcN7,R28S4pFmAojEW7CGnx = [],[]
	for title,RRucmYBaXegTtNOdGHMQ in zip(xCLQK8kh39sjyi5DXSZAVeI,YYmyQXglbEewzL3IA2Sd):
		if fDEdQSsq1uPoU(RRucmYBaXegTtNOdGHMQ):
			mwXy4HaY1uWtlvbZVcN7.append(title)
			R28S4pFmAojEW7CGnx.append(RRucmYBaXegTtNOdGHMQ)
	if not R28S4pFmAojEW7CGnx and not svA3Xnq5GbkTcZPHd: svA3Xnq5GbkTcZPHd = xuYvdJpOEyQKTLNwb(u"ࠬࡌࡡࡪ࡮ࡨࡨࠬ΅")
	return svA3Xnq5GbkTcZPHd,mwXy4HaY1uWtlvbZVcN7,R28S4pFmAojEW7CGnx
def D8vPke4ZbiQftlqS7IJwB(Wnt7oIL4qyl3Mgzi0mCw9,url,source,hcVjpT7mOqX):
	global EiyV87pgJjI4U9loKunYws3Rbr1G6,lOSqboWDwFL2NdTPhzysxVXa4Em,LprUo5sYBzuS0RtqN4,tmOrhVs21Uil6J9HnxdWpE,XVm6dqQCG5wAkeb4gIJT3ScK7zjWZE
	kkCH69JNxuZaz5R1pnMSF = []
	T8fQ4SY5eRbvzwn7OEXlCd1V = (LmcNhzY6fQPd2JyCGslkSr(u"࠭ࡔࡪ࡯ࡨࡳࡺࡺࠧ`"),[],[])
	lOSqboWDwFL2NdTPhzysxVXa4Em[hcVjpT7mOqX],LprUo5sYBzuS0RtqN4[hcVjpT7mOqX],tmOrhVs21Uil6J9HnxdWpE[hcVjpT7mOqX],XVm6dqQCG5wAkeb4gIJT3ScK7zjWZE[hcVjpT7mOqX] = T8fQ4SY5eRbvzwn7OEXlCd1V,T8fQ4SY5eRbvzwn7OEXlCd1V,T8fQ4SY5eRbvzwn7OEXlCd1V,T8fQ4SY5eRbvzwn7OEXlCd1V
	tBcPrblaOKNLzuqVhnSUR5kw = [JNKzVnbog35ZUs7BYP4rucQjaHLt,tIEna6Bhd8uwik,INMJSh6RWVymsp9l8xDGKo,SI4bqd5yjUlP3eAFcmXQVCzMi0ErZ]
	for anAvlXWOpg in tBcPrblaOKNLzuqVhnSUR5kw:
		FbPf49XCZ5pTh87WD6aVlIBEyKRqNt = c3cgVjNv1rde.Thread(target=anAvlXWOpg,args=(url,source,hcVjpT7mOqX))
		FbPf49XCZ5pTh87WD6aVlIBEyKRqNt.start()
		if lOSqboWDwFL2NdTPhzysxVXa4Em[hcVjpT7mOqX][MM2BQ7xrAfNivgenXPytGYOs0DEHRC(u"࠰ྫ")]==MM2BQ7xrAfNivgenXPytGYOs0DEHRC(u"ࠧࡆ࡚ࡌࡘࡤࡇࡌࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬ῰") or (not lOSqboWDwFL2NdTPhzysxVXa4Em[hcVjpT7mOqX][MM2BQ7xrAfNivgenXPytGYOs0DEHRC(u"࠰ྫ")] and lOSqboWDwFL2NdTPhzysxVXa4Em[hcVjpT7mOqX][jYaM5vilgZdFx6QHbApwVXO8et(u"࠳ྫྷ")]): break
		if LprUo5sYBzuS0RtqN4[hcVjpT7mOqX][xuYvdJpOEyQKTLNwb(u"࠲ྭ")]==ffCSGrTJYPsxgVQWKLtHU3iMwB(u"ࠨࡇ࡛ࡍ࡙ࡥࡁࡍࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭῱") or (not LprUo5sYBzuS0RtqN4[hcVjpT7mOqX][xuYvdJpOEyQKTLNwb(u"࠲ྭ")] and LprUo5sYBzuS0RtqN4[hcVjpT7mOqX][J3OCAmZVcn(u"࠵ྮ")]): break
		if tmOrhVs21Uil6J9HnxdWpE[hcVjpT7mOqX][eeIL1TfgFQJaKqVD8hGNPEZ(u"࠴ྯ")]==eeIL1TfgFQJaKqVD8hGNPEZ(u"ࠩࡈ࡜ࡎ࡚࡟ࡂࡎࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧῲ") or (not tmOrhVs21Uil6J9HnxdWpE[hcVjpT7mOqX][eeIL1TfgFQJaKqVD8hGNPEZ(u"࠴ྯ")] and tmOrhVs21Uil6J9HnxdWpE[hcVjpT7mOqX][FhcnOB9t3frzvXb(u"࠷ྰ")]): break
		if XVm6dqQCG5wAkeb4gIJT3ScK7zjWZE[hcVjpT7mOqX][ffCSGrTJYPsxgVQWKLtHU3iMwB(u"࠶ྱ")]==ffCSGrTJYPsxgVQWKLtHU3iMwB(u"ࠪࡉ࡝ࡏࡔࡠࡃࡏࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨῳ") or (not XVm6dqQCG5wAkeb4gIJT3ScK7zjWZE[hcVjpT7mOqX][ffCSGrTJYPsxgVQWKLtHU3iMwB(u"࠶ྱ")] and XVm6dqQCG5wAkeb4gIJT3ScK7zjWZE[hcVjpT7mOqX][yTMWeCgUROcvtsblfK85L62xPk(u"࠲ྲ")]): break
		luMHeSgCBaPrb9KvUjNFqcR.sleep(gnfv8UtZ3daGqpjzk(u"࠱࠰࠺࠹ླ"))
		kkCH69JNxuZaz5R1pnMSF.append(FbPf49XCZ5pTh87WD6aVlIBEyKRqNt)
	timeout,step = AAgpHN0nMZ(u"࠶࠴ྵ"),kRYWcNuAazr4jtmBoxFVS19Z6(u"࠴ྴ")
	for T8fQ4SY5eRbvzwn7OEXlCd1V in range(timeout//step):
		if lOSqboWDwFL2NdTPhzysxVXa4Em[hcVjpT7mOqX][fR68jBGWCzUsFXdlTKPOScugm(u"࠴ྶ")]==OVmSuf8tpd(u"ࠫࡊ࡞ࡉࡕࡡࡄࡐࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩῴ") or (not lOSqboWDwFL2NdTPhzysxVXa4Em[hcVjpT7mOqX][fR68jBGWCzUsFXdlTKPOScugm(u"࠴ྶ")] and lOSqboWDwFL2NdTPhzysxVXa4Em[hcVjpT7mOqX][ffCSGrTJYPsxgVQWKLtHU3iMwB(u"࠷ྷ")]): break
		if LprUo5sYBzuS0RtqN4[hcVjpT7mOqX][XogUJZEijT7KWbxeO6(u"࠶ྸ")]==hjNP5w9srJz2QpVISxBfndbD4CkXvl(u"ࠬࡋࡘࡊࡖࡢࡅࡑࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪ῵") or (not LprUo5sYBzuS0RtqN4[hcVjpT7mOqX][XogUJZEijT7KWbxeO6(u"࠶ྸ")] and LprUo5sYBzuS0RtqN4[hcVjpT7mOqX][m6b7CoBk4EQ(u"࠲ྐྵ")]): break
		if tmOrhVs21Uil6J9HnxdWpE[hcVjpT7mOqX][eeIL1TfgFQJaKqVD8hGNPEZ(u"࠱ྺ")]==hjNP5w9srJz2QpVISxBfndbD4CkXvl(u"࠭ࡅ࡙ࡋࡗࡣࡆࡒࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫῶ") or (not tmOrhVs21Uil6J9HnxdWpE[hcVjpT7mOqX][eeIL1TfgFQJaKqVD8hGNPEZ(u"࠱ྺ")] and tmOrhVs21Uil6J9HnxdWpE[hcVjpT7mOqX][jYaM5vilgZdFx6QHbApwVXO8et(u"࠴ྻ")]): break
		if XVm6dqQCG5wAkeb4gIJT3ScK7zjWZE[hcVjpT7mOqX][ffCSGrTJYPsxgVQWKLtHU3iMwB(u"࠳ྼ")]==xuYvdJpOEyQKTLNwb(u"ࠧࡆ࡚ࡌࡘࡤࡇࡌࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬῷ") or (not XVm6dqQCG5wAkeb4gIJT3ScK7zjWZE[hcVjpT7mOqX][ffCSGrTJYPsxgVQWKLtHU3iMwB(u"࠳ྼ")] and XVm6dqQCG5wAkeb4gIJT3ScK7zjWZE[hcVjpT7mOqX][OVmSuf8tpd(u"࠶྽")]): break
		luMHeSgCBaPrb9KvUjNFqcR.sleep(step)
	for FbPf49XCZ5pTh87WD6aVlIBEyKRqNt in kkCH69JNxuZaz5R1pnMSF: FbPf49XCZ5pTh87WD6aVlIBEyKRqNt.join(sArCMRngQNmXkBoKv(u"࠶྾"))
	o9FNQj8ZSYP0HceCI7g = pEo8g7riWVL014KaRtzQ(u"ࠨࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡤ࠸ࠧῸ")
	svA3Xnq5GbkTcZPHd,xCLQK8kh39sjyi5DXSZAVeI,YYmyQXglbEewzL3IA2Sd = lOSqboWDwFL2NdTPhzysxVXa4Em[hcVjpT7mOqX]
	YYmyQXglbEewzL3IA2Sd = IIiS4d67gwfan3hqzmYVs5opRKFZMb(YYmyQXglbEewzL3IA2Sd)
	EiyV87pgJjI4U9loKunYws3Rbr1G6[hcVjpT7mOqX] = Wnt7oIL4qyl3Mgzi0mCw9,xCLQK8kh39sjyi5DXSZAVeI,YYmyQXglbEewzL3IA2Sd
	if svA3Xnq5GbkTcZPHd==LmcNhzY6fQPd2JyCGslkSr(u"ࠩࡈ࡜ࡎ࡚࡟ࡂࡎࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧΌ") or YYmyQXglbEewzL3IA2Sd: return o9FNQj8ZSYP0HceCI7g,svA3Xnq5GbkTcZPHd,xCLQK8kh39sjyi5DXSZAVeI,YYmyQXglbEewzL3IA2Sd
	Wnt7oIL4qyl3Mgzi0mCw9 += kmdSKeBIwViM9t3(u"ࠪࡠࡳࡘࡥࡴࡱ࡯ࡺࡪࡸࠠ࠳࠼ࠣࠤࠬῺ")+svA3Xnq5GbkTcZPHd.replace(c4QSTnPiWUCjhrLlwGB(u"ࠫࡡࡴࠧΏ"),pEo8g7riWVL014KaRtzQ(u"ࠬ࠭ῼ")).replace(MM2BQ7xrAfNivgenXPytGYOs0DEHRC(u"࠭࡜ࡳࠩ´"),gnfv8UtZ3daGqpjzk(u"ࠧࠨ῾"))[:jYaM5vilgZdFx6QHbApwVXO8et(u"࠾࠰྿")]
	o9FNQj8ZSYP0HceCI7g = EDPaWgMt1SwNn8o(u"ࠨࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡤ࠹ࠧ῿")
	svA3Xnq5GbkTcZPHd,xCLQK8kh39sjyi5DXSZAVeI,YYmyQXglbEewzL3IA2Sd = LprUo5sYBzuS0RtqN4[hcVjpT7mOqX]
	YYmyQXglbEewzL3IA2Sd = IIiS4d67gwfan3hqzmYVs5opRKFZMb(YYmyQXglbEewzL3IA2Sd)
	EiyV87pgJjI4U9loKunYws3Rbr1G6[hcVjpT7mOqX] = Wnt7oIL4qyl3Mgzi0mCw9,xCLQK8kh39sjyi5DXSZAVeI,YYmyQXglbEewzL3IA2Sd
	if svA3Xnq5GbkTcZPHd==eeIL1TfgFQJaKqVD8hGNPEZ(u"ࠫࡊ࡞ࡉࡕࡡࡄࡐࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩࠀ") or YYmyQXglbEewzL3IA2Sd: return o9FNQj8ZSYP0HceCI7g,svA3Xnq5GbkTcZPHd,xCLQK8kh39sjyi5DXSZAVeI,YYmyQXglbEewzL3IA2Sd
	Wnt7oIL4qyl3Mgzi0mCw9 += JMLhEyaBWmskovGHTrVCxQ08(u"ࠬࡢ࡮ࡓࡧࡶࡳࡱࡼࡥࡳࠢ࠶࠾ࠥࠦࠧࠁ")+svA3Xnq5GbkTcZPHd.replace(JcDaEHuiS8TqBbOhWe4ZgwknoC1L3r(u"࠭࡜࡯ࠩࠂ"),XogUJZEijT7KWbxeO6(u"ࠧࠨࠃ")).replace(m6b7CoBk4EQ(u"ࠨ࡞ࡵࠫࠄ"),eeIL1TfgFQJaKqVD8hGNPEZ(u"ࠩࠪࠅ"))[:gSmqZU0plur2xKPJwQA(u"࠸࠱࿀")]
	o9FNQj8ZSYP0HceCI7g = hjNP5w9srJz2QpVISxBfndbD4CkXvl(u"ࠪࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘ࡟࠵ࠩࠆ")
	svA3Xnq5GbkTcZPHd,xCLQK8kh39sjyi5DXSZAVeI,YYmyQXglbEewzL3IA2Sd = tmOrhVs21Uil6J9HnxdWpE[hcVjpT7mOqX]
	YYmyQXglbEewzL3IA2Sd = IIiS4d67gwfan3hqzmYVs5opRKFZMb(YYmyQXglbEewzL3IA2Sd)
	EiyV87pgJjI4U9loKunYws3Rbr1G6[hcVjpT7mOqX] = Wnt7oIL4qyl3Mgzi0mCw9,xCLQK8kh39sjyi5DXSZAVeI,YYmyQXglbEewzL3IA2Sd
	if svA3Xnq5GbkTcZPHd==JMLhEyaBWmskovGHTrVCxQ08(u"ࠫࡊ࡞ࡉࡕࡡࡄࡐࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩࠇ") or YYmyQXglbEewzL3IA2Sd: return o9FNQj8ZSYP0HceCI7g,svA3Xnq5GbkTcZPHd,xCLQK8kh39sjyi5DXSZAVeI,YYmyQXglbEewzL3IA2Sd
	Wnt7oIL4qyl3Mgzi0mCw9 += FhcnOB9t3frzvXb(u"ࠬࡢ࡮ࡓࡧࡶࡳࡱࡼࡥࡳࠢ࠷࠾ࠥࠦࠧࠈ")+svA3Xnq5GbkTcZPHd.replace(kRYWcNuAazr4jtmBoxFVS19Z6(u"࠭࡜࡯ࠩࠉ"),pEo8g7riWVL014KaRtzQ(u"ࠧࠨࠊ")).replace(XogUJZEijT7KWbxeO6(u"ࠨ࡞ࡵࠫࠋ"),pEo8g7riWVL014KaRtzQ(u"ࠩࠪࠌ"))[:jYaM5vilgZdFx6QHbApwVXO8et(u"࠹࠲࿁")]
	o9FNQj8ZSYP0HceCI7g = Ej67fFyoqW8kbV2HdSK(u"ࠪࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘ࡟࠶ࠩࠍ")
	svA3Xnq5GbkTcZPHd,xCLQK8kh39sjyi5DXSZAVeI,YYmyQXglbEewzL3IA2Sd = XVm6dqQCG5wAkeb4gIJT3ScK7zjWZE[hcVjpT7mOqX]
	YYmyQXglbEewzL3IA2Sd = IIiS4d67gwfan3hqzmYVs5opRKFZMb(YYmyQXglbEewzL3IA2Sd)
	EiyV87pgJjI4U9loKunYws3Rbr1G6[hcVjpT7mOqX] = Wnt7oIL4qyl3Mgzi0mCw9,xCLQK8kh39sjyi5DXSZAVeI,YYmyQXglbEewzL3IA2Sd
	if svA3Xnq5GbkTcZPHd==c4QSTnPiWUCjhrLlwGB(u"ࠫࡊ࡞ࡉࡕࡡࡄࡐࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩࠎ") or YYmyQXglbEewzL3IA2Sd: return o9FNQj8ZSYP0HceCI7g,svA3Xnq5GbkTcZPHd,xCLQK8kh39sjyi5DXSZAVeI,YYmyQXglbEewzL3IA2Sd
	Wnt7oIL4qyl3Mgzi0mCw9 += sArCMRngQNmXkBoKv(u"ࠬࡢ࡮ࡓࡧࡶࡳࡱࡼࡥࡳࠢ࠸࠾ࠥࠦࠧࠏ")+svA3Xnq5GbkTcZPHd.replace(XogUJZEijT7KWbxeO6(u"࠭࡜࡯ࠩࠐ"),yTMWeCgUROcvtsblfK85L62xPk(u"ࠧࠨࠑ")).replace(kRYWcNuAazr4jtmBoxFVS19Z6(u"ࠨ࡞ࡵࠫࠒ"),J3OCAmZVcn(u"ࠩࠪࠓ"))[:eeIL1TfgFQJaKqVD8hGNPEZ(u"࠺࠳࿂")]
	EiyV87pgJjI4U9loKunYws3Rbr1G6[hcVjpT7mOqX] = Wnt7oIL4qyl3Mgzi0mCw9,xCLQK8kh39sjyi5DXSZAVeI,YYmyQXglbEewzL3IA2Sd
	return o9FNQj8ZSYP0HceCI7g,Wnt7oIL4qyl3Mgzi0mCw9,xCLQK8kh39sjyi5DXSZAVeI,YYmyQXglbEewzL3IA2Sd
def JNKzVnbog35ZUs7BYP4rucQjaHLt(url,source,hcVjpT7mOqX):
	NGmuWwXdLQ6nMltx39FYECohJ = d78KRnJmBWscGua0XMk(url,J3OCAmZVcn(u"ࠪࡲࡦࡳࡥࠨࠔ"))
	YYmyQXglbEewzL3IA2Sd = []
	if   yTMWeCgUROcvtsblfK85L62xPk(u"ࠫࡾࡵࡵࡵࡷࠪࠕ")		in NGmuWwXdLQ6nMltx39FYECohJ: svA3Xnq5GbkTcZPHd,xCLQK8kh39sjyi5DXSZAVeI,YYmyQXglbEewzL3IA2Sd = gmlsMyZIhB(url)
	elif kRYWcNuAazr4jtmBoxFVS19Z6(u"ࠬࡿ࠲ࡶ࠰ࡥࡩࠬࠖ")		in NGmuWwXdLQ6nMltx39FYECohJ: svA3Xnq5GbkTcZPHd,xCLQK8kh39sjyi5DXSZAVeI,YYmyQXglbEewzL3IA2Sd = gmlsMyZIhB(url)
	elif JMLhEyaBWmskovGHTrVCxQ08(u"࠭ࡧࡰࡱࡪࡰࡪࡻࡳࡦࡴࡦࡳࠬࠗ") in NGmuWwXdLQ6nMltx39FYECohJ: svA3Xnq5GbkTcZPHd,xCLQK8kh39sjyi5DXSZAVeI,YYmyQXglbEewzL3IA2Sd = ILFlPrWyapdhbCGY6xO7Qeq(url)
	elif aFQoGfmYKyqLU6X8libw9k3ncW5(u"ࠧࡱࡪࡲࡸࡴࡹ࠮ࡢࡲࡳ࠲࡬࠭࠘")	in url   : svA3Xnq5GbkTcZPHd,xCLQK8kh39sjyi5DXSZAVeI,YYmyQXglbEewzL3IA2Sd = hEj0s7N1WlBPGK(url)
	elif AAgpHN0nMZ(u"ࠨࡦࡤ࡭ࡱࡿ࡭ࡰࡶ࡬ࡳࡳ࠭࠙")	in NGmuWwXdLQ6nMltx39FYECohJ: svA3Xnq5GbkTcZPHd,xCLQK8kh39sjyi5DXSZAVeI,YYmyQXglbEewzL3IA2Sd = hyzijIU4w3(url)
	elif ZSJVq5XDrRot(u"ࠩࡰࡳࡸ࡮ࡡࡩࡦࡤࠫࠚ")		in NGmuWwXdLQ6nMltx39FYECohJ: svA3Xnq5GbkTcZPHd,xCLQK8kh39sjyi5DXSZAVeI,YYmyQXglbEewzL3IA2Sd = WW4JOYTltX53gcA2Uvbya0E6BIo(url)
	elif m6b7CoBk4EQ(u"ࠪࡪࡦࡹࡥ࡭ࡪࡧࠫࠛ")		in url   : svA3Xnq5GbkTcZPHd,xCLQK8kh39sjyi5DXSZAVeI,YYmyQXglbEewzL3IA2Sd = L5Wip7lPhd(url)
	elif ffCSGrTJYPsxgVQWKLtHU3iMwB(u"ࠫࡦࡸࡡࡣ࡮ࡲࡥࡩࡹࠧࠜ")	in NGmuWwXdLQ6nMltx39FYECohJ: svA3Xnq5GbkTcZPHd,xCLQK8kh39sjyi5DXSZAVeI,YYmyQXglbEewzL3IA2Sd = uzlMmh1dUNbS(url)
	elif aFQoGfmYKyqLU6X8libw9k3ncW5(u"ࠬࡧࡲࡤࡪ࡬ࡺࡪ࠭ࠝ")		in NGmuWwXdLQ6nMltx39FYECohJ: svA3Xnq5GbkTcZPHd,xCLQK8kh39sjyi5DXSZAVeI,YYmyQXglbEewzL3IA2Sd = MkjyorAv4EQ19ftNOCRcTWsXuJn(url)
	elif pEo8g7riWVL014KaRtzQ(u"࠭ࡢࡶࡼࡽࡺࡷࡲࠧࠞ")		in NGmuWwXdLQ6nMltx39FYECohJ: svA3Xnq5GbkTcZPHd,xCLQK8kh39sjyi5DXSZAVeI,YYmyQXglbEewzL3IA2Sd = TV2vt3XUsBcMQJOZ56j7(url)
	elif MM2BQ7xrAfNivgenXPytGYOs0DEHRC(u"ࠧࡦ࠷ࡷࡷࡦࡸࠧࠟ")		in NGmuWwXdLQ6nMltx39FYECohJ: svA3Xnq5GbkTcZPHd,xCLQK8kh39sjyi5DXSZAVeI,YYmyQXglbEewzL3IA2Sd = kb80Jxa3ResnB4SGyiMXfDEKgQLT(url)
	elif xuYvdJpOEyQKTLNwb(u"ࠨࡨࡤࡧࡺࡲࡴࡺࡤࡲࡳࡰࡹࠧࠠ")	in NGmuWwXdLQ6nMltx39FYECohJ: svA3Xnq5GbkTcZPHd,xCLQK8kh39sjyi5DXSZAVeI,YYmyQXglbEewzL3IA2Sd = vvl04Fn8R9tjJOxN(url)
	elif jYaM5vilgZdFx6QHbApwVXO8et(u"ࠩ࡬ࡲ࡫ࡲࡡ࡮࠰ࡦࡧࠬࠡ")	in NGmuWwXdLQ6nMltx39FYECohJ: svA3Xnq5GbkTcZPHd,xCLQK8kh39sjyi5DXSZAVeI,YYmyQXglbEewzL3IA2Sd = vvl04Fn8R9tjJOxN(url)
	elif FhcnOB9t3frzvXb(u"ࠪࡹࡵࡨࡡ࡮ࠩࠢ") 		in NGmuWwXdLQ6nMltx39FYECohJ: svA3Xnq5GbkTcZPHd,xCLQK8kh39sjyi5DXSZAVeI,YYmyQXglbEewzL3IA2Sd = yTMWeCgUROcvtsblfK85L62xPk(u"ࠫࠬࠣ"),[JcDaEHuiS8TqBbOhWe4ZgwknoC1L3r(u"ࠬ࠭ࠤ")],[url]
	elif MM2BQ7xrAfNivgenXPytGYOs0DEHRC(u"࠭࡬ࡪ࡫ࡹ࡭ࡩ࡫࡯ࠨࠥ") 	in NGmuWwXdLQ6nMltx39FYECohJ: svA3Xnq5GbkTcZPHd,xCLQK8kh39sjyi5DXSZAVeI,YYmyQXglbEewzL3IA2Sd = JGyIOL4U0qQtkTHioeYnVrWaz(url)
	elif OVmSuf8tpd(u"ࠧ࡮ࡲ࠷ࡹࡵࡲ࡯ࡢࡦࠪࠦ")	in NGmuWwXdLQ6nMltx39FYECohJ: svA3Xnq5GbkTcZPHd,xCLQK8kh39sjyi5DXSZAVeI,YYmyQXglbEewzL3IA2Sd = E4O2Qwmp0idoL5RVUHCnrZ(url)
	elif JMLhEyaBWmskovGHTrVCxQ08(u"ࠨࡴࡤࡴ࡮ࡪࡶࡪࡦࡨࡳࠬࠧ") 	in NGmuWwXdLQ6nMltx39FYECohJ: svA3Xnq5GbkTcZPHd,xCLQK8kh39sjyi5DXSZAVeI,YYmyQXglbEewzL3IA2Sd = RwYPmxKihAt0svG8XHy9k(url)
	elif aVLSn1xw5cK(u"ࠩࡷࡳࡵ࠺ࡴࡰࡲࠪࠨ")		in NGmuWwXdLQ6nMltx39FYECohJ: svA3Xnq5GbkTcZPHd,xCLQK8kh39sjyi5DXSZAVeI,YYmyQXglbEewzL3IA2Sd = nX73VkBFdQyT6A98Uc5YINtKx(url)
	elif c4QSTnPiWUCjhrLlwGB(u"ࠪࡹࡵࡨࠧࠩ") 			in NGmuWwXdLQ6nMltx39FYECohJ: svA3Xnq5GbkTcZPHd,xCLQK8kh39sjyi5DXSZAVeI,YYmyQXglbEewzL3IA2Sd = VzhTg5iUbqaBln7GroD0mMjd8He(url)
	elif m6b7CoBk4EQ(u"ࠫࡺࡶࡰࠨࠪ") 			in NGmuWwXdLQ6nMltx39FYECohJ: svA3Xnq5GbkTcZPHd,xCLQK8kh39sjyi5DXSZAVeI,YYmyQXglbEewzL3IA2Sd = VzhTg5iUbqaBln7GroD0mMjd8He(url)
	elif aFQoGfmYKyqLU6X8libw9k3ncW5(u"ࠬࡻࡱ࡭ࡱࡤࡨࠬࠫ") 		in NGmuWwXdLQ6nMltx39FYECohJ: svA3Xnq5GbkTcZPHd,xCLQK8kh39sjyi5DXSZAVeI,YYmyQXglbEewzL3IA2Sd = XkbRIPzwT5hgmcJZHo13WVBQE8(url)
	elif eeIL1TfgFQJaKqVD8hGNPEZ(u"࠭ࡶࡤࡵࡷࡶࡪࡧ࡭ࠨࠬ") 	in NGmuWwXdLQ6nMltx39FYECohJ: svA3Xnq5GbkTcZPHd,xCLQK8kh39sjyi5DXSZAVeI,YYmyQXglbEewzL3IA2Sd = v2YgBsiQCX3p7NrLoxSA6adZbcz(url)
	elif kRYWcNuAazr4jtmBoxFVS19Z6(u"ࠧࡷ࡫ࡧࡦࡴࡨࠧ࠭")		in NGmuWwXdLQ6nMltx39FYECohJ: svA3Xnq5GbkTcZPHd,xCLQK8kh39sjyi5DXSZAVeI,YYmyQXglbEewzL3IA2Sd = NATMXtjE0wDV1LzpHx9rg(url)
	elif xuYvdJpOEyQKTLNwb(u"ࠨࡸ࡬ࡨࡴࢀࡡࠨ࠮") 		in NGmuWwXdLQ6nMltx39FYECohJ: svA3Xnq5GbkTcZPHd,xCLQK8kh39sjyi5DXSZAVeI,YYmyQXglbEewzL3IA2Sd = zz0V2WZwE3xHMaGfTcD(url)
	elif jYaM5vilgZdFx6QHbApwVXO8et(u"ࠩࡺࡥࡹࡩࡨࡷ࡫ࡧࡩࡴ࠭࠯") 	in NGmuWwXdLQ6nMltx39FYECohJ: svA3Xnq5GbkTcZPHd,xCLQK8kh39sjyi5DXSZAVeI,YYmyQXglbEewzL3IA2Sd = L1gWehJPDdn6a8(url)
	elif JMLhEyaBWmskovGHTrVCxQ08(u"ࠪࡻ࡮ࡴࡴࡷ࠰࡯࡭ࡻ࡫ࠧ࠰")	in NGmuWwXdLQ6nMltx39FYECohJ: svA3Xnq5GbkTcZPHd,xCLQK8kh39sjyi5DXSZAVeI,YYmyQXglbEewzL3IA2Sd = AAfueHh7pJRq(url)
	elif pEo8g7riWVL014KaRtzQ(u"ࠫࡿ࡯ࡰࡱࡻࡶ࡬ࡦࡸࡥࠨ࠱")	in NGmuWwXdLQ6nMltx39FYECohJ: svA3Xnq5GbkTcZPHd,xCLQK8kh39sjyi5DXSZAVeI,YYmyQXglbEewzL3IA2Sd = LEczFpwq2OYB37(url)
	else: svA3Xnq5GbkTcZPHd,xCLQK8kh39sjyi5DXSZAVeI,YYmyQXglbEewzL3IA2Sd = wwyUWMFAsO(u"ࠬ࠭࠲"),[],[]
	global lOSqboWDwFL2NdTPhzysxVXa4Em
	if svA3Xnq5GbkTcZPHd and svA3Xnq5GbkTcZPHd!=AAgpHN0nMZ(u"࠭ࡅ࡙ࡋࡗࡣࡆࡒࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫ࠳"): svA3Xnq5GbkTcZPHd = LmcNhzY6fQPd2JyCGslkSr(u"ࠧࡇࡣ࡬ࡰࡪࡪ࠺ࠡࠢࠪ࠴")
	lOSqboWDwFL2NdTPhzysxVXa4Em[hcVjpT7mOqX] = svA3Xnq5GbkTcZPHd,xCLQK8kh39sjyi5DXSZAVeI,YYmyQXglbEewzL3IA2Sd
	return
def tIEna6Bhd8uwik(url,source,hcVjpT7mOqX):
	global LprUo5sYBzuS0RtqN4
	if fR68jBGWCzUsFXdlTKPOScugm(u"ࠨࡻࡲࡹࡹࡻࡢࡦࠩ࠵") in url:
		LprUo5sYBzuS0RtqN4[hcVjpT7mOqX] = fR68jBGWCzUsFXdlTKPOScugm(u"ࠩࡉࡥ࡮ࡲࡥࡥ࠼ࠣࠤࡘࡱࡩࡱࡲࡨࡨࠬ࠶"),[],[]
		return
	svA3Xnq5GbkTcZPHd,xCLQK8kh39sjyi5DXSZAVeI,YYmyQXglbEewzL3IA2Sd = gnfv8UtZ3daGqpjzk(u"ࠪࠫ࠷"),[],[]
	if fDEdQSsq1uPoU(url): svA3Xnq5GbkTcZPHd,xCLQK8kh39sjyi5DXSZAVeI,YYmyQXglbEewzL3IA2Sd = PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"ࠫࠬ࠸"),[LmcNhzY6fQPd2JyCGslkSr(u"ࠬ࠭࠹")],[url]
	if not YYmyQXglbEewzL3IA2Sd: svA3Xnq5GbkTcZPHd,xCLQK8kh39sjyi5DXSZAVeI,YYmyQXglbEewzL3IA2Sd = xxC2pTyzikowhlZfjXe9(url)
	if not YYmyQXglbEewzL3IA2Sd: svA3Xnq5GbkTcZPHd,xCLQK8kh39sjyi5DXSZAVeI,YYmyQXglbEewzL3IA2Sd = ZbGHtxq8Ne2S(url)
	if not YYmyQXglbEewzL3IA2Sd:
		if svA3Xnq5GbkTcZPHd==Ej67fFyoqW8kbV2HdSK(u"࠭ࡅ࡙ࡋࡗࡣࡆࡒࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫ࠺"): svA3Xnq5GbkTcZPHd = JcDaEHuiS8TqBbOhWe4ZgwknoC1L3r(u"ࠧࠨ࠻")
		LprUo5sYBzuS0RtqN4[hcVjpT7mOqX] = OVmSuf8tpd(u"ࠨࡈࡤ࡭ࡱ࡫ࡤ࠻ࠢࠣࠫ࠼")+svA3Xnq5GbkTcZPHd,[],[]
		return
	LprUo5sYBzuS0RtqN4[hcVjpT7mOqX] = svA3Xnq5GbkTcZPHd,xCLQK8kh39sjyi5DXSZAVeI,YYmyQXglbEewzL3IA2Sd
	return
def INMJSh6RWVymsp9l8xDGKo(url,source,hcVjpT7mOqX):
	m0AGWhywZVXFtYQ = XogUJZEijT7KWbxeO6(u"ࠩࠪ࠽")
	HkKfQCS7RIa4xi3houjvl = fR68jBGWCzUsFXdlTKPOScugm(u"ࡉࡥࡱࡹࡥᄡ")
	try:
		import resolveurl as Jr5wR1XVvBj0WNKo7pbni
		HkKfQCS7RIa4xi3houjvl = Jr5wR1XVvBj0WNKo7pbni.resolve(url)
	except Exception as pHjsAUzBKJauq3LiFG05ZVh: m0AGWhywZVXFtYQ = str(pHjsAUzBKJauq3LiFG05ZVh)
	global tmOrhVs21Uil6J9HnxdWpE
	if not HkKfQCS7RIa4xi3houjvl:
		if m0AGWhywZVXFtYQ==aVLSn1xw5cK(u"ࠪࠫ࠾"):
			m0AGWhywZVXFtYQ = QQV1pDhCLqHP5a3sGvoUrJfmjXFw.format_exc()
			if m0AGWhywZVXFtYQ!=wwyUWMFAsO(u"ࠫࡓࡵ࡮ࡦࡖࡼࡴࡪࡀࠠࡏࡱࡱࡩࡡࡴࠧ࠿"): ddABnr3K9Xv8e71CzcN0Pxt.stderr.write(m0AGWhywZVXFtYQ)
		svA3Xnq5GbkTcZPHd = m0AGWhywZVXFtYQ.splitlines()[-m6b7CoBk4EQ(u"࠴࿃")]
		tmOrhVs21Uil6J9HnxdWpE[hcVjpT7mOqX] = JMLhEyaBWmskovGHTrVCxQ08(u"ࠬࡌࡡࡪ࡮ࡨࡨ࠿ࠦࠠࠨࡀ")+svA3Xnq5GbkTcZPHd,[],[]
		return
	tmOrhVs21Uil6J9HnxdWpE[hcVjpT7mOqX] = PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"࠭ࠧࡁ"),[pEo8g7riWVL014KaRtzQ(u"ࠧࠨࡂ")],[HkKfQCS7RIa4xi3houjvl]
	return
def SI4bqd5yjUlP3eAFcmXQVCzMi0ErZ(url,source,hcVjpT7mOqX):
	m0AGWhywZVXFtYQ = FhcnOB9t3frzvXb(u"ࠨࠩࡃ")
	HkKfQCS7RIa4xi3houjvl = XogUJZEijT7KWbxeO6(u"ࡊࡦࡲࡳࡦᄢ")
	try:
		import yt_dlp as pdoMXEmb6g8cD5JeZSjO3
		cuCE92TiQe43ZhvnDk0 = pdoMXEmb6g8cD5JeZSjO3.YoutubeDL({FhcnOB9t3frzvXb(u"ࠩࡱࡳࡤࡩ࡯࡭ࡱࡵࠫࡄ"): eeIL1TfgFQJaKqVD8hGNPEZ(u"࡙ࡸࡵࡦᄣ")})
		HkKfQCS7RIa4xi3houjvl = cuCE92TiQe43ZhvnDk0.extract_info(url,download=XogUJZEijT7KWbxeO6(u"ࡌࡡ࡭ࡵࡨᄤ"))
	except Exception as pHjsAUzBKJauq3LiFG05ZVh: m0AGWhywZVXFtYQ = str(pHjsAUzBKJauq3LiFG05ZVh)
	global XVm6dqQCG5wAkeb4gIJT3ScK7zjWZE
	if not HkKfQCS7RIa4xi3houjvl or pEo8g7riWVL014KaRtzQ(u"ࠪࡪࡴࡸ࡭ࡢࡶࡶࠫࡅ") not in list(HkKfQCS7RIa4xi3houjvl.keys()):
		if m0AGWhywZVXFtYQ==kmdSKeBIwViM9t3(u"ࠫࠬࡆ"):
			m0AGWhywZVXFtYQ = QQV1pDhCLqHP5a3sGvoUrJfmjXFw.format_exc()
			if m0AGWhywZVXFtYQ!=OVmSuf8tpd(u"ࠬࡔ࡯࡯ࡧࡗࡽࡵ࡫࠺ࠡࡐࡲࡲࡪࡢ࡮ࠨࡇ"): ddABnr3K9Xv8e71CzcN0Pxt.stderr.write(m0AGWhywZVXFtYQ)
		svA3Xnq5GbkTcZPHd = m0AGWhywZVXFtYQ.splitlines()[-J3OCAmZVcn(u"࠵࿄")]
		XVm6dqQCG5wAkeb4gIJT3ScK7zjWZE[hcVjpT7mOqX] = ffCSGrTJYPsxgVQWKLtHU3iMwB(u"࠭ࡆࡢ࡫࡯ࡩࡩࡀࠠࠡࠩࡈ")+svA3Xnq5GbkTcZPHd,[],[]
	else:
		xCLQK8kh39sjyi5DXSZAVeI,YYmyQXglbEewzL3IA2Sd = [],[]
		for RRucmYBaXegTtNOdGHMQ in HkKfQCS7RIa4xi3houjvl[PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"ࠧࡧࡱࡵࡱࡦࡺࡳࠨࡉ")]:
			xCLQK8kh39sjyi5DXSZAVeI.append(RRucmYBaXegTtNOdGHMQ[JMLhEyaBWmskovGHTrVCxQ08(u"ࠨࡨࡲࡶࡲࡧࡴࠨࡊ")])
			YYmyQXglbEewzL3IA2Sd.append(RRucmYBaXegTtNOdGHMQ[hjNP5w9srJz2QpVISxBfndbD4CkXvl(u"ࠩࡸࡶࡱ࠭ࡋ")])
		XVm6dqQCG5wAkeb4gIJT3ScK7zjWZE[hcVjpT7mOqX] = hjNP5w9srJz2QpVISxBfndbD4CkXvl(u"ࠪࠫࡌ"),xCLQK8kh39sjyi5DXSZAVeI,YYmyQXglbEewzL3IA2Sd
	return
def xxC2pTyzikowhlZfjXe9(url):
	wpFmEA3z8JR = A6F71g3cqN4(dALVaOWB4jKN3Tbt0Cm1ns9k5u,J3OCAmZVcn(u"ࠫࡌࡋࡔࠨࡍ"),url,xuYvdJpOEyQKTLNwb(u"ࠬ࠭ࡎ"),PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"࠭ࠧࡏ"),LmcNhzY6fQPd2JyCGslkSr(u"ࠧࠨࡐ"),eeIL1TfgFQJaKqVD8hGNPEZ(u"ࡆࡢ࡮ࡶࡩᄥ"),kmdSKeBIwViM9t3(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡗࡋࡄࡊࡔࡈࡇ࡙ࡥࡕࡓࡎ࠰࠵ࡸࡺࠧࡑ"))
	headers = wpFmEA3z8JR.headers
	if MM2BQ7xrAfNivgenXPytGYOs0DEHRC(u"ࠩࡏࡳࡨࡧࡴࡪࡱࡱࠫࡒ") in list(headers.keys()):
		RRucmYBaXegTtNOdGHMQ = wpFmEA3z8JR.headers[gnfv8UtZ3daGqpjzk(u"ࠪࡐࡴࡩࡡࡵ࡫ࡲࡲࠬࡓ")]
		if fDEdQSsq1uPoU(RRucmYBaXegTtNOdGHMQ): return ffCSGrTJYPsxgVQWKLtHU3iMwB(u"ࠫࠬࡔ"),[kRYWcNuAazr4jtmBoxFVS19Z6(u"ࠬ࠭ࡕ")],[RRucmYBaXegTtNOdGHMQ]
	return hjNP5w9srJz2QpVISxBfndbD4CkXvl(u"࠭ࡆࡢ࡫࡯ࡩࡩࡀࠠࠡࠩࡖ"),[],[]
def IIiS4d67gwfan3hqzmYVs5opRKFZMb(L5k0oWzXR7TPl3):
	if XogUJZEijT7KWbxeO6(u"ࠧ࡭࡫ࡶࡸࠬࡗ") in str(type(L5k0oWzXR7TPl3)):
		R28S4pFmAojEW7CGnx = []
		for RRucmYBaXegTtNOdGHMQ in L5k0oWzXR7TPl3:
			if m6b7CoBk4EQ(u"ࠨࡵࡷࡶࠬࡘ") in str(type(RRucmYBaXegTtNOdGHMQ)): RRucmYBaXegTtNOdGHMQ = RRucmYBaXegTtNOdGHMQ.replace(EDPaWgMt1SwNn8o(u"ࠩ࡟ࡶ࡙ࠬ"),EDPaWgMt1SwNn8o(u"࡚ࠪࠫ")).replace(PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"ࠫࡡࡴ࡛ࠧ"),PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"ࠬ࠭࡜")).strip(MM2BQ7xrAfNivgenXPytGYOs0DEHRC(u"࠭ࠠࠨ࡝"))
			R28S4pFmAojEW7CGnx.append(RRucmYBaXegTtNOdGHMQ)
	else: R28S4pFmAojEW7CGnx = L5k0oWzXR7TPl3.replace(m6b7CoBk4EQ(u"ࠧ࡝ࡴࠪ࡞"),PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"ࠨࠩ࡟")).replace(m6b7CoBk4EQ(u"ࠩ࡟ࡲࠬࡠ"),ZSJVq5XDrRot(u"ࠪࠫࡡ")).strip(aVLSn1xw5cK(u"ࠫࠥ࠭ࡢ"))
	return R28S4pFmAojEW7CGnx
def kjxV7u5PmHhrTy9SlncaMIsR1WULpw(bFEOBVfxy7nPvCdgta1U,source):
	xx1wskaWc0SMDNdLVnoF325 = JNsoWV1CXc4xy
	data = NUauTXxKLAoqQtJkglSFRWE(hosgCj2byWvuVT,pEo8g7riWVL014KaRtzQ(u"ࠬࡲࡩࡴࡶࠪࡣ"),bdhQDyjm3nPwToFHkprvCzBLUGR(u"࠭ࡓࡆࡔ࡙ࡉࡗ࡙ࠧࡤ"),bFEOBVfxy7nPvCdgta1U)
	if data:
		xCLQK8kh39sjyi5DXSZAVeI,YYmyQXglbEewzL3IA2Sd = list(zip(*data))
		return xCLQK8kh39sjyi5DXSZAVeI,YYmyQXglbEewzL3IA2Sd
	xCLQK8kh39sjyi5DXSZAVeI,YYmyQXglbEewzL3IA2Sd,wNKXCi4WZPt = [],[],[]
	for RRucmYBaXegTtNOdGHMQ in bFEOBVfxy7nPvCdgta1U:
		if gSmqZU0plur2xKPJwQA(u"ࠧ࠰࠱ࠪࡥ") not in RRucmYBaXegTtNOdGHMQ: continue
		pp5VsHSlyY0J3R7akBve8bXh,aaYDh2EzJ5ky,type,P1ajYzT8sKCx6tMl,PHUqTNVJ0ErRSwibn5gD = vcXya3WtDK8IG(RRucmYBaXegTtNOdGHMQ,source)
		PHUqTNVJ0ErRSwibn5gD = ZXFs0mEPR8qI2zj.findall(aFQoGfmYKyqLU6X8libw9k3ncW5(u"ࠨ࡞ࡧ࠯ࠬࡦ"),PHUqTNVJ0ErRSwibn5gD,ZXFs0mEPR8qI2zj.DOTALL)
		if PHUqTNVJ0ErRSwibn5gD: PHUqTNVJ0ErRSwibn5gD = int(PHUqTNVJ0ErRSwibn5gD[FhcnOB9t3frzvXb(u"࠵࿅")])
		else: PHUqTNVJ0ErRSwibn5gD = PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"࠶࿆")
		NGmuWwXdLQ6nMltx39FYECohJ = d78KRnJmBWscGua0XMk(RRucmYBaXegTtNOdGHMQ,aFQoGfmYKyqLU6X8libw9k3ncW5(u"ࠩࡱࡥࡲ࡫ࠧࡧ"))
		wNKXCi4WZPt.append([pp5VsHSlyY0J3R7akBve8bXh,aaYDh2EzJ5ky,type,P1ajYzT8sKCx6tMl,PHUqTNVJ0ErRSwibn5gD,RRucmYBaXegTtNOdGHMQ,NGmuWwXdLQ6nMltx39FYECohJ])
	if wNKXCi4WZPt:
		j3JH8ZpyGqPUwf0hWTorAtvsk = sorted(wNKXCi4WZPt,reverse=ZSJVq5XDrRot(u"ࡕࡴࡸࡩᄦ"),key=lambda key: (key[sArCMRngQNmXkBoKv(u"࠹࿌")],key[ZSJVq5XDrRot(u"࠱࿈")],key[wwyUWMFAsO(u"࠵࿉")],key[FhcnOB9t3frzvXb(u"࠵࿊")],key[Ej67fFyoqW8kbV2HdSK(u"࠱࿇")],key[Ej67fFyoqW8kbV2HdSK(u"࠹࿋")],key[Ej67fFyoqW8kbV2HdSK(u"࠼࿍")]))
		ObVlaU0fkRuTnFQsDBct4AhzMx1ISG = []
		for yJzVl8aho4tDk65mAsT3N in j3JH8ZpyGqPUwf0hWTorAtvsk:
			if yJzVl8aho4tDk65mAsT3N not in ObVlaU0fkRuTnFQsDBct4AhzMx1ISG:
				ObVlaU0fkRuTnFQsDBct4AhzMx1ISG.append(yJzVl8aho4tDk65mAsT3N)
		for pp5VsHSlyY0J3R7akBve8bXh,aaYDh2EzJ5ky,type,P1ajYzT8sKCx6tMl,PHUqTNVJ0ErRSwibn5gD,RRucmYBaXegTtNOdGHMQ,NGmuWwXdLQ6nMltx39FYECohJ in ObVlaU0fkRuTnFQsDBct4AhzMx1ISG:
			if PHUqTNVJ0ErRSwibn5gD: PHUqTNVJ0ErRSwibn5gD = str(PHUqTNVJ0ErRSwibn5gD)
			else: PHUqTNVJ0ErRSwibn5gD = yTMWeCgUROcvtsblfK85L62xPk(u"ࠪࠫࡨ")
			title = aVLSn1xw5cK(u"ุࠫ๐ัโำࠪࡩ")+ZSJVq5XDrRot(u"ࠬࠦࠧࡪ")+type+xuYvdJpOEyQKTLNwb(u"࠭ࠠࠨ࡫")+pp5VsHSlyY0J3R7akBve8bXh+xuYvdJpOEyQKTLNwb(u"ࠧࠡࠩ࡬")+PHUqTNVJ0ErRSwibn5gD+pEo8g7riWVL014KaRtzQ(u"ࠨࠢࠪ࡭")+P1ajYzT8sKCx6tMl+c4QSTnPiWUCjhrLlwGB(u"ࠩࠣࠫ࡮")+aaYDh2EzJ5ky
			if NGmuWwXdLQ6nMltx39FYECohJ not in title: title = title+JcDaEHuiS8TqBbOhWe4ZgwknoC1L3r(u"ࠪࠤࠬ࡯")+NGmuWwXdLQ6nMltx39FYECohJ
			title = title.replace(hjNP5w9srJz2QpVISxBfndbD4CkXvl(u"ࠫࠪ࠭ࡰ"),MM2BQ7xrAfNivgenXPytGYOs0DEHRC(u"ࠬ࠭ࡱ")).strip(jYaM5vilgZdFx6QHbApwVXO8et(u"࠭ࠠࠨࡲ")).replace(J3OCAmZVcn(u"ࠧࠡࠢࠪࡳ"),kRYWcNuAazr4jtmBoxFVS19Z6(u"ࠨࠢࠪࡴ")).replace(sArCMRngQNmXkBoKv(u"ࠩࠣࠤࠬࡵ"),xuYvdJpOEyQKTLNwb(u"ࠪࠤࠬࡶ")).replace(EDPaWgMt1SwNn8o(u"ࠫࠥࠦࠧࡷ"),yTMWeCgUROcvtsblfK85L62xPk(u"ࠬࠦࠧࡸ"))
			if RRucmYBaXegTtNOdGHMQ not in YYmyQXglbEewzL3IA2Sd:
				xCLQK8kh39sjyi5DXSZAVeI.append(title)
				YYmyQXglbEewzL3IA2Sd.append(RRucmYBaXegTtNOdGHMQ)
		if YYmyQXglbEewzL3IA2Sd:
			data = list(zip(xCLQK8kh39sjyi5DXSZAVeI,YYmyQXglbEewzL3IA2Sd))
			if data: Qc96YoCZJOsKUB8yImw034(hosgCj2byWvuVT,m6b7CoBk4EQ(u"࠭ࡓࡆࡔ࡙ࡉࡗ࡙ࠧࡹ"),bFEOBVfxy7nPvCdgta1U,data,xx1wskaWc0SMDNdLVnoF325)
	return xCLQK8kh39sjyi5DXSZAVeI,YYmyQXglbEewzL3IA2Sd
def LHQrCUdfa0t4PYce7xNGJbSDRnvIX(url):
	if aFQoGfmYKyqLU6X8libw9k3ncW5(u"ࠧ࠯࡯࠶ࡹ࠽࠭ࡺ") in url:
		xCLQK8kh39sjyi5DXSZAVeI,YYmyQXglbEewzL3IA2Sd = c8T0X52CGk9UZ71q(url)
		if YYmyQXglbEewzL3IA2Sd: return gnfv8UtZ3daGqpjzk(u"ࠨࠩࡻ"),xCLQK8kh39sjyi5DXSZAVeI,YYmyQXglbEewzL3IA2Sd
		return kmdSKeBIwViM9t3(u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤࡒ࠹ࡕ࠹ࠩࡼ"),[],[]
	return m6b7CoBk4EQ(u"ࠪࡒࡊࡋࡄࡠࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭ࡽ"),[pEo8g7riWVL014KaRtzQ(u"ࠫࠬࡾ")],[url]
def U0UaVBJHgY(url):
	yf608hE5KeRG1DscunvrU,AABKVNO3WiMUSe0 = [],[]
	if aFQoGfmYKyqLU6X8libw9k3ncW5(u"ࠬ࠵ࡶࡪࡦࡨࡳࡸ࠴࡭ࡱ࠶ࡂࡺ࡮ࡪ࠽ࠨࡿ") in url:
		wpFmEA3z8JR = A6F71g3cqN4(Z7uFdWIRv9ybj0,gnfv8UtZ3daGqpjzk(u"࠭ࡇࡆࡖࠪࢀ"),url,jYaM5vilgZdFx6QHbApwVXO8et(u"ࠧࠨࢁ"),MM2BQ7xrAfNivgenXPytGYOs0DEHRC(u"ࠨࠩࢂ"),fR68jBGWCzUsFXdlTKPOScugm(u"ࡈࡤࡰࡸ࡫ᄧ"),aVLSn1xw5cK(u"ࠩࠪࢃ"),yTMWeCgUROcvtsblfK85L62xPk(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡋࡂࡖࡎࡓ࡚࡚ࡅ࠮࠳ࡶࡸࠬࢄ"))
		if MM2BQ7xrAfNivgenXPytGYOs0DEHRC(u"ࠫࡑࡵࡣࡢࡶ࡬ࡳࡳ࠭ࢅ") in wpFmEA3z8JR.headers:
			RRucmYBaXegTtNOdGHMQ = wpFmEA3z8JR.headers[hjNP5w9srJz2QpVISxBfndbD4CkXvl(u"ࠬࡒ࡯ࡤࡣࡷ࡭ࡴࡴࠧࢆ")]
			yf608hE5KeRG1DscunvrU.append(RRucmYBaXegTtNOdGHMQ)
			NGmuWwXdLQ6nMltx39FYECohJ = d78KRnJmBWscGua0XMk(RRucmYBaXegTtNOdGHMQ,ffCSGrTJYPsxgVQWKLtHU3iMwB(u"࠭࡮ࡢ࡯ࡨࠫࢇ"))
			AABKVNO3WiMUSe0.append(NGmuWwXdLQ6nMltx39FYECohJ)
	elif AAgpHN0nMZ(u"ࠧ࡬ࡣࡷ࡯ࡴࡻࡴࡦ࠰ࡦࡳࡲ࠭࢈") in url:
		wpFmEA3z8JR = A6F71g3cqN4(Z7uFdWIRv9ybj0,ZSJVq5XDrRot(u"ࠨࡉࡈࡘࠬࢉ"),url,XogUJZEijT7KWbxeO6(u"ࠩࠪࢊ"),EDPaWgMt1SwNn8o(u"ࠪࠫࢋ"),AAgpHN0nMZ(u"ࠫࠬࢌ"),FhcnOB9t3frzvXb(u"ࠬ࠭ࢍ"),OVmSuf8tpd(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡎࡅ࡙ࡑࡏࡖࡖࡈ࠱࠷ࡴࡤࠨࢎ"))
		QstumvzTIEUMXCcx06aD4y8nSqH = wpFmEA3z8JR.content
		WYRLUPvTZcIHGAnsljMbKhDBEVNOg = ZXFs0mEPR8qI2zj.findall(sArCMRngQNmXkBoKv(u"ࠧࠩࡧࡹࡥࡱࡢࠨࡧࡷࡱࡧࡹ࡯࡯࡯࡞ࠫࡴ࠱ࡧࠬࡤ࠮࡮࠰ࡪ࠲ࡤ࡝ࠫ࠱࠮ࡄࡢࠩ࡝ࠫࠬ࠲ࡁ࠵ࡳࡤࡴ࡬ࡴࡹࡄࠧ࢏"),QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
		if WYRLUPvTZcIHGAnsljMbKhDBEVNOg:
			WYRLUPvTZcIHGAnsljMbKhDBEVNOg = WYRLUPvTZcIHGAnsljMbKhDBEVNOg[aVLSn1xw5cK(u"࠰࿎")]
			GHNJWEoudbyOrUz = yBUaLu7GJmpc(WYRLUPvTZcIHGAnsljMbKhDBEVNOg)
			LzRhxr0bujKNDl8Q4F2AiZvyVB = ZXFs0mEPR8qI2zj.findall(bdhQDyjm3nPwToFHkprvCzBLUGR(u"ࠨࡵࡲࡹࡷࡩࡥࡴ࠼ࠫࡠࡠ࠴ࠪࡀ࡞ࡠ࠭࠱࠭࢐"),GHNJWEoudbyOrUz,ZXFs0mEPR8qI2zj.DOTALL)
			if LzRhxr0bujKNDl8Q4F2AiZvyVB:
				LzRhxr0bujKNDl8Q4F2AiZvyVB = LzRhxr0bujKNDl8Q4F2AiZvyVB[MM2BQ7xrAfNivgenXPytGYOs0DEHRC(u"࠱࿏")]
				LzRhxr0bujKNDl8Q4F2AiZvyVB = NL0JIkbrEWqTYj61vVKGCnBw37MsOF(Ej67fFyoqW8kbV2HdSK(u"ࠩ࡯࡭ࡸࡺࠧ࢑"),LzRhxr0bujKNDl8Q4F2AiZvyVB)
				for dict in LzRhxr0bujKNDl8Q4F2AiZvyVB:
					RRucmYBaXegTtNOdGHMQ = dict[wwyUWMFAsO(u"ࠪࡪ࡮ࡲࡥࠨ࢒")]
					PHUqTNVJ0ErRSwibn5gD = dict[J3OCAmZVcn(u"ࠫࡱࡧࡢࡦ࡮ࠪ࢓")]
					yf608hE5KeRG1DscunvrU.append(RRucmYBaXegTtNOdGHMQ)
					NGmuWwXdLQ6nMltx39FYECohJ = d78KRnJmBWscGua0XMk(RRucmYBaXegTtNOdGHMQ,aVLSn1xw5cK(u"ࠬࡴࡡ࡮ࡧࠪ࢔"))
					AABKVNO3WiMUSe0.append(PHUqTNVJ0ErRSwibn5gD+aFQoGfmYKyqLU6X8libw9k3ncW5(u"࠭ࠠࠨ࢕")+NGmuWwXdLQ6nMltx39FYECohJ)
		elif c4QSTnPiWUCjhrLlwGB(u"ࠧࡍࡱࡦࡥࡹ࡯࡯࡯ࠩ࢖") in wpFmEA3z8JR.headers:
			RRucmYBaXegTtNOdGHMQ = wpFmEA3z8JR.headers[aVLSn1xw5cK(u"ࠨࡎࡲࡧࡦࡺࡩࡰࡰࠪࢗ")]
			yf608hE5KeRG1DscunvrU.append(RRucmYBaXegTtNOdGHMQ)
			NGmuWwXdLQ6nMltx39FYECohJ = d78KRnJmBWscGua0XMk(RRucmYBaXegTtNOdGHMQ,gnfv8UtZ3daGqpjzk(u"ࠩࡱࡥࡲ࡫ࠧ࢘"))
			AABKVNO3WiMUSe0.append(NGmuWwXdLQ6nMltx39FYECohJ)
		if aFQoGfmYKyqLU6X8libw9k3ncW5(u"ࠪࡃࡺࡸ࡬࠾ࡪࡷࡸࡵࡹ࠺࠰࠱ࡳ࡬ࡴࡺ࡯ࡴ࠰ࡤࡴࡵ࠴ࡧࡰࡱ࢙ࠪ") in url:
			RRucmYBaXegTtNOdGHMQ = url.split(hjNP5w9srJz2QpVISxBfndbD4CkXvl(u"ࠫࡄࡻࡲ࡭࠿࢚ࠪ"))[LmcNhzY6fQPd2JyCGslkSr(u"࠳࿐")]
			RRucmYBaXegTtNOdGHMQ = RRucmYBaXegTtNOdGHMQ.split(c4QSTnPiWUCjhrLlwGB(u"࢛ࠬࠬࠧ"))[XogUJZEijT7KWbxeO6(u"࠳࿑")]
			if RRucmYBaXegTtNOdGHMQ:
				yf608hE5KeRG1DscunvrU.append(RRucmYBaXegTtNOdGHMQ)
				AABKVNO3WiMUSe0.append(wwyUWMFAsO(u"࠭ࡰࡩࡱࡷࡳࡸࠦࡧࡰࡱࡪࡰࡪ࠭࢜"))
	else:
		yf608hE5KeRG1DscunvrU.append(url)
		NGmuWwXdLQ6nMltx39FYECohJ = d78KRnJmBWscGua0XMk(url,Ej67fFyoqW8kbV2HdSK(u"ࠧ࡯ࡣࡰࡩࠬ࢝"))
		AABKVNO3WiMUSe0.append(NGmuWwXdLQ6nMltx39FYECohJ)
	if not yf608hE5KeRG1DscunvrU: return LmcNhzY6fQPd2JyCGslkSr(u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦࠣࡏࡆ࡚ࡋࡐࡗࡗࡉࠬ࢞"),[],[]
	elif len(yf608hE5KeRG1DscunvrU)==DLSVmlyBbCK(u"࠵࿒"): RRucmYBaXegTtNOdGHMQ = yf608hE5KeRG1DscunvrU[MM2BQ7xrAfNivgenXPytGYOs0DEHRC(u"࠵࿓")]
	else:
		jQ6w8xOrgYhSHIRpUqzL = F2yZPukcUh09sqCI8nYw7e(sArCMRngQNmXkBoKv(u"ࠩฦาฯืࠠศๆ่่ๆࠦวๅ็้หุฮࠧ࢟"),AABKVNO3WiMUSe0)
		if jQ6w8xOrgYhSHIRpUqzL==-FhcnOB9t3frzvXb(u"࠷࿔"): return sArCMRngQNmXkBoKv(u"ࠪࡉ࡝ࡏࡔࡠࡃࡏࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨࢠ"),[],[]
		RRucmYBaXegTtNOdGHMQ = yf608hE5KeRG1DscunvrU[jQ6w8xOrgYhSHIRpUqzL]
	return JMLhEyaBWmskovGHTrVCxQ08(u"ࠫࡓࡋࡅࡅࡡࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧࢡ"),[AAgpHN0nMZ(u"ࠬ࠭ࢢ")],[RRucmYBaXegTtNOdGHMQ]
def ILFlPrWyapdhbCGY6xO7Qeq(url):
	headers = {pEo8g7riWVL014KaRtzQ(u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪࢣ"):kRYWcNuAazr4jtmBoxFVS19Z6(u"ࠧࡌࡱࡧ࡭࠴࠭ࢤ")+str(V8US2yZAg0QXJebWIHKD5xFa)}
	for OeT2Jo0sp6h1mGdqfFw in range(FhcnOB9t3frzvXb(u"࠵࠱࿕")):
		luMHeSgCBaPrb9KvUjNFqcR.sleep(Ej67fFyoqW8kbV2HdSK(u"࠱࠰࠴࠴࠵࿖"))
		wpFmEA3z8JR = ggAhyPE3zSu(gnfv8UtZ3daGqpjzk(u"ࠨࡉࡈࡘࠬࢥ"),url,pEo8g7riWVL014KaRtzQ(u"ࠩࠪࢦ"),headers,eeIL1TfgFQJaKqVD8hGNPEZ(u"ࡉࡥࡱࡹࡥᄨ"),PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"ࠪࠫࢧ"),FhcnOB9t3frzvXb(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡈࡑࡒࡋࡑࡋࡕࡔࡇࡕࡇࡔࡔࡔࡆࡐࡗ࠱࠶ࡹࡴࠨࢨ"))
		if EDPaWgMt1SwNn8o(u"ࠬࡒ࡯ࡤࡣࡷ࡭ࡴࡴࠧࢩ") in list(wpFmEA3z8JR.headers.keys()):
			RRucmYBaXegTtNOdGHMQ = wpFmEA3z8JR.headers[PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"࠭ࡌࡰࡥࡤࡸ࡮ࡵ࡮ࠨࢪ")]
			RRucmYBaXegTtNOdGHMQ = RRucmYBaXegTtNOdGHMQ+ffCSGrTJYPsxgVQWKLtHU3iMwB(u"ࠧࡽࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࡂ࠭ࢫ")+headers[PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬࢬ")]
			return AAgpHN0nMZ(u"ࠩࠪࢭ"),[DLSVmlyBbCK(u"ࠪࠫࢮ")],[RRucmYBaXegTtNOdGHMQ]
		if wpFmEA3z8JR.code!=FhcnOB9t3frzvXb(u"࠶࠵࠽࿗"): break
	return JcDaEHuiS8TqBbOhWe4ZgwknoC1L3r(u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡇࡐࡑࡊࡐࡊ࡛ࡓࡆࡔࡆࡓࡓ࡚ࡅࡏࡖࠪࢯ"),[],[]
def hEj0s7N1WlBPGK(url):
	wpFmEA3z8JR = A6F71g3cqN4(Z7uFdWIRv9ybj0,m6b7CoBk4EQ(u"ࠬࡍࡅࡕࠩࢰ"),url,bdhQDyjm3nPwToFHkprvCzBLUGR(u"࠭ࠧࢱ"),FhcnOB9t3frzvXb(u"ࠧࠨࢲ"),pEo8g7riWVL014KaRtzQ(u"ࠨࠩࢳ"),yTMWeCgUROcvtsblfK85L62xPk(u"ࠩࠪࢴ"),LmcNhzY6fQPd2JyCGslkSr(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡐࡉࡑࡗࡓࡘࡍࡏࡐࡉࡏࡉ࠲࠷ࡳࡵࠩࢵ"))
	QstumvzTIEUMXCcx06aD4y8nSqH = wpFmEA3z8JR.content
	RRucmYBaXegTtNOdGHMQ = ZXFs0mEPR8qI2zj.findall(sArCMRngQNmXkBoKv(u"ࠫࠧ࠮ࡨࡵࡶࡳࡷ࠿࠵࠯ࡷ࡫ࡧࡩࡴ࠳ࡤࡰࡹࡱࡰࡴࡧࡤࡴ࠰࠭ࡃ࠮ࠨࠬ࠯ࠬࡂ࠰࠳࠰࠿࠭ࠪ࠱࠮ࡄ࠯ࠬࠨࢶ"),QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	if RRucmYBaXegTtNOdGHMQ:
		RRucmYBaXegTtNOdGHMQ,PHUqTNVJ0ErRSwibn5gD = RRucmYBaXegTtNOdGHMQ[bdhQDyjm3nPwToFHkprvCzBLUGR(u"࠳࿘")]
		return J3OCAmZVcn(u"ࠬ࠭ࢷ"),[PHUqTNVJ0ErRSwibn5gD],[RRucmYBaXegTtNOdGHMQ]
	return wwyUWMFAsO(u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡒࡋࡓ࡙ࡕࡓࡈࡑࡒࡋࡑࡋࠧࢸ"),[],[]
def L5Wip7lPhd(url):
	wpFmEA3z8JR = A6F71g3cqN4(dALVaOWB4jKN3Tbt0Cm1ns9k5u,sArCMRngQNmXkBoKv(u"ࠧࡈࡇࡗࠫࢹ"),url,sArCMRngQNmXkBoKv(u"ࠨࠩࢺ"),AAgpHN0nMZ(u"ࠩࠪࢻ"),PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"ࠪࠫࢼ"),xuYvdJpOEyQKTLNwb(u"ࠫࠬࢽ"),aVLSn1xw5cK(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡈࡄࡗࡊࡒࡈࡅ࠳࠰࠵ࡸࡺࠧࢾ"))
	QstumvzTIEUMXCcx06aD4y8nSqH = wpFmEA3z8JR.content
	QstumvzTIEUMXCcx06aD4y8nSqH = Aq4xzQOb5ISuiC9JWnPtavj0gXlh(QstumvzTIEUMXCcx06aD4y8nSqH)
	RRucmYBaXegTtNOdGHMQ = ZXFs0mEPR8qI2zj.findall(hjNP5w9srJz2QpVISxBfndbD4CkXvl(u"࠭ࠢࡧ࡫࡯ࡩࠧࡀࠢࠩ࠰࠭ࡃ࠮ࠨࠧࢿ"),QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	if RRucmYBaXegTtNOdGHMQ: return gSmqZU0plur2xKPJwQA(u"ࠧࠨࣀ"),[MM2BQ7xrAfNivgenXPytGYOs0DEHRC(u"ࠨࠩࣁ")],[RRucmYBaXegTtNOdGHMQ[c4QSTnPiWUCjhrLlwGB(u"࠴࿙")]]
	return c4QSTnPiWUCjhrLlwGB(u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤࡋࡇࡓࡆࡎࡋࡈ࠶࠭ࣂ"),[],[]
def E2RU1x6hfF(url):
	if EDPaWgMt1SwNn8o(u"ࠪ࠳ࡩࡵࡷ࡯࠰ࡳ࡬ࡵ࠭ࣃ") in url:
		wpFmEA3z8JR = A6F71g3cqN4(dALVaOWB4jKN3Tbt0Cm1ns9k5u,wwyUWMFAsO(u"ࠫࡌࡋࡔࠨࣄ"),url,aFQoGfmYKyqLU6X8libw9k3ncW5(u"ࠬ࠭ࣅ"),kRYWcNuAazr4jtmBoxFVS19Z6(u"࠭ࠧࣆ"),ffCSGrTJYPsxgVQWKLtHU3iMwB(u"ࠧࠨࣇ"),AAgpHN0nMZ(u"ࠨࠩࣈ"),J3OCAmZVcn(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲࡙ࡈࡐࡈࡋࡅ࠲࠷ࡳࡵࠩࣉ"))
		QstumvzTIEUMXCcx06aD4y8nSqH = wpFmEA3z8JR.content
		RRucmYBaXegTtNOdGHMQ = ZXFs0mEPR8qI2zj.findall(kRYWcNuAazr4jtmBoxFVS19Z6(u"ࠪࡺ࡮ࡪࡥࡰ࠯ࡺࡶࡦࡶࡰࡦࡴ࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ࣊"),QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
		url = RRucmYBaXegTtNOdGHMQ[XogUJZEijT7KWbxeO6(u"࠵࿚")]
	return fR68jBGWCzUsFXdlTKPOScugm(u"ࠫࡓࡋࡅࡅࡡࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧ࣋"),[JMLhEyaBWmskovGHTrVCxQ08(u"ࠬ࠭࣌")],[url]
def jrfTYWXZnv(url):
	if yTMWeCgUROcvtsblfK85L62xPk(u"࠭ࡳࡦࡴࡹࡩࡷ࠴ࡰࡩࡲࠪ࣍") in url:
		wpFmEA3z8JR = A6F71g3cqN4(dALVaOWB4jKN3Tbt0Cm1ns9k5u,yTMWeCgUROcvtsblfK85L62xPk(u"ࠧࡈࡇࡗࠫ࣎"),url,AAgpHN0nMZ(u"ࠨ࣏ࠩ"),fR68jBGWCzUsFXdlTKPOScugm(u"࣐ࠩࠪ"),MM2BQ7xrAfNivgenXPytGYOs0DEHRC(u"࣑ࠪࠫ"),eeIL1TfgFQJaKqVD8hGNPEZ(u"࣒ࠫࠬ"),sArCMRngQNmXkBoKv(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡅࡌࡑࡆ࠺ࡕ࠮࠳ࡶࡸ࣓ࠬ"))
		QstumvzTIEUMXCcx06aD4y8nSqH = wpFmEA3z8JR.content
		RRucmYBaXegTtNOdGHMQ = ZXFs0mEPR8qI2zj.findall(ZSJVq5XDrRot(u"࠭ࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫࣔ"),QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
		RRucmYBaXegTtNOdGHMQ = RRucmYBaXegTtNOdGHMQ[pEo8g7riWVL014KaRtzQ(u"࠶࿛")]
		if m6b7CoBk4EQ(u"ࠧࡩࡶࡷࡴࠬࣕ") in RRucmYBaXegTtNOdGHMQ: return wwyUWMFAsO(u"ࠨࡐࡈࡉࡉࡥࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫࣖ"),[gnfv8UtZ3daGqpjzk(u"ࠩࠪࣗ")],[RRucmYBaXegTtNOdGHMQ]
		return pEo8g7riWVL014KaRtzQ(u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨࠥࡉࡉࡎࡃ࠷࡙ࠬࣘ"),[],[]
	return kRYWcNuAazr4jtmBoxFVS19Z6(u"ࠫࡓࡋࡅࡅࡡࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧࣙ"),[aVLSn1xw5cK(u"ࠬ࠭ࣚ")],[url]
def rr8BvkwspK(url):
	lQHXdV9Nzf6BLqS8D,BTMputsaqV = hGMVvHBuPC014(url)
	obS4TpHeV3digGC = {wwyUWMFAsO(u"࠭ࡘ࠮ࡔࡨࡵࡺ࡫ࡳࡵࡧࡧ࠱࡜࡯ࡴࡩࠩࣛ"):kmdSKeBIwViM9t3(u"࡙ࠧࡏࡏࡌࡹࡺࡰࡓࡧࡴࡹࡪࡹࡴࠨࣜ"),MM2BQ7xrAfNivgenXPytGYOs0DEHRC(u"ࠨࡅࡲࡲࡹ࡫࡮ࡵ࠯ࡗࡽࡵ࡫ࠧࣝ"):PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"ࠩࡤࡴࡵࡲࡩࡤࡣࡷ࡭ࡴࡴ࠯ࡹ࠯ࡺࡻࡼ࠳ࡦࡰࡴࡰ࠱ࡺࡸ࡬ࡦࡰࡦࡳࡩ࡫ࡤ࠼ࠢࡦ࡬ࡦࡸࡳࡦࡶࡀ࡙࡙ࡌ࠭࠹ࠩࣞ")}
	wpFmEA3z8JR = A6F71g3cqN4(Z7uFdWIRv9ybj0,kRYWcNuAazr4jtmBoxFVS19Z6(u"ࠪࡔࡔ࡙ࡔࠨࣟ"),lQHXdV9Nzf6BLqS8D,BTMputsaqV,obS4TpHeV3digGC,EDPaWgMt1SwNn8o(u"ࠫࠬ࣠"),gnfv8UtZ3daGqpjzk(u"ࠬ࠭࣡"),xuYvdJpOEyQKTLNwb(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡈࡋ࡞ࡔࡏࡘ࠯࠴ࡷࡹ࠭࣢"))
	QstumvzTIEUMXCcx06aD4y8nSqH = wpFmEA3z8JR.content
	RRucmYBaXegTtNOdGHMQ = ZXFs0mEPR8qI2zj.findall(gnfv8UtZ3daGqpjzk(u"ࠧࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࣣࠬࠦࠬ"),QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	if not RRucmYBaXegTtNOdGHMQ: return J3OCAmZVcn(u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦࠣࡉࡌ࡟ࡎࡐ࡙ࠪࣤ"),[],[]
	RRucmYBaXegTtNOdGHMQ = RRucmYBaXegTtNOdGHMQ[JMLhEyaBWmskovGHTrVCxQ08(u"࠰࿜")]
	return kRYWcNuAazr4jtmBoxFVS19Z6(u"ࠩࡑࡉࡊࡊ࡟ࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬࣥ"),[DLSVmlyBbCK(u"ࣦࠪࠫ")],[RRucmYBaXegTtNOdGHMQ]
def yLKZ3U5T8o(url):
	headers = {FhcnOB9t3frzvXb(u"ࠫ࡝࠳ࡒࡦࡳࡸࡩࡸࡺࡥࡥ࠯࡚࡭ࡹ࡮ࠧࣧ"):J3OCAmZVcn(u"ࠬ࡞ࡍࡍࡊࡷࡸࡵࡘࡥࡲࡷࡨࡷࡹ࠭ࣨ")}
	wpFmEA3z8JR = A6F71g3cqN4(Z7uFdWIRv9ybj0,kmdSKeBIwViM9t3(u"࠭ࡇࡆࡖࣩࠪ"),url,kRYWcNuAazr4jtmBoxFVS19Z6(u"ࠧࠨ࣪"),headers,kRYWcNuAazr4jtmBoxFVS19Z6(u"ࠨࠩ࣫"),AAgpHN0nMZ(u"ࠩࠪ࣬"),LmcNhzY6fQPd2JyCGslkSr(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡓࡉࡑࡒࡊࡕࡘࡏ࠮࠳ࡶࡸ࣭ࠬ"))
	QstumvzTIEUMXCcx06aD4y8nSqH = wpFmEA3z8JR.content
	RRucmYBaXegTtNOdGHMQ = ZXFs0mEPR8qI2zj.findall(kRYWcNuAazr4jtmBoxFVS19Z6(u"ࠫࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅ࣮ࠩࠣࠩ"),QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL|ZXFs0mEPR8qI2zj.IGNORECASE)
	if not RRucmYBaXegTtNOdGHMQ: return c4QSTnPiWUCjhrLlwGB(u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡔࡊࡒࡓࡋࡖࡒࡐ࣯ࠩ"),[],[]
	RRucmYBaXegTtNOdGHMQ = RRucmYBaXegTtNOdGHMQ[bdhQDyjm3nPwToFHkprvCzBLUGR(u"࠱࿝")]
	return JMLhEyaBWmskovGHTrVCxQ08(u"࠭ࡎࡆࡇࡇࡣࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࣰࠩ"),[DLSVmlyBbCK(u"ࠧࠨࣱ")],[RRucmYBaXegTtNOdGHMQ]
def zzRXnV0x6N(url):
	lQHXdV9Nzf6BLqS8D,BTMputsaqV = hGMVvHBuPC014(url)
	obS4TpHeV3digGC = {J3OCAmZVcn(u"ࠨࡅࡲࡲࡹ࡫࡮ࡵ࠯ࡗࡽࡵ࡫ࣲࠧ"):sArCMRngQNmXkBoKv(u"ࠩࡤࡴࡵࡲࡩࡤࡣࡷ࡭ࡴࡴ࠯ࡹ࠯ࡺࡻࡼ࠳ࡦࡰࡴࡰ࠱ࡺࡸ࡬ࡦࡰࡦࡳࡩ࡫ࡤ࠼ࠢࡦ࡬ࡦࡸࡳࡦࡶࡀ࡙࡙ࡌ࠭࠹ࠩࣳ")}
	wpFmEA3z8JR = A6F71g3cqN4(Z7uFdWIRv9ybj0,xuYvdJpOEyQKTLNwb(u"ࠪࡔࡔ࡙ࡔࠨࣴ"),lQHXdV9Nzf6BLqS8D,BTMputsaqV,obS4TpHeV3digGC,ffCSGrTJYPsxgVQWKLtHU3iMwB(u"ࠫࠬࣵ"),gnfv8UtZ3daGqpjzk(u"ࣶࠬ࠭"),bdhQDyjm3nPwToFHkprvCzBLUGR(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡋࡅࡑࡇࡃࡊࡏࡄ࠱࠶ࡹࡴࠨࣷ"))
	QstumvzTIEUMXCcx06aD4y8nSqH = wpFmEA3z8JR.content
	RRucmYBaXegTtNOdGHMQ = ZXFs0mEPR8qI2zj.findall(jYaM5vilgZdFx6QHbApwVXO8et(u"ࠧࠨࠩ࠿࡭࡫ࡸࡡ࡮ࡧࠣࡷࡷࡩ࠽࡜ࠤࠪࡡ࠭࠴ࠪࡀࠫ࡞ࠦࠬࡣࠧࠨࠩࣸ"),QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL|ZXFs0mEPR8qI2zj.IGNORECASE)
	if not RRucmYBaXegTtNOdGHMQ: return kmdSKeBIwViM9t3(u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦࠣࡌࡆࡒࡁࡄࡋࡐࡅࣹࠬ"),[],[]
	RRucmYBaXegTtNOdGHMQ = RRucmYBaXegTtNOdGHMQ[XogUJZEijT7KWbxeO6(u"࠲࿞")]
	if gnfv8UtZ3daGqpjzk(u"ࠩ࡫ࡸࡹࡶࣺࠧ") not in RRucmYBaXegTtNOdGHMQ: RRucmYBaXegTtNOdGHMQ = EDPaWgMt1SwNn8o(u"ࠪ࡬ࡹࡺࡰ࠻ࠩࣻ")+RRucmYBaXegTtNOdGHMQ
	return gSmqZU0plur2xKPJwQA(u"ࠫࡓࡋࡅࡅࡡࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧࣼ"),[xuYvdJpOEyQKTLNwb(u"ࠬ࠭ࣽ")],[RRucmYBaXegTtNOdGHMQ]
def BMiW1qeG8b(url):
	oKqQr8Ij0btxZ9SDm6h3Nd,AABKVNO3WiMUSe0,yf608hE5KeRG1DscunvrU = url,[],[]
	if gnfv8UtZ3daGqpjzk(u"࠭࠯ࡢ࡬ࡤࡼ࠴࠭ࣾ") in url:
		lQHXdV9Nzf6BLqS8D,BTMputsaqV = hGMVvHBuPC014(url)
		obS4TpHeV3digGC = {aVLSn1xw5cK(u"ࠧࡄࡱࡱࡸࡪࡴࡴ࠮ࡖࡼࡴࡪ࠭ࣿ"):jYaM5vilgZdFx6QHbApwVXO8et(u"ࠨࡣࡳࡴࡱ࡯ࡣࡢࡶ࡬ࡳࡳ࠵ࡸ࠮ࡹࡺࡻ࠲࡬࡯ࡳ࡯࠰ࡹࡷࡲࡥ࡯ࡥࡲࡨࡪࡪ࠻ࠡࡥ࡫ࡥࡷࡹࡥࡵ࠿ࡘࡘࡋ࠳࠸ࠨऀ")}
		wpFmEA3z8JR = A6F71g3cqN4(Z7uFdWIRv9ybj0,yTMWeCgUROcvtsblfK85L62xPk(u"ࠩࡓࡓࡘ࡚ࠧँ"),lQHXdV9Nzf6BLqS8D,BTMputsaqV,obS4TpHeV3digGC,XogUJZEijT7KWbxeO6(u"ࠪࠫं"),jYaM5vilgZdFx6QHbApwVXO8et(u"ࠫࠬः"),gnfv8UtZ3daGqpjzk(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡅࡌࡑࡆࡇࡂࡅࡑ࠰࠵ࡸࡺࠧऄ"))
		QstumvzTIEUMXCcx06aD4y8nSqH = wpFmEA3z8JR.content
		RRr48IPQSLEdunNcgGUhJozkY = ZXFs0mEPR8qI2zj.findall(gnfv8UtZ3daGqpjzk(u"࠭ࠧࠨ࠾࡬ࡪࡷࡧ࡭ࡦ࠰࠭ࡃࡸࡸࡣ࠾࡝ࠥࠫࡢ࠮࠮ࠫࡁࠬ࡟ࠧ࠭࡝ࠨࠩࠪअ"),QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL|ZXFs0mEPR8qI2zj.IGNORECASE)
		if RRr48IPQSLEdunNcgGUhJozkY: oKqQr8Ij0btxZ9SDm6h3Nd = RRr48IPQSLEdunNcgGUhJozkY[XogUJZEijT7KWbxeO6(u"࠳࿟")]
	return JcDaEHuiS8TqBbOhWe4ZgwknoC1L3r(u"ࠧࡏࡇࡈࡈࡤࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪआ"),[fR68jBGWCzUsFXdlTKPOScugm(u"ࠨࠩइ")],[oKqQr8Ij0btxZ9SDm6h3Nd]
def tjAQk8gwul(url):
	wpFmEA3z8JR = A6F71g3cqN4(Z7uFdWIRv9ybj0,DLSVmlyBbCK(u"ࠩࡊࡉ࡙࠭ई"),url,sArCMRngQNmXkBoKv(u"ࠪࠫउ"),JcDaEHuiS8TqBbOhWe4ZgwknoC1L3r(u"ࠫࠬऊ"),AAgpHN0nMZ(u"ࠬ࠭ऋ"),wwyUWMFAsO(u"࠭ࠧऌ"),JcDaEHuiS8TqBbOhWe4ZgwknoC1L3r(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡘ࡛ࡌࡕࡏ࠯࠴ࡷࡹ࠭ऍ"))
	QstumvzTIEUMXCcx06aD4y8nSqH = wpFmEA3z8JR.content
	mUb59IPOXlzvnGg1uhrRJyC8eBsiSc = ZXFs0mEPR8qI2zj.findall(kmdSKeBIwViM9t3(u"ࠣࡸࡤࡶࠥ࡬ࡳࡦࡴࡹࠤࡂ࠴ࠪࡀࠩࠫ࠲࠯ࡅࠩࠨࠤऎ"),QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL|ZXFs0mEPR8qI2zj.IGNORECASE)
	if mUb59IPOXlzvnGg1uhrRJyC8eBsiSc:
		mUb59IPOXlzvnGg1uhrRJyC8eBsiSc = mUb59IPOXlzvnGg1uhrRJyC8eBsiSc[JMLhEyaBWmskovGHTrVCxQ08(u"࠴࿠")][bdhQDyjm3nPwToFHkprvCzBLUGR(u"࠷࿡"):]
		mUb59IPOXlzvnGg1uhrRJyC8eBsiSc = EGTVgQoSu6ZsD.b64decode(mUb59IPOXlzvnGg1uhrRJyC8eBsiSc)
		if VYMZsxRpcQHPgkaiDKjyoh: mUb59IPOXlzvnGg1uhrRJyC8eBsiSc = mUb59IPOXlzvnGg1uhrRJyC8eBsiSc.decode(DLSVmlyBbCK(u"ࠩࡸࡸ࡫࠾ࠧए"))
		RRucmYBaXegTtNOdGHMQ = ZXFs0mEPR8qI2zj.findall(PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"ࠪࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨऐ"),mUb59IPOXlzvnGg1uhrRJyC8eBsiSc,ZXFs0mEPR8qI2zj.DOTALL)
	else: RRucmYBaXegTtNOdGHMQ = Ej67fFyoqW8kbV2HdSK(u"ࠫࠬऑ")
	if not RRucmYBaXegTtNOdGHMQ: return yTMWeCgUROcvtsblfK85L62xPk(u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡕࡘࡉ࡙ࡓ࠭ऒ"),[],[]
	RRucmYBaXegTtNOdGHMQ = RRucmYBaXegTtNOdGHMQ[ffCSGrTJYPsxgVQWKLtHU3iMwB(u"࠶࿢")]
	if hjNP5w9srJz2QpVISxBfndbD4CkXvl(u"࠭ࡨࡵࡶࡳࠫओ") not in RRucmYBaXegTtNOdGHMQ: RRucmYBaXegTtNOdGHMQ = pEo8g7riWVL014KaRtzQ(u"ࠧࡩࡶࡷࡴ࠿࠭औ")+RRucmYBaXegTtNOdGHMQ
	return hjNP5w9srJz2QpVISxBfndbD4CkXvl(u"ࠨࡐࡈࡉࡉࡥࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫक"),[eeIL1TfgFQJaKqVD8hGNPEZ(u"ࠩࠪख")],[RRucmYBaXegTtNOdGHMQ]
def cnLUO2AkRQwXT1jhF5r(url):
	wpFmEA3z8JR = A6F71g3cqN4(dALVaOWB4jKN3Tbt0Cm1ns9k5u,gnfv8UtZ3daGqpjzk(u"ࠪࡋࡊ࡚ࠧग"),url,AAgpHN0nMZ(u"ࠫࠬघ"),OVmSuf8tpd(u"ࠬ࠭ङ"),ffCSGrTJYPsxgVQWKLtHU3iMwB(u"࠭ࠧच"),pEo8g7riWVL014KaRtzQ(u"ࠧࠨछ"),pEo8g7riWVL014KaRtzQ(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡒ࡟ࡅࡈ࡛࡙ࡍࡕ࠳࠱ࡴࡶࠪज"))
	QstumvzTIEUMXCcx06aD4y8nSqH = wpFmEA3z8JR.content
	RRucmYBaXegTtNOdGHMQ = ZXFs0mEPR8qI2zj.findall(gSmqZU0plur2xKPJwQA(u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡦࡳࡱ࠳ࡳ࡮࠯࠴࠶ࠧ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧझ"),QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	if not RRucmYBaXegTtNOdGHMQ: return EDPaWgMt1SwNn8o(u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨࠥࡓ࡙ࡆࡉ࡜࡚ࡎࡖࠧञ"),[],[]
	RRucmYBaXegTtNOdGHMQ = RRucmYBaXegTtNOdGHMQ[JcDaEHuiS8TqBbOhWe4ZgwknoC1L3r(u"࠰࿣")]
	return OVmSuf8tpd(u"ࠫࡓࡋࡅࡅࡡࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧट"),[ffCSGrTJYPsxgVQWKLtHU3iMwB(u"ࠬ࠭ठ")],[RRucmYBaXegTtNOdGHMQ]
def hyzijIU4w3(url):
	id = url.split(PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"࠭࠯ࠨड"))[-bdhQDyjm3nPwToFHkprvCzBLUGR(u"࠲࿤")]
	if yTMWeCgUROcvtsblfK85L62xPk(u"ࠧ࠰ࡧࡰࡦࡪࡪࠧढ") in url: url = url.replace(m6b7CoBk4EQ(u"ࠨ࠱ࡨࡱࡧ࡫ࡤࠨण"),sArCMRngQNmXkBoKv(u"ࠩࠪत"))
	url = url.replace(OVmSuf8tpd(u"ࠪ࠲ࡨࡵ࡭࠰ࠩथ"),OVmSuf8tpd(u"ࠫ࠳ࡩ࡯࡮࠱ࡳࡰࡦࡿࡥࡳ࠱ࡰࡩࡹࡧࡤࡢࡶࡤ࠳ࠬद"))
	wpFmEA3z8JR = A6F71g3cqN4(dALVaOWB4jKN3Tbt0Cm1ns9k5u,aVLSn1xw5cK(u"ࠬࡍࡅࡕࠩध"),url,J3OCAmZVcn(u"࠭ࠧन"),LmcNhzY6fQPd2JyCGslkSr(u"ࠧࠨऩ"),PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"ࠨࠩप"),DLSVmlyBbCK(u"ࠩࠪफ"),aVLSn1xw5cK(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡄࡂࡋࡏ࡝ࡒࡕࡔࡊࡑࡑ࠱࠶ࡹࡴࠨब"))
	QstumvzTIEUMXCcx06aD4y8nSqH = wpFmEA3z8JR.content
	svA3Xnq5GbkTcZPHd = JMLhEyaBWmskovGHTrVCxQ08(u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡄࡂࡋࡏ࡝ࡒࡕࡔࡊࡑࡑࠫभ")
	pHjsAUzBKJauq3LiFG05ZVh = ZXFs0mEPR8qI2zj.findall(jYaM5vilgZdFx6QHbApwVXO8et(u"ࠬࠨࡥࡳࡴࡲࡶࠧ࠴ࠪࡀࠤࡰࡩࡸࡹࡡࡨࡧࡨࠦ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠭म"),QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	if pHjsAUzBKJauq3LiFG05ZVh: svA3Xnq5GbkTcZPHd = pHjsAUzBKJauq3LiFG05ZVh[FhcnOB9t3frzvXb(u"࠲࿥")]
	url = ZXFs0mEPR8qI2zj.findall(JcDaEHuiS8TqBbOhWe4ZgwknoC1L3r(u"࠭ࡸ࠮࡯ࡳࡩ࡬࡛ࡒࡍࠤ࠯ࠦࡺࡸ࡬ࠣ࠼ࠥࠬ࠳࠰࠿ࠪࠤࠪय"),QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	if not url and svA3Xnq5GbkTcZPHd:
		return svA3Xnq5GbkTcZPHd,[],[]
	RRucmYBaXegTtNOdGHMQ = url[gSmqZU0plur2xKPJwQA(u"࠳࿦")].replace(kmdSKeBIwViM9t3(u"ࠧ࡝࡞ࠪर"),ZSJVq5XDrRot(u"ࠨࠩऱ"))
	FNylha5WkeAxi3r0G4QPqwRZMY,bFEOBVfxy7nPvCdgta1U = c8T0X52CGk9UZ71q(RRucmYBaXegTtNOdGHMQ)
	uk4V7BxXanKgeGcjAqDQLJ26SRr59d = ZXFs0mEPR8qI2zj.findall(PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"ࠩࠥࡳࡼࡴࡥࡳࠤ࠽ࡿࠧ࡯ࡤࠣ࠼ࠥࠬ࠳࠰࠿ࠪࠤ࠯ࠦࡸࡩࡲࡦࡧࡱࡲࡦࡳࡥࠣ࠼ࠥࠬ࠳࠰࠿ࠪࠤ࠯ࠦࡺࡸ࡬ࠣ࠼ࠥࠬ࠳࠰࠿ࠪࠤࠪल"),QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	if uk4V7BxXanKgeGcjAqDQLJ26SRr59d: gglC49z3wHUYhIQDFcJmR,sC3BgwKUR2Nf0ilnq1zH5mQ9v,UUIuBG5gW9Jc48VNfsPXoAHOjlkad = uk4V7BxXanKgeGcjAqDQLJ26SRr59d[kmdSKeBIwViM9t3(u"࠴࿧")]
	else: gglC49z3wHUYhIQDFcJmR,sC3BgwKUR2Nf0ilnq1zH5mQ9v,UUIuBG5gW9Jc48VNfsPXoAHOjlkad = gnfv8UtZ3daGqpjzk(u"ࠪࠫळ"),FhcnOB9t3frzvXb(u"ࠫࠬऴ"),fR68jBGWCzUsFXdlTKPOScugm(u"ࠬ࠭व")
	UUIuBG5gW9Jc48VNfsPXoAHOjlkad = UUIuBG5gW9Jc48VNfsPXoAHOjlkad.replace(jYaM5vilgZdFx6QHbApwVXO8et(u"࠭࡜࠰ࠩश"),Ej67fFyoqW8kbV2HdSK(u"ࠧ࠰ࠩष"))
	sC3BgwKUR2Nf0ilnq1zH5mQ9v = WhJe7bGx5XackTwOIZVLC8ut(sC3BgwKUR2Nf0ilnq1zH5mQ9v)
	xCLQK8kh39sjyi5DXSZAVeI = [J3OCAmZVcn(u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࡓ࡜ࡔࡅࡓ࠼ࠣࠤࠬस")+sC3BgwKUR2Nf0ilnq1zH5mQ9v+fR68jBGWCzUsFXdlTKPOScugm(u"ࠩ࡞࠳ࡈࡕࡌࡐࡔࡠࠫह")]+FNylha5WkeAxi3r0G4QPqwRZMY
	YYmyQXglbEewzL3IA2Sd = [UUIuBG5gW9Jc48VNfsPXoAHOjlkad]+bFEOBVfxy7nPvCdgta1U
	jQ6w8xOrgYhSHIRpUqzL = F2yZPukcUh09sqCI8nYw7e(m6b7CoBk4EQ(u"ࠪหำะัࠡษ็้้็ࠠศๆ่๊ฬูศ࠻ࠢࠫࠫऺ")+str(len(YYmyQXglbEewzL3IA2Sd)-ZSJVq5XDrRot(u"࠶࿨"))+sArCMRngQNmXkBoKv(u"๋ࠫࠥไโࠫࠪऻ"),xCLQK8kh39sjyi5DXSZAVeI)
	if jQ6w8xOrgYhSHIRpUqzL==-hjNP5w9srJz2QpVISxBfndbD4CkXvl(u"࠷࿩"): return bdhQDyjm3nPwToFHkprvCzBLUGR(u"ࠬࡋࡘࡊࡖࡢࡅࡑࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ़ࠪ"),[],[]
	elif jQ6w8xOrgYhSHIRpUqzL==FhcnOB9t3frzvXb(u"࠰࿪"):
		PY7dAjmvOzeTDEU2JI1wi8lyNLQ = ddABnr3K9Xv8e71CzcN0Pxt.argv[aFQoGfmYKyqLU6X8libw9k3ncW5(u"࠱࿫")]+Ej67fFyoqW8kbV2HdSK(u"࠭࠿ࡵࡻࡳࡩࡂ࡬࡯࡭ࡦࡨࡶࠫࡳ࡯ࡥࡧࡀ࠸࠵࠸ࠦࡶࡴ࡯ࡁࠬऽ")+UUIuBG5gW9Jc48VNfsPXoAHOjlkad+EDPaWgMt1SwNn8o(u"ࠧࠧࡶࡨࡼࡹࡺ࠽ࠨा")+sC3BgwKUR2Nf0ilnq1zH5mQ9v
		cPwDBuG4HVTCdQ9JmMeoWjNY2hX.executebuiltin(DLSVmlyBbCK(u"ࠣࡅࡲࡲࡹࡧࡩ࡯ࡧࡵ࠲࡚ࡶࡤࡢࡶࡨࠬࠧि")+PY7dAjmvOzeTDEU2JI1wi8lyNLQ+XogUJZEijT7KWbxeO6(u"ࠤࠬࠦी"))
		return c4QSTnPiWUCjhrLlwGB(u"ࠪࡉ࡝ࡏࡔࡠࡃࡏࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨु"),[],[]
	RRucmYBaXegTtNOdGHMQ =  YYmyQXglbEewzL3IA2Sd[jQ6w8xOrgYhSHIRpUqzL]
	return LmcNhzY6fQPd2JyCGslkSr(u"ࠫࠬू"),[kmdSKeBIwViM9t3(u"ࠬ࠭ृ")],[RRucmYBaXegTtNOdGHMQ]
def dpINwXmrSA(RRucmYBaXegTtNOdGHMQ):
	wpFmEA3z8JR = A6F71g3cqN4(dALVaOWB4jKN3Tbt0Cm1ns9k5u,hjNP5w9srJz2QpVISxBfndbD4CkXvl(u"࠭ࡇࡆࡖࠪॄ"),RRucmYBaXegTtNOdGHMQ,m6b7CoBk4EQ(u"ࠧࠨॅ"),AAgpHN0nMZ(u"ࠨࠩॆ"),OVmSuf8tpd(u"ࠩࠪे"),jYaM5vilgZdFx6QHbApwVXO8et(u"ࠪࠫै"),eeIL1TfgFQJaKqVD8hGNPEZ(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡃࡑࡎࡖࡆ࠳࠱ࡴࡶࠪॉ"))
	QstumvzTIEUMXCcx06aD4y8nSqH = wpFmEA3z8JR.content
	if pEo8g7riWVL014KaRtzQ(u"ࠬ࠴ࡪࡴࡱࡱࠫॊ") in RRucmYBaXegTtNOdGHMQ: url = ZXFs0mEPR8qI2zj.findall(JcDaEHuiS8TqBbOhWe4ZgwknoC1L3r(u"࠭ࠢࡴࡴࡦࠦ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ो"),QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	else: url = ZXFs0mEPR8qI2zj.findall(ffCSGrTJYPsxgVQWKLtHU3iMwB(u"ࠧࡴࡱࡸࡶࡨ࡫ࠠࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬौ"),QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	if not url: return ZSJVq5XDrRot(u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦࠣࡆࡔࡑࡒࡂ्ࠩ"),[],[]
	url = url[JcDaEHuiS8TqBbOhWe4ZgwknoC1L3r(u"࠲࿬")]
	if Ej67fFyoqW8kbV2HdSK(u"ࠩ࡫ࡸࡹࡶࠧॎ") not in url: url = eeIL1TfgFQJaKqVD8hGNPEZ(u"ࠪ࡬ࡹࡺࡰ࠻ࠩॏ")+url
	return eeIL1TfgFQJaKqVD8hGNPEZ(u"ࠫࠬॐ"),[aFQoGfmYKyqLU6X8libw9k3ncW5(u"ࠬ࠭॑")],[url]
def WW4JOYTltX53gcA2Uvbya0E6BIo(url):
	headers = { FhcnOB9t3frzvXb(u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶ॒ࠪ") : wwyUWMFAsO(u"ࠧࠨ॓") }
	if bdhQDyjm3nPwToFHkprvCzBLUGR(u"ࠨࡱࡳࡁࡩࡵࡷ࡯࡮ࡲࡥࡩࡥ࡯ࡳ࡫ࡪࠫ॔") in url:
		QstumvzTIEUMXCcx06aD4y8nSqH = QuWA3hsmIvockZDiy2rLg(dALVaOWB4jKN3Tbt0Cm1ns9k5u,url,OVmSuf8tpd(u"ࠩࠪॕ"),headers,AAgpHN0nMZ(u"ࠪࠫॖ"),ZSJVq5XDrRot(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡎࡑࡖࡌࡆࡎࡄࡂ࠯࠴ࡷࡹ࠭ॗ"))
		items = ZXFs0mEPR8qI2zj.findall(PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"ࠬࡪࡩࡳࡧࡦࡸࠥࡲࡩ࡯࡭࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠫक़"),QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
		if items: return aVLSn1xw5cK(u"࠭ࠧख़"),[sArCMRngQNmXkBoKv(u"ࠧࠨग़")],[items[hjNP5w9srJz2QpVISxBfndbD4CkXvl(u"࠳࿭")]]
		else:
			LaX1QCyeIJ = ZXFs0mEPR8qI2zj.findall(ffCSGrTJYPsxgVQWKLtHU3iMwB(u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡧࡵࡶࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭ज़"),QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
			if LaX1QCyeIJ:
				HHTzVhiY079bvdluNkFQ4wCMpe(FhcnOB9t3frzvXb(u"ࠩࠪड़"),fR68jBGWCzUsFXdlTKPOScugm(u"ࠪࠫढ़"),gSmqZU0plur2xKPJwQA(u"ࠫึูวๅห้๋ࠣࠦวๅ็๋ๆ฾ࠦวๅษุ่๏࠭फ़"),LaX1QCyeIJ[m6b7CoBk4EQ(u"࠴࿮")])
				return m6b7CoBk4EQ(u"ࠬࡋࡲࡳࡱࡵ࠾ࠥ࠭य़")+LaX1QCyeIJ[FhcnOB9t3frzvXb(u"࠵࿯")],[],[]
	else:
		Ym8DlVPuqS1tJb = yTMWeCgUROcvtsblfK85L62xPk(u"࠭࡭ࡰࡸ࡬ࡾࡱࡧ࡮ࡥࠩॠ")
		QstumvzTIEUMXCcx06aD4y8nSqH = QuWA3hsmIvockZDiy2rLg(dALVaOWB4jKN3Tbt0Cm1ns9k5u,url,kmdSKeBIwViM9t3(u"ࠧࠨॡ"),headers,XogUJZEijT7KWbxeO6(u"ࠨࠩॢ"),ZSJVq5XDrRot(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡓࡏࡔࡊࡄࡌࡉࡇ࠭࠳ࡰࡧࠫॣ"))
		IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall(PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"ࠪࡊࡴࡸ࡭ࠡ࡯ࡨࡸ࡭ࡵࡤ࠾ࠤࡓࡓࡘ࡚ࠢࠡࡣࡦࡸ࡮ࡵ࡮࠾࡞ࠪࠬ࠳࠰࠿ࠪ࡞ࠪࠬ࠳࠰࠿ࠪࡦ࡬ࡺࠬ।"),QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
		if not IZGcQbePXxwAoyYR1n: return sArCMRngQNmXkBoKv(u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡍࡐࡕࡋࡅࡍࡊࡁࠨ॥"),[],[]
		oKqQr8Ij0btxZ9SDm6h3Nd = IZGcQbePXxwAoyYR1n[JMLhEyaBWmskovGHTrVCxQ08(u"࠶࿰")][JMLhEyaBWmskovGHTrVCxQ08(u"࠶࿰")]
		bdq4e6Wr2gslnSiA38 = IZGcQbePXxwAoyYR1n[gSmqZU0plur2xKPJwQA(u"࠱࿲")][xuYvdJpOEyQKTLNwb(u"࠱࿱")]
		if XogUJZEijT7KWbxeO6(u"ࠬ࠴ࡲࡢࡴࠪ०") in bdq4e6Wr2gslnSiA38 or JcDaEHuiS8TqBbOhWe4ZgwknoC1L3r(u"࠭࠮ࡻ࡫ࡳࠫ१") in bdq4e6Wr2gslnSiA38: return pEo8g7riWVL014KaRtzQ(u"ࠧࡆࡴࡵࡳࡷࡀࠠࡎࡑࡖࡌࡆࡎࡄࡂࠢࡑࡳࡹࠦࡡࠡࡸ࡬ࡨࡪࡵࠠࡧ࡫࡯ࡩࠬ२"),[],[]
		items = ZXFs0mEPR8qI2zj.findall(jYaM5vilgZdFx6QHbApwVXO8et(u"ࠨࡰࡤࡱࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡹࡥࡱࡻࡥ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ३"),bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
		VbZ1Pig043uIGYQ = {}
		for aaYDh2EzJ5ky,AARNPWHjQU9dEmDI in items:
			VbZ1Pig043uIGYQ[aaYDh2EzJ5ky] = AARNPWHjQU9dEmDI
		data = XapnozmJWluEb8fdYye0SR6QxqZL(VbZ1Pig043uIGYQ)
		QstumvzTIEUMXCcx06aD4y8nSqH = QuWA3hsmIvockZDiy2rLg(dALVaOWB4jKN3Tbt0Cm1ns9k5u,oKqQr8Ij0btxZ9SDm6h3Nd,data,headers,kmdSKeBIwViM9t3(u"ࠩࠪ४"),jYaM5vilgZdFx6QHbApwVXO8et(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡍࡐࡕࡋࡅࡍࡊࡁ࠮࠵ࡵࡨࠬ५"))
		IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall(xuYvdJpOEyQKTLNwb(u"ࠫࡉࡵࡷ࡯࡮ࡲࡥࡩࠦࡖࡪࡦࡨࡳ࠳࠰࠿ࡨࡧࡷࡠ࠭ࡢࠧࠩ࠰࠭ࡃ࠮ࡢࠧ࠯ࠬࡂࡷࡴࡻࡲࡤࡧࡶ࠾࠭࠴ࠪࡀࠫ࡬ࡱࡦ࡭ࡥ࠻ࠩ६"),QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
		if not IZGcQbePXxwAoyYR1n: return LmcNhzY6fQPd2JyCGslkSr(u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡎࡑࡖࡌࡆࡎࡄࡂࠩ७"),[],[]
		download = IZGcQbePXxwAoyYR1n[MM2BQ7xrAfNivgenXPytGYOs0DEHRC(u"࠲࿳")][MM2BQ7xrAfNivgenXPytGYOs0DEHRC(u"࠲࿳")]
		bdq4e6Wr2gslnSiA38 = IZGcQbePXxwAoyYR1n[hjNP5w9srJz2QpVISxBfndbD4CkXvl(u"࠴࿵")][EDPaWgMt1SwNn8o(u"࠴࿴")]
		items = ZXFs0mEPR8qI2zj.findall(c4QSTnPiWUCjhrLlwGB(u"࠭ࡦࡪ࡮ࡨ࠾ࠧ࠮࠮ࠫࡁࠬࠦ࠭࠲࡬ࡢࡤࡨࡰ࠿ࠨ࠮ࠫࡁࠥࢀ࠮࠭८"),bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
		fUmXHDnkK8yCrEbeAdsMwl,xCLQK8kh39sjyi5DXSZAVeI,hk6AGaoeVqUHRbxm792XW,YYmyQXglbEewzL3IA2Sd,Eqt3x2aB8zV0vCLn = [],[],[],[],[]
		for RRucmYBaXegTtNOdGHMQ,title in items:
			if AAgpHN0nMZ(u"ࠧ࠯࡯࠶ࡹ࠽࠭९") in RRucmYBaXegTtNOdGHMQ:
				fUmXHDnkK8yCrEbeAdsMwl,hk6AGaoeVqUHRbxm792XW = c8T0X52CGk9UZ71q(RRucmYBaXegTtNOdGHMQ)
				YYmyQXglbEewzL3IA2Sd = YYmyQXglbEewzL3IA2Sd + hk6AGaoeVqUHRbxm792XW
				if fUmXHDnkK8yCrEbeAdsMwl[m6b7CoBk4EQ(u"࠵࿶")]==EDPaWgMt1SwNn8o(u"ࠨ࠯࠴ࠫ॰"): xCLQK8kh39sjyi5DXSZAVeI.append(aFQoGfmYKyqLU6X8libw9k3ncW5(u"ࠩࠣื๏ืแาࠢัหฺࠦࠧॱ")+sArCMRngQNmXkBoKv(u"ࠪࡱ࠸ࡻ࠸ࠡࠩॲ")+Ym8DlVPuqS1tJb)
				else:
					for title in fUmXHDnkK8yCrEbeAdsMwl:
						xCLQK8kh39sjyi5DXSZAVeI.append(gnfv8UtZ3daGqpjzk(u"ู๊ࠫࠥาใิࠤำอีࠡࠩॳ")+AAgpHN0nMZ(u"ࠬࡳ࠳ࡶ࠺ࠣࠫॴ")+Ym8DlVPuqS1tJb+PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"࠭ࠠࠨॵ")+title)
			else:
				title = title.replace(gnfv8UtZ3daGqpjzk(u"ࠧ࠭࡮ࡤࡦࡪࡲ࠺ࠣࠩॶ"),kmdSKeBIwViM9t3(u"ࠨࠩॷ"))
				title = title.strip(EDPaWgMt1SwNn8o(u"ࠩࠥࠫॸ"))
				title = kmdSKeBIwViM9t3(u"ࠪࠤุ๐ัโำࠣࠤำอีࠡࠩॹ")+ZSJVq5XDrRot(u"ࠫࠥࡳࡰ࠵ࠢࠪॺ")+Ym8DlVPuqS1tJb+hjNP5w9srJz2QpVISxBfndbD4CkXvl(u"ࠬࠦࠧॻ")+title
				xCLQK8kh39sjyi5DXSZAVeI.append(title)
				YYmyQXglbEewzL3IA2Sd.append(RRucmYBaXegTtNOdGHMQ)
		RRucmYBaXegTtNOdGHMQ = LmcNhzY6fQPd2JyCGslkSr(u"࠭ࡨࡵࡶࡳ࠾࠴࠵࡭ࡰࡵ࡫ࡥ࡭ࡪࡡ࠯ࡱࡱࡰ࡮ࡴࡥࠨॼ") + download
		QstumvzTIEUMXCcx06aD4y8nSqH = QuWA3hsmIvockZDiy2rLg(dALVaOWB4jKN3Tbt0Cm1ns9k5u,RRucmYBaXegTtNOdGHMQ,AAgpHN0nMZ(u"ࠧࠨॽ"),headers,aFQoGfmYKyqLU6X8libw9k3ncW5(u"ࠨࠩॾ"),AAgpHN0nMZ(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡓࡏࡔࡊࡄࡌࡉࡇ࠭࠶ࡶ࡫ࠫॿ"))
		items = ZXFs0mEPR8qI2zj.findall(FhcnOB9t3frzvXb(u"ࠥࡨࡴࡽ࡮࡭ࡱࡤࡨࡤࡼࡩࡥࡧࡲࡠ࠭࠭ࠨ࠯ࠬࡂ࠭ࠬ࠲ࠧࠩ࠰࠭ࡃ࠮࠭ࠬࠨࠪ࠱࠮ࡄ࠯ࠧ࠯ࠬࡂࡀࡹࡪ࠾ࠩ࠰࠭ࡃ࠮࠲ࠢঀ"),QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
		for id,nnPsf4XLIJ7RWF,hash,F50hr1lB8iCUeSAVjntKzHsR4 in items:
			title = JMLhEyaBWmskovGHTrVCxQ08(u"ู๊ࠫࠥาใิࠤฯำๅ๋ๆࠣาฬ฻ࠠࠨঁ")+pEo8g7riWVL014KaRtzQ(u"ࠬࠦ࡭ࡱ࠶ࠣࠫং")+Ym8DlVPuqS1tJb+JMLhEyaBWmskovGHTrVCxQ08(u"࠭ࠠࠨঃ")+F50hr1lB8iCUeSAVjntKzHsR4.split(bdhQDyjm3nPwToFHkprvCzBLUGR(u"ࠧࡹࠩ঄"))[sArCMRngQNmXkBoKv(u"࠷࿷")]
			RRucmYBaXegTtNOdGHMQ = m6b7CoBk4EQ(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࡯ࡲࡷ࡭ࡧࡨࡥࡣ࠱ࡳࡳࡲࡩ࡯ࡧ࠲ࡨࡱࡅ࡯ࡱ࠿ࡧࡳࡼࡴ࡬ࡰࡣࡧࡣࡴࡸࡩࡨࠨ࡬ࡨࡂ࠭অ")+id+FhcnOB9t3frzvXb(u"ࠩࠩࡱࡴࡪࡥ࠾ࠩআ")+nnPsf4XLIJ7RWF+c4QSTnPiWUCjhrLlwGB(u"ࠪࠪ࡭ࡧࡳࡩ࠿ࠪই")+hash
			Eqt3x2aB8zV0vCLn.append(F50hr1lB8iCUeSAVjntKzHsR4)
			xCLQK8kh39sjyi5DXSZAVeI.append(title)
			YYmyQXglbEewzL3IA2Sd.append(RRucmYBaXegTtNOdGHMQ)
		Eqt3x2aB8zV0vCLn = set(Eqt3x2aB8zV0vCLn)
		lTero9Y46sv,nT6oMYL0Cz2liXZmjuQqGDs = [],[]
		for title in xCLQK8kh39sjyi5DXSZAVeI:
			hWTJ2ycGOsFrwf6bZA = ZXFs0mEPR8qI2zj.findall(c4QSTnPiWUCjhrLlwGB(u"ࠦࠥ࠮࡜ࡥࠬࡻࢀࡡࡪࠪࠪࠨࠩࠦঈ"),title+jYaM5vilgZdFx6QHbApwVXO8et(u"ࠬࠬࠦࠨউ"),ZXFs0mEPR8qI2zj.DOTALL)
			for F50hr1lB8iCUeSAVjntKzHsR4 in Eqt3x2aB8zV0vCLn:
				if hWTJ2ycGOsFrwf6bZA[aFQoGfmYKyqLU6X8libw9k3ncW5(u"࠰࿸")] in F50hr1lB8iCUeSAVjntKzHsR4:
					title = title.replace(hWTJ2ycGOsFrwf6bZA[hjNP5w9srJz2QpVISxBfndbD4CkXvl(u"࠲࿺")],F50hr1lB8iCUeSAVjntKzHsR4.split(kRYWcNuAazr4jtmBoxFVS19Z6(u"࠭ࡸࠨঊ"))[pEo8g7riWVL014KaRtzQ(u"࠲࿹")])
			lTero9Y46sv.append(title)
		for xxFhvt275i8MdUVuPkSXzmbT in range(len(YYmyQXglbEewzL3IA2Sd)):
			items = ZXFs0mEPR8qI2zj.findall(kRYWcNuAazr4jtmBoxFVS19Z6(u"ࠢࠧࠨࠫ࠲࠯ࡅࠩࠩ࡞ࡧ࠮࠮ࠬࠦࠣঋ"),kmdSKeBIwViM9t3(u"ࠨࠨࠩࠫঌ")+lTero9Y46sv[xxFhvt275i8MdUVuPkSXzmbT]+eeIL1TfgFQJaKqVD8hGNPEZ(u"ࠩࠩࠪࠬ঍"),ZXFs0mEPR8qI2zj.DOTALL)
			nT6oMYL0Cz2liXZmjuQqGDs.append( [lTero9Y46sv[xxFhvt275i8MdUVuPkSXzmbT],YYmyQXglbEewzL3IA2Sd[xxFhvt275i8MdUVuPkSXzmbT],items[pEo8g7riWVL014KaRtzQ(u"࠴࿼")][pEo8g7riWVL014KaRtzQ(u"࠴࿼")],items[pEo8g7riWVL014KaRtzQ(u"࠴࿼")][JcDaEHuiS8TqBbOhWe4ZgwknoC1L3r(u"࠴࿻")]] )
		nT6oMYL0Cz2liXZmjuQqGDs = sorted(nT6oMYL0Cz2liXZmjuQqGDs, key=lambda s9DIkYgQhV8dAR: s9DIkYgQhV8dAR[XogUJZEijT7KWbxeO6(u"࠸࿽")], reverse=DLSVmlyBbCK(u"ࡘࡷࡻࡥᄩ"))
		nT6oMYL0Cz2liXZmjuQqGDs = sorted(nT6oMYL0Cz2liXZmjuQqGDs, key=lambda s9DIkYgQhV8dAR: s9DIkYgQhV8dAR[bdhQDyjm3nPwToFHkprvCzBLUGR(u"࠸࿾")], reverse=gnfv8UtZ3daGqpjzk(u"ࡋࡧ࡬ࡴࡧᄪ"))
		xCLQK8kh39sjyi5DXSZAVeI,YYmyQXglbEewzL3IA2Sd = [],[]
		for xxFhvt275i8MdUVuPkSXzmbT in range(len(nT6oMYL0Cz2liXZmjuQqGDs)):
			xCLQK8kh39sjyi5DXSZAVeI.append(nT6oMYL0Cz2liXZmjuQqGDs[xxFhvt275i8MdUVuPkSXzmbT][JMLhEyaBWmskovGHTrVCxQ08(u"࠰࿿")])
			YYmyQXglbEewzL3IA2Sd.append(nT6oMYL0Cz2liXZmjuQqGDs[xxFhvt275i8MdUVuPkSXzmbT][bdhQDyjm3nPwToFHkprvCzBLUGR(u"࠲က")])
	if len(YYmyQXglbEewzL3IA2Sd)==aFQoGfmYKyqLU6X8libw9k3ncW5(u"࠲ခ"): return c4QSTnPiWUCjhrLlwGB(u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨࠥࡓࡏࡔࡊࡄࡌࡉࡇࠧ঎"),[],[]
	return Ej67fFyoqW8kbV2HdSK(u"ࠫࠬএ"),xCLQK8kh39sjyi5DXSZAVeI,YYmyQXglbEewzL3IA2Sd
def kb80Jxa3ResnB4SGyiMXfDEKgQLT(url):
	mcEHCT3jSM = url.split(kRYWcNuAazr4jtmBoxFVS19Z6(u"ࠬࡅࠧঐ"))
	lQHXdV9Nzf6BLqS8D = mcEHCT3jSM[m6b7CoBk4EQ(u"࠳ဂ")]
	headers = { gnfv8UtZ3daGqpjzk(u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪ঑") : wwyUWMFAsO(u"ࠧࠨ঒") }
	QstumvzTIEUMXCcx06aD4y8nSqH = QuWA3hsmIvockZDiy2rLg(dALVaOWB4jKN3Tbt0Cm1ns9k5u,lQHXdV9Nzf6BLqS8D,xuYvdJpOEyQKTLNwb(u"ࠨࠩও"),headers,ffCSGrTJYPsxgVQWKLtHU3iMwB(u"ࠩࠪঔ"),c4QSTnPiWUCjhrLlwGB(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡅ࠶ࡖࡖࡅࡗ࠳࠱ࡴࡶࠪক"))
	items = ZXFs0mEPR8qI2zj.findall(pEo8g7riWVL014KaRtzQ(u"ࠫࡕࡲࡥࡢࡵࡨࠤࡼࡧࡩࡵ࠰࠭ࡃ࡭ࡸࡥࡧ࠿࡟ࠫ࠭࠴ࠪࡀࠫ࡟ࠫࠬখ"),QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	url = items[DLSVmlyBbCK(u"࠴ဃ")]
	return XogUJZEijT7KWbxeO6(u"ࠬࡔࡅࡆࡆࡢࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨগ"),[hjNP5w9srJz2QpVISxBfndbD4CkXvl(u"࠭ࠧঘ")],[url]
def TV2vt3XUsBcMQJOZ56j7(url):
	xCLQK8kh39sjyi5DXSZAVeI,YYmyQXglbEewzL3IA2Sd = [],[]
	headers = { gnfv8UtZ3daGqpjzk(u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫঙ") : LmcNhzY6fQPd2JyCGslkSr(u"ࠨࠩচ") }
	QstumvzTIEUMXCcx06aD4y8nSqH = QuWA3hsmIvockZDiy2rLg(JNsoWV1CXc4xy,url,gSmqZU0plur2xKPJwQA(u"ࠩࠪছ"),headers,pEo8g7riWVL014KaRtzQ(u"ࠪࠫজ"),c4QSTnPiWUCjhrLlwGB(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡇࡃࡆ࡙ࡑ࡚࡙ࡃࡑࡒࡏࡘ࠳࠱ࡴࡶࠪঝ"))
	lQHXdV9Nzf6BLqS8D = ZXFs0mEPR8qI2zj.findall(FhcnOB9t3frzvXb(u"ࠬࡸࡥࡥ࡫ࡵࡩࡨࡺ࡟ࡶࡴ࡯࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠬঞ"),QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	if lQHXdV9Nzf6BLqS8D: return LmcNhzY6fQPd2JyCGslkSr(u"࠭ࠧট"),[OVmSuf8tpd(u"ࠧࠨঠ")],[lQHXdV9Nzf6BLqS8D[sArCMRngQNmXkBoKv(u"࠵င")]]
	else: return aVLSn1xw5cK(u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦࠣࡆ࡚ࡠ࡚ࡗࡔࡏࠫড"),[],[]
def vvl04Fn8R9tjJOxN(url):
	xCLQK8kh39sjyi5DXSZAVeI,YYmyQXglbEewzL3IA2Sd = [],[]
	headers = { m6b7CoBk4EQ(u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭ঢ") : MM2BQ7xrAfNivgenXPytGYOs0DEHRC(u"ࠪࠫণ") }
	QstumvzTIEUMXCcx06aD4y8nSqH = QuWA3hsmIvockZDiy2rLg(JNsoWV1CXc4xy,url,eeIL1TfgFQJaKqVD8hGNPEZ(u"ࠫࠬত"),headers,Ej67fFyoqW8kbV2HdSK(u"ࠬ࠭থ"),fR68jBGWCzUsFXdlTKPOScugm(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡉࡅࡈ࡛ࡌࡕ࡛ࡅࡓࡔࡑࡓ࠮࠳ࡶࡸࠬদ"))
	lQHXdV9Nzf6BLqS8D = ZXFs0mEPR8qI2zj.findall(ZSJVq5XDrRot(u"ࠧࡩࡴࡨࡪࠧ࠲ࠢࠩࡪࡷࡸ࠳࠰࠿ࠪࠤࠪধ"),QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	if lQHXdV9Nzf6BLqS8D: return sArCMRngQNmXkBoKv(u"ࠨࠩন"),[Ej67fFyoqW8kbV2HdSK(u"ࠩࠪ঩")],[lQHXdV9Nzf6BLqS8D[FhcnOB9t3frzvXb(u"࠶စ")]]
	else: return gSmqZU0plur2xKPJwQA(u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨࠥࡌࡁࡄࡗࡏࡘ࡞ࡈࡏࡐࡍࡖࠫপ"),[],[]
def RaP18ex9yp(url):
	xCLQK8kh39sjyi5DXSZAVeI,YYmyQXglbEewzL3IA2Sd,errno = [],[],gnfv8UtZ3daGqpjzk(u"ࠫࠬফ")
	if ZSJVq5XDrRot(u"ࠬ࠵ࡷࡱ࠯ࡤࡨࡲ࡯࡮࠰ࠩব") in url:
		lQHXdV9Nzf6BLqS8D,BTMputsaqV = hGMVvHBuPC014(url)
		obS4TpHeV3digGC = {kRYWcNuAazr4jtmBoxFVS19Z6(u"࠭ࡃࡰࡰࡷࡩࡳࡺ࠭ࡕࡻࡳࡩࠬভ"):m6b7CoBk4EQ(u"ࠧࡢࡲࡳࡰ࡮ࡩࡡࡵ࡫ࡲࡲ࠴ࡾ࠭ࡸࡹࡺ࠱࡫ࡵࡲ࡮࠯ࡸࡶࡱ࡫࡮ࡤࡱࡧࡩࡩࡁࠠࡤࡪࡤࡶࡸ࡫ࡴ࠾ࡗࡗࡊ࠲࠾ࠧম")}
		wpFmEA3z8JR = A6F71g3cqN4(dALVaOWB4jKN3Tbt0Cm1ns9k5u,gSmqZU0plur2xKPJwQA(u"ࠨࡒࡒࡗ࡙࠭য"),lQHXdV9Nzf6BLqS8D,BTMputsaqV,obS4TpHeV3digGC,LmcNhzY6fQPd2JyCGslkSr(u"ࠩࠪর"),ffCSGrTJYPsxgVQWKLtHU3iMwB(u"ࠪࠫ঱"),gnfv8UtZ3daGqpjzk(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡇࡃࡍࡉࡗ࡙ࡈࡐ࡙࠰࠶ࡳࡪࠧল"))
		XgMyLUkfvP4uKVpQsY8RiWZz6N50O = wpFmEA3z8JR.content
		if XgMyLUkfvP4uKVpQsY8RiWZz6N50O.startswith(fR68jBGWCzUsFXdlTKPOScugm(u"ࠬ࡮ࡴࡵࡲࠪ঳")): lQHXdV9Nzf6BLqS8D = XgMyLUkfvP4uKVpQsY8RiWZz6N50O
		else:
			aaIn3XlQKJ6zSfkmjuCyM = ZXFs0mEPR8qI2zj.findall(m6b7CoBk4EQ(u"࠭ࠧࠨࡵࡵࡧࡂࡡࠧࠣ࡟ࠫ࠲࠯ࡅࠩ࡜ࠩࠥࡡࠬ࠭ࠧ঴"),XgMyLUkfvP4uKVpQsY8RiWZz6N50O,ZXFs0mEPR8qI2zj.DOTALL)
			if aaIn3XlQKJ6zSfkmjuCyM:
				lQHXdV9Nzf6BLqS8D = aaIn3XlQKJ6zSfkmjuCyM[m6b7CoBk4EQ(u"࠰ဆ")]
				aaIn3XlQKJ6zSfkmjuCyM = ZXFs0mEPR8qI2zj.findall(hjNP5w9srJz2QpVISxBfndbD4CkXvl(u"ࠧࡴࡱࡸࡶࡨ࡫࠽ࠩ࠰࠭ࡃ࠮ࡡࠦࠥ࡟ࠪ঵"),lQHXdV9Nzf6BLqS8D,ZXFs0mEPR8qI2zj.DOTALL)
				if aaIn3XlQKJ6zSfkmjuCyM:
					lQHXdV9Nzf6BLqS8D = ejBOu2WXwvb4YpITdsLF16(aaIn3XlQKJ6zSfkmjuCyM[DLSVmlyBbCK(u"࠱ဇ")])
					return J3OCAmZVcn(u"ࠨࠩশ"),[LmcNhzY6fQPd2JyCGslkSr(u"ࠩࠪষ")],[lQHXdV9Nzf6BLqS8D]
	elif gnfv8UtZ3daGqpjzk(u"ࠪ࠳ࡱ࡯࡮࡬ࡵ࠲ࠫস") in url:
		wpFmEA3z8JR = A6F71g3cqN4(dALVaOWB4jKN3Tbt0Cm1ns9k5u,m6b7CoBk4EQ(u"ࠫࡌࡋࡔࠨহ"),url,eeIL1TfgFQJaKqVD8hGNPEZ(u"ࠬ࠭঺"),kRYWcNuAazr4jtmBoxFVS19Z6(u"࠭ࠧ঻"),xuYvdJpOEyQKTLNwb(u"࡚ࡲࡶࡧᄫ"),EDPaWgMt1SwNn8o(u"ࠧࠨ়"),jYaM5vilgZdFx6QHbApwVXO8et(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡋࡇࡊࡆࡔࡖࡌࡔ࡝࠭࠲ࡵࡷࠫঽ"))
		XgMyLUkfvP4uKVpQsY8RiWZz6N50O = wpFmEA3z8JR.content
		if JMLhEyaBWmskovGHTrVCxQ08(u"ࠩࡏࡳࡨࡧࡴࡪࡱࡱࠫা") in list(wpFmEA3z8JR.headers.keys()): lQHXdV9Nzf6BLqS8D = wpFmEA3z8JR.headers[pEo8g7riWVL014KaRtzQ(u"ࠪࡐࡴࡩࡡࡵ࡫ࡲࡲࠬি")]
		else: lQHXdV9Nzf6BLqS8D = ZXFs0mEPR8qI2zj.findall(bdhQDyjm3nPwToFHkprvCzBLUGR(u"ࠫ࡮ࡪ࠽ࠣ࡮࡬ࡲࡰࠨ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨী"),XgMyLUkfvP4uKVpQsY8RiWZz6N50O,ZXFs0mEPR8qI2zj.DOTALL)[ZSJVq5XDrRot(u"࠲ဈ")]
	if JMLhEyaBWmskovGHTrVCxQ08(u"ࠬ࠵ࡶ࠰ࠩু") in lQHXdV9Nzf6BLqS8D or MM2BQ7xrAfNivgenXPytGYOs0DEHRC(u"࠭࠯ࡧ࠱ࠪূ") in lQHXdV9Nzf6BLqS8D:
		lQHXdV9Nzf6BLqS8D = lQHXdV9Nzf6BLqS8D.replace(hjNP5w9srJz2QpVISxBfndbD4CkXvl(u"ࠧ࠰ࡨ࠲ࠫৃ"),sArCMRngQNmXkBoKv(u"ࠨ࠱ࡤࡴ࡮࠵ࡳࡰࡷࡵࡧࡪ࠵ࠧৄ"))
		lQHXdV9Nzf6BLqS8D = lQHXdV9Nzf6BLqS8D.replace(JcDaEHuiS8TqBbOhWe4ZgwknoC1L3r(u"ࠩ࠲ࡺ࠴࠭৅"),yTMWeCgUROcvtsblfK85L62xPk(u"ࠪ࠳ࡦࡶࡩ࠰ࡵࡲࡹࡷࡩࡥ࠰ࠩ৆"))
		wpFmEA3z8JR = A6F71g3cqN4(dALVaOWB4jKN3Tbt0Cm1ns9k5u,EDPaWgMt1SwNn8o(u"ࠫࡕࡕࡓࡕࠩে"),lQHXdV9Nzf6BLqS8D,OVmSuf8tpd(u"ࠬ࠭ৈ"),MM2BQ7xrAfNivgenXPytGYOs0DEHRC(u"࠭ࠧ৉"),xuYvdJpOEyQKTLNwb(u"ࠧࠨ৊"),aFQoGfmYKyqLU6X8libw9k3ncW5(u"ࠨࠩো"),ZSJVq5XDrRot(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡌࡁࡋࡇࡕࡗࡍࡕࡗ࠮࠵ࡵࡨࠬৌ"))
		XgMyLUkfvP4uKVpQsY8RiWZz6N50O = wpFmEA3z8JR.content
		items = ZXFs0mEPR8qI2zj.findall(MM2BQ7xrAfNivgenXPytGYOs0DEHRC(u"ࠪࠦ࡫࡯࡬ࡦࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥ࠰ࠧࡲࡡࡣࡧ࡯ࠦ࠿ࠨࠨ࠯ࠬࡂ্࠭ࠧ࠭"),XgMyLUkfvP4uKVpQsY8RiWZz6N50O,ZXFs0mEPR8qI2zj.DOTALL)
		if items:
			for RRucmYBaXegTtNOdGHMQ,title in items:
				RRucmYBaXegTtNOdGHMQ = RRucmYBaXegTtNOdGHMQ.replace(xuYvdJpOEyQKTLNwb(u"ࠫࡡࡢࠧৎ"),JcDaEHuiS8TqBbOhWe4ZgwknoC1L3r(u"ࠬ࠭৏"))
				xCLQK8kh39sjyi5DXSZAVeI.append(title)
				YYmyQXglbEewzL3IA2Sd.append(RRucmYBaXegTtNOdGHMQ)
		else:
			items = ZXFs0mEPR8qI2zj.findall(gSmqZU0plur2xKPJwQA(u"࠭ࠢࡧ࡫࡯ࡩࠧࡀࠢࠩ࠰࠭ࡃ࠮ࠨࠧ৐"),XgMyLUkfvP4uKVpQsY8RiWZz6N50O,ZXFs0mEPR8qI2zj.DOTALL)
			if items:
				RRucmYBaXegTtNOdGHMQ = items[pEo8g7riWVL014KaRtzQ(u"࠳ဉ")]
				RRucmYBaXegTtNOdGHMQ = RRucmYBaXegTtNOdGHMQ.replace(ZSJVq5XDrRot(u"ࠧ࡝࡞ࠪ৑"),sArCMRngQNmXkBoKv(u"ࠨࠩ৒"))
				xCLQK8kh39sjyi5DXSZAVeI.append(PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"ࠩࠪ৓"))
				YYmyQXglbEewzL3IA2Sd.append(RRucmYBaXegTtNOdGHMQ)
	else: return m6b7CoBk4EQ(u"ࠪࡒࡊࡋࡄࡠࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭৔"),[ZSJVq5XDrRot(u"ࠫࠬ৕")],[lQHXdV9Nzf6BLqS8D]
	if len(YYmyQXglbEewzL3IA2Sd)==DLSVmlyBbCK(u"࠴ည"): return kRYWcNuAazr4jtmBoxFVS19Z6(u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡇࡃࡍࡉࡗ࡙ࡈࡐ࡙ࠪ৖"),[],[]
	return gSmqZU0plur2xKPJwQA(u"࠭ࠧৗ"),xCLQK8kh39sjyi5DXSZAVeI,YYmyQXglbEewzL3IA2Sd
def D2DLOUb5Qx(url):
	wpFmEA3z8JR = A6F71g3cqN4(dALVaOWB4jKN3Tbt0Cm1ns9k5u,JMLhEyaBWmskovGHTrVCxQ08(u"ࠧࡈࡇࡗࠫ৘"),url,hjNP5w9srJz2QpVISxBfndbD4CkXvl(u"ࠨࠩ৙"),FhcnOB9t3frzvXb(u"ࠩࠪ৚"),EDPaWgMt1SwNn8o(u"ࠪࠫ৛"),c4QSTnPiWUCjhrLlwGB(u"ࠫࠬড়"),MM2BQ7xrAfNivgenXPytGYOs0DEHRC(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡏࡒ࡚ࡘ࠺ࡕ࠮࠳ࡶࡸࠬঢ়"))
	QstumvzTIEUMXCcx06aD4y8nSqH = wpFmEA3z8JR.content
	xCLQK8kh39sjyi5DXSZAVeI,YYmyQXglbEewzL3IA2Sd,errno = [],[],gnfv8UtZ3daGqpjzk(u"࠭ࠧ৞")
	if jYaM5vilgZdFx6QHbApwVXO8et(u"ࠧࡱ࡮ࡤࡽࡪࡸ࡟ࡦ࡯ࡥࡩࡩ࠴ࡰࡩࡲࠪয়") in url or eeIL1TfgFQJaKqVD8hGNPEZ(u"ࠨ࠱ࡨࡱࡧ࡫ࡤ࠰ࠩৠ") in url:
		if OVmSuf8tpd(u"ࠩࡳࡰࡦࡿࡥࡳࡡࡨࡱࡧ࡫ࡤ࠯ࡲ࡫ࡴࠬৡ") in url:
			lQHXdV9Nzf6BLqS8D = ZXFs0mEPR8qI2zj.findall(kRYWcNuAazr4jtmBoxFVS19Z6(u"ࠪࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨৢ"),QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
			lQHXdV9Nzf6BLqS8D = lQHXdV9Nzf6BLqS8D[jYaM5vilgZdFx6QHbApwVXO8et(u"࠵ဋ")]
		else: lQHXdV9Nzf6BLqS8D = url
		if OVmSuf8tpd(u"ࠫࡲࡵࡶࡴ࠶ࡸࠫৣ") not in lQHXdV9Nzf6BLqS8D: return aVLSn1xw5cK(u"ࠬࡔࡅࡆࡆࡢࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨ৤"),[kmdSKeBIwViM9t3(u"࠭ࠧ৥")],[lQHXdV9Nzf6BLqS8D]
		wpFmEA3z8JR = A6F71g3cqN4(dALVaOWB4jKN3Tbt0Cm1ns9k5u,Ej67fFyoqW8kbV2HdSK(u"ࠧࡈࡇࡗࠫ০"),lQHXdV9Nzf6BLqS8D,XogUJZEijT7KWbxeO6(u"ࠨࠩ১"),ffCSGrTJYPsxgVQWKLtHU3iMwB(u"ࠩࠪ২"),J3OCAmZVcn(u"ࠪࠫ৩"),Ej67fFyoqW8kbV2HdSK(u"ࠫࠬ৪"),DLSVmlyBbCK(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡏࡒ࡚ࡘ࠺ࡕ࠮࠴ࡱࡨࠬ৫"))
		QstumvzTIEUMXCcx06aD4y8nSqH = wpFmEA3z8JR.content
		IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall(ZSJVq5XDrRot(u"࠭ࡩࡥ࠿ࠥࡴࡱࡧࡹࡦࡴࠥࠬ࠳࠰࠿ࠪࡸ࡬ࡨࡪࡵࡪࡴࠩ৬"),QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
		bdq4e6Wr2gslnSiA38 = IZGcQbePXxwAoyYR1n[sArCMRngQNmXkBoKv(u"࠶ဌ")]
		items = ZXFs0mEPR8qI2zj.findall(kRYWcNuAazr4jtmBoxFVS19Z6(u"ࠧ࠽ࡵࡲࡹࡷࡩࡥࠡࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࡮ࡤࡦࡪࡲ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ৭"),bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
		if items:
			for RRucmYBaXegTtNOdGHMQ,W5V6oRmIDCvcMGBQU in items:
				xCLQK8kh39sjyi5DXSZAVeI.append(W5V6oRmIDCvcMGBQU)
				YYmyQXglbEewzL3IA2Sd.append(RRucmYBaXegTtNOdGHMQ)
	elif hjNP5w9srJz2QpVISxBfndbD4CkXvl(u"ࠨ࡯ࡤ࡭ࡳࡥࡰ࡭ࡣࡼࡩࡷ࠴ࡰࡩࡲࠪ৮") in url:
		lQHXdV9Nzf6BLqS8D = ZXFs0mEPR8qI2zj.findall(J3OCAmZVcn(u"ࠩࡸࡶࡱࡃࠨ࠯ࠬࡂ࠭ࠧ࠭৯"),QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
		lQHXdV9Nzf6BLqS8D = lQHXdV9Nzf6BLqS8D[ffCSGrTJYPsxgVQWKLtHU3iMwB(u"࠰ဍ")]
		wpFmEA3z8JR = A6F71g3cqN4(dALVaOWB4jKN3Tbt0Cm1ns9k5u,DLSVmlyBbCK(u"ࠪࡋࡊ࡚ࠧৰ"),lQHXdV9Nzf6BLqS8D,LmcNhzY6fQPd2JyCGslkSr(u"ࠫࠬৱ"),eeIL1TfgFQJaKqVD8hGNPEZ(u"ࠬ࠭৲"),EDPaWgMt1SwNn8o(u"࠭ࠧ৳"),xuYvdJpOEyQKTLNwb(u"ࠧࠨ৴"),ZSJVq5XDrRot(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡒࡕࡖࡔ࠶ࡘ࠱࠸ࡸࡤࠨ৵"))
		QstumvzTIEUMXCcx06aD4y8nSqH = wpFmEA3z8JR.content
		aaIn3XlQKJ6zSfkmjuCyM = ZXFs0mEPR8qI2zj.findall(xuYvdJpOEyQKTLNwb(u"ࠩࠥࡪ࡮ࡲࡥࠣ࠼ࠣࠦ࠭࠴ࠪࡀࠫࠥࠫ৶"),QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
		aaIn3XlQKJ6zSfkmjuCyM = aaIn3XlQKJ6zSfkmjuCyM[fR68jBGWCzUsFXdlTKPOScugm(u"࠱ဎ")]
		xCLQK8kh39sjyi5DXSZAVeI.append(kmdSKeBIwViM9t3(u"ࠪࠫ৷"))
		YYmyQXglbEewzL3IA2Sd.append(aaIn3XlQKJ6zSfkmjuCyM)
	elif m6b7CoBk4EQ(u"ࠫࡩࡵࡷ࡯࡮ࡲࡥࡩࡥ࡬ࡪࡰ࡮ࠫ৸") in url:
		lQHXdV9Nzf6BLqS8D = ZXFs0mEPR8qI2zj.findall(gSmqZU0plur2xKPJwQA(u"ࠬࡂࡣࡦࡰࡷࡩࡷࡄ࠼ࡢࠢ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ৹"),QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
		if lQHXdV9Nzf6BLqS8D:
			lQHXdV9Nzf6BLqS8D = lQHXdV9Nzf6BLqS8D[EDPaWgMt1SwNn8o(u"࠲ဏ")]
			return JcDaEHuiS8TqBbOhWe4ZgwknoC1L3r(u"࠭ࡎࡆࡇࡇࡣࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩ৺"),[kRYWcNuAazr4jtmBoxFVS19Z6(u"ࠧࠨ৻")],[lQHXdV9Nzf6BLqS8D]
	if len(YYmyQXglbEewzL3IA2Sd)==pEo8g7riWVL014KaRtzQ(u"࠳တ"): return xuYvdJpOEyQKTLNwb(u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦࠣࡑࡔ࡜ࡓ࠵ࡗࠪৼ"),[],[]
	return Ej67fFyoqW8kbV2HdSK(u"ࠩࠪ৽"),xCLQK8kh39sjyi5DXSZAVeI,YYmyQXglbEewzL3IA2Sd
def u2APxIQdlD(url):
	if J3OCAmZVcn(u"ࠪࡃ࡬࡫ࡴ࠾ࠩ৾") in url:
		RRucmYBaXegTtNOdGHMQ = url.split(gnfv8UtZ3daGqpjzk(u"ࠫࡄ࡭ࡥࡵ࠿ࠪ৿"),FhcnOB9t3frzvXb(u"࠵ထ"))[FhcnOB9t3frzvXb(u"࠵ထ")]
		RRucmYBaXegTtNOdGHMQ = EGTVgQoSu6ZsD.b64decode(RRucmYBaXegTtNOdGHMQ)
		if VYMZsxRpcQHPgkaiDKjyoh: RRucmYBaXegTtNOdGHMQ = RRucmYBaXegTtNOdGHMQ.decode(jYaM5vilgZdFx6QHbApwVXO8et(u"ࠬࡻࡴࡧ࠺ࠪ਀"),yTMWeCgUROcvtsblfK85L62xPk(u"࠭ࡩࡨࡰࡲࡶࡪ࠭ਁ"))
		return gnfv8UtZ3daGqpjzk(u"ࠧࡏࡇࡈࡈࡤࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪਂ"),[PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"ࠨࠩਃ")],[RRucmYBaXegTtNOdGHMQ]
	website = uReHcEzxkTm6pN4Q[Ej67fFyoqW8kbV2HdSK(u"ࠩࡆࡍࡒࡇࡃࡍࡗࡅࠫ਄")][bdhQDyjm3nPwToFHkprvCzBLUGR(u"࠵ဒ")]
	headers = {kmdSKeBIwViM9t3(u"ࠪࡖࡪ࡬ࡥࡳࡧࡵࠫਅ"):website}
	wpFmEA3z8JR = A6F71g3cqN4(KxirmCLT6Gw,JcDaEHuiS8TqBbOhWe4ZgwknoC1L3r(u"ࠫࡌࡋࡔࠨਆ"),url,J3OCAmZVcn(u"ࠬ࠭ਇ"),headers,aVLSn1xw5cK(u"࠭ࠧਈ"),pEo8g7riWVL014KaRtzQ(u"ࠧࠨਉ"),PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡈࡏࡍࡂࡅࡏ࡙ࡇ࠳࠲࡯ࡦࠪਊ"))
	QstumvzTIEUMXCcx06aD4y8nSqH = wpFmEA3z8JR.content
	NGmuWwXdLQ6nMltx39FYECohJ = d78KRnJmBWscGua0XMk(url,yTMWeCgUROcvtsblfK85L62xPk(u"ࠩࡸࡶࡱ࠭਋"))
	RRucmYBaXegTtNOdGHMQ = ZXFs0mEPR8qI2zj.findall(gSmqZU0plur2xKPJwQA(u"ࠪࡨࡴࡽ࡮࡭ࡱࡤࡨࡂ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ਌"),QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	if not RRucmYBaXegTtNOdGHMQ: RRucmYBaXegTtNOdGHMQ = ZXFs0mEPR8qI2zj.findall(JcDaEHuiS8TqBbOhWe4ZgwknoC1L3r(u"ࠦࡸࡵࡵࡳࡥࡨࡷ࠿ࠦ࡜࡜ࠩࠫ࠲࠯ࡅࠩࠨࠤ਍"),QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	if not RRucmYBaXegTtNOdGHMQ: RRucmYBaXegTtNOdGHMQ = ZXFs0mEPR8qI2zj.findall(JMLhEyaBWmskovGHTrVCxQ08(u"ࠧ࡬ࡩ࡭ࡧ࠽ࠫ࠭࠴ࠪࡀࠫࠪࠦ਎"),QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	if RRucmYBaXegTtNOdGHMQ:
		RRucmYBaXegTtNOdGHMQ = RRucmYBaXegTtNOdGHMQ[gSmqZU0plur2xKPJwQA(u"࠶ဓ")]+EDPaWgMt1SwNn8o(u"࠭ࡼࡓࡧࡩࡩࡷ࡫ࡲ࠾ࠩਏ")+website
		return LmcNhzY6fQPd2JyCGslkSr(u"ࠧࠨਐ"),[AAgpHN0nMZ(u"ࠨࠩ਑")],[RRucmYBaXegTtNOdGHMQ]
	if aVLSn1xw5cK(u"ࠩࡱࡥࡲ࡫࠽࡚ࠣࡷࡳࡰ࡫࡮ࠣࠩ਒") in QstumvzTIEUMXCcx06aD4y8nSqH:
		bO2kJsUQdx9MZt7CFRwoVAP = ZXFs0mEPR8qI2zj.findall(gnfv8UtZ3daGqpjzk(u"ࠪࡲࡦࡳࡥ࠾ࠤ࡛ࡸࡴࡱࡥ࡯ࠤࠣࡧࡴࡴࡴࡦࡰࡷࡁࠧ࠮࠮ࠫࡁࠬࠦࠬਓ"),QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
		if bO2kJsUQdx9MZt7CFRwoVAP:
			RRucmYBaXegTtNOdGHMQ = bO2kJsUQdx9MZt7CFRwoVAP[Ej67fFyoqW8kbV2HdSK(u"࠰န")]
			RRucmYBaXegTtNOdGHMQ = EGTVgQoSu6ZsD.b64decode(RRucmYBaXegTtNOdGHMQ)
			if VYMZsxRpcQHPgkaiDKjyoh: RRucmYBaXegTtNOdGHMQ = RRucmYBaXegTtNOdGHMQ.decode(wwyUWMFAsO(u"ࠫࡺࡺࡦ࠹ࠩਔ"),gnfv8UtZ3daGqpjzk(u"ࠬ࡯ࡧ࡯ࡱࡵࡩࠬਕ"))
			RRucmYBaXegTtNOdGHMQ = ZXFs0mEPR8qI2zj.findall(xuYvdJpOEyQKTLNwb(u"࠭ࡨࡵࡶࡳ࠲࠯ࡅࠨࡩࡶࡷࡴ࠳࠰࠿ࠪ࠮ࠪਖ"),RRucmYBaXegTtNOdGHMQ,ZXFs0mEPR8qI2zj.DOTALL)
			if RRucmYBaXegTtNOdGHMQ:
				RRucmYBaXegTtNOdGHMQ = RRucmYBaXegTtNOdGHMQ[kmdSKeBIwViM9t3(u"࠱ပ")]+pEo8g7riWVL014KaRtzQ(u"ࠧࡽࡔࡨࡪࡪࡸࡥࡳ࠿ࠪਗ")+website
				return kmdSKeBIwViM9t3(u"ࠨࠩਘ"),[pEo8g7riWVL014KaRtzQ(u"ࠩࠪਙ")],[RRucmYBaXegTtNOdGHMQ]
	return XogUJZEijT7KWbxeO6(u"ࠪࡒࡊࡋࡄࡠࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭ਚ"),[ZSJVq5XDrRot(u"ࠫࠬਛ")],[url]
def jRx1tlqX0z(url,qBKDxcalp4QdXitguWhSHwo2Zy9E):
	AABKVNO3WiMUSe0,yf608hE5KeRG1DscunvrU = [],[]
	if LmcNhzY6fQPd2JyCGslkSr(u"ࠬ࠵࠱࠰ࠩਜ") in url:
		RRucmYBaXegTtNOdGHMQ = url.replace(OVmSuf8tpd(u"࠭࠯࠲࠱ࠪਝ"),OVmSuf8tpd(u"ࠧ࠰࠶࠲ࠫਞ"))
		wpFmEA3z8JR = A6F71g3cqN4(KxirmCLT6Gw,MM2BQ7xrAfNivgenXPytGYOs0DEHRC(u"ࠨࡉࡈࡘࠬਟ"),RRucmYBaXegTtNOdGHMQ,ZSJVq5XDrRot(u"ࠩࠪਠ"),JcDaEHuiS8TqBbOhWe4ZgwknoC1L3r(u"ࠪࠫਡ"),gnfv8UtZ3daGqpjzk(u"ࡆࡢ࡮ࡶࡩᄬ"),xuYvdJpOEyQKTLNwb(u"ࠫࠬਢ"),hjNP5w9srJz2QpVISxBfndbD4CkXvl(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡇࡊ࡝ࡇࡋࡓࡕ࠳࠰࠵ࡸࡺࠧਣ"))
		XgMyLUkfvP4uKVpQsY8RiWZz6N50O = wpFmEA3z8JR.content
		IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall(FhcnOB9t3frzvXb(u"࠭࠼ࡷ࡫ࡧࡩࡴ࠮࠮ࠫࡁࠬࡀ࠴ࡼࡩࡥࡧࡲࡂࠬਤ"),XgMyLUkfvP4uKVpQsY8RiWZz6N50O,ZXFs0mEPR8qI2zj.DOTALL)
		if IZGcQbePXxwAoyYR1n:
			bdq4e6Wr2gslnSiA38 = IZGcQbePXxwAoyYR1n[kmdSKeBIwViM9t3(u"࠲ဖ")]
			items = ZXFs0mEPR8qI2zj.findall(PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"ࠧࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡴ࡫ࡽࡩࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ਥ"),bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
			for RRucmYBaXegTtNOdGHMQ,PHUqTNVJ0ErRSwibn5gD in items:
				if RRucmYBaXegTtNOdGHMQ not in yf608hE5KeRG1DscunvrU:
					yf608hE5KeRG1DscunvrU.append(RRucmYBaXegTtNOdGHMQ)
					NGmuWwXdLQ6nMltx39FYECohJ = d78KRnJmBWscGua0XMk(RRucmYBaXegTtNOdGHMQ,PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"ࠨࡰࡤࡱࡪ࠭ਦ"))
					AABKVNO3WiMUSe0.append(NGmuWwXdLQ6nMltx39FYECohJ+kRYWcNuAazr4jtmBoxFVS19Z6(u"ࠩࠣࠤࠬਧ")+PHUqTNVJ0ErRSwibn5gD)
			return pEo8g7riWVL014KaRtzQ(u"ࠪࠫਨ"),AABKVNO3WiMUSe0,yf608hE5KeRG1DscunvrU
	elif aFQoGfmYKyqLU6X8libw9k3ncW5(u"ࠫ࠴ࡪ࠯ࠨ਩") in url:
		wpFmEA3z8JR = A6F71g3cqN4(KxirmCLT6Gw,wwyUWMFAsO(u"ࠬࡍࡅࡕࠩਪ"),url,sArCMRngQNmXkBoKv(u"࠭ࠧਫ"),yTMWeCgUROcvtsblfK85L62xPk(u"ࠧࠨਬ"),kRYWcNuAazr4jtmBoxFVS19Z6(u"ࠨࠩਭ"),DLSVmlyBbCK(u"ࠩࠪਮ"),AAgpHN0nMZ(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡅࡈ࡛ࡅࡉࡘ࡚࠱࠮࠴ࡱࡨࠬਯ"))
		XgMyLUkfvP4uKVpQsY8RiWZz6N50O = wpFmEA3z8JR.content
		RRucmYBaXegTtNOdGHMQ = ZXFs0mEPR8qI2zj.findall(xuYvdJpOEyQKTLNwb(u"ࠫࡁ࡯ࡦࡳࡣࡰࡩ࠳࠰࠿ࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬਰ"),XgMyLUkfvP4uKVpQsY8RiWZz6N50O,ZXFs0mEPR8qI2zj.DOTALL)
		if RRucmYBaXegTtNOdGHMQ:
			RRucmYBaXegTtNOdGHMQ = RRucmYBaXegTtNOdGHMQ[JcDaEHuiS8TqBbOhWe4ZgwknoC1L3r(u"࠳ဗ")].replace(XogUJZEijT7KWbxeO6(u"ࠬ࠵࠱࠰ࠩ਱"),hjNP5w9srJz2QpVISxBfndbD4CkXvl(u"࠭࠯࠵࠱ࠪਲ"))
			wpFmEA3z8JR = A6F71g3cqN4(KxirmCLT6Gw,eeIL1TfgFQJaKqVD8hGNPEZ(u"ࠧࡈࡇࡗࠫਲ਼"),RRucmYBaXegTtNOdGHMQ,ffCSGrTJYPsxgVQWKLtHU3iMwB(u"ࠨࠩ਴"),xuYvdJpOEyQKTLNwb(u"ࠩࠪਵ"),JcDaEHuiS8TqBbOhWe4ZgwknoC1L3r(u"ࡇࡣ࡯ࡷࡪᄭ"),kRYWcNuAazr4jtmBoxFVS19Z6(u"ࠪࠫਸ਼"),MM2BQ7xrAfNivgenXPytGYOs0DEHRC(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡆࡉ࡜ࡆࡊ࡙ࡔ࠲࠯࠶ࡶࡩ࠭਷"))
			XgMyLUkfvP4uKVpQsY8RiWZz6N50O = wpFmEA3z8JR.content
			RRucmYBaXegTtNOdGHMQ = ZXFs0mEPR8qI2zj.findall(Ej67fFyoqW8kbV2HdSK(u"ࠬࡩ࡬ࡢࡵࡶ࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠬਸ"),XgMyLUkfvP4uKVpQsY8RiWZz6N50O,ZXFs0mEPR8qI2zj.DOTALL)
			if RRucmYBaXegTtNOdGHMQ: return hjNP5w9srJz2QpVISxBfndbD4CkXvl(u"࠭ࡎࡆࡇࡇࡣࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩਹ"),[sArCMRngQNmXkBoKv(u"ࠧࠨ਺")],[RRucmYBaXegTtNOdGHMQ[sArCMRngQNmXkBoKv(u"࠴ဘ")]]
	elif XogUJZEijT7KWbxeO6(u"ࠨ࠱ࡵࡳࡱ࡫࠯ࠨ਻") in url:
		headers = {gSmqZU0plur2xKPJwQA(u"ࠩࡕࡩ࡫࡫ࡲࡦࡴ਼ࠪ"):qBKDxcalp4QdXitguWhSHwo2Zy9E}
		wpFmEA3z8JR = A6F71g3cqN4(dALVaOWB4jKN3Tbt0Cm1ns9k5u,J3OCAmZVcn(u"ࠪࡋࡊ࡚ࠧ਽"),url,JMLhEyaBWmskovGHTrVCxQ08(u"ࠫࠬਾ"),headers,jYaM5vilgZdFx6QHbApwVXO8et(u"ࡈࡤࡰࡸ࡫ᄮ"),eeIL1TfgFQJaKqVD8hGNPEZ(u"ࠬ࠭ਿ"),eeIL1TfgFQJaKqVD8hGNPEZ(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡈࡋ࡞ࡈࡅࡔࡖ࠴࠱࠹ࡺࡨࠨੀ"))
		RRucmYBaXegTtNOdGHMQ = wpFmEA3z8JR.headers[xuYvdJpOEyQKTLNwb(u"ࠧࡍࡱࡦࡥࡹ࡯࡯࡯ࠩੁ")]
		wpFmEA3z8JR = A6F71g3cqN4(dALVaOWB4jKN3Tbt0Cm1ns9k5u,PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"ࠨࡉࡈࡘࠬੂ"),RRucmYBaXegTtNOdGHMQ,JMLhEyaBWmskovGHTrVCxQ08(u"ࠩࠪ੃"),PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"ࠪࠫ੄"),LmcNhzY6fQPd2JyCGslkSr(u"ࠫࠬ੅"),JMLhEyaBWmskovGHTrVCxQ08(u"ࠬ࠭੆"),J3OCAmZVcn(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡈࡋ࡞ࡈࡅࡔࡖ࠴࠱࠺ࡺࡨࠨੇ"))
		QstumvzTIEUMXCcx06aD4y8nSqH = wpFmEA3z8JR.content
		svA3Xnq5GbkTcZPHd,AABKVNO3WiMUSe0,yf608hE5KeRG1DscunvrU = PmCNXaShAy0RI1rxVDHnvMikQcOj(RRucmYBaXegTtNOdGHMQ,QstumvzTIEUMXCcx06aD4y8nSqH)
		return svA3Xnq5GbkTcZPHd,AABKVNO3WiMUSe0,yf608hE5KeRG1DscunvrU
	elif ZSJVq5XDrRot(u"ࠧ࠰ࡦࡲࡻࡳࡲ࡯ࡢࡦ࠲ࠫੈ") in url:
		lQHXdV9Nzf6BLqS8D = url.replace(MM2BQ7xrAfNivgenXPytGYOs0DEHRC(u"ࠨ࠱ࡧࡳࡼࡴ࡬ࡰࡣࡧ࠳ࠬ੉"),bdhQDyjm3nPwToFHkprvCzBLUGR(u"ࠩ࠲ࡷࡨࡸࡩࡱࡶ࠲ࠫ੊"))
		obS4TpHeV3digGC = {bdhQDyjm3nPwToFHkprvCzBLUGR(u"ࠪࡖࡪ࡬ࡥࡳࡧࡵࠫੋ"):qBKDxcalp4QdXitguWhSHwo2Zy9E}
		wpFmEA3z8JR = A6F71g3cqN4(dALVaOWB4jKN3Tbt0Cm1ns9k5u,Ej67fFyoqW8kbV2HdSK(u"ࠫࡌࡋࡔࠨੌ"),lQHXdV9Nzf6BLqS8D,ZSJVq5XDrRot(u"੍ࠬ࠭"),obS4TpHeV3digGC,Ej67fFyoqW8kbV2HdSK(u"ࡉࡥࡱࡹࡥᄯ"),ffCSGrTJYPsxgVQWKLtHU3iMwB(u"࠭ࠧ੎"),gSmqZU0plur2xKPJwQA(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡉࡌ࡟ࡂࡆࡕࡗ࠵࠲࠼ࡴࡩࠩ੏"))
		QstumvzTIEUMXCcx06aD4y8nSqH = wpFmEA3z8JR.content
		RRucmYBaXegTtNOdGHMQ = ZXFs0mEPR8qI2zj.findall(hjNP5w9srJz2QpVISxBfndbD4CkXvl(u"ࠨ࠾࡬ࡪࡷࡧ࡭ࡦ࠰࠭ࡃࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ੐"),QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
		if RRucmYBaXegTtNOdGHMQ:
			RRucmYBaXegTtNOdGHMQ = RRucmYBaXegTtNOdGHMQ[JMLhEyaBWmskovGHTrVCxQ08(u"࠵မ")]
			wpFmEA3z8JR = A6F71g3cqN4(dALVaOWB4jKN3Tbt0Cm1ns9k5u,kRYWcNuAazr4jtmBoxFVS19Z6(u"ࠩࡊࡉ࡙࠭ੑ"),RRucmYBaXegTtNOdGHMQ,AAgpHN0nMZ(u"ࠪࠫ੒"),obS4TpHeV3digGC,kmdSKeBIwViM9t3(u"ࡊࡦࡲࡳࡦᄰ"),JMLhEyaBWmskovGHTrVCxQ08(u"ࠫࠬ੓"),XogUJZEijT7KWbxeO6(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡇࡊ࡝ࡇࡋࡓࡕ࠳࠰࠻ࡹ࡮ࠧ੔"))
			QstumvzTIEUMXCcx06aD4y8nSqH = wpFmEA3z8JR.content
			if J3OCAmZVcn(u"࠭ࡌࡰࡥࡤࡸ࡮ࡵ࡮ࠨ੕") in list(wpFmEA3z8JR.headers.keys()):
				RRucmYBaXegTtNOdGHMQ = wpFmEA3z8JR.headers[JcDaEHuiS8TqBbOhWe4ZgwknoC1L3r(u"ࠧࡍࡱࡦࡥࡹ࡯࡯࡯ࠩ੖")]
				wpFmEA3z8JR = A6F71g3cqN4(dALVaOWB4jKN3Tbt0Cm1ns9k5u,eeIL1TfgFQJaKqVD8hGNPEZ(u"ࠨࡉࡈࡘࠬ੗"),RRucmYBaXegTtNOdGHMQ,hjNP5w9srJz2QpVISxBfndbD4CkXvl(u"ࠩࠪ੘"),obS4TpHeV3digGC,fR68jBGWCzUsFXdlTKPOScugm(u"ࡋࡧ࡬ࡴࡧᄱ"),hjNP5w9srJz2QpVISxBfndbD4CkXvl(u"ࠪࠫਖ਼"),JcDaEHuiS8TqBbOhWe4ZgwknoC1L3r(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡆࡉ࡜ࡆࡊ࡙ࡔ࠲࠯࠻ࡸ࡭࠭ਗ਼"))
				QstumvzTIEUMXCcx06aD4y8nSqH = wpFmEA3z8JR.content
				svA3Xnq5GbkTcZPHd,AABKVNO3WiMUSe0,yf608hE5KeRG1DscunvrU = PmCNXaShAy0RI1rxVDHnvMikQcOj(RRucmYBaXegTtNOdGHMQ,QstumvzTIEUMXCcx06aD4y8nSqH)
				if yf608hE5KeRG1DscunvrU: return svA3Xnq5GbkTcZPHd,AABKVNO3WiMUSe0,yf608hE5KeRG1DscunvrU
			elif MM2BQ7xrAfNivgenXPytGYOs0DEHRC(u"ࠬ࠵ࡥ࡮ࡤࡨࡨ࠳ࡶࡨࡱࡁ࡬ࡨࡂ࠭ਜ਼") in RRucmYBaXegTtNOdGHMQ:
				RRucmYBaXegTtNOdGHMQ = RRucmYBaXegTtNOdGHMQ.replace(aVLSn1xw5cK(u"࠭࠯ࡦ࡯ࡥࡩࡩ࠴ࡰࡩࡲࡂ࡭ࡩࡃࠧੜ"),pEo8g7riWVL014KaRtzQ(u"ࠧ࠰࡬ࡺࡴࡱࡧࡹࡦࡴ࠱ࡴ࡭ࡶ࠿ࡪࡦࡀࠫ੝"))
				return PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"ࠨࡐࡈࡉࡉࡥࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫਫ਼"),[Ej67fFyoqW8kbV2HdSK(u"ࠩࠪ੟")],[RRucmYBaXegTtNOdGHMQ]
	else: return m6b7CoBk4EQ(u"ࠪࡒࡊࡋࡄࡠࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭੠"),[EDPaWgMt1SwNn8o(u"ࠫࠬ੡")],[url]
	return yTMWeCgUROcvtsblfK85L62xPk(u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡆࡉ࡜ࡆࡊ࡙ࡔ࠲ࠩ੢"),[],[]
def KK7JZeE4GP(url):
	wpFmEA3z8JR = A6F71g3cqN4(KxirmCLT6Gw,LmcNhzY6fQPd2JyCGslkSr(u"࠭ࡇࡆࡖࠪ੣"),url,jYaM5vilgZdFx6QHbApwVXO8et(u"ࠧࠨ੤"),jYaM5vilgZdFx6QHbApwVXO8et(u"ࠨࠩ੥"),JcDaEHuiS8TqBbOhWe4ZgwknoC1L3r(u"ࠩࠪ੦"),xuYvdJpOEyQKTLNwb(u"ࠪࠫ੧"),Ej67fFyoqW8kbV2HdSK(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡆࡉ࡜ࡆࡊ࡙ࡔ࠴࠯࠴ࡷࡹ࠭੨"))
	QstumvzTIEUMXCcx06aD4y8nSqH = wpFmEA3z8JR.content
	data = ZXFs0mEPR8qI2zj.findall(FhcnOB9t3frzvXb(u"ࠬࠨࡡࡤࡶ࡬ࡳࡳࠨ࠮ࠫࡁࡹࡥࡱࡻࡥ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡻࡧ࡬ࡶࡧࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡶࡢ࡮ࡸࡩࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭੩"),QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	if data:
		GSoJsZ6bBjQ2T47mRWghiOK,id,TmFaqB3ihUJrSejO9YlWX850yd = data[ZSJVq5XDrRot(u"࠶ယ")]
		data = wwyUWMFAsO(u"࠭࡯ࡱ࠿ࠪ੪")+GSoJsZ6bBjQ2T47mRWghiOK+aVLSn1xw5cK(u"ࠧࠧ࡫ࡧࡁࠬ੫")+id+jYaM5vilgZdFx6QHbApwVXO8et(u"ࠨࠨࡩࡲࡦࡳࡥ࠾ࠩ੬")+TmFaqB3ihUJrSejO9YlWX850yd
		headers = {hjNP5w9srJz2QpVISxBfndbD4CkXvl(u"ࠩࡆࡳࡳࡺࡥ࡯ࡶ࠰ࡘࡾࡶࡥࠨ੭"):gSmqZU0plur2xKPJwQA(u"ࠪࡥࡵࡶ࡬ࡪࡥࡤࡸ࡮ࡵ࡮࠰ࡺ࠰ࡻࡼࡽ࠭ࡧࡱࡵࡱ࠲ࡻࡲ࡭ࡧࡱࡧࡴࡪࡥࡥࠩ੮")}
		wpFmEA3z8JR = A6F71g3cqN4(KxirmCLT6Gw,eeIL1TfgFQJaKqVD8hGNPEZ(u"ࠫࡕࡕࡓࡕࠩ੯"),url,data,headers,bdhQDyjm3nPwToFHkprvCzBLUGR(u"ࠬ࠭ੰ"),jYaM5vilgZdFx6QHbApwVXO8et(u"࠭ࠧੱ"),XogUJZEijT7KWbxeO6(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡉࡌ࡟ࡂࡆࡕࡗ࠷࠲࠸࡮ࡥࠩੲ"))
		QstumvzTIEUMXCcx06aD4y8nSqH = wpFmEA3z8JR.content
		RRucmYBaXegTtNOdGHMQ = ZXFs0mEPR8qI2zj.findall(ffCSGrTJYPsxgVQWKLtHU3iMwB(u"ࠨࠤࡵࡩ࡫࡫ࡲࡦࡴࠥࠤࡻࡧ࡬ࡶࡧࡀࠦ࠭࠴ࠪࡀࠫࠥࠫੳ"),QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
		if RRucmYBaXegTtNOdGHMQ: return xuYvdJpOEyQKTLNwb(u"ࠩࡑࡉࡊࡊ࡟ࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬੴ"),[sArCMRngQNmXkBoKv(u"ࠪࠫੵ")],[RRucmYBaXegTtNOdGHMQ[c4QSTnPiWUCjhrLlwGB(u"࠰ရ")]]
	return ffCSGrTJYPsxgVQWKLtHU3iMwB(u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡅࡈ࡛ࡅࡉࡘ࡚࠱ࠨ੶"),[],[]
def foyTwPNklz(url):
	lQHXdV9Nzf6BLqS8D = url.split(ffCSGrTJYPsxgVQWKLtHU3iMwB(u"ࠬࡅ࡮ࡢ࡯ࡨࡨࡂ࠭੷"),gnfv8UtZ3daGqpjzk(u"࠲လ"))[AAgpHN0nMZ(u"࠲ဝ")].strip(xuYvdJpOEyQKTLNwb(u"࠭࠿ࠨ੸")).strip(JMLhEyaBWmskovGHTrVCxQ08(u"ࠧ࠰ࠩ੹")).strip(EDPaWgMt1SwNn8o(u"ࠨࠨࠪ੺"))
	xCLQK8kh39sjyi5DXSZAVeI,YYmyQXglbEewzL3IA2Sd,items,aaIn3XlQKJ6zSfkmjuCyM = [],[],[],xuYvdJpOEyQKTLNwb(u"ࠩࠪ੻")
	headers = { sArCMRngQNmXkBoKv(u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧ੼"):bdhQDyjm3nPwToFHkprvCzBLUGR(u"ࠫࡒࡵࡺࡪ࡮࡯ࡥ࠴࠻࠮࠱࡛ࠢࠫ࡮ࡴࡤࡰࡹࡶࠤࡓ࡚ࠠ࠲࠲࠱࠴ࡀࠦࡗࡪࡰ࠹࠸ࡀࠦࡸ࠷࠶ࠬࠫ੽") }
	wpFmEA3z8JR = A6F71g3cqN4(dALVaOWB4jKN3Tbt0Cm1ns9k5u,sArCMRngQNmXkBoKv(u"ࠬࡍࡅࡕࠩ੾"),lQHXdV9Nzf6BLqS8D,ffCSGrTJYPsxgVQWKLtHU3iMwB(u"࠭ࠧ੿"),headers,pEo8g7riWVL014KaRtzQ(u"࡚ࡲࡶࡧᄲ"),ffCSGrTJYPsxgVQWKLtHU3iMwB(u"ࠧࠨ઀"),jYaM5vilgZdFx6QHbApwVXO8et(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡊࡍ࡙ࡃࡇࡖࡘ࠲࠷ࡳࡵࠩઁ"))
	if bdhQDyjm3nPwToFHkprvCzBLUGR(u"ࠩࡏࡳࡨࡧࡴࡪࡱࡱࠫં") in list(wpFmEA3z8JR.headers.keys()): aaIn3XlQKJ6zSfkmjuCyM = wpFmEA3z8JR.headers[LmcNhzY6fQPd2JyCGslkSr(u"ࠪࡐࡴࡩࡡࡵ࡫ࡲࡲࠬઃ")]
	if XogUJZEijT7KWbxeO6(u"ࠫ࡭ࡺࡴࡱࠩ઄") in aaIn3XlQKJ6zSfkmjuCyM:
		if aFQoGfmYKyqLU6X8libw9k3ncW5(u"ࠬࡥ࡟ࡸࡣࡷࡧ࡭࠭અ") in url: aaIn3XlQKJ6zSfkmjuCyM = aaIn3XlQKJ6zSfkmjuCyM.replace(eeIL1TfgFQJaKqVD8hGNPEZ(u"࠭࠯ࡧ࠱ࠪઆ"),FhcnOB9t3frzvXb(u"ࠧ࠰ࡸ࠲ࠫઇ"))
		LsJhxcAeG2CqPZl0REKtiQkpySf = lQHXdV9Nzf6BLqS8D.split(kmdSKeBIwViM9t3(u"ࠨࡁࡓࡌࡕ࡙ࡉࡅ࠿ࠪઈ"))[c4QSTnPiWUCjhrLlwGB(u"࠴သ")]
		headers = { kmdSKeBIwViM9t3(u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭ઉ"):headers[Ej67fFyoqW8kbV2HdSK(u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧઊ")] , Ej67fFyoqW8kbV2HdSK(u"ࠫࡈࡵ࡯࡬࡫ࡨࠫઋ"):gnfv8UtZ3daGqpjzk(u"ࠬࡖࡈࡑࡕࡌࡈࡂ࠭ઌ")+LsJhxcAeG2CqPZl0REKtiQkpySf }
		wpFmEA3z8JR = A6F71g3cqN4(dALVaOWB4jKN3Tbt0Cm1ns9k5u,JMLhEyaBWmskovGHTrVCxQ08(u"࠭ࡇࡆࡖࠪઍ"),aaIn3XlQKJ6zSfkmjuCyM,kRYWcNuAazr4jtmBoxFVS19Z6(u"ࠧࠨ઎"),headers,LmcNhzY6fQPd2JyCGslkSr(u"ࡆࡢ࡮ࡶࡩᄳ"),gnfv8UtZ3daGqpjzk(u"ࠨࠩએ"),gnfv8UtZ3daGqpjzk(u"ࠩࡈࡋ࡞ࡈࡅࡔࡖ࠰ࡔࡑࡇ࡙࠮࠵ࡵࡨࠬઐ"))
		QstumvzTIEUMXCcx06aD4y8nSqH = wpFmEA3z8JR.content
		if ZSJVq5XDrRot(u"ࠪ࠳࡫࠵ࠧઑ") in aaIn3XlQKJ6zSfkmjuCyM: items = ZXFs0mEPR8qI2zj.findall(bdhQDyjm3nPwToFHkprvCzBLUGR(u"ࠫࡁ࡮࠲࠿࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ઒"),QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
		elif eeIL1TfgFQJaKqVD8hGNPEZ(u"ࠬ࠵ࡶ࠰ࠩઓ") in aaIn3XlQKJ6zSfkmjuCyM: items = ZXFs0mEPR8qI2zj.findall(JMLhEyaBWmskovGHTrVCxQ08(u"࠭ࡩࡥ࠿ࠥࡺ࡮ࡪࡥࡰࠤ࠱࠮ࡄࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪઔ"),QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
		if items: return [],[DLSVmlyBbCK(u"ࠧࠨક")],[ items[J3OCAmZVcn(u"࠴ဟ")] ]
		elif DLSVmlyBbCK(u"ࠨ࠾࡫࠵ࡃ࠺࠰࠵࠾࠲࡬࠶ࡄࠧખ") in QstumvzTIEUMXCcx06aD4y8nSqH:
			return J3OCAmZVcn(u"ࠩࡈࡶࡷࡵࡲ࠻ࠢึ๎ึ็ัࠡษ็ๅ๏ี๊้ࠢไ๎์ࠦออสฺࠣิࠦใ้ัํࠤํ๋ีะำ๊ࠤ๊์ࠠศๆศ๊ฯืๆหࠢส่ำอีสࠢห็ࠬગ"),[],[]
	else: return hjNP5w9srJz2QpVISxBfndbD4CkXvl(u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨࠥࡋࡇ࡚ࡄࡈࡗ࡙࠭ઘ"),[],[]
def NpYuwRIMtG(RRucmYBaXegTtNOdGHMQ):
	mcEHCT3jSM = ZXFs0mEPR8qI2zj.findall(ZSJVq5XDrRot(u"ࠫࡵࡵࡳࡵ࡫ࡧࡁ࠭࠴ࠪࡀࠫࠩࡷࡪࡸࡶࡦࡴ࡬ࡨࡂ࠮࠮ࠫࡁࠬࠪࠫ࠭ઙ"),RRucmYBaXegTtNOdGHMQ+jYaM5vilgZdFx6QHbApwVXO8et(u"ࠬࠬࠦࠨચ"),ZXFs0mEPR8qI2zj.DOTALL|ZXFs0mEPR8qI2zj.IGNORECASE)
	mnt96JHiPpI,uu2AypHEw6lW = mcEHCT3jSM[LmcNhzY6fQPd2JyCGslkSr(u"࠵ဠ")]
	url = XogUJZEijT7KWbxeO6(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡴࡧࡵ࡭ࡪࡹ࠴ࡸࡣࡷࡧ࡭࠴࡮ࡦࡶ࠲ࡥ࡯ࡧࡸࡄࡧࡱࡸࡪࡸ࠿ࡠࡣࡦࡸ࡮ࡵ࡮࠾ࡩࡨࡸࡸ࡫ࡲࡷࡧࡵࠪࡤࡶ࡯ࡴࡶࡢ࡭ࡩࡃࠧછ")+mnt96JHiPpI+bdhQDyjm3nPwToFHkprvCzBLUGR(u"ࠧࠧࡵࡨࡶࡻ࡫ࡲࡪࡦࡀࠫજ")+uu2AypHEw6lW
	headers = { m6b7CoBk4EQ(u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬઝ"):OVmSuf8tpd(u"ࠩࠪઞ") , MM2BQ7xrAfNivgenXPytGYOs0DEHRC(u"ࠪ࡜࠲ࡘࡥࡲࡷࡨࡷࡹ࡫ࡤ࠮࡙࡬ࡸ࡭࠭ટ"):MM2BQ7xrAfNivgenXPytGYOs0DEHRC(u"ࠫ࡝ࡓࡌࡉࡶࡷࡴࡗ࡫ࡱࡶࡧࡶࡸࠬઠ") }
	lQHXdV9Nzf6BLqS8D = QuWA3hsmIvockZDiy2rLg(dALVaOWB4jKN3Tbt0Cm1ns9k5u,url,EDPaWgMt1SwNn8o(u"ࠬ࠭ડ"),headers,J3OCAmZVcn(u"࠭ࠧઢ"),J3OCAmZVcn(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡗࡊࡘࡉࡆࡕ࠷࡛ࡆ࡚ࡃࡉ࠯࠴ࡷࡹ࠭ણ"))
	return MM2BQ7xrAfNivgenXPytGYOs0DEHRC(u"ࠨࡐࡈࡉࡉࡥࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫત"),[PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"ࠩࠪથ")],[lQHXdV9Nzf6BLqS8D]
def z8zlcAXu7D(url):
	NGmuWwXdLQ6nMltx39FYECohJ = d78KRnJmBWscGua0XMk(url,xuYvdJpOEyQKTLNwb(u"ࠪࡹࡷࡲࠧદ"))
	obS4TpHeV3digGC = {J3OCAmZVcn(u"ࠫࡗ࡫ࡦࡦࡴࡨࡶࠬધ"):NGmuWwXdLQ6nMltx39FYECohJ,pEo8g7riWVL014KaRtzQ(u"ࠬࡇࡣࡤࡧࡳࡸ࠲ࡋ࡮ࡤࡱࡧ࡭ࡳ࡭ࠧન"):kRYWcNuAazr4jtmBoxFVS19Z6(u"࠭ࡧࡻ࡫ࡳ࠰ࠥࡪࡥࡧ࡮ࡤࡸࡪ࠭઩")}
	wpFmEA3z8JR = A6F71g3cqN4(RwhaLmQ4cpyvfxsPUJVA0DtM,XogUJZEijT7KWbxeO6(u"ࠧࡈࡇࡗࠫપ"),url,aFQoGfmYKyqLU6X8libw9k3ncW5(u"ࠨࠩફ"),obS4TpHeV3digGC,Ej67fFyoqW8kbV2HdSK(u"ࠩࠪબ"),c4QSTnPiWUCjhrLlwGB(u"ࠪࠫભ"),MM2BQ7xrAfNivgenXPytGYOs0DEHRC(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡎ࡛ࡆࡍࡒࡇ࠭࠲ࡵࡷࠫમ"))
	QstumvzTIEUMXCcx06aD4y8nSqH = wpFmEA3z8JR.content
	IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall(gSmqZU0plur2xKPJwQA(u"ࠬࡶ࡬ࡢࡻࡨࡶ࠳ࡷࡵࡢ࡮࡬ࡸࡾࡹࡥ࡭ࡧࡦࡸࡴࡸࠨ࠯ࠬࡂ࠭࡫ࡵࡲ࡮ࡣࡷࡷ࠿࠭ય"),QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	lQHXdV9Nzf6BLqS8D = OVmSuf8tpd(u"࠭ࠧર")
	if IZGcQbePXxwAoyYR1n:
		bdq4e6Wr2gslnSiA38 = IZGcQbePXxwAoyYR1n[PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"࠶အ")]
		items = ZXFs0mEPR8qI2zj.findall(yTMWeCgUROcvtsblfK85L62xPk(u"ࠧࡧࡱࡵࡱࡦࡺ࠺ࠡ࡞ࠪࠬࡡࡪ࠮ࠫࡁࠬࡠࠬ࠲ࠠࡴࡴࡦ࠾ࠥࠨࠨ࠯ࠬࡂ࠭ࠧ࠭઱"),bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
		xCLQK8kh39sjyi5DXSZAVeI,YYmyQXglbEewzL3IA2Sd = [],[]
		for title,RRucmYBaXegTtNOdGHMQ in items:
			xCLQK8kh39sjyi5DXSZAVeI.append(title)
			YYmyQXglbEewzL3IA2Sd.append(RRucmYBaXegTtNOdGHMQ)
		if len(YYmyQXglbEewzL3IA2Sd)==aFQoGfmYKyqLU6X8libw9k3ncW5(u"࠱ဢ"): lQHXdV9Nzf6BLqS8D = YYmyQXglbEewzL3IA2Sd[jYaM5vilgZdFx6QHbApwVXO8et(u"࠱ဣ")]
		elif len(YYmyQXglbEewzL3IA2Sd)>JMLhEyaBWmskovGHTrVCxQ08(u"࠳ဤ"):
			jQ6w8xOrgYhSHIRpUqzL = F2yZPukcUh09sqCI8nYw7e(XogUJZEijT7KWbxeO6(u"ࠨลัฮึࠦวๅ็็ๅࠥอไๆ่สือ࠭લ"), xCLQK8kh39sjyi5DXSZAVeI)
			if jQ6w8xOrgYhSHIRpUqzL==-MM2BQ7xrAfNivgenXPytGYOs0DEHRC(u"࠴ဥ"): return m6b7CoBk4EQ(u"ࠩࠪળ"),[],[]
			lQHXdV9Nzf6BLqS8D = YYmyQXglbEewzL3IA2Sd[jQ6w8xOrgYhSHIRpUqzL]
	else:
		IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall(jYaM5vilgZdFx6QHbApwVXO8et(u"ࠪࡷࡴࡻࡲࡤࡧࠣࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ઴"),QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
		if IZGcQbePXxwAoyYR1n: lQHXdV9Nzf6BLqS8D = IZGcQbePXxwAoyYR1n[ffCSGrTJYPsxgVQWKLtHU3iMwB(u"࠴ဦ")]
	if not lQHXdV9Nzf6BLqS8D: return JcDaEHuiS8TqBbOhWe4ZgwknoC1L3r(u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡍ࡚ࡅࡌࡑࡆ࠭વ"),[],[]
	return pEo8g7riWVL014KaRtzQ(u"ࠬࡔࡅࡆࡆࡢࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨશ"),[gnfv8UtZ3daGqpjzk(u"࠭ࠧષ")],[lQHXdV9Nzf6BLqS8D]
def GAOBVmq23j(url):
	NGmuWwXdLQ6nMltx39FYECohJ = d78KRnJmBWscGua0XMk(url,AAgpHN0nMZ(u"ࠧࡶࡴ࡯ࠫસ"))
	obS4TpHeV3digGC = {XogUJZEijT7KWbxeO6(u"ࠨࡔࡨࡪࡪࡸࡥࡳࠩહ"):NGmuWwXdLQ6nMltx39FYECohJ,bdhQDyjm3nPwToFHkprvCzBLUGR(u"ࠩࡄࡧࡨ࡫ࡰࡵ࠯ࡈࡲࡨࡵࡤࡪࡰࡪࠫ઺"):gSmqZU0plur2xKPJwQA(u"ࠪ࡫ࡿ࡯ࡰ࠭ࠢࡧࡩ࡫ࡲࡡࡵࡧࠪ઻")}
	wpFmEA3z8JR = A6F71g3cqN4(RwhaLmQ4cpyvfxsPUJVA0DtM,wwyUWMFAsO(u"ࠫࡌࡋࡔࠨ઼"),url,MM2BQ7xrAfNivgenXPytGYOs0DEHRC(u"ࠬ࠭ઽ"),obS4TpHeV3digGC,pEo8g7riWVL014KaRtzQ(u"࠭ࠧા"),gSmqZU0plur2xKPJwQA(u"ࠧࠨિ"),ZSJVq5XDrRot(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱࡜ࡋࡃࡊࡏࡄ࠱࠶ࡹࡴࠨી"))
	QstumvzTIEUMXCcx06aD4y8nSqH = wpFmEA3z8JR.content
	IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall(wwyUWMFAsO(u"ࠩࡳࡰࡦࡿࡥࡳ࠰ࡴࡹࡦࡲࡩࡵࡻࡶࡩࡱ࡫ࡣࡵࡱࡵࠬ࠳࠰࠿ࠪࡨࡲࡶࡲࡧࡴࡴ࠼ࠪુ"),QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	lQHXdV9Nzf6BLqS8D = XogUJZEijT7KWbxeO6(u"ࠪࠫૂ")
	if IZGcQbePXxwAoyYR1n:
		bdq4e6Wr2gslnSiA38 = IZGcQbePXxwAoyYR1n[sArCMRngQNmXkBoKv(u"࠵ဧ")]
		items = ZXFs0mEPR8qI2zj.findall(ZSJVq5XDrRot(u"ࠫ࡫ࡵࡲ࡮ࡣࡷ࠾ࠥࡢࠧࠩ࡞ࡧ࠲࠯ࡅࠩ࡝ࠩ࠯ࠤࡸࡸࡣ࠻ࠢࠥࠬ࠳࠰࠿ࠪࠤࠪૃ"),bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
		xCLQK8kh39sjyi5DXSZAVeI,YYmyQXglbEewzL3IA2Sd = [],[]
		for title,RRucmYBaXegTtNOdGHMQ in items:
			xCLQK8kh39sjyi5DXSZAVeI.append(title)
			YYmyQXglbEewzL3IA2Sd.append(RRucmYBaXegTtNOdGHMQ)
		if len(YYmyQXglbEewzL3IA2Sd)==DLSVmlyBbCK(u"࠷ဨ"): lQHXdV9Nzf6BLqS8D = YYmyQXglbEewzL3IA2Sd[jYaM5vilgZdFx6QHbApwVXO8et(u"࠰ဩ")]
		elif len(YYmyQXglbEewzL3IA2Sd)>wwyUWMFAsO(u"࠲ဪ"):
			jQ6w8xOrgYhSHIRpUqzL = F2yZPukcUh09sqCI8nYw7e(fR68jBGWCzUsFXdlTKPOScugm(u"ࠬษฮหำࠣห้๋ไโࠢส่๊์วิสࠪૄ"), xCLQK8kh39sjyi5DXSZAVeI)
			if jQ6w8xOrgYhSHIRpUqzL==-hjNP5w9srJz2QpVISxBfndbD4CkXvl(u"࠳ါ"): return fR68jBGWCzUsFXdlTKPOScugm(u"࠭ࠧૅ"),[],[]
			lQHXdV9Nzf6BLqS8D = YYmyQXglbEewzL3IA2Sd[jQ6w8xOrgYhSHIRpUqzL]
	if not lQHXdV9Nzf6BLqS8D:
		IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall(JMLhEyaBWmskovGHTrVCxQ08(u"ࠧࡴࡱࡸࡶࡨ࡫ࠠࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ૆"),QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
		if IZGcQbePXxwAoyYR1n: lQHXdV9Nzf6BLqS8D = IZGcQbePXxwAoyYR1n[JcDaEHuiS8TqBbOhWe4ZgwknoC1L3r(u"࠳ာ")]
	if not lQHXdV9Nzf6BLqS8D: return EDPaWgMt1SwNn8o(u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦ࡛ࠣࡊࡉࡉࡎࡃࠪે"),[],[]
	return xuYvdJpOEyQKTLNwb(u"ࠩࡑࡉࡊࡊ࡟ࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬૈ"),[ZSJVq5XDrRot(u"ࠪࠫૉ")],[lQHXdV9Nzf6BLqS8D]
def oV8DHKQf25(RRucmYBaXegTtNOdGHMQ):
	mcEHCT3jSM = ZXFs0mEPR8qI2zj.findall(xuYvdJpOEyQKTLNwb(u"ࠫ࠭࡮ࡴࡵࡲ࠱࠮ࡄ࠯࡜ࡀࡲࡲࡷࡹ࡯ࡤ࠾ࠪ࠱࠮ࡄ࠯ࠦࡴࡧࡵࡺࡪࡸࡩࡥ࠿ࠫ࠲࠯ࡅࠩࠧࠨࠪ૊"),RRucmYBaXegTtNOdGHMQ+yTMWeCgUROcvtsblfK85L62xPk(u"ࠬࠬࠦࠨો"),ZXFs0mEPR8qI2zj.DOTALL)
	url,mnt96JHiPpI,uu2AypHEw6lW = mcEHCT3jSM[gSmqZU0plur2xKPJwQA(u"࠴ိ")]
	data = {sArCMRngQNmXkBoKv(u"࠭ࡰࡰࡵࡷࡣ࡮ࡪࠧૌ"):mnt96JHiPpI,eeIL1TfgFQJaKqVD8hGNPEZ(u"ࠧࡴࡧࡵࡺࡪࡸ્ࠧ"):uu2AypHEw6lW}
	wpFmEA3z8JR = A6F71g3cqN4(Z7uFdWIRv9ybj0,aFQoGfmYKyqLU6X8libw9k3ncW5(u"ࠨࡒࡒࡗ࡙࠭૎"),url,data,Ej67fFyoqW8kbV2HdSK(u"ࠩࠪ૏"),c4QSTnPiWUCjhrLlwGB(u"ࠪࠫૐ"),FhcnOB9t3frzvXb(u"ࠫࠬ૑"),Ej67fFyoqW8kbV2HdSK(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡃࡎࡓࡆࡓࡃࡂࡏ࠰࠵ࡸࡺࠧ૒"))
	QstumvzTIEUMXCcx06aD4y8nSqH = wpFmEA3z8JR.content
	lQHXdV9Nzf6BLqS8D = ZXFs0mEPR8qI2zj.findall(wwyUWMFAsO(u"࠭ࡩࡧࡴࡤࡱࡪࠦࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ૓"),QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)[DLSVmlyBbCK(u"࠵ီ")]
	return DLSVmlyBbCK(u"ࠧࡏࡇࡈࡈࡤࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪ૔"),[JcDaEHuiS8TqBbOhWe4ZgwknoC1L3r(u"ࠨࠩ૕")],[lQHXdV9Nzf6BLqS8D]
def zeHi9kbLcZ(url):
	wpFmEA3z8JR = A6F71g3cqN4(Z7uFdWIRv9ybj0,bdhQDyjm3nPwToFHkprvCzBLUGR(u"ࠩࡊࡉ࡙࠭૖"),url,EDPaWgMt1SwNn8o(u"ࠪࠫ૗"),XogUJZEijT7KWbxeO6(u"ࠫࠬ૘"),DLSVmlyBbCK(u"ࠬ࠭૙"),EDPaWgMt1SwNn8o(u"࠭ࠧ૚"),PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡇࡎࡓࡁࡍࡋࡊࡌ࡙࠳࠱ࡴࡶࠪ૛"))
	QstumvzTIEUMXCcx06aD4y8nSqH = wpFmEA3z8JR.content
	RRucmYBaXegTtNOdGHMQ = ZXFs0mEPR8qI2zj.findall(DLSVmlyBbCK(u"ࠨ࠾࡬ࡪࡷࡧ࡭ࡦ࠰࠭ࡃࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ૜"),QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	if RRucmYBaXegTtNOdGHMQ:
		RRucmYBaXegTtNOdGHMQ = RRucmYBaXegTtNOdGHMQ[FhcnOB9t3frzvXb(u"࠶ု")]
		if RRucmYBaXegTtNOdGHMQ: return XogUJZEijT7KWbxeO6(u"ࠩࡑࡉࡊࡊ࡟ࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬ૝"),[ZSJVq5XDrRot(u"ࠪࠫ૞")],[RRucmYBaXegTtNOdGHMQ]
	return JMLhEyaBWmskovGHTrVCxQ08(u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡃࡊࡏࡄࡐࡎࡍࡈࡕࠩ૟"),[],[]
def Ea7O1mGSgv(url):
	wpFmEA3z8JR = A6F71g3cqN4(Z7uFdWIRv9ybj0,gnfv8UtZ3daGqpjzk(u"ࠬࡍࡅࡕࠩૠ"),url,pEo8g7riWVL014KaRtzQ(u"࠭ࠧૡ"),kRYWcNuAazr4jtmBoxFVS19Z6(u"ࠧࠨૢ"),kmdSKeBIwViM9t3(u"ࠨࠩૣ"),PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"ࠩࠪ૤"),kmdSKeBIwViM9t3(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡃࡊࡏࡄࡇࡑ࡛ࡐ࠮࠳ࡶࡸࠬ૥"))
	QstumvzTIEUMXCcx06aD4y8nSqH = wpFmEA3z8JR.content
	RRucmYBaXegTtNOdGHMQ = ZXFs0mEPR8qI2zj.findall(xuYvdJpOEyQKTLNwb(u"ࠫࡁࡏࡆࡓࡃࡐࡉ࡙ࠥࡒࡄ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ૦"),QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)[DLSVmlyBbCK(u"࠰ူ")]
	return eeIL1TfgFQJaKqVD8hGNPEZ(u"ࠬࡔࡅࡆࡆࡢࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨ૧"),[c4QSTnPiWUCjhrLlwGB(u"࠭ࠧ૨")],[RRucmYBaXegTtNOdGHMQ]
def iNwU014Zu7(url):
	ZFcjgy5Kb1GuRlmeCqY0vT = d78KRnJmBWscGua0XMk(url,eeIL1TfgFQJaKqVD8hGNPEZ(u"ࠧࡶࡴ࡯ࠫ૩"))
	if gSmqZU0plur2xKPJwQA(u"ࠨ࡫ࡱࡨࡪࡾ࠽ࠨ૪") in url:
		headers = {ZSJVq5XDrRot(u"ࠩࡕࡩ࡫࡫ࡲࡦࡴࠪ૫"):ZFcjgy5Kb1GuRlmeCqY0vT}
		wpFmEA3z8JR = A6F71g3cqN4(Z7uFdWIRv9ybj0,gnfv8UtZ3daGqpjzk(u"ࠪࡋࡊ࡚ࠧ૬"),url,wwyUWMFAsO(u"ࠫࠬ૭"),headers,EDPaWgMt1SwNn8o(u"ࠬ࠭૮"),AAgpHN0nMZ(u"࠭ࠧ૯"),aFQoGfmYKyqLU6X8libw9k3ncW5(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡇࡎࡓࡁࡏࡑ࡚࠱࠶ࡹࡴࠨ૰"))
		QstumvzTIEUMXCcx06aD4y8nSqH = wpFmEA3z8JR.content
		lQHXdV9Nzf6BLqS8D = ZXFs0mEPR8qI2zj.findall(kRYWcNuAazr4jtmBoxFVS19Z6(u"ࠨࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭૱"),QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
		if lQHXdV9Nzf6BLqS8D:
			lQHXdV9Nzf6BLqS8D = lQHXdV9Nzf6BLqS8D[J3OCAmZVcn(u"࠱ေ")]
			if AAgpHN0nMZ(u"ࠩ࡫ࡸࡹࡶࠧ૲") not in lQHXdV9Nzf6BLqS8D: lQHXdV9Nzf6BLqS8D = OVmSuf8tpd(u"ࠪ࡬ࡹࡺࡰ࠻ࠩ૳")+lQHXdV9Nzf6BLqS8D
			if eeIL1TfgFQJaKqVD8hGNPEZ(u"ࠫࡨ࡯࡭ࡢࡰࡲࡻࠬ૴") in lQHXdV9Nzf6BLqS8D:
				lQHXdV9Nzf6BLqS8D = lQHXdV9Nzf6BLqS8D.replace(pEo8g7riWVL014KaRtzQ(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࠧ૵"),J3OCAmZVcn(u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࠧ૶"))
				wpFmEA3z8JR = A6F71g3cqN4(Z7uFdWIRv9ybj0,yTMWeCgUROcvtsblfK85L62xPk(u"ࠧࡈࡇࡗࠫ૷"),lQHXdV9Nzf6BLqS8D,wwyUWMFAsO(u"ࠨࠩ૸"),headers,JcDaEHuiS8TqBbOhWe4ZgwknoC1L3r(u"ࠩࠪૹ"),XogUJZEijT7KWbxeO6(u"ࠪࠫૺ"),MM2BQ7xrAfNivgenXPytGYOs0DEHRC(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡄࡋࡐࡅࡓࡕࡗ࠮࠴ࡱࡨࠬૻ"))
				XgMyLUkfvP4uKVpQsY8RiWZz6N50O = wpFmEA3z8JR.content
				items = ZXFs0mEPR8qI2zj.findall(EDPaWgMt1SwNn8o(u"ࠬࡹ࡯ࡶࡴࡦࡩࠥࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡹࡩࡻࡧࡀࠦ࠭࠴ࠪࡀࠫࠥࠫૼ"),XgMyLUkfvP4uKVpQsY8RiWZz6N50O,ZXFs0mEPR8qI2zj.DOTALL)
				xCLQK8kh39sjyi5DXSZAVeI,YYmyQXglbEewzL3IA2Sd = [],[]
				SSybMXta8gxTFKrUZDwNLWPcoHfEQ = d78KRnJmBWscGua0XMk(lQHXdV9Nzf6BLqS8D,hjNP5w9srJz2QpVISxBfndbD4CkXvl(u"࠭ࡵࡳ࡮ࠪ૽"))
				for RRucmYBaXegTtNOdGHMQ,PHUqTNVJ0ErRSwibn5gD in reversed(items):
					RRucmYBaXegTtNOdGHMQ = SSybMXta8gxTFKrUZDwNLWPcoHfEQ+RRucmYBaXegTtNOdGHMQ+XogUJZEijT7KWbxeO6(u"ࠧࡽࡔࡨࡪࡪࡸࡥࡳ࠿ࠪ૾")+SSybMXta8gxTFKrUZDwNLWPcoHfEQ
					xCLQK8kh39sjyi5DXSZAVeI.append(PHUqTNVJ0ErRSwibn5gD)
					YYmyQXglbEewzL3IA2Sd.append(RRucmYBaXegTtNOdGHMQ)
				return LmcNhzY6fQPd2JyCGslkSr(u"ࠨࠩ૿"),xCLQK8kh39sjyi5DXSZAVeI,YYmyQXglbEewzL3IA2Sd
			else: return pEo8g7riWVL014KaRtzQ(u"ࠩࡑࡉࡊࡊ࡟ࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬ଀"),[fR68jBGWCzUsFXdlTKPOScugm(u"ࠪࠫଁ")],[lQHXdV9Nzf6BLqS8D]
	lQHXdV9Nzf6BLqS8D = url+m6b7CoBk4EQ(u"ࠫࢁࡘࡥࡧࡧࡵࡩࡷࡃࠧଂ")+ZFcjgy5Kb1GuRlmeCqY0vT
	if EDPaWgMt1SwNn8o(u"ࠬ࡮ࡴࡵࡲࠪଃ") not in lQHXdV9Nzf6BLqS8D: lQHXdV9Nzf6BLqS8D = sArCMRngQNmXkBoKv(u"࠭ࡨࡵࡶࡳ࠾ࠬ଄")+lQHXdV9Nzf6BLqS8D
	return Ej67fFyoqW8kbV2HdSK(u"ࠧࠨଅ"),[hjNP5w9srJz2QpVISxBfndbD4CkXvl(u"ࠨࠩଆ")],[lQHXdV9Nzf6BLqS8D]
def C03Ya8L1dPr5k2ER4XtI(RRucmYBaXegTtNOdGHMQ):
	ZFcjgy5Kb1GuRlmeCqY0vT = d78KRnJmBWscGua0XMk(RRucmYBaXegTtNOdGHMQ,LmcNhzY6fQPd2JyCGslkSr(u"ࠩࡸࡶࡱ࠭ଇ"))
	if EDPaWgMt1SwNn8o(u"ࠪࡴࡴࡹࡴࡪࡦࠪଈ") in RRucmYBaXegTtNOdGHMQ:
		mcEHCT3jSM = ZXFs0mEPR8qI2zj.findall(OVmSuf8tpd(u"ࠫ࠭࡮ࡴࡵࡲ࠱࠮ࡄ࠯࡜ࡀࡲࡲࡷࡹ࡯ࡤ࠾ࠪ࠱࠮ࡄ࠯ࠦࡴࡧࡵࡺࡪࡸࡩࡥ࠿ࠫ࠲࠯ࡅࠩࠧࠨࠪଉ"),RRucmYBaXegTtNOdGHMQ+hjNP5w9srJz2QpVISxBfndbD4CkXvl(u"ࠬࠬࠦࠨଊ"),ZXFs0mEPR8qI2zj.DOTALL)
		url,mnt96JHiPpI,uu2AypHEw6lW = mcEHCT3jSM[ZSJVq5XDrRot(u"࠲ဲ")]
		data = {yTMWeCgUROcvtsblfK85L62xPk(u"࠭ࡩࡥࠩଋ"):mnt96JHiPpI,JMLhEyaBWmskovGHTrVCxQ08(u"ࠧࡴࡧࡵࡺࡪࡸࠧଌ"):uu2AypHEw6lW}
		wpFmEA3z8JR = A6F71g3cqN4(Z7uFdWIRv9ybj0,PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"ࠨࡒࡒࡗ࡙࠭଍"),url,data,J3OCAmZVcn(u"ࠩࠪ଎"),ffCSGrTJYPsxgVQWKLtHU3iMwB(u"ࠪࠫଏ"),gSmqZU0plur2xKPJwQA(u"ࠫࠬଐ"),xuYvdJpOEyQKTLNwb(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡅࡌࡑࡆࡔࡏࡘ࠯࠴ࡷࡹ࠭଑"))
		QstumvzTIEUMXCcx06aD4y8nSqH = wpFmEA3z8JR.content
		lQHXdV9Nzf6BLqS8D = ZXFs0mEPR8qI2zj.findall(kmdSKeBIwViM9t3(u"࠭ࡩࡧࡴࡤࡱࡪࠦࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ଒"),QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)[jYaM5vilgZdFx6QHbApwVXO8et(u"࠳ဳ")]
		if ffCSGrTJYPsxgVQWKLtHU3iMwB(u"ࠧࡤ࡫ࡰࡥࡳࡵࡷࠨଓ") in lQHXdV9Nzf6BLqS8D:
			headers = {gSmqZU0plur2xKPJwQA(u"ࠨࡔࡨࡪࡪࡸࡥࡳࠩଔ"):ZFcjgy5Kb1GuRlmeCqY0vT,Ej67fFyoqW8kbV2HdSK(u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭କ"):gSmqZU0plur2xKPJwQA(u"ࠪࠫଖ")}
			wpFmEA3z8JR = A6F71g3cqN4(Z7uFdWIRv9ybj0,xuYvdJpOEyQKTLNwb(u"ࠫࡌࡋࡔࠨଗ"),lQHXdV9Nzf6BLqS8D,jYaM5vilgZdFx6QHbApwVXO8et(u"ࠬ࠭ଘ"),headers,Ej67fFyoqW8kbV2HdSK(u"࠭ࠧଙ"),fR68jBGWCzUsFXdlTKPOScugm(u"ࠧࠨଚ"),aFQoGfmYKyqLU6X8libw9k3ncW5(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡈࡏࡍࡂࡐࡒ࡛࠲࠸࡮ࡥࠩଛ"))
			XgMyLUkfvP4uKVpQsY8RiWZz6N50O = wpFmEA3z8JR.content
			items = ZXFs0mEPR8qI2zj.findall(kRYWcNuAazr4jtmBoxFVS19Z6(u"ࠩࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡶ࡭ࡿ࡫࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨଜ"),XgMyLUkfvP4uKVpQsY8RiWZz6N50O,ZXFs0mEPR8qI2zj.DOTALL)
			xCLQK8kh39sjyi5DXSZAVeI,YYmyQXglbEewzL3IA2Sd = [],[]
			SSybMXta8gxTFKrUZDwNLWPcoHfEQ = d78KRnJmBWscGua0XMk(lQHXdV9Nzf6BLqS8D,kRYWcNuAazr4jtmBoxFVS19Z6(u"ࠪࡹࡷࡲࠧଝ"))
			for RRucmYBaXegTtNOdGHMQ,PHUqTNVJ0ErRSwibn5gD in reversed(items):
				RRucmYBaXegTtNOdGHMQ = SSybMXta8gxTFKrUZDwNLWPcoHfEQ+RRucmYBaXegTtNOdGHMQ+aVLSn1xw5cK(u"ࠫࢁࡘࡥࡧࡧࡵࡩࡷࡃࠧଞ")+SSybMXta8gxTFKrUZDwNLWPcoHfEQ
				xCLQK8kh39sjyi5DXSZAVeI.append(PHUqTNVJ0ErRSwibn5gD)
				YYmyQXglbEewzL3IA2Sd.append(RRucmYBaXegTtNOdGHMQ)
			return FhcnOB9t3frzvXb(u"ࠬ࠭ଟ"),xCLQK8kh39sjyi5DXSZAVeI,YYmyQXglbEewzL3IA2Sd
		else: return bdhQDyjm3nPwToFHkprvCzBLUGR(u"࠭ࡎࡆࡇࡇࡣࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩଠ"),[xuYvdJpOEyQKTLNwb(u"ࠧࠨଡ")],[lQHXdV9Nzf6BLqS8D]
	else:
		RRucmYBaXegTtNOdGHMQ = RRucmYBaXegTtNOdGHMQ+aVLSn1xw5cK(u"ࠨࡾࡕࡩ࡫࡫ࡲࡦࡴࡀࠫଢ")+ZFcjgy5Kb1GuRlmeCqY0vT
		return ZSJVq5XDrRot(u"ࠩࠪଣ"),[pEo8g7riWVL014KaRtzQ(u"ࠪࠫତ")],[RRucmYBaXegTtNOdGHMQ]
def eL6whX7imV(RRucmYBaXegTtNOdGHMQ):
	if hjNP5w9srJz2QpVISxBfndbD4CkXvl(u"ࠫࡵࡵࡳࡵ࡫ࡧࠫଥ") in RRucmYBaXegTtNOdGHMQ:
		mcEHCT3jSM = ZXFs0mEPR8qI2zj.findall(wwyUWMFAsO(u"ࠬࡶ࡯ࡴࡶ࡬ࡨࡂ࠮࠮ࠫࡁࠬࠪࡸ࡫ࡲࡷࡧࡵ࡭ࡩࡃࠨ࠯ࠬࡂ࠭ࠫࠬࠧଦ"),RRucmYBaXegTtNOdGHMQ+c4QSTnPiWUCjhrLlwGB(u"࠭ࠦࠧࠩଧ"),ZXFs0mEPR8qI2zj.DOTALL|ZXFs0mEPR8qI2zj.IGNORECASE)
		mnt96JHiPpI,uu2AypHEw6lW = mcEHCT3jSM[jYaM5vilgZdFx6QHbApwVXO8et(u"࠴ဴ")]
		rTl7PF3UpGNJkiEs6BvCK = d78KRnJmBWscGua0XMk(RRucmYBaXegTtNOdGHMQ,EDPaWgMt1SwNn8o(u"ࠧࡶࡴ࡯ࠫନ"))
		url = rTl7PF3UpGNJkiEs6BvCK+fR68jBGWCzUsFXdlTKPOScugm(u"ࠨ࠱ࡤ࡮ࡦࡾࡃࡦࡰࡷࡩࡷࡅ࡟ࡢࡥࡷ࡭ࡴࡴ࠽ࡨࡧࡷࡷࡪࡸࡶࡦࡴࠩࡣࡵࡵࡳࡵࡡ࡬ࡨࡂ࠭଩")+mnt96JHiPpI+xuYvdJpOEyQKTLNwb(u"ࠩࠩࡷࡪࡸࡶࡦࡴ࡬ࡨࡂ࠭ପ")+uu2AypHEw6lW
		headers = { AAgpHN0nMZ(u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧଫ"):hjNP5w9srJz2QpVISxBfndbD4CkXvl(u"ࠫࠬବ") , XogUJZEijT7KWbxeO6(u"ࠬ࡞࠭ࡓࡧࡴࡹࡪࡹࡴࡦࡦ࠰࡛࡮ࡺࡨࠨଭ"):FhcnOB9t3frzvXb(u"࠭ࡘࡎࡎࡋࡸࡹࡶࡒࡦࡳࡸࡩࡸࡺࠧମ") }
		lQHXdV9Nzf6BLqS8D = QuWA3hsmIvockZDiy2rLg(dALVaOWB4jKN3Tbt0Cm1ns9k5u,url,AAgpHN0nMZ(u"ࠧࠨଯ"),headers,gnfv8UtZ3daGqpjzk(u"ࠨࠩର"),JMLhEyaBWmskovGHTrVCxQ08(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡇࡒࡃࡎࡌࡓࡓࡠ࠭࠲ࡵࡷࠫ଱"))
		lQHXdV9Nzf6BLqS8D = lQHXdV9Nzf6BLqS8D.replace(pEo8g7riWVL014KaRtzQ(u"ࠪࡠࡳ࠭ଲ"),kRYWcNuAazr4jtmBoxFVS19Z6(u"ࠫࠬଳ")).replace(ZSJVq5XDrRot(u"ࠬࡢࡲࠨ଴"),ZSJVq5XDrRot(u"࠭ࠧଵ"))
		return kmdSKeBIwViM9t3(u"ࠧࡏࡇࡈࡈࡤࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪଶ"),[c4QSTnPiWUCjhrLlwGB(u"ࠨࠩଷ")],[lQHXdV9Nzf6BLqS8D]
	elif XogUJZEijT7KWbxeO6(u"ࠩ࠲ࡶࡪࡪࡩࡳࡧࡦࡸ࠴࠭ସ") in RRucmYBaXegTtNOdGHMQ:
		qq3nmoTeXK2t8j4PFZ = aVLSn1xw5cK(u"࠵ဵ")
		while OVmSuf8tpd(u"ࠪ࠳ࡷ࡫ࡤࡪࡴࡨࡧࡹ࠵ࠧହ") in RRucmYBaXegTtNOdGHMQ and qq3nmoTeXK2t8j4PFZ<aVLSn1xw5cK(u"࠻ံ"):
			wpFmEA3z8JR = A6F71g3cqN4(JNsoWV1CXc4xy,aFQoGfmYKyqLU6X8libw9k3ncW5(u"ࠫࡌࡋࡔࠨ଺"),RRucmYBaXegTtNOdGHMQ,wwyUWMFAsO(u"ࠬ࠭଻"),AAgpHN0nMZ(u"଼࠭ࠧ"),EDPaWgMt1SwNn8o(u"ࠧࠨଽ"),ffCSGrTJYPsxgVQWKLtHU3iMwB(u"ࠨࠩା"),wwyUWMFAsO(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡇࡒࡃࡎࡌࡓࡓࡠ࠭࠳ࡰࡧࠫି"))
			if LmcNhzY6fQPd2JyCGslkSr(u"ࠪࡐࡴࡩࡡࡵ࡫ࡲࡲࠬୀ") in list(wpFmEA3z8JR.headers.keys()): RRucmYBaXegTtNOdGHMQ = wpFmEA3z8JR.headers[JMLhEyaBWmskovGHTrVCxQ08(u"ࠫࡑࡵࡣࡢࡶ࡬ࡳࡳ࠭ୁ")]
			qq3nmoTeXK2t8j4PFZ += pEo8g7riWVL014KaRtzQ(u"࠱့")
		return J3OCAmZVcn(u"ࠬ࠭ୂ"),[jYaM5vilgZdFx6QHbApwVXO8et(u"࠭ࠧୃ")],[RRucmYBaXegTtNOdGHMQ]
	else: return AAgpHN0nMZ(u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥࠢࡄࡖࡇࡒࡉࡐࡐ࡝ࠫୄ"),[],[]
def iRzsfUmpP7(url):
	NGmuWwXdLQ6nMltx39FYECohJ = d78KRnJmBWscGua0XMk(url,jYaM5vilgZdFx6QHbApwVXO8et(u"ࠨࡷࡵࡰࠬ୅"))
	headers = {jYaM5vilgZdFx6QHbApwVXO8et(u"ࠩࡕࡩ࡫࡫ࡲࡦࡴࠪ୆"):NGmuWwXdLQ6nMltx39FYECohJ,aVLSn1xw5cK(u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧେ"):SjMG7CYyUqbPVso0DErhXROvkl()}
	if bdhQDyjm3nPwToFHkprvCzBLUGR(u"ࠫ࠴࡫࡭ࡣࡧࡧ࠱ࠬୈ") in url:
		QstumvzTIEUMXCcx06aD4y8nSqH = QuWA3hsmIvockZDiy2rLg(dALVaOWB4jKN3Tbt0Cm1ns9k5u,url,Ej67fFyoqW8kbV2HdSK(u"ࠬ࠭୉"),headers,hjNP5w9srJz2QpVISxBfndbD4CkXvl(u"࠭ࠧ୊"),XogUJZEijT7KWbxeO6(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡅࡗࡇࡂࡔࡇࡈࡈ࠲࠸࡮ࡥࠩୋ"))
		RRucmYBaXegTtNOdGHMQ = ZXFs0mEPR8qI2zj.findall(hjNP5w9srJz2QpVISxBfndbD4CkXvl(u"ࠨ࠾ࡶࡳࡺࡸࡣࡦࠢࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧୌ"),QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
		if RRucmYBaXegTtNOdGHMQ:
			RRucmYBaXegTtNOdGHMQ = RRucmYBaXegTtNOdGHMQ[bdhQDyjm3nPwToFHkprvCzBLUGR(u"࠱း")].replace(gSmqZU0plur2xKPJwQA(u"ࠩ࡫ࡸࡹࡶࡳࠨ୍"),JcDaEHuiS8TqBbOhWe4ZgwknoC1L3r(u"ࠪ࡬ࡹࡺࡰࠨ୎"))
			return kmdSKeBIwViM9t3(u"ࠫࠬ୏"),[JcDaEHuiS8TqBbOhWe4ZgwknoC1L3r(u"ࠬ࠭୐")],[RRucmYBaXegTtNOdGHMQ]
	else:
		IMZHyAV5cmzn = A6F71g3cqN4(JNsoWV1CXc4xy,jYaM5vilgZdFx6QHbApwVXO8et(u"࠭ࡇࡆࡖࠪ୑"),url,ZSJVq5XDrRot(u"ࠧࠨ୒"),headers,DLSVmlyBbCK(u"ࠨࠩ୓"),c4QSTnPiWUCjhrLlwGB(u"ࠩࠪ୔"),eeIL1TfgFQJaKqVD8hGNPEZ(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡁࡓࡃࡅࡗࡊࡋࡄ࠮࠵ࡵࡨࠬ୕"))
		QstumvzTIEUMXCcx06aD4y8nSqH = IMZHyAV5cmzn.content
		obS4TpHeV3digGC = headers.copy()
		if gnfv8UtZ3daGqpjzk(u"ࠫࡤࡲ࡮࡬ࡡࠪୖ") in str(IMZHyAV5cmzn.cookies):
			cookies = IMZHyAV5cmzn.cookies
			obS4TpHeV3digGC[JcDaEHuiS8TqBbOhWe4ZgwknoC1L3r(u"ࠬࡉ࡯ࡰ࡭࡬ࡩࠬୗ")] = ejBOu2WXwvb4YpITdsLF16(XapnozmJWluEb8fdYye0SR6QxqZL(cookies))
		RRucmYBaXegTtNOdGHMQ = ZXFs0mEPR8qI2zj.findall(sArCMRngQNmXkBoKv(u"࠭࡬ࡪࡰ࡮࠲࡭ࡸࡥࡧࠢࡀࠤࠧ࠮ࡨࡵࡶࡳ࠲࠯ࡅࠩࠣࠩ୘"),QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
		if not RRucmYBaXegTtNOdGHMQ: return jYaM5vilgZdFx6QHbApwVXO8et(u"ࠧࡏࡇࡈࡈࡤࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪ୙"),[wwyUWMFAsO(u"ࠨࠩ୚")],[url]
		else:
			RRucmYBaXegTtNOdGHMQ = ejBOu2WXwvb4YpITdsLF16(RRucmYBaXegTtNOdGHMQ[bdhQDyjm3nPwToFHkprvCzBLUGR(u"࠲္")])+c4QSTnPiWUCjhrLlwGB(u"ࠩࠩࡨࡂ࠷ࠧ୛")
			qShkDLtUac9u = A6F71g3cqN4(JNsoWV1CXc4xy,EDPaWgMt1SwNn8o(u"ࠪࡋࡊ࡚ࠧଡ଼"),RRucmYBaXegTtNOdGHMQ,DLSVmlyBbCK(u"ࠫࠬଢ଼"),obS4TpHeV3digGC,PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"ࠬ࠭୞"),AAgpHN0nMZ(u"࠭ࠧୟ"),MM2BQ7xrAfNivgenXPytGYOs0DEHRC(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡅࡗࡇࡂࡔࡇࡈࡈ࠲࠺ࡴࡩࠩୠ"))
			QstumvzTIEUMXCcx06aD4y8nSqH = qShkDLtUac9u.content
			RRucmYBaXegTtNOdGHMQ = ZXFs0mEPR8qI2zj.findall(kRYWcNuAazr4jtmBoxFVS19Z6(u"ࠨ࡫ࡧࡁࠧࡨࡴ࡯ࠤ࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠫୡ"),QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
			if RRucmYBaXegTtNOdGHMQ:
				RRucmYBaXegTtNOdGHMQ = ejBOu2WXwvb4YpITdsLF16(RRucmYBaXegTtNOdGHMQ[LmcNhzY6fQPd2JyCGslkSr(u"࠳်")])
				if OVmSuf8tpd(u"ࠩࡰࡴ࠹࠭ୢ") in RRucmYBaXegTtNOdGHMQ and AAgpHN0nMZ(u"ࠪ࠳ࡩ࠵ࠧୣ") in RRucmYBaXegTtNOdGHMQ: return OVmSuf8tpd(u"ࠫࠬ୤"),[XogUJZEijT7KWbxeO6(u"ࠬ࠭୥")],[RRucmYBaXegTtNOdGHMQ]
				else: return aFQoGfmYKyqLU6X8libw9k3ncW5(u"࠭ࡎࡆࡇࡇࡣࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩ୦"),[PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"ࠧࠨ୧")],[RRucmYBaXegTtNOdGHMQ]
	return kRYWcNuAazr4jtmBoxFVS19Z6(u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦࠣࡅࡗࡇࡂࡔࡇࡈࡈࠬ୨"),[],[]
def epWEGAh8dK(RRucmYBaXegTtNOdGHMQ):
	if c4QSTnPiWUCjhrLlwGB(u"ࠩࡢࡥࡨࡺࡩࡰࡰࡀ࡫ࡪࡺࡳࡦࡴࡹࡩࡷ࠭୩") in RRucmYBaXegTtNOdGHMQ:
		headers = {DLSVmlyBbCK(u"ࠪ࡜࠲ࡘࡥࡲࡷࡨࡷࡹ࡫ࡤ࠮࡙࡬ࡸ࡭࠭୪"):OVmSuf8tpd(u"ࠫ࡝ࡓࡌࡉࡶࡷࡴࡗ࡫ࡱࡶࡧࡶࡸࠬ୫")}
		wpFmEA3z8JR = A6F71g3cqN4(Z7uFdWIRv9ybj0,gnfv8UtZ3daGqpjzk(u"ࠬࡍࡅࡕࠩ୬"),RRucmYBaXegTtNOdGHMQ,gnfv8UtZ3daGqpjzk(u"࠭ࠧ୭"),headers,fR68jBGWCzUsFXdlTKPOScugm(u"ࠧࠨ୮"),m6b7CoBk4EQ(u"ࠨࠩ୯"),gnfv8UtZ3daGqpjzk(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲࡙ࡈࡂࡊࡌࡈ࠹࡛࠭࠲ࡵࡷࠫ୰"))
		url = wpFmEA3z8JR.content
		if url: return J3OCAmZVcn(u"ࠪࡒࡊࡋࡄࡠࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭ୱ"),[eeIL1TfgFQJaKqVD8hGNPEZ(u"ࠫࠬ୲")],[url]
	else:
		mcEHCT3jSM = ZXFs0mEPR8qI2zj.findall(fR68jBGWCzUsFXdlTKPOScugm(u"ࠬࡶ࡯ࡴࡶ࡬ࡨࡂ࠮࠮ࠫࡁࠬࠪࡸ࡫ࡲࡷࡧࡵ࡭ࡩࡃࠨ࠯ࠬࡂ࠭ࠩ࠭୳"),RRucmYBaXegTtNOdGHMQ,ZXFs0mEPR8qI2zj.DOTALL|ZXFs0mEPR8qI2zj.IGNORECASE)
		if not mcEHCT3jSM: mcEHCT3jSM = ZXFs0mEPR8qI2zj.findall(ZSJVq5XDrRot(u"࠭࡟ࡱࡱࡶࡸࡤ࡯ࡤ࠾ࠪ࠱࠮ࡄ࠯ࠦࡴࡧࡵࡺࡪࡸࡩࡥ࠿ࠫ࠲࠯ࡅࠩࠥࠩ୴"),RRucmYBaXegTtNOdGHMQ,ZXFs0mEPR8qI2zj.DOTALL|ZXFs0mEPR8qI2zj.IGNORECASE)
		mnt96JHiPpI,uu2AypHEw6lW = mcEHCT3jSM[EDPaWgMt1SwNn8o(u"࠴ျ")]
		NGmuWwXdLQ6nMltx39FYECohJ = d78KRnJmBWscGua0XMk(RRucmYBaXegTtNOdGHMQ,ffCSGrTJYPsxgVQWKLtHU3iMwB(u"ࠧࡶࡴ࡯ࠫ୵"))
		url = NGmuWwXdLQ6nMltx39FYECohJ+XogUJZEijT7KWbxeO6(u"ࠨ࠱ࡺࡴ࠲ࡩ࡯࡯ࡶࡨࡲࡹ࠵ࡴࡩࡧࡰࡩࡸ࠵ࡴࡩࡧࡰࡩ࠴ࡇࡪࡢࡺࡤࡸ࠴࡙ࡩ࡯ࡩ࡯ࡩ࠴࡙ࡥࡳࡸࡨࡶ࠳ࡶࡨࡱࠩ୶")
		data = {pEo8g7riWVL014KaRtzQ(u"ࠩ࡬ࡨࠬ୷"):mnt96JHiPpI,ZSJVq5XDrRot(u"ࠪ࡭ࠬ୸"):uu2AypHEw6lW}
		headers = {Ej67fFyoqW8kbV2HdSK(u"ࠫ࡝࠳ࡒࡦࡳࡸࡩࡸࡺࡥࡥ࠯࡚࡭ࡹ࡮ࠧ୹"):OVmSuf8tpd(u"ࠬ࡞ࡍࡍࡊࡷࡸࡵࡘࡥࡲࡷࡨࡷࡹ࠭୺"),xuYvdJpOEyQKTLNwb(u"࠭ࡒࡦࡨࡨࡶࡪࡸࠧ୻"):RRucmYBaXegTtNOdGHMQ}
		wpFmEA3z8JR = A6F71g3cqN4(Z7uFdWIRv9ybj0,JcDaEHuiS8TqBbOhWe4ZgwknoC1L3r(u"ࠧࡑࡑࡖࡘࠬ୼"),url,data,headers,pEo8g7riWVL014KaRtzQ(u"ࠨࠩ୽"),xuYvdJpOEyQKTLNwb(u"ࠩࠪ୾"),PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡓࡉࡃࡋࡍࡉ࠺ࡕ࠮࠴ࡱࡨࠬ୿"))
		XgMyLUkfvP4uKVpQsY8RiWZz6N50O = wpFmEA3z8JR.content
		lQHXdV9Nzf6BLqS8D = ZXFs0mEPR8qI2zj.findall(DLSVmlyBbCK(u"ࠫࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ஀"),XgMyLUkfvP4uKVpQsY8RiWZz6N50O,ZXFs0mEPR8qI2zj.DOTALL|ZXFs0mEPR8qI2zj.IGNORECASE)
		if lQHXdV9Nzf6BLqS8D:
			lQHXdV9Nzf6BLqS8D = lQHXdV9Nzf6BLqS8D[PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"࠵ြ")]
			return XogUJZEijT7KWbxeO6(u"ࠬࡔࡅࡆࡆࡢࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨ஁"),[JcDaEHuiS8TqBbOhWe4ZgwknoC1L3r(u"࠭ࠧஂ")],[lQHXdV9Nzf6BLqS8D]
	return eeIL1TfgFQJaKqVD8hGNPEZ(u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥࠢࡖࡌࡆࡎࡉࡅ࠶ࡘࠫஃ"),[],[]
def FWg3peNhl0U(Uuk5EyoaxM):
	MYy3reW74PSXGiBcAN0I6fHpoO5zn = j2agIU0xsLS6c7T.getSetting(MM2BQ7xrAfNivgenXPytGYOs0DEHRC(u"ࠨࡣࡹ࠲ࡦࡱࡷࡢ࡯࠱ࡺࡪࡸࡩࡧ࡫ࡦࡥࡹ࡯࡯࡯ࠩ஄"))
	headers = {jYaM5vilgZdFx6QHbApwVXO8et(u"ࠩࡆࡳࡴࡱࡩࡦࠩஅ"):MYy3reW74PSXGiBcAN0I6fHpoO5zn} if MYy3reW74PSXGiBcAN0I6fHpoO5zn else sArCMRngQNmXkBoKv(u"ࠪࠫஆ")
	wpFmEA3z8JR = A6F71g3cqN4(JNsoWV1CXc4xy,ffCSGrTJYPsxgVQWKLtHU3iMwB(u"ࠫࡌࡋࡔࠨஇ"),Uuk5EyoaxM,LmcNhzY6fQPd2JyCGslkSr(u"ࠬ࠭ஈ"),headers,MM2BQ7xrAfNivgenXPytGYOs0DEHRC(u"࠭ࠧஉ"),wwyUWMFAsO(u"ࠧࠨஊ"),OVmSuf8tpd(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡇ࡟ࡐࡂࡕࡖࡣࡆࡑࡗࡂࡏࡢࡇࡆࡖࡔࡄࡊࡄ࠱࠶ࡹࡴࠨ஋"))
	grCTKhQGHpt3q = wpFmEA3z8JR.content
	nIGwfpReQZoiOmMH8N = str(wpFmEA3z8JR.headers)
	imuLazAkgXMlO3UxbnQF = nIGwfpReQZoiOmMH8N+grCTKhQGHpt3q
	if yTMWeCgUROcvtsblfK85L62xPk(u"ࠩ࠱ࡱࡵ࠺ࠧ஌") in imuLazAkgXMlO3UxbnQF: CTQlmBkHVz6JioRW = LmcNhzY6fQPd2JyCGslkSr(u"ࡕࡴࡸࡩᄴ")
	else:
		SWVLD3vAMgKwzldm,Yhqjz4bLa1HB,mLx2tKuROfjkSZBzbr7TC,FF1VHRywMLz,CTQlmBkHVz6JioRW = yTMWeCgUROcvtsblfK85L62xPk(u"ࠪࠫ஍"),ZSJVq5XDrRot(u"ࠫࠬஎ"),ffCSGrTJYPsxgVQWKLtHU3iMwB(u"ࠬ࠭ஏ"),gSmqZU0plur2xKPJwQA(u"࠭ࠧஐ"),eeIL1TfgFQJaKqVD8hGNPEZ(u"ࡈࡤࡰࡸ࡫ᄵ")
		captcha = ZXFs0mEPR8qI2zj.findall(eeIL1TfgFQJaKqVD8hGNPEZ(u"ࠧࡱࡣࡪࡩ࠲ࡸࡥࡥ࡫ࡵࡩࡨࡺ࠮ࠫࡁࡤࡧࡹ࡯࡯࡯࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡪࡡࡵࡣ࠰ࡷ࡮ࡺࡥ࡬ࡧࡼࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ஑"),grCTKhQGHpt3q,ZXFs0mEPR8qI2zj.DOTALL)
		if captcha: mLx2tKuROfjkSZBzbr7TC,FF1VHRywMLz = captcha[JMLhEyaBWmskovGHTrVCxQ08(u"࠶ွ")]
		Nt345vWAcI6qnQRY1S8apyGuXJ = uReHcEzxkTm6pN4Q[gSmqZU0plur2xKPJwQA(u"ࠨࡒ࡜ࡘࡍࡕࡎࠨஒ")][wwyUWMFAsO(u"࠷ှ")]
		hhC9JITqv3yWEGFm = HHWAnGJrb9powOqTkYgcPQ6Ef(m6b7CoBk4EQ(u"࠴࠴ဿ"))
		if yTMWeCgUROcvtsblfK85L62xPk(u"࠲၀"):
			data = {EDPaWgMt1SwNn8o(u"ࠩࡸࡷࡪࡸࠧஓ"):hhC9JITqv3yWEGFm,sArCMRngQNmXkBoKv(u"ࠪࡺࡪࡸࡳࡪࡱࡱࠫஔ"):i69DxzEZSwmuY5Il,EDPaWgMt1SwNn8o(u"ࠫࡺࡸ࡬ࠨக"):Uuk5EyoaxM,MM2BQ7xrAfNivgenXPytGYOs0DEHRC(u"ࠬࡱࡥࡺࠩ஖"):FF1VHRywMLz,LmcNhzY6fQPd2JyCGslkSr(u"࠭ࡩࡥࠩ஗"):hjNP5w9srJz2QpVISxBfndbD4CkXvl(u"ࠧࠨ஘"),jYaM5vilgZdFx6QHbApwVXO8et(u"ࠨ࡬ࡲࡦࠬங"):J3OCAmZVcn(u"ࠩࡪࡩࡹࡻࡲ࡭ࡵࠪச")}
			wpFmEA3z8JR = A6F71g3cqN4(KxirmCLT6Gw,gnfv8UtZ3daGqpjzk(u"ࠪࡔࡔ࡙ࡔࠨ஛"),Nt345vWAcI6qnQRY1S8apyGuXJ,data,AAgpHN0nMZ(u"ࠫࠬஜ"),ffCSGrTJYPsxgVQWKLtHU3iMwB(u"ࠬ࠭஝"),pEo8g7riWVL014KaRtzQ(u"࠭ࠧஞ"),c4QSTnPiWUCjhrLlwGB(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡆ࡞ࡖࡁࡔࡕࡢࡅࡐ࡝ࡁࡎࡡࡆࡅࡕ࡚ࡃࡉࡃ࠰࠶ࡳࡪࠧட"))
			QstumvzTIEUMXCcx06aD4y8nSqH = wpFmEA3z8JR.content
		QstumvzTIEUMXCcx06aD4y8nSqH = hjNP5w9srJz2QpVISxBfndbD4CkXvl(u"ࠨࠩ஠")
		if QstumvzTIEUMXCcx06aD4y8nSqH.startswith(JMLhEyaBWmskovGHTrVCxQ08(u"ࠩࡘࡖࡑ࡙࠽ࠨ஡")):
			L5k0oWzXR7TPl3 = NL0JIkbrEWqTYj61vVKGCnBw37MsOF(m6b7CoBk4EQ(u"ࠪࡰ࡮ࡹࡴࠨ஢"),QstumvzTIEUMXCcx06aD4y8nSqH.split(m6b7CoBk4EQ(u"࡚ࠫࡘࡌࡔ࠿ࠪண"),J3OCAmZVcn(u"࠴၁"))[J3OCAmZVcn(u"࠴၁")])
			for l3UpyxrXZ2 in L5k0oWzXR7TPl3:
				url = l3UpyxrXZ2[Ej67fFyoqW8kbV2HdSK(u"ࠬࡻࡲ࡭ࠩத")]
				q7ZsJYigubKLljme32W = l3UpyxrXZ2[kRYWcNuAazr4jtmBoxFVS19Z6(u"࠭࡭ࡦࡶ࡫ࡳࡩ࠭஥")]
				data = l3UpyxrXZ2[aVLSn1xw5cK(u"ࠧࡥࡣࡷࡥࠬ஦")]
				headers = l3UpyxrXZ2[Ej67fFyoqW8kbV2HdSK(u"ࠨࡪࡨࡥࡩ࡫ࡲࡴࠩ஧")]
				wpFmEA3z8JR = A6F71g3cqN4(KxirmCLT6Gw,q7ZsJYigubKLljme32W,url,data,headers,ZSJVq5XDrRot(u"ࠩࠪந"),MM2BQ7xrAfNivgenXPytGYOs0DEHRC(u"ࠪࠫன"),bdhQDyjm3nPwToFHkprvCzBLUGR(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡃ࡛ࡓࡅࡘ࡙࡟ࡂࡍ࡚ࡅࡒࡥࡃࡂࡒࡗࡇࡍࡇ࠭࠴ࡴࡧࠫப"))
				grCTKhQGHpt3q = wpFmEA3z8JR.content
				if AAgpHN0nMZ(u"ࠬ࠴࡭ࡱ࠶ࠪ஫") in grCTKhQGHpt3q:
					CTQlmBkHVz6JioRW = gnfv8UtZ3daGqpjzk(u"ࡗࡶࡺ࡫ᄶ")
					break
				nIGwfpReQZoiOmMH8N = str(wpFmEA3z8JR.headers)
				imuLazAkgXMlO3UxbnQF = nIGwfpReQZoiOmMH8N+grCTKhQGHpt3q
				SWVLD3vAMgKwzldm = ZXFs0mEPR8qI2zj.findall(MM2BQ7xrAfNivgenXPytGYOs0DEHRC(u"࠭ࠨࡢ࡭ࡺࡥࡲ࡜ࡥࡳ࡫ࡩ࡭ࡨࡧࡴࡪࡱࡱࡠࡼ࠱ࠩ࠯ࠬࡂࠦ࠭࡫ࡹࡋ࠰࠭ࡃ࠮ࠨࠧ஬"),imuLazAkgXMlO3UxbnQF,ZXFs0mEPR8qI2zj.DOTALL)
				Yhqjz4bLa1HB = ZXFs0mEPR8qI2zj.findall(m6b7CoBk4EQ(u"ࠧࡳࡧࡦࡥࡵࡺࡣࡩࡣ࠰ࡸࡴࡱࡥ࡯࠰࠭ࡃࠧ࠮࠰࠴ࡃ࠱࠮ࡄ࠯ࠢࠨ஭"),imuLazAkgXMlO3UxbnQF,ZXFs0mEPR8qI2zj.DOTALL)
				if Yhqjz4bLa1HB: Yhqjz4bLa1HB = Yhqjz4bLa1HB[aFQoGfmYKyqLU6X8libw9k3ncW5(u"࠴၂")]
				if SWVLD3vAMgKwzldm or Yhqjz4bLa1HB: break
		if not CTQlmBkHVz6JioRW:
			if not SWVLD3vAMgKwzldm:
				if captcha and not Yhqjz4bLa1HB:
					if kRYWcNuAazr4jtmBoxFVS19Z6(u"࠶၃"): Yhqjz4bLa1HB = a4WNSCwzBqZ(FF1VHRywMLz,gSmqZU0plur2xKPJwQA(u"ࠨࡣࡵࠫம"),Uuk5EyoaxM)
					else:
						if not QstumvzTIEUMXCcx06aD4y8nSqH.startswith(AAgpHN0nMZ(u"ࠩࡌࡈࡂ࠭ய")):
							data = {wwyUWMFAsO(u"ࠪࡹࡸ࡫ࡲࠨர"):hhC9JITqv3yWEGFm,jYaM5vilgZdFx6QHbApwVXO8et(u"ࠫࡻ࡫ࡲࡴ࡫ࡲࡲࠬற"):i69DxzEZSwmuY5Il,jYaM5vilgZdFx6QHbApwVXO8et(u"ࠬࡻࡲ࡭ࠩல"):Uuk5EyoaxM,yTMWeCgUROcvtsblfK85L62xPk(u"࠭࡫ࡦࡻࠪள"):FF1VHRywMLz,XogUJZEijT7KWbxeO6(u"ࠧࡪࡦࠪழ"):eeIL1TfgFQJaKqVD8hGNPEZ(u"ࠨࠩவ"),AAgpHN0nMZ(u"ࠩ࡭ࡳࡧ࠭ஶ"):eeIL1TfgFQJaKqVD8hGNPEZ(u"ࠪ࡫ࡪࡺࡩࡥࠩஷ")}
							wpFmEA3z8JR = A6F71g3cqN4(KxirmCLT6Gw,PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"ࠫࡕࡕࡓࡕࠩஸ"),Nt345vWAcI6qnQRY1S8apyGuXJ,data,J3OCAmZVcn(u"ࠬ࠭ஹ"),yTMWeCgUROcvtsblfK85L62xPk(u"࠭ࠧ஺"),kRYWcNuAazr4jtmBoxFVS19Z6(u"ࠧࠨ஻"),aFQoGfmYKyqLU6X8libw9k3ncW5(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡇ࡟ࡐࡂࡕࡖࡣࡆࡑࡗࡂࡏࡢࡇࡆࡖࡔࡄࡊࡄ࠱࠹ࡺࡨࠨ஼"))
							QstumvzTIEUMXCcx06aD4y8nSqH = wpFmEA3z8JR.content
						else: QstumvzTIEUMXCcx06aD4y8nSqH = jYaM5vilgZdFx6QHbApwVXO8et(u"ࠩࡌࡈࡂ࠷࠲࠴࠶࠽࠾࠿ࡀࡔࡊࡏࡈࡓ࡚࡚࠽࠵࠷ࠪ஽")
						if QstumvzTIEUMXCcx06aD4y8nSqH.startswith(jYaM5vilgZdFx6QHbApwVXO8et(u"ࠪࡍࡉࡃࠧா")):
							LLXdfYs5vnKlSEZBqWcD623 = ZXFs0mEPR8qI2zj.findall(PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"ࠫࡎࡊ࠽ࠩ࠰࠭ࡃ࠮ࡀ࠺࠻࠼ࡗࡍࡒࡋࡏࡖࡖࡀࠬ࠳࠰࠿ࠪࠦࠪி"),QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
							RymQAFXts4,DyGfNV3WpHzPF2CL = LLXdfYs5vnKlSEZBqWcD623[eeIL1TfgFQJaKqVD8hGNPEZ(u"࠶၄")]
							LaX1QCyeIJ = xuYvdJpOEyQKTLNwb(u"ࠬํะ่ࠢส่฾๋ไ๋หࠣฮาะวอ๋ࠢๆฯࠦๅ็ࠢ࠴࠴ࠥหไ๊ࠢࠪீ")+DyGfNV3WpHzPF2CL+ZSJVq5XDrRot(u"࠭ࠠฬษ้๎ฮ࠭ு")
							EEA7qzwV381eifP = a6Nd4etSry0P1W()
							EEA7qzwV381eifP.create(ffCSGrTJYPsxgVQWKLtHU3iMwB(u"ࠧๆฯส์้ฯࠠหฮส์ืࠦแฮืࠣว๋อࠠฤ่ึห๋่ࠦๅีอࠤอืๆศ็ฯࠤ่๎ๅษ์๋ฮึ࠭ூ"),LaX1QCyeIJ)
							FuztGLxaW45chQUeDEN6PASKR = luMHeSgCBaPrb9KvUjNFqcR.time()
							loU9wvMiyqden4P,b8PdOKX3ascnNtw = kmdSKeBIwViM9t3(u"࠰၅"),kmdSKeBIwViM9t3(u"࠰၅")
							while loU9wvMiyqden4P<int(DyGfNV3WpHzPF2CL):
								b8bEl0XjyR4hACKcYkJVP2oBavnGm1(EEA7qzwV381eifP,int(loU9wvMiyqden4P/int(DyGfNV3WpHzPF2CL)*fR68jBGWCzUsFXdlTKPOScugm(u"࠲࠲࠳၆")),LaX1QCyeIJ,yTMWeCgUROcvtsblfK85L62xPk(u"ࠨࠩ௃"),DyGfNV3WpHzPF2CL+FhcnOB9t3frzvXb(u"ࠩࠣ࠳ࠥ࠭௄")+str(int(loU9wvMiyqden4P))+JcDaEHuiS8TqBbOhWe4ZgwknoC1L3r(u"ࠪࠤࠥัว็์ฬࠫ௅"))
								if loU9wvMiyqden4P>b8PdOKX3ascnNtw+m6b7CoBk4EQ(u"࠳࠳၇"):
									data = {gnfv8UtZ3daGqpjzk(u"ࠫࡺࡹࡥࡳࠩெ"):hhC9JITqv3yWEGFm,Ej67fFyoqW8kbV2HdSK(u"ࠬࡼࡥࡳࡵ࡬ࡳࡳ࠭ே"):i69DxzEZSwmuY5Il,aVLSn1xw5cK(u"࠭ࡵࡳ࡮ࠪை"):Uuk5EyoaxM,xuYvdJpOEyQKTLNwb(u"ࠧ࡬ࡧࡼࠫ௉"):FF1VHRywMLz,jYaM5vilgZdFx6QHbApwVXO8et(u"ࠨ࡫ࡧࠫொ"):RymQAFXts4,kRYWcNuAazr4jtmBoxFVS19Z6(u"ࠩ࡭ࡳࡧ࠭ோ"):MM2BQ7xrAfNivgenXPytGYOs0DEHRC(u"ࠪ࡫ࡪࡺࡴࡰ࡭ࡨࡲࠬௌ")}
									wpFmEA3z8JR = A6F71g3cqN4(KxirmCLT6Gw,kmdSKeBIwViM9t3(u"ࠫࡕࡕࡓࡕ்ࠩ"),Nt345vWAcI6qnQRY1S8apyGuXJ,data,aFQoGfmYKyqLU6X8libw9k3ncW5(u"ࠬ࠭௎"),jYaM5vilgZdFx6QHbApwVXO8et(u"࠭ࠧ௏"),OVmSuf8tpd(u"ࠧࠨௐ"),FhcnOB9t3frzvXb(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡇ࡟ࡐࡂࡕࡖࡣࡆࡑࡗࡂࡏࡢࡇࡆࡖࡔࡄࡊࡄ࠱࠺ࡺࡨࠨ௑"))
									QstumvzTIEUMXCcx06aD4y8nSqH = wpFmEA3z8JR.content
									if QstumvzTIEUMXCcx06aD4y8nSqH.startswith(AAgpHN0nMZ(u"ࠩࡗࡓࡐࡋࡎ࠾ࠩ௒")):
										Yhqjz4bLa1HB = QstumvzTIEUMXCcx06aD4y8nSqH.split(LmcNhzY6fQPd2JyCGslkSr(u"ࠪࡘࡔࡑࡅࡏ࠿ࠪ௓"),PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"࠴၈"))[PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"࠴၈")]
										break
									b8PdOKX3ascnNtw = loU9wvMiyqden4P
								else: luMHeSgCBaPrb9KvUjNFqcR.sleep(aVLSn1xw5cK(u"࠵၉"))
								loU9wvMiyqden4P = luMHeSgCBaPrb9KvUjNFqcR.time()-FuztGLxaW45chQUeDEN6PASKR
							EEA7qzwV381eifP.close()
				if Yhqjz4bLa1HB:
					JU8wfTgV5C0qoB4lOFIZNkY1Xc9jyK = wpFmEA3z8JR.cookies
					lf0Dq16LtMnpobaKyc = ZXFs0mEPR8qI2zj.findall(Ej67fFyoqW8kbV2HdSK(u"ࠫࡦࡱࡷࡢ࡯ࡢࡷࡪࡹࡳࡪࡱࡱࡁ࠭࠴ࠪࡀࠫ࠾ࠫ௔"),imuLazAkgXMlO3UxbnQF,ZXFs0mEPR8qI2zj.DOTALL)
					if aVLSn1xw5cK(u"ࠬࡧ࡫ࡸࡣࡰࡣࡸ࡫ࡳࡴ࡫ࡲࡲࠬ௕") in list(JU8wfTgV5C0qoB4lOFIZNkY1Xc9jyK.keys()): lf0Dq16LtMnpobaKyc = JU8wfTgV5C0qoB4lOFIZNkY1Xc9jyK[hjNP5w9srJz2QpVISxBfndbD4CkXvl(u"࠭ࡡ࡬ࡹࡤࡱࡤࡹࡥࡴࡵ࡬ࡳࡳ࠭௖")]
					elif lf0Dq16LtMnpobaKyc: lf0Dq16LtMnpobaKyc = lf0Dq16LtMnpobaKyc[Ej67fFyoqW8kbV2HdSK(u"࠵၊")]
					captcha = ZXFs0mEPR8qI2zj.findall(bdhQDyjm3nPwToFHkprvCzBLUGR(u"ࠧࡱࡣࡪࡩ࠲ࡸࡥࡥ࡫ࡵࡩࡨࡺ࠮ࠫࡁࡤࡧࡹ࡯࡯࡯࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡪࡡࡵࡣ࠰ࡷ࡮ࡺࡥ࡬ࡧࡼࡁࠧ࠮࠮ࠫࡁࠬࠦࠬௗ"),grCTKhQGHpt3q,ZXFs0mEPR8qI2zj.DOTALL)
					if captcha: mLx2tKuROfjkSZBzbr7TC,FF1VHRywMLz = captcha[DLSVmlyBbCK(u"࠶။")]
					if lf0Dq16LtMnpobaKyc and captcha:
						headers = {c4QSTnPiWUCjhrLlwGB(u"ࠨࡅࡲࡳࡰ࡯ࡥࠨ௘"):AAgpHN0nMZ(u"ࠩࡤ࡯ࡼࡧ࡭ࡠࡵࡨࡷࡸ࡯࡯࡯࠿ࠪ௙")+lf0Dq16LtMnpobaKyc,aVLSn1xw5cK(u"ࠪࡖࡪ࡬ࡥࡳࡧࡵࠫ௚"):Uuk5EyoaxM,c4QSTnPiWUCjhrLlwGB(u"ࠫࡈࡵ࡮ࡵࡧࡱࡸ࠲࡚ࡹࡱࡧࠪ௛"):J3OCAmZVcn(u"ࠬࡧࡰࡱ࡮࡬ࡧࡦࡺࡩࡰࡰ࠲ࡼ࠲ࡽࡷࡸ࠯ࡩࡳࡷࡳ࠭ࡶࡴ࡯ࡩࡳࡩ࡯ࡥࡧࡧࠫ௜")}
						data = EDPaWgMt1SwNn8o(u"࠭ࡧ࠮ࡴࡨࡧࡦࡶࡴࡤࡪࡤ࠱ࡷ࡫ࡳࡱࡱࡱࡷࡪࡃࠧ௝")+Yhqjz4bLa1HB
						wpFmEA3z8JR = A6F71g3cqN4(JNsoWV1CXc4xy,DLSVmlyBbCK(u"ࠧࡑࡑࡖࡘࠬ௞"),mLx2tKuROfjkSZBzbr7TC,data,headers,m6b7CoBk4EQ(u"ࡊࡦࡲࡳࡦᄷ"),fR68jBGWCzUsFXdlTKPOScugm(u"ࠨࠩ௟"),FhcnOB9t3frzvXb(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡈ࡙ࡑࡃࡖࡗࡤࡇࡋࡘࡃࡐࡣࡈࡇࡐࡕࡅࡋࡅ࠲࠼ࡴࡩࠩ௠"))
						grCTKhQGHpt3q = wpFmEA3z8JR.content
						try: cookies = wpFmEA3z8JR.cookies
						except: cookies = {}
						SWVLD3vAMgKwzldm = ZXFs0mEPR8qI2zj.findall(Ej67fFyoqW8kbV2HdSK(u"ࠥࠫ࠭ࡧ࡫ࡸࡣࡰ࡚ࡪࡸࡩࡧ࡫ࡦࡥࡹ࡯࡯࡯࠰࠭ࡃ࠮࠭࠺ࠡࠩࠫ࠲࠯ࡅࠩࠨࠤ௡"),str(cookies),ZXFs0mEPR8qI2zj.DOTALL)
			if SWVLD3vAMgKwzldm:
				aaYDh2EzJ5ky,SWVLD3vAMgKwzldm = SWVLD3vAMgKwzldm[DLSVmlyBbCK(u"࠰၌")]
				MYy3reW74PSXGiBcAN0I6fHpoO5zn = aaYDh2EzJ5ky+m6b7CoBk4EQ(u"ࠫࡂ࠭௢")+SWVLD3vAMgKwzldm
				j2agIU0xsLS6c7T.setSetting(gnfv8UtZ3daGqpjzk(u"ࠬࡧࡶ࠯ࡣ࡮ࡻࡦࡳ࠮ࡷࡧࡵ࡭࡫࡯ࡣࡢࡶ࡬ࡳࡳ࠭௣"),MYy3reW74PSXGiBcAN0I6fHpoO5zn)
				HHTzVhiY079bvdluNkFQ4wCMpe(bdhQDyjm3nPwToFHkprvCzBLUGR(u"࠭ࠧ௤"),jYaM5vilgZdFx6QHbApwVXO8et(u"ࠧࠨ௥"),JMLhEyaBWmskovGHTrVCxQ08(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ௦"),XogUJZEijT7KWbxeO6(u"้ࠩะาะฺࠠ็็๎ฮࠦแฮืࠣว๋อࠠฦ่ึห๋ࠦ࠮࠯๋ࠢๆฬ๋ࠠศๆหี๋อๅอࠢหาื์ࠠ็ฬสสัࠦ็ัษࠣห้็อึࠢ็็๏๊ࠦิฬัำ๊ํวࠡๆสั็อࠠ࠯࠰ࠣ์้อࠠห๊ฯำࠥำวอห่ࠣส฿วะห๋ࠣีอࠠศๆไัฺࠦไฺัฬࠤศฺ็าࠢ࡟ࡲࡡࡴฺࠠๆ่หࠥษๆ้ࠡำหࠥอไโฯุࠤุ๎แࠡ์อ็ึืࠠโ์ࠣัฬ๊ษࠡฬ฽๎ึࠦัษูࠣห้า็ศิࠣฬฬ๊ล็ฬิ๊ฯࠦ࠮࠯ࠢฦ์ࠥหืโษฤࠤึอ่หำࠣห้หๆหำ้ฮࠥ࠴࠮ࠡล๋ࠤๆ฻ไࠡี็็ࠥอไาษ๋ฮึࠦ࠮࠯ࠢฦ์ࠥอำหะาห๊ࠦࡖࡑࡐࠣวํࠦศา๊ๆื๏࠭௧"))
				if gnfv8UtZ3daGqpjzk(u"ࠪ࠲ࡲࡶ࠴ࠨ௨") not in grCTKhQGHpt3q:
					headers = {JMLhEyaBWmskovGHTrVCxQ08(u"ࠫࡈࡵ࡯࡬࡫ࡨࠫ௩"):MYy3reW74PSXGiBcAN0I6fHpoO5zn}
					wpFmEA3z8JR = A6F71g3cqN4(JNsoWV1CXc4xy,eeIL1TfgFQJaKqVD8hGNPEZ(u"ࠬࡍࡅࡕࠩ௪"),Uuk5EyoaxM,jYaM5vilgZdFx6QHbApwVXO8et(u"࠭ࠧ௫"),headers,yTMWeCgUROcvtsblfK85L62xPk(u"ࠧࠨ௬"),XogUJZEijT7KWbxeO6(u"ࠨࠩ௭"),hjNP5w9srJz2QpVISxBfndbD4CkXvl(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡈ࡙ࡑࡃࡖࡗࡤࡇࡋࡘࡃࡐࡣࡈࡇࡐࡕࡅࡋࡅ࠲࠽ࡴࡩࠩ௮"))
					grCTKhQGHpt3q = wpFmEA3z8JR.content
	if not CTQlmBkHVz6JioRW and not MYy3reW74PSXGiBcAN0I6fHpoO5zn: HHTzVhiY079bvdluNkFQ4wCMpe(hjNP5w9srJz2QpVISxBfndbD4CkXvl(u"ࠪࠫ௯"),XogUJZEijT7KWbxeO6(u"ࠫࠬ௰"),EDPaWgMt1SwNn8o(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ௱"),jYaM5vilgZdFx6QHbApwVXO8et(u"࠭แีๆอࠤ฾๋ไ๋หࠣๅา฻ࠠฤ่สࠤศ์ำศ่ࠣ࠲࠳ࠦอศ๊็ࠤส฿วะหࠣห้฿ๅๅ์ฬࠤ๊ืษࠡลัี๎ࠦศศีอาิอๅ่ࠡไืࠥอไโ์า๎ํࠦร้ࠢไ๎ิ๐่ࠡ฼ํี์ࠦๅ็้ࠢๅุࠦวๅ็๋ๆ฾࠭௲"))
	return grCTKhQGHpt3q
def FN6uzHvdbp(url,type,PHUqTNVJ0ErRSwibn5gD):
	yf608hE5KeRG1DscunvrU,AABKVNO3WiMUSe0 = [],[]
	Uuk5EyoaxM = url
	wpFmEA3z8JR = A6F71g3cqN4(JNsoWV1CXc4xy,ZSJVq5XDrRot(u"ࠧࡈࡇࡗࠫ௳"),url,Ej67fFyoqW8kbV2HdSK(u"ࠨࠩ௴"),EDPaWgMt1SwNn8o(u"ࠩࠪ௵"),JMLhEyaBWmskovGHTrVCxQ08(u"ࠪࠫ௶"),jYaM5vilgZdFx6QHbApwVXO8et(u"ࠫࠬ௷"),sArCMRngQNmXkBoKv(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡃࡎ࡛ࡆࡓ࠭࠲ࡵࡷࠫ௸"))
	XgMyLUkfvP4uKVpQsY8RiWZz6N50O = wpFmEA3z8JR.content
	xp0tHBieOcC = []
	if aFQoGfmYKyqLU6X8libw9k3ncW5(u"࠭࠯ࡸࡣࡷࡧ࡭࠵ࠧ௹") in XgMyLUkfvP4uKVpQsY8RiWZz6N50O or wwyUWMFAsO(u"ࠧ࠰ࡦࡲࡻࡳࡲ࡯ࡢࡦ࠲ࠫ௺") in XgMyLUkfvP4uKVpQsY8RiWZz6N50O:
		n5nyDgxTuHbY0LNV4cWvoBtp = ZXFs0mEPR8qI2zj.findall(gSmqZU0plur2xKPJwQA(u"ࠨ࠾ࡤࠤ࡭ࡸࡥࡧ࠿ࠥ࡬ࡹࡺࡰ࠯ࠬࡂࡀ࠴ࡧ࠾ࠨ௻"),XgMyLUkfvP4uKVpQsY8RiWZz6N50O,ZXFs0mEPR8qI2zj.DOTALL)
		if n5nyDgxTuHbY0LNV4cWvoBtp:
			for bdq4e6Wr2gslnSiA38 in n5nyDgxTuHbY0LNV4cWvoBtp:
				R28S4pFmAojEW7CGnx = ZXFs0mEPR8qI2zj.findall(m6b7CoBk4EQ(u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࡫ࡸࡹࡶ࠮ࠫࡁࠬࠦ࠳࠰࠿࠽ࡵࡳࡥࡳ࠴ࠪࡀࠤࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡥࡃ࠭௼"),bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
				for RRucmYBaXegTtNOdGHMQ,title in R28S4pFmAojEW7CGnx:
					if RRucmYBaXegTtNOdGHMQ in yf608hE5KeRG1DscunvrU: continue
					if OVmSuf8tpd(u"ࠪ࠳ࡼࡧࡴࡤࡪ࠲ࠫ௽") not in RRucmYBaXegTtNOdGHMQ and OVmSuf8tpd(u"ࠫ࠴ࡪ࡯ࡸࡰ࡯ࡳࡦࡪ࠯ࠨ௾") not in RRucmYBaXegTtNOdGHMQ: continue
					if aVLSn1xw5cK(u"ࠬอࠧ௿") not in title:
						xp0tHBieOcC.append((title,RRucmYBaXegTtNOdGHMQ))
						continue
					title = title.replace(XogUJZEijT7KWbxeO6(u"࠭࠼࠰ࡵࡳࡥࡳࡄࠧఀ"),J3OCAmZVcn(u"ࠧࠨఁ")).replace(JMLhEyaBWmskovGHTrVCxQ08(u"ࠨࠢ࠰ࠤࠬం"),aVLSn1xw5cK(u"ࠩࠪః")).strip(xuYvdJpOEyQKTLNwb(u"ࠪࠤࠬఄ")).replace(pEo8g7riWVL014KaRtzQ(u"ࠫࠥࠦࠧఅ"),EDPaWgMt1SwNn8o(u"ࠬࠦࠧఆ"))
					if OVmSuf8tpd(u"࠭ࡳࡱࡣࡱࠫఇ") in title: continue
					yf608hE5KeRG1DscunvrU.append(RRucmYBaXegTtNOdGHMQ)
					AABKVNO3WiMUSe0.append(title)
			for title,RRucmYBaXegTtNOdGHMQ in xp0tHBieOcC:
				if RRucmYBaXegTtNOdGHMQ not in yf608hE5KeRG1DscunvrU:
					yf608hE5KeRG1DscunvrU.append(RRucmYBaXegTtNOdGHMQ)
					AABKVNO3WiMUSe0.append(title)
			jQ6w8xOrgYhSHIRpUqzL = jYaM5vilgZdFx6QHbApwVXO8et(u"࠱၍")
			if len(yf608hE5KeRG1DscunvrU)>sArCMRngQNmXkBoKv(u"࠳၎"):
				jQ6w8xOrgYhSHIRpUqzL = F2yZPukcUh09sqCI8nYw7e(gSmqZU0plur2xKPJwQA(u"ࠧษ฻ู๋ฬ๊ࠦฮฬสะࠥ࠼࠰ࠡอส๊๏ฯࠧఈ"),AABKVNO3WiMUSe0)
				if jQ6w8xOrgYhSHIRpUqzL==-gnfv8UtZ3daGqpjzk(u"࠴၏"): return ffCSGrTJYPsxgVQWKLtHU3iMwB(u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡇࡦࡴࡣࡦ࡮ࡨࡨࠥࡇࡋࡘࡃࡐࠫఉ"),[],[]
			if yf608hE5KeRG1DscunvrU and jQ6w8xOrgYhSHIRpUqzL>=c4QSTnPiWUCjhrLlwGB(u"࠴ၐ"): Uuk5EyoaxM = yf608hE5KeRG1DscunvrU[jQ6w8xOrgYhSHIRpUqzL]
	grCTKhQGHpt3q = FWg3peNhl0U(Uuk5EyoaxM)
	YYmyQXglbEewzL3IA2Sd,xCLQK8kh39sjyi5DXSZAVeI = [],[]
	if type==MM2BQ7xrAfNivgenXPytGYOs0DEHRC(u"ࠩࡧࡳࡼࡴ࡬ࡰࡣࡧࠫఊ"):
		OtEXLVw3rz4ev = ZXFs0mEPR8qI2zj.findall(hjNP5w9srJz2QpVISxBfndbD4CkXvl(u"ࠪࡦࡹࡴ࠭࡭ࡱࡤࡨࡪࡸ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨఋ"),grCTKhQGHpt3q,ZXFs0mEPR8qI2zj.DOTALL)
		if OtEXLVw3rz4ev:
			RRucmYBaXegTtNOdGHMQ = ejBOu2WXwvb4YpITdsLF16(OtEXLVw3rz4ev[Ej67fFyoqW8kbV2HdSK(u"࠵ၑ")])
			YYmyQXglbEewzL3IA2Sd.append(RRucmYBaXegTtNOdGHMQ)
			xCLQK8kh39sjyi5DXSZAVeI.append(PHUqTNVJ0ErRSwibn5gD)
	elif type==eeIL1TfgFQJaKqVD8hGNPEZ(u"ࠫࡼࡧࡴࡤࡪࠪఌ"):
		R28S4pFmAojEW7CGnx = ZXFs0mEPR8qI2zj.findall(gnfv8UtZ3daGqpjzk(u"ࠬࡂࡳࡰࡷࡵࡧࡪ࠴ࠪࡀࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡵ࡬ࡾࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ఍"),grCTKhQGHpt3q,ZXFs0mEPR8qI2zj.DOTALL)
		for RRucmYBaXegTtNOdGHMQ,size in R28S4pFmAojEW7CGnx:
			if not RRucmYBaXegTtNOdGHMQ: continue
			if PHUqTNVJ0ErRSwibn5gD in size:
				xCLQK8kh39sjyi5DXSZAVeI.append(size)
				YYmyQXglbEewzL3IA2Sd.append(RRucmYBaXegTtNOdGHMQ)
				break
		if not YYmyQXglbEewzL3IA2Sd:
			for RRucmYBaXegTtNOdGHMQ,size in R28S4pFmAojEW7CGnx:
				if not RRucmYBaXegTtNOdGHMQ: continue
				xCLQK8kh39sjyi5DXSZAVeI.append(size)
				YYmyQXglbEewzL3IA2Sd.append(RRucmYBaXegTtNOdGHMQ)
	if not YYmyQXglbEewzL3IA2Sd: return ffCSGrTJYPsxgVQWKLtHU3iMwB(u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡃࡎ࡛ࡆࡓࠧఎ"),[],[]
	return xuYvdJpOEyQKTLNwb(u"ࠧࠨఏ"),xCLQK8kh39sjyi5DXSZAVeI,YYmyQXglbEewzL3IA2Sd
def mCTR9VFong(url,aaYDh2EzJ5ky):
	wpFmEA3z8JR = A6F71g3cqN4(Z7uFdWIRv9ybj0,EDPaWgMt1SwNn8o(u"ࠨࡉࡈࡘࠬఐ"),url,JMLhEyaBWmskovGHTrVCxQ08(u"ࠩࠪ఑"),JMLhEyaBWmskovGHTrVCxQ08(u"ࠪࠫఒ"),gnfv8UtZ3daGqpjzk(u"࡙ࡸࡵࡦᄸ"),jYaM5vilgZdFx6QHbApwVXO8et(u"ࠫࠬఓ"),gnfv8UtZ3daGqpjzk(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡃࡎࡓࡆࡓ࠭࠲ࡵࡷࠫఔ"))
	QstumvzTIEUMXCcx06aD4y8nSqH = wpFmEA3z8JR.content
	cookies = wpFmEA3z8JR.cookies
	if J3OCAmZVcn(u"࠭ࡧࡰ࡮࡬ࡲࡰ࠭క") in list(cookies.keys()):
		MYy3reW74PSXGiBcAN0I6fHpoO5zn = cookies[sArCMRngQNmXkBoKv(u"ࠧࡨࡱ࡯࡭ࡳࡱࠧఖ")]
		MYy3reW74PSXGiBcAN0I6fHpoO5zn = ejBOu2WXwvb4YpITdsLF16(WhJe7bGx5XackTwOIZVLC8ut(MYy3reW74PSXGiBcAN0I6fHpoO5zn))
		items = ZXFs0mEPR8qI2zj.findall(gnfv8UtZ3daGqpjzk(u"ࠨࡴࡲࡹࡹ࡫ࠢ࠻ࠤࠫ࠲࠯ࡅࠩࠣࠩగ"),MYy3reW74PSXGiBcAN0I6fHpoO5zn,ZXFs0mEPR8qI2zj.DOTALL)
		lQHXdV9Nzf6BLqS8D = items[wwyUWMFAsO(u"࠶ၒ")].replace(bdhQDyjm3nPwToFHkprvCzBLUGR(u"ࠩ࡟࠳ࠬఘ"),kmdSKeBIwViM9t3(u"ࠪ࠳ࠬఙ"))
		lQHXdV9Nzf6BLqS8D = WhJe7bGx5XackTwOIZVLC8ut(lQHXdV9Nzf6BLqS8D)
	else: lQHXdV9Nzf6BLqS8D = url
	if PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"ࠫࡨࡧࡴࡤࡪ࠱࡭ࡸ࠭చ") in lQHXdV9Nzf6BLqS8D:
		id = lQHXdV9Nzf6BLqS8D.split(FhcnOB9t3frzvXb(u"ࠬࠫ࠲ࡇࠩఛ"))[-LmcNhzY6fQPd2JyCGslkSr(u"࠱ၓ")]
		lQHXdV9Nzf6BLqS8D = eeIL1TfgFQJaKqVD8hGNPEZ(u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡣࡢࡶࡦ࡬࠳࡯ࡳ࠰ࠩజ")+id
		return gnfv8UtZ3daGqpjzk(u"ࠧࡏࡇࡈࡈࡤࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪఝ"),[Ej67fFyoqW8kbV2HdSK(u"ࠨࠩఞ")],[lQHXdV9Nzf6BLqS8D]
	else:
		website = uReHcEzxkTm6pN4Q[PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"ࠩࡄࡏࡔࡇࡍࠨట")][hjNP5w9srJz2QpVISxBfndbD4CkXvl(u"࠱ၔ")]
		wpFmEA3z8JR = A6F71g3cqN4(Z7uFdWIRv9ybj0,c4QSTnPiWUCjhrLlwGB(u"ࠪࡋࡊ࡚ࠧఠ"),website,OVmSuf8tpd(u"ࠫࠬడ"),gSmqZU0plur2xKPJwQA(u"ࠬ࠭ఢ"),DLSVmlyBbCK(u"࡚ࡲࡶࡧᄹ"),m6b7CoBk4EQ(u"࠭ࠧణ"),ffCSGrTJYPsxgVQWKLtHU3iMwB(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡅࡐࡕࡁࡎ࠯࠵ࡲࡩ࠭త"))
		wKv52q8uzSp = wpFmEA3z8JR.url
		Xk3vi7J0tL2Yu5RwHeOCbj1 = lQHXdV9Nzf6BLqS8D.split(Ej67fFyoqW8kbV2HdSK(u"ࠨ࠱ࠪథ"))[xuYvdJpOEyQKTLNwb(u"࠴ၕ")]
		lN92E15uD0zRZY = wKv52q8uzSp.split(xuYvdJpOEyQKTLNwb(u"ࠩ࠲ࠫద"))[PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"࠵ၖ")]
		aaIn3XlQKJ6zSfkmjuCyM = lQHXdV9Nzf6BLqS8D.replace(Xk3vi7J0tL2Yu5RwHeOCbj1,lN92E15uD0zRZY)
		headers = { aFQoGfmYKyqLU6X8libw9k3ncW5(u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧధ"):aVLSn1xw5cK(u"ࠫࠬన") , aFQoGfmYKyqLU6X8libw9k3ncW5(u"ࠬ࡞࠭ࡓࡧࡴࡹࡪࡹࡴࡦࡦ࠰࡛࡮ࡺࡨࠨ఩"):EDPaWgMt1SwNn8o(u"࠭ࡘࡎࡎࡋࡸࡹࡶࡒࡦࡳࡸࡩࡸࡺࠧప") , aVLSn1xw5cK(u"ࠧࡓࡧࡩࡩࡷ࡫ࡲࠨఫ"):aaIn3XlQKJ6zSfkmjuCyM }
		wpFmEA3z8JR = A6F71g3cqN4(dALVaOWB4jKN3Tbt0Cm1ns9k5u,gSmqZU0plur2xKPJwQA(u"ࠨࡒࡒࡗ࡙࠭బ"), aaIn3XlQKJ6zSfkmjuCyM, aVLSn1xw5cK(u"ࠩࠪభ"), headers, fR68jBGWCzUsFXdlTKPOScugm(u"ࡆࡢ࡮ࡶࡩᄺ"),ZSJVq5XDrRot(u"ࠪࠫమ"),DLSVmlyBbCK(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡂࡍࡒࡅࡒ࠳࠳ࡳࡦࠪయ"))
		QstumvzTIEUMXCcx06aD4y8nSqH = wpFmEA3z8JR.content
		items = ZXFs0mEPR8qI2zj.findall(gSmqZU0plur2xKPJwQA(u"ࠬࡪࡩࡳࡧࡦࡸࡤࡲࡩ࡯࡭ࠥ࠾ࠧ࠮࠮ࠫࡁࠬࠦࠬర"),QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL|ZXFs0mEPR8qI2zj.IGNORECASE)
		if not items:
			items = ZXFs0mEPR8qI2zj.findall(OVmSuf8tpd(u"࠭࠼ࡪࡨࡵࡥࡲ࡫࠮ࠫࡁࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧఱ"),QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL|ZXFs0mEPR8qI2zj.IGNORECASE)
			if not items:
				items = ZXFs0mEPR8qI2zj.findall(LmcNhzY6fQPd2JyCGslkSr(u"ࠧ࠽ࡧࡰࡦࡪࡪ࠮ࠫࡁࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧల"),QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL|ZXFs0mEPR8qI2zj.IGNORECASE)
		if items:
			RRucmYBaXegTtNOdGHMQ = items[aVLSn1xw5cK(u"࠴ၗ")].replace(OVmSuf8tpd(u"ࠨ࡞࠲ࠫళ"),PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"ࠩ࠲ࠫఴ"))
			RRucmYBaXegTtNOdGHMQ = RRucmYBaXegTtNOdGHMQ.rstrip(m6b7CoBk4EQ(u"ࠪ࠳ࠬవ"))
			if XogUJZEijT7KWbxeO6(u"ࠫ࡭ࡺࡴࡱࠩశ") not in RRucmYBaXegTtNOdGHMQ: RRucmYBaXegTtNOdGHMQ = EDPaWgMt1SwNn8o(u"ࠬ࡮ࡴࡵࡲ࠽ࠫష") + RRucmYBaXegTtNOdGHMQ
			RRucmYBaXegTtNOdGHMQ = RRucmYBaXegTtNOdGHMQ.replace(JcDaEHuiS8TqBbOhWe4ZgwknoC1L3r(u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࠧస"),AAgpHN0nMZ(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࠩహ"))
			if aaYDh2EzJ5ky==FhcnOB9t3frzvXb(u"ࠨࠩ఺"): svA3Xnq5GbkTcZPHd,xCLQK8kh39sjyi5DXSZAVeI,YYmyQXglbEewzL3IA2Sd = MM2BQ7xrAfNivgenXPytGYOs0DEHRC(u"ࠩࠪ఻"),[kRYWcNuAazr4jtmBoxFVS19Z6(u"఼ࠪࠫ")],[RRucmYBaXegTtNOdGHMQ]
			else: svA3Xnq5GbkTcZPHd,xCLQK8kh39sjyi5DXSZAVeI,YYmyQXglbEewzL3IA2Sd = kmdSKeBIwViM9t3(u"ࠫࡓࡋࡅࡅࡡࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧఽ"),[ffCSGrTJYPsxgVQWKLtHU3iMwB(u"ࠬ࠭ా")],[RRucmYBaXegTtNOdGHMQ]
		else: svA3Xnq5GbkTcZPHd,xCLQK8kh39sjyi5DXSZAVeI,YYmyQXglbEewzL3IA2Sd = bdhQDyjm3nPwToFHkprvCzBLUGR(u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡃࡎࡓࡆࡓࠧి"),[],[]
		return svA3Xnq5GbkTcZPHd,xCLQK8kh39sjyi5DXSZAVeI,YYmyQXglbEewzL3IA2Sd
def RwYPmxKihAt0svG8XHy9k(url):
	headers = { xuYvdJpOEyQKTLNwb(u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫీ") : OVmSuf8tpd(u"ࠨࠩు") }
	QstumvzTIEUMXCcx06aD4y8nSqH = QuWA3hsmIvockZDiy2rLg(dALVaOWB4jKN3Tbt0Cm1ns9k5u,url,aFQoGfmYKyqLU6X8libw9k3ncW5(u"ࠩࠪూ"),headers,wwyUWMFAsO(u"ࠪࠫృ"),AAgpHN0nMZ(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡓࡃࡓࡍࡉ࡜ࡉࡅࡇࡒ࠱࠶ࡹࡴࠨౄ"))
	items = ZXFs0mEPR8qI2zj.findall(aVLSn1xw5cK(u"ࠬࡂࡳࡰࡷࡵࡧࡪࠦࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࡬ࡢࡤࡨࡰࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭౅"),QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	xCLQK8kh39sjyi5DXSZAVeI,YYmyQXglbEewzL3IA2Sd,errno = [],[],aVLSn1xw5cK(u"࠭ࠧె")
	if items:
		for RRucmYBaXegTtNOdGHMQ,W5V6oRmIDCvcMGBQU in items:
			xCLQK8kh39sjyi5DXSZAVeI.append(W5V6oRmIDCvcMGBQU)
			YYmyQXglbEewzL3IA2Sd.append(RRucmYBaXegTtNOdGHMQ)
	if len(YYmyQXglbEewzL3IA2Sd)==JcDaEHuiS8TqBbOhWe4ZgwknoC1L3r(u"࠵ၘ"): return m6b7CoBk4EQ(u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥࠢࡕࡅࡕࡏࡄࡗࡋࡇࡉࡔ࠭ే"),[],[]
	return sArCMRngQNmXkBoKv(u"ࠨࠩై"),xCLQK8kh39sjyi5DXSZAVeI,YYmyQXglbEewzL3IA2Sd
def XkbRIPzwT5hgmcJZHo13WVBQE8(url):
	headers = {MM2BQ7xrAfNivgenXPytGYOs0DEHRC(u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭౉"):DLSVmlyBbCK(u"ࠪࠫొ")}
	QstumvzTIEUMXCcx06aD4y8nSqH = QuWA3hsmIvockZDiy2rLg(dALVaOWB4jKN3Tbt0Cm1ns9k5u,url,EDPaWgMt1SwNn8o(u"ࠫࠬో"),headers,MM2BQ7xrAfNivgenXPytGYOs0DEHRC(u"ࠬ࠭ౌ"),OVmSuf8tpd(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡘࡕࡑࡕࡁࡅ࠯࠴ࡷࡹ్࠭"))
	items = ZXFs0mEPR8qI2zj.findall(Ej67fFyoqW8kbV2HdSK(u"ࠧࡴࡱࡸࡶࡨ࡫ࡳ࠻ࠢ࡟࡟ࠧ࠮࠮ࠫࡁࠬࠦࠬ౎"),QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	if items:
		url = items[fR68jBGWCzUsFXdlTKPOScugm(u"࠶ၙ")]+yTMWeCgUROcvtsblfK85L62xPk(u"ࠨࡾࡕࡩ࡫࡫ࡲࡦࡴࡀࠫ౏")+url
		return ffCSGrTJYPsxgVQWKLtHU3iMwB(u"ࠩࠪ౐"),[Ej67fFyoqW8kbV2HdSK(u"ࠪࠫ౑")],[url]
	else: return aVLSn1xw5cK(u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡕࡒࡎࡒࡅࡉ࠭౒"),[],[]
def v2YgBsiQCX3p7NrLoxSA6adZbcz(url):
	url = url.strip(kRYWcNuAazr4jtmBoxFVS19Z6(u"ࠬ࠵ࠧ౓"))
	if gSmqZU0plur2xKPJwQA(u"࠭࠯ࡦ࡯ࡥࡩࡩ࠵ࠧ౔") in url: id = url.split(PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"ࠧ࠰ౕࠩ"))[FhcnOB9t3frzvXb(u"࠴ၚ")]
	else: id = url.split(m6b7CoBk4EQ(u"ࠨ࠱ౖࠪ"))[-PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"࠲ၛ")]
	url = gSmqZU0plur2xKPJwQA(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡺࡨࡹࡴࡳࡧࡤࡱ࠳ࡺ࡯࠰ࡲ࡯ࡥࡾ࡫ࡲࡀࡨ࡬ࡨࡂ࠭౗") + id
	headers = { bdhQDyjm3nPwToFHkprvCzBLUGR(u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧౘ") : xuYvdJpOEyQKTLNwb(u"ࠫࠬౙ") }
	QstumvzTIEUMXCcx06aD4y8nSqH = QuWA3hsmIvockZDiy2rLg(dALVaOWB4jKN3Tbt0Cm1ns9k5u,url,kmdSKeBIwViM9t3(u"ࠬ࠭ౚ"),headers,PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"࠭ࠧ౛"),fR68jBGWCzUsFXdlTKPOScugm(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰࡚ࡈ࡙ࡔࡓࡇࡄࡑ࠲࠷ࡳࡵࠩ౜"))
	QstumvzTIEUMXCcx06aD4y8nSqH = QstumvzTIEUMXCcx06aD4y8nSqH.replace(FhcnOB9t3frzvXb(u"ࠨ࡞࡟ࠫౝ"),hjNP5w9srJz2QpVISxBfndbD4CkXvl(u"ࠩࠪ౞"))
	items = ZXFs0mEPR8qI2zj.findall(ffCSGrTJYPsxgVQWKLtHU3iMwB(u"ࠪࡪ࡮ࡲࡥࠣ࠼ࠥࠬ࠳࠰࠿ࠪࠤࠪ౟"),QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	if items: return wwyUWMFAsO(u"ࠫࠬౠ"),[FhcnOB9t3frzvXb(u"ࠬ࠭ౡ")],[ items[eeIL1TfgFQJaKqVD8hGNPEZ(u"࠲ၜ")] ]
	else: return Ej67fFyoqW8kbV2HdSK(u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡘࡆࡗ࡙ࡘࡅࡂࡏࠪౢ"),[],[]
def zz0V2WZwE3xHMaGfTcD(url):
	QstumvzTIEUMXCcx06aD4y8nSqH = QuWA3hsmIvockZDiy2rLg(dALVaOWB4jKN3Tbt0Cm1ns9k5u,url,J3OCAmZVcn(u"ࠧࠨౣ"),xuYvdJpOEyQKTLNwb(u"ࠨࠩ౤"),Ej67fFyoqW8kbV2HdSK(u"ࠩࠪ౥"),AAgpHN0nMZ(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡖࡊࡆࡒ࡞ࡆ࠳࠱ࡴࡶࠪ౦"))
	items = ZXFs0mEPR8qI2zj.findall(OVmSuf8tpd(u"ࠫࡸࡸࡣ࠻ࠢࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡲࡡࡣࡧ࡯࠾ࠧ࠮࠮ࠫࡁࠬࠦ࠱ࠦࡲࡦࡵ࠽ࠦ࠭࠴ࠪࡀࠫࠥࠫ౧"),QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	xCLQK8kh39sjyi5DXSZAVeI,YYmyQXglbEewzL3IA2Sd = [],[]
	for RRucmYBaXegTtNOdGHMQ,W5V6oRmIDCvcMGBQU,hWTJ2ycGOsFrwf6bZA in items:
		xCLQK8kh39sjyi5DXSZAVeI.append(W5V6oRmIDCvcMGBQU+yTMWeCgUROcvtsblfK85L62xPk(u"ࠬࠦࠧ౨")+hWTJ2ycGOsFrwf6bZA)
		YYmyQXglbEewzL3IA2Sd.append(RRucmYBaXegTtNOdGHMQ)
	if len(YYmyQXglbEewzL3IA2Sd)==jYaM5vilgZdFx6QHbApwVXO8et(u"࠳ၝ"): return OVmSuf8tpd(u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡘࡌࡈࡔࡠࡁࠨ౩"),[],[]
	return JcDaEHuiS8TqBbOhWe4ZgwknoC1L3r(u"ࠧࠨ౪"),xCLQK8kh39sjyi5DXSZAVeI,YYmyQXglbEewzL3IA2Sd
def L1gWehJPDdn6a8(url):
	QstumvzTIEUMXCcx06aD4y8nSqH = QuWA3hsmIvockZDiy2rLg(dALVaOWB4jKN3Tbt0Cm1ns9k5u,url,ZSJVq5XDrRot(u"ࠨࠩ౫"),ffCSGrTJYPsxgVQWKLtHU3iMwB(u"ࠩࠪ౬"),OVmSuf8tpd(u"ࠪࠫ౭"),hjNP5w9srJz2QpVISxBfndbD4CkXvl(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡘࡃࡗࡇࡍ࡜ࡉࡅࡇࡒ࠱࠶ࡹࡴࠨ౮"))
	items = ZXFs0mEPR8qI2zj.findall(J3OCAmZVcn(u"ࠧࡪ࡯ࡸࡰ࡯ࡳࡦࡪ࡟ࡷ࡫ࡧࡩࡴࡢࠨࠨࠪ࠱࠮ࡄ࠯ࠧ࠭ࠩࠫ࠲࠯ࡅࠩࠨ࠮ࠪࠬ࠳࠰࠿ࠪࠩ࡟࠭ࡡࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡢࡀ࠱࠮ࡄࡂࡴࡥࡀࠫ࠲࠯ࡅࠩ࠭࠰࠭ࡃࡁ࠵ࡴࡥࡀࠥ౯"),QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	items = set(items)
	xCLQK8kh39sjyi5DXSZAVeI,YYmyQXglbEewzL3IA2Sd = [],[]
	for id,nnPsf4XLIJ7RWF,hash,W5V6oRmIDCvcMGBQU,hWTJ2ycGOsFrwf6bZA in items:
		url = ZSJVq5XDrRot(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡸࡣࡷࡧ࡭ࡼࡩࡥࡧࡲ࠲ࡺࡹ࠯ࡥ࡮ࡂࡳࡵࡃࡤࡰࡹࡱࡰࡴࡧࡤࡠࡱࡵ࡭࡬ࠬࡩࡥ࠿ࠪ౰")+id+JcDaEHuiS8TqBbOhWe4ZgwknoC1L3r(u"ࠧࠧ࡯ࡲࡨࡪࡃࠧ౱")+nnPsf4XLIJ7RWF+ZSJVq5XDrRot(u"ࠨࠨ࡫ࡥࡸ࡮࠽ࠨ౲")+hash
		QstumvzTIEUMXCcx06aD4y8nSqH = QuWA3hsmIvockZDiy2rLg(dALVaOWB4jKN3Tbt0Cm1ns9k5u,url,gSmqZU0plur2xKPJwQA(u"ࠩࠪ౳"),J3OCAmZVcn(u"ࠪࠫ౴"),OVmSuf8tpd(u"ࠫࠬ౵"),FhcnOB9t3frzvXb(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮࡙ࡄࡘࡈࡎࡖࡊࡆࡈࡓ࠲࠸࡮ࡥࠩ౶"))
		items = ZXFs0mEPR8qI2zj.findall(ffCSGrTJYPsxgVQWKLtHU3iMwB(u"࠭ࡤࡪࡴࡨࡧࡹࠦ࡬ࡪࡰ࡮࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ౷"),QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
		for RRucmYBaXegTtNOdGHMQ in items:
			xCLQK8kh39sjyi5DXSZAVeI.append(W5V6oRmIDCvcMGBQU+EDPaWgMt1SwNn8o(u"ࠧࠡࠩ౸")+hWTJ2ycGOsFrwf6bZA)
			YYmyQXglbEewzL3IA2Sd.append(RRucmYBaXegTtNOdGHMQ)
	if len(YYmyQXglbEewzL3IA2Sd)==MM2BQ7xrAfNivgenXPytGYOs0DEHRC(u"࠴ၞ"): return pEo8g7riWVL014KaRtzQ(u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦ࡛ࠣࡆ࡚ࡃࡉࡘࡌࡈࡊࡕࠧ౹"),[],[]
	return pEo8g7riWVL014KaRtzQ(u"ࠩࠪ౺"),xCLQK8kh39sjyi5DXSZAVeI,YYmyQXglbEewzL3IA2Sd
def VzhTg5iUbqaBln7GroD0mMjd8He(url):
	RRucmYBaXegTtNOdGHMQ = gSmqZU0plur2xKPJwQA(u"ࠪࠫ౻")
	if OVmSuf8tpd(u"࠶ၟ") or FhcnOB9t3frzvXb(u"ࠫࡐ࡫ࡹ࠾ࠩ౼") not in url:
		lQHXdV9Nzf6BLqS8D = url.replace(JMLhEyaBWmskovGHTrVCxQ08(u"ࠬࡻࡰࡣࡱࡰ࠲ࡱ࡯ࡶࡦࠩ౽"),OVmSuf8tpd(u"࠭ࡵࡱࡲࡲࡱ࠳ࡲࡩࡷࡧࠪ౾"))
		lQHXdV9Nzf6BLqS8D = lQHXdV9Nzf6BLqS8D.split(FhcnOB9t3frzvXb(u"ࠧ࠰ࠩ౿"))
		id = lQHXdV9Nzf6BLqS8D[fR68jBGWCzUsFXdlTKPOScugm(u"࠹ၠ")]
		lQHXdV9Nzf6BLqS8D = XogUJZEijT7KWbxeO6(u"ࠨ࠱ࠪಀ").join(lQHXdV9Nzf6BLqS8D[bdhQDyjm3nPwToFHkprvCzBLUGR(u"࠰ၡ"):OVmSuf8tpd(u"࠵ၢ")])
		VbZ1Pig043uIGYQ = {XogUJZEijT7KWbxeO6(u"ࠩ࡬ࡨࠬಁ"):id,ffCSGrTJYPsxgVQWKLtHU3iMwB(u"ࠪࡳࡵ࠭ಂ"):gnfv8UtZ3daGqpjzk(u"ࠫࡩࡵࡷ࡯࡮ࡲࡥࡩ࠸ࠧಃ"),ffCSGrTJYPsxgVQWKLtHU3iMwB(u"ࠬࡳࡥࡵࡪࡲࡨࡤ࡬ࡲࡦࡧࠪ಄"):JMLhEyaBWmskovGHTrVCxQ08(u"࠭ࡆࡳࡧࡨ࠯ࡉࡵࡷ࡯࡮ࡲࡥࡩ࠱ࠥ࠴ࡇࠨ࠷ࡊ࠭ಅ")}
		wpFmEA3z8JR = A6F71g3cqN4(dALVaOWB4jKN3Tbt0Cm1ns9k5u,FhcnOB9t3frzvXb(u"ࠧࡑࡑࡖࡘࠬಆ"),lQHXdV9Nzf6BLqS8D,VbZ1Pig043uIGYQ,Ej67fFyoqW8kbV2HdSK(u"ࠨࠩಇ"),yTMWeCgUROcvtsblfK85L62xPk(u"ࠩࠪಈ"),FhcnOB9t3frzvXb(u"ࠪࠫಉ"),JMLhEyaBWmskovGHTrVCxQ08(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡖࡒࡅࡓࡒ࠳࠱ࡴࡶࠪಊ"))
		if aVLSn1xw5cK(u"ࠬࡒ࡯ࡤࡣࡷ࡭ࡴࡴࠧಋ") in list(wpFmEA3z8JR.headers.keys()): RRucmYBaXegTtNOdGHMQ = wpFmEA3z8JR.headers[LmcNhzY6fQPd2JyCGslkSr(u"࠭ࡌࡰࡥࡤࡸ࡮ࡵ࡮ࠨಌ")]
		if not RRucmYBaXegTtNOdGHMQ and wpFmEA3z8JR.succeeded:
			QstumvzTIEUMXCcx06aD4y8nSqH = wpFmEA3z8JR.content
			RRucmYBaXegTtNOdGHMQ = ZXFs0mEPR8qI2zj.findall(AAgpHN0nMZ(u"ࠧࡪࡦࡀࠦࡩ࡯ࡲࡦࡥࡷࡣࡱ࡯࡮࡬ࠤ࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ಍"),QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
			if RRucmYBaXegTtNOdGHMQ: RRucmYBaXegTtNOdGHMQ = RRucmYBaXegTtNOdGHMQ[sArCMRngQNmXkBoKv(u"࠲ၣ")]
	else:
		wpFmEA3z8JR = A6F71g3cqN4(dALVaOWB4jKN3Tbt0Cm1ns9k5u,wwyUWMFAsO(u"ࠨࡉࡈࡘࠬಎ"),url,DLSVmlyBbCK(u"ࠩࠪಏ"),XogUJZEijT7KWbxeO6(u"ࠪࠫಐ"),sArCMRngQNmXkBoKv(u"ࠫࠬ಑"),JMLhEyaBWmskovGHTrVCxQ08(u"ࠬ࠭ಒ"),AAgpHN0nMZ(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡘࡔࡇࡕࡍ࠮࠴ࡱࡨࠬಓ"))
		if ffCSGrTJYPsxgVQWKLtHU3iMwB(u"ࠧ࡭ࡱࡦࡥࡹ࡯࡯࡯ࠩಔ") in list(wpFmEA3z8JR.headers.keys()): RRucmYBaXegTtNOdGHMQ = wpFmEA3z8JR.headers[Ej67fFyoqW8kbV2HdSK(u"ࠨ࡮ࡲࡧࡦࡺࡩࡰࡰࠪಕ")]
	if RRucmYBaXegTtNOdGHMQ: return Ej67fFyoqW8kbV2HdSK(u"ࠩࠪಖ"),[sArCMRngQNmXkBoKv(u"ࠪࠫಗ")],[RRucmYBaXegTtNOdGHMQ]
	return sArCMRngQNmXkBoKv(u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡕࡑࡄࡒࡑࠬಘ"),[],[]
def JGyIOL4U0qQtkTHioeYnVrWaz(url):
	headers = { ffCSGrTJYPsxgVQWKLtHU3iMwB(u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩಙ") : jYaM5vilgZdFx6QHbApwVXO8et(u"࠭ࠧಚ") }
	QstumvzTIEUMXCcx06aD4y8nSqH = QuWA3hsmIvockZDiy2rLg(dALVaOWB4jKN3Tbt0Cm1ns9k5u,url,kmdSKeBIwViM9t3(u"ࠧࠨಛ"),headers,LmcNhzY6fQPd2JyCGslkSr(u"ࠨࠩಜ"),eeIL1TfgFQJaKqVD8hGNPEZ(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡒࡉࡊࡘࡌࡈࡊࡕ࠭࠲ࡵࡷࠫಝ"))
	items = ZXFs0mEPR8qI2zj.findall(gnfv8UtZ3daGqpjzk(u"ࠪࡷࡴࡻࡲࡤࡧࡶ࠾࠳࠰࠿ࠣࠪ࠱࠮ࡄ࠯ࠢ࠭ࠤࠫ࠲࠯ࡅࠩࠣࠩಞ"),QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	xCLQK8kh39sjyi5DXSZAVeI,YYmyQXglbEewzL3IA2Sd = [],[]
	if items:
		xCLQK8kh39sjyi5DXSZAVeI.append(Ej67fFyoqW8kbV2HdSK(u"ࠫࡲࡶ࠴ࠨಟ"))
		YYmyQXglbEewzL3IA2Sd.append(items[EDPaWgMt1SwNn8o(u"࠴ၥ")][bdhQDyjm3nPwToFHkprvCzBLUGR(u"࠴ၤ")])
		xCLQK8kh39sjyi5DXSZAVeI.append(JcDaEHuiS8TqBbOhWe4ZgwknoC1L3r(u"ࠬࡳ࠳ࡶ࠺ࠪಠ"))
		YYmyQXglbEewzL3IA2Sd.append(items[kRYWcNuAazr4jtmBoxFVS19Z6(u"࠵ၦ")][kRYWcNuAazr4jtmBoxFVS19Z6(u"࠵ၦ")])
		return ZSJVq5XDrRot(u"࠭ࠧಡ"),xCLQK8kh39sjyi5DXSZAVeI,YYmyQXglbEewzL3IA2Sd
	else: return JMLhEyaBWmskovGHTrVCxQ08(u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥࠢࡏࡍࡎ࡜ࡉࡅࡇࡒࠫಢ"),[],[]
def gmlsMyZIhB(url):
	id = url.split(EDPaWgMt1SwNn8o(u"ࠨ࠱ࠪಣ"))[-bdhQDyjm3nPwToFHkprvCzBLUGR(u"࠷ၧ")]
	id = id.split(OVmSuf8tpd(u"ࠩࠩࠫತ"))[J3OCAmZVcn(u"࠰ၨ")]
	id = id.replace(aFQoGfmYKyqLU6X8libw9k3ncW5(u"ࠪࡻࡦࡺࡣࡩࡁࡹࡁࠬಥ"),xuYvdJpOEyQKTLNwb(u"ࠫࠬದ"))
	lQHXdV9Nzf6BLqS8D = uReHcEzxkTm6pN4Q[JcDaEHuiS8TqBbOhWe4ZgwknoC1L3r(u"ࠬ࡟ࡏࡖࡖࡘࡆࡊ࠭ಧ")][XogUJZEijT7KWbxeO6(u"࠱ၩ")]+m6b7CoBk4EQ(u"࠭࠯ࡸࡣࡷࡧ࡭ࡅࡶ࠾ࠩನ")+id
	ai5kI9sPDUH2BZw7V = DLSVmlyBbCK(u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡺࡱࡸࡸࡺ࠴ࡢࡦ࠱ࠪ಩")+id
	Jt7EANGgL8,icNLw6X3Pkjo95al1IOQA8qmFW,N65nUTfSGL42PtavZDeqyjBIw,gt2RuaDQ683IWeY4fyoLjhpX01xN7 = DLSVmlyBbCK(u"ࠨࠩಪ"),aFQoGfmYKyqLU6X8libw9k3ncW5(u"ࠩࠪಫ"),yTMWeCgUROcvtsblfK85L62xPk(u"ࠪࠫಬ"),Ej67fFyoqW8kbV2HdSK(u"ࠫࠬಭ")
	headers = {bdhQDyjm3nPwToFHkprvCzBLUGR(u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩಮ"):xuYvdJpOEyQKTLNwb(u"࠭ࠧಯ")}
	for OeT2Jo0sp6h1mGdqfFw in range(kRYWcNuAazr4jtmBoxFVS19Z6(u"࠷ၪ")):
		wpFmEA3z8JR = A6F71g3cqN4(KxirmCLT6Gw,JcDaEHuiS8TqBbOhWe4ZgwknoC1L3r(u"ࠧࡈࡇࡗࠫರ"),lQHXdV9Nzf6BLqS8D,JcDaEHuiS8TqBbOhWe4ZgwknoC1L3r(u"ࠨࠩಱ"),headers,JcDaEHuiS8TqBbOhWe4ZgwknoC1L3r(u"ࠩࠪಲ"),FhcnOB9t3frzvXb(u"ࠪࠫಳ"),kRYWcNuAazr4jtmBoxFVS19Z6(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࡚࠭ࡑࡘࡘ࡚ࡈࡅ࠮࠳ࡶࡸࠬ಴"))
		QstumvzTIEUMXCcx06aD4y8nSqH = wpFmEA3z8JR.content
		if AAgpHN0nMZ(u"ࠬ࡯ࡴࡢࡩࠪವ") in QstumvzTIEUMXCcx06aD4y8nSqH: break
		luMHeSgCBaPrb9KvUjNFqcR.sleep(MM2BQ7xrAfNivgenXPytGYOs0DEHRC(u"࠵ၫ"))
	U9EPiz13FOSaL8YANvhQWKMktDZ = ZXFs0mEPR8qI2zj.findall(EDPaWgMt1SwNn8o(u"࠭ࡶࡢࡴࠣࡽࡹࡏ࡮ࡪࡶ࡬ࡥࡱࡖ࡬ࡢࡻࡨࡶࡗ࡫ࡳࡱࡱࡱࡷࡪࠦ࠽ࠡࠪ࠱࠮ࡄ࠯࠻࠽࠱ࡶࡧࡷ࡯ࡰࡵࡀࠪಶ"),QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	if U9EPiz13FOSaL8YANvhQWKMktDZ: U9EPiz13FOSaL8YANvhQWKMktDZ = U9EPiz13FOSaL8YANvhQWKMktDZ[DLSVmlyBbCK(u"࠴ၬ")]
	else: U9EPiz13FOSaL8YANvhQWKMktDZ = QstumvzTIEUMXCcx06aD4y8nSqH
	U9EPiz13FOSaL8YANvhQWKMktDZ = U9EPiz13FOSaL8YANvhQWKMktDZ.replace(xuYvdJpOEyQKTLNwb(u"ࠧ࡝࡞ࡸ࠴࠵࠸࠶ࠨಷ"),Ej67fFyoqW8kbV2HdSK(u"ࠨࠨࠪಸ"))
	YZ4rq9g1mMC = NL0JIkbrEWqTYj61vVKGCnBw37MsOF(kmdSKeBIwViM9t3(u"ࠩࡧ࡭ࡨࡺࠧಹ"),U9EPiz13FOSaL8YANvhQWKMktDZ)
	xCLQK8kh39sjyi5DXSZAVeI,YYmyQXglbEewzL3IA2Sd = [JcDaEHuiS8TqBbOhWe4ZgwknoC1L3r(u"ࠪฬิ๎ๆࠡฬิะ๊ฯ๋๊ࠠอ๎ํฮࠧ಺")],[kmdSKeBIwViM9t3(u"ࠫࠬ಻")]
	try:
		zdaQvnBRZos7bwGfm = YZ4rq9g1mMC[EDPaWgMt1SwNn8o(u"ࠬࡩࡡࡱࡶ࡬ࡳࡳࡹ಼ࠧ")][wwyUWMFAsO(u"࠭ࡰ࡭ࡣࡼࡩࡷࡉࡡࡱࡶ࡬ࡳࡳࡹࡔࡳࡣࡦ࡯ࡱ࡯ࡳࡵࡔࡨࡲࡩ࡫ࡲࡦࡴࠪಽ")][jYaM5vilgZdFx6QHbApwVXO8et(u"ࠧࡤࡣࡳࡸ࡮ࡵ࡮ࡕࡴࡤࡧࡰࡹࠧಾ")]
		for KrX5MpgZ01z in zdaQvnBRZos7bwGfm:
			RRucmYBaXegTtNOdGHMQ = KrX5MpgZ01z[J3OCAmZVcn(u"ࠨࡤࡤࡷࡪ࡛ࡲ࡭ࠩಿ")]
			try: title = KrX5MpgZ01z[jYaM5vilgZdFx6QHbApwVXO8et(u"ࠩࡱࡥࡲ࡫ࠧೀ")][J3OCAmZVcn(u"ࠪࡷ࡮ࡳࡰ࡭ࡧࡗࡩࡽࡺࠧು")]
			except: title = KrX5MpgZ01z[MM2BQ7xrAfNivgenXPytGYOs0DEHRC(u"ࠫࡳࡧ࡭ࡦࠩೂ")][JMLhEyaBWmskovGHTrVCxQ08(u"ࠬࡸࡵ࡯ࡵࠪೃ")][eeIL1TfgFQJaKqVD8hGNPEZ(u"࠵ၭ")][AAgpHN0nMZ(u"࠭ࡴࡦࡺࡷࡸࠬೄ")]
			YYmyQXglbEewzL3IA2Sd.append(RRucmYBaXegTtNOdGHMQ)
			xCLQK8kh39sjyi5DXSZAVeI.append(title)
	except: pass
	if len(xCLQK8kh39sjyi5DXSZAVeI)>kRYWcNuAazr4jtmBoxFVS19Z6(u"࠷ၮ"):
		jQ6w8xOrgYhSHIRpUqzL = F2yZPukcUh09sqCI8nYw7e(xuYvdJpOEyQKTLNwb(u"ࠧศะอีࠥอไหำฯ้ฮࠦวๅ็้หุฮษ࠻ࠩ೅"), xCLQK8kh39sjyi5DXSZAVeI)
		if jQ6w8xOrgYhSHIRpUqzL==-JMLhEyaBWmskovGHTrVCxQ08(u"࠱ၯ"): return XogUJZEijT7KWbxeO6(u"ࠨࡇ࡛ࡍ࡙ࡥࡁࡍࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭ೆ"),[],[]
		elif jQ6w8xOrgYhSHIRpUqzL!=ZSJVq5XDrRot(u"࠱ၰ"):
			RRucmYBaXegTtNOdGHMQ = YYmyQXglbEewzL3IA2Sd[jQ6w8xOrgYhSHIRpUqzL]+MM2BQ7xrAfNivgenXPytGYOs0DEHRC(u"ࠩࠩࠫೇ")
			nZzsdF8vXAya = ZXFs0mEPR8qI2zj.findall(FhcnOB9t3frzvXb(u"ࠪࠪ࠭࡬࡭ࡵ࠿࠱࠮ࡄ࠯ࠦࠨೈ"),RRucmYBaXegTtNOdGHMQ)
			if nZzsdF8vXAya: RRucmYBaXegTtNOdGHMQ = RRucmYBaXegTtNOdGHMQ.replace(nZzsdF8vXAya[bdhQDyjm3nPwToFHkprvCzBLUGR(u"࠲ၱ")],gnfv8UtZ3daGqpjzk(u"ࠫ࡫ࡳࡴ࠾ࡸࡷࡸࠬ೉"))
			else: RRucmYBaXegTtNOdGHMQ = RRucmYBaXegTtNOdGHMQ+J3OCAmZVcn(u"ࠬ࡬࡭ࡵ࠿ࡹࡸࡹ࠭ೊ")
			Jt7EANGgL8 = RRucmYBaXegTtNOdGHMQ.strip(kmdSKeBIwViM9t3(u"࠭ࠦࠨೋ"))
	x5DI8O7FaJkiNMf02nbC41wBg,sp72PVkRvre0l,twySvoRx389IhDG0zJP,vvQbNc0CIAD2JEe9jGZ7wxlomMO3yf,nd2Tek5z8DvtbKBuO0WcfgMY = [],[],[],[],[]
	try: icNLw6X3Pkjo95al1IOQA8qmFW = YZ4rq9g1mMC[aFQoGfmYKyqLU6X8libw9k3ncW5(u"ࠧࡴࡶࡵࡩࡦࡳࡩ࡯ࡩࡇࡥࡹࡧࠧೌ")][aFQoGfmYKyqLU6X8libw9k3ncW5(u"ࠨࡦࡤࡷ࡭ࡓࡡ࡯࡫ࡩࡩࡸࡺࡕࡳ࡮್ࠪ")]
	except: pass
	try: N65nUTfSGL42PtavZDeqyjBIw = YZ4rq9g1mMC[m6b7CoBk4EQ(u"ࠩࡶࡸࡷ࡫ࡡ࡮࡫ࡱ࡫ࡉࡧࡴࡢࠩ೎")][ZSJVq5XDrRot(u"ࠪ࡬ࡱࡹࡍࡢࡰ࡬ࡪࡪࡹࡴࡖࡴ࡯ࠫ೏")]
	except: pass
	try: x5DI8O7FaJkiNMf02nbC41wBg = YZ4rq9g1mMC[JcDaEHuiS8TqBbOhWe4ZgwknoC1L3r(u"ࠫࡸࡺࡲࡦࡣࡰ࡭ࡳ࡭ࡄࡢࡶࡤࠫ೐")][pEo8g7riWVL014KaRtzQ(u"ࠬ࡬࡯ࡳ࡯ࡤࡸࡸ࠭೑")]
	except: pass
	try: sp72PVkRvre0l = YZ4rq9g1mMC[gSmqZU0plur2xKPJwQA(u"࠭ࡳࡵࡴࡨࡥࡲ࡯࡮ࡨࡆࡤࡸࡦ࠭೒")][aVLSn1xw5cK(u"ࠧࡢࡦࡤࡴࡹ࡯ࡶࡦࡈࡲࡶࡲࡧࡴࡴࠩ೓")]
	except: pass
	uu8Z5yIOdTtj3PrL0KHgMXhp6kJ = x5DI8O7FaJkiNMf02nbC41wBg+sp72PVkRvre0l
	for dict in uu8Z5yIOdTtj3PrL0KHgMXhp6kJ:
		if gSmqZU0plur2xKPJwQA(u"ࠨ࡫ࡷࡥ࡬࠭೔") in list(dict.keys()): dict[aVLSn1xw5cK(u"ࠩ࡬ࡸࡦ࡭ࠧೕ")] = str(dict[XogUJZEijT7KWbxeO6(u"ࠪ࡭ࡹࡧࡧࠨೖ")])
		if Ej67fFyoqW8kbV2HdSK(u"ࠫ࡫ࡶࡳࠨ೗") in list(dict.keys()): dict[yTMWeCgUROcvtsblfK85L62xPk(u"ࠬ࡬ࡰࡴࠩ೘")] = str(dict[xuYvdJpOEyQKTLNwb(u"࠭ࡦࡱࡵࠪ೙")])
		if OVmSuf8tpd(u"ࠧ࡮࡫ࡰࡩ࡙ࡿࡰࡦࠩ೚") in list(dict.keys()): dict[LmcNhzY6fQPd2JyCGslkSr(u"ࠨࡶࡼࡴࡪ࠭೛")] = dict[jYaM5vilgZdFx6QHbApwVXO8et(u"ࠩࡰ࡭ࡲ࡫ࡔࡺࡲࡨࠫ೜")]
		if JcDaEHuiS8TqBbOhWe4ZgwknoC1L3r(u"ࠪࡥࡺࡪࡩࡰࡕࡤࡱࡵࡲࡥࡓࡣࡷࡩࠬೝ") in list(dict.keys()): dict[m6b7CoBk4EQ(u"ࠫࡦࡻࡤࡪࡱࡢࡷࡦࡳࡰ࡭ࡧࡢࡶࡦࡺࡥࠨೞ")] = str(dict[PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"ࠬࡧࡵࡥ࡫ࡲࡗࡦࡳࡰ࡭ࡧࡕࡥࡹ࡫ࠧ೟")])
		if eeIL1TfgFQJaKqVD8hGNPEZ(u"࠭ࡡࡶࡦ࡬ࡳࡈ࡮ࡡ࡯ࡰࡨࡰࡸ࠭ೠ") in list(dict.keys()): dict[Ej67fFyoqW8kbV2HdSK(u"ࠧࡢࡷࡧ࡭ࡴࡥࡣࡩࡣࡱࡲࡪࡲࡳࠨೡ")] = str(dict[FhcnOB9t3frzvXb(u"ࠨࡣࡸࡨ࡮ࡵࡃࡩࡣࡱࡲࡪࡲࡳࠨೢ")])
		if ffCSGrTJYPsxgVQWKLtHU3iMwB(u"ࠩࡺ࡭ࡩࡺࡨࠨೣ") in list(dict.keys()): dict[c4QSTnPiWUCjhrLlwGB(u"ࠪࡷ࡮ࢀࡥࠨ೤")] = str(dict[ffCSGrTJYPsxgVQWKLtHU3iMwB(u"ࠫࡼ࡯ࡤࡵࡪࠪ೥")])+bdhQDyjm3nPwToFHkprvCzBLUGR(u"ࠬࡾࠧ೦")+str(dict[jYaM5vilgZdFx6QHbApwVXO8et(u"࠭ࡨࡦ࡫ࡪ࡬ࡹ࠭೧")])
		if JMLhEyaBWmskovGHTrVCxQ08(u"ࠧࡪࡰ࡬ࡸࡗࡧ࡮ࡨࡧࠪ೨") in list(dict.keys()): dict[hjNP5w9srJz2QpVISxBfndbD4CkXvl(u"ࠨ࡫ࡱ࡭ࡹ࠭೩")] = dict[AAgpHN0nMZ(u"ࠩ࡬ࡲ࡮ࡺࡒࡢࡰࡪࡩࠬ೪")][c4QSTnPiWUCjhrLlwGB(u"ࠪࡷࡹࡧࡲࡵࠩ೫")]+Ej67fFyoqW8kbV2HdSK(u"ࠫ࠲࠭೬")+dict[wwyUWMFAsO(u"ࠬ࡯࡮ࡪࡶࡕࡥࡳ࡭ࡥࠨ೭")][c4QSTnPiWUCjhrLlwGB(u"࠭ࡥ࡯ࡦࠪ೮")]
		if XogUJZEijT7KWbxeO6(u"ࠧࡪࡰࡧࡩࡽࡘࡡ࡯ࡩࡨࠫ೯") in list(dict.keys()): dict[AAgpHN0nMZ(u"ࠨ࡫ࡱࡨࡪࡾࠧ೰")] = dict[hjNP5w9srJz2QpVISxBfndbD4CkXvl(u"ࠩ࡬ࡲࡩ࡫ࡸࡓࡣࡱ࡫ࡪ࠭ೱ")][jYaM5vilgZdFx6QHbApwVXO8et(u"ࠪࡷࡹࡧࡲࡵࠩೲ")]+bdhQDyjm3nPwToFHkprvCzBLUGR(u"ࠫ࠲࠭ೳ")+dict[bdhQDyjm3nPwToFHkprvCzBLUGR(u"ࠬ࡯࡮ࡥࡧࡻࡖࡦࡴࡧࡦࠩ೴")][hjNP5w9srJz2QpVISxBfndbD4CkXvl(u"࠭ࡥ࡯ࡦࠪ೵")]
		if AAgpHN0nMZ(u"ࠧࡢࡸࡨࡶࡦ࡭ࡥࡃ࡫ࡷࡶࡦࡺࡥࠨ೶") in list(dict.keys()): dict[XogUJZEijT7KWbxeO6(u"ࠨࡤ࡬ࡸࡷࡧࡴࡦࠩ೷")] = dict[EDPaWgMt1SwNn8o(u"ࠩࡤࡺࡪࡸࡡࡨࡧࡅ࡭ࡹࡸࡡࡵࡧࠪ೸")]
		if PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"ࠪࡦ࡮ࡺࡲࡢࡶࡨࠫ೹") in list(dict.keys()) and int(dict[OVmSuf8tpd(u"ࠫࡧ࡯ࡴࡳࡣࡷࡩࠬ೺")])>LmcNhzY6fQPd2JyCGslkSr(u"࠴࠵࠶࠸࠲࠳࠵࠶࠷ၲ"): del dict[fR68jBGWCzUsFXdlTKPOScugm(u"ࠬࡨࡩࡵࡴࡤࡸࡪ࠭೻")]
		if FhcnOB9t3frzvXb(u"࠭ࡳࡪࡩࡱࡥࡹࡻࡲࡦࡅ࡬ࡴ࡭࡫ࡲࠨ೼") in list(dict.keys()):
			uumg4d5zIGnVwaoy9Q = dict[aVLSn1xw5cK(u"ࠧࡴ࡫ࡪࡲࡦࡺࡵࡳࡧࡆ࡭ࡵ࡮ࡥࡳࠩ೽")].split(AAgpHN0nMZ(u"ࠨࠨࠪ೾"))
			for q8BXZlN9sU1fP2JAxH7W in uumg4d5zIGnVwaoy9Q:
				key,AARNPWHjQU9dEmDI = q8BXZlN9sU1fP2JAxH7W.split(gSmqZU0plur2xKPJwQA(u"ࠩࡀࠫ೿"),kmdSKeBIwViM9t3(u"࠵ၳ"))
				dict[key] = ejBOu2WXwvb4YpITdsLF16(AARNPWHjQU9dEmDI)
		if m6b7CoBk4EQ(u"ࠪࡹࡷࡲࠧഀ") in list(dict.keys()): dict[sArCMRngQNmXkBoKv(u"ࠫࡺࡸ࡬ࠨഁ")] = ejBOu2WXwvb4YpITdsLF16(dict[Ej67fFyoqW8kbV2HdSK(u"ࠬࡻࡲ࡭ࠩം")])
		twySvoRx389IhDG0zJP.append(dict)
	jJ7ICsqrzTWS4pNeLDBAn6m = DLSVmlyBbCK(u"࠭ࠧഃ")
	if OVmSuf8tpd(u"ࠧࡴࡲࡀࡷ࡮࡭ࠧഄ") in U9EPiz13FOSaL8YANvhQWKMktDZ:
		eBfD4ZycFrC7qRMSjgw = ZXFs0mEPR8qI2zj.findall(jYaM5vilgZdFx6QHbApwVXO8et(u"ࠨࡵࡵࡧࡂࠨࠨ࠰ࡵ࠲ࡴࡱࡧࡹࡦࡴ࠲ࡠࡼ࠰࠿࠰ࡲ࡯ࡥࡾ࡫ࡲࡠ࡫ࡤࡷ࠳ࡼࡦ࡭ࡵࡨࡸ࠴࡫࡮ࡠ࠰࠱࠳ࡧࡧࡳࡦ࠰࡭ࡷ࠮ࠨࠧഅ"),QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
		if eBfD4ZycFrC7qRMSjgw:
			eBfD4ZycFrC7qRMSjgw = uReHcEzxkTm6pN4Q[AAgpHN0nMZ(u"ࠩ࡜ࡓ࡚࡚ࡕࡃࡇࠪആ")][kmdSKeBIwViM9t3(u"࠵ၴ")]+eBfD4ZycFrC7qRMSjgw[kmdSKeBIwViM9t3(u"࠵ၴ")]
			wpFmEA3z8JR = A6F71g3cqN4(KxirmCLT6Gw,aVLSn1xw5cK(u"ࠪࡋࡊ࡚ࠧഇ"),eBfD4ZycFrC7qRMSjgw,Ej67fFyoqW8kbV2HdSK(u"ࠫࠬഈ"),XogUJZEijT7KWbxeO6(u"ࠬ࠭ഉ"),bdhQDyjm3nPwToFHkprvCzBLUGR(u"࠭ࠧഊ"),kmdSKeBIwViM9t3(u"ࠧࠨഋ"),gnfv8UtZ3daGqpjzk(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱࡞ࡕࡕࡕࡗࡅࡉ࠲࠸࡮ࡥࠩഌ"))
			jJ7ICsqrzTWS4pNeLDBAn6m = wpFmEA3z8JR.content
			import youtube_signature.cipher as EQP4CjNbD5yxHLvuI3e6q,youtube_signature.json_script_engine as XXz73VW9fQNZu
			uumg4d5zIGnVwaoy9Q = eEq19cJUyv8GmRrnOfoN4tDaQw.uumg4d5zIGnVwaoy9Q.Cipher()
			uumg4d5zIGnVwaoy9Q._object_cache = {}
			SWJt3Pdw0O1xaulE8HKi = uumg4d5zIGnVwaoy9Q._load_javascript(jJ7ICsqrzTWS4pNeLDBAn6m)
			pmWHfPJoVuvxhNj0TkyLOFcb = NL0JIkbrEWqTYj61vVKGCnBw37MsOF(sArCMRngQNmXkBoKv(u"ࠩࡶࡸࡷ࠭഍"),str(SWJt3Pdw0O1xaulE8HKi))
			agIt7YDOmdyboHPRS = eEq19cJUyv8GmRrnOfoN4tDaQw.l8g2U0uDosh9EVBn.JsonScriptEngine(pmWHfPJoVuvxhNj0TkyLOFcb)
	for dict in twySvoRx389IhDG0zJP:
		url = dict[hjNP5w9srJz2QpVISxBfndbD4CkXvl(u"ࠪࡹࡷࡲࠧഎ")]
		if kRYWcNuAazr4jtmBoxFVS19Z6(u"ࠫࡸ࡯ࡧ࡯ࡣࡷࡹࡷ࡫࠽ࠨഏ") in url or url.count(XogUJZEijT7KWbxeO6(u"ࠬࡹࡩࡨ࠿ࠪഐ"))>EDPaWgMt1SwNn8o(u"࠷ၵ"):
			vvQbNc0CIAD2JEe9jGZ7wxlomMO3yf.append(dict)
		elif jJ7ICsqrzTWS4pNeLDBAn6m and xuYvdJpOEyQKTLNwb(u"࠭ࡳࠨ഑") in list(dict.keys()) and c4QSTnPiWUCjhrLlwGB(u"ࠧࡴࡲࠪഒ") in list(dict.keys()):
			R9LCqIbT8P2tGaEi3S1MpdeNlh = agIt7YDOmdyboHPRS.execute(dict[aVLSn1xw5cK(u"ࠨࡵࠪഓ")])
			if R9LCqIbT8P2tGaEi3S1MpdeNlh!=dict[yTMWeCgUROcvtsblfK85L62xPk(u"ࠩࡶࠫഔ")]:
				dict[MM2BQ7xrAfNivgenXPytGYOs0DEHRC(u"ࠪࡹࡷࡲࠧക")] = url+EDPaWgMt1SwNn8o(u"ࠫࠫ࠭ഖ")+dict[kmdSKeBIwViM9t3(u"ࠬࡹࡰࠨഗ")]+eeIL1TfgFQJaKqVD8hGNPEZ(u"࠭࠽ࠨഘ")+R9LCqIbT8P2tGaEi3S1MpdeNlh
				vvQbNc0CIAD2JEe9jGZ7wxlomMO3yf.append(dict)
	for dict in vvQbNc0CIAD2JEe9jGZ7wxlomMO3yf:
		P1ajYzT8sKCx6tMl,DDqYO5C6irlyu8MQgPh,SX79agIpuDv3WPbm,DOVwrFbPi1kIm8n,sTp9WCtAKHVciNFnh6,TzMbHrQSJ5AVKxmOY = gSmqZU0plur2xKPJwQA(u"ࠧࡶࡰ࡮ࡲࡴࡽ࡮ࠨങ"),sArCMRngQNmXkBoKv(u"ࠨࡷࡱ࡯ࡳࡵࡷ࡯ࠩച"),aFQoGfmYKyqLU6X8libw9k3ncW5(u"ࠩࡸࡲࡰࡴ࡯ࡸࡰࠪഛ"),PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"࡙ࠪࡳࡱ࡮ࡰࡹࡱࠫജ"),aFQoGfmYKyqLU6X8libw9k3ncW5(u"ࠫࠬഝ"),m6b7CoBk4EQ(u"ࠬ࠶ࠧഞ")
		try:
			mm7CsuLEc1G6j = dict[kRYWcNuAazr4jtmBoxFVS19Z6(u"࠭ࡴࡺࡲࡨࠫട")]
			mm7CsuLEc1G6j = mm7CsuLEc1G6j.replace(bdhQDyjm3nPwToFHkprvCzBLUGR(u"ࠧࠬࠩഠ"),kmdSKeBIwViM9t3(u"ࠨࠩഡ"))
			items = ZXFs0mEPR8qI2zj.findall(OVmSuf8tpd(u"ࠩࠫ࠲࠯ࡅࠩ࠰ࠪ࠱࠮ࡄ࠯࠻࠯ࠬࡂࠦ࠭࠴ࠪࡀࠫࠥࠫഢ"),mm7CsuLEc1G6j,ZXFs0mEPR8qI2zj.DOTALL)
			DOVwrFbPi1kIm8n,P1ajYzT8sKCx6tMl,sTp9WCtAKHVciNFnh6 = items[DLSVmlyBbCK(u"࠰ၶ")]
			bdc87l409zBYpMq5T = sTp9WCtAKHVciNFnh6.split(DLSVmlyBbCK(u"ࠪ࠰ࠬണ"))
			DDqYO5C6irlyu8MQgPh = gnfv8UtZ3daGqpjzk(u"ࠫࠬത")
			for q8BXZlN9sU1fP2JAxH7W in bdc87l409zBYpMq5T: DDqYO5C6irlyu8MQgPh += q8BXZlN9sU1fP2JAxH7W.split(gSmqZU0plur2xKPJwQA(u"ࠬ࠴ࠧഥ"))[c4QSTnPiWUCjhrLlwGB(u"࠱ၷ")]+OVmSuf8tpd(u"࠭ࠬࠨദ")
			DDqYO5C6irlyu8MQgPh = DDqYO5C6irlyu8MQgPh.strip(Ej67fFyoqW8kbV2HdSK(u"ࠧ࠭ࠩധ"))
			if MM2BQ7xrAfNivgenXPytGYOs0DEHRC(u"ࠨࡤ࡬ࡸࡷࡧࡴࡦࠩന") in list(dict.keys()): TzMbHrQSJ5AVKxmOY = str(float(dict[bdhQDyjm3nPwToFHkprvCzBLUGR(u"ࠩࡥ࡭ࡹࡸࡡࡵࡧࠪഩ")]*aFQoGfmYKyqLU6X8libw9k3ncW5(u"࠳࠳ၸ"))//XogUJZEijT7KWbxeO6(u"࠴࠴࠷࠺ၹ")/aFQoGfmYKyqLU6X8libw9k3ncW5(u"࠳࠳ၸ"))+Ej67fFyoqW8kbV2HdSK(u"ࠪ࡯ࡧࡶࡳࠡࠢࠪപ")
			else: TzMbHrQSJ5AVKxmOY = kRYWcNuAazr4jtmBoxFVS19Z6(u"ࠫࠬഫ")
			if DOVwrFbPi1kIm8n==xuYvdJpOEyQKTLNwb(u"ࠬࡺࡥࡹࡶࡷࠫബ"): continue
			elif yTMWeCgUROcvtsblfK85L62xPk(u"࠭ࠬࠨഭ") in mm7CsuLEc1G6j:
				DOVwrFbPi1kIm8n = sArCMRngQNmXkBoKv(u"ࠧࡂ࡙࠭ࠫമ")
				SX79agIpuDv3WPbm = P1ajYzT8sKCx6tMl+ffCSGrTJYPsxgVQWKLtHU3iMwB(u"ࠨࠢࠣࠫയ")+TzMbHrQSJ5AVKxmOY+dict[aVLSn1xw5cK(u"ࠩࡶ࡭ࡿ࡫ࠧര")].split(MM2BQ7xrAfNivgenXPytGYOs0DEHRC(u"ࠪࡼࠬറ"))[FhcnOB9t3frzvXb(u"࠵ၺ")]
			elif DOVwrFbPi1kIm8n==Ej67fFyoqW8kbV2HdSK(u"ࠫࡻ࡯ࡤࡦࡱࠪല"):
				DOVwrFbPi1kIm8n = J3OCAmZVcn(u"ࠬ࡜ࡩࡥࡧࡲࠫള")
				SX79agIpuDv3WPbm = TzMbHrQSJ5AVKxmOY+dict[eeIL1TfgFQJaKqVD8hGNPEZ(u"࠭ࡳࡪࡼࡨࠫഴ")].split(eeIL1TfgFQJaKqVD8hGNPEZ(u"ࠧࡹࠩവ"))[XogUJZEijT7KWbxeO6(u"࠶ၻ")]+AAgpHN0nMZ(u"ࠨࠢࠣࠫശ")+dict[c4QSTnPiWUCjhrLlwGB(u"ࠩࡩࡴࡸ࠭ഷ")]+FhcnOB9t3frzvXb(u"ࠪࡪࡵࡹࠧസ")+wwyUWMFAsO(u"ࠫࠥࠦࠧഹ")+P1ajYzT8sKCx6tMl
			elif DOVwrFbPi1kIm8n==PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"ࠬࡧࡵࡥ࡫ࡲࠫഺ"):
				DOVwrFbPi1kIm8n = c4QSTnPiWUCjhrLlwGB(u"࠭ࡁࡶࡦ࡬ࡳ഻ࠬ")
				SX79agIpuDv3WPbm = TzMbHrQSJ5AVKxmOY+str(int(dict[PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"ࠧࡢࡷࡧ࡭ࡴࡥࡳࡢ࡯ࡳࡰࡪࡥࡲࡢࡶࡨ഼ࠫ")])/JMLhEyaBWmskovGHTrVCxQ08(u"࠷࠰࠱࠲ၼ"))+ffCSGrTJYPsxgVQWKLtHU3iMwB(u"ࠨ࡭࡫ࡾࠥࠦࠧഽ")+dict[kmdSKeBIwViM9t3(u"ࠩࡤࡹࡩ࡯࡯ࡠࡥ࡫ࡥࡳࡴࡥ࡭ࡵࠪാ")]+wwyUWMFAsO(u"ࠪࡧ࡭࠭ി")+FhcnOB9t3frzvXb(u"ࠫࠥࠦࠧീ")+P1ajYzT8sKCx6tMl
		except:
			m0AGWhywZVXFtYQ = QQV1pDhCLqHP5a3sGvoUrJfmjXFw.format_exc()
			if m0AGWhywZVXFtYQ!=yTMWeCgUROcvtsblfK85L62xPk(u"ࠬࡔ࡯࡯ࡧࡗࡽࡵ࡫࠺ࠡࡐࡲࡲࡪࡢ࡮ࠨു"): ddABnr3K9Xv8e71CzcN0Pxt.stderr.write(m0AGWhywZVXFtYQ)
		if gSmqZU0plur2xKPJwQA(u"࠭ࡤࡶࡴࡀࠫൂ") in dict[aFQoGfmYKyqLU6X8libw9k3ncW5(u"ࠧࡶࡴ࡯ࠫൃ")]: UombAD0Kk4XqOrYLB = round(JMLhEyaBWmskovGHTrVCxQ08(u"࠲࠱࠹ၿ")+float(dict[aVLSn1xw5cK(u"ࠨࡷࡵࡰࠬൄ")].split(sArCMRngQNmXkBoKv(u"ࠩࡧࡹࡷࡃࠧ൅"),jYaM5vilgZdFx6QHbApwVXO8et(u"࠱ၽ"))[jYaM5vilgZdFx6QHbApwVXO8et(u"࠱ၽ")].split(LmcNhzY6fQPd2JyCGslkSr(u"ࠪࠪࠬെ"),jYaM5vilgZdFx6QHbApwVXO8et(u"࠱ၽ"))[ZSJVq5XDrRot(u"࠱ၾ")]))
		elif aFQoGfmYKyqLU6X8libw9k3ncW5(u"ࠫࡦࡶࡰࡳࡱࡻࡈࡺࡸࡡࡵ࡫ࡲࡲࡒࡹࠧേ") in list(dict.keys()): UombAD0Kk4XqOrYLB = round(JcDaEHuiS8TqBbOhWe4ZgwknoC1L3r(u"࠳࠲࠺ႀ")+float(dict[eeIL1TfgFQJaKqVD8hGNPEZ(u"ࠬࡧࡰࡱࡴࡲࡼࡉࡻࡲࡢࡶ࡬ࡳࡳࡓࡳࠨൈ")])/xuYvdJpOEyQKTLNwb(u"࠵࠵࠶࠰ႁ"))
		else: UombAD0Kk4XqOrYLB = hjNP5w9srJz2QpVISxBfndbD4CkXvl(u"࠭࠰ࠨ൉")
		if J3OCAmZVcn(u"ࠧࡣ࡫ࡷࡶࡦࡺࡥࠨൊ") not in list(dict.keys()): TzMbHrQSJ5AVKxmOY = dict[FhcnOB9t3frzvXb(u"ࠨࡵ࡬ࡾࡪ࠭ോ")].split(ffCSGrTJYPsxgVQWKLtHU3iMwB(u"ࠩࡻࠫൌ"))[OVmSuf8tpd(u"࠶ႂ")]
		else: TzMbHrQSJ5AVKxmOY = dict[fR68jBGWCzUsFXdlTKPOScugm(u"ࠪࡦ࡮ࡺࡲࡢࡶࡨ്ࠫ")]
		if AAgpHN0nMZ(u"ࠫ࡮ࡴࡩࡵࠩൎ") not in list(dict.keys()): dict[ffCSGrTJYPsxgVQWKLtHU3iMwB(u"ࠬ࡯࡮ࡪࡶࠪ൏")] = m6b7CoBk4EQ(u"࠭࠰࠮࠲ࠪ൐")
		dict[gnfv8UtZ3daGqpjzk(u"ࠧࡵ࡫ࡷࡰࡪ࠭൑")] = DOVwrFbPi1kIm8n+c4QSTnPiWUCjhrLlwGB(u"ࠨ࠼ࠣࠤࠬ൒")+SX79agIpuDv3WPbm+J3OCAmZVcn(u"ࠩࠣࠤ࠭࠭൓")+DDqYO5C6irlyu8MQgPh+aFQoGfmYKyqLU6X8libw9k3ncW5(u"ࠪ࠰ࠬൔ")+dict[sArCMRngQNmXkBoKv(u"ࠫ࡮ࡺࡡࡨࠩൕ")]+gnfv8UtZ3daGqpjzk(u"ࠬ࠯ࠧൖ")
		dict[c4QSTnPiWUCjhrLlwGB(u"࠭ࡱࡶࡣ࡯࡭ࡹࡿࠧൗ")] = SX79agIpuDv3WPbm.split(MM2BQ7xrAfNivgenXPytGYOs0DEHRC(u"ࠧࠡࠢࠪ൘"))[ZSJVq5XDrRot(u"࠶ႃ")].split(aFQoGfmYKyqLU6X8libw9k3ncW5(u"ࠨ࡭ࡥࡴࡸ࠭൙"))[ZSJVq5XDrRot(u"࠶ႃ")]
		dict[EDPaWgMt1SwNn8o(u"ࠩࡷࡽࡵ࡫࠲ࠨ൚")] = DOVwrFbPi1kIm8n
		dict[ffCSGrTJYPsxgVQWKLtHU3iMwB(u"ࠪࡪ࡮ࡲࡥࡵࡻࡳࡩࠬ൛")] = P1ajYzT8sKCx6tMl
		dict[aVLSn1xw5cK(u"ࠫࡨࡵࡤࡦࡥࡶࠫ൜")] = sTp9WCtAKHVciNFnh6
		dict[aFQoGfmYKyqLU6X8libw9k3ncW5(u"ࠬࡪࡵࡳࡣࡷ࡭ࡴࡴࠧ൝")] = UombAD0Kk4XqOrYLB
		dict[EDPaWgMt1SwNn8o(u"࠭ࡢࡪࡶࡵࡥࡹ࡫ࠧ൞")] = TzMbHrQSJ5AVKxmOY
		nd2Tek5z8DvtbKBuO0WcfgMY.append(dict)
	g9fFirP4WON2UT3pRaclSsteAYy8,eZWBHkcmaVlftsqOhUng5jNdovT10,KyES8tQXjPN2WipmFIuR5,KZl5I869eGPBwYsvXtfMCFHkqL,sHvq6cog0DepyZxEkSi = [],[],[],[],[]
	u7QpsmaYohOtNZJ,KcAB8J6pTWOMxtuonqlj7Xh,pfvKALlXZFdsJw4,PiUOIyNdoGgjrw2cQKBZC8Eup,NMrVZCofS8EUvyL9wzH6Ycjm = [],[],[],[],[]
	if icNLw6X3Pkjo95al1IOQA8qmFW:
		dict = {}
		dict[EDPaWgMt1SwNn8o(u"ࠧࡵࡻࡳࡩ࠷࠭ൟ")] = yTMWeCgUROcvtsblfK85L62xPk(u"ࠨࡃ࠮࡚ࠬൠ")
		dict[MM2BQ7xrAfNivgenXPytGYOs0DEHRC(u"ࠩࡩ࡭ࡱ࡫ࡴࡺࡲࡨࠫൡ")] = PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"ࠪࡱࡵࡪࠧൢ")
		dict[aFQoGfmYKyqLU6X8libw9k3ncW5(u"ࠫࡹ࡯ࡴ࡭ࡧࠪൣ")] = dict[yTMWeCgUROcvtsblfK85L62xPk(u"ࠬࡺࡹࡱࡧ࠵ࠫ൤")]+m6b7CoBk4EQ(u"࠭࠺ࠡࠢࠪ൥")+dict[hjNP5w9srJz2QpVISxBfndbD4CkXvl(u"ࠧࡧ࡫࡯ࡩࡹࡿࡰࡦࠩ൦")]+wwyUWMFAsO(u"ࠨࠢࠣࠫ൧")+gSmqZU0plur2xKPJwQA(u"ࠩฯ์ิฯࠠัๅํอࠬ൨")
		dict[aVLSn1xw5cK(u"ࠪࡹࡷࡲࠧ൩")] = icNLw6X3Pkjo95al1IOQA8qmFW
		dict[J3OCAmZVcn(u"ࠫࡶࡻࡡ࡭࡫ࡷࡽࠬ൪")] = pEo8g7riWVL014KaRtzQ(u"ࠬ࠶ࠧ൫")
		dict[m6b7CoBk4EQ(u"࠭ࡢࡪࡶࡵࡥࡹ࡫ࠧ൬")] = kmdSKeBIwViM9t3(u"ࠧ࠺࠺࠺࠺࠺࠺࠳࠳࠳࠳ࠫ൭")
		nd2Tek5z8DvtbKBuO0WcfgMY.append(dict)
	if N65nUTfSGL42PtavZDeqyjBIw:
		fUmXHDnkK8yCrEbeAdsMwl,hk6AGaoeVqUHRbxm792XW = c8T0X52CGk9UZ71q(N65nUTfSGL42PtavZDeqyjBIw)
		paKPJjfnXg4YhV0AILvH = list(zip(fUmXHDnkK8yCrEbeAdsMwl,hk6AGaoeVqUHRbxm792XW))
		for title,RRucmYBaXegTtNOdGHMQ in paKPJjfnXg4YhV0AILvH:
			dict = {}
			dict[jYaM5vilgZdFx6QHbApwVXO8et(u"ࠨࡶࡼࡴࡪ࠸ࠧ൮")] = DLSVmlyBbCK(u"ࠩࡄ࠯࡛࠭൯")
			dict[PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"ࠪࡪ࡮ࡲࡥࡵࡻࡳࡩࠬ൰")] = fR68jBGWCzUsFXdlTKPOScugm(u"ࠫࡲ࠹ࡵ࠹ࠩ൱")
			dict[aVLSn1xw5cK(u"ࠬࡻࡲ࡭ࠩ൲")] = RRucmYBaXegTtNOdGHMQ
			if jYaM5vilgZdFx6QHbApwVXO8et(u"࠭࡫ࡣࡲࡶࠫ൳") in title: dict[bdhQDyjm3nPwToFHkprvCzBLUGR(u"ࠧࡣ࡫ࡷࡶࡦࡺࡥࠨ൴")] = title.split(kRYWcNuAazr4jtmBoxFVS19Z6(u"ࠨ࡭ࡥࡴࡸ࠭൵"))[ZSJVq5XDrRot(u"࠱ႅ")].rsplit(pEo8g7riWVL014KaRtzQ(u"ࠩࠣࠤࠬ൶"))[-aVLSn1xw5cK(u"࠱ႄ")]
			else: dict[XogUJZEijT7KWbxeO6(u"ࠪࡦ࡮ࡺࡲࡢࡶࡨࠫ൷")] = OVmSuf8tpd(u"ࠫ࠶࠶ࠧ൸")
			if title.count(yTMWeCgUROcvtsblfK85L62xPk(u"ࠬࠦࠠࠨ൹"))>wwyUWMFAsO(u"࠳ႆ"):
				PHUqTNVJ0ErRSwibn5gD = title.rsplit(Ej67fFyoqW8kbV2HdSK(u"࠭ࠠࠡࠩൺ"))[-aFQoGfmYKyqLU6X8libw9k3ncW5(u"࠶ႇ")]
				if PHUqTNVJ0ErRSwibn5gD.isdigit(): dict[m6b7CoBk4EQ(u"ࠧࡲࡷࡤࡰ࡮ࡺࡹࠨൻ")] = PHUqTNVJ0ErRSwibn5gD
				else: dict[aFQoGfmYKyqLU6X8libw9k3ncW5(u"ࠨࡳࡸࡥࡱ࡯ࡴࡺࠩർ")] = JcDaEHuiS8TqBbOhWe4ZgwknoC1L3r(u"ࠩ࠳࠴࠵࠶ࠧൽ")
			if title==xuYvdJpOEyQKTLNwb(u"ࠪ࠱࠶࠭ൾ"): dict[hjNP5w9srJz2QpVISxBfndbD4CkXvl(u"ࠫࡹ࡯ࡴ࡭ࡧࠪൿ")] = dict[hjNP5w9srJz2QpVISxBfndbD4CkXvl(u"ࠬࡺࡹࡱࡧ࠵ࠫ඀")]+AAgpHN0nMZ(u"࠭࠺ࠡࠢࠪඁ")+dict[AAgpHN0nMZ(u"ࠧࡧ࡫࡯ࡩࡹࡿࡰࡦࠩං")]+yTMWeCgUROcvtsblfK85L62xPk(u"ࠨࠢࠣࠫඃ")+MM2BQ7xrAfNivgenXPytGYOs0DEHRC(u"ࠩฯ์ิฯࠠัๅํอࠬ඄")
			else: dict[m6b7CoBk4EQ(u"ࠪࡸ࡮ࡺ࡬ࡦࠩඅ")] = dict[sArCMRngQNmXkBoKv(u"ࠫࡹࡿࡰࡦ࠴ࠪආ")]+aFQoGfmYKyqLU6X8libw9k3ncW5(u"ࠬࡀࠠࠡࠩඇ")+dict[aVLSn1xw5cK(u"࠭ࡦࡪ࡮ࡨࡸࡾࡶࡥࠨඈ")]+gSmqZU0plur2xKPJwQA(u"ࠧࠡࠢࠪඉ")+dict[gnfv8UtZ3daGqpjzk(u"ࠨࡤ࡬ࡸࡷࡧࡴࡦࠩඊ")]+eeIL1TfgFQJaKqVD8hGNPEZ(u"ࠩ࡮ࡦࡵࡹࠠࠡࠩඋ")+dict[LmcNhzY6fQPd2JyCGslkSr(u"ࠪࡵࡺࡧ࡬ࡪࡶࡼࠫඌ")]
			nd2Tek5z8DvtbKBuO0WcfgMY.append(dict)
	nd2Tek5z8DvtbKBuO0WcfgMY = sorted(nd2Tek5z8DvtbKBuO0WcfgMY,reverse=MM2BQ7xrAfNivgenXPytGYOs0DEHRC(u"ࡕࡴࡸࡩᄻ"),key=lambda key: float(key[gSmqZU0plur2xKPJwQA(u"ࠫࡧ࡯ࡴࡳࡣࡷࡩࠬඍ")]))
	if not nd2Tek5z8DvtbKBuO0WcfgMY:
		uu5SDqLcCs7IUA = ZXFs0mEPR8qI2zj.findall(m6b7CoBk4EQ(u"ࠬࡩ࡬ࡢࡵࡶࡁࠧࡳࡥࡴࡵࡤ࡫ࡪ࡫ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨඎ"),QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
		zzPuKeTq6I4gHrRA3aUDmEpVyl = ZXFs0mEPR8qI2zj.findall(kRYWcNuAazr4jtmBoxFVS19Z6(u"࠭ࠢࡱ࡮ࡤࡽࡪࡸࡅࡳࡴࡲࡶࡒ࡫ࡳࡴࡣࡪࡩࡗ࡫࡮ࡥࡧࡵࡩࡷࠨ࠺࡝ࡽࠥࡷࡺࡨࡲࡦࡣࡶࡳࡳࠨ࠺࡝ࡽࠥࡶࡺࡴࡳࠣ࠼࡟࡟ࡡࢁࠢࡵࡧࡻࡸࡹࠨ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢࠨඏ"),QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
		zb9ro4X6jnBHhxpg = ZXFs0mEPR8qI2zj.findall(hjNP5w9srJz2QpVISxBfndbD4CkXvl(u"ࠧࠣࡲ࡯ࡥࡾ࡫ࡲࡆࡴࡵࡳࡷࡓࡥࡴࡵࡤ࡫ࡪࡘࡥ࡯ࡦࡨࡶࡪࡸࠢ࠻࡞ࡾࠦࡷ࡫ࡡࡴࡱࡱࠦ࠿ࢁࠢࡴ࡫ࡰࡴࡱ࡫ࡔࡦࡺࡷࠦ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ඐ"),QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
		kAotrbLajs5J2m8 = ZXFs0mEPR8qI2zj.findall(PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"ࠨࠤࡳࡰࡦࡿࡥࡳࡇࡵࡶࡴࡸࡍࡦࡵࡶࡥ࡬࡫ࡒࡦࡰࡧࡩࡷ࡫ࡲࠣ࠼࡟ࡿࠧࡹࡵࡣࡴࡨࡥࡸࡵ࡮ࠣ࠼ࡾࠦࡸ࡯࡭ࡱ࡮ࡨࡘࡪࡾࡴࠣ࠼ࠥࠬ࠳࠰࠿ࠪࠤࠪඑ"),QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
		try: CMqHoE0FLzApUQIY5tPZewb = YZ4rq9g1mMC[bdhQDyjm3nPwToFHkprvCzBLUGR(u"ࠩࡳࡰࡦࡿࡡࡣ࡫࡯࡭ࡹࡿࡓࡵࡣࡷࡹࡸ࠭ඒ")][bdhQDyjm3nPwToFHkprvCzBLUGR(u"ࠪࡩࡷࡸ࡯ࡳࡕࡦࡶࡪ࡫࡮ࠨඓ")][DLSVmlyBbCK(u"ࠫࡨࡵ࡮ࡧ࡫ࡵࡱࡉ࡯ࡡ࡭ࡱࡪࡖࡪࡴࡤࡦࡴࡨࡶࠬඔ")][AAgpHN0nMZ(u"ࠬࡺࡩࡵ࡮ࡨࠫඕ")][yTMWeCgUROcvtsblfK85L62xPk(u"࠭ࡲࡶࡰࡶࠫඖ")][MM2BQ7xrAfNivgenXPytGYOs0DEHRC(u"࠴ႈ")][FhcnOB9t3frzvXb(u"ࠧࡵࡧࡻࡸࡹ࠭඗")]
		except: CMqHoE0FLzApUQIY5tPZewb = hjNP5w9srJz2QpVISxBfndbD4CkXvl(u"ࠨࠩ඘")
		try: jjYB4Por9lqnzivIZeACEuDfxgd = YZ4rq9g1mMC[pEo8g7riWVL014KaRtzQ(u"ࠩࡳࡰࡦࡿࡡࡣ࡫࡯࡭ࡹࡿࡓࡵࡣࡷࡹࡸ࠭඙")][AAgpHN0nMZ(u"ࠪࡩࡷࡸ࡯ࡳࡕࡦࡶࡪ࡫࡮ࠨක")][wwyUWMFAsO(u"ࠫࡨࡵ࡮ࡧ࡫ࡵࡱࡉ࡯ࡡ࡭ࡱࡪࡖࡪࡴࡤࡦࡴࡨࡶࠬඛ")][fR68jBGWCzUsFXdlTKPOScugm(u"ࠬࡪࡩࡢ࡮ࡲ࡫ࡒ࡫ࡳࡴࡣࡪࡩࡸ࠭ග")][MM2BQ7xrAfNivgenXPytGYOs0DEHRC(u"࠵ႉ")][JcDaEHuiS8TqBbOhWe4ZgwknoC1L3r(u"࠭ࡲࡶࡰࡶࠫඝ")][MM2BQ7xrAfNivgenXPytGYOs0DEHRC(u"࠵ႉ")][fR68jBGWCzUsFXdlTKPOScugm(u"ࠧࡵࡧࡻࡸࡹ࠭ඞ")]
		except: jjYB4Por9lqnzivIZeACEuDfxgd = pEo8g7riWVL014KaRtzQ(u"ࠨࠩඟ")
		try: krmjZdPgTp4KUwicJYOQBfnXy5e7t = YZ4rq9g1mMC[LmcNhzY6fQPd2JyCGslkSr(u"ࠩࡳࡰࡦࡿࡡࡣ࡫࡯࡭ࡹࡿࡓࡵࡣࡷࡹࡸ࠭ච")][gnfv8UtZ3daGqpjzk(u"ࠪࡶࡪࡧࡳࡰࡰࠪඡ")]
		except: krmjZdPgTp4KUwicJYOQBfnXy5e7t = Ej67fFyoqW8kbV2HdSK(u"ࠫࠬජ")
		if uu5SDqLcCs7IUA or zzPuKeTq6I4gHrRA3aUDmEpVyl or zb9ro4X6jnBHhxpg or kAotrbLajs5J2m8 or CMqHoE0FLzApUQIY5tPZewb or jjYB4Por9lqnzivIZeACEuDfxgd or krmjZdPgTp4KUwicJYOQBfnXy5e7t:
			if   uu5SDqLcCs7IUA: LaX1QCyeIJ = uu5SDqLcCs7IUA[sArCMRngQNmXkBoKv(u"࠶ႊ")]
			elif zzPuKeTq6I4gHrRA3aUDmEpVyl: LaX1QCyeIJ = zzPuKeTq6I4gHrRA3aUDmEpVyl[aVLSn1xw5cK(u"࠰ႋ")]
			elif zb9ro4X6jnBHhxpg: LaX1QCyeIJ = zb9ro4X6jnBHhxpg[MM2BQ7xrAfNivgenXPytGYOs0DEHRC(u"࠱ႌ")]
			elif kAotrbLajs5J2m8: LaX1QCyeIJ = kAotrbLajs5J2m8[Ej67fFyoqW8kbV2HdSK(u"࠲ႍ")]
			elif CMqHoE0FLzApUQIY5tPZewb: LaX1QCyeIJ = CMqHoE0FLzApUQIY5tPZewb
			elif jjYB4Por9lqnzivIZeACEuDfxgd: LaX1QCyeIJ = jjYB4Por9lqnzivIZeACEuDfxgd
			elif krmjZdPgTp4KUwicJYOQBfnXy5e7t: LaX1QCyeIJ = krmjZdPgTp4KUwicJYOQBfnXy5e7t
			aaMu9gC6wTnX85kexbzHhVv = LaX1QCyeIJ.replace(gnfv8UtZ3daGqpjzk(u"ࠬࡢ࡮ࠨඣ"),c4QSTnPiWUCjhrLlwGB(u"࠭ࠧඤ")).strip(gSmqZU0plur2xKPJwQA(u"ࠧࠡࠩඥ"))
			Snv6DCTgwrPLYK = sArCMRngQNmXkBoKv(u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠ๋ีอࠠศๆไ๎ิ๐่ࠡใํ๋๋ࠥิไๆฬࠤํ่ฯࠡ์ๆ์ฺ๋๋ࠦำ้้ࠣอฦๆࠢ็ฬ฾฼ࠠศๆ่ืฯิฯๆ์้ࠤศ๎ࠠ฻์ิࠤ๊ะ่โำࠣห้ศๆ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩඦ")
			HHTzVhiY079bvdluNkFQ4wCMpe(sArCMRngQNmXkBoKv(u"ࠩࠪට"),AAgpHN0nMZ(u"ࠪࠫඨ"),m6b7CoBk4EQ(u"ࠫึูวๅห้๋ࠣࠦวๅ็๋ๆ฾่ࠦศๆ่ฬึ๋ฬࠨඩ"),Snv6DCTgwrPLYK+LmcNhzY6fQPd2JyCGslkSr(u"ࠬࡢ࡮࡝ࡰࠪඪ")+aaMu9gC6wTnX85kexbzHhVv)
			return MM2BQ7xrAfNivgenXPytGYOs0DEHRC(u"࠭ࡅࡳࡴࡲࡶࠥࠦࠠࠡ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥ࡟ࡏࡖࡖࡘࡆࡊࠦࡆࡢ࡫࡯ࡩࡩࡀࠠࠨණ")+aaMu9gC6wTnX85kexbzHhVv,[],[]
		else: return LmcNhzY6fQPd2JyCGslkSr(u"ࠧࡆࡴࡵࡳࡷࠦࠠࠡࠢ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷ࡙ࠦࡐࡗࡗ࡙ࡇࡋࠠࡇࡣ࡬ࡰࡪࡪࠧඬ"),[],[]
	RwsmKPNvrJfOWH8,N1E2gvm9xoiBh7z5c6VF,RVtgh1zS2ZAGTuyQ = [],[],[]
	for dict in nd2Tek5z8DvtbKBuO0WcfgMY:
		if dict[gnfv8UtZ3daGqpjzk(u"ࠨࡶࡼࡴࡪ࠸ࠧත")]==aVLSn1xw5cK(u"࡙ࠩ࡭ࡩ࡫࡯ࠨථ"):
			g9fFirP4WON2UT3pRaclSsteAYy8.append(dict[m6b7CoBk4EQ(u"ࠪࡸ࡮ࡺ࡬ࡦࠩද")])
			u7QpsmaYohOtNZJ.append(dict)
		elif dict[ZSJVq5XDrRot(u"ࠫࡹࡿࡰࡦ࠴ࠪධ")]==aFQoGfmYKyqLU6X8libw9k3ncW5(u"ࠬࡇࡵࡥ࡫ࡲࠫන"):
			eZWBHkcmaVlftsqOhUng5jNdovT10.append(dict[kmdSKeBIwViM9t3(u"࠭ࡴࡪࡶ࡯ࡩࠬ඲")])
			KcAB8J6pTWOMxtuonqlj7Xh.append(dict)
		elif dict[OVmSuf8tpd(u"ࠧࡧ࡫࡯ࡩࡹࡿࡰࡦࠩඳ")]==xuYvdJpOEyQKTLNwb(u"ࠨ࡯ࡳࡨࠬප"):
			title = dict[fR68jBGWCzUsFXdlTKPOScugm(u"ࠩࡷ࡭ࡹࡲࡥࠨඵ")].replace(hjNP5w9srJz2QpVISxBfndbD4CkXvl(u"ࠪࡅ࠰࡜࠺ࠡࠢࠪබ"),jYaM5vilgZdFx6QHbApwVXO8et(u"ࠫࠬභ"))
			if ffCSGrTJYPsxgVQWKLtHU3iMwB(u"ࠬࡨࡩࡵࡴࡤࡸࡪ࠭ම") not in list(dict.keys()): TzMbHrQSJ5AVKxmOY = gnfv8UtZ3daGqpjzk(u"࠭࠰ࠨඹ")
			else: TzMbHrQSJ5AVKxmOY = dict[pEo8g7riWVL014KaRtzQ(u"ࠧࡣ࡫ࡷࡶࡦࡺࡥࠨය")]
			RwsmKPNvrJfOWH8.append([dict,{},title,TzMbHrQSJ5AVKxmOY])
		else:
			title = dict[DLSVmlyBbCK(u"ࠨࡶ࡬ࡸࡱ࡫ࠧර")].replace(XogUJZEijT7KWbxeO6(u"ࠩࡄ࠯࡛ࡀࠠࠡࠩ඼"),EDPaWgMt1SwNn8o(u"ࠪࠫල"))
			if eeIL1TfgFQJaKqVD8hGNPEZ(u"ࠫࡧ࡯ࡴࡳࡣࡷࡩࠬ඾") not in list(dict.keys()): TzMbHrQSJ5AVKxmOY = XogUJZEijT7KWbxeO6(u"ࠬ࠶ࠧ඿")
			else: TzMbHrQSJ5AVKxmOY = dict[J3OCAmZVcn(u"࠭ࡢࡪࡶࡵࡥࡹ࡫ࠧව")]
			RwsmKPNvrJfOWH8.append([dict,{},title,TzMbHrQSJ5AVKxmOY])
			KyES8tQXjPN2WipmFIuR5.append(title)
			pfvKALlXZFdsJw4.append(dict)
		HrKYcPwbD0jq5dTah9ueJivM1f8NL = hjNP5w9srJz2QpVISxBfndbD4CkXvl(u"ࡖࡵࡹࡪᄼ")
		if eeIL1TfgFQJaKqVD8hGNPEZ(u"ࠧࡤࡱࡧࡩࡨࡹࠧශ") in list(dict.keys()):
			if ffCSGrTJYPsxgVQWKLtHU3iMwB(u"ࠨࡣࡹ࠴ࠬෂ") in dict[AAgpHN0nMZ(u"ࠩࡦࡳࡩ࡫ࡣࡴࠩස")]: HrKYcPwbD0jq5dTah9ueJivM1f8NL = jYaM5vilgZdFx6QHbApwVXO8et(u"ࡉࡥࡱࡹࡥᄽ")
			elif V8US2yZAg0QXJebWIHKD5xFa<XogUJZEijT7KWbxeO6(u"࠴࠼ႎ"):
				if aFQoGfmYKyqLU6X8libw9k3ncW5(u"ࠪࡥࡻࡩࠧහ") not in dict[hjNP5w9srJz2QpVISxBfndbD4CkXvl(u"ࠫࡨࡵࡤࡦࡥࡶࠫළ")] and pEo8g7riWVL014KaRtzQ(u"ࠬࡳࡰ࠵ࡣࠪෆ") not in dict[EDPaWgMt1SwNn8o(u"࠭ࡣࡰࡦࡨࡧࡸ࠭෇")]: HrKYcPwbD0jq5dTah9ueJivM1f8NL = PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"ࡊࡦࡲࡳࡦᄾ")
		if dict[XogUJZEijT7KWbxeO6(u"ࠧࡵࡻࡳࡩ࠷࠭෈")]==jYaM5vilgZdFx6QHbApwVXO8et(u"ࠨࡘ࡬ࡨࡪࡵࠧ෉") and dict[yTMWeCgUROcvtsblfK85L62xPk(u"ࠩ࡬ࡲ࡮ࡺ්ࠧ")]!=c4QSTnPiWUCjhrLlwGB(u"ࠪ࠴࠲࠶ࠧ෋") and HrKYcPwbD0jq5dTah9ueJivM1f8NL==PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"࡙ࡸࡵࡦᄿ"):
			sHvq6cog0DepyZxEkSi.append(dict[m6b7CoBk4EQ(u"ࠫࡹ࡯ࡴ࡭ࡧࠪ෌")])
			NMrVZCofS8EUvyL9wzH6Ycjm.append(dict)
		elif dict[jYaM5vilgZdFx6QHbApwVXO8et(u"ࠬࡺࡹࡱࡧ࠵ࠫ෍")]==kRYWcNuAazr4jtmBoxFVS19Z6(u"࠭ࡁࡶࡦ࡬ࡳࠬ෎") and dict[hjNP5w9srJz2QpVISxBfndbD4CkXvl(u"ࠧࡪࡰ࡬ࡸࠬා")]!=jYaM5vilgZdFx6QHbApwVXO8et(u"ࠨ࠲࠰࠴ࠬැ") and HrKYcPwbD0jq5dTah9ueJivM1f8NL==xuYvdJpOEyQKTLNwb(u"࡚ࡲࡶࡧᅀ"):
			KZl5I869eGPBwYsvXtfMCFHkqL.append(dict[fR68jBGWCzUsFXdlTKPOScugm(u"ࠩࡷ࡭ࡹࡲࡥࠨෑ")])
			PiUOIyNdoGgjrw2cQKBZC8Eup.append(dict)
	for w6nBHVF3Pb2mzXj in PiUOIyNdoGgjrw2cQKBZC8Eup:
		gIWGVfkTLZiaF = w6nBHVF3Pb2mzXj[MM2BQ7xrAfNivgenXPytGYOs0DEHRC(u"ࠪࡦ࡮ࡺࡲࡢࡶࡨࠫි")]
		for nnQmGzXAtw7SfrR1V in NMrVZCofS8EUvyL9wzH6Ycjm:
			SSsotNFrlD21huRq3fx06H4e8LTMc = nnQmGzXAtw7SfrR1V[XogUJZEijT7KWbxeO6(u"ࠫࡧ࡯ࡴࡳࡣࡷࡩࠬී")]
			TzMbHrQSJ5AVKxmOY = SSsotNFrlD21huRq3fx06H4e8LTMc+gIWGVfkTLZiaF
			title = nnQmGzXAtw7SfrR1V[Ej67fFyoqW8kbV2HdSK(u"ࠬࡺࡩࡵ࡮ࡨࠫු")].replace(gnfv8UtZ3daGqpjzk(u"࠭ࡖࡪࡦࡨࡳ࠿ࠦࠠࠨ෕"),gSmqZU0plur2xKPJwQA(u"ࠧ࡮ࡲࡧࠤࠥ࠭ූ"))
			title = title.replace(nnQmGzXAtw7SfrR1V[XogUJZEijT7KWbxeO6(u"ࠨࡨ࡬ࡰࡪࡺࡹࡱࡧࠪ෗")]+gSmqZU0plur2xKPJwQA(u"ࠩࠣࠤࠬෘ"),kRYWcNuAazr4jtmBoxFVS19Z6(u"ࠪࠫෙ"))
			title = title.replace(str((float(SSsotNFrlD21huRq3fx06H4e8LTMc*JcDaEHuiS8TqBbOhWe4ZgwknoC1L3r(u"࠵࠵ႏ"))//aFQoGfmYKyqLU6X8libw9k3ncW5(u"࠶࠶࠲࠵႐")/JcDaEHuiS8TqBbOhWe4ZgwknoC1L3r(u"࠵࠵ႏ")))+J3OCAmZVcn(u"ࠫࡰࡨࡰࡴࠩේ"),str((float(TzMbHrQSJ5AVKxmOY*JcDaEHuiS8TqBbOhWe4ZgwknoC1L3r(u"࠵࠵ႏ"))//aFQoGfmYKyqLU6X8libw9k3ncW5(u"࠶࠶࠲࠵႐")/JcDaEHuiS8TqBbOhWe4ZgwknoC1L3r(u"࠵࠵ႏ")))+XogUJZEijT7KWbxeO6(u"ࠬࡱࡢࡱࡵࠪෛ"))
			title = title+ffCSGrTJYPsxgVQWKLtHU3iMwB(u"࠭ࠨࠨො")+w6nBHVF3Pb2mzXj[hjNP5w9srJz2QpVISxBfndbD4CkXvl(u"ࠧࡵ࡫ࡷࡰࡪ࠭ෝ")].split(J3OCAmZVcn(u"ࠨࠪࠪෞ"),aFQoGfmYKyqLU6X8libw9k3ncW5(u"࠷႑"))[aFQoGfmYKyqLU6X8libw9k3ncW5(u"࠷႑")]
			RwsmKPNvrJfOWH8.append([nnQmGzXAtw7SfrR1V,w6nBHVF3Pb2mzXj,title,TzMbHrQSJ5AVKxmOY])
	RwsmKPNvrJfOWH8 = sorted(RwsmKPNvrJfOWH8, reverse=gSmqZU0plur2xKPJwQA(u"ࡔࡳࡷࡨᅁ"), key=lambda key: float(key[fR68jBGWCzUsFXdlTKPOScugm(u"࠳႒")]))
	for nnQmGzXAtw7SfrR1V,w6nBHVF3Pb2mzXj,title,TzMbHrQSJ5AVKxmOY in RwsmKPNvrJfOWH8:
		PP41k2VQDho58l = nnQmGzXAtw7SfrR1V[LmcNhzY6fQPd2JyCGslkSr(u"ࠩࡩ࡭ࡱ࡫ࡴࡺࡲࡨࠫෟ")]
		if kRYWcNuAazr4jtmBoxFVS19Z6(u"ࠪࡪ࡮ࡲࡥࡵࡻࡳࡩࠬ෠") in list(w6nBHVF3Pb2mzXj.keys()):
			PP41k2VQDho58l = yTMWeCgUROcvtsblfK85L62xPk(u"ࠫࡲࡶࡤࠨ෡")
		if PP41k2VQDho58l not in RVtgh1zS2ZAGTuyQ:
			RVtgh1zS2ZAGTuyQ.append(PP41k2VQDho58l)
			N1E2gvm9xoiBh7z5c6VF.append([nnQmGzXAtw7SfrR1V,w6nBHVF3Pb2mzXj,title,TzMbHrQSJ5AVKxmOY])
	p5Aa2OZKnhcDz4Ewr6FVNHRiLW,ERQ1Pcis2KyG6v,KP0YBtJjwMe3ndSO8qCR2 = [],[],XogUJZEijT7KWbxeO6(u"࠱႓")
	sC3BgwKUR2Nf0ilnq1zH5mQ9v,I29mGBjcxkVN71KSJs = kmdSKeBIwViM9t3(u"ࠬ࠭෢"),AAgpHN0nMZ(u"࠭ࠧ෣")
	try: sC3BgwKUR2Nf0ilnq1zH5mQ9v = YZ4rq9g1mMC[MM2BQ7xrAfNivgenXPytGYOs0DEHRC(u"ࠧࡷ࡫ࡧࡩࡴࡊࡥࡵࡣ࡬ࡰࡸ࠭෤")][PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"ࠨࡣࡸࡸ࡭ࡵࡲࠨ෥")]
	except: sC3BgwKUR2Nf0ilnq1zH5mQ9v = c4QSTnPiWUCjhrLlwGB(u"ࠩࠪ෦")
	try: bCBSJVxmwjXnueIRh = YZ4rq9g1mMC[LmcNhzY6fQPd2JyCGslkSr(u"ࠪࡺ࡮ࡪࡥࡰࡆࡨࡸࡦ࡯࡬ࡴࠩ෧")][c4QSTnPiWUCjhrLlwGB(u"ࠫࡨ࡮ࡡ࡯ࡰࡨࡰࡎࡪࠧ෨")]
	except: bCBSJVxmwjXnueIRh = kRYWcNuAazr4jtmBoxFVS19Z6(u"ࠬ࠭෩")
	if sC3BgwKUR2Nf0ilnq1zH5mQ9v and bCBSJVxmwjXnueIRh:
		KP0YBtJjwMe3ndSO8qCR2 += yTMWeCgUROcvtsblfK85L62xPk(u"࠳႔")
		title = OVmSuf8tpd(u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࡑ࡚ࡒࡊࡘ࠺ࠡࠢࠪ෪")+sC3BgwKUR2Nf0ilnq1zH5mQ9v+ZSJVq5XDrRot(u"ࠧ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ෫")
		RRucmYBaXegTtNOdGHMQ = uReHcEzxkTm6pN4Q[JcDaEHuiS8TqBbOhWe4ZgwknoC1L3r(u"ࠨ࡛ࡒ࡙࡙࡛ࡂࡆࠩ෬")][jYaM5vilgZdFx6QHbApwVXO8et(u"࠳႕")]+wwyUWMFAsO(u"ࠩ࠲ࡧ࡭ࡧ࡮࡯ࡧ࡯࠳ࠬ෭")+bCBSJVxmwjXnueIRh
		p5Aa2OZKnhcDz4Ewr6FVNHRiLW.append(title)
		ERQ1Pcis2KyG6v.append(RRucmYBaXegTtNOdGHMQ)
		try: I29mGBjcxkVN71KSJs = YZ4rq9g1mMC[c4QSTnPiWUCjhrLlwGB(u"ࠪࡺ࡮ࡪࡥࡰࡆࡨࡸࡦ࡯࡬ࡴࠩ෮")][XogUJZEijT7KWbxeO6(u"ࠫࡹ࡮ࡵ࡮ࡤࡱࡥ࡮ࡲࠧ෯")][kmdSKeBIwViM9t3(u"ࠬࡺࡨࡶ࡯ࡥࡲࡦ࡯࡬ࡴࠩ෰")][-DLSVmlyBbCK(u"࠵႖")][DLSVmlyBbCK(u"࠭ࡵࡳ࡮ࠪ෱")]
		except: pass
	for nnQmGzXAtw7SfrR1V,w6nBHVF3Pb2mzXj,title,TzMbHrQSJ5AVKxmOY in N1E2gvm9xoiBh7z5c6VF:
		p5Aa2OZKnhcDz4Ewr6FVNHRiLW.append(title) ; ERQ1Pcis2KyG6v.append(J3OCAmZVcn(u"ࠧࡩ࡫ࡪ࡬ࡪࡹࡴࠨෲ"))
	if KyES8tQXjPN2WipmFIuR5: p5Aa2OZKnhcDz4Ewr6FVNHRiLW.append(jYaM5vilgZdFx6QHbApwVXO8et(u"ࠨื๋ีฮ่ࠦึ๊อࠤ๊ำฯะหࠪෳ")) ; ERQ1Pcis2KyG6v.append(JcDaEHuiS8TqBbOhWe4ZgwknoC1L3r(u"ࠩࡰࡹࡽ࡫ࡤࠨ෴"))
	if RwsmKPNvrJfOWH8: p5Aa2OZKnhcDz4Ewr6FVNHRiLW.append(OVmSuf8tpd(u"ูࠪํืษุ๊ࠡ์ฯࠦวๅ็อ์ๆืࠧ෵")) ; ERQ1Pcis2KyG6v.append(bdhQDyjm3nPwToFHkprvCzBLUGR(u"ࠫࡦࡲ࡬ࠨ෶"))
	if sHvq6cog0DepyZxEkSi: p5Aa2OZKnhcDz4Ewr6FVNHRiLW.append(FhcnOB9t3frzvXb(u"ࠬࡳࡰࡥࠢสาฯืࠠศๆุ์ึฯ้ࠠษ็ูํะࠧ෷")) ; ERQ1Pcis2KyG6v.append(EDPaWgMt1SwNn8o(u"࠭࡭ࡱࡦࠪ෸"))
	if g9fFirP4WON2UT3pRaclSsteAYy8: p5Aa2OZKnhcDz4Ewr6FVNHRiLW.append(ffCSGrTJYPsxgVQWKLtHU3iMwB(u"ࠧึ๊ิอࠥฮฯู้่ࠣํะࠧ෹")) ; ERQ1Pcis2KyG6v.append(bdhQDyjm3nPwToFHkprvCzBLUGR(u"ࠨࡸ࡬ࡨࡪࡵࠧ෺"))
	if eZWBHkcmaVlftsqOhUng5jNdovT10: p5Aa2OZKnhcDz4Ewr6FVNHRiLW.append(fR68jBGWCzUsFXdlTKPOScugm(u"ุࠩ์ฯࠦศะ๊้ࠤฺ๎ัสࠩ෻")) ; ERQ1Pcis2KyG6v.append(kmdSKeBIwViM9t3(u"ࠪࡥࡺࡪࡩࡰࠩ෼"))
	PuHXxU4vIlY5EsetaNSnoFg = ffCSGrTJYPsxgVQWKLtHU3iMwB(u"ࡇࡣ࡯ࡷࡪᅂ")
	while LmcNhzY6fQPd2JyCGslkSr(u"ࡖࡵࡹࡪᅃ"):
		jQ6w8xOrgYhSHIRpUqzL = F2yZPukcUh09sqCI8nYw7e(ai5kI9sPDUH2BZw7V, p5Aa2OZKnhcDz4Ewr6FVNHRiLW)
		if jQ6w8xOrgYhSHIRpUqzL==-LmcNhzY6fQPd2JyCGslkSr(u"࠶႗"): return fR68jBGWCzUsFXdlTKPOScugm(u"ࠫࡊ࡞ࡉࡕࡡࡄࡐࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩ෽"),[],[]
		elif jQ6w8xOrgYhSHIRpUqzL==MM2BQ7xrAfNivgenXPytGYOs0DEHRC(u"࠶႘") and sC3BgwKUR2Nf0ilnq1zH5mQ9v:
			RRucmYBaXegTtNOdGHMQ = ERQ1Pcis2KyG6v[jQ6w8xOrgYhSHIRpUqzL]
			PY7dAjmvOzeTDEU2JI1wi8lyNLQ = ddABnr3K9Xv8e71CzcN0Pxt.argv[hjNP5w9srJz2QpVISxBfndbD4CkXvl(u"࠰႙")]+aVLSn1xw5cK(u"ࠬࡅࡴࡺࡲࡨࡁ࡫ࡵ࡬ࡥࡧࡵࠪࡲࡵࡤࡦ࠿࠴࠸࠶ࠬ࡮ࡢ࡯ࡨࡁࠬ෾")+cD1AgYCl0qZI8(sC3BgwKUR2Nf0ilnq1zH5mQ9v)+bdhQDyjm3nPwToFHkprvCzBLUGR(u"࠭ࠦࡶࡴ࡯ࡁࠬ෿")+RRucmYBaXegTtNOdGHMQ
			if I29mGBjcxkVN71KSJs: PY7dAjmvOzeTDEU2JI1wi8lyNLQ = PY7dAjmvOzeTDEU2JI1wi8lyNLQ+OVmSuf8tpd(u"ࠧࠧ࡫ࡰࡥ࡬࡫࠽ࠨ฀")+cD1AgYCl0qZI8(I29mGBjcxkVN71KSJs)
			cPwDBuG4HVTCdQ9JmMeoWjNY2hX.executebuiltin(kRYWcNuAazr4jtmBoxFVS19Z6(u"ࠣࡅࡲࡲࡹࡧࡩ࡯ࡧࡵ࠲࡚ࡶࡤࡢࡶࡨࠬࠧก")+PY7dAjmvOzeTDEU2JI1wi8lyNLQ+bdhQDyjm3nPwToFHkprvCzBLUGR(u"ࠤࠬࠦข"))
			return pEo8g7riWVL014KaRtzQ(u"ࠪࡉ࡝ࡏࡔࡠࡃࡏࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨฃ"),[],[]
		PTQimzWJpkrt6H = ERQ1Pcis2KyG6v[jQ6w8xOrgYhSHIRpUqzL]
		UgRMbihED7elrsQfYO60KA = p5Aa2OZKnhcDz4Ewr6FVNHRiLW[jQ6w8xOrgYhSHIRpUqzL]
		if PTQimzWJpkrt6H==kRYWcNuAazr4jtmBoxFVS19Z6(u"ࠫࡩࡧࡳࡩࠩค"):
			gt2RuaDQ683IWeY4fyoLjhpX01xN7 = icNLw6X3Pkjo95al1IOQA8qmFW
			break
		elif PTQimzWJpkrt6H in [yTMWeCgUROcvtsblfK85L62xPk(u"ࠬࡧࡵࡥ࡫ࡲࠫฅ"),kRYWcNuAazr4jtmBoxFVS19Z6(u"࠭ࡶࡪࡦࡨࡳࠬฆ"),AAgpHN0nMZ(u"ࠧ࡮ࡷࡻࡩࡩ࠭ง")]:
			if PTQimzWJpkrt6H==kRYWcNuAazr4jtmBoxFVS19Z6(u"ࠨ࡯ࡸࡼࡪࡪࠧจ"): xCLQK8kh39sjyi5DXSZAVeI,LZtK3kFV6wJzSC9rivgmyp = KyES8tQXjPN2WipmFIuR5,pfvKALlXZFdsJw4
			elif PTQimzWJpkrt6H==JMLhEyaBWmskovGHTrVCxQ08(u"ࠩࡹ࡭ࡩ࡫࡯ࠨฉ"): xCLQK8kh39sjyi5DXSZAVeI,LZtK3kFV6wJzSC9rivgmyp = g9fFirP4WON2UT3pRaclSsteAYy8,u7QpsmaYohOtNZJ
			elif PTQimzWJpkrt6H==JMLhEyaBWmskovGHTrVCxQ08(u"ࠪࡥࡺࡪࡩࡰࠩช"): xCLQK8kh39sjyi5DXSZAVeI,LZtK3kFV6wJzSC9rivgmyp = eZWBHkcmaVlftsqOhUng5jNdovT10,KcAB8J6pTWOMxtuonqlj7Xh
			jQ6w8xOrgYhSHIRpUqzL = F2yZPukcUh09sqCI8nYw7e(J3OCAmZVcn(u"ࠫฬิสาࠢส่๊๊แࠡษ็้๋อำษ࠼ࠪซ"), xCLQK8kh39sjyi5DXSZAVeI)
			if jQ6w8xOrgYhSHIRpUqzL!=-EDPaWgMt1SwNn8o(u"࠲ႚ"):
				gt2RuaDQ683IWeY4fyoLjhpX01xN7 = LZtK3kFV6wJzSC9rivgmyp[jQ6w8xOrgYhSHIRpUqzL][pEo8g7riWVL014KaRtzQ(u"ࠬࡻࡲ࡭ࠩฌ")]
				UgRMbihED7elrsQfYO60KA = xCLQK8kh39sjyi5DXSZAVeI[jQ6w8xOrgYhSHIRpUqzL]
				break
		elif PTQimzWJpkrt6H==m6b7CoBk4EQ(u"࠭࡭ࡱࡦࠪญ"):
			jQ6w8xOrgYhSHIRpUqzL = F2yZPukcUh09sqCI8nYw7e(MM2BQ7xrAfNivgenXPytGYOs0DEHRC(u"ࠧศะอีࠥา่ะหࠣห้฻่าห࠽ࠫฎ"), sHvq6cog0DepyZxEkSi)
			if jQ6w8xOrgYhSHIRpUqzL!=-ZSJVq5XDrRot(u"࠳ႛ"):
				UgRMbihED7elrsQfYO60KA = sHvq6cog0DepyZxEkSi[jQ6w8xOrgYhSHIRpUqzL]
				bE64SRYiqv8e3yH = NMrVZCofS8EUvyL9wzH6Ycjm[jQ6w8xOrgYhSHIRpUqzL]
				jQ6w8xOrgYhSHIRpUqzL = F2yZPukcUh09sqCI8nYw7e(kmdSKeBIwViM9t3(u"ࠨษัฮึࠦฬ้ัฬࠤฬ๊ี้ฬ࠽ࠫฏ"), KZl5I869eGPBwYsvXtfMCFHkqL)
				if jQ6w8xOrgYhSHIRpUqzL!=-jYaM5vilgZdFx6QHbApwVXO8et(u"࠴ႜ"):
					UgRMbihED7elrsQfYO60KA += aFQoGfmYKyqLU6X8libw9k3ncW5(u"ࠩࠣ࠯ࠥ࠭ฐ")+KZl5I869eGPBwYsvXtfMCFHkqL[jQ6w8xOrgYhSHIRpUqzL]
					kujoZsDhM1YCa6OFXWg3 = PiUOIyNdoGgjrw2cQKBZC8Eup[jQ6w8xOrgYhSHIRpUqzL]
					PuHXxU4vIlY5EsetaNSnoFg = JcDaEHuiS8TqBbOhWe4ZgwknoC1L3r(u"ࡗࡶࡺ࡫ᅄ")
					break
		elif PTQimzWJpkrt6H==EDPaWgMt1SwNn8o(u"ࠪࡥࡱࡲࠧฑ"):
			ceYZ0kr5dyKsBm3IhbUHS8Vlju,LDmuKkX1GjJZR6eOp,vGT0rsdfQRBa,NFfB0vyPMWT = list(zip(*RwsmKPNvrJfOWH8))
			jQ6w8xOrgYhSHIRpUqzL = F2yZPukcUh09sqCI8nYw7e(LmcNhzY6fQPd2JyCGslkSr(u"ࠫฬิสาࠢส่๊๊แࠡษ็้๋อำษ࠼ࠪฒ"), vGT0rsdfQRBa)
			if jQ6w8xOrgYhSHIRpUqzL!=-aFQoGfmYKyqLU6X8libw9k3ncW5(u"࠵ႝ"):
				UgRMbihED7elrsQfYO60KA = vGT0rsdfQRBa[jQ6w8xOrgYhSHIRpUqzL]
				bE64SRYiqv8e3yH = ceYZ0kr5dyKsBm3IhbUHS8Vlju[jQ6w8xOrgYhSHIRpUqzL]
				if eeIL1TfgFQJaKqVD8hGNPEZ(u"ࠬࡳࡰࡥࠩณ") in vGT0rsdfQRBa[jQ6w8xOrgYhSHIRpUqzL] and bE64SRYiqv8e3yH[pEo8g7riWVL014KaRtzQ(u"࠭ࡵࡳ࡮ࠪด")]!=icNLw6X3Pkjo95al1IOQA8qmFW:
					kujoZsDhM1YCa6OFXWg3 = LDmuKkX1GjJZR6eOp[jQ6w8xOrgYhSHIRpUqzL]
					PuHXxU4vIlY5EsetaNSnoFg = bdhQDyjm3nPwToFHkprvCzBLUGR(u"ࡘࡷࡻࡥᅅ")
				else: gt2RuaDQ683IWeY4fyoLjhpX01xN7 = bE64SRYiqv8e3yH[gnfv8UtZ3daGqpjzk(u"ࠧࡶࡴ࡯ࠫต")]
				break
		elif PTQimzWJpkrt6H==kmdSKeBIwViM9t3(u"ࠨࡪ࡬࡫࡭࡫ࡳࡵࠩถ"):
			ceYZ0kr5dyKsBm3IhbUHS8Vlju,LDmuKkX1GjJZR6eOp,vGT0rsdfQRBa,NFfB0vyPMWT = list(zip(*N1E2gvm9xoiBh7z5c6VF))
			bE64SRYiqv8e3yH = ceYZ0kr5dyKsBm3IhbUHS8Vlju[jQ6w8xOrgYhSHIRpUqzL-KP0YBtJjwMe3ndSO8qCR2]
			if FhcnOB9t3frzvXb(u"ࠩࡰࡴࡩ࠭ท") in vGT0rsdfQRBa[jQ6w8xOrgYhSHIRpUqzL-KP0YBtJjwMe3ndSO8qCR2] and bE64SRYiqv8e3yH[pEo8g7riWVL014KaRtzQ(u"ࠪࡹࡷࡲࠧธ")]!=icNLw6X3Pkjo95al1IOQA8qmFW:
				kujoZsDhM1YCa6OFXWg3 = LDmuKkX1GjJZR6eOp[jQ6w8xOrgYhSHIRpUqzL-KP0YBtJjwMe3ndSO8qCR2]
				PuHXxU4vIlY5EsetaNSnoFg = eeIL1TfgFQJaKqVD8hGNPEZ(u"࡙ࡸࡵࡦᅆ")
			else: gt2RuaDQ683IWeY4fyoLjhpX01xN7 = bE64SRYiqv8e3yH[m6b7CoBk4EQ(u"ࠫࡺࡸ࡬ࠨน")]
			UgRMbihED7elrsQfYO60KA = vGT0rsdfQRBa[jQ6w8xOrgYhSHIRpUqzL-KP0YBtJjwMe3ndSO8qCR2]
			break
	if not PuHXxU4vIlY5EsetaNSnoFg: bbeP1WvXAoaZOtDkzH3VQN = gt2RuaDQ683IWeY4fyoLjhpX01xN7
	else: bbeP1WvXAoaZOtDkzH3VQN = aVLSn1xw5cK(u"ࠬ࡜ࡩࡥࡧࡲ࠾ࠥ࠭บ")+bE64SRYiqv8e3yH[gSmqZU0plur2xKPJwQA(u"࠭ࡵࡳ࡮ࠪป")]+FhcnOB9t3frzvXb(u"ࠧࠡ࠭ࠣࡅࡺࡪࡩࡰ࠼ࠣࠫผ")+kujoZsDhM1YCa6OFXWg3[LmcNhzY6fQPd2JyCGslkSr(u"ࠨࡷࡵࡰࠬฝ")]
	if PuHXxU4vIlY5EsetaNSnoFg:
		LK9zfMSRJ3hnVTDqomr = int(bE64SRYiqv8e3yH[FhcnOB9t3frzvXb(u"ࠩࡧࡹࡷࡧࡴࡪࡱࡱࠫพ")])
		rlxp7vWKVRy9 = int(kujoZsDhM1YCa6OFXWg3[OVmSuf8tpd(u"ࠪࡨࡺࡸࡡࡵ࡫ࡲࡲࠬฟ")])
		UombAD0Kk4XqOrYLB = str(max(LK9zfMSRJ3hnVTDqomr,rlxp7vWKVRy9))
		zjBP6rdtxE07Tgm = bE64SRYiqv8e3yH[kmdSKeBIwViM9t3(u"ࠫࡺࡸ࡬ࠨภ")].replace(kmdSKeBIwViM9t3(u"ࠬࠬࠧม"),c4QSTnPiWUCjhrLlwGB(u"࠭ࠦࡢ࡯ࡳ࠿ࠬย"))
		AqNMsUreF9w5QpG6I = kujoZsDhM1YCa6OFXWg3[bdhQDyjm3nPwToFHkprvCzBLUGR(u"ࠧࡶࡴ࡯ࠫร")].replace(hjNP5w9srJz2QpVISxBfndbD4CkXvl(u"ࠨࠨࠪฤ"),DLSVmlyBbCK(u"ࠩࠩࡥࡲࡶ࠻ࠨล"))
		mpd = LmcNhzY6fQPd2JyCGslkSr(u"ࠪࡀࡄࡾ࡭࡭ࠢࡹࡩࡷࡹࡩࡰࡰࡀࠦ࠶࠴࠰ࠣࠢࡨࡲࡨࡵࡤࡪࡰࡪࡁ࡛ࠧࡔࡇ࠯࠻ࠦࡄࡄ࡜࡯ࠩฦ")
		mpd += aFQoGfmYKyqLU6X8libw9k3ncW5(u"ࠫࡁࡓࡐࡅࠢࡻࡱࡱࡴࡳ࠻ࡺࡶ࡭ࡂࠨࡨࡵࡶࡳ࠾࠴࠵ࡷࡸࡹ࠱ࡻ࠸࠴࡯ࡳࡩ࠲࠶࠵࠶࠱࠰࡚ࡐࡐࡘࡩࡨࡦ࡯ࡤ࠱࡮ࡴࡳࡵࡣࡱࡧࡪࠨࠠࡹ࡯࡯ࡲࡸࡃࠢࡶࡴࡱ࠾ࡲࡶࡥࡨ࠼ࡧࡥࡸ࡮࠺ࡴࡥ࡫ࡩࡲࡧ࠺࡮ࡲࡧ࠾࠷࠶࠱࠲ࠤࠣࡼࡲࡲ࡮ࡴ࠼ࡻࡰ࡮ࡴ࡫࠾ࠤ࡫ࡸࡹࡶ࠺࠰࠱ࡺࡻࡼ࠴ࡷ࠴࠰ࡲࡶ࡬࠵࠱࠺࠻࠼࠳ࡽࡲࡩ࡯࡭ࠥࠤࡽࡹࡩ࠻ࡵࡦ࡬ࡪࡳࡡࡍࡱࡦࡥࡹ࡯࡯࡯࠿ࠥࡹࡷࡴ࠺࡮ࡲࡨ࡫࠿ࡪࡡࡴࡪ࠽ࡷࡨ࡮ࡥ࡮ࡣ࠽ࡱࡵࡪ࠺࠳࠲࠴࠵ࠥ࡮ࡴࡵࡲ࠽࠳࠴ࡹࡴࡢࡰࡧࡥࡷࡪࡳ࠯࡫ࡶࡳ࠳ࡵࡲࡨ࠱࡬ࡸࡹ࡬࠯ࡑࡷࡥࡰ࡮ࡩ࡬ࡺࡃࡹࡥ࡮ࡲࡡࡣ࡮ࡨࡗࡹࡧ࡮ࡥࡣࡵࡨࡸ࠵ࡍࡑࡇࡊ࠱ࡉࡇࡓࡉࡡࡶࡧ࡭࡫࡭ࡢࡡࡩ࡭ࡱ࡫ࡳ࠰ࡆࡄࡗࡍ࠳ࡍࡑࡆ࠱ࡼࡸࡪࠢࠡ࡯࡬ࡲࡇࡻࡦࡧࡧࡵࡘ࡮ࡳࡥ࠾ࠤࡓࡘ࠶࠴࠵ࡔࠤࠣࡱࡪࡪࡩࡢࡒࡵࡩࡸ࡫࡮ࡵࡣࡷ࡭ࡴࡴࡄࡶࡴࡤࡸ࡮ࡵ࡮࠾ࠤࡓࡘࠬว")+UombAD0Kk4XqOrYLB+fR68jBGWCzUsFXdlTKPOScugm(u"࡙ࠬࠢࠡࡶࡼࡴࡪࡃࠢࡴࡶࡤࡸ࡮ࡩࠢࠡࡲࡵࡳ࡫࡯࡬ࡦࡵࡀࠦࡺࡸ࡮࠻࡯ࡳࡩ࡬ࡀࡤࡢࡵ࡫࠾ࡵࡸ࡯ࡧ࡫࡯ࡩ࠿࡯ࡳࡰࡨࡩ࠱ࡲࡧࡩ࡯࠼࠵࠴࠶࠷ࠢ࠿࡞ࡱࠫศ")
		mpd += hjNP5w9srJz2QpVISxBfndbD4CkXvl(u"࠭࠼ࡑࡧࡵ࡭ࡴࡪ࠾࡝ࡰࠪษ")
		mpd += hjNP5w9srJz2QpVISxBfndbD4CkXvl(u"ࠧ࠽ࡃࡧࡥࡵࡺࡡࡵ࡫ࡲࡲࡘ࡫ࡴࠡ࡫ࡧࡁࠧ࠶ࠢࠡ࡯࡬ࡱࡪ࡚ࡹࡱࡧࡀࠦࡻ࡯ࡤࡦࡱ࠲ࠫส")+bE64SRYiqv8e3yH[EDPaWgMt1SwNn8o(u"ࠨࡨ࡬ࡰࡪࡺࡹࡱࡧࠪห")]+bdhQDyjm3nPwToFHkprvCzBLUGR(u"ࠩࠥࠤࡸࡻࡢࡴࡧࡪࡱࡪࡴࡴࡂ࡮࡬࡫ࡳࡳࡥ࡯ࡶࡀࠦࡹࡸࡵࡦࠤࡁࡠࡳ࠭ฬ")
		mpd += EDPaWgMt1SwNn8o(u"ࠪࡀࡗࡵ࡬ࡦࠢࡶࡧ࡭࡫࡭ࡦࡋࡧ࡙ࡷ࡯࠽ࠣࡷࡵࡲ࠿ࡳࡰࡦࡩ࠽ࡈࡆ࡙ࡈ࠻ࡴࡲࡰࡪࡀ࠲࠱࠳࠴ࠦࠥࡼࡡ࡭ࡷࡨࡁࠧࡳࡡࡪࡰࠥ࠳ࡃࡢ࡮ࠨอ")
		mpd += bdhQDyjm3nPwToFHkprvCzBLUGR(u"ࠫࡁࡘࡥࡱࡴࡨࡷࡪࡴࡴࡢࡶ࡬ࡳࡳࠦࡩࡥ࠿ࠥࠫฮ")+bE64SRYiqv8e3yH[FhcnOB9t3frzvXb(u"ࠬ࡯ࡴࡢࡩࠪฯ")]+aFQoGfmYKyqLU6X8libw9k3ncW5(u"࠭ࠢࠡࡥࡲࡨࡪࡩࡳ࠾ࠤࠪะ")+bE64SRYiqv8e3yH[kmdSKeBIwViM9t3(u"ࠧࡤࡱࡧࡩࡨࡹࠧั")]+pEo8g7riWVL014KaRtzQ(u"ࠨࠤࠣࡷࡹࡧࡲࡵ࡙࡬ࡸ࡭࡙ࡁࡑ࠿ࠥ࠵ࠧࠦࡢࡢࡰࡧࡻ࡮ࡪࡴࡩ࠿ࠥࠫา")+str(bE64SRYiqv8e3yH[DLSVmlyBbCK(u"ࠩࡥ࡭ࡹࡸࡡࡵࡧࠪำ")])+ZSJVq5XDrRot(u"ࠪࠦࠥࡽࡩࡥࡶ࡫ࡁࠧ࠭ิ")+str(bE64SRYiqv8e3yH[hjNP5w9srJz2QpVISxBfndbD4CkXvl(u"ࠫࡼ࡯ࡤࡵࡪࠪี")])+DLSVmlyBbCK(u"ࠬࠨࠠࡩࡧ࡬࡫࡭ࡺ࠽ࠣࠩึ")+str(bE64SRYiqv8e3yH[OVmSuf8tpd(u"࠭ࡨࡦ࡫ࡪ࡬ࡹ࠭ื")])+hjNP5w9srJz2QpVISxBfndbD4CkXvl(u"ࠧࠣࠢࡩࡶࡦࡳࡥࡓࡣࡷࡩࡂࠨุࠧ")+bE64SRYiqv8e3yH[aFQoGfmYKyqLU6X8libw9k3ncW5(u"ࠨࡨࡳࡷูࠬ")]+kRYWcNuAazr4jtmBoxFVS19Z6(u"ࠩࠥࡂࡡࡴฺࠧ")
		mpd += yTMWeCgUROcvtsblfK85L62xPk(u"ࠪࡀࡇࡧࡳࡦࡗࡕࡐࡃ࠭฻")+zjBP6rdtxE07Tgm+FhcnOB9t3frzvXb(u"ࠫࡁ࠵ࡂࡢࡵࡨ࡙ࡗࡒ࠾࡝ࡰࠪ฼")
		mpd += JcDaEHuiS8TqBbOhWe4ZgwknoC1L3r(u"ࠬࡂࡓࡦࡩࡰࡩࡳࡺࡂࡢࡵࡨࠤ࡮ࡴࡤࡦࡺࡕࡥࡳ࡭ࡥ࠾ࠤࠪ฽")+bE64SRYiqv8e3yH[JMLhEyaBWmskovGHTrVCxQ08(u"࠭ࡩ࡯ࡦࡨࡼࠬ฾")]+DLSVmlyBbCK(u"ࠧࠣࡀ࡟ࡲࠬ฿")
		mpd += OVmSuf8tpd(u"ࠨ࠾ࡌࡲ࡮ࡺࡩࡢ࡮࡬ࡾࡦࡺࡩࡰࡰࠣࡶࡦࡴࡧࡦ࠿ࠥࠫเ")+bE64SRYiqv8e3yH[OVmSuf8tpd(u"ࠩ࡬ࡲ࡮ࡺࠧแ")]+PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"ࠪࠦࠥ࠵࠾࡝ࡰࠪโ")
		mpd += gSmqZU0plur2xKPJwQA(u"ࠫࡁ࠵ࡓࡦࡩࡰࡩࡳࡺࡂࡢࡵࡨࡂࡡࡴࠧใ")
		mpd += pEo8g7riWVL014KaRtzQ(u"ࠬࡂ࠯ࡓࡧࡳࡶࡪࡹࡥ࡯ࡶࡤࡸ࡮ࡵ࡮࠿࡞ࡱࠫไ")
		mpd += fR68jBGWCzUsFXdlTKPOScugm(u"࠭࠼࠰ࡃࡧࡥࡵࡺࡡࡵ࡫ࡲࡲࡘ࡫ࡴ࠿࡞ࡱࠫๅ")
		mpd += gSmqZU0plur2xKPJwQA(u"ࠧ࠽ࡃࡧࡥࡵࡺࡡࡵ࡫ࡲࡲࡘ࡫ࡴࠡ࡫ࡧࡁࠧ࠷ࠢࠡ࡯࡬ࡱࡪ࡚ࡹࡱࡧࡀࠦࡦࡻࡤࡪࡱ࠲ࠫๆ")+kujoZsDhM1YCa6OFXWg3[DLSVmlyBbCK(u"ࠨࡨ࡬ࡰࡪࡺࡹࡱࡧࠪ็")]+DLSVmlyBbCK(u"ࠩࠥࠤࡸࡻࡢࡴࡧࡪࡱࡪࡴࡴࡂ࡮࡬࡫ࡳࡳࡥ࡯ࡶࡀࠦࡹࡸࡵࡦࠤࡁࡠࡳ่࠭")
		mpd += sArCMRngQNmXkBoKv(u"ࠪࡀࡗࡵ࡬ࡦࠢࡶࡧ࡭࡫࡭ࡦࡋࡧ࡙ࡷ࡯࠽ࠣࡷࡵࡲ࠿ࡳࡰࡦࡩ࠽ࡈࡆ࡙ࡈ࠻ࡴࡲࡰࡪࡀ࠲࠱࠳࠴ࠦࠥࡼࡡ࡭ࡷࡨࡁࠧࡳࡡࡪࡰࠥ࠳ࡃࡢ࡮ࠨ้")
		mpd += eeIL1TfgFQJaKqVD8hGNPEZ(u"ࠫࡁࡘࡥࡱࡴࡨࡷࡪࡴࡴࡢࡶ࡬ࡳࡳࠦࡩࡥ࠿๊ࠥࠫ")+kujoZsDhM1YCa6OFXWg3[kRYWcNuAazr4jtmBoxFVS19Z6(u"ࠬ࡯ࡴࡢࡩ๋ࠪ")]+c4QSTnPiWUCjhrLlwGB(u"࠭ࠢࠡࡥࡲࡨࡪࡩࡳ࠾ࠤࠪ์")+kujoZsDhM1YCa6OFXWg3[bdhQDyjm3nPwToFHkprvCzBLUGR(u"ࠧࡤࡱࡧࡩࡨࡹࠧํ")]+bdhQDyjm3nPwToFHkprvCzBLUGR(u"ࠨࠤࠣࡦࡦࡴࡤࡸ࡫ࡧࡸ࡭ࡃࠢ࠲࠵࠳࠸࠼࠻ࠢ࠿࡞ࡱࠫ๎")
		mpd += aVLSn1xw5cK(u"ࠩ࠿ࡅࡺࡪࡩࡰࡅ࡫ࡥࡳࡴࡥ࡭ࡅࡲࡲ࡫࡯ࡧࡶࡴࡤࡸ࡮ࡵ࡮ࠡࡵࡦ࡬ࡪࡳࡥࡊࡦࡘࡶ࡮ࡃࠢࡶࡴࡱ࠾ࡲࡶࡥࡨ࠼ࡧࡥࡸ࡮࠺࠳࠵࠳࠴࠸ࡀ࠳࠻ࡣࡸࡨ࡮ࡵ࡟ࡤࡪࡤࡲࡳ࡫࡬ࡠࡥࡲࡲ࡫࡯ࡧࡶࡴࡤࡸ࡮ࡵ࡮࠻࠴࠳࠵࠶ࠨࠠࡷࡣ࡯ࡹࡪࡃࠢࠨ๏")+kujoZsDhM1YCa6OFXWg3[kmdSKeBIwViM9t3(u"ࠪࡥࡺࡪࡩࡰࡡࡦ࡬ࡦࡴ࡮ࡦ࡮ࡶࠫ๐")]+JMLhEyaBWmskovGHTrVCxQ08(u"ࠫࠧ࠵࠾࡝ࡰࠪ๑")
		mpd += XogUJZEijT7KWbxeO6(u"ࠬࡂࡂࡢࡵࡨ࡙ࡗࡒ࠾ࠨ๒")+AqNMsUreF9w5QpG6I+JcDaEHuiS8TqBbOhWe4ZgwknoC1L3r(u"࠭࠼࠰ࡄࡤࡷࡪ࡛ࡒࡍࡀ࡟ࡲࠬ๓")
		mpd += XogUJZEijT7KWbxeO6(u"ࠧ࠽ࡕࡨ࡫ࡲ࡫࡮ࡵࡄࡤࡷࡪࠦࡩ࡯ࡦࡨࡼࡗࡧ࡮ࡨࡧࡀࠦࠬ๔")+kujoZsDhM1YCa6OFXWg3[ffCSGrTJYPsxgVQWKLtHU3iMwB(u"ࠨ࡫ࡱࡨࡪࡾࠧ๕")]+MM2BQ7xrAfNivgenXPytGYOs0DEHRC(u"ࠩࠥࡂࡡࡴࠧ๖")
		mpd += sArCMRngQNmXkBoKv(u"ࠪࡀࡎࡴࡩࡵ࡫ࡤࡰ࡮ࢀࡡࡵ࡫ࡲࡲࠥࡸࡡ࡯ࡩࡨࡁࠧ࠭๗")+kujoZsDhM1YCa6OFXWg3[LmcNhzY6fQPd2JyCGslkSr(u"ࠫ࡮ࡴࡩࡵࠩ๘")]+pEo8g7riWVL014KaRtzQ(u"ࠬࠨࠠ࠰ࡀ࡟ࡲࠬ๙")
		mpd += xuYvdJpOEyQKTLNwb(u"࠭࠼࠰ࡕࡨ࡫ࡲ࡫࡮ࡵࡄࡤࡷࡪࡄ࡜࡯ࠩ๚")
		mpd += pEo8g7riWVL014KaRtzQ(u"ࠧ࠽࠱ࡕࡩࡵࡸࡥࡴࡧࡱࡸࡦࡺࡩࡰࡰࡁࡠࡳ࠭๛")
		mpd += fR68jBGWCzUsFXdlTKPOScugm(u"ࠨ࠾࠲ࡅࡩࡧࡰࡵࡣࡷ࡭ࡴࡴࡓࡦࡶࡁࡠࡳ࠭๜")
		mpd += xuYvdJpOEyQKTLNwb(u"ࠩ࠿࠳ࡕ࡫ࡲࡪࡱࡧࡂࡡࡴࠧ๝")
		mpd += wwyUWMFAsO(u"ࠪࡀ࠴ࡓࡐࡅࡀ࡟ࡲࠬ๞")
		if VYMZsxRpcQHPgkaiDKjyoh:
			import http.server as ERogzYCij9
			import http.client as HzUOrm3IV0cpqfLRXSMe6K8
		else:
			import BaseHTTPServer as ERogzYCij9
			import httplib as HzUOrm3IV0cpqfLRXSMe6K8
		class T5fuOtMa04LGsQ1Fh7(ERogzYCij9.HTTPServer):
			def __init__(CMPn7E0iLfArl,ip=LmcNhzY6fQPd2JyCGslkSr(u"ࠫࡱࡵࡣࡢ࡮࡫ࡳࡸࡺࠧ๟"),port=EDPaWgMt1SwNn8o(u"࠺࠻࠰࠶࠷႞"),mpd=JcDaEHuiS8TqBbOhWe4ZgwknoC1L3r(u"ࠬࡂ࠾ࠨ๠")):
				CMPn7E0iLfArl.ip = ip
				CMPn7E0iLfArl.port = port
				CMPn7E0iLfArl.mpd = mpd
				ERogzYCij9.HTTPServer.__init__(CMPn7E0iLfArl,(CMPn7E0iLfArl.ip,CMPn7E0iLfArl.port),UUJlo7EBNC4d0KDbe1pHRFuAW2Z)
				CMPn7E0iLfArl.mpdurl = XogUJZEijT7KWbxeO6(u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࠧ๡")+ip+xuYvdJpOEyQKTLNwb(u"ࠧ࠻ࠩ๢")+str(port)+bdhQDyjm3nPwToFHkprvCzBLUGR(u"ࠨ࠱ࡼࡳࡺࡺࡵࡣࡧ࠱ࡱࡵࡪࠧ๣")
			def start(CMPn7E0iLfArl):
				CMPn7E0iLfArl.threads = K7Mybc2p4irvPHQ1GaIhjXZ(sArCMRngQNmXkBoKv(u"ࡌࡡ࡭ࡵࡨᅇ"))
				CMPn7E0iLfArl.threads.qDZujpko1NmiSc60L9RIQUgF(xuYvdJpOEyQKTLNwb(u"࠷႟"),CMPn7E0iLfArl.bp5PBgqmKON3L4shtxGr6D89YR)
			def bp5PBgqmKON3L4shtxGr6D89YR(CMPn7E0iLfArl):
				CMPn7E0iLfArl.keeprunning = AAgpHN0nMZ(u"ࡔࡳࡷࡨᅈ")
				while CMPn7E0iLfArl.keeprunning:
					CMPn7E0iLfArl.handle_request()
			def stop(CMPn7E0iLfArl):
				CMPn7E0iLfArl.keeprunning = JcDaEHuiS8TqBbOhWe4ZgwknoC1L3r(u"ࡇࡣ࡯ࡷࡪᅉ")
				CMPn7E0iLfArl.pLrBgftnihP9DqQ8eEzXuj2WmlYH()
			def EtRc7idBF6u1rPgh(CMPn7E0iLfArl):
				CMPn7E0iLfArl.stop()
				CMPn7E0iLfArl.z1FdwRrY6OLgZ.close()
				CMPn7E0iLfArl.server_close()
			def vSQaHJD0B8K3y1sXzNE4I(CMPn7E0iLfArl,mpd):
				CMPn7E0iLfArl.mpd = mpd
			def pLrBgftnihP9DqQ8eEzXuj2WmlYH(CMPn7E0iLfArl):
				m5h4wdsHCKLvPu9V6rEFi2q = HzUOrm3IV0cpqfLRXSMe6K8.HTTPConnection(CMPn7E0iLfArl.ip+jYaM5vilgZdFx6QHbApwVXO8et(u"ࠩ࠽ࠫ๤")+str(CMPn7E0iLfArl.port))
				m5h4wdsHCKLvPu9V6rEFi2q.request(Ej67fFyoqW8kbV2HdSK(u"ࠥࡌࡊࡇࡄࠣ๥"), JMLhEyaBWmskovGHTrVCxQ08(u"ࠦ࠴ࠨ๦"))
		class UUJlo7EBNC4d0KDbe1pHRFuAW2Z(ERogzYCij9.BaseHTTPRequestHandler):
			def Wif7gkYamruDlCNTIVKG1O(CMPn7E0iLfArl):
				CMPn7E0iLfArl.send_response(XogUJZEijT7KWbxeO6(u"࠲࠱࠲Ⴀ"))
				CMPn7E0iLfArl.send_header(EDPaWgMt1SwNn8o(u"ࠬࡉ࡯࡯ࡶࡨࡲࡹ࠳ࡴࡺࡲࡨࠫ๧"),ffCSGrTJYPsxgVQWKLtHU3iMwB(u"࠭ࡴࡦࡺࡷࡸ࠴ࡶ࡬ࡢ࡫ࡱࠫ๨"))
				CMPn7E0iLfArl.end_headers()
				CMPn7E0iLfArl.wfile.write(CMPn7E0iLfArl.NGmuWwXdLQ6nMltx39FYECohJ.mpd.encode(m6b7CoBk4EQ(u"ࠧࡶࡶࡩ࠼ࠬ๩")))
				luMHeSgCBaPrb9KvUjNFqcR.sleep(JcDaEHuiS8TqBbOhWe4ZgwknoC1L3r(u"࠲Ⴁ"))
				if CMPn7E0iLfArl.path==pEo8g7riWVL014KaRtzQ(u"ࠨ࠱ࡼࡳࡺࡺࡵࡣࡧ࠱ࡱࡵࡪࠧ๪"): CMPn7E0iLfArl.NGmuWwXdLQ6nMltx39FYECohJ.EtRc7idBF6u1rPgh()
				if CMPn7E0iLfArl.path==XogUJZEijT7KWbxeO6(u"ࠩ࠲ࡷ࡭ࡻࡴࡥࡱࡺࡲࠬ๫"): CMPn7E0iLfArl.NGmuWwXdLQ6nMltx39FYECohJ.EtRc7idBF6u1rPgh()
			def XKe5nAsayQk0tHBVhgT6xZjr9(CMPn7E0iLfArl):
				CMPn7E0iLfArl.send_response(OVmSuf8tpd(u"࠴࠳࠴Ⴂ"))
				CMPn7E0iLfArl.end_headers()
		PHnRyap4rJevEQOoICZNwF10izhf8c = T5fuOtMa04LGsQ1Fh7(Ej67fFyoqW8kbV2HdSK(u"ࠪ࠵࠷࠽࠮࠱࠰࠳࠲࠶࠭๬"),ZSJVq5XDrRot(u"࠸࠹࠵࠻࠵Ⴃ"),mpd)
		gt2RuaDQ683IWeY4fyoLjhpX01xN7 = PHnRyap4rJevEQOoICZNwF10izhf8c.mpdurl
		PHnRyap4rJevEQOoICZNwF10izhf8c.start()
	else: PHnRyap4rJevEQOoICZNwF10izhf8c = yTMWeCgUROcvtsblfK85L62xPk(u"ࠫࠬ๭")
	if not gt2RuaDQ683IWeY4fyoLjhpX01xN7: return yTMWeCgUROcvtsblfK85L62xPk(u"ࠬࡋࡲࡳࡱࡵࠤࠥࠦࠠ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤ࡞ࡕࡕࡕࡗࡅࡉࠥࡌࡡࡪ࡮ࡨࡨࠬ๮"),[],[]
	return hjNP5w9srJz2QpVISxBfndbD4CkXvl(u"࠭ࠧ๯"),[sArCMRngQNmXkBoKv(u"ࠧࠨ๰")],[[gt2RuaDQ683IWeY4fyoLjhpX01xN7,Jt7EANGgL8,PHnRyap4rJevEQOoICZNwF10izhf8c]]
def NATMXtjE0wDV1LzpHx9rg(url):
	headers = { aFQoGfmYKyqLU6X8libw9k3ncW5(u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬ๱") : J3OCAmZVcn(u"ࠩࠪ๲") }
	QstumvzTIEUMXCcx06aD4y8nSqH = QuWA3hsmIvockZDiy2rLg(dALVaOWB4jKN3Tbt0Cm1ns9k5u,url,MM2BQ7xrAfNivgenXPytGYOs0DEHRC(u"ࠪࠫ๳"),headers,hjNP5w9srJz2QpVISxBfndbD4CkXvl(u"ࠫࠬ๴"),LmcNhzY6fQPd2JyCGslkSr(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡘࡌࡈࡇࡕࡂ࠮࠳ࡶࡸࠬ๵"))
	items = ZXFs0mEPR8qI2zj.findall(kmdSKeBIwViM9t3(u"࠭ࡦࡪ࡮ࡨ࠾ࠧ࠮࠮ࠫࡁࠬࠦ࠭࠲࡬ࡢࡤࡨࡰ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧࢂࠩ࡝ࡿࠪ๶"),QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	items = set(items)
	items = sorted(items, reverse=wwyUWMFAsO(u"ࡖࡵࡹࡪᅊ"), key=lambda key: key[eeIL1TfgFQJaKqVD8hGNPEZ(u"࠶Ⴄ")])
	fUmXHDnkK8yCrEbeAdsMwl,xCLQK8kh39sjyi5DXSZAVeI,hk6AGaoeVqUHRbxm792XW,YYmyQXglbEewzL3IA2Sd = [],[],[],[]
	if not items: return fR68jBGWCzUsFXdlTKPOScugm(u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥ࡙ࠢࡍࡉࡈࡏࡃࠩ๷"),[],[]
	for RRucmYBaXegTtNOdGHMQ,vfLGDU1N0e8c,W5V6oRmIDCvcMGBQU in items:
		RRucmYBaXegTtNOdGHMQ = RRucmYBaXegTtNOdGHMQ.replace(eeIL1TfgFQJaKqVD8hGNPEZ(u"ࠨࡪࡷࡸࡵࡹ࠺ࠨ๸"),kRYWcNuAazr4jtmBoxFVS19Z6(u"ࠩ࡫ࡸࡹࡶ࠺ࠨ๹"))
		if AAgpHN0nMZ(u"ࠪ࠲ࡲ࠹ࡵ࠹ࠩ๺") in RRucmYBaXegTtNOdGHMQ:
			fUmXHDnkK8yCrEbeAdsMwl,hk6AGaoeVqUHRbxm792XW = c8T0X52CGk9UZ71q(RRucmYBaXegTtNOdGHMQ)
			YYmyQXglbEewzL3IA2Sd = YYmyQXglbEewzL3IA2Sd + hk6AGaoeVqUHRbxm792XW
			if fUmXHDnkK8yCrEbeAdsMwl[bdhQDyjm3nPwToFHkprvCzBLUGR(u"࠵Ⴅ")]==aFQoGfmYKyqLU6X8libw9k3ncW5(u"ࠫ࠲࠷ࠧ๻"): xCLQK8kh39sjyi5DXSZAVeI.append(PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"ู๊ࠬาใิࠤำอีࠨ๼")+MM2BQ7xrAfNivgenXPytGYOs0DEHRC(u"࠭ࠠࠡࠢࡰ࠷ࡺ࠾ࠧ๽"))
			else:
				for title in fUmXHDnkK8yCrEbeAdsMwl:
					xCLQK8kh39sjyi5DXSZAVeI.append(OVmSuf8tpd(u"ࠧิ์ิๅึࠦฮศืࠪ๾")+gnfv8UtZ3daGqpjzk(u"ࠨࠢࠣࠤࠬ๿")+title)
		else:
			title = PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"ࠩึ๎ึ็ัࠡะสูࠬ຀")+OVmSuf8tpd(u"ࠪࠤࠥࠦ࡭ࡱ࠶ࠣࠤࠥ࠭ກ")+W5V6oRmIDCvcMGBQU
			YYmyQXglbEewzL3IA2Sd.append(RRucmYBaXegTtNOdGHMQ)
			xCLQK8kh39sjyi5DXSZAVeI.append(title)
	return gnfv8UtZ3daGqpjzk(u"ࠫࠬຂ"),xCLQK8kh39sjyi5DXSZAVeI,YYmyQXglbEewzL3IA2Sd
def PmCNXaShAy0RI1rxVDHnvMikQcOj(url,QstumvzTIEUMXCcx06aD4y8nSqH):
	AABKVNO3WiMUSe0,yf608hE5KeRG1DscunvrU,bxWCGVmFzdi1uLEs0Xk5nKvr4TBQO,LngWDh4U7Qs0Jj2ty,R28S4pFmAojEW7CGnx = [],[],[],[],[]
	RRucmYBaXegTtNOdGHMQ = ZXFs0mEPR8qI2zj.findall(ZSJVq5XDrRot(u"ࠬࡂࡶࡪࡦࡨࡳࠥࡶࡲࡦ࡮ࡲࡥࡩ࠴ࠪࡀࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭຃"),QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	if RRucmYBaXegTtNOdGHMQ and not fDEdQSsq1uPoU(RRucmYBaXegTtNOdGHMQ[FhcnOB9t3frzvXb(u"࠶Ⴆ")]): RRucmYBaXegTtNOdGHMQ = []
	if not RRucmYBaXegTtNOdGHMQ: RRucmYBaXegTtNOdGHMQ = ZXFs0mEPR8qI2zj.findall(PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"࠭࠼ࡴࡱࡸࡶࡨ࡫ࠠࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬຄ"),QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	if RRucmYBaXegTtNOdGHMQ and not fDEdQSsq1uPoU(RRucmYBaXegTtNOdGHMQ[jYaM5vilgZdFx6QHbApwVXO8et(u"࠰Ⴇ")]): RRucmYBaXegTtNOdGHMQ = []
	if not RRucmYBaXegTtNOdGHMQ: RRucmYBaXegTtNOdGHMQ = ZXFs0mEPR8qI2zj.findall(fR68jBGWCzUsFXdlTKPOScugm(u"ࠧࡥ࡫ࡵࡩࡨࡺ࡟࡭࡫ࡱ࡯࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭຅"),QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	if RRucmYBaXegTtNOdGHMQ and not fDEdQSsq1uPoU(RRucmYBaXegTtNOdGHMQ[MM2BQ7xrAfNivgenXPytGYOs0DEHRC(u"࠱Ⴈ")]): RRucmYBaXegTtNOdGHMQ = []
	if RRucmYBaXegTtNOdGHMQ:
		RRucmYBaXegTtNOdGHMQ = RRucmYBaXegTtNOdGHMQ[PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"࠲Ⴉ")]
		title = RRucmYBaXegTtNOdGHMQ.rsplit(JMLhEyaBWmskovGHTrVCxQ08(u"ࠨ࠰ࠪຆ"),jYaM5vilgZdFx6QHbApwVXO8et(u"࠴Ⴊ"))[jYaM5vilgZdFx6QHbApwVXO8et(u"࠴Ⴊ")]
		AABKVNO3WiMUSe0.append(title)
		yf608hE5KeRG1DscunvrU.append(RRucmYBaXegTtNOdGHMQ)
	else:
		n5nyDgxTuHbY0LNV4cWvoBtp = ZXFs0mEPR8qI2zj.findall(JcDaEHuiS8TqBbOhWe4ZgwknoC1L3r(u"ࠩࡶࡳࡺࡸࡣࡦࡵ࠽ࠤ࠯࠮࡜࡜࠰࠭ࡃࡡࡣࠩࠨງ"),QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
		if not n5nyDgxTuHbY0LNV4cWvoBtp: n5nyDgxTuHbY0LNV4cWvoBtp = ZXFs0mEPR8qI2zj.findall(kRYWcNuAazr4jtmBoxFVS19Z6(u"ࠪࡺࡦࡸࠠࡴࡱࡸࡶࡨ࡫ࡳࠡ࠿ࠣࠬࡡࢁ࠮ࠫࡁ࡟ࢁ࠮࠭ຈ"),QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
		if not n5nyDgxTuHbY0LNV4cWvoBtp: n5nyDgxTuHbY0LNV4cWvoBtp = ZXFs0mEPR8qI2zj.findall(OVmSuf8tpd(u"ࠫࡻࡧࡲࠡ࡬ࡺࠤࡂࠦࠨ࡝ࡽ࠱࠮ࡄࡢࡽࠪࠩຉ"),QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
		if not n5nyDgxTuHbY0LNV4cWvoBtp: n5nyDgxTuHbY0LNV4cWvoBtp = ZXFs0mEPR8qI2zj.findall(DLSVmlyBbCK(u"ࠬࡼࡡࡳࠢࡳࡰࡦࡿࡥࡳࠢࡀࠤ࠳࠰࠿࡝ࠪࠫࡠࢀ࠴ࠪࡀ࡞ࢀ࠭ࡡ࠯ࠧຊ"),QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
		if n5nyDgxTuHbY0LNV4cWvoBtp:
			n5nyDgxTuHbY0LNV4cWvoBtp = n5nyDgxTuHbY0LNV4cWvoBtp[MM2BQ7xrAfNivgenXPytGYOs0DEHRC(u"࠴Ⴋ")]
			n5nyDgxTuHbY0LNV4cWvoBtp = ZXFs0mEPR8qI2zj.sub(AAgpHN0nMZ(u"ࡸࠧࠩ࡝࡟ࡿࡡ࠲࡝࡜࡞ࡷࡠࡸࡢ࡮࡝ࡴࡠ࠮࠮࠮࡜ࡸ࠭࡞ࡠࡹࡢࡳ࡞ࠬࠬ࠾ࠬ຋"),xuYvdJpOEyQKTLNwb(u"ࡲࠨ࡞࠴ࠦࡡ࠸ࠢ࠻ࠩຌ"),n5nyDgxTuHbY0LNV4cWvoBtp)
			n5nyDgxTuHbY0LNV4cWvoBtp = NL0JIkbrEWqTYj61vVKGCnBw37MsOF(yTMWeCgUROcvtsblfK85L62xPk(u"ࠨࡦ࡬ࡧࡹ࠭ຍ"),n5nyDgxTuHbY0LNV4cWvoBtp)
			if isinstance(n5nyDgxTuHbY0LNV4cWvoBtp,dict): n5nyDgxTuHbY0LNV4cWvoBtp = [n5nyDgxTuHbY0LNV4cWvoBtp]
			for bdq4e6Wr2gslnSiA38 in n5nyDgxTuHbY0LNV4cWvoBtp:
				ZdI7pLnwH1oQ0bNt58Tvk,RRucmYBaXegTtNOdGHMQ = eeIL1TfgFQJaKqVD8hGNPEZ(u"ࠩࠪຎ"),sArCMRngQNmXkBoKv(u"ࠪࠫຏ")
				if isinstance(bdq4e6Wr2gslnSiA38,dict):
					keys = list(bdq4e6Wr2gslnSiA38.keys())
					if   gSmqZU0plur2xKPJwQA(u"ࠫࡹࡿࡰࡦࠩຐ") in keys: ZdI7pLnwH1oQ0bNt58Tvk = str(bdq4e6Wr2gslnSiA38[fR68jBGWCzUsFXdlTKPOScugm(u"ࠬࡺࡹࡱࡧࠪຑ")])
					if   gnfv8UtZ3daGqpjzk(u"࠭ࡦࡪ࡮ࡨࠫຒ") in keys: RRucmYBaXegTtNOdGHMQ = bdq4e6Wr2gslnSiA38[hjNP5w9srJz2QpVISxBfndbD4CkXvl(u"ࠧࡧ࡫࡯ࡩࠬຓ")]
					elif ffCSGrTJYPsxgVQWKLtHU3iMwB(u"ࠨࡪ࡯ࡷࠬດ") in keys: RRucmYBaXegTtNOdGHMQ = bdq4e6Wr2gslnSiA38[hjNP5w9srJz2QpVISxBfndbD4CkXvl(u"ࠩ࡫ࡰࡸ࠭ຕ")]
					elif EDPaWgMt1SwNn8o(u"ࠪࡷࡷࡩࠧຖ") in keys: RRucmYBaXegTtNOdGHMQ = bdq4e6Wr2gslnSiA38[eeIL1TfgFQJaKqVD8hGNPEZ(u"ࠫࡸࡸࡣࠨທ")]
					if   pEo8g7riWVL014KaRtzQ(u"ࠬࡲࡡࡣࡧ࡯ࠫຘ") in keys: title = str(bdq4e6Wr2gslnSiA38[bdhQDyjm3nPwToFHkprvCzBLUGR(u"࠭࡬ࡢࡤࡨࡰࠬນ")])
					elif kmdSKeBIwViM9t3(u"ࠧࡷ࡫ࡧࡩࡴࡥࡨࡦ࡫ࡪ࡬ࡹ࠭ບ") in keys: title = str(bdq4e6Wr2gslnSiA38[kmdSKeBIwViM9t3(u"ࠨࡸ࡬ࡨࡪࡵ࡟ࡩࡧ࡬࡫࡭ࡺࠧປ")])
					elif Ej67fFyoqW8kbV2HdSK(u"ࠩ࠱ࠫຜ") in RRucmYBaXegTtNOdGHMQ: title = RRucmYBaXegTtNOdGHMQ.rsplit(c4QSTnPiWUCjhrLlwGB(u"ࠪ࠲ࠬຝ"),XogUJZEijT7KWbxeO6(u"࠶Ⴌ"))[XogUJZEijT7KWbxeO6(u"࠶Ⴌ")]
					else: title = RRucmYBaXegTtNOdGHMQ
				elif isinstance(bdq4e6Wr2gslnSiA38,str):
					RRucmYBaXegTtNOdGHMQ = bdq4e6Wr2gslnSiA38
					title = RRucmYBaXegTtNOdGHMQ.rsplit(kRYWcNuAazr4jtmBoxFVS19Z6(u"ࠫ࠳࠭ພ"),m6b7CoBk4EQ(u"࠷Ⴍ"))[m6b7CoBk4EQ(u"࠷Ⴍ")]
				if fR68jBGWCzUsFXdlTKPOScugm(u"࠱Ⴎ"):
					AABKVNO3WiMUSe0.append(title+kmdSKeBIwViM9t3(u"ࠬࠦࠠࠨຟ")+ZdI7pLnwH1oQ0bNt58Tvk)
					yf608hE5KeRG1DscunvrU.append(RRucmYBaXegTtNOdGHMQ)
	for RRucmYBaXegTtNOdGHMQ,title in zip(yf608hE5KeRG1DscunvrU,AABKVNO3WiMUSe0):
		RRucmYBaXegTtNOdGHMQ = RRucmYBaXegTtNOdGHMQ.replace(m6b7CoBk4EQ(u"࠭࡜࡝࠱ࠪຠ"),jYaM5vilgZdFx6QHbApwVXO8et(u"ࠧ࠰ࠩມ"))
		NGmuWwXdLQ6nMltx39FYECohJ = d78KRnJmBWscGua0XMk(url,ZSJVq5XDrRot(u"ࠨࡷࡵࡰࠬຢ"))
		k0kUAjI76Erhgf = SjMG7CYyUqbPVso0DErhXROvkl()
		if AAgpHN0nMZ(u"ࠩ࡫ࡸࡹࡶࠧຣ") not in RRucmYBaXegTtNOdGHMQ: RRucmYBaXegTtNOdGHMQ = NGmuWwXdLQ6nMltx39FYECohJ+RRucmYBaXegTtNOdGHMQ
		if DLSVmlyBbCK(u"ࠪ࠲ࡲ࠹ࡵ࠹ࠩ຤") in RRucmYBaXegTtNOdGHMQ:
			headers = {xuYvdJpOEyQKTLNwb(u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨລ"):k0kUAjI76Erhgf,eeIL1TfgFQJaKqVD8hGNPEZ(u"ࠬࡘࡥࡧࡧࡵࡩࡷ࠭຦"):NGmuWwXdLQ6nMltx39FYECohJ}
			cWLwgjed4ChZrpMqSJ5t,QZpYNEGzOmTcu10yb = c8T0X52CGk9UZ71q(RRucmYBaXegTtNOdGHMQ,headers)
			LngWDh4U7Qs0Jj2ty += QZpYNEGzOmTcu10yb
			bxWCGVmFzdi1uLEs0Xk5nKvr4TBQO += cWLwgjed4ChZrpMqSJ5t
		else:
			RRucmYBaXegTtNOdGHMQ = RRucmYBaXegTtNOdGHMQ+fR68jBGWCzUsFXdlTKPOScugm(u"࠭ࡼࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࡁࠬວ")+k0kUAjI76Erhgf+kRYWcNuAazr4jtmBoxFVS19Z6(u"ࠧࠧࡔࡨࡪࡪࡸࡥࡳ࠿ࠪຨ")+NGmuWwXdLQ6nMltx39FYECohJ
			LngWDh4U7Qs0Jj2ty.append(RRucmYBaXegTtNOdGHMQ)
			bxWCGVmFzdi1uLEs0Xk5nKvr4TBQO.append(title)
	svA3Xnq5GbkTcZPHd,AABKVNO3WiMUSe0,yf608hE5KeRG1DscunvrU = aVLSn1xw5cK(u"ࠨࠩຩ"),[],[]
	if LngWDh4U7Qs0Jj2ty: svA3Xnq5GbkTcZPHd,AABKVNO3WiMUSe0,yf608hE5KeRG1DscunvrU = AAgpHN0nMZ(u"ࠩࠪສ"),bxWCGVmFzdi1uLEs0Xk5nKvr4TBQO,LngWDh4U7Qs0Jj2ty
	else:
		if gnfv8UtZ3daGqpjzk(u"ࠪࡀࠬຫ") not in QstumvzTIEUMXCcx06aD4y8nSqH and len(QstumvzTIEUMXCcx06aD4y8nSqH)<yTMWeCgUROcvtsblfK85L62xPk(u"࠲࠲࠳Ⴏ") and QstumvzTIEUMXCcx06aD4y8nSqH: svA3Xnq5GbkTcZPHd = QstumvzTIEUMXCcx06aD4y8nSqH
		else:
			msg = ZXFs0mEPR8qI2zj.findall(gSmqZU0plur2xKPJwQA(u"ࠫࡁࡪࡩࡷࠢࡶࡸࡾࡲࡥ࠾ࠤ࠱࠮ࡄࠨ࠾ࠩࡈ࡬ࡰࡪ࠴ࠪࡀࠫ࠿ࠫຬ"),QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
			if not msg: msg = ZXFs0mEPR8qI2zj.findall(J3OCAmZVcn(u"ࠬࡂࡤࡪࡸࠣࡧࡱࡧࡳࡴ࠿ࠥࡺࡵࡥࡶࡪࡦࡨࡳࡤࡹࡴࡶࡤࡢࡸࡽࡺࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨອ"),QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
			if not msg: msg = ZXFs0mEPR8qI2zj.findall(sArCMRngQNmXkBoKv(u"࠭࠼ࡩ࠴ࡁࠬࡘࡵࡲࡳࡻ࠱࠮ࡄ࠯࠼ࠨຮ"),QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
			if msg: svA3Xnq5GbkTcZPHd = msg[m6b7CoBk4EQ(u"࠲Ⴐ")]
	return svA3Xnq5GbkTcZPHd,AABKVNO3WiMUSe0,yf608hE5KeRG1DscunvrU
def EEB6DW7QJK(ffBuorhq4SU2,url):
	global Tzt8HviFYVMBhf1ldoq3GI5
	url = url.strip(m6b7CoBk4EQ(u"ࠧ࠰ࠩຯ"))
	GHNJWEoudbyOrUz,VbZ1Pig043uIGYQ = yTMWeCgUROcvtsblfK85L62xPk(u"ࠨࠩະ"),{}
	headers = {c4QSTnPiWUCjhrLlwGB(u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭ັ"):SjMG7CYyUqbPVso0DErhXROvkl()}
	headers[yTMWeCgUROcvtsblfK85L62xPk(u"ࠪࡖࡪ࡬ࡥࡳࡧࡵࠫາ")] = d78KRnJmBWscGua0XMk(url,sArCMRngQNmXkBoKv(u"ࠫࡺࡸ࡬ࠨຳ"))
	headers[PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"ࠬࡇࡣࡤࡧࡳࡸ࠲ࡒࡡ࡯ࡩࡸࡥ࡬࡫ࠧິ")] = J3OCAmZVcn(u"࠭ࡥ࡯࠯ࡘࡗ࠱࡫࡮࠼ࡳࡀ࠴࠳࠿ࠧີ")
	headers[ffCSGrTJYPsxgVQWKLtHU3iMwB(u"ࠧࡔࡧࡦ࠱ࡋ࡫ࡴࡤࡪ࠰ࡈࡪࡹࡴࠨຶ")] = J3OCAmZVcn(u"ࠨ࡫ࡩࡶࡦࡳࡥࠨື")
	wpFmEA3z8JR = A6F71g3cqN4(dALVaOWB4jKN3Tbt0Cm1ns9k5u,m6b7CoBk4EQ(u"ࠩࡊࡉຸ࡙࠭"),url,wwyUWMFAsO(u"ູࠪࠫ"),headers,wwyUWMFAsO(u"຺ࠫࠬ"),XogUJZEijT7KWbxeO6(u"ࡉࡥࡱࡹࡥᅋ"),PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮࡚ࡖࡌࡆࡘࡉࡏࡉ࠰࠵ࡸࡺࠧົ"))
	QstumvzTIEUMXCcx06aD4y8nSqH = wpFmEA3z8JR.content
	Hf42g9qI3oeD18xKhA0kwaQuRF = wpFmEA3z8JR.code
	if not isinstance(QstumvzTIEUMXCcx06aD4y8nSqH,str): QstumvzTIEUMXCcx06aD4y8nSqH = QstumvzTIEUMXCcx06aD4y8nSqH.decode(jYaM5vilgZdFx6QHbApwVXO8et(u"࠭ࡵࡵࡨ࠻ࠫຼ"),sArCMRngQNmXkBoKv(u"ࠧࡪࡩࡱࡳࡷ࡫ࠧຽ"))
	if JcDaEHuiS8TqBbOhWe4ZgwknoC1L3r(u"ࠨࡨࡸࡲࡨࡺࡩࡰࡰࠫࡴ࠱ࡧࠬࡤ࠮࡮࠰ࡪ࠲ࠧ຾") in QstumvzTIEUMXCcx06aD4y8nSqH:
		WYRLUPvTZcIHGAnsljMbKhDBEVNOg = ZXFs0mEPR8qI2zj.findall(DLSVmlyBbCK(u"ࠩࠫࡩࡻࡧ࡬࡝ࠪࡩࡹࡳࡩࡴࡪࡱࡱࡠ࠭ࡶࠬࡢ࠮ࡦ࠰ࡰ࠲ࡥ࠭࡝ࡧࡶࡢ࠴ࠪࡀࠫ࠿࠳ࡸࡩࡲࡪࡲࡷࡂࠬ຿"),QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
		if WYRLUPvTZcIHGAnsljMbKhDBEVNOg:
			try: GHNJWEoudbyOrUz = yBUaLu7GJmpc(WYRLUPvTZcIHGAnsljMbKhDBEVNOg[Ej67fFyoqW8kbV2HdSK(u"࠳Ⴑ")])
			except: GHNJWEoudbyOrUz = OVmSuf8tpd(u"ࠪࠫເ")
	XgMyLUkfvP4uKVpQsY8RiWZz6N50O = QstumvzTIEUMXCcx06aD4y8nSqH+GHNJWEoudbyOrUz
	if aFQoGfmYKyqLU6X8libw9k3ncW5(u"ࠫࠧ࡯ࡤ࠳ࠤࠪແ") in XgMyLUkfvP4uKVpQsY8RiWZz6N50O or jYaM5vilgZdFx6QHbApwVXO8et(u"ࠬࠨࡩࡥࠤࠪໂ") in XgMyLUkfvP4uKVpQsY8RiWZz6N50O:
		AiSfDjOH5Pse27EkGMy = url.split(JcDaEHuiS8TqBbOhWe4ZgwknoC1L3r(u"࠭࠯ࠨໃ"))[ffCSGrTJYPsxgVQWKLtHU3iMwB(u"࠷Ⴒ")].replace(FhcnOB9t3frzvXb(u"ࠧࡦ࡯ࡥࡩࡩ࠳ࠧໄ"),m6b7CoBk4EQ(u"ࠨࠩ໅")).replace(JMLhEyaBWmskovGHTrVCxQ08(u"ࠩ࠱࡬ࡹࡳ࡬ࠨໆ"),PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"ࠪࠫ໇"))
		if pEo8g7riWVL014KaRtzQ(u"ࠫࠧ࡯ࡤ࠳ࠤ່ࠪ") in XgMyLUkfvP4uKVpQsY8RiWZz6N50O: VbZ1Pig043uIGYQ = {XogUJZEijT7KWbxeO6(u"ࠬ࡯ࡤ࠳້ࠩ"):AiSfDjOH5Pse27EkGMy,LmcNhzY6fQPd2JyCGslkSr(u"࠭࡯ࡱ໊ࠩ"):aVLSn1xw5cK(u"ࠧࡥࡱࡺࡲࡱࡵࡡࡥ࠴໋ࠪ")}
		elif yTMWeCgUROcvtsblfK85L62xPk(u"ࠨࠤ࡬ࡨࠧ࠭໌") in XgMyLUkfvP4uKVpQsY8RiWZz6N50O: VbZ1Pig043uIGYQ = {JMLhEyaBWmskovGHTrVCxQ08(u"ࠩ࡬ࡨࠬໍ"):AiSfDjOH5Pse27EkGMy,FhcnOB9t3frzvXb(u"ࠪࡳࡵ࠭໎"):hjNP5w9srJz2QpVISxBfndbD4CkXvl(u"ࠫࡩࡵࡷ࡯࡮ࡲࡥࡩ࠸ࠧ໏")}
		obS4TpHeV3digGC = headers.copy()
		obS4TpHeV3digGC[EDPaWgMt1SwNn8o(u"ࠬࡉ࡯࡯ࡶࡨࡲࡹ࠳ࡔࡺࡲࡨࠫ໐")] = JcDaEHuiS8TqBbOhWe4ZgwknoC1L3r(u"࠭ࡡࡱࡲ࡯࡭ࡨࡧࡴࡪࡱࡱ࠳ࡽ࠳ࡷࡸࡹ࠰ࡪࡴࡸ࡭࠮ࡷࡵࡰࡪࡴࡣࡰࡦࡨࡨࠬ໑")
		qShkDLtUac9u = A6F71g3cqN4(dALVaOWB4jKN3Tbt0Cm1ns9k5u,xuYvdJpOEyQKTLNwb(u"ࠧࡑࡑࡖࡘࠬ໒"),url,VbZ1Pig043uIGYQ,obS4TpHeV3digGC,kmdSKeBIwViM9t3(u"ࠨࠩ໓"),wwyUWMFAsO(u"ࡊࡦࡲࡳࡦᅌ"),yTMWeCgUROcvtsblfK85L62xPk(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲࡞ࡓࡉࡃࡕࡍࡓࡍ࠭࠳ࡰࡧࠫ໔"))
		XgMyLUkfvP4uKVpQsY8RiWZz6N50O = qShkDLtUac9u.content
	InQmaOESzZYdK6N09HhkqGl8MAeo3,M3i7e906aCDNEhmRx8UOA42oryF,K6QoO5h391YjpsbnABC = PmCNXaShAy0RI1rxVDHnvMikQcOj(url,XgMyLUkfvP4uKVpQsY8RiWZz6N50O)
	Tzt8HviFYVMBhf1ldoq3GI5[ffBuorhq4SU2] = InQmaOESzZYdK6N09HhkqGl8MAeo3,M3i7e906aCDNEhmRx8UOA42oryF,K6QoO5h391YjpsbnABC,Hf42g9qI3oeD18xKhA0kwaQuRF
	return
Tzt8HviFYVMBhf1ldoq3GI5,S28H0Mk9spXFBx4PZvDGIUTrj6t7 = {},bdhQDyjm3nPwToFHkprvCzBLUGR(u"࠵Ⴓ")
def ZbGHtxq8Ne2S(url):
	global Tzt8HviFYVMBhf1ldoq3GI5,S28H0Mk9spXFBx4PZvDGIUTrj6t7
	R28S4pFmAojEW7CGnx,threads = [],[]
	S28H0Mk9spXFBx4PZvDGIUTrj6t7 += PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"࠷࠰࠱Ⴔ")
	XJDSp8dToncwEg = S28H0Mk9spXFBx4PZvDGIUTrj6t7
	R28S4pFmAojEW7CGnx.append([m6b7CoBk4EQ(u"࠱Ⴕ"),url])
	Tzt8HviFYVMBhf1ldoq3GI5[XJDSp8dToncwEg+OVmSuf8tpd(u"࠲Ⴖ")] = [None,None,None,None]
	AAZ0ohJ2ywm = c3cgVjNv1rde.Thread(target=EEB6DW7QJK,args=(XJDSp8dToncwEg+c4QSTnPiWUCjhrLlwGB(u"࠳Ⴗ"),url))
	AAZ0ohJ2ywm.start()
	AAZ0ohJ2ywm.join(bdhQDyjm3nPwToFHkprvCzBLUGR(u"࠴࠴Ⴘ"))
	if not Tzt8HviFYVMBhf1ldoq3GI5[XJDSp8dToncwEg+eeIL1TfgFQJaKqVD8hGNPEZ(u"࠵Ⴙ")][MM2BQ7xrAfNivgenXPytGYOs0DEHRC(u"࠷Ⴚ")]:
		lQHXdV9Nzf6BLqS8D = url.replace(c4QSTnPiWUCjhrLlwGB(u"ࠪ࠳ࡪࡳࡢࡦࡦ࠰ࠫ໕"),yTMWeCgUROcvtsblfK85L62xPk(u"ࠫ࠴࠭໖"))
		mcEHCT3jSM = ZXFs0mEPR8qI2zj.findall(eeIL1TfgFQJaKqVD8hGNPEZ(u"ࠬࡤࠨ࠯ࠬࡂ࠾࠴࠵࠮ࠫࡁࠬ࠳࠭࠴ࠪࡀࠫ࠲ࠬ࠳࠰࠿ࠪࠦࠪ໗"),lQHXdV9Nzf6BLqS8D+J3OCAmZVcn(u"࠭࠯ࠨ໘"),ZXFs0mEPR8qI2zj.DOTALL)
		start,NWE9sXDG7duyKChnFO8Tbx5ewcpVaB,end = mcEHCT3jSM[AAgpHN0nMZ(u"࠶Ⴛ")]
		end = end.strip(AAgpHN0nMZ(u"ࠧ࠰ࠩ໙"))
		dQjy8vn2iWhZO = len(NWE9sXDG7duyKChnFO8Tbx5ewcpVaB)<xuYvdJpOEyQKTLNwb(u"࠴Ⴜ") or NWE9sXDG7duyKChnFO8Tbx5ewcpVaB in [OVmSuf8tpd(u"ࠨࡨ࡬ࡰࡪ࠭໚"),sArCMRngQNmXkBoKv(u"ࠩࡹ࡭ࡩ࡫࡯ࠨ໛"),kRYWcNuAazr4jtmBoxFVS19Z6(u"ࠪࡺ࡮ࡪࡥࡰࡧࡰࡦࡪࡪࠧໜ"),DLSVmlyBbCK(u"ࠫࡦࡰࡡࡹࠩໝ"),pEo8g7riWVL014KaRtzQ(u"ࠬ࡯ࡦࡳࡣࡰࡩࠬໞ"),ZSJVq5XDrRot(u"࠭࡭ࡪࡴࡵࡳࡷ࠭ໟ")]
		if not dQjy8vn2iWhZO: R28S4pFmAojEW7CGnx.append([xuYvdJpOEyQKTLNwb(u"࠳Ⴝ"),start+PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"ࠧ࠰ࡧࡰࡦࡪࡪ࠭ࠨ໠")+NWE9sXDG7duyKChnFO8Tbx5ewcpVaB+J3OCAmZVcn(u"ࠨ࠱ࠪ໡")+end])
		if end: R28S4pFmAojEW7CGnx.append([hjNP5w9srJz2QpVISxBfndbD4CkXvl(u"࠵Ⴞ"),start+AAgpHN0nMZ(u"ࠩ࠲ࠫ໢")+NWE9sXDG7duyKChnFO8Tbx5ewcpVaB+Ej67fFyoqW8kbV2HdSK(u"ࠪ࠳ࡪࡳࡢࡦࡦ࠰ࠫ໣")+end])
		if ffCSGrTJYPsxgVQWKLtHU3iMwB(u"ࠫ࠳࡮ࡴ࡮࡮ࠪ໤") in NWE9sXDG7duyKChnFO8Tbx5ewcpVaB:
			kFmEYSNi5PwWIVHeAcoK = NWE9sXDG7duyKChnFO8Tbx5ewcpVaB.replace(ffCSGrTJYPsxgVQWKLtHU3iMwB(u"ࠬ࠴ࡨࡵ࡯࡯ࠫ໥"),fR68jBGWCzUsFXdlTKPOScugm(u"࠭ࠧ໦"))
			R28S4pFmAojEW7CGnx.append([wwyUWMFAsO(u"࠷Ⴟ"),start+PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"ࠧ࠰ࠩ໧")+kFmEYSNi5PwWIVHeAcoK+JMLhEyaBWmskovGHTrVCxQ08(u"ࠨ࠱ࠪ໨")+end])
			R28S4pFmAojEW7CGnx.append([AAgpHN0nMZ(u"࠹Ⴠ"),start+FhcnOB9t3frzvXb(u"ࠩ࠲ࡩࡲࡨࡥࡥ࠯ࠪ໩")+kFmEYSNi5PwWIVHeAcoK+pEo8g7riWVL014KaRtzQ(u"ࠪ࠳ࠬ໪")+end])
			if end: R28S4pFmAojEW7CGnx.append([wwyUWMFAsO(u"࠻Ⴡ"),start+Ej67fFyoqW8kbV2HdSK(u"ࠫ࠴࠭໫")+kFmEYSNi5PwWIVHeAcoK+hjNP5w9srJz2QpVISxBfndbD4CkXvl(u"ࠬ࠵ࡥ࡮ࡤࡨࡨ࠲࠭໬")+end])
		elif hjNP5w9srJz2QpVISxBfndbD4CkXvl(u"࠭࠮ࡩࡶࡰࡰࠬ໭") in end:
			usxJFaWzI6v4H2eMCfTc = end.replace(yTMWeCgUROcvtsblfK85L62xPk(u"ࠧ࠯ࡪࡷࡱࡱ࠭໮"),gSmqZU0plur2xKPJwQA(u"ࠨࠩ໯"))
			R28S4pFmAojEW7CGnx.append([JcDaEHuiS8TqBbOhWe4ZgwknoC1L3r(u"࠽Ⴢ"),start+pEo8g7riWVL014KaRtzQ(u"ࠩ࠲ࠫ໰")+NWE9sXDG7duyKChnFO8Tbx5ewcpVaB+DLSVmlyBbCK(u"ࠪ࠳ࠬ໱")+usxJFaWzI6v4H2eMCfTc])
			if not dQjy8vn2iWhZO: R28S4pFmAojEW7CGnx.append([AAgpHN0nMZ(u"࠸Ⴣ"),start+bdhQDyjm3nPwToFHkprvCzBLUGR(u"ࠫ࠴࡫࡭ࡣࡧࡧ࠱ࠬ໲")+NWE9sXDG7duyKChnFO8Tbx5ewcpVaB+eeIL1TfgFQJaKqVD8hGNPEZ(u"ࠬ࠵ࠧ໳")+usxJFaWzI6v4H2eMCfTc])
			R28S4pFmAojEW7CGnx.append([EDPaWgMt1SwNn8o(u"࠺Ⴤ"),start+c4QSTnPiWUCjhrLlwGB(u"࠭࠯ࠨ໴")+NWE9sXDG7duyKChnFO8Tbx5ewcpVaB+OVmSuf8tpd(u"ࠧ࠰ࡧࡰࡦࡪࡪ࠭ࠨ໵")+usxJFaWzI6v4H2eMCfTc])
		else:
			if not dQjy8vn2iWhZO: R28S4pFmAojEW7CGnx.append([yTMWeCgUROcvtsblfK85L62xPk(u"࠳࠳Ⴥ"),start+Ej67fFyoqW8kbV2HdSK(u"ࠨ࠱ࠪ໶")+NWE9sXDG7duyKChnFO8Tbx5ewcpVaB+gnfv8UtZ3daGqpjzk(u"ࠩ࠱࡬ࡹࡳ࡬ࠨ໷")])
			if not dQjy8vn2iWhZO: R28S4pFmAojEW7CGnx.append([jYaM5vilgZdFx6QHbApwVXO8et(u"࠴࠵჆"),start+pEo8g7riWVL014KaRtzQ(u"ࠪ࠳ࡪࡳࡢࡦࡦ࠰ࠫ໸")+NWE9sXDG7duyKChnFO8Tbx5ewcpVaB+xuYvdJpOEyQKTLNwb(u"ࠫ࠳࡮ࡴ࡮࡮ࠪ໹")])
			if end: R28S4pFmAojEW7CGnx.append([JMLhEyaBWmskovGHTrVCxQ08(u"࠵࠷Ⴧ"),start+jYaM5vilgZdFx6QHbApwVXO8et(u"ࠬ࠵ࠧ໺")+NWE9sXDG7duyKChnFO8Tbx5ewcpVaB+FhcnOB9t3frzvXb(u"࠭࠯ࠨ໻")+end+m6b7CoBk4EQ(u"ࠧ࠯ࡪࡷࡱࡱ࠭໼")])
			if end: R28S4pFmAojEW7CGnx.append([J3OCAmZVcn(u"࠶࠹჈"),start+JMLhEyaBWmskovGHTrVCxQ08(u"ࠨ࠱ࠪ໽")+NWE9sXDG7duyKChnFO8Tbx5ewcpVaB+AAgpHN0nMZ(u"ࠩ࠲ࡩࡲࡨࡥࡥ࠯ࠪ໾")+end+fR68jBGWCzUsFXdlTKPOScugm(u"ࠪ࠲࡭ࡺ࡭࡭ࠩ໿")])
		if dQjy8vn2iWhZO and end:
			end = end.replace(eeIL1TfgFQJaKqVD8hGNPEZ(u"ࠫ࠴࡫࡭ࡣࡧࡧ࠱ࠬༀ"),AAgpHN0nMZ(u"ࠬ࠵ࠧ༁"))
			R28S4pFmAojEW7CGnx.append([AAgpHN0nMZ(u"࠷࠴჉"),start+PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"࠭࠯ࠨ༂")+end])
			R28S4pFmAojEW7CGnx.append([wwyUWMFAsO(u"࠱࠶჊"),start+fR68jBGWCzUsFXdlTKPOScugm(u"ࠧ࠰ࡧࡰࡦࡪࡪ࠭ࠨ༃")+end])
			if MM2BQ7xrAfNivgenXPytGYOs0DEHRC(u"ࠨ࠰࡫ࡸࡲࡲࠧ༄") in end:
				usxJFaWzI6v4H2eMCfTc = end.replace(sArCMRngQNmXkBoKv(u"ࠩ࠱࡬ࡹࡳ࡬ࠨ༅"),gSmqZU0plur2xKPJwQA(u"ࠪࠫ༆"))
				R28S4pFmAojEW7CGnx.append([ffCSGrTJYPsxgVQWKLtHU3iMwB(u"࠲࠸჋"),start+EDPaWgMt1SwNn8o(u"ࠫ࠴࠭༇")+usxJFaWzI6v4H2eMCfTc])
				R28S4pFmAojEW7CGnx.append([kmdSKeBIwViM9t3(u"࠳࠺჌"),start+kmdSKeBIwViM9t3(u"ࠬ࠵ࡥ࡮ࡤࡨࡨ࠲࠭༈")+usxJFaWzI6v4H2eMCfTc])
			else:
				R28S4pFmAojEW7CGnx.append([eeIL1TfgFQJaKqVD8hGNPEZ(u"࠴࠼Ⴭ"),start+J3OCAmZVcn(u"࠭࠯ࠨ༉")+end+EDPaWgMt1SwNn8o(u"ࠧ࠯ࡪࡷࡱࡱ࠭༊")])
				R28S4pFmAojEW7CGnx.append([gnfv8UtZ3daGqpjzk(u"࠵࠾჎"),start+EDPaWgMt1SwNn8o(u"ࠨ࠱ࡨࡱࡧ࡫ࡤ࠮ࠩ་")+end+MM2BQ7xrAfNivgenXPytGYOs0DEHRC(u"ࠩ࠱࡬ࡹࡳ࡬ࠨ༌")])
		JAyae4XNGfp235YOicRuTKkjqLF7dl = []
		for yfZpUog0Rbs8CFEv9,RRucmYBaXegTtNOdGHMQ in R28S4pFmAojEW7CGnx[aVLSn1xw5cK(u"࠶჏"):]:
			Tzt8HviFYVMBhf1ldoq3GI5[XJDSp8dToncwEg+yfZpUog0Rbs8CFEv9] = [None,None,None,None]
			bqnzQDC3UXja7eBpcgPZRdtMIi = c3cgVjNv1rde.Thread(target=EEB6DW7QJK,args=(XJDSp8dToncwEg+yfZpUog0Rbs8CFEv9,RRucmYBaXegTtNOdGHMQ))
			bqnzQDC3UXja7eBpcgPZRdtMIi.start()
			JAyae4XNGfp235YOicRuTKkjqLF7dl.append(bqnzQDC3UXja7eBpcgPZRdtMIi)
			luMHeSgCBaPrb9KvUjNFqcR.sleep(yTMWeCgUROcvtsblfK85L62xPk(u"࠶࠮࠸࠷ა"))
		for bqnzQDC3UXja7eBpcgPZRdtMIi in JAyae4XNGfp235YOicRuTKkjqLF7dl: bqnzQDC3UXja7eBpcgPZRdtMIi.join(m6b7CoBk4EQ(u"࠱࠱ბ"))
	svA3Xnq5GbkTcZPHd,xCLQK8kh39sjyi5DXSZAVeI,YYmyQXglbEewzL3IA2Sd = EDPaWgMt1SwNn8o(u"ࠪࠫ།"),[],[]
	ii0kK76z1eROvaHQs9A = []
	for yfZpUog0Rbs8CFEv9,RRucmYBaXegTtNOdGHMQ in R28S4pFmAojEW7CGnx:
		PSE7a3fLxv4kRH8AW9yjue,iFPsmk8AQ7VcTynof6XWze,kBSI0QVCc7jneX,U0aBp1RckbISLDwgTJYQfmZ84lKj = Tzt8HviFYVMBhf1ldoq3GI5[XJDSp8dToncwEg+yfZpUog0Rbs8CFEv9]
		if not YYmyQXglbEewzL3IA2Sd and kBSI0QVCc7jneX: xCLQK8kh39sjyi5DXSZAVeI,YYmyQXglbEewzL3IA2Sd = iFPsmk8AQ7VcTynof6XWze,kBSI0QVCc7jneX
		if not svA3Xnq5GbkTcZPHd and PSE7a3fLxv4kRH8AW9yjue: svA3Xnq5GbkTcZPHd = PSE7a3fLxv4kRH8AW9yjue
		if U0aBp1RckbISLDwgTJYQfmZ84lKj: ii0kK76z1eROvaHQs9A.append(U0aBp1RckbISLDwgTJYQfmZ84lKj)
	ii0kK76z1eROvaHQs9A = list(set(ii0kK76z1eROvaHQs9A))
	if not svA3Xnq5GbkTcZPHd and len(ii0kK76z1eROvaHQs9A)==PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"࠲გ"):
		Hf42g9qI3oeD18xKhA0kwaQuRF = ii0kK76z1eROvaHQs9A[gnfv8UtZ3daGqpjzk(u"࠲დ")]
		if Hf42g9qI3oeD18xKhA0kwaQuRF!=yTMWeCgUROcvtsblfK85L62xPk(u"࠵࠴࠵ე"):
			if Hf42g9qI3oeD18xKhA0kwaQuRF<aFQoGfmYKyqLU6X8libw9k3ncW5(u"࠴ვ"): svA3Xnq5GbkTcZPHd = J3OCAmZVcn(u"࡛ࠫ࡯ࡤࡦࡱࠣࡴࡦ࡭ࡥ࠰ࡵࡨࡶࡻ࡫ࡲࠡ࡫ࡶࠤࡳࡵࡴࠡࡣࡦࡧࡪࡹࡳࡪࡤ࡯ࡩࠬ༎")
			else:
				svA3Xnq5GbkTcZPHd = LmcNhzY6fQPd2JyCGslkSr(u"ࠬࡎࡔࡕࡒࠣࡉࡷࡸ࡯ࡳ࠼ࠣࠫ༏")+str(Hf42g9qI3oeD18xKhA0kwaQuRF)
				if VYMZsxRpcQHPgkaiDKjyoh: import http.client as HzUOrm3IV0cpqfLRXSMe6K8
				else: import httplib as HzUOrm3IV0cpqfLRXSMe6K8
				svA3Xnq5GbkTcZPHd += kRYWcNuAazr4jtmBoxFVS19Z6(u"࠭ࠠࠩࠢࠪ༐")+HzUOrm3IV0cpqfLRXSMe6K8.responses[Hf42g9qI3oeD18xKhA0kwaQuRF]+OVmSuf8tpd(u"ࠧࠡࠫࠪ༑")
	luMHeSgCBaPrb9KvUjNFqcR.sleep(c4QSTnPiWUCjhrLlwGB(u"࠶ზ"))
	return svA3Xnq5GbkTcZPHd,xCLQK8kh39sjyi5DXSZAVeI,YYmyQXglbEewzL3IA2Sd
class nA0wHLMlYJU(kGEPsyxKnHDJ.WindowDialog):
	def __init__(CMPn7E0iLfArl, *args, **EJSwmovBilsHkP95GUA3D):
		WVtLj3M6mbNwha7B = hhHq8m5vauKG9dl.path.join(J5keFiyQtf9bGZ0vulzNIsTYMx1oR, kmdSKeBIwViM9t3(u"ࠨࡴࡨࡷࡴࡻࡲࡤࡧࡶࠫ༒"), kRYWcNuAazr4jtmBoxFVS19Z6(u"ࠩࡵࡩࡨࡧࡰࡵࡥ࡫ࡥ࠷࠭༓"), bdhQDyjm3nPwToFHkprvCzBLUGR(u"ࠪࡨ࡮ࡧ࡬ࡰࡩࡥ࡫࠳ࡶ࡮ࡨࠩ༔"))
		tyZsrgf6Rnzk = hhHq8m5vauKG9dl.path.join(J5keFiyQtf9bGZ0vulzNIsTYMx1oR, c4QSTnPiWUCjhrLlwGB(u"ࠫࡷ࡫ࡳࡰࡷࡵࡧࡪࡹࠧ༕"), yTMWeCgUROcvtsblfK85L62xPk(u"ࠬࡸࡥࡤࡣࡳࡸࡨ࡮ࡡ࠳ࠩ༖"), wwyUWMFAsO(u"࠭ࡳࡦ࡮ࡨࡧࡹ࡫ࡤ࠯ࡲࡱ࡫ࠬ༗"))
		ZYrPUMFzycQChTmnG4VdDIes1BWqK = hhHq8m5vauKG9dl.path.join(J5keFiyQtf9bGZ0vulzNIsTYMx1oR, sArCMRngQNmXkBoKv(u"ࠧࡳࡧࡶࡳࡺࡸࡣࡦࡵ༘ࠪ"), yTMWeCgUROcvtsblfK85L62xPk(u"ࠨࡴࡨࡧࡦࡶࡴࡤࡪࡤ࠶༙ࠬ"), MM2BQ7xrAfNivgenXPytGYOs0DEHRC(u"ࠩࡥࡹࡹࡺ࡯࡯ࡨࡲ࠲ࡵࡴࡧࠨ༚"))
		JlH5RszWeLfV6oaE = hhHq8m5vauKG9dl.path.join(J5keFiyQtf9bGZ0vulzNIsTYMx1oR, XogUJZEijT7KWbxeO6(u"ࠪࡶࡪࡹ࡯ࡶࡴࡦࡩࡸ࠭༛"), ZSJVq5XDrRot(u"ࠫࡷ࡫ࡣࡢࡲࡷࡧ࡭ࡧ࠲ࠨ༜"), Ej67fFyoqW8kbV2HdSK(u"ࠬࡨࡵࡵࡶࡲࡲࡳ࡬࠮ࡱࡰࡪࠫ༝"))
		kVjfxciq8l1eNAKpo0PLuFb6RY3Q = hhHq8m5vauKG9dl.path.join(J5keFiyQtf9bGZ0vulzNIsTYMx1oR, PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"࠭ࡲࡦࡵࡲࡹࡷࡩࡥࡴࠩ༞"), MM2BQ7xrAfNivgenXPytGYOs0DEHRC(u"ࠧࡳࡧࡦࡥࡵࡺࡣࡩࡣ࠵ࠫ༟"), gnfv8UtZ3daGqpjzk(u"ࠨࡤࡸࡸࡹࡵ࡮ࡣࡩ࠱ࡴࡳ࡭ࠧ༠"))
		CMPn7E0iLfArl.cancelled = JMLhEyaBWmskovGHTrVCxQ08(u"ࡋࡧ࡬ࡴࡧᅍ")
		CMPn7E0iLfArl.chk = [XogUJZEijT7KWbxeO6(u"࠰ი")] * J3OCAmZVcn(u"࠿თ")
		CMPn7E0iLfArl.chkbutton = [ZSJVq5XDrRot(u"࠲ლ")] * pEo8g7riWVL014KaRtzQ(u"࠺კ")
		CMPn7E0iLfArl.chkstate = [Ej67fFyoqW8kbV2HdSK(u"ࡌࡡ࡭ࡵࡨᅎ")] * LmcNhzY6fQPd2JyCGslkSr(u"࠼მ")
		JcISY0yWqkuo3rhVXBxTiA2j7pH8lR, AAYbZjvc6V3koP8EmnO1t, WI6tGArlecz, ElNxGiYVXZTypbfogBMAL8DF = ffCSGrTJYPsxgVQWKLtHU3iMwB(u"࠷࠻࠰ო"), LmcNhzY6fQPd2JyCGslkSr(u"࠴ნ"), JMLhEyaBWmskovGHTrVCxQ08(u"࠽࠰࠱პ"), hjNP5w9srJz2QpVISxBfndbD4CkXvl(u"࠷࠷࠲ჟ")
		wAUoltBQHKEqD6bhJ = JcISY0yWqkuo3rhVXBxTiA2j7pH8lR+WI6tGArlecz//PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"࠳რ")
		FgHTqvEnhptOmDysG5Sr, QVlfjHDo6A7MuvZ1KLeCRTE5P, nls1GHNVDzY0cqUPI, wYlV3DfFPH1q8EUiIk65 = PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"࠶࠹࠺ტ"), kRYWcNuAazr4jtmBoxFVS19Z6(u"࠳࠵࠴ს"), bdhQDyjm3nPwToFHkprvCzBLUGR(u"࠹࠵࠶უ"), bdhQDyjm3nPwToFHkprvCzBLUGR(u"࠹࠵࠶უ")
		QCFgrl75WHa3zBL0DTIkPVcKedijb = FgHTqvEnhptOmDysG5Sr+nls1GHNVDzY0cqUPI//AAgpHN0nMZ(u"࠷ფ")
		QQC3ybJlHtrBfu48eYncR, wd0uLm69kqPbcWYXH4z1O, xSRILmyoK2f, oo7QiIpyftn2md3K4gesc = JMLhEyaBWmskovGHTrVCxQ08(u"࠱࠱࠲ღ"), eeIL1TfgFQJaKqVD8hGNPEZ(u"࠷࠷࠸ყ"), c4QSTnPiWUCjhrLlwGB(u"࠷࠵࠱ქ"), aFQoGfmYKyqLU6X8libw9k3ncW5(u"࠷࠳შ")
		LWcrH4K6QaS = wAUoltBQHKEqD6bhJ-xSRILmyoK2f-QQC3ybJlHtrBfu48eYncR//aFQoGfmYKyqLU6X8libw9k3ncW5(u"࠵ჩ")
		kcyKFjqu5SAls7rUgzR = wAUoltBQHKEqD6bhJ+QQC3ybJlHtrBfu48eYncR//m6b7CoBk4EQ(u"࠶ც")
		SsR9Jegkp0FEa4cAuK, BZM8GtYghscr, rr8MIgOSnjtsoqBDY, k0YegcxtjdCu8DKBV = gSmqZU0plur2xKPJwQA(u"࠸࠻࠵ძ"), MM2BQ7xrAfNivgenXPytGYOs0DEHRC(u"࠹࠰წ"), aVLSn1xw5cK(u"࠶࠲࠳ხ"), XogUJZEijT7KWbxeO6(u"࠵࠱ჭ")
		pIVS0LctPzBg1Y6wfdUHeK, HHoWnSrh5vdV3a6RwLGzAlfjgm, jNBVvUtAYXwPo, kSUIh1Y2VfjJRWlbTs = pEo8g7riWVL014KaRtzQ(u"࠵࠸࠹ჯ"), c4QSTnPiWUCjhrLlwGB(u"࠼࠶ჲ"), JMLhEyaBWmskovGHTrVCxQ08(u"࠹࠵࠶ჱ"), LmcNhzY6fQPd2JyCGslkSr(u"࠸࠴ჰ")
		ft6icN18YH9W = OVmSuf8tpd(u"࠶࠮࠺ჳ")
		JcISY0yWqkuo3rhVXBxTiA2j7pH8lR, AAYbZjvc6V3koP8EmnO1t, WI6tGArlecz, ElNxGiYVXZTypbfogBMAL8DF = int(JcISY0yWqkuo3rhVXBxTiA2j7pH8lR*ft6icN18YH9W), int(AAYbZjvc6V3koP8EmnO1t*ft6icN18YH9W), int(WI6tGArlecz*ft6icN18YH9W), int(ElNxGiYVXZTypbfogBMAL8DF*ft6icN18YH9W)
		FgHTqvEnhptOmDysG5Sr, QVlfjHDo6A7MuvZ1KLeCRTE5P, nls1GHNVDzY0cqUPI, wYlV3DfFPH1q8EUiIk65 = int(FgHTqvEnhptOmDysG5Sr*ft6icN18YH9W), int(QVlfjHDo6A7MuvZ1KLeCRTE5P*ft6icN18YH9W), int(nls1GHNVDzY0cqUPI*ft6icN18YH9W), int(wYlV3DfFPH1q8EUiIk65*ft6icN18YH9W)
		LWcrH4K6QaS, rBFjTKQwcC1LJb05O32Ihx, BfJyOiYmgRobCwdHSFGqh2TKnXut, Mg0oIntXUf817jWJzVFqScuB4b6deL = int(LWcrH4K6QaS*ft6icN18YH9W), int(wd0uLm69kqPbcWYXH4z1O*ft6icN18YH9W), int(xSRILmyoK2f*ft6icN18YH9W), int(oo7QiIpyftn2md3K4gesc*ft6icN18YH9W)
		kcyKFjqu5SAls7rUgzR, pHnGvcSmRw3VjikrCQ79fyW84ETB, C2WiFh8SkNHm37v6pr5lt9sQKnYGy, jhcEyUpBaLFTXCge5WbKimnM = int(kcyKFjqu5SAls7rUgzR*ft6icN18YH9W), int(wd0uLm69kqPbcWYXH4z1O*ft6icN18YH9W), int(xSRILmyoK2f*ft6icN18YH9W), int(oo7QiIpyftn2md3K4gesc*ft6icN18YH9W)
		SsR9Jegkp0FEa4cAuK, BZM8GtYghscr, rr8MIgOSnjtsoqBDY, k0YegcxtjdCu8DKBV = int(SsR9Jegkp0FEa4cAuK*ft6icN18YH9W), int(BZM8GtYghscr*ft6icN18YH9W), int(rr8MIgOSnjtsoqBDY*ft6icN18YH9W), int(k0YegcxtjdCu8DKBV*ft6icN18YH9W)
		pIVS0LctPzBg1Y6wfdUHeK, HHoWnSrh5vdV3a6RwLGzAlfjgm, jNBVvUtAYXwPo, kSUIh1Y2VfjJRWlbTs = int(pIVS0LctPzBg1Y6wfdUHeK*ft6icN18YH9W), int(HHoWnSrh5vdV3a6RwLGzAlfjgm*ft6icN18YH9W), int(jNBVvUtAYXwPo*ft6icN18YH9W), int(kSUIh1Y2VfjJRWlbTs*ft6icN18YH9W)
		BmrPGkuDc4Jw = kGEPsyxKnHDJ.ControlImage(JcISY0yWqkuo3rhVXBxTiA2j7pH8lR, AAYbZjvc6V3koP8EmnO1t, WI6tGArlecz, ElNxGiYVXZTypbfogBMAL8DF, WVtLj3M6mbNwha7B)
		CMPn7E0iLfArl.addControl(BmrPGkuDc4Jw)
		CMPn7E0iLfArl.iteration = EJSwmovBilsHkP95GUA3D.get(xuYvdJpOEyQKTLNwb(u"ࠩ࡬ࡸࡪࡸࡡࡵ࡫ࡲࡲࠬ༡"))
		QGc87fgiVhyJnP = OVmSuf8tpd(u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌࡆࡇࡈ࠳࠴ࡢ࠭༢")+wwyUWMFAsO(u"ࠫๆำีࠡล้หࠥหๆิษ้ࠤํ๊ำหࠢิ์อ๎สࠡࠢࠣࠤࠥࠦࠠࠡࠢࠪ༣")+c4QSTnPiWUCjhrLlwGB(u"ࠬอไๆฯส์้ฯࠠาไ่ࠤࠥ࠭༤")+str(CMPn7E0iLfArl.iteration)+sArCMRngQNmXkBoKv(u"࡛࠭࠰ࡅࡒࡐࡔࡘ࡝ࠨ༥")
		CMPn7E0iLfArl.strActionInfo = kGEPsyxKnHDJ.ControlLabel(SsR9Jegkp0FEa4cAuK, BZM8GtYghscr, rr8MIgOSnjtsoqBDY, k0YegcxtjdCu8DKBV, QGc87fgiVhyJnP, c4QSTnPiWUCjhrLlwGB(u"ࠧࡧࡱࡱࡸ࠶࠹ࠧ༦"))
		CMPn7E0iLfArl.addControl(CMPn7E0iLfArl.strActionInfo)
		CrGO63LT7j2UxniW = kGEPsyxKnHDJ.ControlImage(FgHTqvEnhptOmDysG5Sr, QVlfjHDo6A7MuvZ1KLeCRTE5P, nls1GHNVDzY0cqUPI, wYlV3DfFPH1q8EUiIk65, EJSwmovBilsHkP95GUA3D.get(m6b7CoBk4EQ(u"ࠨࡥࡤࡴࡹࡩࡨࡢࠩ༧")))
		CMPn7E0iLfArl.addControl(CrGO63LT7j2UxniW)
		w6UfYSmrlLHRu3ATjCBI = J3OCAmZVcn(u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡋࡌࡆࡇ࠲࠳ࡡࠬ༨")+EJSwmovBilsHkP95GUA3D.get(MM2BQ7xrAfNivgenXPytGYOs0DEHRC(u"ࠪࡱࡸ࡭ࠧ༩"))+FhcnOB9t3frzvXb(u"ࠫࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭༪")
		CMPn7E0iLfArl.strActionInfo = kGEPsyxKnHDJ.ControlLabel(pIVS0LctPzBg1Y6wfdUHeK, HHoWnSrh5vdV3a6RwLGzAlfjgm, jNBVvUtAYXwPo, kSUIh1Y2VfjJRWlbTs, w6UfYSmrlLHRu3ATjCBI, gnfv8UtZ3daGqpjzk(u"ࠬ࡬࡯࡯ࡶ࠴࠷ࠬ༫"))
		CMPn7E0iLfArl.addControl(CMPn7E0iLfArl.strActionInfo)
		text = bdhQDyjm3nPwToFHkprvCzBLUGR(u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡈࡉࡊࡋ࠶࠰࡞ࠩ༬")+bdhQDyjm3nPwToFHkprvCzBLUGR(u"ࠧฯำ๋ะࠬ༭")+c4QSTnPiWUCjhrLlwGB(u"ࠨ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ༮")
		CMPn7E0iLfArl.cancelbutton = kGEPsyxKnHDJ.ControlButton(LWcrH4K6QaS, rBFjTKQwcC1LJb05O32Ihx, BfJyOiYmgRobCwdHSFGqh2TKnXut, Mg0oIntXUf817jWJzVFqScuB4b6deL, text, focusTexture=kVjfxciq8l1eNAKpo0PLuFb6RY3Q, noFocusTexture=ZYrPUMFzycQChTmnG4VdDIes1BWqK, alignment=AAgpHN0nMZ(u"࠲ჴ"))
		text = Ej67fFyoqW8kbV2HdSK(u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡋࡌࡆࡇ࠲࠳ࡡࠬ༯")+aVLSn1xw5cK(u"ࠪหุะๅาษิࠫ༰")+LmcNhzY6fQPd2JyCGslkSr(u"ࠫࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭༱")
		CMPn7E0iLfArl.okbutton = kGEPsyxKnHDJ.ControlButton(kcyKFjqu5SAls7rUgzR, pHnGvcSmRw3VjikrCQ79fyW84ETB, C2WiFh8SkNHm37v6pr5lt9sQKnYGy, jhcEyUpBaLFTXCge5WbKimnM, text, focusTexture=kVjfxciq8l1eNAKpo0PLuFb6RY3Q, noFocusTexture=ZYrPUMFzycQChTmnG4VdDIes1BWqK, alignment=xuYvdJpOEyQKTLNwb(u"࠳ჵ"))
		CMPn7E0iLfArl.addControl(CMPn7E0iLfArl.okbutton)
		CMPn7E0iLfArl.addControl(CMPn7E0iLfArl.cancelbutton)
		TTBnLdaRIxmw0HbjUfMVNGoFhz6lPY, LolOFbDWtyk0R6 = wYlV3DfFPH1q8EUiIk65//AAgpHN0nMZ(u"࠵ჶ"), nls1GHNVDzY0cqUPI//AAgpHN0nMZ(u"࠵ჶ")
		for xxFhvt275i8MdUVuPkSXzmbT in range(LmcNhzY6fQPd2JyCGslkSr(u"࠼ჷ")):
			qUJQMx4nilFGvuk9 = xxFhvt275i8MdUVuPkSXzmbT // jYaM5vilgZdFx6QHbApwVXO8et(u"࠷ჸ")
			DDAKMh2umwv4sfQ0RePz = xxFhvt275i8MdUVuPkSXzmbT % JcDaEHuiS8TqBbOhWe4ZgwknoC1L3r(u"࠸ჹ")
			mJPwDVQl6XoTzSW745k = FgHTqvEnhptOmDysG5Sr + (LolOFbDWtyk0R6 * DDAKMh2umwv4sfQ0RePz)
			XYAvpQ9CJM84jRexyfi = QVlfjHDo6A7MuvZ1KLeCRTE5P + (TTBnLdaRIxmw0HbjUfMVNGoFhz6lPY * qUJQMx4nilFGvuk9)
			CMPn7E0iLfArl.chk[xxFhvt275i8MdUVuPkSXzmbT] = kGEPsyxKnHDJ.ControlImage(mJPwDVQl6XoTzSW745k, XYAvpQ9CJM84jRexyfi, LolOFbDWtyk0R6, TTBnLdaRIxmw0HbjUfMVNGoFhz6lPY, tyZsrgf6Rnzk)
			CMPn7E0iLfArl.addControl(CMPn7E0iLfArl.chk[xxFhvt275i8MdUVuPkSXzmbT])
			CMPn7E0iLfArl.chk[xxFhvt275i8MdUVuPkSXzmbT].setVisible(m6b7CoBk4EQ(u"ࡆࡢ࡮ࡶࡩᅏ"))
			CMPn7E0iLfArl.chkbutton[xxFhvt275i8MdUVuPkSXzmbT] = kGEPsyxKnHDJ.ControlButton(mJPwDVQl6XoTzSW745k, XYAvpQ9CJM84jRexyfi, LolOFbDWtyk0R6, TTBnLdaRIxmw0HbjUfMVNGoFhz6lPY, str(xxFhvt275i8MdUVuPkSXzmbT + AAgpHN0nMZ(u"࠷ჺ")), font=m6b7CoBk4EQ(u"ࠬ࡬࡯࡯ࡶ࠴࠷ࠬ༲"), focusTexture=ZYrPUMFzycQChTmnG4VdDIes1BWqK, noFocusTexture=JlH5RszWeLfV6oaE)
			CMPn7E0iLfArl.addControl(CMPn7E0iLfArl.chkbutton[xxFhvt275i8MdUVuPkSXzmbT])
		for xxFhvt275i8MdUVuPkSXzmbT in range(fR68jBGWCzUsFXdlTKPOScugm(u"࠹჻")):
			zzlSFMmpvh1645inDdVjYgX = (xxFhvt275i8MdUVuPkSXzmbT // aVLSn1xw5cK(u"࠴ჼ")) * aVLSn1xw5cK(u"࠴ჼ")
			kYXvzM6Pi8IOna = zzlSFMmpvh1645inDdVjYgX + (xxFhvt275i8MdUVuPkSXzmbT + kmdSKeBIwViM9t3(u"࠳ჽ")) % yTMWeCgUROcvtsblfK85L62xPk(u"࠶ჾ")
			YDl30P7SJZrdWtCb6Egp = zzlSFMmpvh1645inDdVjYgX + (xxFhvt275i8MdUVuPkSXzmbT - ZSJVq5XDrRot(u"࠵ჿ")) % gSmqZU0plur2xKPJwQA(u"࠸ᄀ")
			LLwcRPBrJ32gVlS5TxDWzZashntujX = (xxFhvt275i8MdUVuPkSXzmbT - XogUJZEijT7KWbxeO6(u"࠳ᄂ")) % FhcnOB9t3frzvXb(u"࠿ᄁ")
			bMgzJ8PqrVkmxs915nXIZof2OcN6TE = (xxFhvt275i8MdUVuPkSXzmbT + kRYWcNuAazr4jtmBoxFVS19Z6(u"࠵ᄄ")) % ZSJVq5XDrRot(u"࠺ᄃ")
			CMPn7E0iLfArl.chkbutton[xxFhvt275i8MdUVuPkSXzmbT].controlRight(CMPn7E0iLfArl.chkbutton[kYXvzM6Pi8IOna])
			CMPn7E0iLfArl.chkbutton[xxFhvt275i8MdUVuPkSXzmbT].controlLeft(CMPn7E0iLfArl.chkbutton[YDl30P7SJZrdWtCb6Egp])
			if xxFhvt275i8MdUVuPkSXzmbT <= wwyUWMFAsO(u"࠵ᄅ"):
				CMPn7E0iLfArl.chkbutton[xxFhvt275i8MdUVuPkSXzmbT].controlUp(CMPn7E0iLfArl.okbutton)
			else:
				CMPn7E0iLfArl.chkbutton[xxFhvt275i8MdUVuPkSXzmbT].controlUp(CMPn7E0iLfArl.chkbutton[LLwcRPBrJ32gVlS5TxDWzZashntujX])
			if xxFhvt275i8MdUVuPkSXzmbT >= hjNP5w9srJz2QpVISxBfndbD4CkXvl(u"࠺ᄆ"):
				CMPn7E0iLfArl.chkbutton[xxFhvt275i8MdUVuPkSXzmbT].controlDown(CMPn7E0iLfArl.okbutton)
			else:
				CMPn7E0iLfArl.chkbutton[xxFhvt275i8MdUVuPkSXzmbT].controlDown(CMPn7E0iLfArl.chkbutton[bMgzJ8PqrVkmxs915nXIZof2OcN6TE])
		CMPn7E0iLfArl.okbutton.controlLeft(CMPn7E0iLfArl.cancelbutton)
		CMPn7E0iLfArl.okbutton.controlRight(CMPn7E0iLfArl.cancelbutton)
		CMPn7E0iLfArl.cancelbutton.controlLeft(CMPn7E0iLfArl.okbutton)
		CMPn7E0iLfArl.cancelbutton.controlRight(CMPn7E0iLfArl.okbutton)
		CMPn7E0iLfArl.okbutton.controlDown(CMPn7E0iLfArl.chkbutton[aFQoGfmYKyqLU6X8libw9k3ncW5(u"࠷ᄇ")])
		CMPn7E0iLfArl.okbutton.controlUp(CMPn7E0iLfArl.chkbutton[J3OCAmZVcn(u"࠾ᄈ")])
		CMPn7E0iLfArl.cancelbutton.controlDown(CMPn7E0iLfArl.chkbutton[ZSJVq5XDrRot(u"࠰ᄉ")])
		CMPn7E0iLfArl.cancelbutton.controlUp(CMPn7E0iLfArl.chkbutton[LmcNhzY6fQPd2JyCGslkSr(u"࠷ᄊ")])
		CMPn7E0iLfArl.setFocus(CMPn7E0iLfArl.okbutton)
	def get(CMPn7E0iLfArl):
		CMPn7E0iLfArl.doModal()
		CMPn7E0iLfArl.close()
		if not CMPn7E0iLfArl.cancelled:
			return [xxFhvt275i8MdUVuPkSXzmbT for xxFhvt275i8MdUVuPkSXzmbT in range(sArCMRngQNmXkBoKv(u"࠻ᄋ")) if CMPn7E0iLfArl.chkstate[xxFhvt275i8MdUVuPkSXzmbT]]
	def onControl(CMPn7E0iLfArl, vuADqgK0OcB8E62pfWTJzY3hi):
		if vuADqgK0OcB8E62pfWTJzY3hi.getId() == CMPn7E0iLfArl.okbutton.getId() and any(CMPn7E0iLfArl.chkstate):
			CMPn7E0iLfArl.close()
		elif vuADqgK0OcB8E62pfWTJzY3hi.getId() == CMPn7E0iLfArl.cancelbutton.getId():
			CMPn7E0iLfArl.cancelled = ZSJVq5XDrRot(u"ࡕࡴࡸࡩᅐ")
			CMPn7E0iLfArl.close()
		else:
			W5V6oRmIDCvcMGBQU = vuADqgK0OcB8E62pfWTJzY3hi.getLabel()
			if W5V6oRmIDCvcMGBQU.isnumeric():
				index = int(W5V6oRmIDCvcMGBQU) - DLSVmlyBbCK(u"࠴ᄌ")
				CMPn7E0iLfArl.chkstate[index] = not CMPn7E0iLfArl.chkstate[index]
				CMPn7E0iLfArl.chk[index].setVisible(CMPn7E0iLfArl.chkstate[index])
	def onAction(CMPn7E0iLfArl, w2wpLei4bynB6cafQHtsDUEG):
		if w2wpLei4bynB6cafQHtsDUEG == kmdSKeBIwViM9t3(u"࠵࠵ᄍ"):
			CMPn7E0iLfArl.cancelled = wwyUWMFAsO(u"ࡖࡵࡹࡪᅑ")
			CMPn7E0iLfArl.close()
def a4WNSCwzBqZ(key,EWMGN9wslbO5qRn34Sy,url):
	headers = {yTMWeCgUROcvtsblfK85L62xPk(u"࠭ࡒࡦࡨࡨࡶࡪࡸࠧ༳"):url,Ej67fFyoqW8kbV2HdSK(u"ࠧࡂࡥࡦࡩࡵࡺ࠭ࡍࡣࡱ࡫ࡺࡧࡧࡦࠩ༴"):EWMGN9wslbO5qRn34Sy}
	r5uKcdi8bRnXN = pEo8g7riWVL014KaRtzQ(u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࡹࡺࡻ࠳࡭࡯ࡰࡩ࡯ࡩ࠳ࡩ࡯࡮࠱ࡵࡩࡨࡧࡰࡵࡥ࡫ࡥ࠴ࡧࡰࡪ࠱ࡩࡥࡱࡲࡢࡢࡥ࡮ࡃࡰࡃ༵ࠧ")+key
	wpFmEA3z8JR = A6F71g3cqN4(JNsoWV1CXc4xy,c4QSTnPiWUCjhrLlwGB(u"ࠩࡊࡉ࡙࠭༶"),r5uKcdi8bRnXN,JMLhEyaBWmskovGHTrVCxQ08(u"༷ࠪࠫ"),headers,LmcNhzY6fQPd2JyCGslkSr(u"ࠫࠬ༸"),sArCMRngQNmXkBoKv(u"༹ࠬ࠭"),eeIL1TfgFQJaKqVD8hGNPEZ(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡊࡉ࡙ࡥࡒࡆࡅࡄࡔ࡙ࡉࡈࡂ࠴ࡢࡘࡔࡑࡅࡏ࠯࠴ࡷࡹ࠭༺"))
	Yhqjz4bLa1HB,iteration = kRYWcNuAazr4jtmBoxFVS19Z6(u"ࠧࠨ༻"),kRYWcNuAazr4jtmBoxFVS19Z6(u"࠵ᄎ")
	while wwyUWMFAsO(u"ࡗࡶࡺ࡫ᅒ"):
		QstumvzTIEUMXCcx06aD4y8nSqH = wpFmEA3z8JR.content
		VbZ1Pig043uIGYQ = ZXFs0mEPR8qI2zj.findall(jYaM5vilgZdFx6QHbApwVXO8et(u"ࠨࠤࠫ࠳ࡷ࡫ࡣࡢࡲࡷࡧ࡭ࡧ࠯ࡢࡲ࡬࠶࠴ࡶࡡࡺ࡮ࡲࡥࡩࡡ࡞ࠣ࡟࠮࠭ࠬ༼"), QstumvzTIEUMXCcx06aD4y8nSqH)
		iteration += Ej67fFyoqW8kbV2HdSK(u"࠷ᄏ")
		message = ZXFs0mEPR8qI2zj.findall(m6b7CoBk4EQ(u"ࠩ࠿ࡰࡦࡨࡥ࡭࡝ࡡࡂࡢ࠱ࡣ࡭ࡣࡶࡷࡂࠨࡦࡣࡥ࠰࡭ࡲࡧࡧࡦࡵࡨࡰࡪࡩࡴ࠮࡯ࡨࡷࡸࡧࡧࡦ࠯ࡷࡩࡽࡺࠢ࡜ࡠࡁࡡ࠯ࡄࠨ࠯ࠬࡂ࠭ࡁ࠵࡬ࡢࡤࡨࡰࡃ࠭༽"), QstumvzTIEUMXCcx06aD4y8nSqH)
		if not message: message = ZXFs0mEPR8qI2zj.findall(eeIL1TfgFQJaKqVD8hGNPEZ(u"ࠪࡀࡩ࡯ࡶ࡜ࡠࡁࡡ࠰ࡩ࡬ࡢࡵࡶࡁࠧ࡬ࡢࡤ࠯࡬ࡱࡦ࡭ࡥࡴࡧ࡯ࡩࡨࡺ࠭࡮ࡧࡶࡷࡦ࡭ࡥ࠮ࡧࡵࡶࡴࡸࠢ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡦ࡬ࡺࡃ࠭༾"), QstumvzTIEUMXCcx06aD4y8nSqH)
		if not message:
			Yhqjz4bLa1HB = ZXFs0mEPR8qI2zj.findall(JMLhEyaBWmskovGHTrVCxQ08(u"ࠫࡷ࡫ࡡࡥࡱࡱࡰࡾࡄࠨ࠯ࠬࡂ࠭ࡁ࠭༿"), QstumvzTIEUMXCcx06aD4y8nSqH)[ZSJVq5XDrRot(u"࠰ᄐ")]
			break
		else:
			message = message[FhcnOB9t3frzvXb(u"࠱ᄑ")]
			VbZ1Pig043uIGYQ = VbZ1Pig043uIGYQ[jYaM5vilgZdFx6QHbApwVXO8et(u"࠲ᄒ")]
		wYTl0JGQ6jg4XBCzeFf15suKb = ZXFs0mEPR8qI2zj.findall(sArCMRngQNmXkBoKv(u"ࡷ࠭࡮ࡢ࡯ࡨࡁࠧࡩࠢ࡝ࡵ࠮ࡺࡦࡲࡵࡦ࠿ࠥࠬࡠࡤࠢ࡞࠭ࠬࠫཀ"), QstumvzTIEUMXCcx06aD4y8nSqH)[JcDaEHuiS8TqBbOhWe4ZgwknoC1L3r(u"࠳ᄓ")]
		mOg67Me2zqbSXiRntjKDAYE = eeIL1TfgFQJaKqVD8hGNPEZ(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡸࡹࡺ࠲࡬ࡵ࡯ࡨ࡮ࡨ࠲ࡨࡵ࡭ࠦࡵࠪཁ") % (VbZ1Pig043uIGYQ.replace(sArCMRngQNmXkBoKv(u"ࠧࠧࡣࡰࡴࡀ࠭ག"), DLSVmlyBbCK(u"ࠨࠨࠪགྷ")))
		message = ZXFs0mEPR8qI2zj.sub(eeIL1TfgFQJaKqVD8hGNPEZ(u"ࠩ࠿࠳ࡄ࠮ࡤࡪࡸࡿࡷࡹࡸ࡯࡯ࡩࠬ࡟ࡣࡄ࡝ࠫࡀࠪང"), DLSVmlyBbCK(u"ࠪࠫཅ"), message)
		peHTF2MzPI = nA0wHLMlYJU(captcha=mOg67Me2zqbSXiRntjKDAYE, msg=message, iteration=iteration)
		ot3pMzuwdOR = peHTF2MzPI.get()
		if not ot3pMzuwdOR: break
		data = {wwyUWMFAsO(u"ࠫࡨ࠭ཆ"): wYTl0JGQ6jg4XBCzeFf15suKb, FhcnOB9t3frzvXb(u"ࠬࡸࡥࡴࡲࡲࡲࡸ࡫ࠧཇ"): ot3pMzuwdOR}
		wpFmEA3z8JR = A6F71g3cqN4(JNsoWV1CXc4xy,aFQoGfmYKyqLU6X8libw9k3ncW5(u"࠭ࡐࡐࡕࡗࠫ཈"),r5uKcdi8bRnXN,data,headers,m6b7CoBk4EQ(u"ࠧࠨཉ"),J3OCAmZVcn(u"ࠨࠩཊ"),XogUJZEijT7KWbxeO6(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡍࡅࡕࡡࡕࡉࡈࡇࡐࡕࡅࡋࡅ࠷ࡥࡔࡐࡍࡈࡒ࠲࠸࡮ࡥࠩཋ"))
	return Yhqjz4bLa1HB
def uzlMmh1dUNbS(url):
	QstumvzTIEUMXCcx06aD4y8nSqH = QuWA3hsmIvockZDiy2rLg(dALVaOWB4jKN3Tbt0Cm1ns9k5u,url,aVLSn1xw5cK(u"ࠪࠫཌ"),Ej67fFyoqW8kbV2HdSK(u"ࠫࠬཌྷ"),ZSJVq5XDrRot(u"ࠬ࠭ཎ"),EDPaWgMt1SwNn8o(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡄࡖࡆࡈࡌࡐࡃࡇࡗ࠲࠷ࡳࡵࠩཏ"))
	items = ZXFs0mEPR8qI2zj.findall(eeIL1TfgFQJaKqVD8hGNPEZ(u"ࠧࡤࡱ࡯ࡳࡷࡃࠢࡳࡧࡧࠦࡃ࠮࠮ࠫࡁࠬࡀࠬཐ"),QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	if items: return sArCMRngQNmXkBoKv(u"ࠨࠩད"),[ZSJVq5XDrRot(u"ࠩࠪདྷ")],[ items[hjNP5w9srJz2QpVISxBfndbD4CkXvl(u"࠴ᄔ")] ]
	else: return PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨࠥࡇࡒࡂࡄࡏࡓࡆࡊࡓࠨན"),[],[]
def nX73VkBFdQyT6A98Uc5YINtKx(url):
	return pEo8g7riWVL014KaRtzQ(u"ࠫࠬཔ"),[ZSJVq5XDrRot(u"ࠬ࠭ཕ")],[ url ]
def LEczFpwq2OYB37(url):
	NGmuWwXdLQ6nMltx39FYECohJ = url.split(kRYWcNuAazr4jtmBoxFVS19Z6(u"࠭࠯ࠨབ"))
	PEe25KZbcH7p = hjNP5w9srJz2QpVISxBfndbD4CkXvl(u"ࠧ࠰ࠩབྷ").join(NGmuWwXdLQ6nMltx39FYECohJ[aFQoGfmYKyqLU6X8libw9k3ncW5(u"࠵ᄕ"):yTMWeCgUROcvtsblfK85L62xPk(u"࠹ᄖ")])
	QstumvzTIEUMXCcx06aD4y8nSqH = QuWA3hsmIvockZDiy2rLg(dALVaOWB4jKN3Tbt0Cm1ns9k5u,url,ZSJVq5XDrRot(u"ࠨࠩམ"),jYaM5vilgZdFx6QHbApwVXO8et(u"ࠩࠪཙ"),OVmSuf8tpd(u"ࠪࠫཚ"),aFQoGfmYKyqLU6X8libw9k3ncW5(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࡛࠭ࡋࡓࡔ࡞࡙ࡈࡂࡔࡈ࠱࠶ࡹࡴࠨཛ"))
	items = ZXFs0mEPR8qI2zj.findall(LmcNhzY6fQPd2JyCGslkSr(u"ࠬࡪ࡬ࡣࡷࡷࡸࡴࡴ࡜ࠨ࡞ࠬ࠲࡭ࡸࡥࡧࠢࡀࠤࠧ࠮࠮ࠫࡁࠬࠦࠥࡢࠫࠡ࡞ࠫࠬ࠳࠰࠿ࠪࠢ࡟ࠩࠥ࠮࠮ࠫࡁࠬࠤࡡ࠱ࠠࠩ࠰࠭ࡃ࠮ࠦ࡜ࠦࠢࠫ࠲࠯ࡅࠩ࡝ࠫࠣࡠ࠰ࠦࠢࠩ࠰࠭ࡃ࠮ࠨࠧཛྷ"),QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	if items:
		ssMt96muVHx,umJRt83OTfvgsBzNi2V5L,IfVB6TCcAkG1tJ5sprlROyP0MFK,yk9KaeDJcOnbwPr,oBw6sqF8TRbi3XDHJ,Re95jolqkS0 = items[aFQoGfmYKyqLU6X8libw9k3ncW5(u"࠰ᄗ")]
		cfMR9TgeL2hx6Wnq4liDX = int(umJRt83OTfvgsBzNi2V5L) % int(IfVB6TCcAkG1tJ5sprlROyP0MFK) + int(yk9KaeDJcOnbwPr) % int(oBw6sqF8TRbi3XDHJ)
		url = PEe25KZbcH7p + ssMt96muVHx + str(cfMR9TgeL2hx6Wnq4liDX) + Re95jolqkS0
		return ZSJVq5XDrRot(u"࠭ࠧཝ"),[LmcNhzY6fQPd2JyCGslkSr(u"ࠧࠨཞ")],[url]
	else: return wwyUWMFAsO(u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦࠣ࡞ࡎࡖࡐ࡚ࡕࡋࡅࡗࡋࠧཟ"),[],[]
def E4O2Qwmp0idoL5RVUHCnrZ(url):
	id = url.split(pEo8g7riWVL014KaRtzQ(u"ࠩ࠲ࠫའ"))[-J3OCAmZVcn(u"࠲ᄘ")]
	headers = { fR68jBGWCzUsFXdlTKPOScugm(u"ࠪࡇࡴࡴࡴࡦࡰࡷ࠱࡙ࡿࡰࡦࠩཡ") : c4QSTnPiWUCjhrLlwGB(u"ࠫࡦࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯࠱ࡻ࠱ࡼࡽࡷ࠮ࡨࡲࡶࡲ࠳ࡵࡳ࡮ࡨࡲࡨࡵࡤࡦࡦࠪར") }
	VbZ1Pig043uIGYQ = { c4QSTnPiWUCjhrLlwGB(u"ࠧ࡯ࡤࠣལ"):id , gnfv8UtZ3daGqpjzk(u"ࠨ࡯ࡱࠤཤ"):EDPaWgMt1SwNn8o(u"ࠢࡥࡱࡺࡲࡱࡵࡡࡥ࠴ࠥཥ") }
	l3UpyxrXZ2 = A6F71g3cqN4(dALVaOWB4jKN3Tbt0Cm1ns9k5u,PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg(u"ࠨࡒࡒࡗ࡙࠭ས"), url, VbZ1Pig043uIGYQ, headers, XogUJZEijT7KWbxeO6(u"ࠩࠪཧ"),MM2BQ7xrAfNivgenXPytGYOs0DEHRC(u"ࠪࠫཨ"),pEo8g7riWVL014KaRtzQ(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡎࡒ࠷࡙ࡕࡒࡏࡂࡆ࠰࠵ࡸࡺࠧཀྵ"))
	if XogUJZEijT7KWbxeO6(u"ࠬࡒ࡯ࡤࡣࡷ࡭ࡴࡴࠧཪ") in list(l3UpyxrXZ2.headers.keys()): RRucmYBaXegTtNOdGHMQ = l3UpyxrXZ2.headers[DLSVmlyBbCK(u"࠭ࡌࡰࡥࡤࡸ࡮ࡵ࡮ࠨཫ")]
	else: RRucmYBaXegTtNOdGHMQ = url
	if RRucmYBaXegTtNOdGHMQ: return JcDaEHuiS8TqBbOhWe4ZgwknoC1L3r(u"ࠧࠨཬ"),[kRYWcNuAazr4jtmBoxFVS19Z6(u"ࠨࠩ཭")],[RRucmYBaXegTtNOdGHMQ]
	else: return JMLhEyaBWmskovGHTrVCxQ08(u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤࡒࡖ࠴ࡖࡒࡏࡓࡆࡊࠧ཮"),[],[]
def AAfueHh7pJRq(url):
	QstumvzTIEUMXCcx06aD4y8nSqH = QuWA3hsmIvockZDiy2rLg(dALVaOWB4jKN3Tbt0Cm1ns9k5u,url,JMLhEyaBWmskovGHTrVCxQ08(u"ࠪࠫ཯"),jYaM5vilgZdFx6QHbApwVXO8et(u"ࠫࠬ཰"),aFQoGfmYKyqLU6X8libw9k3ncW5(u"ཱࠬ࠭"),aVLSn1xw5cK(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯࡚ࡍࡓ࡚ࡖࡍࡋ࡙ࡉ࠲࠷ࡳࡵིࠩ"))
	items = ZXFs0mEPR8qI2zj.findall(aVLSn1xw5cK(u"ࠧ࡮ࡲ࠷࠾ࠥࡢ࡛࡝ࠩࠫ࠲࠯ࡅࠩ࡝ཱིࠩࠪ"),QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	if items: return aFQoGfmYKyqLU6X8libw9k3ncW5(u"ࠨུࠩ"),[OVmSuf8tpd(u"ཱུࠩࠪ")],[ items[fR68jBGWCzUsFXdlTKPOScugm(u"࠲ᄙ")] ]
	else: return bdhQDyjm3nPwToFHkprvCzBLUGR(u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨࠥ࡝ࡉࡏࡖ࡙ࡐࡎ࡜ࡅࠨྲྀ"),[],[]
def MkjyorAv4EQ19ftNOCRcTWsXuJn(url):
	QstumvzTIEUMXCcx06aD4y8nSqH = QuWA3hsmIvockZDiy2rLg(dALVaOWB4jKN3Tbt0Cm1ns9k5u,url,pEo8g7riWVL014KaRtzQ(u"ࠫࠬཷ"),J3OCAmZVcn(u"ࠬ࠭ླྀ"),sArCMRngQNmXkBoKv(u"࠭ࠧཹ"),aFQoGfmYKyqLU6X8libw9k3ncW5(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡅࡗࡉࡈࡊࡘࡈ࠱࠶ࡹࡴࠨེ"))
	items = ZXFs0mEPR8qI2zj.findall(bdhQDyjm3nPwToFHkprvCzBLUGR(u"ࠨࡵࡲࡹࡷࡩࡥࠡࡵࡵࡧࡂࠨࠨ࠯ࠬࡂཻ࠭ࠧ࠭"),QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	if items:
		url = url = kmdSKeBIwViM9t3(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡥࡷࡩࡨࡪࡸࡨ࠲ࡴࡸࡧࠨོ") + items[LmcNhzY6fQPd2JyCGslkSr(u"࠳ᄚ")]
		return wwyUWMFAsO(u"ཽࠪࠫ"),[yTMWeCgUROcvtsblfK85L62xPk(u"ࠫࠬཾ")],[ url ]
	else: return gnfv8UtZ3daGqpjzk(u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡂࡔࡆࡌࡎ࡜ࡅࠨཿ"),[],[]
def MBVZ3m1zAu(url):
	QstumvzTIEUMXCcx06aD4y8nSqH = QuWA3hsmIvockZDiy2rLg(dALVaOWB4jKN3Tbt0Cm1ns9k5u,url,DLSVmlyBbCK(u"ྀ࠭ࠧ"),aVLSn1xw5cK(u"ࠧࠨཱྀ"),J3OCAmZVcn(u"ࠨࠩྂ"),XogUJZEijT7KWbxeO6(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡋࡓࡕࡔࡈࡅࡒ࠳࠱ࡴࡶࠪྃ"))
	items = ZXFs0mEPR8qI2zj.findall(aVLSn1xw5cK(u"ࠪࡺ࡮ࡪࡥࡰࠢࡳࡶࡪࡲ࡯ࡢࡦ࠱࠮ࡄࡹࡲࡤ࠿࠱࠮ࡄࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤ྄ࠪ"),QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	if items: return yTMWeCgUROcvtsblfK85L62xPk(u"ࠫࠬ྅"),[LmcNhzY6fQPd2JyCGslkSr(u"ࠬ࠭྆")],[ items[OVmSuf8tpd(u"࠴ᄛ")] ]
	else: return m6b7CoBk4EQ(u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡇࡖࡘࡗࡋࡁࡎࠩ྇"),[],[]