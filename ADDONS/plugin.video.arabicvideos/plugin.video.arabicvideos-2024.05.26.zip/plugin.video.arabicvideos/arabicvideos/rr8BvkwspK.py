# -*- coding: utf-8 -*-
from j3x780FpaM import *
ll6f2wvU4FdqL3MJyDxORESCK197i = 'EGYNOW'
W74fAyGxODoLPs5vMX2l8C93R = '_EGN_'
JJTrn6SEtYZV31eyR97 = uReHcEzxkTm6pN4Q[ll6f2wvU4FdqL3MJyDxORESCK197i][0]
SmgoEYJ7uyL = ['عروض مصارعة','الكل','n/A','المزيد','قصة عشق']
def OVQIAezo6U1NSTl4L(mode,url,text):
	if   mode==430: HkKfQCS7RIa4xi3houjvl = oMUN5hPpTkxVZG12Qiva8BKnyw6()
	elif mode==431: HkKfQCS7RIa4xi3houjvl = RxAy5lEFQ1chv0BrdU4p6Pt2(url,text)
	elif mode==432: HkKfQCS7RIa4xi3houjvl = jXYwiO9D056pkrzRh1y8tfWJxQoaI3(url)
	elif mode==433: HkKfQCS7RIa4xi3houjvl = pqx0gStI9ojGFP2rWhwRfkVCNX(url)
	elif mode==434: HkKfQCS7RIa4xi3houjvl = nvzlr8m5JEsbaqKd6YTuHCIfX9kLR(url,'ALL_ITEMS_FILTER___'+text)
	elif mode==435: HkKfQCS7RIa4xi3houjvl = nvzlr8m5JEsbaqKd6YTuHCIfX9kLR(url,'SPECIFIED_FILTER___'+text)
	elif mode==436: HkKfQCS7RIa4xi3houjvl = yPzYJU5Wup8(url)
	elif mode==437: HkKfQCS7RIa4xi3houjvl = oysOdNZQLc21AUrtqf6CxbvJRS4pm(url)
	elif mode==439: HkKfQCS7RIa4xi3houjvl = F6OgHwYPRiX10tJEv8r(text)
	else: HkKfQCS7RIa4xi3houjvl = False
	return HkKfQCS7RIa4xi3houjvl
def oMUN5hPpTkxVZG12Qiva8BKnyw6():
	wpFmEA3z8JR = A6F71g3cqN4(Z7uFdWIRv9ybj0,'GET',JJTrn6SEtYZV31eyR97+'/films','','','','','EGYNOW-MENU-1st')
	QstumvzTIEUMXCcx06aD4y8nSqH = wpFmEA3z8JR.content
	pp5vX2CWHBtwOPzdq0Junij7 = ZXFs0mEPR8qI2zj.findall('"canonical" href="(.*?)"',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	pp5vX2CWHBtwOPzdq0Junij7 = pp5vX2CWHBtwOPzdq0Junij7[0].strip('/')
	pp5vX2CWHBtwOPzdq0Junij7 = d78KRnJmBWscGua0XMk(pp5vX2CWHBtwOPzdq0Junij7,'url')
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+'بحث في الموقع','',439,'','','_REMEMBERRESULTS_')
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+'فلتر محدد',pp5vX2CWHBtwOPzdq0Junij7,435)
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+'فلتر كامل',pp5vX2CWHBtwOPzdq0Junij7,434)
	Tca7NsYPkIRWtBpFgxLZbSmCi('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder',ll6f2wvU4FdqL3MJyDxORESCK197i+'_SCRIPT_'+W74fAyGxODoLPs5vMX2l8C93R+'المضاف حديثا',pp5vX2CWHBtwOPzdq0Junij7,431)
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder',ll6f2wvU4FdqL3MJyDxORESCK197i+'_SCRIPT_'+W74fAyGxODoLPs5vMX2l8C93R+'افلام اون لاين',pp5vX2CWHBtwOPzdq0Junij7+'/films1',436)
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder',ll6f2wvU4FdqL3MJyDxORESCK197i+'_SCRIPT_'+W74fAyGxODoLPs5vMX2l8C93R+'مسلسلات اون لاين',pp5vX2CWHBtwOPzdq0Junij7+'/series-all1',436)
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder',ll6f2wvU4FdqL3MJyDxORESCK197i+'_SCRIPT_'+W74fAyGxODoLPs5vMX2l8C93R+'قائمة تفصيلية',pp5vX2CWHBtwOPzdq0Junij7,437)
	Tca7NsYPkIRWtBpFgxLZbSmCi('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('"SiteNavigation"(.*?)"Search"',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	bdq4e6Wr2gslnSiA38 = IZGcQbePXxwAoyYR1n[0]
	items = ZXFs0mEPR8qI2zj.findall('href="(.*?)".*?>(.*?)<',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
	for RRucmYBaXegTtNOdGHMQ,title in items:
		if title in SmgoEYJ7uyL: continue
		if title=='الرئيسية': continue
		if 'اون لاين' in title: continue
		Tca7NsYPkIRWtBpFgxLZbSmCi('folder',ll6f2wvU4FdqL3MJyDxORESCK197i+'_SCRIPT_'+W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,431)
	return
def oysOdNZQLc21AUrtqf6CxbvJRS4pm(website=''):
	wpFmEA3z8JR = A6F71g3cqN4(Z7uFdWIRv9ybj0,'GET',website+'/films','','','','','EGYNOW-MENU-1st')
	QstumvzTIEUMXCcx06aD4y8nSqH = wpFmEA3z8JR.content
	pp5vX2CWHBtwOPzdq0Junij7 = ZXFs0mEPR8qI2zj.findall('"canonical" href="(.*?)"',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	pp5vX2CWHBtwOPzdq0Junij7 = pp5vX2CWHBtwOPzdq0Junij7[0].strip('/')
	pp5vX2CWHBtwOPzdq0Junij7 = d78KRnJmBWscGua0XMk(pp5vX2CWHBtwOPzdq0Junij7,'url')
	IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('"ListDroped"(.*?)"SearchingMaster"',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	bdq4e6Wr2gslnSiA38 = IZGcQbePXxwAoyYR1n[0]
	items = ZXFs0mEPR8qI2zj.findall('data-tax="(.*?)" data-term="(.*?)" data-name="(.*?)"',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
	for p8pgXONsjY,AARNPWHjQU9dEmDI,title in items:
		if title in SmgoEYJ7uyL: continue
		RRucmYBaXegTtNOdGHMQ = website+'/explore/?'+p8pgXONsjY+'='+AARNPWHjQU9dEmDI
		Tca7NsYPkIRWtBpFgxLZbSmCi('folder',ll6f2wvU4FdqL3MJyDxORESCK197i+'_SCRIPT_'+W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,431)
	return
def yPzYJU5Wup8(url):
	pp5vX2CWHBtwOPzdq0Junij7 = d78KRnJmBWscGua0XMk(url,'url')
	wpFmEA3z8JR = A6F71g3cqN4(Z7uFdWIRv9ybj0,'GET',url,'','','','','EGYNOW-SUBMENU-1st')
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+'الجميع',url,431)
	QstumvzTIEUMXCcx06aD4y8nSqH = wpFmEA3z8JR.content
	IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('"titleSectionCon"(.*?)</div></div>',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	bdq4e6Wr2gslnSiA38 = IZGcQbePXxwAoyYR1n[0]
	items = ZXFs0mEPR8qI2zj.findall('data-key="(.*?)".*?<em>(.*?)</em>',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
	for qzTpS3aBcFGiM,title in items:
		if title in SmgoEYJ7uyL: continue
		lQHXdV9Nzf6BLqS8D = pp5vX2CWHBtwOPzdq0Junij7+'/wp-content/themes/EgyNowByElshaikh/Ajaxt/Movies/Keys.php?key='+qzTpS3aBcFGiM
		Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+title,lQHXdV9Nzf6BLqS8D,431)
	return
def RxAy5lEFQ1chv0BrdU4p6Pt2(url,l3UpyxrXZ2=''):
	pp5vX2CWHBtwOPzdq0Junij7 = d78KRnJmBWscGua0XMk(url,'url')
	items = []
	if '/Terms.php' in url or '/Get.php' in url or '/Keys.php' in url:
		lQHXdV9Nzf6BLqS8D,BTMputsaqV = hGMVvHBuPC014(url)
		obS4TpHeV3digGC = {'X-Requested-With':'XMLHttpRequest','Content-Type':'application/x-www-form-urlencoded; charset=UTF-8'}
		wpFmEA3z8JR = A6F71g3cqN4(Z7uFdWIRv9ybj0,'POST',lQHXdV9Nzf6BLqS8D,BTMputsaqV,obS4TpHeV3digGC,'','','EGYNOW-TITLES-1st')
		QstumvzTIEUMXCcx06aD4y8nSqH = wpFmEA3z8JR.content
		bdq4e6Wr2gslnSiA38 = QstumvzTIEUMXCcx06aD4y8nSqH
	elif l3UpyxrXZ2=='featured':
		wpFmEA3z8JR = A6F71g3cqN4(Z7uFdWIRv9ybj0,'GET',url,'','','','','EGYNOW-TITLES-2nd')
		QstumvzTIEUMXCcx06aD4y8nSqH = wpFmEA3z8JR.content
		IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('"MainSlider"(.*?)"MatchesTable"',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
		bdq4e6Wr2gslnSiA38 = IZGcQbePXxwAoyYR1n[0]
		items = ZXFs0mEPR8qI2zj.findall('<a href="(.*?)" title="(.*?)".*?image: url\((.*?)\)',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
	else:
		wpFmEA3z8JR = A6F71g3cqN4(Z7uFdWIRv9ybj0,'GET',url,'','','','','EGYNOW-TITLES-2nd')
		QstumvzTIEUMXCcx06aD4y8nSqH = wpFmEA3z8JR.content
		IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('"BlocksList"(.*?)"Paginate"',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
		if not IZGcQbePXxwAoyYR1n: IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('"BlocksList"(.*?)"titleSectionCon"',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
		bdq4e6Wr2gslnSiA38 = IZGcQbePXxwAoyYR1n[0]
	if not items: items = ZXFs0mEPR8qI2zj.findall('<a href="(.*?)" title="(.*?)".*?data-image="(.*?)"',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
	FF1TYf6O5KENr8R72LUVievClmudxD = []
	QK2N8Bn0lLVdsURIgufJ = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم']
	for RRucmYBaXegTtNOdGHMQ,title,CrGO63LT7j2UxniW in items:
		RRucmYBaXegTtNOdGHMQ = ejBOu2WXwvb4YpITdsLF16(RRucmYBaXegTtNOdGHMQ).strip('/')
		title = qpob7TvxHSs4fEzO6(title)
		LqYKJ36CBG = ZXFs0mEPR8qI2zj.findall('(.*?) الحلقة \d+',title,ZXFs0mEPR8qI2zj.DOTALL)
		if any(AARNPWHjQU9dEmDI in title for AARNPWHjQU9dEmDI in QK2N8Bn0lLVdsURIgufJ):
			Tca7NsYPkIRWtBpFgxLZbSmCi('video',W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,432,CrGO63LT7j2UxniW)
		elif LqYKJ36CBG and 'الحلقة' in title:
			title = '_MOD_' + LqYKJ36CBG[0]
			if title not in FF1TYf6O5KENr8R72LUVievClmudxD:
				Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,433,CrGO63LT7j2UxniW)
				FF1TYf6O5KENr8R72LUVievClmudxD.append(title)
		elif '/movseries/' in RRucmYBaXegTtNOdGHMQ:
			Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,431,CrGO63LT7j2UxniW)
		else: Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,433,CrGO63LT7j2UxniW)
	if l3UpyxrXZ2!='featured':
		IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('"Paginate"(.*?)</ul>',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
		if IZGcQbePXxwAoyYR1n:
			bdq4e6Wr2gslnSiA38 = IZGcQbePXxwAoyYR1n[0]
			items = ZXFs0mEPR8qI2zj.findall('href="(.*?)">(.*?)<',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
			for RRucmYBaXegTtNOdGHMQ,title in items:
				if 'http' not in RRucmYBaXegTtNOdGHMQ: RRucmYBaXegTtNOdGHMQ = pp5vX2CWHBtwOPzdq0Junij7+RRucmYBaXegTtNOdGHMQ
				RRucmYBaXegTtNOdGHMQ = qpob7TvxHSs4fEzO6(RRucmYBaXegTtNOdGHMQ)
				title = qpob7TvxHSs4fEzO6(title)
				if title!='': Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+'صفحة '+title,RRucmYBaXegTtNOdGHMQ,431)
		Yt06jaVmgoDfUOu = ZXFs0mEPR8qI2zj.findall('showmore" href="(.*?)"',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
		if Yt06jaVmgoDfUOu:
			RRucmYBaXegTtNOdGHMQ = Yt06jaVmgoDfUOu[0]
			Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+'مشاهدة المزيد',RRucmYBaXegTtNOdGHMQ,431)
	return
def pqx0gStI9ojGFP2rWhwRfkVCNX(url):
	pp5vX2CWHBtwOPzdq0Junij7 = d78KRnJmBWscGua0XMk(url,'url')
	Wgapb9wyGrVHo0,CCqaV18lM0OL = [],[]
	if 'Episodes.php' in url:
		lQHXdV9Nzf6BLqS8D,BTMputsaqV = hGMVvHBuPC014(url)
		obS4TpHeV3digGC = {'X-Requested-With':'XMLHttpRequest','Content-Type':'application/x-www-form-urlencoded; charset=UTF-8'}
		wpFmEA3z8JR = A6F71g3cqN4(Z7uFdWIRv9ybj0,'POST',lQHXdV9Nzf6BLqS8D,BTMputsaqV,obS4TpHeV3digGC,'','','EGYNOW-EPISODES-1st')
		QstumvzTIEUMXCcx06aD4y8nSqH = wpFmEA3z8JR.content
		CCqaV18lM0OL = [QstumvzTIEUMXCcx06aD4y8nSqH]
	else:
		wpFmEA3z8JR = A6F71g3cqN4(Z7uFdWIRv9ybj0,'GET',url,'','','','','EGYNOW-EPISODES-2nd')
		QstumvzTIEUMXCcx06aD4y8nSqH = wpFmEA3z8JR.content
		Wgapb9wyGrVHo0 = ZXFs0mEPR8qI2zj.findall('"SeasonsList"(.*?)</ul>',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
		CCqaV18lM0OL = ZXFs0mEPR8qI2zj.findall('"EpisodesList"(.*?)</ul>',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	if Wgapb9wyGrVHo0:
		CrGO63LT7j2UxniW = ZXFs0mEPR8qI2zj.findall('"og:image" content="(.*?)"',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
		CrGO63LT7j2UxniW = CrGO63LT7j2UxniW[0]
		bdq4e6Wr2gslnSiA38 = Wgapb9wyGrVHo0[0]
		items = ZXFs0mEPR8qI2zj.findall('data-id="(.*?)".*?data-season="(.*?)".*?">(.*?)</a>',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
		for yVEAeqBJpG,EMtDTaSOYV0mCx3cUjyBobgzp,title in items:
			RRucmYBaXegTtNOdGHMQ = pp5vX2CWHBtwOPzdq0Junij7+'/wp-content/themes/EgyNowByElshaikh/Ajaxt/Single/Episodes.php?'+'season='+EMtDTaSOYV0mCx3cUjyBobgzp+'&post_id='+yVEAeqBJpG
			Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,433,CrGO63LT7j2UxniW)
	elif CCqaV18lM0OL:
		CrGO63LT7j2UxniW = cPwDBuG4HVTCdQ9JmMeoWjNY2hX.getInfoLabel('ListItem.Thumb')
		bdq4e6Wr2gslnSiA38 = CCqaV18lM0OL[0]
		items = ZXFs0mEPR8qI2zj.findall('href="(.*?)".*?</i>(.*?)<em>(.*?)</em>',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
		for RRucmYBaXegTtNOdGHMQ,title,LqYKJ36CBG in items:
			title = title+' '+LqYKJ36CBG
			Tca7NsYPkIRWtBpFgxLZbSmCi('video',W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,432,CrGO63LT7j2UxniW)
	return
def jXYwiO9D056pkrzRh1y8tfWJxQoaI3(url):
	lQHXdV9Nzf6BLqS8D = url+'/watch/'
	wpFmEA3z8JR = A6F71g3cqN4(Z7uFdWIRv9ybj0,'GET',lQHXdV9Nzf6BLqS8D,'','','','','EGYNOW-PLAY-1st')
	QstumvzTIEUMXCcx06aD4y8nSqH = wpFmEA3z8JR.content
	YYmyQXglbEewzL3IA2Sd = []
	pp5vX2CWHBtwOPzdq0Junij7 = d78KRnJmBWscGua0XMk(lQHXdV9Nzf6BLqS8D,'url')
	IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('"container-servers"(.*?)</ul>',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	if IZGcQbePXxwAoyYR1n:
		bdq4e6Wr2gslnSiA38 = IZGcQbePXxwAoyYR1n[0]
		hTkD9vPqXtIzeRiACF = ZXFs0mEPR8qI2zj.findall('data-id="(.*?)"',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
		if hTkD9vPqXtIzeRiACF:
			hTkD9vPqXtIzeRiACF = hTkD9vPqXtIzeRiACF[0]
			items = ZXFs0mEPR8qI2zj.findall('data-server="(.*?)".*?<span>(.*?)</span>',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
			for NGmuWwXdLQ6nMltx39FYECohJ,title in items:
				RRucmYBaXegTtNOdGHMQ = pp5vX2CWHBtwOPzdq0Junij7+'/wp-content/themes/EgyNowByElshaikh/Ajaxt/Single/Server.php?server='+NGmuWwXdLQ6nMltx39FYECohJ+'&post_id='+hTkD9vPqXtIzeRiACF+'?named='+title+'__watch'
				YYmyQXglbEewzL3IA2Sd.append(RRucmYBaXegTtNOdGHMQ)
	EEAxdNRIuJhcef2HC31ZbwFUPSa4 = ZXFs0mEPR8qI2zj.findall('"container-iframe"><iframe src="(.*?)"',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	if EEAxdNRIuJhcef2HC31ZbwFUPSa4:
		EEAxdNRIuJhcef2HC31ZbwFUPSa4 = EEAxdNRIuJhcef2HC31ZbwFUPSa4[0].replace('\n','')
		title = d78KRnJmBWscGua0XMk(EEAxdNRIuJhcef2HC31ZbwFUPSa4,'name')
		RRucmYBaXegTtNOdGHMQ = EEAxdNRIuJhcef2HC31ZbwFUPSa4+'?named='+title+'__embed'
		YYmyQXglbEewzL3IA2Sd.append(RRucmYBaXegTtNOdGHMQ)
	IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('"container-download"(.*?)</ul>',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	if IZGcQbePXxwAoyYR1n:
		bdq4e6Wr2gslnSiA38 = IZGcQbePXxwAoyYR1n[0]
		items = ZXFs0mEPR8qI2zj.findall('href="(.*?)".*?span>(.*?)<.*?em>(.*?)<',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
		for RRucmYBaXegTtNOdGHMQ,title,PHUqTNVJ0ErRSwibn5gD in items:
			RRucmYBaXegTtNOdGHMQ = RRucmYBaXegTtNOdGHMQ.replace('\n','')
			if PHUqTNVJ0ErRSwibn5gD!='': PHUqTNVJ0ErRSwibn5gD = '____'+PHUqTNVJ0ErRSwibn5gD
			RRucmYBaXegTtNOdGHMQ = RRucmYBaXegTtNOdGHMQ+'?named='+title+'__download'+PHUqTNVJ0ErRSwibn5gD
			YYmyQXglbEewzL3IA2Sd.append(RRucmYBaXegTtNOdGHMQ)
	import fnxsZbk2Fm
	fnxsZbk2Fm.n2h4SBIzxbgJD3K7rtVej01EuGcHPs(YYmyQXglbEewzL3IA2Sd,ll6f2wvU4FdqL3MJyDxORESCK197i,'video',url)
	return
def F6OgHwYPRiX10tJEv8r(search):
	search,Y9RKmgsxBefkFcuIj2GULDHy3,showDialogs = XDzpr8RxgZhT(search)
	if search=='': search = CjyEnpfQ23o0PYwDtLId()
	if search=='': return
	search = search.replace(' ','%20')
	url = JJTrn6SEtYZV31eyR97+'/?s='+search
	RxAy5lEFQ1chv0BrdU4p6Pt2(url)
	return
def VB2O0ktvjpGqC4JrTKlu9EWsIM(url):
	url = url.split('/smartemadfilter?')[0]
	pp5vX2CWHBtwOPzdq0Junij7 = d78KRnJmBWscGua0XMk(url,'url')
	wpFmEA3z8JR = A6F71g3cqN4(JNsoWV1CXc4xy,'GET',pp5vX2CWHBtwOPzdq0Junij7,'','','','','EGYNOW-GET_FILTERS_BLOCKS-1st')
	QstumvzTIEUMXCcx06aD4y8nSqH = wpFmEA3z8JR.content
	IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('("dropdown-button".*?)"SearchingMaster"',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	bdq4e6Wr2gslnSiA38 = IZGcQbePXxwAoyYR1n[0]
	jNFqoOewYB2mG = ZXFs0mEPR8qI2zj.findall('"dropdown-button".*?<em>(.*?)</em>(.*?data-tax="(.*?)".*?</div>)',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
	return jNFqoOewYB2mG
def ZsvjUo8dVL0cPGRIqD5iEgN67COr(bdq4e6Wr2gslnSiA38):
	items = ZXFs0mEPR8qI2zj.findall('data-term="(\d+)" data-name="(.*?)"',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
	return items
def mMV5WYge1qZDd3oU7QcP(url):
	ZFcjgy5Kb1GuRlmeCqY0vT = url.split('/smartemadfilter?')[0]
	SSybMXta8gxTFKrUZDwNLWPcoHfEQ = d78KRnJmBWscGua0XMk(url,'url')
	url = url.replace(ZFcjgy5Kb1GuRlmeCqY0vT,SSybMXta8gxTFKrUZDwNLWPcoHfEQ)
	url = url.replace('/smartemadfilter?','/explore/?')
	return url
def iFlog8CjM90(t9NhYxrZKcBf4u,url):
	KMUEN9cD1OByji = l0mO1GdhAtb(t9NhYxrZKcBf4u,'modified_filters')
	aaIn3XlQKJ6zSfkmjuCyM = url+'/smartemadfilter?'+KMUEN9cD1OByji
	aaIn3XlQKJ6zSfkmjuCyM = mMV5WYge1qZDd3oU7QcP(aaIn3XlQKJ6zSfkmjuCyM)
	return aaIn3XlQKJ6zSfkmjuCyM
E0tDmCreab3BWYTcdIupkU46v = ['category','country','genre','release-year']
t1tvAd5EPXM = ['quality','release-year','genre','category','language','country']
def nvzlr8m5JEsbaqKd6YTuHCIfX9kLR(url,filter):
	if '?' in url: url = url.split('/smartemadfilter?')[0]
	type,filter = filter.split('___',1)
	if filter=='': SFbYEzoech4wU1,kXR5NJaOcQUd47zugHqCAvjGoLmW = '',''
	else: SFbYEzoech4wU1,kXR5NJaOcQUd47zugHqCAvjGoLmW = filter.split('___')
	if type=='SPECIFIED_FILTER':
		if E0tDmCreab3BWYTcdIupkU46v[0]+'=' not in SFbYEzoech4wU1: p8pgXONsjY = E0tDmCreab3BWYTcdIupkU46v[0]
		for xxFhvt275i8MdUVuPkSXzmbT in range(len(E0tDmCreab3BWYTcdIupkU46v[0:-1])):
			if E0tDmCreab3BWYTcdIupkU46v[xxFhvt275i8MdUVuPkSXzmbT]+'=' in SFbYEzoech4wU1: p8pgXONsjY = E0tDmCreab3BWYTcdIupkU46v[xxFhvt275i8MdUVuPkSXzmbT+1]
		vX5qmpr1hSAszGE = SFbYEzoech4wU1+'&'+p8pgXONsjY+'=0'
		t9NhYxrZKcBf4u = kXR5NJaOcQUd47zugHqCAvjGoLmW+'&'+p8pgXONsjY+'=0'
		tt6AbxYRgQ3aC4O = vX5qmpr1hSAszGE.strip('&')+'___'+t9NhYxrZKcBf4u.strip('&')
		KMUEN9cD1OByji = l0mO1GdhAtb(kXR5NJaOcQUd47zugHqCAvjGoLmW,'modified_filters')
		lQHXdV9Nzf6BLqS8D = url+'/smartemadfilter?'+KMUEN9cD1OByji
	elif type=='ALL_ITEMS_FILTER':
		cOM2mQXqbrRyiKasDz = l0mO1GdhAtb(SFbYEzoech4wU1,'modified_values')
		cOM2mQXqbrRyiKasDz = ejBOu2WXwvb4YpITdsLF16(cOM2mQXqbrRyiKasDz)
		if kXR5NJaOcQUd47zugHqCAvjGoLmW!='': kXR5NJaOcQUd47zugHqCAvjGoLmW = l0mO1GdhAtb(kXR5NJaOcQUd47zugHqCAvjGoLmW,'modified_filters')
		if kXR5NJaOcQUd47zugHqCAvjGoLmW=='': lQHXdV9Nzf6BLqS8D = url
		else: lQHXdV9Nzf6BLqS8D = url+'/smartemadfilter?'+kXR5NJaOcQUd47zugHqCAvjGoLmW
		lQHXdV9Nzf6BLqS8D = mMV5WYge1qZDd3oU7QcP(lQHXdV9Nzf6BLqS8D)
		Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+'أظهار قائمة الفيديو التي تم اختيارها ',lQHXdV9Nzf6BLqS8D,431)
		Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+' [[   '+cOM2mQXqbrRyiKasDz+'   ]]',lQHXdV9Nzf6BLqS8D,431)
		Tca7NsYPkIRWtBpFgxLZbSmCi('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	jNFqoOewYB2mG = VB2O0ktvjpGqC4JrTKlu9EWsIM(url)
	dict = {}
	for name,bdq4e6Wr2gslnSiA38,Lm4n6ZMXPrWpo in jNFqoOewYB2mG:
		name = name.replace('--','')
		items = ZsvjUo8dVL0cPGRIqD5iEgN67COr(bdq4e6Wr2gslnSiA38)
		if '=' not in lQHXdV9Nzf6BLqS8D: lQHXdV9Nzf6BLqS8D = url
		if type=='SPECIFIED_FILTER':
			if p8pgXONsjY!=Lm4n6ZMXPrWpo: continue
			elif len(items)<2:
				if Lm4n6ZMXPrWpo==E0tDmCreab3BWYTcdIupkU46v[-1]:
					url = mMV5WYge1qZDd3oU7QcP(url)
					RxAy5lEFQ1chv0BrdU4p6Pt2(url)
				else: nvzlr8m5JEsbaqKd6YTuHCIfX9kLR(lQHXdV9Nzf6BLqS8D,'SPECIFIED_FILTER___'+tt6AbxYRgQ3aC4O)
				return
			else:
				lQHXdV9Nzf6BLqS8D = mMV5WYge1qZDd3oU7QcP(lQHXdV9Nzf6BLqS8D)
				if Lm4n6ZMXPrWpo==E0tDmCreab3BWYTcdIupkU46v[-1]: Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+'الجميع ',lQHXdV9Nzf6BLqS8D,431)
				else: Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+'الجميع ',lQHXdV9Nzf6BLqS8D,435,'','',tt6AbxYRgQ3aC4O)
		elif type=='ALL_ITEMS_FILTER':
			vX5qmpr1hSAszGE = SFbYEzoech4wU1+'&'+Lm4n6ZMXPrWpo+'=0'
			t9NhYxrZKcBf4u = kXR5NJaOcQUd47zugHqCAvjGoLmW+'&'+Lm4n6ZMXPrWpo+'=0'
			tt6AbxYRgQ3aC4O = vX5qmpr1hSAszGE+'___'+t9NhYxrZKcBf4u
			Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+'الجميع :'+name,lQHXdV9Nzf6BLqS8D,434,'','',tt6AbxYRgQ3aC4O)
		dict[Lm4n6ZMXPrWpo] = {}
		for AARNPWHjQU9dEmDI,Z7ZzgCTMBsNlVi9 in items:
			if AARNPWHjQU9dEmDI=='196533': Z7ZzgCTMBsNlVi9 = 'أفلام نيتفلكس'
			elif AARNPWHjQU9dEmDI=='196531': Z7ZzgCTMBsNlVi9 = 'مسلسلات نيتفلكس'
			if Z7ZzgCTMBsNlVi9 in SmgoEYJ7uyL: continue
			dict[Lm4n6ZMXPrWpo][AARNPWHjQU9dEmDI] = Z7ZzgCTMBsNlVi9
			vX5qmpr1hSAszGE = SFbYEzoech4wU1+'&'+Lm4n6ZMXPrWpo+'='+Z7ZzgCTMBsNlVi9
			t9NhYxrZKcBf4u = kXR5NJaOcQUd47zugHqCAvjGoLmW+'&'+Lm4n6ZMXPrWpo+'='+AARNPWHjQU9dEmDI
			WYXmvw9l3jToq6rui1SCs = vX5qmpr1hSAszGE+'___'+t9NhYxrZKcBf4u
			title = Z7ZzgCTMBsNlVi9+' :'#+dict[Lm4n6ZMXPrWpo]['0']
			title = Z7ZzgCTMBsNlVi9+' :'+name
			if type=='ALL_ITEMS_FILTER': Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+title,url,434,'','',WYXmvw9l3jToq6rui1SCs)
			elif type=='SPECIFIED_FILTER' and E0tDmCreab3BWYTcdIupkU46v[-2]+'=' in SFbYEzoech4wU1:
				aaIn3XlQKJ6zSfkmjuCyM = iFlog8CjM90(t9NhYxrZKcBf4u,url)
				Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+title,aaIn3XlQKJ6zSfkmjuCyM,431)
			else: Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+title,url,435,'','',WYXmvw9l3jToq6rui1SCs)
	return
def l0mO1GdhAtb(zIpQyOG78Nvreijwa,mode):
	zIpQyOG78Nvreijwa = zIpQyOG78Nvreijwa.replace('=&','=0&')
	zIpQyOG78Nvreijwa = zIpQyOG78Nvreijwa.strip('&')
	JhV0ZrwmLIcOaHfQDK9qNsEGPzF83p = {}
	if '=' in zIpQyOG78Nvreijwa:
		items = zIpQyOG78Nvreijwa.split('&')
		for q8BXZlN9sU1fP2JAxH7W in items:
			cfMR9TgeL2hx6Wnq4liDX,AARNPWHjQU9dEmDI = q8BXZlN9sU1fP2JAxH7W.split('=')
			JhV0ZrwmLIcOaHfQDK9qNsEGPzF83p[cfMR9TgeL2hx6Wnq4liDX] = AARNPWHjQU9dEmDI
	rXLaWluDjvi4xMwpOSF91JB7 = ''
	for key in t1tvAd5EPXM:
		if key in list(JhV0ZrwmLIcOaHfQDK9qNsEGPzF83p.keys()): AARNPWHjQU9dEmDI = JhV0ZrwmLIcOaHfQDK9qNsEGPzF83p[key]
		else: AARNPWHjQU9dEmDI = '0'
		if '%' not in AARNPWHjQU9dEmDI: AARNPWHjQU9dEmDI = cD1AgYCl0qZI8(AARNPWHjQU9dEmDI)
		if mode=='modified_values' and AARNPWHjQU9dEmDI!='0': rXLaWluDjvi4xMwpOSF91JB7 = rXLaWluDjvi4xMwpOSF91JB7+' + '+AARNPWHjQU9dEmDI
		elif mode=='modified_filters' and AARNPWHjQU9dEmDI!='0': rXLaWluDjvi4xMwpOSF91JB7 = rXLaWluDjvi4xMwpOSF91JB7+'&'+key+'='+AARNPWHjQU9dEmDI
		elif mode=='all_filters': rXLaWluDjvi4xMwpOSF91JB7 = rXLaWluDjvi4xMwpOSF91JB7+'&'+key+'='+AARNPWHjQU9dEmDI
	rXLaWluDjvi4xMwpOSF91JB7 = rXLaWluDjvi4xMwpOSF91JB7.strip(' + ')
	rXLaWluDjvi4xMwpOSF91JB7 = rXLaWluDjvi4xMwpOSF91JB7.strip('&')
	rXLaWluDjvi4xMwpOSF91JB7 = rXLaWluDjvi4xMwpOSF91JB7.replace('=0','=')
	return rXLaWluDjvi4xMwpOSF91JB7