# -*- coding: utf-8 -*-
from j3x780FpaM import *
ll6f2wvU4FdqL3MJyDxORESCK197i = 'FASELHD2'
headers = {'User-Agent':''}
W74fAyGxODoLPs5vMX2l8C93R = '_FH2_'
JJTrn6SEtYZV31eyR97 = uReHcEzxkTm6pN4Q[ll6f2wvU4FdqL3MJyDxORESCK197i][0]
SmgoEYJ7uyL = ['wwe']
def OVQIAezo6U1NSTl4L(mode,url,text):
	if   mode==590: HkKfQCS7RIa4xi3houjvl = oMUN5hPpTkxVZG12Qiva8BKnyw6()
	elif mode==591: HkKfQCS7RIa4xi3houjvl = RxAy5lEFQ1chv0BrdU4p6Pt2(url,text)
	elif mode==592: HkKfQCS7RIa4xi3houjvl = jXYwiO9D056pkrzRh1y8tfWJxQoaI3(url)
	elif mode==593: HkKfQCS7RIa4xi3houjvl = DFjzy4r8hXNtR0(url,text)
	elif mode==599: HkKfQCS7RIa4xi3houjvl = F6OgHwYPRiX10tJEv8r(text)
	else: HkKfQCS7RIa4xi3houjvl = False
	return HkKfQCS7RIa4xi3houjvl
def oMUN5hPpTkxVZG12Qiva8BKnyw6():
	pp5vX2CWHBtwOPzdq0Junij7 = JJTrn6SEtYZV31eyR97
	wpFmEA3z8JR = A6F71g3cqN4(Z7uFdWIRv9ybj0,'GET',pp5vX2CWHBtwOPzdq0Junij7,'','','','','FASELHD2-MENU-1st')
	QstumvzTIEUMXCcx06aD4y8nSqH = wpFmEA3z8JR.content
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+'بحث في الموقع',pp5vX2CWHBtwOPzdq0Junij7,599,'','','_REMEMBERRESULTS_')
	Tca7NsYPkIRWtBpFgxLZbSmCi('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+'المميزة',pp5vX2CWHBtwOPzdq0Junij7,591,'','','featured1')
	items = ZXFs0mEPR8qI2zj.findall('<strong>(.*?)</strong>.*?href="(.*?)"',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	for title,RRucmYBaXegTtNOdGHMQ in items:
		Tca7NsYPkIRWtBpFgxLZbSmCi('folder',ll6f2wvU4FdqL3MJyDxORESCK197i+'_SCRIPT_'+W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,591,'','','details1')
	Tca7NsYPkIRWtBpFgxLZbSmCi('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('main-menu"(.*?)header-social',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	if IZGcQbePXxwAoyYR1n:
		bdq4e6Wr2gslnSiA38 = IZGcQbePXxwAoyYR1n[0]
		uLe9dW1C3gpXtNDGrvnRYq = ZXFs0mEPR8qI2zj.findall('<li (.*?)</li>',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
		for Iwo3ZzUA69btP5g21r in uLe9dW1C3gpXtNDGrvnRYq:
			items = ZXFs0mEPR8qI2zj.findall('href="(.*?)".*?>(.*?)<',Iwo3ZzUA69btP5g21r,ZXFs0mEPR8qI2zj.DOTALL)
			for RRucmYBaXegTtNOdGHMQ,title in items:
				if 'http' not in RRucmYBaXegTtNOdGHMQ: RRucmYBaXegTtNOdGHMQ = pp5vX2CWHBtwOPzdq0Junij7+RRucmYBaXegTtNOdGHMQ
				Tca7NsYPkIRWtBpFgxLZbSmCi('folder',ll6f2wvU4FdqL3MJyDxORESCK197i+'_SCRIPT_'+W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,591,'','','details2')
	return QstumvzTIEUMXCcx06aD4y8nSqH
def RxAy5lEFQ1chv0BrdU4p6Pt2(url,type=''):
	wpFmEA3z8JR = A6F71g3cqN4(Z7uFdWIRv9ybj0,'GET',url,'','','','','FASELHD2-TITLES-1st')
	QstumvzTIEUMXCcx06aD4y8nSqH = wpFmEA3z8JR.content
	qGY7bL3P12mtST = 0
	CCqaV18lM0OL = ZXFs0mEPR8qI2zj.findall('"archive-slider(.*?)<h4>',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	if CCqaV18lM0OL: i9jtofq4JrV = CCqaV18lM0OL[0]
	else: i9jtofq4JrV = ''
	if type=='featured1':
		IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('"slider-carousel"(.*?)</container>',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
		bdq4e6Wr2gslnSiA38 = IZGcQbePXxwAoyYR1n[0]
		items = ZXFs0mEPR8qI2zj.findall(' src="(.*?)".*?"slider-title">(.*?)<.*?<a href="(.*?)"',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
		Mbe4UmywtK8Pj9or,mwXy4HaY1uWtlvbZVcN7,R28S4pFmAojEW7CGnx = zip(*items)
		items = zip(R28S4pFmAojEW7CGnx,Mbe4UmywtK8Pj9or,mwXy4HaY1uWtlvbZVcN7)
	elif type=='featured2':
		items = ZXFs0mEPR8qI2zj.findall('href="(.*?)".*?image:url\((.*?)\).*?<h3.*?>(.*?)</h3>',i9jtofq4JrV,ZXFs0mEPR8qI2zj.DOTALL)
	elif type=='filters':
		IZGcQbePXxwAoyYR1n = [QstumvzTIEUMXCcx06aD4y8nSqH.replace('\\/','/').replace('\\"','"')]
	elif type=='details2' and 'href' in i9jtofq4JrV:
		IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('<h4>(.*?)</h4>(.*?)</container>',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
		Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+'مميزة',url,591,'','','featured2')
		title = IZGcQbePXxwAoyYR1n[0][0]
		Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+title,url,591,'','','details3')
		return
	else:
		IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('<h4>(.*?)</h4>(.*?)</container>',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
		title,bdq4e6Wr2gslnSiA38 = IZGcQbePXxwAoyYR1n[0]
		items = ZXFs0mEPR8qI2zj.findall('href="(.*?)".*?image:url\((.*?)\).*?<h3.*?>(.*?)</h3>',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
	QK2N8Bn0lLVdsURIgufJ = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم','مسرحية','حلقة']
	FF1TYf6O5KENr8R72LUVievClmudxD = []
	for RRucmYBaXegTtNOdGHMQ,CrGO63LT7j2UxniW,title in items:
		if any(AARNPWHjQU9dEmDI in title.lower() for AARNPWHjQU9dEmDI in SmgoEYJ7uyL): continue
		title = title.strip(' ')
		title = qpob7TvxHSs4fEzO6(title)
		LqYKJ36CBG = ZXFs0mEPR8qI2zj.findall('(.*?) (الحلقة|حلقة).\d+',title,ZXFs0mEPR8qI2zj.DOTALL)
		if '/movseries/' in RRucmYBaXegTtNOdGHMQ:
			Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,591,CrGO63LT7j2UxniW)
		elif LqYKJ36CBG and type=='':
			title = '_MOD_'+LqYKJ36CBG[0][0]
			if title not in FF1TYf6O5KENr8R72LUVievClmudxD:
				Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,593,CrGO63LT7j2UxniW)
				FF1TYf6O5KENr8R72LUVievClmudxD.append(title)
		elif any(AARNPWHjQU9dEmDI in title for AARNPWHjQU9dEmDI in QK2N8Bn0lLVdsURIgufJ):
			Tca7NsYPkIRWtBpFgxLZbSmCi('video',W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,592,CrGO63LT7j2UxniW)
		else: Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,593,CrGO63LT7j2UxniW)
	if type=='filters':
		jMD8RBfTGUlQwJCk = ZXFs0mEPR8qI2zj.findall('"more_button_page":(.*?),',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
		if jMD8RBfTGUlQwJCk:
			count = jMD8RBfTGUlQwJCk[0]
			RRucmYBaXegTtNOdGHMQ = url+'/offset/'+count
			Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+'صفحة أخرى',RRucmYBaXegTtNOdGHMQ,591,'','','filters')
	elif 'details' in type:
		IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('class="pagination(.*?)</div>',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
		if IZGcQbePXxwAoyYR1n:
			bdq4e6Wr2gslnSiA38 = IZGcQbePXxwAoyYR1n[0]
			items = ZXFs0mEPR8qI2zj.findall('href="(.*?)">(.*?)<',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
			for RRucmYBaXegTtNOdGHMQ,title in items:
				title = 'صفحة '+qpob7TvxHSs4fEzO6(title)
				Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,591,'','','details4')
	return
def DFjzy4r8hXNtR0(url,type=''):
	wpFmEA3z8JR = A6F71g3cqN4(Z7uFdWIRv9ybj0,'GET',url,'','','','','FASELHD2-SEASONS_EPISODES-1st')
	QstumvzTIEUMXCcx06aD4y8nSqH = wpFmEA3z8JR.content
	HEplfjN5wBxeYtD4ds6FvA38rK0U = False
	if not type:
		IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('<seasons(.*?)</seasons>',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
		if IZGcQbePXxwAoyYR1n:
			bdq4e6Wr2gslnSiA38 = IZGcQbePXxwAoyYR1n[0]
			items = ZXFs0mEPR8qI2zj.findall('href="(.*?)".*?image:url\((.*?)\).*?<h3>(.*?)</h3>',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
			if len(items)>1:
				pp5vX2CWHBtwOPzdq0Junij7 = d78KRnJmBWscGua0XMk(url,'url')
				HEplfjN5wBxeYtD4ds6FvA38rK0U = True
				for RRucmYBaXegTtNOdGHMQ,CrGO63LT7j2UxniW,title in items:
					title = qpob7TvxHSs4fEzO6(title)
					Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,593,CrGO63LT7j2UxniW,'','episodes')
	if type=='episodes' or not HEplfjN5wBxeYtD4ds6FvA38rK0U:
		ttiasLcTXGvgqb41nC7DRF = ZXFs0mEPR8qI2zj.findall('<bkز*?image:url\((.*?)\)"></bk>',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
		if ttiasLcTXGvgqb41nC7DRF: CrGO63LT7j2UxniW = ttiasLcTXGvgqb41nC7DRF[0]
		else: CrGO63LT7j2UxniW = ''
		IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('<all-episodes(.*?)</all-episodes>',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
		if IZGcQbePXxwAoyYR1n:
			bdq4e6Wr2gslnSiA38 = IZGcQbePXxwAoyYR1n[0]
			items = ZXFs0mEPR8qI2zj.findall('href="(.*?)".*?>(.*?)</a>',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
			for RRucmYBaXegTtNOdGHMQ,title in items:
				title = title.strip(' ')
				title = qpob7TvxHSs4fEzO6(title)
				Tca7NsYPkIRWtBpFgxLZbSmCi('video',W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,592,CrGO63LT7j2UxniW)
	return
def jXYwiO9D056pkrzRh1y8tfWJxQoaI3(url):
	yf608hE5KeRG1DscunvrU,D21FvpPhVbtslNIXRwxZJiyB9,LngWDh4U7Qs0Jj2ty = [],[],[]
	wpFmEA3z8JR = A6F71g3cqN4(dALVaOWB4jKN3Tbt0Cm1ns9k5u,'GET',url,'','','','','FASELHD2-PLAY-1st')
	QstumvzTIEUMXCcx06aD4y8nSqH = wpFmEA3z8JR.content
	Cglu0VToFyv = ZXFs0mEPR8qI2zj.findall('العمر :.*?<strong">(.*?)</strong>',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	if Cglu0VToFyv and GBC7yanr9WNYIKXSHRxgP(ll6f2wvU4FdqL3MJyDxORESCK197i,url,Cglu0VToFyv): return
	RRucmYBaXegTtNOdGHMQ = ZXFs0mEPR8qI2zj.findall('<iframe src="(.*?)"',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	if RRucmYBaXegTtNOdGHMQ:
		RRucmYBaXegTtNOdGHMQ = RRucmYBaXegTtNOdGHMQ[0]
		yf608hE5KeRG1DscunvrU.append(RRucmYBaXegTtNOdGHMQ+'?named=__embed')
	IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('<slice-title(.*?)</ul>',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	if IZGcQbePXxwAoyYR1n:
		bdq4e6Wr2gslnSiA38 = IZGcQbePXxwAoyYR1n[0]
		items = ZXFs0mEPR8qI2zj.findall('data-url="(.*?)".*?</i>(.*?)</li>',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
		for RRucmYBaXegTtNOdGHMQ,name in items:
			name = name.strip(' ')
			yf608hE5KeRG1DscunvrU.append(RRucmYBaXegTtNOdGHMQ+'?named='+name+'__watch')
	IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('<downloads(.*?)</downloads>',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	if IZGcQbePXxwAoyYR1n:
		bdq4e6Wr2gslnSiA38 = IZGcQbePXxwAoyYR1n[0]
		items = ZXFs0mEPR8qI2zj.findall('href="(.*?)".*?</div>(.*?)</div>',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
		for RRucmYBaXegTtNOdGHMQ,name in items:
			yf608hE5KeRG1DscunvrU.append(RRucmYBaXegTtNOdGHMQ+'?named='+name+'__download')
	for BO9nRHDL2oS43eh6l in yf608hE5KeRG1DscunvrU:
		RRucmYBaXegTtNOdGHMQ,name = BO9nRHDL2oS43eh6l.split('?named')
		if RRucmYBaXegTtNOdGHMQ not in D21FvpPhVbtslNIXRwxZJiyB9:
			D21FvpPhVbtslNIXRwxZJiyB9.append(RRucmYBaXegTtNOdGHMQ)
			LngWDh4U7Qs0Jj2ty.append(BO9nRHDL2oS43eh6l)
	import fnxsZbk2Fm
	fnxsZbk2Fm.n2h4SBIzxbgJD3K7rtVej01EuGcHPs(LngWDh4U7Qs0Jj2ty,ll6f2wvU4FdqL3MJyDxORESCK197i,'video',url)
	return
def F6OgHwYPRiX10tJEv8r(search):
	search,Y9RKmgsxBefkFcuIj2GULDHy3,showDialogs = XDzpr8RxgZhT(search)
	if search=='': search = CjyEnpfQ23o0PYwDtLId()
	if search=='': return
	search = search.replace(' ','+')
	pp5vX2CWHBtwOPzdq0Junij7 = JJTrn6SEtYZV31eyR97
	url = pp5vX2CWHBtwOPzdq0Junij7+'/?s='+search
	RxAy5lEFQ1chv0BrdU4p6Pt2(url,'details5')
	return