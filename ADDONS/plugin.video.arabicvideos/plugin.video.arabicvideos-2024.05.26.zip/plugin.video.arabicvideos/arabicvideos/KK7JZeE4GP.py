# -*- coding: utf-8 -*-
from j3x780FpaM import *
ll6f2wvU4FdqL3MJyDxORESCK197i = 'EGYBEST3'
W74fAyGxODoLPs5vMX2l8C93R = '_EB3_'
JJTrn6SEtYZV31eyR97 = uReHcEzxkTm6pN4Q[ll6f2wvU4FdqL3MJyDxORESCK197i][0]
SmgoEYJ7uyL = ['المصارعة الحرة','ايجي بست','التصميم الجديد','عروض المصارعة','مكتبتي','ايجي بست الجديد','ايجي بست البديل','egybest','موقع ايجي بست','موقع نتفليكس']
def OVQIAezo6U1NSTl4L(mode,url,wwNtFTLK2IqAszYBDV9J,text):
	if   mode==790: HkKfQCS7RIa4xi3houjvl = oMUN5hPpTkxVZG12Qiva8BKnyw6()
	elif mode==791: HkKfQCS7RIa4xi3houjvl = RxAy5lEFQ1chv0BrdU4p6Pt2(url,wwNtFTLK2IqAszYBDV9J)
	elif mode==792: HkKfQCS7RIa4xi3houjvl = yPzYJU5Wup8(url)
	elif mode==793: HkKfQCS7RIa4xi3houjvl = jXYwiO9D056pkrzRh1y8tfWJxQoaI3(url)
	elif mode==796: HkKfQCS7RIa4xi3houjvl = DFjzy4r8hXNtR0(url,wwNtFTLK2IqAszYBDV9J)
	elif mode==799: HkKfQCS7RIa4xi3houjvl = F6OgHwYPRiX10tJEv8r(text)
	else: HkKfQCS7RIa4xi3houjvl = False
	return HkKfQCS7RIa4xi3houjvl
def oMUN5hPpTkxVZG12Qiva8BKnyw6():
	wpFmEA3z8JR = A6F71g3cqN4(JNsoWV1CXc4xy,'GET',JJTrn6SEtYZV31eyR97,'','','','','EGYBEST3-MENU-1st')
	QstumvzTIEUMXCcx06aD4y8nSqH = wpFmEA3z8JR.content
	IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('list-pages(.*?)fa-folder',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	if IZGcQbePXxwAoyYR1n:
		bdq4e6Wr2gslnSiA38 = IZGcQbePXxwAoyYR1n[0]
		items = ZXFs0mEPR8qI2zj.findall('href="(.*?)".*?<span>(.*?)</span>',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
		for RRucmYBaXegTtNOdGHMQ,title in items:
			title = title.strip(' ')
			if any(AARNPWHjQU9dEmDI in title for AARNPWHjQU9dEmDI in SmgoEYJ7uyL): continue
			if 'http' not in RRucmYBaXegTtNOdGHMQ: RRucmYBaXegTtNOdGHMQ = JJTrn6SEtYZV31eyR97+RRucmYBaXegTtNOdGHMQ
			Tca7NsYPkIRWtBpFgxLZbSmCi('folder',ll6f2wvU4FdqL3MJyDxORESCK197i+'_SCRIPT_'+W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,791)
		Tca7NsYPkIRWtBpFgxLZbSmCi('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('main-article(.*?)social-box',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	if IZGcQbePXxwAoyYR1n:
		bdq4e6Wr2gslnSiA38 = IZGcQbePXxwAoyYR1n[0]
		items = ZXFs0mEPR8qI2zj.findall('main-title.*?">(.*?)<.*?href="(.*?)"',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
		for title,RRucmYBaXegTtNOdGHMQ in items:
			title = title.strip(' ')
			if any(AARNPWHjQU9dEmDI in title for AARNPWHjQU9dEmDI in SmgoEYJ7uyL): continue
			if 'http' not in RRucmYBaXegTtNOdGHMQ: RRucmYBaXegTtNOdGHMQ = JJTrn6SEtYZV31eyR97+RRucmYBaXegTtNOdGHMQ
			Tca7NsYPkIRWtBpFgxLZbSmCi('folder',ll6f2wvU4FdqL3MJyDxORESCK197i+'_SCRIPT_'+W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,791,'','mainmenu')
		Tca7NsYPkIRWtBpFgxLZbSmCi('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('main-menu(.*?)</ul>',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	if IZGcQbePXxwAoyYR1n:
		bdq4e6Wr2gslnSiA38 = IZGcQbePXxwAoyYR1n[0]
		items = ZXFs0mEPR8qI2zj.findall('href="(.*?)">(.*?)<',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
		for RRucmYBaXegTtNOdGHMQ,title in items:
			title = title.strip(' ')
			if any(AARNPWHjQU9dEmDI in title for AARNPWHjQU9dEmDI in SmgoEYJ7uyL): continue
			if 'http' not in RRucmYBaXegTtNOdGHMQ: RRucmYBaXegTtNOdGHMQ = JJTrn6SEtYZV31eyR97+RRucmYBaXegTtNOdGHMQ
			Tca7NsYPkIRWtBpFgxLZbSmCi('folder',ll6f2wvU4FdqL3MJyDxORESCK197i+'_SCRIPT_'+W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,791)
	return QstumvzTIEUMXCcx06aD4y8nSqH
def DFjzy4r8hXNtR0(url,type=''):
	wpFmEA3z8JR = A6F71g3cqN4(Z7uFdWIRv9ybj0,'GET',url,'','','','','EGYBEST3-SEASONS_EPISODES-1st')
	QstumvzTIEUMXCcx06aD4y8nSqH = wpFmEA3z8JR.content
	IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('main-article".*?">(.*?)<(.*?)article',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	if IZGcQbePXxwAoyYR1n:
		HEplfjN5wBxeYtD4ds6FvA38rK0U,xvWJR3VCAcyLZ,items = '','',[]
		for name,bdq4e6Wr2gslnSiA38 in IZGcQbePXxwAoyYR1n:
			if 'حلقات' in name: xvWJR3VCAcyLZ = bdq4e6Wr2gslnSiA38
			if 'مواسم' in name: HEplfjN5wBxeYtD4ds6FvA38rK0U = bdq4e6Wr2gslnSiA38
		if HEplfjN5wBxeYtD4ds6FvA38rK0U and not type:
			items = ZXFs0mEPR8qI2zj.findall('href="(.*?)".*?data-src="(.*?)".*?"title">(.*?)<',HEplfjN5wBxeYtD4ds6FvA38rK0U,ZXFs0mEPR8qI2zj.DOTALL)
			if len(items)>1:
				for RRucmYBaXegTtNOdGHMQ,CrGO63LT7j2UxniW,title in items:
					Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,796,CrGO63LT7j2UxniW,'season')
		if xvWJR3VCAcyLZ and len(items)<2:
			items = ZXFs0mEPR8qI2zj.findall('href="(.*?)".*?data-src="(.*?)".*?class="title">(.*?)<',xvWJR3VCAcyLZ,ZXFs0mEPR8qI2zj.DOTALL)
			if items:
				for RRucmYBaXegTtNOdGHMQ,CrGO63LT7j2UxniW,title in items:
					Tca7NsYPkIRWtBpFgxLZbSmCi('video',W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,793,CrGO63LT7j2UxniW)
			else:
				items = ZXFs0mEPR8qI2zj.findall('href="(.*?)">(.*?)<',xvWJR3VCAcyLZ,ZXFs0mEPR8qI2zj.DOTALL)
				for RRucmYBaXegTtNOdGHMQ,title in items:
					Tca7NsYPkIRWtBpFgxLZbSmCi('video',W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,793)
	return
def RxAy5lEFQ1chv0BrdU4p6Pt2(url,type=''):
	zMgjU0c1p3xke7GQEJqWv,start,DOVwrFbPi1kIm8n,select,rOd2abCI1hSegBuqP6G = 0,0,'','',''
	if 'pagination' in type:
		GOuBcLdJk31zseN7xQFn4vjq5ptWYg,data = hGMVvHBuPC014(url)
		zMgjU0c1p3xke7GQEJqWv = int(data['limit'])
		start = int(data['start'])
		DOVwrFbPi1kIm8n = data['type']
		select = data['select']
		BTMputsaqV = 'limit='+str(zMgjU0c1p3xke7GQEJqWv)+'&start='+str(start)+'&type='+DOVwrFbPi1kIm8n+'&select='+select
		obS4TpHeV3digGC = {'Content-Type':'application/x-www-form-urlencoded'}
		wpFmEA3z8JR = A6F71g3cqN4(Z7uFdWIRv9ybj0,'POST',GOuBcLdJk31zseN7xQFn4vjq5ptWYg,BTMputsaqV,obS4TpHeV3digGC,'','','EGYBEST3-TITLES-1st')
		QstumvzTIEUMXCcx06aD4y8nSqH = wpFmEA3z8JR.content
		XgMyLUkfvP4uKVpQsY8RiWZz6N50O = 'blocks'+QstumvzTIEUMXCcx06aD4y8nSqH+'article'
	else:
		wpFmEA3z8JR = A6F71g3cqN4(Z7uFdWIRv9ybj0,'GET',url,'','','','','EGYBEST3-TITLES-2nd')
		QstumvzTIEUMXCcx06aD4y8nSqH = wpFmEA3z8JR.content
		XgMyLUkfvP4uKVpQsY8RiWZz6N50O = QstumvzTIEUMXCcx06aD4y8nSqH
		code = ZXFs0mEPR8qI2zj.findall("<script>(var.*?=.*?;var.*?=.*?;var.*?=.*?;var.*?=.*?;var.*?=.*?);</script>",QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
		if code:
			code = code[0].replace('var','').replace(' ','').replace("'",'').replace(';','&')
			vfLGDU1N0e8c,data = hGMVvHBuPC014('?'+code)
			zMgjU0c1p3xke7GQEJqWv = int(data['limit'])
			start = int(data['start'])
			DOVwrFbPi1kIm8n = data['type']
			select = data['select']
			rOd2abCI1hSegBuqP6G = data['ajaxurl']
			BTMputsaqV = 'limit='+str(zMgjU0c1p3xke7GQEJqWv)+'&start='+str(start)+'&type='+DOVwrFbPi1kIm8n+'&select='+select
			GOuBcLdJk31zseN7xQFn4vjq5ptWYg = JJTrn6SEtYZV31eyR97+rOd2abCI1hSegBuqP6G
			obS4TpHeV3digGC = {'Content-Type':'application/x-www-form-urlencoded'}
			wpFmEA3z8JR = A6F71g3cqN4(Z7uFdWIRv9ybj0,'POST',GOuBcLdJk31zseN7xQFn4vjq5ptWYg,BTMputsaqV,obS4TpHeV3digGC,'','','EGYBEST3-TITLES-3rd')
			XgMyLUkfvP4uKVpQsY8RiWZz6N50O = wpFmEA3z8JR.content
			XgMyLUkfvP4uKVpQsY8RiWZz6N50O = 'blocks'+XgMyLUkfvP4uKVpQsY8RiWZz6N50O+'article'
	items,rzc5pxXnS1eFdMg,zIpQyOG78Nvreijwa = [],False,False
	if not type:
		IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('main-content(.*?)</div>',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
		if IZGcQbePXxwAoyYR1n:
			bdq4e6Wr2gslnSiA38 = IZGcQbePXxwAoyYR1n[0]
			items = ZXFs0mEPR8qI2zj.findall('href="(.*?)".*?</i>(.*?)</a>',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
			for RRucmYBaXegTtNOdGHMQ,title in items:
				title = title.strip(' ')
				Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,791,'','submenu')
				rzc5pxXnS1eFdMg = True
	if not type:
		zIpQyOG78Nvreijwa = pkFycSeY2Efgd(QstumvzTIEUMXCcx06aD4y8nSqH)
	if not rzc5pxXnS1eFdMg and not zIpQyOG78Nvreijwa:
		IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('blocks(.*?)article',XgMyLUkfvP4uKVpQsY8RiWZz6N50O,ZXFs0mEPR8qI2zj.DOTALL)
		if IZGcQbePXxwAoyYR1n:
			bdq4e6Wr2gslnSiA38 = IZGcQbePXxwAoyYR1n[0]
			items = ZXFs0mEPR8qI2zj.findall('href="(.*?)".*?src="(.*?)".*?class="title">(.*?)<',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
			for RRucmYBaXegTtNOdGHMQ,CrGO63LT7j2UxniW,title in items:
				CrGO63LT7j2UxniW = CrGO63LT7j2UxniW.strip('\n')
				RRucmYBaXegTtNOdGHMQ = ejBOu2WXwvb4YpITdsLF16(RRucmYBaXegTtNOdGHMQ)
				if '/selary/' in RRucmYBaXegTtNOdGHMQ: Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,791,CrGO63LT7j2UxniW)
				elif 'مسلسل' in RRucmYBaXegTtNOdGHMQ and 'حلقة' not in RRucmYBaXegTtNOdGHMQ: Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,796,CrGO63LT7j2UxniW)
				elif 'موسم' in RRucmYBaXegTtNOdGHMQ and 'حلقة' not in RRucmYBaXegTtNOdGHMQ: Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,796,CrGO63LT7j2UxniW)
				else: Tca7NsYPkIRWtBpFgxLZbSmCi('video',W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,793,CrGO63LT7j2UxniW)
		aCjFiMNJDG = 12
		data = ZXFs0mEPR8qI2zj.findall('class="(load-more.*?)<',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
		if len(items)==aCjFiMNJDG and (data or 'pagination' in type):
			BTMputsaqV = 'limit='+str(aCjFiMNJDG)+'&start='+str(start+aCjFiMNJDG)+'&type='+DOVwrFbPi1kIm8n+'&select='+select
			lQHXdV9Nzf6BLqS8D = GOuBcLdJk31zseN7xQFn4vjq5ptWYg+'?next=page&'+BTMputsaqV
			Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+'المزيد',lQHXdV9Nzf6BLqS8D,791,'','pagination_'+type)
	return
def pkFycSeY2Efgd(QstumvzTIEUMXCcx06aD4y8nSqH):
	zIpQyOG78Nvreijwa = False
	IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('main-article(.*?)article',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	if IZGcQbePXxwAoyYR1n:
		bdq4e6Wr2gslnSiA38 = IZGcQbePXxwAoyYR1n[0]
		n5nyDgxTuHbY0LNV4cWvoBtp = ZXFs0mEPR8qI2zj.findall('data-tax="(.*?)".*?<span>(.*?)<(.*?)</ul>',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
		if n5nyDgxTuHbY0LNV4cWvoBtp: Tca7NsYPkIRWtBpFgxLZbSmCi('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
		for p8pgXONsjY,name,bdq4e6Wr2gslnSiA38 in n5nyDgxTuHbY0LNV4cWvoBtp:
			name = name.strip(' ')
			items = ZXFs0mEPR8qI2zj.findall('href="(.*?)">(.*?)<',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
			for RRucmYBaXegTtNOdGHMQ,AARNPWHjQU9dEmDI in items:
				title = name+':  '+AARNPWHjQU9dEmDI
				Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,791,'','filter')
				zIpQyOG78Nvreijwa = True
	return zIpQyOG78Nvreijwa
def jXYwiO9D056pkrzRh1y8tfWJxQoaI3(url):
	wpFmEA3z8JR = A6F71g3cqN4(KxirmCLT6Gw,'GET',url,'','','','','EGYBEST3-PLAY-1st')
	QstumvzTIEUMXCcx06aD4y8nSqH = wpFmEA3z8JR.content
	yf608hE5KeRG1DscunvrU,B1lkJKt2wS4EHFLuayQvAN9X0gxf = [],[]
	items = ZXFs0mEPR8qI2zj.findall('server-item.*?data-code="(.*?)"',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	for lMLE6SRw8PVHoyAhvrNp1TKYkO in items:
		nD2eLgmu4U85GvOZ1l = EGTVgQoSu6ZsD.b64decode(lMLE6SRw8PVHoyAhvrNp1TKYkO)
		if VYMZsxRpcQHPgkaiDKjyoh: nD2eLgmu4U85GvOZ1l = nD2eLgmu4U85GvOZ1l.decode('utf8')
		RRucmYBaXegTtNOdGHMQ = ZXFs0mEPR8qI2zj.findall('src="(.*?)"',nD2eLgmu4U85GvOZ1l,ZXFs0mEPR8qI2zj.DOTALL)
		if RRucmYBaXegTtNOdGHMQ:
			RRucmYBaXegTtNOdGHMQ = RRucmYBaXegTtNOdGHMQ[0]
			if RRucmYBaXegTtNOdGHMQ not in B1lkJKt2wS4EHFLuayQvAN9X0gxf:
				B1lkJKt2wS4EHFLuayQvAN9X0gxf.append(RRucmYBaXegTtNOdGHMQ)
				NGmuWwXdLQ6nMltx39FYECohJ = d78KRnJmBWscGua0XMk(RRucmYBaXegTtNOdGHMQ,'name')
				yf608hE5KeRG1DscunvrU.append(RRucmYBaXegTtNOdGHMQ+'?named='+NGmuWwXdLQ6nMltx39FYECohJ+'__watch')
	IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('class="downloads(.*?)</section>',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	if IZGcQbePXxwAoyYR1n:
		bdq4e6Wr2gslnSiA38 = IZGcQbePXxwAoyYR1n[0]
		items = ZXFs0mEPR8qI2zj.findall('"tr flex-start".*?<div>[ a-zA-Z]*(\d{3,4})[ a-zA-Z]*</div>.*?href="(.*?)"',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
		for PHUqTNVJ0ErRSwibn5gD,RRucmYBaXegTtNOdGHMQ in items:
			if RRucmYBaXegTtNOdGHMQ not in B1lkJKt2wS4EHFLuayQvAN9X0gxf:
				if '/?url=' in RRucmYBaXegTtNOdGHMQ: RRucmYBaXegTtNOdGHMQ = RRucmYBaXegTtNOdGHMQ.split('/?url=')[1]
				B1lkJKt2wS4EHFLuayQvAN9X0gxf.append(RRucmYBaXegTtNOdGHMQ)
				NGmuWwXdLQ6nMltx39FYECohJ = d78KRnJmBWscGua0XMk(RRucmYBaXegTtNOdGHMQ,'name')
				yf608hE5KeRG1DscunvrU.append(RRucmYBaXegTtNOdGHMQ+'?named='+NGmuWwXdLQ6nMltx39FYECohJ+'__download____'+PHUqTNVJ0ErRSwibn5gD)
	import fnxsZbk2Fm
	fnxsZbk2Fm.n2h4SBIzxbgJD3K7rtVej01EuGcHPs(yf608hE5KeRG1DscunvrU,ll6f2wvU4FdqL3MJyDxORESCK197i,'video',url)
	return
def F6OgHwYPRiX10tJEv8r(text):
	return