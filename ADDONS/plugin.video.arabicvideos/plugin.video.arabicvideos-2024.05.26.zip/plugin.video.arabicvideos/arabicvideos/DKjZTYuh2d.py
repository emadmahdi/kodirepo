# -*- coding: utf-8 -*-
from j3x780FpaM import *
ll6f2wvU4FdqL3MJyDxORESCK197i = 'IFILM'
W74fAyGxODoLPs5vMX2l8C93R = '_IFL_'
JJTrn6SEtYZV31eyR97 = uReHcEzxkTm6pN4Q[ll6f2wvU4FdqL3MJyDxORESCK197i][0]
dJSW5LrBmHfxeu = uReHcEzxkTm6pN4Q[ll6f2wvU4FdqL3MJyDxORESCK197i][1]
GD7tZ81nNvWm2cB9uqHgYP5hAOadjs = uReHcEzxkTm6pN4Q[ll6f2wvU4FdqL3MJyDxORESCK197i][2]
jiWJkoFNsB4ycah = uReHcEzxkTm6pN4Q[ll6f2wvU4FdqL3MJyDxORESCK197i][3]
def OVQIAezo6U1NSTl4L(mode,url,wwNtFTLK2IqAszYBDV9J,text):
	if   mode==20: HkKfQCS7RIa4xi3houjvl = LwulYKBn6VHFjh1R0iUo()
	elif mode==21: HkKfQCS7RIa4xi3houjvl = oMUN5hPpTkxVZG12Qiva8BKnyw6(url)
	elif mode==22: HkKfQCS7RIa4xi3houjvl = RxAy5lEFQ1chv0BrdU4p6Pt2(url,wwNtFTLK2IqAszYBDV9J)
	elif mode==23: HkKfQCS7RIa4xi3houjvl = pqx0gStI9ojGFP2rWhwRfkVCNX(url,wwNtFTLK2IqAszYBDV9J)
	elif mode==24: HkKfQCS7RIa4xi3houjvl = jXYwiO9D056pkrzRh1y8tfWJxQoaI3(url,text)
	elif mode==25: HkKfQCS7RIa4xi3houjvl = ww0j5Syunb41HihtCKpY83qMekW(url)
	elif mode==27: HkKfQCS7RIa4xi3houjvl = RRDqBGVHKunaeLk5hcsSvYr(url)
	elif mode==28: HkKfQCS7RIa4xi3houjvl = Z5gkCHaWFE()
	elif mode==29: HkKfQCS7RIa4xi3houjvl = F6OgHwYPRiX10tJEv8r(text)
	else: HkKfQCS7RIa4xi3houjvl = False
	return HkKfQCS7RIa4xi3houjvl
def LwulYKBn6VHFjh1R0iUo():
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+'عربي',JJTrn6SEtYZV31eyR97,21,'','101')
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+'English',dJSW5LrBmHfxeu,21,'','101')
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+'فارسى',GD7tZ81nNvWm2cB9uqHgYP5hAOadjs,21,'','101')
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+'فارسى 2',jiWJkoFNsB4ycah,21,'','101')
	return
def Z5gkCHaWFE():
	Tca7NsYPkIRWtBpFgxLZbSmCi('live',W74fAyGxODoLPs5vMX2l8C93R+'عربي',JJTrn6SEtYZV31eyR97,27)
	Tca7NsYPkIRWtBpFgxLZbSmCi('live',W74fAyGxODoLPs5vMX2l8C93R+'English',dJSW5LrBmHfxeu,27)
	Tca7NsYPkIRWtBpFgxLZbSmCi('live',W74fAyGxODoLPs5vMX2l8C93R+'فارسى',GD7tZ81nNvWm2cB9uqHgYP5hAOadjs,27)
	Tca7NsYPkIRWtBpFgxLZbSmCi('live',W74fAyGxODoLPs5vMX2l8C93R+'فارسى 2',jiWJkoFNsB4ycah,27)
	return
def oMUN5hPpTkxVZG12Qiva8BKnyw6(uuqhf1T7da5YX0UF):
	ll6f2wvU4FdqL3MJyDxORESCK197i = uuqhf1T7da5YX0UF
	if uuqhf1T7da5YX0UF=='IFILM-ARABIC': uuqhf1T7da5YX0UF = JJTrn6SEtYZV31eyR97
	elif uuqhf1T7da5YX0UF=='IFILM-ENGLISH': uuqhf1T7da5YX0UF = dJSW5LrBmHfxeu
	else: ll6f2wvU4FdqL3MJyDxORESCK197i = ''
	EWMGN9wslbO5qRn34Sy = qfmwg1O7UjcSHWQy9pD(uuqhf1T7da5YX0UF)
	if EWMGN9wslbO5qRn34Sy=='ar' or ll6f2wvU4FdqL3MJyDxORESCK197i=='IFILM-ARABIC':
		svwePZ9o2ab7Szjt4HRcdh3xY = 'بحث في الموقع'
		Isp16k7xRZa0lYD5vdmA = 'مسلسلات - حالية'
		Ym8DlVPuqS1tJb = 'مسلسلات - أحدث'
		Co4Qq7fnvINTujFBhGKMWgxPmtr = 'مسلسلات - أبجدي'
		OuaQFxR4enA7oLJsZp01cVt = 'بث حي آي فيلم'
		rrK7WqLZyoBX5TA4DgmkcnhSPNGpM = 'أفلام'
		vvTtrzBpVw9WRfiGX = 'موسيقى'
		oLhWQHUKZlpzS = 'برامج'
	elif EWMGN9wslbO5qRn34Sy=='en' or ll6f2wvU4FdqL3MJyDxORESCK197i=='IFILM-ENGLISH':
		svwePZ9o2ab7Szjt4HRcdh3xY = 'Search in site'
		Isp16k7xRZa0lYD5vdmA = 'Series - Current'
		Ym8DlVPuqS1tJb = 'Series - Latest'
		Co4Qq7fnvINTujFBhGKMWgxPmtr = 'Series - Alphabet'
		OuaQFxR4enA7oLJsZp01cVt = 'Live iFilm channel'
		rrK7WqLZyoBX5TA4DgmkcnhSPNGpM = 'Movies'
		vvTtrzBpVw9WRfiGX = 'Music'
		oLhWQHUKZlpzS = 'Shows'
	elif EWMGN9wslbO5qRn34Sy in ['fa','fa2']:
		svwePZ9o2ab7Szjt4HRcdh3xY = 'جستجو در سایت'
		Isp16k7xRZa0lYD5vdmA = 'سريال - جاری'
		Ym8DlVPuqS1tJb = 'سريال - آخرین'
		Co4Qq7fnvINTujFBhGKMWgxPmtr = 'سريال - الفبا'
		OuaQFxR4enA7oLJsZp01cVt = 'پخش زنده اي فيلم'
		rrK7WqLZyoBX5TA4DgmkcnhSPNGpM = 'فيلم'
		vvTtrzBpVw9WRfiGX = 'موسيقى'
		oLhWQHUKZlpzS = 'برنامه ها'
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+svwePZ9o2ab7Szjt4HRcdh3xY,uuqhf1T7da5YX0UF,29,'','','_REMEMBERRESULTS_')
	Tca7NsYPkIRWtBpFgxLZbSmCi('live',ll6f2wvU4FdqL3MJyDxORESCK197i+'_SCRIPT_'+W74fAyGxODoLPs5vMX2l8C93R+OuaQFxR4enA7oLJsZp01cVt,uuqhf1T7da5YX0UF,27)
	Tca7NsYPkIRWtBpFgxLZbSmCi('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	Iwo3ZzUA69btP5g21r = ['Series','Program','Music']
	QstumvzTIEUMXCcx06aD4y8nSqH = QuWA3hsmIvockZDiy2rLg(JNsoWV1CXc4xy,uuqhf1T7da5YX0UF+'/home','','','','IFILM-MENU-1st')
	IZGcQbePXxwAoyYR1n=ZXFs0mEPR8qI2zj.findall('button-menu(.*?)/Contact',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	if IZGcQbePXxwAoyYR1n:
		bdq4e6Wr2gslnSiA38 = IZGcQbePXxwAoyYR1n[0]
		items = ZXFs0mEPR8qI2zj.findall('href="(.*?)">(.*?)<',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
		for RRucmYBaXegTtNOdGHMQ,title in items:
			if any(AARNPWHjQU9dEmDI in RRucmYBaXegTtNOdGHMQ for AARNPWHjQU9dEmDI in Iwo3ZzUA69btP5g21r):
				url = uuqhf1T7da5YX0UF+RRucmYBaXegTtNOdGHMQ
				if 'Series' in RRucmYBaXegTtNOdGHMQ:
					Tca7NsYPkIRWtBpFgxLZbSmCi('folder',ll6f2wvU4FdqL3MJyDxORESCK197i+'_SCRIPT_'+W74fAyGxODoLPs5vMX2l8C93R+Isp16k7xRZa0lYD5vdmA,url,22,'','100')
					Tca7NsYPkIRWtBpFgxLZbSmCi('folder',ll6f2wvU4FdqL3MJyDxORESCK197i+'_SCRIPT_'+W74fAyGxODoLPs5vMX2l8C93R+Ym8DlVPuqS1tJb,url,22,'','101')
					Tca7NsYPkIRWtBpFgxLZbSmCi('folder',ll6f2wvU4FdqL3MJyDxORESCK197i+'_SCRIPT_'+W74fAyGxODoLPs5vMX2l8C93R+Co4Qq7fnvINTujFBhGKMWgxPmtr,url,22,'','201')
				elif 'Film' in RRucmYBaXegTtNOdGHMQ: Tca7NsYPkIRWtBpFgxLZbSmCi('folder',ll6f2wvU4FdqL3MJyDxORESCK197i+'_SCRIPT_'+W74fAyGxODoLPs5vMX2l8C93R+rrK7WqLZyoBX5TA4DgmkcnhSPNGpM,url,22,'','100')
				elif 'Music' in RRucmYBaXegTtNOdGHMQ: Tca7NsYPkIRWtBpFgxLZbSmCi('folder',ll6f2wvU4FdqL3MJyDxORESCK197i+'_SCRIPT_'+W74fAyGxODoLPs5vMX2l8C93R+vvTtrzBpVw9WRfiGX,url,25,'','101')
				elif 'Program' in RRucmYBaXegTtNOdGHMQ: Tca7NsYPkIRWtBpFgxLZbSmCi('folder',ll6f2wvU4FdqL3MJyDxORESCK197i+'_SCRIPT_'+W74fAyGxODoLPs5vMX2l8C93R+oLhWQHUKZlpzS,url,22,'','101')
	return QstumvzTIEUMXCcx06aD4y8nSqH
def ww0j5Syunb41HihtCKpY83qMekW(url):
	uuqhf1T7da5YX0UF = oDJeKP7ik5rQU(url)
	QstumvzTIEUMXCcx06aD4y8nSqH = QuWA3hsmIvockZDiy2rLg(JNsoWV1CXc4xy,url,'','','','IFILM-MUSIC_MENU-1st')
	IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('Music-tools-header(.*?)Music-body',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	bdq4e6Wr2gslnSiA38 = IZGcQbePXxwAoyYR1n[0]
	title = ZXFs0mEPR8qI2zj.findall('<p>(.*?)</p>',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)[0]
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+title,url,22,'','101')
	items = ZXFs0mEPR8qI2zj.findall('href="(.*?)">(.*?)<',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
	for RRucmYBaXegTtNOdGHMQ,title in items:
		RRucmYBaXegTtNOdGHMQ = uuqhf1T7da5YX0UF + RRucmYBaXegTtNOdGHMQ
		Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,23,'','101')
	return
def RxAy5lEFQ1chv0BrdU4p6Pt2(url,wwNtFTLK2IqAszYBDV9J):
	uuqhf1T7da5YX0UF = oDJeKP7ik5rQU(url)
	EWMGN9wslbO5qRn34Sy = qfmwg1O7UjcSHWQy9pD(url)
	type = url.split('/')[-1]
	BBjnPAG9lrx7FLJYd5Q = str(int(wwNtFTLK2IqAszYBDV9J)//100)
	wwNtFTLK2IqAszYBDV9J = str(int(wwNtFTLK2IqAszYBDV9J)%100)
	if type=='Series' and wwNtFTLK2IqAszYBDV9J=='0':
		QstumvzTIEUMXCcx06aD4y8nSqH = QuWA3hsmIvockZDiy2rLg(Z7uFdWIRv9ybj0,url,'','','','IFILM-TITLES-1st')
		IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('serial-body(.*?)class="row',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
		bdq4e6Wr2gslnSiA38 = IZGcQbePXxwAoyYR1n[0]
		items = ZXFs0mEPR8qI2zj.findall('href="(.*?)".*?src=(.*?)>.*?h3>(.*?)<',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
		for RRucmYBaXegTtNOdGHMQ,CrGO63LT7j2UxniW,title in items:
			title = WhJe7bGx5XackTwOIZVLC8ut(title)
			title = qpob7TvxHSs4fEzO6(title)
			RRucmYBaXegTtNOdGHMQ = uuqhf1T7da5YX0UF + RRucmYBaXegTtNOdGHMQ
			CrGO63LT7j2UxniW = uuqhf1T7da5YX0UF + cD1AgYCl0qZI8(CrGO63LT7j2UxniW)
			Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,23,CrGO63LT7j2UxniW,BBjnPAG9lrx7FLJYd5Q+'01')
	DLwsumndBlcP5Y36Ue7a1RjkVCxS=0
	if type=='Series': p8pgXONsjY='3'
	if type=='Film': p8pgXONsjY='5'
	if type=='Program': p8pgXONsjY='7'
	if type in ['Series','Program','Film'] and wwNtFTLK2IqAszYBDV9J!='0':
		lQHXdV9Nzf6BLqS8D = uuqhf1T7da5YX0UF+'/Home/PageingItem?category='+p8pgXONsjY+'&page='+wwNtFTLK2IqAszYBDV9J+'&size=30&orderby='+BBjnPAG9lrx7FLJYd5Q
		QstumvzTIEUMXCcx06aD4y8nSqH = QuWA3hsmIvockZDiy2rLg(Z7uFdWIRv9ybj0,lQHXdV9Nzf6BLqS8D,'','','','IFILM-TITLES-2nd')
		items = ZXFs0mEPR8qI2zj.findall('"Id":(.*?),"Title":(.*?),.+?"ImageAddress_S":"(.*?)"',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
		for id,title,CrGO63LT7j2UxniW in items:
			title = WhJe7bGx5XackTwOIZVLC8ut(title)
			title = title.replace('\\','')
			title = title.replace('"','')
			DLwsumndBlcP5Y36Ue7a1RjkVCxS += 1
			RRucmYBaXegTtNOdGHMQ = uuqhf1T7da5YX0UF + '/' + type + '/Content/' + id
			CrGO63LT7j2UxniW = uuqhf1T7da5YX0UF + cD1AgYCl0qZI8(CrGO63LT7j2UxniW)
			if type=='Film': Tca7NsYPkIRWtBpFgxLZbSmCi('video',W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,24,CrGO63LT7j2UxniW,BBjnPAG9lrx7FLJYd5Q+'01')
			else: Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,23,CrGO63LT7j2UxniW,BBjnPAG9lrx7FLJYd5Q+'01')
	if type=='Music':
		QstumvzTIEUMXCcx06aD4y8nSqH = QuWA3hsmIvockZDiy2rLg(Z7uFdWIRv9ybj0,uuqhf1T7da5YX0UF+'/Music/Index?page='+wwNtFTLK2IqAszYBDV9J,'','','','IFILM-TITLES-3rd')
		IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('pagination-demo(.*?)pagination-demo',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
		bdq4e6Wr2gslnSiA38 = IZGcQbePXxwAoyYR1n[0]
		items = ZXFs0mEPR8qI2zj.findall('href="(.*?)".*?src="(.*?)".*?<h3>(.*?)</h3>',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
		for RRucmYBaXegTtNOdGHMQ,CrGO63LT7j2UxniW,title in items:
			DLwsumndBlcP5Y36Ue7a1RjkVCxS += 1
			CrGO63LT7j2UxniW = uuqhf1T7da5YX0UF + CrGO63LT7j2UxniW
			RRucmYBaXegTtNOdGHMQ = uuqhf1T7da5YX0UF + RRucmYBaXegTtNOdGHMQ
			Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,23,CrGO63LT7j2UxniW,'101')
	if DLwsumndBlcP5Y36Ue7a1RjkVCxS>20:
		title='صفحة '
		if EWMGN9wslbO5qRn34Sy=='en': title = 'Page '
		if EWMGN9wslbO5qRn34Sy=='fa': title = 'صفحه '
		if EWMGN9wslbO5qRn34Sy=='fa2': title = 'صفحه '
		for LH7kPtRnx2rzGuZiXFWV in range(1,11) :
			if not wwNtFTLK2IqAszYBDV9J==str(LH7kPtRnx2rzGuZiXFWV):
				Bv64fdjXU7CZbpJnRsqmLOti9r2M = '0'+str(LH7kPtRnx2rzGuZiXFWV)
				Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+title+str(LH7kPtRnx2rzGuZiXFWV),url,22,'',BBjnPAG9lrx7FLJYd5Q+Bv64fdjXU7CZbpJnRsqmLOti9r2M[-2:])
	return
def pqx0gStI9ojGFP2rWhwRfkVCNX(url,wwNtFTLK2IqAszYBDV9J):
	if not wwNtFTLK2IqAszYBDV9J: wwNtFTLK2IqAszYBDV9J = 0
	uuqhf1T7da5YX0UF = oDJeKP7ik5rQU(url)
	ssnI4ASGlVvce79 = oDJeKP7ik5rQU(url)
	EWMGN9wslbO5qRn34Sy = qfmwg1O7UjcSHWQy9pD(url)
	mcEHCT3jSM = url.split('/')
	id,type = mcEHCT3jSM[-1],mcEHCT3jSM[3]
	BBjnPAG9lrx7FLJYd5Q = str(int(wwNtFTLK2IqAszYBDV9J)//100)
	wwNtFTLK2IqAszYBDV9J = str(int(wwNtFTLK2IqAszYBDV9J)%100)
	DLwsumndBlcP5Y36Ue7a1RjkVCxS = 0
	if type=='Series':
		QstumvzTIEUMXCcx06aD4y8nSqH = QuWA3hsmIvockZDiy2rLg(Z7uFdWIRv9ybj0,url,'','','','IFILM-EPISODES-1st')
		items = ZXFs0mEPR8qI2zj.findall('Comment_panel_Item.*?p>(.*?)<i.+?var inter_ = (.*?);.*?src="(.*?)\'.*?data-url="(.*?)\'',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
		title = ' - الحلقة '
		if EWMGN9wslbO5qRn34Sy=='en': title = ' - Episode '
		if EWMGN9wslbO5qRn34Sy=='fa': title = ' - قسمت '
		if EWMGN9wslbO5qRn34Sy=='fa2': title = ' - قسمت '
		if EWMGN9wslbO5qRn34Sy=='fa': weVBRoaPQt4uGWHSCFZMyTs = ''
		else: weVBRoaPQt4uGWHSCFZMyTs = EWMGN9wslbO5qRn34Sy
		VawCglEdpmiIcZ = ZXFs0mEPR8qI2zj.findall('data-video="(.*?)(\'.*?\'_)(.*?)">',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
		for name,count,CrGO63LT7j2UxniW,RRucmYBaXegTtNOdGHMQ in items:
			for LqYKJ36CBG in range(int(count),0,-1):
				Za7MW5QuIHitpceqdfvl2r0oy = CrGO63LT7j2UxniW + weVBRoaPQt4uGWHSCFZMyTs + id + '/' + str(LqYKJ36CBG) + '.png'
				Isp16k7xRZa0lYD5vdmA = name + title + str(LqYKJ36CBG)
				Isp16k7xRZa0lYD5vdmA = qpob7TvxHSs4fEzO6(Isp16k7xRZa0lYD5vdmA)
				Tca7NsYPkIRWtBpFgxLZbSmCi('video',W74fAyGxODoLPs5vMX2l8C93R+Isp16k7xRZa0lYD5vdmA,url,24,Za7MW5QuIHitpceqdfvl2r0oy,'',str(LqYKJ36CBG))
	elif type=='Program':
		lQHXdV9Nzf6BLqS8D = uuqhf1T7da5YX0UF+'/Home/PageingAttachmentItem?id='+str(id)+'&page='+wwNtFTLK2IqAszYBDV9J+'&size=30&orderby=1'
		QstumvzTIEUMXCcx06aD4y8nSqH = QuWA3hsmIvockZDiy2rLg(Z7uFdWIRv9ybj0,lQHXdV9Nzf6BLqS8D,'','','','IFILM-EPISODES-2nd')
		items = ZXFs0mEPR8qI2zj.findall('Episode":(.*?),.*?ImageAddress_S":"(.*?)".*?VideoAddress":"(.*?)".*?Discription":"(.*?)".*?Caption":"(.*?)"',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
		title = ' - الحلقة '
		if EWMGN9wslbO5qRn34Sy=='en': title = ' - Episode '
		if EWMGN9wslbO5qRn34Sy=='fa': title = ' - قسمت '
		if EWMGN9wslbO5qRn34Sy=='fa2': title = ' - قسمت '
		for LqYKJ36CBG,CrGO63LT7j2UxniW,RRucmYBaXegTtNOdGHMQ,KIfACdrROM26tb0jeTUN9,name in items:
			DLwsumndBlcP5Y36Ue7a1RjkVCxS += 1
			Za7MW5QuIHitpceqdfvl2r0oy = ssnI4ASGlVvce79 + cD1AgYCl0qZI8(CrGO63LT7j2UxniW)
			name = WhJe7bGx5XackTwOIZVLC8ut(name)
			Isp16k7xRZa0lYD5vdmA = name + title + str(LqYKJ36CBG)
			Tca7NsYPkIRWtBpFgxLZbSmCi('video',W74fAyGxODoLPs5vMX2l8C93R+Isp16k7xRZa0lYD5vdmA,lQHXdV9Nzf6BLqS8D,24,Za7MW5QuIHitpceqdfvl2r0oy,'',str(DLwsumndBlcP5Y36Ue7a1RjkVCxS))
	elif type=='Music':
		if 'Content' in url and 'category' not in url:
			lQHXdV9Nzf6BLqS8D = uuqhf1T7da5YX0UF+'/Music/GetTracksBy?id='+str(id)+'&page='+wwNtFTLK2IqAszYBDV9J+'&size=30&type=0'
			QstumvzTIEUMXCcx06aD4y8nSqH = QuWA3hsmIvockZDiy2rLg(Z7uFdWIRv9ybj0,lQHXdV9Nzf6BLqS8D,'','','','IFILM-EPISODES-3rd')
			items = ZXFs0mEPR8qI2zj.findall('ImageAddress_S":"(.*?)".*?VoiceAddress":"(.*?)".*?Caption":"(.*?)","Title":"(.*?)"',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
			for CrGO63LT7j2UxniW,RRucmYBaXegTtNOdGHMQ,name,title in items:
				DLwsumndBlcP5Y36Ue7a1RjkVCxS += 1
				Za7MW5QuIHitpceqdfvl2r0oy = ssnI4ASGlVvce79 + cD1AgYCl0qZI8(CrGO63LT7j2UxniW)
				Isp16k7xRZa0lYD5vdmA = name + ' - ' + title
				Isp16k7xRZa0lYD5vdmA = Isp16k7xRZa0lYD5vdmA.strip(' ')
				Isp16k7xRZa0lYD5vdmA = WhJe7bGx5XackTwOIZVLC8ut(Isp16k7xRZa0lYD5vdmA)
				Tca7NsYPkIRWtBpFgxLZbSmCi('video',W74fAyGxODoLPs5vMX2l8C93R+Isp16k7xRZa0lYD5vdmA,lQHXdV9Nzf6BLqS8D,24,Za7MW5QuIHitpceqdfvl2r0oy,'',str(DLwsumndBlcP5Y36Ue7a1RjkVCxS))
		elif 'Clips' in url:
			lQHXdV9Nzf6BLqS8D = uuqhf1T7da5YX0UF+'/Music/GetTracksBy?id=0&page='+wwNtFTLK2IqAszYBDV9J+'&size=30&type=15'
			QstumvzTIEUMXCcx06aD4y8nSqH = QuWA3hsmIvockZDiy2rLg(Z7uFdWIRv9ybj0,lQHXdV9Nzf6BLqS8D,'','','','IFILM-EPISODES-4th')
			items = ZXFs0mEPR8qI2zj.findall('ImageAddress_S":"(.*?)".*?Caption":"(.*?)".*?VideoAddress":"(.*?)"',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
			for CrGO63LT7j2UxniW,title,RRucmYBaXegTtNOdGHMQ in items:
				DLwsumndBlcP5Y36Ue7a1RjkVCxS += 1
				Za7MW5QuIHitpceqdfvl2r0oy = ssnI4ASGlVvce79 + cD1AgYCl0qZI8(CrGO63LT7j2UxniW)
				Isp16k7xRZa0lYD5vdmA = title.strip(' ')
				Isp16k7xRZa0lYD5vdmA = WhJe7bGx5XackTwOIZVLC8ut(Isp16k7xRZa0lYD5vdmA)
				Tca7NsYPkIRWtBpFgxLZbSmCi('video',W74fAyGxODoLPs5vMX2l8C93R+Isp16k7xRZa0lYD5vdmA,lQHXdV9Nzf6BLqS8D,24,Za7MW5QuIHitpceqdfvl2r0oy,'',str(DLwsumndBlcP5Y36Ue7a1RjkVCxS))
		elif 'category' in url:
			if 'category=6' in url:
				lQHXdV9Nzf6BLqS8D = uuqhf1T7da5YX0UF+'/Music/GetTracksBy?id=0&page='+wwNtFTLK2IqAszYBDV9J+'&size=30&type=6'
				QstumvzTIEUMXCcx06aD4y8nSqH = QuWA3hsmIvockZDiy2rLg(Z7uFdWIRv9ybj0,lQHXdV9Nzf6BLqS8D,'','','','IFILM-EPISODES-5th')
			elif 'category=4' in url:
				lQHXdV9Nzf6BLqS8D = uuqhf1T7da5YX0UF+'/Music/GetTracksBy?id=0&page='+wwNtFTLK2IqAszYBDV9J+'&size=30&type=4'
				QstumvzTIEUMXCcx06aD4y8nSqH = QuWA3hsmIvockZDiy2rLg(Z7uFdWIRv9ybj0,lQHXdV9Nzf6BLqS8D,'','','','IFILM-EPISODES-6th')
			items = ZXFs0mEPR8qI2zj.findall('ImageAddress_S":"(.*?)".*?VoiceAddress":"(.*?)".*?Caption":"(.*?)","Title":"(.*?)"',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
			for CrGO63LT7j2UxniW,RRucmYBaXegTtNOdGHMQ,name,title in items:
				DLwsumndBlcP5Y36Ue7a1RjkVCxS += 1
				Za7MW5QuIHitpceqdfvl2r0oy = ssnI4ASGlVvce79 + cD1AgYCl0qZI8(CrGO63LT7j2UxniW)
				Isp16k7xRZa0lYD5vdmA = name + ' - ' + title
				Isp16k7xRZa0lYD5vdmA = Isp16k7xRZa0lYD5vdmA.strip(' ')
				Isp16k7xRZa0lYD5vdmA = WhJe7bGx5XackTwOIZVLC8ut(Isp16k7xRZa0lYD5vdmA)
				Tca7NsYPkIRWtBpFgxLZbSmCi('video',W74fAyGxODoLPs5vMX2l8C93R+Isp16k7xRZa0lYD5vdmA,lQHXdV9Nzf6BLqS8D,24,Za7MW5QuIHitpceqdfvl2r0oy,'',str(DLwsumndBlcP5Y36Ue7a1RjkVCxS))
	if type=='Music' or type=='Program':
		if DLwsumndBlcP5Y36Ue7a1RjkVCxS>25:
			title='صفحة '
			if EWMGN9wslbO5qRn34Sy=='en': title = ' Page '
			if EWMGN9wslbO5qRn34Sy=='fa': title = ' صفحه '
			if EWMGN9wslbO5qRn34Sy=='fa2': title = ' صفحه '
			for LH7kPtRnx2rzGuZiXFWV in range(1,11):
				if not wwNtFTLK2IqAszYBDV9J==str(LH7kPtRnx2rzGuZiXFWV):
					Bv64fdjXU7CZbpJnRsqmLOti9r2M = '0'+str(LH7kPtRnx2rzGuZiXFWV)
					Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+title+str(LH7kPtRnx2rzGuZiXFWV),url,23,'',BBjnPAG9lrx7FLJYd5Q+Bv64fdjXU7CZbpJnRsqmLOti9r2M[-2:])
	return
def jXYwiO9D056pkrzRh1y8tfWJxQoaI3(url,LqYKJ36CBG):
	ssnI4ASGlVvce79 = oDJeKP7ik5rQU(url)
	xCLQK8kh39sjyi5DXSZAVeI,YYmyQXglbEewzL3IA2Sd = [],[]
	QstumvzTIEUMXCcx06aD4y8nSqH = QuWA3hsmIvockZDiy2rLg(Z7uFdWIRv9ybj0,url,'','','','IFILM-PLAY-1st')
	items = ZXFs0mEPR8qI2zj.findall('data-video="(.*?)(\'.*?\'_)(.*?)">',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	if items:
		EWMGN9wslbO5qRn34Sy = qfmwg1O7UjcSHWQy9pD(url)
		mcEHCT3jSM = url.split('/')
		id,type = mcEHCT3jSM[-1],mcEHCT3jSM[3]
		RRucmYBaXegTtNOdGHMQ = items[0][0]+EWMGN9wslbO5qRn34Sy+id+'/,'+LqYKJ36CBG+','+LqYKJ36CBG+'_'+items[0][2]
		xCLQK8kh39sjyi5DXSZAVeI.append('m3u8')
		YYmyQXglbEewzL3IA2Sd.append(RRucmYBaXegTtNOdGHMQ)
	items = ZXFs0mEPR8qI2zj.findall('data-url="(http.*?)(\'.*?\')(\..*?)"',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	if items:
		EWMGN9wslbO5qRn34Sy = qfmwg1O7UjcSHWQy9pD(url)
		mcEHCT3jSM = url.split('/')
		id,type = mcEHCT3jSM[-1],mcEHCT3jSM[3]
		RRucmYBaXegTtNOdGHMQ = items[0][0]+EWMGN9wslbO5qRn34Sy+id+'/'+LqYKJ36CBG+items[0][2]
		xCLQK8kh39sjyi5DXSZAVeI.append('mp4 url')
		YYmyQXglbEewzL3IA2Sd.append(RRucmYBaXegTtNOdGHMQ)
	items = ZXFs0mEPR8qI2zj.findall('source src="(.*?)"',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	for RRucmYBaXegTtNOdGHMQ in items:
		RRucmYBaXegTtNOdGHMQ = RRucmYBaXegTtNOdGHMQ.replace('//','/')
		xCLQK8kh39sjyi5DXSZAVeI.append('mp4 src')
		YYmyQXglbEewzL3IA2Sd.append(RRucmYBaXegTtNOdGHMQ)
	items = ZXFs0mEPR8qI2zj.findall('VideoAddress":"(.*?)"',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	if items:
		RRucmYBaXegTtNOdGHMQ = items[int(LqYKJ36CBG)-1]
		RRucmYBaXegTtNOdGHMQ = ssnI4ASGlVvce79+cD1AgYCl0qZI8(RRucmYBaXegTtNOdGHMQ)
		xCLQK8kh39sjyi5DXSZAVeI.append('mp4 address')
		YYmyQXglbEewzL3IA2Sd.append(RRucmYBaXegTtNOdGHMQ)
	items = ZXFs0mEPR8qI2zj.findall('VoiceAddress":"(.*?)"',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	if items:
		RRucmYBaXegTtNOdGHMQ = items[int(LqYKJ36CBG)-1]
		RRucmYBaXegTtNOdGHMQ = ssnI4ASGlVvce79+cD1AgYCl0qZI8(RRucmYBaXegTtNOdGHMQ)
		xCLQK8kh39sjyi5DXSZAVeI.append('mp3 address')
		YYmyQXglbEewzL3IA2Sd.append(RRucmYBaXegTtNOdGHMQ)
	if len(YYmyQXglbEewzL3IA2Sd)==1: RRucmYBaXegTtNOdGHMQ = YYmyQXglbEewzL3IA2Sd[0]
	else:
		jQ6w8xOrgYhSHIRpUqzL = F2yZPukcUh09sqCI8nYw7e('اختر الفيديو المناسب:', xCLQK8kh39sjyi5DXSZAVeI)
		if jQ6w8xOrgYhSHIRpUqzL == -1 : return
		RRucmYBaXegTtNOdGHMQ = YYmyQXglbEewzL3IA2Sd[jQ6w8xOrgYhSHIRpUqzL]
	w3hq0Xp8D9rZJ(RRucmYBaXegTtNOdGHMQ,ll6f2wvU4FdqL3MJyDxORESCK197i,'video')
	return
def oDJeKP7ik5rQU(url):
	if JJTrn6SEtYZV31eyR97 in url: ji1dGuYnsFNKe = JJTrn6SEtYZV31eyR97
	elif dJSW5LrBmHfxeu in url: ji1dGuYnsFNKe = dJSW5LrBmHfxeu
	elif GD7tZ81nNvWm2cB9uqHgYP5hAOadjs in url: ji1dGuYnsFNKe = GD7tZ81nNvWm2cB9uqHgYP5hAOadjs
	elif jiWJkoFNsB4ycah in url: ji1dGuYnsFNKe = jiWJkoFNsB4ycah
	else: ji1dGuYnsFNKe = ''
	return ji1dGuYnsFNKe
def qfmwg1O7UjcSHWQy9pD(url):
	if   JJTrn6SEtYZV31eyR97 in url: EWMGN9wslbO5qRn34Sy = 'ar'
	elif dJSW5LrBmHfxeu in url: EWMGN9wslbO5qRn34Sy = 'en'
	elif GD7tZ81nNvWm2cB9uqHgYP5hAOadjs in url: EWMGN9wslbO5qRn34Sy = 'fa'
	elif jiWJkoFNsB4ycah in url: EWMGN9wslbO5qRn34Sy = 'fa2'
	else: EWMGN9wslbO5qRn34Sy = ''
	return EWMGN9wslbO5qRn34Sy
def RRDqBGVHKunaeLk5hcsSvYr(url):
	EWMGN9wslbO5qRn34Sy = qfmwg1O7UjcSHWQy9pD(url)
	lQHXdV9Nzf6BLqS8D = url + '/Home/Live'
	wpFmEA3z8JR = A6F71g3cqN4(JNsoWV1CXc4xy,'GET',lQHXdV9Nzf6BLqS8D,'','','','','IFILM-LIVE-1st')
	QstumvzTIEUMXCcx06aD4y8nSqH = wpFmEA3z8JR.content
	items = ZXFs0mEPR8qI2zj.findall('source src="(.*?)"',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	aaIn3XlQKJ6zSfkmjuCyM = items[0]
	w3hq0Xp8D9rZJ(aaIn3XlQKJ6zSfkmjuCyM,ll6f2wvU4FdqL3MJyDxORESCK197i,'live')
	return
def F6OgHwYPRiX10tJEv8r(search):
	search,Y9RKmgsxBefkFcuIj2GULDHy3,showDialogs = XDzpr8RxgZhT(search)
	if not search:
		search = CjyEnpfQ23o0PYwDtLId()
		if not search: return
	H9IMP4eTVW8dji3EXnS7w = search.replace(' ','+')
	if showDialogs:
		OrdItJUQGKR0iexz8Eok4l1ymvn7 = [ JJTrn6SEtYZV31eyR97 , dJSW5LrBmHfxeu , GD7tZ81nNvWm2cB9uqHgYP5hAOadjs , jiWJkoFNsB4ycah ]
		Y4yxdBjU2Tm = [ 'عربي' , 'English' , 'فارسى' , 'فارسى 2' ]
		jQ6w8xOrgYhSHIRpUqzL = F2yZPukcUh09sqCI8nYw7e('اختر اللغة المناسبة:', Y4yxdBjU2Tm)
		if jQ6w8xOrgYhSHIRpUqzL == -1 : return
		website = OrdItJUQGKR0iexz8Eok4l1ymvn7[jQ6w8xOrgYhSHIRpUqzL]
	else:
		if '_IFILM-ARABIC_' in Y9RKmgsxBefkFcuIj2GULDHy3: website = JJTrn6SEtYZV31eyR97
		elif '_IFILM-ENGLISH_' in Y9RKmgsxBefkFcuIj2GULDHy3: website = dJSW5LrBmHfxeu
		else: website = ''
	if not website: return
	EWMGN9wslbO5qRn34Sy = qfmwg1O7UjcSHWQy9pD(website)
	lQHXdV9Nzf6BLqS8D = website + "/Home/Search?searchstring=" + H9IMP4eTVW8dji3EXnS7w
	QstumvzTIEUMXCcx06aD4y8nSqH = QuWA3hsmIvockZDiy2rLg(Z7uFdWIRv9ybj0,lQHXdV9Nzf6BLqS8D,'','','','IFILM-SEARCH-1st')
	items = ZXFs0mEPR8qI2zj.findall('"ImageAddress_S":"(.*?)".*?"CategoryId":(.*?),"Id":(.*?),"Title":"(.*?)",',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	if items:
		for CrGO63LT7j2UxniW,p8pgXONsjY,id,title in items:
			if p8pgXONsjY in ['3','7']:
				title = title.replace('\\','')
				title = title.replace('"','')
				if p8pgXONsjY=='3':
					type = 'Series'
					if EWMGN9wslbO5qRn34Sy=='ar': name = 'مسلسل : '
					elif EWMGN9wslbO5qRn34Sy=='en': name = 'Series : '
					elif EWMGN9wslbO5qRn34Sy=='fa': name = 'سريال ها : '
					elif EWMGN9wslbO5qRn34Sy=='fa2': name = 'سريال ها : '
				elif p8pgXONsjY=='5':
					type = 'Film'
					if EWMGN9wslbO5qRn34Sy=='ar': name = 'فيلم : '
					elif EWMGN9wslbO5qRn34Sy=='en': name = 'Movie : '
					elif EWMGN9wslbO5qRn34Sy=='fa': name = 'فيلم : '
					elif EWMGN9wslbO5qRn34Sy=='fa2': name = 'فلم ها : '
				elif p8pgXONsjY=='7':
					type = 'Program'
					if EWMGN9wslbO5qRn34Sy=='ar': name = 'برنامج : '
					elif EWMGN9wslbO5qRn34Sy=='en': name = 'Program : '
					elif EWMGN9wslbO5qRn34Sy=='fa': name = 'برنامه ها : '
					elif EWMGN9wslbO5qRn34Sy=='fa2': name = 'برنامه ها : '
				title = name + title
				RRucmYBaXegTtNOdGHMQ = website + '/' + type + '/Content/' + id
				CrGO63LT7j2UxniW = cD1AgYCl0qZI8(CrGO63LT7j2UxniW)
				CrGO63LT7j2UxniW = website+CrGO63LT7j2UxniW
				Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,23,CrGO63LT7j2UxniW,'101')
	return