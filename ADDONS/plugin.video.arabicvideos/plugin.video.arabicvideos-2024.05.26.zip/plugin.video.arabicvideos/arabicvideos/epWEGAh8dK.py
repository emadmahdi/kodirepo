# -*- coding: utf-8 -*-
from j3x780FpaM import *
ll6f2wvU4FdqL3MJyDxORESCK197i = 'SHAHID4U'
W74fAyGxODoLPs5vMX2l8C93R = '_SH4_'
JJTrn6SEtYZV31eyR97 = uReHcEzxkTm6pN4Q[ll6f2wvU4FdqL3MJyDxORESCK197i][0]
SmgoEYJ7uyL = ['عروض مصارعة','الكل','افلام','javascript','مصارعة حرة']
def OVQIAezo6U1NSTl4L(mode,url,text):
	if   mode==110: HkKfQCS7RIa4xi3houjvl = oMUN5hPpTkxVZG12Qiva8BKnyw6()
	elif mode==111: HkKfQCS7RIa4xi3houjvl = RxAy5lEFQ1chv0BrdU4p6Pt2(url,text)
	elif mode==112: HkKfQCS7RIa4xi3houjvl = jXYwiO9D056pkrzRh1y8tfWJxQoaI3(url)
	elif mode==113: HkKfQCS7RIa4xi3houjvl = pqx0gStI9ojGFP2rWhwRfkVCNX(url,True)
	elif mode==114: HkKfQCS7RIa4xi3houjvl = nvzlr8m5JEsbaqKd6YTuHCIfX9kLR(url,'FULL_FILTER___'+text)
	elif mode==115: HkKfQCS7RIa4xi3houjvl = nvzlr8m5JEsbaqKd6YTuHCIfX9kLR(url,'DEFINED_FILTER___'+text)
	elif mode==116: HkKfQCS7RIa4xi3houjvl = pqx0gStI9ojGFP2rWhwRfkVCNX(url,False)
	elif mode==119: HkKfQCS7RIa4xi3houjvl = F6OgHwYPRiX10tJEv8r(text)
	else: HkKfQCS7RIa4xi3houjvl = False
	return HkKfQCS7RIa4xi3houjvl
def oMUN5hPpTkxVZG12Qiva8BKnyw6():
	headers = {'User-Agent':SjMG7CYyUqbPVso0DErhXROvkl(True)}
	wpFmEA3z8JR = A6F71g3cqN4(Z7uFdWIRv9ybj0,'GET',JJTrn6SEtYZV31eyR97,'',headers,'','','SHAHID4U-MENU-1st')
	QstumvzTIEUMXCcx06aD4y8nSqH = wpFmEA3z8JR.content
	pp5vX2CWHBtwOPzdq0Junij7 = d78KRnJmBWscGua0XMk(wpFmEA3z8JR.url,'url')
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+'بحث في الموقع','',119,'','','_REMEMBERRESULTS_')
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+'فلتر محدد',pp5vX2CWHBtwOPzdq0Junij7,115)
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+'فلتر كامل',pp5vX2CWHBtwOPzdq0Junij7,114)
	Tca7NsYPkIRWtBpFgxLZbSmCi('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+'المميزة',pp5vX2CWHBtwOPzdq0Junij7,111,'','','featured')
	IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('simple-filter(.*?)adv-filter',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	if not IZGcQbePXxwAoyYR1n:
		HHTzVhiY079bvdluNkFQ4wCMpe('','','موقع شاهد فوريو','البرنامج لم يستطيع إيجاد عنوان الموقع أو تصميم الموقع تغير')
		return
	else:
		bdq4e6Wr2gslnSiA38 = IZGcQbePXxwAoyYR1n[0]
		items = ZXFs0mEPR8qI2zj.findall('location = \'(.*?)\'.*?src="(.*?)".*?<h3>(.*?)<',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
		for filter,CrGO63LT7j2UxniW,title in items:
			url = pp5vX2CWHBtwOPzdq0Junij7+filter
			Tca7NsYPkIRWtBpFgxLZbSmCi('folder',ll6f2wvU4FdqL3MJyDxORESCK197i+'_SCRIPT_'+W74fAyGxODoLPs5vMX2l8C93R+title,url,111,CrGO63LT7j2UxniW,'',filter)
		Tca7NsYPkIRWtBpFgxLZbSmCi('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('class="dropdown"(.*?)<script>',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	if IZGcQbePXxwAoyYR1n:
		bdq4e6Wr2gslnSiA38 = IZGcQbePXxwAoyYR1n[0]
		items = ZXFs0mEPR8qI2zj.findall('href="(.*?)".*?>(.*?)<',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
		for RRucmYBaXegTtNOdGHMQ,title in items:
			title = title.replace('\n','').replace('\r','').strip(' ')
			if title in SmgoEYJ7uyL: continue
			if 'http' not in RRucmYBaXegTtNOdGHMQ: RRucmYBaXegTtNOdGHMQ = pp5vX2CWHBtwOPzdq0Junij7+RRucmYBaXegTtNOdGHMQ
			if 'netflix' in RRucmYBaXegTtNOdGHMQ: title = 'نيتفلكس'
			Tca7NsYPkIRWtBpFgxLZbSmCi('folder',ll6f2wvU4FdqL3MJyDxORESCK197i+'_SCRIPT_'+W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,111)
	return QstumvzTIEUMXCcx06aD4y8nSqH
def RxAy5lEFQ1chv0BrdU4p6Pt2(url,qzTpS3aBcFGiM='',wpFmEA3z8JR=''):
	headers = {'User-Agent':SjMG7CYyUqbPVso0DErhXROvkl(True)}
	if not wpFmEA3z8JR: wpFmEA3z8JR = A6F71g3cqN4(Z7uFdWIRv9ybj0,'GET',url,'',headers,'','','SHAHID4U-TITLES-1st')
	QstumvzTIEUMXCcx06aD4y8nSqH = wpFmEA3z8JR.content
	IZGcQbePXxwAoyYR1n,items,FF1TYf6O5KENr8R72LUVievClmudxD = [],[],[]
	if qzTpS3aBcFGiM=='featured': IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('glide__slides(.*?)</ul>',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	else: IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('shows-container(.*?)pagination',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	if not IZGcQbePXxwAoyYR1n: return
	bdq4e6Wr2gslnSiA38 = IZGcQbePXxwAoyYR1n[0]
	if not items: items = ZXFs0mEPR8qI2zj.findall('href="(.*?)".*?url\((.*?)\).*?"title">(.*?)</h4>',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
	QK2N8Bn0lLVdsURIgufJ = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم']
	for RRucmYBaXegTtNOdGHMQ,CrGO63LT7j2UxniW,title in items:
		if 'WWE' in title: continue
		if 'javascript' in RRucmYBaXegTtNOdGHMQ: continue
		RRucmYBaXegTtNOdGHMQ = ejBOu2WXwvb4YpITdsLF16(RRucmYBaXegTtNOdGHMQ).strip('/')
		title = qpob7TvxHSs4fEzO6(title)
		title = title.strip(' ')
		LqYKJ36CBG = ZXFs0mEPR8qI2zj.findall('(.*?) الحلقة \d+',title,ZXFs0mEPR8qI2zj.DOTALL)
		if '/film/' in RRucmYBaXegTtNOdGHMQ or 'فيلم' in RRucmYBaXegTtNOdGHMQ or any(AARNPWHjQU9dEmDI in title for AARNPWHjQU9dEmDI in QK2N8Bn0lLVdsURIgufJ):
			Tca7NsYPkIRWtBpFgxLZbSmCi('video',W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,112,CrGO63LT7j2UxniW)
		elif LqYKJ36CBG and 'الحلقة' in title and '/list' not in url:
			title = '_MOD_' + LqYKJ36CBG[0]
			if title not in FF1TYf6O5KENr8R72LUVievClmudxD:
				Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,113,CrGO63LT7j2UxniW)
				FF1TYf6O5KENr8R72LUVievClmudxD.append(title)
		elif '/actor/' in RRucmYBaXegTtNOdGHMQ:
			Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,111,CrGO63LT7j2UxniW)
		elif '/series/' in RRucmYBaXegTtNOdGHMQ and '/list' not in url:
			RRucmYBaXegTtNOdGHMQ = RRucmYBaXegTtNOdGHMQ+'/list'
			Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,111,CrGO63LT7j2UxniW)
		elif '/list' in url and 'حلقة' in title:
			Tca7NsYPkIRWtBpFgxLZbSmCi('video',W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,112,CrGO63LT7j2UxniW)
		else: Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,113,CrGO63LT7j2UxniW)
	IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('"pagination"(.*?)</ul>',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	if IZGcQbePXxwAoyYR1n:
		bdq4e6Wr2gslnSiA38 = IZGcQbePXxwAoyYR1n[0]
		if qzTpS3aBcFGiM!='search': items = ZXFs0mEPR8qI2zj.findall('(updateQuery).*?>(.+?)<',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
		else: items = ZXFs0mEPR8qI2zj.findall('<li>.*?href="(.*?)">(.*?)<',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
		if 'page=' in url: url = url.split('page=',1)[0][:-1]
		for RRucmYBaXegTtNOdGHMQ,title in items:
			title = title.replace('\n','').replace('\r','')
			title = title.strip(' ')
			if qzTpS3aBcFGiM!='search':
				if '?' in url: RRucmYBaXegTtNOdGHMQ = url+'&page='+title
				else: RRucmYBaXegTtNOdGHMQ = url+'?page='+title
			title = qpob7TvxHSs4fEzO6(title)
			if title: Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+'صفحة '+title,RRucmYBaXegTtNOdGHMQ,111,'','',qzTpS3aBcFGiM)
	return
def pqx0gStI9ojGFP2rWhwRfkVCNX(url,bbQMRj65d0vncqmCiWeZ8l):
	headers = {'User-Agent':SjMG7CYyUqbPVso0DErhXROvkl(True)}
	wpFmEA3z8JR = A6F71g3cqN4(Z7uFdWIRv9ybj0,'GET',url,'',headers,'','','SHAHID4U-EPISODES-1st')
	QstumvzTIEUMXCcx06aD4y8nSqH = wpFmEA3z8JR.content
	IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('items d-flex(.*?)</div>',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	if len(IZGcQbePXxwAoyYR1n)>1:
		if '/season/' in IZGcQbePXxwAoyYR1n[0]: HEplfjN5wBxeYtD4ds6FvA38rK0U,xvWJR3VCAcyLZ = IZGcQbePXxwAoyYR1n[0],IZGcQbePXxwAoyYR1n[1]
		else: HEplfjN5wBxeYtD4ds6FvA38rK0U,xvWJR3VCAcyLZ = IZGcQbePXxwAoyYR1n[1],IZGcQbePXxwAoyYR1n[0]
	else: HEplfjN5wBxeYtD4ds6FvA38rK0U,xvWJR3VCAcyLZ = IZGcQbePXxwAoyYR1n[0],IZGcQbePXxwAoyYR1n[0]
	for OeT2Jo0sp6h1mGdqfFw in range(2):
		if bbQMRj65d0vncqmCiWeZ8l: mode,type,bdq4e6Wr2gslnSiA38 = 116,'folder',HEplfjN5wBxeYtD4ds6FvA38rK0U
		else: mode,type,bdq4e6Wr2gslnSiA38 = 112,'video',xvWJR3VCAcyLZ
		items = ZXFs0mEPR8qI2zj.findall('href="(.*?)".*?span.*?">(.*?)<.*?span.*?">(.*?)<',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
		if bbQMRj65d0vncqmCiWeZ8l and len(items)<2:
			bbQMRj65d0vncqmCiWeZ8l = False
			continue
		for RRucmYBaXegTtNOdGHMQ,QCDVzPGHj6IxMA,Wu4CadwRTJfkbXMUVxO3jQ2 in items:
			title = QCDVzPGHj6IxMA+' '+Wu4CadwRTJfkbXMUVxO3jQ2
			Tca7NsYPkIRWtBpFgxLZbSmCi(type,W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,mode)
		break
	if not items and '/episodes' in QstumvzTIEUMXCcx06aD4y8nSqH:
		svw1K9Sp4Fl = ZXFs0mEPR8qI2zj.findall('class="breadcrumb"(.*?)</div>',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
		if svw1K9Sp4Fl:
			bdq4e6Wr2gslnSiA38 = svw1K9Sp4Fl[0]
			R28S4pFmAojEW7CGnx = ZXFs0mEPR8qI2zj.findall('href="(.*?)"',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
			if len(R28S4pFmAojEW7CGnx)>2:
				RRucmYBaXegTtNOdGHMQ = R28S4pFmAojEW7CGnx[2]+'list'
				RxAy5lEFQ1chv0BrdU4p6Pt2(RRucmYBaXegTtNOdGHMQ)
	return
def jXYwiO9D056pkrzRh1y8tfWJxQoaI3(url):
	headers = {'User-Agent':SjMG7CYyUqbPVso0DErhXROvkl(True)}
	wpFmEA3z8JR = A6F71g3cqN4(JNsoWV1CXc4xy,'GET',url,'',headers,'','','SHAHID4U-PLAY-1st')
	QstumvzTIEUMXCcx06aD4y8nSqH = wpFmEA3z8JR.content
	IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('class="actions(.*?)</div>',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	if not IZGcQbePXxwAoyYR1n: return
	bdq4e6Wr2gslnSiA38 = IZGcQbePXxwAoyYR1n[0]
	R28S4pFmAojEW7CGnx = ZXFs0mEPR8qI2zj.findall('href="(.*?)"',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
	jqk9WQcCI3mGgfR = '/watch/' in bdq4e6Wr2gslnSiA38
	download = '/download/' in bdq4e6Wr2gslnSiA38
	if   jqk9WQcCI3mGgfR and not download: E5EvwVGLuJOlIxQbeqZ,lwLehj2ro0nqTVuyIfGE3s1AbROtv = R28S4pFmAojEW7CGnx[0],''
	elif not jqk9WQcCI3mGgfR and download: E5EvwVGLuJOlIxQbeqZ,lwLehj2ro0nqTVuyIfGE3s1AbROtv = '',R28S4pFmAojEW7CGnx[0]
	elif jqk9WQcCI3mGgfR and download: E5EvwVGLuJOlIxQbeqZ,lwLehj2ro0nqTVuyIfGE3s1AbROtv = R28S4pFmAojEW7CGnx[0],R28S4pFmAojEW7CGnx[1]
	else: E5EvwVGLuJOlIxQbeqZ,lwLehj2ro0nqTVuyIfGE3s1AbROtv = '',''
	YYmyQXglbEewzL3IA2Sd = []
	if jqk9WQcCI3mGgfR:
		wpFmEA3z8JR = A6F71g3cqN4(JNsoWV1CXc4xy,'GET',E5EvwVGLuJOlIxQbeqZ,'',headers,'','','SHAHID4U-PLAY-2nd')
		XgMyLUkfvP4uKVpQsY8RiWZz6N50O = wpFmEA3z8JR.content
		CCqaV18lM0OL = ZXFs0mEPR8qI2zj.findall('let servers(.*?)player',XgMyLUkfvP4uKVpQsY8RiWZz6N50O,ZXFs0mEPR8qI2zj.DOTALL|ZXFs0mEPR8qI2zj.IGNORECASE)
		if CCqaV18lM0OL:
			i9jtofq4JrV = CCqaV18lM0OL[0]
			kYoiqbhP2AfzOHWmjxS69sNdM = ZXFs0mEPR8qI2zj.findall('"name":"(.*?)".*?"url":"(.*?)"',i9jtofq4JrV,ZXFs0mEPR8qI2zj.DOTALL)
			for title,RRucmYBaXegTtNOdGHMQ in kYoiqbhP2AfzOHWmjxS69sNdM:
				RRucmYBaXegTtNOdGHMQ = RRucmYBaXegTtNOdGHMQ.replace('\\/','/')
				RRucmYBaXegTtNOdGHMQ = RRucmYBaXegTtNOdGHMQ+'?named='+title+'__watch'
				YYmyQXglbEewzL3IA2Sd.append(RRucmYBaXegTtNOdGHMQ)
	if download:
		wpFmEA3z8JR = A6F71g3cqN4(JNsoWV1CXc4xy,'GET',lwLehj2ro0nqTVuyIfGE3s1AbROtv,'',headers,'','','SHAHID4U-PLAY-3rd')
		XgMyLUkfvP4uKVpQsY8RiWZz6N50O = wpFmEA3z8JR.content
		CCqaV18lM0OL = ZXFs0mEPR8qI2zj.findall('"servers"(.*?)info-container',XgMyLUkfvP4uKVpQsY8RiWZz6N50O,ZXFs0mEPR8qI2zj.DOTALL)
		if CCqaV18lM0OL:
			i9jtofq4JrV = CCqaV18lM0OL[0]
			kYoiqbhP2AfzOHWmjxS69sNdM = ZXFs0mEPR8qI2zj.findall('href="(.*?)".*?<span>(.*?)<.*?</i>.*?<span>(.*?)<',i9jtofq4JrV,ZXFs0mEPR8qI2zj.DOTALL)
			for RRucmYBaXegTtNOdGHMQ,title,PHUqTNVJ0ErRSwibn5gD in kYoiqbhP2AfzOHWmjxS69sNdM:
				RRucmYBaXegTtNOdGHMQ = RRucmYBaXegTtNOdGHMQ+'?named='+title+'__download'+'____'+PHUqTNVJ0ErRSwibn5gD
				YYmyQXglbEewzL3IA2Sd.append(RRucmYBaXegTtNOdGHMQ)
	import fnxsZbk2Fm
	fnxsZbk2Fm.n2h4SBIzxbgJD3K7rtVej01EuGcHPs(YYmyQXglbEewzL3IA2Sd,ll6f2wvU4FdqL3MJyDxORESCK197i,'video',url)
	return
def F6OgHwYPRiX10tJEv8r(search):
	search,Y9RKmgsxBefkFcuIj2GULDHy3,showDialogs = XDzpr8RxgZhT(search)
	if not search:
		search = CjyEnpfQ23o0PYwDtLId()
		if not search: return
	search = search.replace(' ','+')
	url = JJTrn6SEtYZV31eyR97+'/search?s='+search
	RxAy5lEFQ1chv0BrdU4p6Pt2(url,'search')
	return
def VB2O0ktvjpGqC4JrTKlu9EWsIM(url):
	url = url.split('/smartemadfilter?')[0]
	headers = {'User-Agent':SjMG7CYyUqbPVso0DErhXROvkl(True)}
	wpFmEA3z8JR = A6F71g3cqN4(JNsoWV1CXc4xy,'GET',url,'',headers,'','','SHAHID4U-GET_FILTERS_BLOCKS-1st')
	QstumvzTIEUMXCcx06aD4y8nSqH = wpFmEA3z8JR.content
	jNFqoOewYB2mG = []
	IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('adv-filter(.*?)shows-container',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	if IZGcQbePXxwAoyYR1n:
		bdq4e6Wr2gslnSiA38 = IZGcQbePXxwAoyYR1n[0]
		jNFqoOewYB2mG = ZXFs0mEPR8qI2zj.findall('''updateQuery\('(.*?)'.*?value="">(.*?)<(.*?)</select''',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
		PQqDFYUwuCO0,dmBJGMLH1U7,n5nyDgxTuHbY0LNV4cWvoBtp = zip(*jNFqoOewYB2mG)
		jNFqoOewYB2mG = zip(dmBJGMLH1U7,PQqDFYUwuCO0,n5nyDgxTuHbY0LNV4cWvoBtp)
	return jNFqoOewYB2mG
def ZsvjUo8dVL0cPGRIqD5iEgN67COr(bdq4e6Wr2gslnSiA38):
	items = ZXFs0mEPR8qI2zj.findall('value="(.*?)".*?>\s*(.*?)\s*<',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
	return items
def eYPc6TvD40LHE7(url):
	if '/smartemadfilter?' not in url: url = url+'/smartemadfilter?'
	ZFcjgy5Kb1GuRlmeCqY0vT = url.split('/smartemadfilter?')[0]
	SSybMXta8gxTFKrUZDwNLWPcoHfEQ = d78KRnJmBWscGua0XMk(url,'url')
	url = url.replace(ZFcjgy5Kb1GuRlmeCqY0vT,SSybMXta8gxTFKrUZDwNLWPcoHfEQ)
	url = url.replace('/smartemadfilter?','/?')
	return url
ZZNgtFYdW3MTeRKb7 = ['quality','year','genre','category']
P3QLjTBhF70tmHuA64DJknIXO = ['category','genre','year']
def nvzlr8m5JEsbaqKd6YTuHCIfX9kLR(url,filter):
	url = url.split('/smartemadfilter?')[0]
	type,filter = filter.split('___',1)
	if filter=='': SFbYEzoech4wU1,kXR5NJaOcQUd47zugHqCAvjGoLmW = '',''
	else: SFbYEzoech4wU1,kXR5NJaOcQUd47zugHqCAvjGoLmW = filter.split('___')
	if type=='DEFINED_FILTER':
		if P3QLjTBhF70tmHuA64DJknIXO[0]+'=' not in SFbYEzoech4wU1: p8pgXONsjY = P3QLjTBhF70tmHuA64DJknIXO[0]
		for xxFhvt275i8MdUVuPkSXzmbT in range(len(P3QLjTBhF70tmHuA64DJknIXO[0:-1])):
			if P3QLjTBhF70tmHuA64DJknIXO[xxFhvt275i8MdUVuPkSXzmbT]+'=' in SFbYEzoech4wU1: p8pgXONsjY = P3QLjTBhF70tmHuA64DJknIXO[xxFhvt275i8MdUVuPkSXzmbT+1]
		vX5qmpr1hSAszGE = SFbYEzoech4wU1+'&'+p8pgXONsjY+'=0'
		t9NhYxrZKcBf4u = kXR5NJaOcQUd47zugHqCAvjGoLmW+'&'+p8pgXONsjY+'=0'
		tt6AbxYRgQ3aC4O = vX5qmpr1hSAszGE.strip('&')+'___'+t9NhYxrZKcBf4u.strip('&')
		KMUEN9cD1OByji = l0mO1GdhAtb(kXR5NJaOcQUd47zugHqCAvjGoLmW,'modified_filters')
		lQHXdV9Nzf6BLqS8D = url+'/smartemadfilter?'+KMUEN9cD1OByji
	elif type=='FULL_FILTER':
		cOM2mQXqbrRyiKasDz = l0mO1GdhAtb(SFbYEzoech4wU1,'modified_values')
		cOM2mQXqbrRyiKasDz = ejBOu2WXwvb4YpITdsLF16(cOM2mQXqbrRyiKasDz)
		if kXR5NJaOcQUd47zugHqCAvjGoLmW!='': kXR5NJaOcQUd47zugHqCAvjGoLmW = l0mO1GdhAtb(kXR5NJaOcQUd47zugHqCAvjGoLmW,'modified_filters')
		if kXR5NJaOcQUd47zugHqCAvjGoLmW=='': lQHXdV9Nzf6BLqS8D = url
		else: lQHXdV9Nzf6BLqS8D = url+'/smartemadfilter?'+kXR5NJaOcQUd47zugHqCAvjGoLmW
		aaIn3XlQKJ6zSfkmjuCyM = eYPc6TvD40LHE7(lQHXdV9Nzf6BLqS8D)
		Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+'أظهار قائمة الفيديو التي تم اختيارها ',aaIn3XlQKJ6zSfkmjuCyM,111)
		Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+' [[   '+cOM2mQXqbrRyiKasDz+'   ]]',aaIn3XlQKJ6zSfkmjuCyM,111)
		Tca7NsYPkIRWtBpFgxLZbSmCi('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	jNFqoOewYB2mG = VB2O0ktvjpGqC4JrTKlu9EWsIM(url)
	dict = {}
	for name,Lm4n6ZMXPrWpo,bdq4e6Wr2gslnSiA38 in jNFqoOewYB2mG:
		name = name.replace('كل ','')
		items = ZsvjUo8dVL0cPGRIqD5iEgN67COr(bdq4e6Wr2gslnSiA38)
		if '=' not in lQHXdV9Nzf6BLqS8D: lQHXdV9Nzf6BLqS8D = url
		if type=='DEFINED_FILTER':
			if p8pgXONsjY!=Lm4n6ZMXPrWpo: continue
			elif len(items)<2:
				if Lm4n6ZMXPrWpo==P3QLjTBhF70tmHuA64DJknIXO[-1]:
					aaIn3XlQKJ6zSfkmjuCyM = eYPc6TvD40LHE7(lQHXdV9Nzf6BLqS8D)
					RxAy5lEFQ1chv0BrdU4p6Pt2(aaIn3XlQKJ6zSfkmjuCyM)
				else: nvzlr8m5JEsbaqKd6YTuHCIfX9kLR(lQHXdV9Nzf6BLqS8D,'DEFINED_FILTER___'+tt6AbxYRgQ3aC4O)
				return
			else:
				if Lm4n6ZMXPrWpo==P3QLjTBhF70tmHuA64DJknIXO[-1]:
					aaIn3XlQKJ6zSfkmjuCyM = eYPc6TvD40LHE7(lQHXdV9Nzf6BLqS8D)
					Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+'الجميع',aaIn3XlQKJ6zSfkmjuCyM,111)
				else: Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+'الجميع',lQHXdV9Nzf6BLqS8D,115,'','',tt6AbxYRgQ3aC4O)
		elif type=='FULL_FILTER':
			vX5qmpr1hSAszGE = SFbYEzoech4wU1+'&'+Lm4n6ZMXPrWpo+'=0'
			t9NhYxrZKcBf4u = kXR5NJaOcQUd47zugHqCAvjGoLmW+'&'+Lm4n6ZMXPrWpo+'=0'
			tt6AbxYRgQ3aC4O = vX5qmpr1hSAszGE+'___'+t9NhYxrZKcBf4u
			Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+'الجميع :'+name,lQHXdV9Nzf6BLqS8D,114,'','',tt6AbxYRgQ3aC4O)
		dict[Lm4n6ZMXPrWpo] = {}
		for AARNPWHjQU9dEmDI,Z7ZzgCTMBsNlVi9 in items:
			if AARNPWHjQU9dEmDI=='196533': Z7ZzgCTMBsNlVi9 = 'أفلام نيتفلكس'
			elif AARNPWHjQU9dEmDI=='196531': Z7ZzgCTMBsNlVi9 = 'مسلسلات نيتفلكس'
			if Z7ZzgCTMBsNlVi9 in SmgoEYJ7uyL: continue
			dict[Lm4n6ZMXPrWpo][AARNPWHjQU9dEmDI] = Z7ZzgCTMBsNlVi9
			vX5qmpr1hSAszGE = SFbYEzoech4wU1+'&'+Lm4n6ZMXPrWpo+'='+Z7ZzgCTMBsNlVi9
			t9NhYxrZKcBf4u = kXR5NJaOcQUd47zugHqCAvjGoLmW+'&'+Lm4n6ZMXPrWpo+'='+AARNPWHjQU9dEmDI
			WYXmvw9l3jToq6rui1SCs = vX5qmpr1hSAszGE+'___'+t9NhYxrZKcBf4u
			title = Z7ZzgCTMBsNlVi9+' :'#+dict[Lm4n6ZMXPrWpo]['0']
			title = Z7ZzgCTMBsNlVi9+' :'+name
			if type=='FULL_FILTER': Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+title,url,114,'','',WYXmvw9l3jToq6rui1SCs)
			elif type=='DEFINED_FILTER' and P3QLjTBhF70tmHuA64DJknIXO[-2]+'=' in SFbYEzoech4wU1:
				KMUEN9cD1OByji = l0mO1GdhAtb(t9NhYxrZKcBf4u,'modified_filters')
				lQHXdV9Nzf6BLqS8D = url+'/smartemadfilter?'+KMUEN9cD1OByji
				aaIn3XlQKJ6zSfkmjuCyM = eYPc6TvD40LHE7(lQHXdV9Nzf6BLqS8D)
				Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+title,aaIn3XlQKJ6zSfkmjuCyM,111)
			else: Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+title,url,115,'','',WYXmvw9l3jToq6rui1SCs)
	return
def l0mO1GdhAtb(zIpQyOG78Nvreijwa,mode):
	zIpQyOG78Nvreijwa = zIpQyOG78Nvreijwa.replace('=&','=0&')
	zIpQyOG78Nvreijwa = zIpQyOG78Nvreijwa.strip('&')
	JhV0ZrwmLIcOaHfQDK9qNsEGPzF83p = {}
	if '=' in zIpQyOG78Nvreijwa:
		items = zIpQyOG78Nvreijwa.split('&')
		for q8BXZlN9sU1fP2JAxH7W in items:
			cfMR9TgeL2hx6Wnq4liDX,AARNPWHjQU9dEmDI = q8BXZlN9sU1fP2JAxH7W.split('=')
			JhV0ZrwmLIcOaHfQDK9qNsEGPzF83p[cfMR9TgeL2hx6Wnq4liDX] = AARNPWHjQU9dEmDI
	rXLaWluDjvi4xMwpOSF91JB7 = ''
	for key in ZZNgtFYdW3MTeRKb7:
		if key in list(JhV0ZrwmLIcOaHfQDK9qNsEGPzF83p.keys()): AARNPWHjQU9dEmDI = JhV0ZrwmLIcOaHfQDK9qNsEGPzF83p[key]
		else: AARNPWHjQU9dEmDI = '0'
		if '%' not in AARNPWHjQU9dEmDI: AARNPWHjQU9dEmDI = cD1AgYCl0qZI8(AARNPWHjQU9dEmDI)
		if mode=='modified_values' and AARNPWHjQU9dEmDI!='0': rXLaWluDjvi4xMwpOSF91JB7 = rXLaWluDjvi4xMwpOSF91JB7+' + '+AARNPWHjQU9dEmDI
		elif mode=='modified_filters' and AARNPWHjQU9dEmDI!='0': rXLaWluDjvi4xMwpOSF91JB7 = rXLaWluDjvi4xMwpOSF91JB7+'&'+key+'='+AARNPWHjQU9dEmDI
		elif mode=='all': rXLaWluDjvi4xMwpOSF91JB7 = rXLaWluDjvi4xMwpOSF91JB7+'&'+key+'='+AARNPWHjQU9dEmDI
	rXLaWluDjvi4xMwpOSF91JB7 = rXLaWluDjvi4xMwpOSF91JB7.strip(' + ')
	rXLaWluDjvi4xMwpOSF91JB7 = rXLaWluDjvi4xMwpOSF91JB7.strip('&')
	rXLaWluDjvi4xMwpOSF91JB7 = rXLaWluDjvi4xMwpOSF91JB7.replace('=0','=')
	return rXLaWluDjvi4xMwpOSF91JB7