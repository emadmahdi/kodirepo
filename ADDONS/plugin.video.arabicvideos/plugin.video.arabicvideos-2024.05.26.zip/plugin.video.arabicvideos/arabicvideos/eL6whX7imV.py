# -*- coding: utf-8 -*-
from j3x780FpaM import *
ll6f2wvU4FdqL3MJyDxORESCK197i = 'ARBLIONZ'
headers = { 'User-Agent' : '' }
W74fAyGxODoLPs5vMX2l8C93R = '_ARL_'
JJTrn6SEtYZV31eyR97 = uReHcEzxkTm6pN4Q[ll6f2wvU4FdqL3MJyDxORESCK197i][0]
SmgoEYJ7uyL = ['عروض المصارعة','الكل','الرئيسية','العاب','برامج كمبيوتر','موبايل و جوال','القسم الاسلامي']
def OVQIAezo6U1NSTl4L(mode,url,text):
	if   mode==200: HkKfQCS7RIa4xi3houjvl = oMUN5hPpTkxVZG12Qiva8BKnyw6()
	elif mode==201: HkKfQCS7RIa4xi3houjvl = RxAy5lEFQ1chv0BrdU4p6Pt2(url)
	elif mode==202: HkKfQCS7RIa4xi3houjvl = jXYwiO9D056pkrzRh1y8tfWJxQoaI3(url)
	elif mode==203: HkKfQCS7RIa4xi3houjvl = pqx0gStI9ojGFP2rWhwRfkVCNX(url)
	elif mode==204: HkKfQCS7RIa4xi3houjvl = nvzlr8m5JEsbaqKd6YTuHCIfX9kLR(url,'FILTERS___'+text)
	elif mode==205: HkKfQCS7RIa4xi3houjvl = nvzlr8m5JEsbaqKd6YTuHCIfX9kLR(url,'CATEGORIES___'+text)
	elif mode==209: HkKfQCS7RIa4xi3houjvl = F6OgHwYPRiX10tJEv8r(text)
	else: HkKfQCS7RIa4xi3houjvl = False
	return HkKfQCS7RIa4xi3houjvl
def oMUN5hPpTkxVZG12Qiva8BKnyw6():
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+'بحث في الموقع','',209,'','','_REMEMBERRESULTS_')
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+'فلتر محدد',JJTrn6SEtYZV31eyR97,205)
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+'فلتر كامل',JJTrn6SEtYZV31eyR97,204)
	Tca7NsYPkIRWtBpFgxLZbSmCi('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder',ll6f2wvU4FdqL3MJyDxORESCK197i+'_SCRIPT_'+W74fAyGxODoLPs5vMX2l8C93R+'مميزة',JJTrn6SEtYZV31eyR97+'??trending',201)
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder',ll6f2wvU4FdqL3MJyDxORESCK197i+'_SCRIPT_'+W74fAyGxODoLPs5vMX2l8C93R+'أفلام مميزة',JJTrn6SEtYZV31eyR97+'??trending_movies',201)
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder',ll6f2wvU4FdqL3MJyDxORESCK197i+'_SCRIPT_'+W74fAyGxODoLPs5vMX2l8C93R+'مسلسلات مميزة',JJTrn6SEtYZV31eyR97+'??trending_series',201)
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder',ll6f2wvU4FdqL3MJyDxORESCK197i+'_SCRIPT_'+W74fAyGxODoLPs5vMX2l8C93R+'الصفحة الرئيسية',JJTrn6SEtYZV31eyR97+'??mainpage',201)
	wpFmEA3z8JR = A6F71g3cqN4(JNsoWV1CXc4xy,'GET',JJTrn6SEtYZV31eyR97,'',headers,True,'','ARBLIONZ-MENU-1st')
	QstumvzTIEUMXCcx06aD4y8nSqH = wpFmEA3z8JR.content
	IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('categories-tabs(.*?)MainRow',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	if IZGcQbePXxwAoyYR1n:
		bdq4e6Wr2gslnSiA38 = IZGcQbePXxwAoyYR1n[0]
		items = ZXFs0mEPR8qI2zj.findall('data-get="(.*?)".*?<h3>(.*?)<',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
		for filter,title in items:
			RRucmYBaXegTtNOdGHMQ = JJTrn6SEtYZV31eyR97+'/ajax/home/more?filter='+filter
			Tca7NsYPkIRWtBpFgxLZbSmCi('folder',ll6f2wvU4FdqL3MJyDxORESCK197i+'_SCRIPT_'+W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,201)
		Tca7NsYPkIRWtBpFgxLZbSmCi('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('navigation-menu(.*?)</div>',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	bdq4e6Wr2gslnSiA38 = IZGcQbePXxwAoyYR1n[0]
	items = ZXFs0mEPR8qI2zj.findall('href="(.*?)".*?>(.*?)<',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
	for RRucmYBaXegTtNOdGHMQ,title in items:
		if 'http' not in RRucmYBaXegTtNOdGHMQ: RRucmYBaXegTtNOdGHMQ = JJTrn6SEtYZV31eyR97+RRucmYBaXegTtNOdGHMQ
		title = title.strip(' ')
		if not any(AARNPWHjQU9dEmDI in title for AARNPWHjQU9dEmDI in SmgoEYJ7uyL):
			Tca7NsYPkIRWtBpFgxLZbSmCi('folder',ll6f2wvU4FdqL3MJyDxORESCK197i+'_SCRIPT_'+W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,201)
	return QstumvzTIEUMXCcx06aD4y8nSqH
def RxAy5lEFQ1chv0BrdU4p6Pt2(url):
	if '??' in url: url,type = url.split('??')
	else: type = ''
	wpFmEA3z8JR = A6F71g3cqN4(Z7uFdWIRv9ybj0,'GET',url,'',headers,True,'','ARBLIONZ-TITLES-2nd')
	QstumvzTIEUMXCcx06aD4y8nSqH = wpFmEA3z8JR.content.encode('utf8')
	if 'getposts' in url: IZGcQbePXxwAoyYR1n = [QstumvzTIEUMXCcx06aD4y8nSqH]
	elif type=='trending':
		IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('MasterSlider(.*?)</div>\n *</div>\n *</div>',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	elif type=='trending_movies':
		IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('Slider_1(.*?)</div>.</div>.</div>.</div>',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	elif type=='trending_series':
		IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('Slider_2(.*?)</div>.</div>.</div>.</div>',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	elif type=='111mainpage':
		IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('class="container page-content"(.*?)class="tabs"',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	else:
		IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('page-content(.*?)main-footer',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	if not IZGcQbePXxwAoyYR1n: return
	bdq4e6Wr2gslnSiA38 = IZGcQbePXxwAoyYR1n[0]
	OVKupw4tFexi6JMykj3lNhW1 = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم']
	items = ZXFs0mEPR8qI2zj.findall('content-box".*?src="(.*?)".*?href="(.*?)".*?<h3>(.*?)<',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
	if not items:
		items = ZXFs0mEPR8qI2zj.findall('SliderItem".*?href="(.*?)".*?image: url\((.*?)\).*?<h2>(.*?)<',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
		R28S4pFmAojEW7CGnx,Mbe4UmywtK8Pj9or,mwXy4HaY1uWtlvbZVcN7 = zip(*items)
		items = zip(Mbe4UmywtK8Pj9or,R28S4pFmAojEW7CGnx,mwXy4HaY1uWtlvbZVcN7)
	FF1TYf6O5KENr8R72LUVievClmudxD = []
	for CrGO63LT7j2UxniW,RRucmYBaXegTtNOdGHMQ,title in items:
		if '/series/' in RRucmYBaXegTtNOdGHMQ: continue
		RRucmYBaXegTtNOdGHMQ = RRucmYBaXegTtNOdGHMQ.strip('/')
		title = qpob7TvxHSs4fEzO6(title)
		title = title.strip(' ')
		if '/film/' in RRucmYBaXegTtNOdGHMQ or any(AARNPWHjQU9dEmDI in title for AARNPWHjQU9dEmDI in OVKupw4tFexi6JMykj3lNhW1):
			Tca7NsYPkIRWtBpFgxLZbSmCi('video',W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,202,CrGO63LT7j2UxniW)
		elif '/episode/' in RRucmYBaXegTtNOdGHMQ and 'الحلقة' in title:
			LqYKJ36CBG = ZXFs0mEPR8qI2zj.findall('(.*?) الحلقة \d+',title,ZXFs0mEPR8qI2zj.DOTALL)
			if LqYKJ36CBG:
				title = '_MOD_' + LqYKJ36CBG[0]
				if title not in FF1TYf6O5KENr8R72LUVievClmudxD:
					Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,203,CrGO63LT7j2UxniW)
					FF1TYf6O5KENr8R72LUVievClmudxD.append(title)
		elif '/pack/' in RRucmYBaXegTtNOdGHMQ:
			Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ+'/films',201,CrGO63LT7j2UxniW)
		else: Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,203,CrGO63LT7j2UxniW)
	if type in ['','mainpage']:
		IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('class="pagination(.*?)</div>',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
		if IZGcQbePXxwAoyYR1n:
			bdq4e6Wr2gslnSiA38 = IZGcQbePXxwAoyYR1n[0]
			items = ZXFs0mEPR8qI2zj.findall('href=["\'](http.*?)["\'].*?>(.*?)<',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
			for RRucmYBaXegTtNOdGHMQ,title in items:
				RRucmYBaXegTtNOdGHMQ = qpob7TvxHSs4fEzO6(RRucmYBaXegTtNOdGHMQ)
				title = qpob7TvxHSs4fEzO6(title)
				title = title.replace('الصفحة ','')
				if 'search?s=' in url:
					DKP1r3delJkmMSfLWRtz2GwZHBO8 = RRucmYBaXegTtNOdGHMQ.split('page=')[1]
					NLqFlkRvxT0u4QUjeDpsA7J2hC = url.split('page=')[1]
					RRucmYBaXegTtNOdGHMQ = url.replace('page='+NLqFlkRvxT0u4QUjeDpsA7J2hC,'page='+DKP1r3delJkmMSfLWRtz2GwZHBO8)
				if title!='': Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+'صفحة '+title,RRucmYBaXegTtNOdGHMQ,201)
	return
def pqx0gStI9ojGFP2rWhwRfkVCNX(url):
	FLZWy5QnN2m9GbXSoIhP1dUr7Yilwu,items,IN6fHPDgUuOEvsXR3814Y = -1,[],[]
	wpFmEA3z8JR = A6F71g3cqN4(Z7uFdWIRv9ybj0,'GET',url,'',headers,True,'','ARBLIONZ-EPISODES-1st')
	QstumvzTIEUMXCcx06aD4y8nSqH = wpFmEA3z8JR.content.encode('utf8')
	IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('ti-list-numbered(.*?)</div>',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	if IZGcQbePXxwAoyYR1n:
		IN6fHPDgUuOEvsXR3814Y = []
		n5nyDgxTuHbY0LNV4cWvoBtp = ''.join(IZGcQbePXxwAoyYR1n)
		items = ZXFs0mEPR8qI2zj.findall('href="(.*?)"',n5nyDgxTuHbY0LNV4cWvoBtp,ZXFs0mEPR8qI2zj.DOTALL)
	items.append(url)
	items = set(items)
	for RRucmYBaXegTtNOdGHMQ in items:
		RRucmYBaXegTtNOdGHMQ = RRucmYBaXegTtNOdGHMQ.strip('/')
		title = '_MOD_' + RRucmYBaXegTtNOdGHMQ.split('/')[-1].replace('-',' ')
		QmVwp4UG5eXbO6vRtcWghHY8a7nFqN = ZXFs0mEPR8qI2zj.findall('الحلقة-(\d+)',RRucmYBaXegTtNOdGHMQ.split('/')[-1],ZXFs0mEPR8qI2zj.DOTALL)
		if QmVwp4UG5eXbO6vRtcWghHY8a7nFqN: QmVwp4UG5eXbO6vRtcWghHY8a7nFqN = QmVwp4UG5eXbO6vRtcWghHY8a7nFqN[0]
		else: QmVwp4UG5eXbO6vRtcWghHY8a7nFqN = '0'
		IN6fHPDgUuOEvsXR3814Y.append([RRucmYBaXegTtNOdGHMQ,title,QmVwp4UG5eXbO6vRtcWghHY8a7nFqN])
	items = sorted(IN6fHPDgUuOEvsXR3814Y, reverse=False, key=lambda key: int(key[2]))
	EMOwU2mH4Ku8cP0ypzt1vIbqB = str(items).count('/season/')
	FLZWy5QnN2m9GbXSoIhP1dUr7Yilwu = str(items).count('/episode/')
	if EMOwU2mH4Ku8cP0ypzt1vIbqB>1 and FLZWy5QnN2m9GbXSoIhP1dUr7Yilwu>0 and '/season/' not in url:
		for RRucmYBaXegTtNOdGHMQ,title,QmVwp4UG5eXbO6vRtcWghHY8a7nFqN in items:
			if '/season/' in RRucmYBaXegTtNOdGHMQ:
				Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,203)
	else:
		for RRucmYBaXegTtNOdGHMQ,title,QmVwp4UG5eXbO6vRtcWghHY8a7nFqN in items:
			if '/season/' not in RRucmYBaXegTtNOdGHMQ:
				title = ejBOu2WXwvb4YpITdsLF16(title)
				Tca7NsYPkIRWtBpFgxLZbSmCi('video',W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,202)
	return
def jXYwiO9D056pkrzRh1y8tfWJxQoaI3(url):
	YYmyQXglbEewzL3IA2Sd = []
	mcEHCT3jSM = url.split('/')
	C6GzBa2KvmX3PRSypYMIE51cu = JJTrn6SEtYZV31eyR97
	wpFmEA3z8JR = A6F71g3cqN4(JNsoWV1CXc4xy,'GET',url,'',headers,True,True,'ARBLIONZ-PLAY-1st')
	QstumvzTIEUMXCcx06aD4y8nSqH = wpFmEA3z8JR.content.encode('utf8')
	id = ZXFs0mEPR8qI2zj.findall('postId:"(.*?)"',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	if not id: id = ZXFs0mEPR8qI2zj.findall('post_id=(.*?)"',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	if not id: id = ZXFs0mEPR8qI2zj.findall('post-id="(.*?)"',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	if id: id = id[0]
	if '/watch/' in QstumvzTIEUMXCcx06aD4y8nSqH:
		lQHXdV9Nzf6BLqS8D = url.replace(mcEHCT3jSM[3],'watch')
		wpFmEA3z8JR = A6F71g3cqN4(JNsoWV1CXc4xy,'GET',lQHXdV9Nzf6BLqS8D,'',headers,True,True,'ARBLIONZ-PLAY-2nd')
		XgMyLUkfvP4uKVpQsY8RiWZz6N50O = wpFmEA3z8JR.content.encode('utf8')
		FFZDfvbrVnP92CtJYNp4UQ5 = ZXFs0mEPR8qI2zj.findall('data-embedd="(.*?)".*?alt="(.*?)"',XgMyLUkfvP4uKVpQsY8RiWZz6N50O,ZXFs0mEPR8qI2zj.DOTALL)
		kYoiqbhP2AfzOHWmjxS69sNdM = ZXFs0mEPR8qI2zj.findall('data-embedd=".*?(http.*?)("|&quot;)',XgMyLUkfvP4uKVpQsY8RiWZz6N50O,ZXFs0mEPR8qI2zj.DOTALL)
		V7hbc5UGrkIlsuFLC4mMpvqA = ZXFs0mEPR8qI2zj.findall('src=&quot;(.*?)&quot;.*?>(.*?)<',XgMyLUkfvP4uKVpQsY8RiWZz6N50O,ZXFs0mEPR8qI2zj.DOTALL|ZXFs0mEPR8qI2zj.IGNORECASE)
		fl59AZMoswqWEDp8HbiJ = ZXFs0mEPR8qI2zj.findall('data-embedd="(.*?)">\n*.*?server_image">\n(.*?)\n',XgMyLUkfvP4uKVpQsY8RiWZz6N50O)
		xJDjicRvVYsEu3UQSw = ZXFs0mEPR8qI2zj.findall('src=&quot;(.*?)&quot;.*?alt="(.*?)"',XgMyLUkfvP4uKVpQsY8RiWZz6N50O,ZXFs0mEPR8qI2zj.DOTALL|ZXFs0mEPR8qI2zj.IGNORECASE)
		XuCPzTjyJcsvGN6tZVBpkFWKn = ZXFs0mEPR8qI2zj.findall('server="(.*?)".*?<span>(.*?)<',XgMyLUkfvP4uKVpQsY8RiWZz6N50O,ZXFs0mEPR8qI2zj.DOTALL|ZXFs0mEPR8qI2zj.IGNORECASE)
		items = FFZDfvbrVnP92CtJYNp4UQ5+kYoiqbhP2AfzOHWmjxS69sNdM+V7hbc5UGrkIlsuFLC4mMpvqA+fl59AZMoswqWEDp8HbiJ+xJDjicRvVYsEu3UQSw+XuCPzTjyJcsvGN6tZVBpkFWKn
		if not items:
			items = ZXFs0mEPR8qI2zj.findall('<span>(.*?)</span>.*?src="(.*?)"',XgMyLUkfvP4uKVpQsY8RiWZz6N50O,ZXFs0mEPR8qI2zj.DOTALL|ZXFs0mEPR8qI2zj.IGNORECASE)
			items = [(NNegALBo7uywU2CbGQczXpa1,t1XqvOW7h3IDQRuErCjyg) for t1XqvOW7h3IDQRuErCjyg,NNegALBo7uywU2CbGQczXpa1 in items]
		for NGmuWwXdLQ6nMltx39FYECohJ,title in items:
			if '.png' in NGmuWwXdLQ6nMltx39FYECohJ: continue
			if '.jpg' in NGmuWwXdLQ6nMltx39FYECohJ: continue
			if '&quot;' in NGmuWwXdLQ6nMltx39FYECohJ: continue
			PHUqTNVJ0ErRSwibn5gD = ZXFs0mEPR8qI2zj.findall('\d\d\d+',title,ZXFs0mEPR8qI2zj.DOTALL)
			if PHUqTNVJ0ErRSwibn5gD:
				PHUqTNVJ0ErRSwibn5gD = PHUqTNVJ0ErRSwibn5gD[0]
				if PHUqTNVJ0ErRSwibn5gD in title: title = title.replace(PHUqTNVJ0ErRSwibn5gD+'p','').replace(PHUqTNVJ0ErRSwibn5gD,'').strip(' ')
				PHUqTNVJ0ErRSwibn5gD = '____'+PHUqTNVJ0ErRSwibn5gD
			else: PHUqTNVJ0ErRSwibn5gD = ''
			if NGmuWwXdLQ6nMltx39FYECohJ.isdigit():
				RRucmYBaXegTtNOdGHMQ = C6GzBa2KvmX3PRSypYMIE51cu+'/?postid='+id+'&serverid='+NGmuWwXdLQ6nMltx39FYECohJ+'?named='+title+'__watch'+PHUqTNVJ0ErRSwibn5gD
			else:
				if 'http' not in NGmuWwXdLQ6nMltx39FYECohJ: NGmuWwXdLQ6nMltx39FYECohJ = 'http:'+NGmuWwXdLQ6nMltx39FYECohJ
				PHUqTNVJ0ErRSwibn5gD = ZXFs0mEPR8qI2zj.findall('\d\d\d+',title,ZXFs0mEPR8qI2zj.DOTALL)
				if PHUqTNVJ0ErRSwibn5gD: PHUqTNVJ0ErRSwibn5gD = '____'+PHUqTNVJ0ErRSwibn5gD[0]
				else: PHUqTNVJ0ErRSwibn5gD = ''
				RRucmYBaXegTtNOdGHMQ = NGmuWwXdLQ6nMltx39FYECohJ+'?named=__watch'+PHUqTNVJ0ErRSwibn5gD
			YYmyQXglbEewzL3IA2Sd.append(RRucmYBaXegTtNOdGHMQ)
	if 'DownloadNow' in QstumvzTIEUMXCcx06aD4y8nSqH:
		obS4TpHeV3digGC = { 'Content-Type':'application/x-www-form-urlencoded; charset=UTF-8' }
		lQHXdV9Nzf6BLqS8D = url+'/download'
		wpFmEA3z8JR = A6F71g3cqN4(JNsoWV1CXc4xy,'GET',lQHXdV9Nzf6BLqS8D,'',obS4TpHeV3digGC,True,'','ARBLIONZ-PLAY-3rd')
		XgMyLUkfvP4uKVpQsY8RiWZz6N50O = wpFmEA3z8JR.content.encode('utf8')
		IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('<ul class="download-items(.*?)</ul>',XgMyLUkfvP4uKVpQsY8RiWZz6N50O,ZXFs0mEPR8qI2zj.DOTALL)
		for bdq4e6Wr2gslnSiA38 in IZGcQbePXxwAoyYR1n:
			items = ZXFs0mEPR8qI2zj.findall('href="(http.*?)".*?<span>(.*?)<.*?<p>(.*?)<',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
			for RRucmYBaXegTtNOdGHMQ,name,PHUqTNVJ0ErRSwibn5gD in items:
				RRucmYBaXegTtNOdGHMQ = RRucmYBaXegTtNOdGHMQ+'?named='+name+'__download'+'____'+PHUqTNVJ0ErRSwibn5gD
				YYmyQXglbEewzL3IA2Sd.append(RRucmYBaXegTtNOdGHMQ)
	elif '/download/' in QstumvzTIEUMXCcx06aD4y8nSqH:
		obS4TpHeV3digGC = { 'User-Agent':'' , 'X-Requested-With':'XMLHttpRequest' }
		lQHXdV9Nzf6BLqS8D = C6GzBa2KvmX3PRSypYMIE51cu + '/ajaxCenter?_action=getdownloadlinks&postId='+id
		wpFmEA3z8JR = A6F71g3cqN4(JNsoWV1CXc4xy,'GET',lQHXdV9Nzf6BLqS8D,'',obS4TpHeV3digGC,True,True,'ARBLIONZ-PLAY-4th')
		XgMyLUkfvP4uKVpQsY8RiWZz6N50O = wpFmEA3z8JR.content.encode('utf8')
		if 'download-btns' in XgMyLUkfvP4uKVpQsY8RiWZz6N50O:
			V7hbc5UGrkIlsuFLC4mMpvqA = ZXFs0mEPR8qI2zj.findall('href="(.*?)"',XgMyLUkfvP4uKVpQsY8RiWZz6N50O,ZXFs0mEPR8qI2zj.DOTALL)
			for aaIn3XlQKJ6zSfkmjuCyM in V7hbc5UGrkIlsuFLC4mMpvqA:
				if '/page/' not in aaIn3XlQKJ6zSfkmjuCyM and 'http' in aaIn3XlQKJ6zSfkmjuCyM:
					aaIn3XlQKJ6zSfkmjuCyM = aaIn3XlQKJ6zSfkmjuCyM+'?named=__download'
					YYmyQXglbEewzL3IA2Sd.append(aaIn3XlQKJ6zSfkmjuCyM)
				elif '/page/' in aaIn3XlQKJ6zSfkmjuCyM:
					PHUqTNVJ0ErRSwibn5gD = ''
					wpFmEA3z8JR = A6F71g3cqN4(JNsoWV1CXc4xy,'GET',aaIn3XlQKJ6zSfkmjuCyM,'',headers,True,True,'ARBLIONZ-PLAY-5th')
					CE9JuktifOaXG4zsxYy = wpFmEA3z8JR.content.encode('utf8')
					n5nyDgxTuHbY0LNV4cWvoBtp = ZXFs0mEPR8qI2zj.findall('(<strong>.*?)-----',CE9JuktifOaXG4zsxYy,ZXFs0mEPR8qI2zj.DOTALL)
					for MOLtUPpSoY51qvN9cTHZxaQCryK4md in n5nyDgxTuHbY0LNV4cWvoBtp:
						cLDqpXOWfY = ''
						fl59AZMoswqWEDp8HbiJ = ZXFs0mEPR8qI2zj.findall('<strong>(.*?)</strong>',MOLtUPpSoY51qvN9cTHZxaQCryK4md,ZXFs0mEPR8qI2zj.DOTALL)
						for B3BvhplUCqgfRcP2stWz89Jryi in fl59AZMoswqWEDp8HbiJ:
							q8BXZlN9sU1fP2JAxH7W = ZXFs0mEPR8qI2zj.findall('\d\d\d+',B3BvhplUCqgfRcP2stWz89Jryi,ZXFs0mEPR8qI2zj.DOTALL)
							if q8BXZlN9sU1fP2JAxH7W:
								PHUqTNVJ0ErRSwibn5gD = '____'+q8BXZlN9sU1fP2JAxH7W[0]
								break
						for B3BvhplUCqgfRcP2stWz89Jryi in reversed(fl59AZMoswqWEDp8HbiJ):
							q8BXZlN9sU1fP2JAxH7W = ZXFs0mEPR8qI2zj.findall('\w\w+',B3BvhplUCqgfRcP2stWz89Jryi,ZXFs0mEPR8qI2zj.DOTALL)
							if q8BXZlN9sU1fP2JAxH7W:
								cLDqpXOWfY = q8BXZlN9sU1fP2JAxH7W[0]
								break
						xJDjicRvVYsEu3UQSw = ZXFs0mEPR8qI2zj.findall('href="(.*?)"',MOLtUPpSoY51qvN9cTHZxaQCryK4md,ZXFs0mEPR8qI2zj.DOTALL)
						for H1OqiVcF2BoC8WvNY6kXzpJ7ys in xJDjicRvVYsEu3UQSw:
							H1OqiVcF2BoC8WvNY6kXzpJ7ys = H1OqiVcF2BoC8WvNY6kXzpJ7ys+'?named='+cLDqpXOWfY+'__download'+PHUqTNVJ0ErRSwibn5gD
							YYmyQXglbEewzL3IA2Sd.append(H1OqiVcF2BoC8WvNY6kXzpJ7ys)
		elif 'slow-motion' in XgMyLUkfvP4uKVpQsY8RiWZz6N50O:
			XgMyLUkfvP4uKVpQsY8RiWZz6N50O = XgMyLUkfvP4uKVpQsY8RiWZz6N50O.replace('<h6 ','==END== ==START==')+'==END=='
			XgMyLUkfvP4uKVpQsY8RiWZz6N50O = XgMyLUkfvP4uKVpQsY8RiWZz6N50O.replace('<h3 ','==END== ==START==')+'==END=='
			j81KNOg5Ux4fkQlau3i = ZXFs0mEPR8qI2zj.findall('==START==(.*?)==END==',XgMyLUkfvP4uKVpQsY8RiWZz6N50O,ZXFs0mEPR8qI2zj.DOTALL)
			if j81KNOg5Ux4fkQlau3i:
				for MOLtUPpSoY51qvN9cTHZxaQCryK4md in j81KNOg5Ux4fkQlau3i:
					if 'href=' not in MOLtUPpSoY51qvN9cTHZxaQCryK4md: continue
					FkajiZJDRIYg6 = ''
					fl59AZMoswqWEDp8HbiJ = ZXFs0mEPR8qI2zj.findall('slow-motion">(.*?)<',MOLtUPpSoY51qvN9cTHZxaQCryK4md,ZXFs0mEPR8qI2zj.DOTALL)
					for B3BvhplUCqgfRcP2stWz89Jryi in fl59AZMoswqWEDp8HbiJ:
						q8BXZlN9sU1fP2JAxH7W = ZXFs0mEPR8qI2zj.findall('\d\d\d+',B3BvhplUCqgfRcP2stWz89Jryi,ZXFs0mEPR8qI2zj.DOTALL)
						if q8BXZlN9sU1fP2JAxH7W:
							FkajiZJDRIYg6 = '____'+q8BXZlN9sU1fP2JAxH7W[0]
							break
					fl59AZMoswqWEDp8HbiJ = ZXFs0mEPR8qI2zj.findall('<td>(.*?)</td>.*?href="(http.*?)"',MOLtUPpSoY51qvN9cTHZxaQCryK4md,ZXFs0mEPR8qI2zj.DOTALL)
					if fl59AZMoswqWEDp8HbiJ:
						for cLDqpXOWfY,kBSI0QVCc7jneX in fl59AZMoswqWEDp8HbiJ:
							kBSI0QVCc7jneX = kBSI0QVCc7jneX+'?named='+cLDqpXOWfY+'__download'+FkajiZJDRIYg6
							YYmyQXglbEewzL3IA2Sd.append(kBSI0QVCc7jneX)
					else:
						fl59AZMoswqWEDp8HbiJ = ZXFs0mEPR8qI2zj.findall('href="(.*?http.*?)".*?name">(.*?)<',MOLtUPpSoY51qvN9cTHZxaQCryK4md,ZXFs0mEPR8qI2zj.DOTALL)
						for kBSI0QVCc7jneX,cLDqpXOWfY in fl59AZMoswqWEDp8HbiJ:
							kBSI0QVCc7jneX = kBSI0QVCc7jneX.strip(' ')+'?named='+cLDqpXOWfY+'__download'+FkajiZJDRIYg6
							YYmyQXglbEewzL3IA2Sd.append(kBSI0QVCc7jneX)
			else:
				fl59AZMoswqWEDp8HbiJ = ZXFs0mEPR8qI2zj.findall('href="(.*?)".*?>(\w+)<',XgMyLUkfvP4uKVpQsY8RiWZz6N50O,ZXFs0mEPR8qI2zj.DOTALL)
				for kBSI0QVCc7jneX,cLDqpXOWfY in fl59AZMoswqWEDp8HbiJ:
					kBSI0QVCc7jneX = kBSI0QVCc7jneX.strip(' ')+'?named='+cLDqpXOWfY+'__download'
					YYmyQXglbEewzL3IA2Sd.append(kBSI0QVCc7jneX)
	import fnxsZbk2Fm
	fnxsZbk2Fm.n2h4SBIzxbgJD3K7rtVej01EuGcHPs(YYmyQXglbEewzL3IA2Sd,ll6f2wvU4FdqL3MJyDxORESCK197i,'video',url)
	return
def F6OgHwYPRiX10tJEv8r(search):
	search,Y9RKmgsxBefkFcuIj2GULDHy3,showDialogs = XDzpr8RxgZhT(search)
	if search=='': search = CjyEnpfQ23o0PYwDtLId()
	if search=='': return
	search = search.replace(' ','+')
	wpFmEA3z8JR = A6F71g3cqN4(JNsoWV1CXc4xy,'GET',JJTrn6SEtYZV31eyR97+'/alz','',headers,True,'','ARBLIONZ-SEARCH-1st')
	QstumvzTIEUMXCcx06aD4y8nSqH = wpFmEA3z8JR.content.encode('utf8')
	IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('chevron-select(.*?)</div>',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	if showDialogs and IZGcQbePXxwAoyYR1n:
		bdq4e6Wr2gslnSiA38 = IZGcQbePXxwAoyYR1n[0]
		items = ZXFs0mEPR8qI2zj.findall('value="(.*?)".*?>(.*?)<',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
		UTZAg38PWk7aM1fthHLIlq6DB,T9kVgUrWnHusiQFbBaYE = [],[]
		for p8pgXONsjY,title in items:
			UTZAg38PWk7aM1fthHLIlq6DB.append(p8pgXONsjY)
			T9kVgUrWnHusiQFbBaYE.append(title)
		jQ6w8xOrgYhSHIRpUqzL = F2yZPukcUh09sqCI8nYw7e('اختر الفلتر المناسب:', T9kVgUrWnHusiQFbBaYE)
		if jQ6w8xOrgYhSHIRpUqzL == -1 : return
		p8pgXONsjY = UTZAg38PWk7aM1fthHLIlq6DB[jQ6w8xOrgYhSHIRpUqzL]
	else: p8pgXONsjY = ''
	url = JJTrn6SEtYZV31eyR97 + '/search?s='+search+'&category='+p8pgXONsjY+'&page=1'
	RxAy5lEFQ1chv0BrdU4p6Pt2(url)
	return
def nvzlr8m5JEsbaqKd6YTuHCIfX9kLR(url,filter):
	E0tDmCreab3BWYTcdIupkU46v = ['category','release-year','genre','Quality']
	if '?' in url: url = url.split('/getposts?')[0]
	type,filter = filter.split('___',1)
	if filter=='': SFbYEzoech4wU1,kXR5NJaOcQUd47zugHqCAvjGoLmW = '',''
	else: SFbYEzoech4wU1,kXR5NJaOcQUd47zugHqCAvjGoLmW = filter.split('___')
	if type=='CATEGORIES':
		if E0tDmCreab3BWYTcdIupkU46v[0]+'=' not in SFbYEzoech4wU1: p8pgXONsjY = E0tDmCreab3BWYTcdIupkU46v[0]
		for xxFhvt275i8MdUVuPkSXzmbT in range(len(E0tDmCreab3BWYTcdIupkU46v[0:-1])):
			if E0tDmCreab3BWYTcdIupkU46v[xxFhvt275i8MdUVuPkSXzmbT]+'=' in SFbYEzoech4wU1: p8pgXONsjY = E0tDmCreab3BWYTcdIupkU46v[xxFhvt275i8MdUVuPkSXzmbT+1]
		vX5qmpr1hSAszGE = SFbYEzoech4wU1+'&'+p8pgXONsjY+'=0'
		t9NhYxrZKcBf4u = kXR5NJaOcQUd47zugHqCAvjGoLmW+'&'+p8pgXONsjY+'=0'
		tt6AbxYRgQ3aC4O = vX5qmpr1hSAszGE.strip('&')+'___'+t9NhYxrZKcBf4u.strip('&')
		KMUEN9cD1OByji = l0mO1GdhAtb(kXR5NJaOcQUd47zugHqCAvjGoLmW,'modified_filters')
		lQHXdV9Nzf6BLqS8D = url+'/getposts?'+KMUEN9cD1OByji
	elif type=='FILTERS':
		cOM2mQXqbrRyiKasDz = l0mO1GdhAtb(SFbYEzoech4wU1,'modified_values')
		cOM2mQXqbrRyiKasDz = ejBOu2WXwvb4YpITdsLF16(cOM2mQXqbrRyiKasDz)
		if kXR5NJaOcQUd47zugHqCAvjGoLmW!='': kXR5NJaOcQUd47zugHqCAvjGoLmW = l0mO1GdhAtb(kXR5NJaOcQUd47zugHqCAvjGoLmW,'modified_filters')
		if kXR5NJaOcQUd47zugHqCAvjGoLmW=='': lQHXdV9Nzf6BLqS8D = url
		else: lQHXdV9Nzf6BLqS8D = url+'/getposts?'+kXR5NJaOcQUd47zugHqCAvjGoLmW
		Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+'أظهار قائمة الفيديو التي تم اختيارها ',lQHXdV9Nzf6BLqS8D,201)
		Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+' [[   '+cOM2mQXqbrRyiKasDz+'   ]]',lQHXdV9Nzf6BLqS8D,201)
		Tca7NsYPkIRWtBpFgxLZbSmCi('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	QstumvzTIEUMXCcx06aD4y8nSqH = QuWA3hsmIvockZDiy2rLg(JNsoWV1CXc4xy,url+'/alz','',headers,'','ARBLIONZ-FILTERS_MENU-1st')
	IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('AjaxFilteringData(.*?)FilterWord',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	bdq4e6Wr2gslnSiA38 = IZGcQbePXxwAoyYR1n[0]
	jNFqoOewYB2mG = ZXFs0mEPR8qI2zj.findall('</i>(.*?)<.*?data-forTax="(.*?)"(.*?)<h2',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
	dict = {}
	for name,Lm4n6ZMXPrWpo,bdq4e6Wr2gslnSiA38 in jNFqoOewYB2mG:
		name = name.replace('اختيار ','')
		name = name.replace('سنة الإنتاج','السنة')
		items = ZXFs0mEPR8qI2zj.findall('value="(.*?)".*?</div>(.*?)<',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
		if '=' not in lQHXdV9Nzf6BLqS8D: lQHXdV9Nzf6BLqS8D = url
		if type=='CATEGORIES':
			if p8pgXONsjY!=Lm4n6ZMXPrWpo: continue
			elif len(items)<=1:
				if Lm4n6ZMXPrWpo==E0tDmCreab3BWYTcdIupkU46v[-1]: RxAy5lEFQ1chv0BrdU4p6Pt2(lQHXdV9Nzf6BLqS8D)
				else: nvzlr8m5JEsbaqKd6YTuHCIfX9kLR(lQHXdV9Nzf6BLqS8D,'CATEGORIES___'+tt6AbxYRgQ3aC4O)
				return
			else:
				if Lm4n6ZMXPrWpo==E0tDmCreab3BWYTcdIupkU46v[-1]: Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+'الجميع ',lQHXdV9Nzf6BLqS8D,201)
				else: Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+'الجميع ',lQHXdV9Nzf6BLqS8D,205,'','',tt6AbxYRgQ3aC4O)
		elif type=='FILTERS':
			vX5qmpr1hSAszGE = SFbYEzoech4wU1+'&'+Lm4n6ZMXPrWpo+'=0'
			t9NhYxrZKcBf4u = kXR5NJaOcQUd47zugHqCAvjGoLmW+'&'+Lm4n6ZMXPrWpo+'=0'
			tt6AbxYRgQ3aC4O = vX5qmpr1hSAszGE+'___'+t9NhYxrZKcBf4u
			Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+'الجميع :'+name,lQHXdV9Nzf6BLqS8D,204,'','',tt6AbxYRgQ3aC4O)
		dict[Lm4n6ZMXPrWpo] = {}
		for AARNPWHjQU9dEmDI,Z7ZzgCTMBsNlVi9 in items:
			Z7ZzgCTMBsNlVi9 = Z7ZzgCTMBsNlVi9.replace('\n','')
			if Z7ZzgCTMBsNlVi9 in SmgoEYJ7uyL: continue
			dict[Lm4n6ZMXPrWpo][AARNPWHjQU9dEmDI] = Z7ZzgCTMBsNlVi9
			vX5qmpr1hSAszGE = SFbYEzoech4wU1+'&'+Lm4n6ZMXPrWpo+'='+Z7ZzgCTMBsNlVi9
			t9NhYxrZKcBf4u = kXR5NJaOcQUd47zugHqCAvjGoLmW+'&'+Lm4n6ZMXPrWpo+'='+AARNPWHjQU9dEmDI
			WYXmvw9l3jToq6rui1SCs = vX5qmpr1hSAszGE+'___'+t9NhYxrZKcBf4u
			title = Z7ZzgCTMBsNlVi9+' :'#+dict[Lm4n6ZMXPrWpo]['0']
			title = Z7ZzgCTMBsNlVi9+' :'+name
			if type=='FILTERS': Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+title,url,204,'','',WYXmvw9l3jToq6rui1SCs)
			elif type=='CATEGORIES' and E0tDmCreab3BWYTcdIupkU46v[-2]+'=' in SFbYEzoech4wU1:
				KMUEN9cD1OByji = l0mO1GdhAtb(t9NhYxrZKcBf4u,'modified_filters')
				aaIn3XlQKJ6zSfkmjuCyM = url+'/getposts?'+KMUEN9cD1OByji
				Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+title,aaIn3XlQKJ6zSfkmjuCyM,201)
			else: Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+title,url,205,'','',WYXmvw9l3jToq6rui1SCs)
	return
def l0mO1GdhAtb(zIpQyOG78Nvreijwa,mode):
	zIpQyOG78Nvreijwa = zIpQyOG78Nvreijwa.replace('=&','=0&')
	zIpQyOG78Nvreijwa = zIpQyOG78Nvreijwa.strip('&')
	JhV0ZrwmLIcOaHfQDK9qNsEGPzF83p = {}
	if '=' in zIpQyOG78Nvreijwa:
		items = zIpQyOG78Nvreijwa.split('&')
		for q8BXZlN9sU1fP2JAxH7W in items:
			cfMR9TgeL2hx6Wnq4liDX,AARNPWHjQU9dEmDI = q8BXZlN9sU1fP2JAxH7W.split('=')
			JhV0ZrwmLIcOaHfQDK9qNsEGPzF83p[cfMR9TgeL2hx6Wnq4liDX] = AARNPWHjQU9dEmDI
	rXLaWluDjvi4xMwpOSF91JB7 = ''
	t1tvAd5EPXM = ['category','release-year','genre','Quality']
	for key in t1tvAd5EPXM:
		if key in list(JhV0ZrwmLIcOaHfQDK9qNsEGPzF83p.keys()): AARNPWHjQU9dEmDI = JhV0ZrwmLIcOaHfQDK9qNsEGPzF83p[key]
		else: AARNPWHjQU9dEmDI = '0'
		if '%' not in AARNPWHjQU9dEmDI: AARNPWHjQU9dEmDI = cD1AgYCl0qZI8(AARNPWHjQU9dEmDI)
		if mode=='modified_values' and AARNPWHjQU9dEmDI!='0': rXLaWluDjvi4xMwpOSF91JB7 = rXLaWluDjvi4xMwpOSF91JB7+' + '+AARNPWHjQU9dEmDI
		elif mode=='modified_filters' and AARNPWHjQU9dEmDI!='0': rXLaWluDjvi4xMwpOSF91JB7 = rXLaWluDjvi4xMwpOSF91JB7+'&'+key+'='+AARNPWHjQU9dEmDI
		elif mode=='all': rXLaWluDjvi4xMwpOSF91JB7 = rXLaWluDjvi4xMwpOSF91JB7+'&'+key+'='+AARNPWHjQU9dEmDI
	rXLaWluDjvi4xMwpOSF91JB7 = rXLaWluDjvi4xMwpOSF91JB7.strip(' + ')
	rXLaWluDjvi4xMwpOSF91JB7 = rXLaWluDjvi4xMwpOSF91JB7.strip('&')
	rXLaWluDjvi4xMwpOSF91JB7 = rXLaWluDjvi4xMwpOSF91JB7.replace('=0','=')
	rXLaWluDjvi4xMwpOSF91JB7 = rXLaWluDjvi4xMwpOSF91JB7.replace('Quality','quality')
	return rXLaWluDjvi4xMwpOSF91JB7