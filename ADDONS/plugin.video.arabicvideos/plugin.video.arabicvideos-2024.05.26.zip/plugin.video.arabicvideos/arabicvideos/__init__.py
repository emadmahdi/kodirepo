# -*- coding: utf-8 -*-
import sys as ddABnr3K9Xv8e71CzcN0Pxt
NLQaPokgt7Zi = ddABnr3K9Xv8e71CzcN0Pxt.version_info [0] == 2
QzcRNkipwA1WPJu6ZoTnxrjBlqe2 = 2048
Y07K8pBzWtXncO9rUdsw1MTgAyFS = 7
def pFM6HfGd7Urbxto45vSNLniWA (gKVwro2lTJQEp):
	global AUQrTjaXt8K
	UUhFMplXo8RaCwxnEz5Hm7r = ord (gKVwro2lTJQEp [-1])
	slDu7whZzrU2b3oCYREig1L65F9HK = gKVwro2lTJQEp [:-1]
	Ha7jrvByPJYSIiRoXm5ThCOWc = UUhFMplXo8RaCwxnEz5Hm7r % len (slDu7whZzrU2b3oCYREig1L65F9HK)
	E5JVTBFqvjCN2Sc = slDu7whZzrU2b3oCYREig1L65F9HK [:Ha7jrvByPJYSIiRoXm5ThCOWc] + slDu7whZzrU2b3oCYREig1L65F9HK [Ha7jrvByPJYSIiRoXm5ThCOWc:]
	if NLQaPokgt7Zi:
		lK9D8U71rY = unicode () .join ([unichr (ord (ysjIJ8PTAQv5copxFkLUXrRwf) - QzcRNkipwA1WPJu6ZoTnxrjBlqe2 - (WutIpGj5YChbO + UUhFMplXo8RaCwxnEz5Hm7r) % Y07K8pBzWtXncO9rUdsw1MTgAyFS) for WutIpGj5YChbO, ysjIJ8PTAQv5copxFkLUXrRwf in enumerate (E5JVTBFqvjCN2Sc)])
	else:
		lK9D8U71rY = str () .join ([chr (ord (ysjIJ8PTAQv5copxFkLUXrRwf) - QzcRNkipwA1WPJu6ZoTnxrjBlqe2 - (WutIpGj5YChbO + UUhFMplXo8RaCwxnEz5Hm7r) % Y07K8pBzWtXncO9rUdsw1MTgAyFS) for WutIpGj5YChbO, ysjIJ8PTAQv5copxFkLUXrRwf in enumerate (E5JVTBFqvjCN2Sc)])
	return eval (lK9D8U71rY)
OVmSuf8tpd,LmcNhzY6fQPd2JyCGslkSr,J3OCAmZVcn=pFM6HfGd7Urbxto45vSNLniWA,pFM6HfGd7Urbxto45vSNLniWA,pFM6HfGd7Urbxto45vSNLniWA
eeIL1TfgFQJaKqVD8hGNPEZ,aFQoGfmYKyqLU6X8libw9k3ncW5,m6b7CoBk4EQ=J3OCAmZVcn,LmcNhzY6fQPd2JyCGslkSr,OVmSuf8tpd
ZSJVq5XDrRot,yTMWeCgUROcvtsblfK85L62xPk,AAgpHN0nMZ=m6b7CoBk4EQ,aFQoGfmYKyqLU6X8libw9k3ncW5,eeIL1TfgFQJaKqVD8hGNPEZ
XogUJZEijT7KWbxeO6,FhcnOB9t3frzvXb,aVLSn1xw5cK=AAgpHN0nMZ,yTMWeCgUROcvtsblfK85L62xPk,ZSJVq5XDrRot
ffCSGrTJYPsxgVQWKLtHU3iMwB,EDPaWgMt1SwNn8o,PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg=aVLSn1xw5cK,FhcnOB9t3frzvXb,XogUJZEijT7KWbxeO6
Ej67fFyoqW8kbV2HdSK,kmdSKeBIwViM9t3,fR68jBGWCzUsFXdlTKPOScugm=PPAVGxsHp3vMBrFt8dh1bJ0LzmlYg,EDPaWgMt1SwNn8o,ffCSGrTJYPsxgVQWKLtHU3iMwB
bdhQDyjm3nPwToFHkprvCzBLUGR,JcDaEHuiS8TqBbOhWe4ZgwknoC1L3r,wwyUWMFAsO=fR68jBGWCzUsFXdlTKPOScugm,kmdSKeBIwViM9t3,Ej67fFyoqW8kbV2HdSK
kRYWcNuAazr4jtmBoxFVS19Z6,pEo8g7riWVL014KaRtzQ,sArCMRngQNmXkBoKv=wwyUWMFAsO,JcDaEHuiS8TqBbOhWe4ZgwknoC1L3r,bdhQDyjm3nPwToFHkprvCzBLUGR
JMLhEyaBWmskovGHTrVCxQ08,MM2BQ7xrAfNivgenXPytGYOs0DEHRC,hjNP5w9srJz2QpVISxBfndbD4CkXvl=sArCMRngQNmXkBoKv,pEo8g7riWVL014KaRtzQ,kRYWcNuAazr4jtmBoxFVS19Z6
xuYvdJpOEyQKTLNwb,jYaM5vilgZdFx6QHbApwVXO8et,DLSVmlyBbCK=hjNP5w9srJz2QpVISxBfndbD4CkXvl,MM2BQ7xrAfNivgenXPytGYOs0DEHRC,JMLhEyaBWmskovGHTrVCxQ08
gnfv8UtZ3daGqpjzk,gSmqZU0plur2xKPJwQA,c4QSTnPiWUCjhrLlwGB=DLSVmlyBbCK,jYaM5vilgZdFx6QHbApwVXO8et,xuYvdJpOEyQKTLNwb
from xcH7j3ButC import *
ll6f2wvU4FdqL3MJyDxORESCK197i = aFQoGfmYKyqLU6X8libw9k3ncW5(u"ࠩࡌࡒࡎ࡚ࠧᚭ")
tr24ZoudmqvxfYCw(fR68jBGWCzUsFXdlTKPOScugm(u"ࠪࡒࡔ࡚ࡉࡄࡇࠪᚮ"),pEo8g7riWVL014KaRtzQ(u"ࠫࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠫᚯ"))
m6egkRrjcavHEdwYDSOs,vABVTz0qOd1anSJ3D,XpOsU3v5dqH8MQAK6FcafmP1z0kL2,knu9Y0BX6ErPRJWT13A5o,ttiasLcTXGvgqb41nC7DRF,wwNtFTLK2IqAszYBDV9J,unjzvHfWpPTbqACy9RtOY6m,UISsAqZ5MGpEvJntk2N0LgbFuzHTK6,B0BjfWuVKkht7gPaNqFsTJOdcHbw = q0tgURwzEOJIYc27DbG4aT(VPIEsaiROZwmp20Jdn8WrA7c3Y)
ewfcdr7BUIRb1FE9htzSONsKo4gVjD = int(knu9Y0BX6ErPRJWT13A5o)
W5V6oRmIDCvcMGBQU = cPwDBuG4HVTCdQ9JmMeoWjNY2hX.getInfoLabel(aFQoGfmYKyqLU6X8libw9k3ncW5(u"ࠬࡒࡩࡴࡶࡌࡸࡪࡳ࠮ࡍࡣࡥࡩࡱ࠭ᚰ"))
W5V6oRmIDCvcMGBQU = W5V6oRmIDCvcMGBQU.replace(llDwesm6h4YkuLBCKQE8W0JIORoFS,AAgpHN0nMZ(u"࠭ࠧᚱ")).replace(PGLUYu7ySB5gD8b4ZJQq,kRYWcNuAazr4jtmBoxFVS19Z6(u"ࠧࠨᚲ"))
if ewfcdr7BUIRb1FE9htzSONsKo4gVjD==LmcNhzY6fQPd2JyCGslkSr(u"࠵࠺࠵ᛦ"): d0Z7abLoEfmpHTOkgVG = FhcnOB9t3frzvXb(u"ࠨࠢࠣࠤ࡛࡫ࡲࡴ࡫ࡲࡲ࠿࡛ࠦࠡࠩᚳ")+i69DxzEZSwmuY5Il+JMLhEyaBWmskovGHTrVCxQ08(u"ࠩࠣࡡࠥࠦࠠࡌࡱࡧ࡭࠿࡛ࠦࠡࠩᚴ")+RDroKU08JGFn53dsguECSkYTW1+JMLhEyaBWmskovGHTrVCxQ08(u"ࠪࠤࡢ࠭ᚵ")
else:
	coSwnYEDrU = ejBOu2WXwvb4YpITdsLF16(VPIEsaiROZwmp20Jdn8WrA7c3Y).replace(XogUJZEijT7KWbxeO6(u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠧᚶ"),kRYWcNuAazr4jtmBoxFVS19Z6(u"ࠬ࠭ᚷ")).replace(JcDaEHuiS8TqBbOhWe4ZgwknoC1L3r(u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡈࡉࡊࡋ࠶࠰࡞ࠩᚸ"),wwyUWMFAsO(u"ࠧࠨᚹ"))
	coSwnYEDrU = coSwnYEDrU.replace(kRYWcNuAazr4jtmBoxFVS19Z6(u"ࠨ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪᚺ"),hjNP5w9srJz2QpVISxBfndbD4CkXvl(u"ࠩࠪᚻ")).strip(DLSVmlyBbCK(u"ࠪࠤࠬᚼ"))
	coSwnYEDrU = coSwnYEDrU.replace(bdhQDyjm3nPwToFHkprvCzBLUGR(u"ࠫࠥࠦࠠࠡࠩᚽ"),eeIL1TfgFQJaKqVD8hGNPEZ(u"ࠬࠦࠧᚾ")).replace(pEo8g7riWVL014KaRtzQ(u"࠭ࠠࠡࠢࠪᚿ"),aFQoGfmYKyqLU6X8libw9k3ncW5(u"ࠧࠡࠩᛀ")).replace(gSmqZU0plur2xKPJwQA(u"ࠨࠢࠣࠫᛁ"),gSmqZU0plur2xKPJwQA(u"ࠩࠣࠫᛂ"))
	d0Z7abLoEfmpHTOkgVG = c4QSTnPiWUCjhrLlwGB(u"ࠪࠤࠥࠦࡌࡢࡤࡨࡰ࠿࡛ࠦࠡࠩᛃ")+W5V6oRmIDCvcMGBQU+c4QSTnPiWUCjhrLlwGB(u"ࠫࠥࡣࠠࠡࠢࡐࡳࡩ࡫࠺ࠡ࡝ࠣࠫᛄ")+knu9Y0BX6ErPRJWT13A5o+AAgpHN0nMZ(u"ࠬࠦ࡝ࠡࠢࠣࡔࡦࡺࡨ࠻ࠢ࡞ࠤࠬᛅ")+coSwnYEDrU+kRYWcNuAazr4jtmBoxFVS19Z6(u"࠭ࠠ࡞ࠩᛆ")
tr24ZoudmqvxfYCw(pEo8g7riWVL014KaRtzQ(u"ࠧࡏࡑࡗࡍࡈࡋࠧᛇ"),RGSFZ7ls3nO(ll6f2wvU4FdqL3MJyDxORESCK197i)+d0Z7abLoEfmpHTOkgVG)
if wwyUWMFAsO(u"ࠨࡡࠪᛈ") in UISsAqZ5MGpEvJntk2N0LgbFuzHTK6: TnXLWxs5MD6FY1Ktwfl2kQuVASdhZ9,RGivP87NcYKdw = UISsAqZ5MGpEvJntk2N0LgbFuzHTK6.split(gnfv8UtZ3daGqpjzk(u"ࠩࡢࠫᛉ"),wwyUWMFAsO(u"࠵ᛧ"))
else: TnXLWxs5MD6FY1Ktwfl2kQuVASdhZ9,RGivP87NcYKdw = UISsAqZ5MGpEvJntk2N0LgbFuzHTK6,fR68jBGWCzUsFXdlTKPOScugm(u"ࠪࠫᛊ")
if TnXLWxs5MD6FY1Ktwfl2kQuVASdhZ9 in [eeIL1TfgFQJaKqVD8hGNPEZ(u"ࠫ࠶࠭ᛋ"),eeIL1TfgFQJaKqVD8hGNPEZ(u"ࠬ࠸ࠧᛌ"),AAgpHN0nMZ(u"࠭࠳ࠨᛍ"),J3OCAmZVcn(u"ࠧ࠵ࠩᛎ"),gSmqZU0plur2xKPJwQA(u"ࠨ࠷ࠪᛏ")] and (FhcnOB9t3frzvXb(u"ࠩࡄࡈࡉ࠭ᛐ") in RGivP87NcYKdw or JMLhEyaBWmskovGHTrVCxQ08(u"ࠪࡖࡊࡓࡏࡗࡇࠪᛑ") in RGivP87NcYKdw or gnfv8UtZ3daGqpjzk(u"࡚ࠫࡖࠧᛒ") in RGivP87NcYKdw or pEo8g7riWVL014KaRtzQ(u"ࠬࡊࡏࡘࡐࠪᛓ") in RGivP87NcYKdw):
	from bepC1A2Yfo import hhUnvQ52jmRlVGxcyeK38NagAFI
	hhUnvQ52jmRlVGxcyeK38NagAFI(UISsAqZ5MGpEvJntk2N0LgbFuzHTK6,TnXLWxs5MD6FY1Ktwfl2kQuVASdhZ9,RGivP87NcYKdw)
	j2agIU0xsLS6c7T.setSetting(gnfv8UtZ3daGqpjzk(u"࠭ࡡࡷ࠰ࡶࡸࡦࡺࡵࡴ࠰ࡵࡩ࡫ࡸࡥࡴࡪࠪᛔ"),VPIEsaiROZwmp20Jdn8WrA7c3Y)
	cPwDBuG4HVTCdQ9JmMeoWjNY2hX.executebuiltin(yTMWeCgUROcvtsblfK85L62xPk(u"ࠧࡄࡱࡱࡸࡦ࡯࡮ࡦࡴ࠱ࡖࡪ࡬ࡲࡦࡵ࡫ࠫᛕ"))
elif not nc1u5UZAtX2WNO4aJMmbg and ewfcdr7BUIRb1FE9htzSONsKo4gVjD in [c4QSTnPiWUCjhrLlwGB(u"࠷࠹࠵ᛨ"),pEo8g7riWVL014KaRtzQ(u"࠽࠱࠶ᛩ")]:
	koJDb5cLtesTaQ1OM = str(B0BjfWuVKkht7gPaNqFsTJOdcHbw[OVmSuf8tpd(u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᛖ")])
	ll6f2wvU4FdqL3MJyDxORESCK197i = kmdSKeBIwViM9t3(u"ࠩࡌࡔ࡙࡜ࠧᛗ") if ewfcdr7BUIRb1FE9htzSONsKo4gVjD==pEo8g7riWVL014KaRtzQ(u"࠲࠴࠷ᛪ") else hjNP5w9srJz2QpVISxBfndbD4CkXvl(u"ࠪࡑ࠸࡛ࠧᛘ")
	PIfZqiV64covr2kBFR = ll6f2wvU4FdqL3MJyDxORESCK197i.lower()
	k0kUAjI76Erhgf = j2agIU0xsLS6c7T.getSetting(gnfv8UtZ3daGqpjzk(u"ࠫࡦࡼ࠮ࠨᛙ")+PIfZqiV64covr2kBFR+yTMWeCgUROcvtsblfK85L62xPk(u"ࠬ࠴ࡵࡴࡧࡵࡥ࡬࡫࡮ࡵࡡࠪᛚ")+koJDb5cLtesTaQ1OM)
	qBKDxcalp4QdXitguWhSHwo2Zy9E = j2agIU0xsLS6c7T.getSetting(AAgpHN0nMZ(u"࠭ࡡࡷ࠰ࠪᛛ")+PIfZqiV64covr2kBFR+ffCSGrTJYPsxgVQWKLtHU3iMwB(u"ࠧ࠯ࡴࡨࡪࡪࡸࡥࡳࡡࠪᛜ")+koJDb5cLtesTaQ1OM)
	if k0kUAjI76Erhgf or qBKDxcalp4QdXitguWhSHwo2Zy9E:
		XpOsU3v5dqH8MQAK6FcafmP1z0kL2 += Ej67fFyoqW8kbV2HdSK(u"ࠨࡾࠪᛝ")
		if k0kUAjI76Erhgf: XpOsU3v5dqH8MQAK6FcafmP1z0kL2 += ffCSGrTJYPsxgVQWKLtHU3iMwB(u"࡙ࠩࠩࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺ࠽ࠨᛞ")+k0kUAjI76Erhgf
		if qBKDxcalp4QdXitguWhSHwo2Zy9E: XpOsU3v5dqH8MQAK6FcafmP1z0kL2 += xuYvdJpOEyQKTLNwb(u"ࠪࠪࡗ࡫ࡦࡦࡴࡨࡶࡂ࠭ᛟ")+qBKDxcalp4QdXitguWhSHwo2Zy9E
		XpOsU3v5dqH8MQAK6FcafmP1z0kL2 = XpOsU3v5dqH8MQAK6FcafmP1z0kL2.replace(AAgpHN0nMZ(u"ࠫࢁࠬࠧᛠ"),jYaM5vilgZdFx6QHbApwVXO8et(u"ࠬࢂࠧᛡ"))
	gvZ1turOciIPpx = j2agIU0xsLS6c7T.getSetting(LmcNhzY6fQPd2JyCGslkSr(u"࠭ࡡࡷ࠰ࠪᛢ")+PIfZqiV64covr2kBFR+Ej67fFyoqW8kbV2HdSK(u"ࠧ࠯ࡵࡨࡶࡻ࡫ࡲࡠࠩᛣ")+koJDb5cLtesTaQ1OM)
	if gvZ1turOciIPpx:
		zLNSEwInye96PtoKk3 = ZXFs0mEPR8qI2zj.findall(XogUJZEijT7KWbxeO6(u"ࠨ࠼࠲࠳࠭࠴ࠪࡀࠫ࠲ࠫᛤ"),XpOsU3v5dqH8MQAK6FcafmP1z0kL2,ZXFs0mEPR8qI2zj.DOTALL)
		XpOsU3v5dqH8MQAK6FcafmP1z0kL2 = XpOsU3v5dqH8MQAK6FcafmP1z0kL2.replace(zLNSEwInye96PtoKk3[eeIL1TfgFQJaKqVD8hGNPEZ(u"࠱᛫")],gvZ1turOciIPpx)
	w3hq0Xp8D9rZJ(XpOsU3v5dqH8MQAK6FcafmP1z0kL2,ll6f2wvU4FdqL3MJyDxORESCK197i,m6egkRrjcavHEdwYDSOs)
else:
	qDBsizKL2w = NiOkerpvwHXxLGR1Yy9um(vABVTz0qOd1anSJ3D)
	import j3x780FpaM
	m0AGWhywZVXFtYQ = eeIL1TfgFQJaKqVD8hGNPEZ(u"ࠩࠪᛥ")
	try: j3x780FpaM.f3fo8AlmKQH9e6IJ451dr(m6egkRrjcavHEdwYDSOs,vABVTz0qOd1anSJ3D,XpOsU3v5dqH8MQAK6FcafmP1z0kL2,knu9Y0BX6ErPRJWT13A5o,ttiasLcTXGvgqb41nC7DRF,wwNtFTLK2IqAszYBDV9J,unjzvHfWpPTbqACy9RtOY6m,UISsAqZ5MGpEvJntk2N0LgbFuzHTK6,B0BjfWuVKkht7gPaNqFsTJOdcHbw,qDBsizKL2w,ewfcdr7BUIRb1FE9htzSONsKo4gVjD,TnXLWxs5MD6FY1Ktwfl2kQuVASdhZ9,RGivP87NcYKdw,W5V6oRmIDCvcMGBQU)
	except Exception as KB1kx0UPF7: m0AGWhywZVXFtYQ = QQV1pDhCLqHP5a3sGvoUrJfmjXFw.format_exc()
	j3x780FpaM.Uzk5El62NdFj(m0AGWhywZVXFtYQ)