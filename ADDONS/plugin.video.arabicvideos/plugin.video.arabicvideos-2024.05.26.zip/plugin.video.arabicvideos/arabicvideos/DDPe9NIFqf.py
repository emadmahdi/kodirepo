# -*- coding: utf-8 -*-
from j3x780FpaM import *
ll6f2wvU4FdqL3MJyDxORESCK197i = 'LIVETV'
JJTrn6SEtYZV31eyR97 = uReHcEzxkTm6pN4Q['PYTHON'][0]
def OVQIAezo6U1NSTl4L(mode,url):
	if   mode==100: HkKfQCS7RIa4xi3houjvl = oMUN5hPpTkxVZG12Qiva8BKnyw6()
	elif mode==101: HkKfQCS7RIa4xi3houjvl = J2K0qdYZMhG('0',True)
	elif mode==102: HkKfQCS7RIa4xi3houjvl = J2K0qdYZMhG('1',True)
	elif mode==103: HkKfQCS7RIa4xi3houjvl = J2K0qdYZMhG('2',True)
	elif mode==104: HkKfQCS7RIa4xi3houjvl = J2K0qdYZMhG('3',True)
	elif mode==105: HkKfQCS7RIa4xi3houjvl = jXYwiO9D056pkrzRh1y8tfWJxQoaI3(url)
	elif mode==106: HkKfQCS7RIa4xi3houjvl = J2K0qdYZMhG('4',True)
	else: HkKfQCS7RIa4xi3houjvl = False
	return HkKfQCS7RIa4xi3houjvl
def oMUN5hPpTkxVZG12Qiva8BKnyw6():
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder','_M3U_'+'قوائم فيديوهات M3U','',762)
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder','_IPT_'+'قوائم فيديوهات IPTV','',761)
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder','_TV0_'+'قنوات من مواقعها الأصلية','',101)
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder','_TV4_'+'قنوات مختارة من يوتيوب','',106)
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder','_YUT_'+'قنوات عربية من يوتيوب','',147)
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder','_YUT_'+'قنوات أجنبية من يوتيوب','',148)
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder','_IFL_'+'  قناة آي فيلم من موقعهم  ','',28)
	Tca7NsYPkIRWtBpFgxLZbSmCi('live','_MRF_'+'قناة المعارف من موقعهم','',41)
	Tca7NsYPkIRWtBpFgxLZbSmCi('live','_PNT_'+'قناة هلا من موقع بانيت','',38)
	Tca7NsYPkIRWtBpFgxLZbSmCi('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder','_TV1_'+'قنوات تلفزيونية عامة','',102)
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder','_TV2_'+'قنوات تلفزيونية خاصة','',103)
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder','_TV3_'+'قنوات تلفزيونية للفحص','',104)
	return
def J2K0qdYZMhG(Iwo3ZzUA69btP5g21r,showDialogs=True):
	W74fAyGxODoLPs5vMX2l8C93R = '_TV'+Iwo3ZzUA69btP5g21r+'_'
	hhC9JITqv3yWEGFm = HHWAnGJrb9powOqTkYgcPQ6Ef(32)
	VbZ1Pig043uIGYQ = {'id':'','user':hhC9JITqv3yWEGFm,'function':'list','menu':Iwo3ZzUA69btP5g21r}
	wpFmEA3z8JR = A6F71g3cqN4(dALVaOWB4jKN3Tbt0Cm1ns9k5u,'POST',JJTrn6SEtYZV31eyR97,VbZ1Pig043uIGYQ,'','','','LIVETV-ITEMS-1st')
	QstumvzTIEUMXCcx06aD4y8nSqH = wpFmEA3z8JR.content
	items = ZXFs0mEPR8qI2zj.findall('([^;\r\n]+?);;(.*?);;(.*?);;(.*?);;(.*?);;',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	if items:
		for xxFhvt275i8MdUVuPkSXzmbT in range(len(items)):
			name = items[xxFhvt275i8MdUVuPkSXzmbT][3]
			start = name[0:2]
			start = start.replace('al','Al')
			start = start.replace('El','Al')
			start = start.replace('AL','Al')
			start = start.replace('EL','Al')
			name = start+name[2:]
			start = name[0:3]
			start = start.replace('Al-','Al')
			start = start.replace('Al ','Al')
			name = start+name[3:]
			items[xxFhvt275i8MdUVuPkSXzmbT] = items[xxFhvt275i8MdUVuPkSXzmbT][0],items[xxFhvt275i8MdUVuPkSXzmbT][1],items[xxFhvt275i8MdUVuPkSXzmbT][2],name,items[xxFhvt275i8MdUVuPkSXzmbT][4]
		items = set(items)
		items = sorted(items, reverse=False, key=lambda key: key[0].lower())
		items = sorted(items, reverse=False, key=lambda key: key[3].lower())
		for j5jMXZ7myEuoLG,NGmuWwXdLQ6nMltx39FYECohJ,yfZpUog0Rbs8CFEv9,name,CrGO63LT7j2UxniW in items:
			if '#' in j5jMXZ7myEuoLG: continue
			if j5jMXZ7myEuoLG!='URL': name = name+'[COLOR FFC89008]   '+j5jMXZ7myEuoLG+'[/COLOR]'
			url = j5jMXZ7myEuoLG+';;'+NGmuWwXdLQ6nMltx39FYECohJ+';;'+yfZpUog0Rbs8CFEv9+';;'+Iwo3ZzUA69btP5g21r
			Tca7NsYPkIRWtBpFgxLZbSmCi('live',W74fAyGxODoLPs5vMX2l8C93R+''+name,url,105,CrGO63LT7j2UxniW)
	else:
		if showDialogs: Tca7NsYPkIRWtBpFgxLZbSmCi('link',W74fAyGxODoLPs5vMX2l8C93R+'هذه الخدمة مخصصة للمبرمج فقط','',9999)
	return
def jXYwiO9D056pkrzRh1y8tfWJxQoaI3(id):
	j5jMXZ7myEuoLG,NGmuWwXdLQ6nMltx39FYECohJ,yfZpUog0Rbs8CFEv9,Iwo3ZzUA69btP5g21r = id.split(';;')
	url = ''
	hhC9JITqv3yWEGFm = HHWAnGJrb9powOqTkYgcPQ6Ef(32)
	if j5jMXZ7myEuoLG=='URL': url = yfZpUog0Rbs8CFEv9
	elif j5jMXZ7myEuoLG=='YOUTUBE':
		url = uReHcEzxkTm6pN4Q['YOUTUBE'][0]+'/watch?v='+yfZpUog0Rbs8CFEv9
		import fnxsZbk2Fm
		fnxsZbk2Fm.n2h4SBIzxbgJD3K7rtVej01EuGcHPs([url],ll6f2wvU4FdqL3MJyDxORESCK197i,'live',url)
		return
	elif j5jMXZ7myEuoLG=='GA':
		VbZ1Pig043uIGYQ = { 'id' : '', 'user' : hhC9JITqv3yWEGFm , 'function' : 'playGA1' , 'menu' : '' }
		wpFmEA3z8JR = A6F71g3cqN4(dALVaOWB4jKN3Tbt0Cm1ns9k5u,'GET',JJTrn6SEtYZV31eyR97,VbZ1Pig043uIGYQ,'',False,'','LIVETV-PLAY-1st')
		if not wpFmEA3z8JR.succeeded:
			HHTzVhiY079bvdluNkFQ4wCMpe('','','رسالة من المبرمج','هذه الخدمة مخصصة للمبرمج فقط')
			return
		QstumvzTIEUMXCcx06aD4y8nSqH = wpFmEA3z8JR.content
		cookies = wpFmEA3z8JR.cookies
		lf0Dq16LtMnpobaKyc = cookies['ASP.NET_SessionId']
		url = wpFmEA3z8JR.headers['Location']
		VbZ1Pig043uIGYQ = { 'id' : yfZpUog0Rbs8CFEv9 , 'user' : hhC9JITqv3yWEGFm , 'function' : 'playGA2' , 'menu' : '' }
		headers = { 'Cookie' : 'ASP.NET_SessionId='+lf0Dq16LtMnpobaKyc }
		wpFmEA3z8JR = A6F71g3cqN4(dALVaOWB4jKN3Tbt0Cm1ns9k5u,'GET',JJTrn6SEtYZV31eyR97,VbZ1Pig043uIGYQ,headers,'','','LIVETV-PLAY-2nd')
		if not wpFmEA3z8JR.succeeded:
			HHTzVhiY079bvdluNkFQ4wCMpe('','','رسالة من المبرمج','هذه الخدمة مخصصة للمبرمج فقط')
			return
		QstumvzTIEUMXCcx06aD4y8nSqH = wpFmEA3z8JR.content
		url = ZXFs0mEPR8qI2zj.findall('resp":"(http.*?m3u8)(.*?)"',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
		RRucmYBaXegTtNOdGHMQ = url[0][0]
		s8nZN31lf7OUr2J = url[0][1]
		ieOG95YjPCboKsu8DJBZ = 'http://38.'+NGmuWwXdLQ6nMltx39FYECohJ+'777/'+yfZpUog0Rbs8CFEv9+'_HD.m3u8'+s8nZN31lf7OUr2J
		Oo1Wswl8LdR2yc6m7SuArXGEk0zDh = ieOG95YjPCboKsu8DJBZ.replace('36:7','40:7').replace('_HD.m3u8','.m3u8')
		mMTIriVb0Ba = ieOG95YjPCboKsu8DJBZ.replace('36:7','42:7').replace('_HD.m3u8','.m3u8')
		xCLQK8kh39sjyi5DXSZAVeI = ['HD','SD1','SD2']
		YYmyQXglbEewzL3IA2Sd = [ieOG95YjPCboKsu8DJBZ,Oo1Wswl8LdR2yc6m7SuArXGEk0zDh,mMTIriVb0Ba]
		jQ6w8xOrgYhSHIRpUqzL = 0
		if jQ6w8xOrgYhSHIRpUqzL == -1: return
		else: url = YYmyQXglbEewzL3IA2Sd[jQ6w8xOrgYhSHIRpUqzL]
	elif j5jMXZ7myEuoLG=='NT':
		headers = { 'Content-Type' : 'application/x-www-form-urlencoded' }
		VbZ1Pig043uIGYQ = { 'id' : yfZpUog0Rbs8CFEv9 , 'user' : hhC9JITqv3yWEGFm , 'function' : 'playNT' , 'menu' : Iwo3ZzUA69btP5g21r }
		wpFmEA3z8JR = A6F71g3cqN4(dALVaOWB4jKN3Tbt0Cm1ns9k5u,'POST', JJTrn6SEtYZV31eyR97, VbZ1Pig043uIGYQ, headers, False,'','LIVETV-PLAY-3rd')
		if not wpFmEA3z8JR.succeeded:
			HHTzVhiY079bvdluNkFQ4wCMpe('','','رسالة من المبرمج','هذه الخدمة مخصصة للمبرمج فقط')
			return
		QstumvzTIEUMXCcx06aD4y8nSqH = wpFmEA3z8JR.content
		url = wpFmEA3z8JR.headers['Location']
		url = url.replace('%20',' ')
		url = url.replace('%3D','=')
		if 'Learn' in yfZpUog0Rbs8CFEv9:
			url = url.replace('NTNNile','')
			url = url.replace('learning1','Learning')
	elif j5jMXZ7myEuoLG=='PL':
		VbZ1Pig043uIGYQ = { 'id' : yfZpUog0Rbs8CFEv9 , 'user' : hhC9JITqv3yWEGFm , 'function' : 'playPL' , 'menu' : Iwo3ZzUA69btP5g21r }
		wpFmEA3z8JR = A6F71g3cqN4(dALVaOWB4jKN3Tbt0Cm1ns9k5u,'POST', JJTrn6SEtYZV31eyR97, VbZ1Pig043uIGYQ, '',False,'','LIVETV-PLAY-4th')
		if not wpFmEA3z8JR.succeeded:
			HHTzVhiY079bvdluNkFQ4wCMpe('','','رسالة من المبرمج','هذه الخدمة مخصصة للمبرمج فقط')
			return
		QstumvzTIEUMXCcx06aD4y8nSqH = wpFmEA3z8JR.content
		url = wpFmEA3z8JR.headers['Location']
		headers = {'Referer':wpFmEA3z8JR.headers['Referer']}
		wpFmEA3z8JR = A6F71g3cqN4(KxirmCLT6Gw,'POST',url, '',headers , '','','LIVETV-PLAY-5th')
		if not wpFmEA3z8JR.succeeded:
			HHTzVhiY079bvdluNkFQ4wCMpe('','','رسالة من المبرمج','هذه الخدمة مخصصة للمبرمج فقط')
			return
		QstumvzTIEUMXCcx06aD4y8nSqH = wpFmEA3z8JR.content
		items = ZXFs0mEPR8qI2zj.findall('source src="(.*?)"',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
		url = items[0]
	elif j5jMXZ7myEuoLG in ['TA','FM','YU','WS1','WS2','RL1','RL2']:
		if j5jMXZ7myEuoLG=='TA': yfZpUog0Rbs8CFEv9 = id
		headers = { 'Content-Type' : 'application/x-www-form-urlencoded' }
		VbZ1Pig043uIGYQ = { 'id' : yfZpUog0Rbs8CFEv9 , 'user' : hhC9JITqv3yWEGFm , 'function' : 'play'+j5jMXZ7myEuoLG , 'menu' : Iwo3ZzUA69btP5g21r }
		wpFmEA3z8JR = A6F71g3cqN4(dALVaOWB4jKN3Tbt0Cm1ns9k5u,'POST',JJTrn6SEtYZV31eyR97,VbZ1Pig043uIGYQ,headers,'','','LIVETV-PLAY-6th')
		if not wpFmEA3z8JR.succeeded:
			HHTzVhiY079bvdluNkFQ4wCMpe('','','رسالة من المبرمج','هذه الخدمة مخصصة للمبرمج فقط')
			return
		QstumvzTIEUMXCcx06aD4y8nSqH = wpFmEA3z8JR.content
		url = wpFmEA3z8JR.headers['Location']
		if j5jMXZ7myEuoLG=='FM':
			wpFmEA3z8JR = A6F71g3cqN4(KxirmCLT6Gw,'GET', url, '', '', False,'','LIVETV-PLAY-7th')
			url = wpFmEA3z8JR.headers['Location']
			url = url.replace('https','http')
	w3hq0Xp8D9rZJ(url,ll6f2wvU4FdqL3MJyDxORESCK197i,'live')
	return