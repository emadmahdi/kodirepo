# -*- coding: utf-8 -*-
from j3x780FpaM import *
ll6f2wvU4FdqL3MJyDxORESCK197i = 'ALARAB'
headers = {'User-Agent':''}
W74fAyGxODoLPs5vMX2l8C93R = '_KLA_'
JJTrn6SEtYZV31eyR97 = uReHcEzxkTm6pN4Q[ll6f2wvU4FdqL3MJyDxORESCK197i][0]
def OVQIAezo6U1NSTl4L(mode,url,text):
	if   mode==10: HkKfQCS7RIa4xi3houjvl = oMUN5hPpTkxVZG12Qiva8BKnyw6()
	elif mode==11: HkKfQCS7RIa4xi3houjvl = RxAy5lEFQ1chv0BrdU4p6Pt2(url)
	elif mode==12: HkKfQCS7RIa4xi3houjvl = jXYwiO9D056pkrzRh1y8tfWJxQoaI3(url)
	elif mode==13: HkKfQCS7RIa4xi3houjvl = pqx0gStI9ojGFP2rWhwRfkVCNX(url)
	elif mode==14: HkKfQCS7RIa4xi3houjvl = vyM5CbgVYS()
	elif mode==15: HkKfQCS7RIa4xi3houjvl = QgOjcaeKvptBJ70fFNEoV9W1wSLMD()
	elif mode==16: HkKfQCS7RIa4xi3houjvl = EoR08gLBFy()
	elif mode==19: HkKfQCS7RIa4xi3houjvl = F6OgHwYPRiX10tJEv8r(text)
	else: HkKfQCS7RIa4xi3houjvl = False
	return HkKfQCS7RIa4xi3houjvl
def oMUN5hPpTkxVZG12Qiva8BKnyw6():
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+'بحث في الموقع','',19,'','','_REMEMBERRESULTS_')
	Tca7NsYPkIRWtBpFgxLZbSmCi('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder',ll6f2wvU4FdqL3MJyDxORESCK197i+'_SCRIPT_'+W74fAyGxODoLPs5vMX2l8C93R+'آخر الإضافات','',14)
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder',ll6f2wvU4FdqL3MJyDxORESCK197i+'_SCRIPT_'+W74fAyGxODoLPs5vMX2l8C93R+'مسلسلات رمضان','',15)
	QstumvzTIEUMXCcx06aD4y8nSqH = QuWA3hsmIvockZDiy2rLg(JNsoWV1CXc4xy,JJTrn6SEtYZV31eyR97,'',headers,'','ALARAB-MENU-1st')
	IZGcQbePXxwAoyYR1n=ZXFs0mEPR8qI2zj.findall('id="nav-slider"(.*?)</div>',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	prYhL5s8zHG14qjgwtCTXbdf0en = IZGcQbePXxwAoyYR1n[0]
	items = ZXFs0mEPR8qI2zj.findall('href="(.*?)".*?>(.*?)<',prYhL5s8zHG14qjgwtCTXbdf0en,ZXFs0mEPR8qI2zj.DOTALL)
	for RRucmYBaXegTtNOdGHMQ,title in items:
		RRucmYBaXegTtNOdGHMQ = JJTrn6SEtYZV31eyR97+RRucmYBaXegTtNOdGHMQ
		title = title.strip(' ')
		Tca7NsYPkIRWtBpFgxLZbSmCi('folder',ll6f2wvU4FdqL3MJyDxORESCK197i+'_SCRIPT_'+W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,11)
	Tca7NsYPkIRWtBpFgxLZbSmCi('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('id="navbar"(.*?)</div>',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	i9jtofq4JrV = IZGcQbePXxwAoyYR1n[0]
	items = ZXFs0mEPR8qI2zj.findall('href="(.*?)".*?>(.*?)<',i9jtofq4JrV,ZXFs0mEPR8qI2zj.DOTALL)
	for RRucmYBaXegTtNOdGHMQ,title in items:
		RRucmYBaXegTtNOdGHMQ = JJTrn6SEtYZV31eyR97+RRucmYBaXegTtNOdGHMQ
		Tca7NsYPkIRWtBpFgxLZbSmCi('folder',ll6f2wvU4FdqL3MJyDxORESCK197i+'_SCRIPT_'+W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,11)
	return QstumvzTIEUMXCcx06aD4y8nSqH
def QgOjcaeKvptBJ70fFNEoV9W1wSLMD():
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+'جميع المسلسلات العربية',JJTrn6SEtYZV31eyR97+'/view-8/مسلسلات-عربية',11)
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+'مسلسلات السنة الأخيرة','',16)
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+'مسلسلات رمضان الأخيرة 1',JJTrn6SEtYZV31eyR97+'/view-8/مسلسلات-رمضان-2022',11)
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+'مسلسلات رمضان الأخيرة 2',JJTrn6SEtYZV31eyR97+'/view-8/مسلسلات-رمضان-2023',11)
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+'مسلسلات رمضان 2023',JJTrn6SEtYZV31eyR97+'/ramadan2023/مصرية',11)
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+'مسلسلات رمضان 2022',JJTrn6SEtYZV31eyR97+'/ramadan2022/مصرية',11)
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+'مسلسلات رمضان 2021',JJTrn6SEtYZV31eyR97+'/ramadan2021/مصرية',11)
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+'مسلسلات رمضان 2020',JJTrn6SEtYZV31eyR97+'/ramadan2020/مصرية',11)
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+'مسلسلات رمضان 2019',JJTrn6SEtYZV31eyR97+'/ramadan2019/مصرية',11)
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+'مسلسلات رمضان 2018',JJTrn6SEtYZV31eyR97+'/ramadan2018/مصرية',11)
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+'مسلسلات رمضان 2017',JJTrn6SEtYZV31eyR97+'/ramadan2017/مصرية',11)
	Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+'مسلسلات رمضان 2016',JJTrn6SEtYZV31eyR97+'/ramadan2016/مصرية',11)
	return
def vyM5CbgVYS():
	QstumvzTIEUMXCcx06aD4y8nSqH = QuWA3hsmIvockZDiy2rLg(Z7uFdWIRv9ybj0,JJTrn6SEtYZV31eyR97,'',headers,True,'ALARAB-LATEST-1st')
	IZGcQbePXxwAoyYR1n=ZXFs0mEPR8qI2zj.findall('heading-top(.*?)div class=',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	bdq4e6Wr2gslnSiA38 = IZGcQbePXxwAoyYR1n[0]+IZGcQbePXxwAoyYR1n[1]
	items=ZXFs0mEPR8qI2zj.findall('href="(.*?)".*?data-src="(.*?)" alt="(.*?)"',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
	for RRucmYBaXegTtNOdGHMQ,CrGO63LT7j2UxniW,title in items:
		url = JJTrn6SEtYZV31eyR97 + RRucmYBaXegTtNOdGHMQ
		if 'series' in url: Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+title,url,11,CrGO63LT7j2UxniW)
		else: Tca7NsYPkIRWtBpFgxLZbSmCi('video',W74fAyGxODoLPs5vMX2l8C93R+title,url,12,CrGO63LT7j2UxniW)
	return
def RxAy5lEFQ1chv0BrdU4p6Pt2(url):
	wpFmEA3z8JR = A6F71g3cqN4(Z7uFdWIRv9ybj0,'GET',url,'',headers,True,True,'ALARAB-TITLES-1st')
	QstumvzTIEUMXCcx06aD4y8nSqH = wpFmEA3z8JR.content
	IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('video-category(.*?)right_content',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	if not IZGcQbePXxwAoyYR1n: return
	bdq4e6Wr2gslnSiA38 = IZGcQbePXxwAoyYR1n[0]
	CTQlmBkHVz6JioRW = False
	items = ZXFs0mEPR8qI2zj.findall('video-box.*?href="(.*?)".*?src="(http.*?)" alt="(.*?)"',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
	FF1TYf6O5KENr8R72LUVievClmudxD,IN6fHPDgUuOEvsXR3814Y = [],[]
	for RRucmYBaXegTtNOdGHMQ,CrGO63LT7j2UxniW,title in items:
		if title=='': title = RRucmYBaXegTtNOdGHMQ.split('/')[-1].replace('-',' ')
		QmVwp4UG5eXbO6vRtcWghHY8a7nFqN = ZXFs0mEPR8qI2zj.findall('(\d+)',title,ZXFs0mEPR8qI2zj.DOTALL)
		if QmVwp4UG5eXbO6vRtcWghHY8a7nFqN: QmVwp4UG5eXbO6vRtcWghHY8a7nFqN = int(QmVwp4UG5eXbO6vRtcWghHY8a7nFqN[0])
		else: QmVwp4UG5eXbO6vRtcWghHY8a7nFqN = 0
		IN6fHPDgUuOEvsXR3814Y.append([CrGO63LT7j2UxniW,RRucmYBaXegTtNOdGHMQ,title,QmVwp4UG5eXbO6vRtcWghHY8a7nFqN])
	IN6fHPDgUuOEvsXR3814Y = sorted(IN6fHPDgUuOEvsXR3814Y, reverse=True, key=lambda key: key[3])
	for CrGO63LT7j2UxniW,RRucmYBaXegTtNOdGHMQ,title,QmVwp4UG5eXbO6vRtcWghHY8a7nFqN in IN6fHPDgUuOEvsXR3814Y:
		RRucmYBaXegTtNOdGHMQ = JJTrn6SEtYZV31eyR97 + RRucmYBaXegTtNOdGHMQ
		title = title.replace('مشاهدة مسلسل','مسلسل')
		title = title.replace('مشاهدة المسلسل','المسلسل')
		title = title.replace('مشاهدة فيلم','فيلم')
		title = title.replace('مشاهدة الفيلم','الفيلم')
		title = title.replace('مباشرة كواليتي','')
		title = title.replace('عالية على العرب','')
		title = title.replace('مشاهدة مباشرة','')
		title = title.replace('اون لاين','')
		title = title.replace('اونلاين','')
		title = title.replace('بجودة عالية','')
		title = title.replace('جودة عالية','')
		title = title.replace('بدون تحميل','')
		title = title.replace('على العرب','')
		title = title.replace('مباشرة','')
		title = title.strip(' ').replace('  ',' ').replace('  ',' ')
		title = '_MOD_'+title
		Wu4CadwRTJfkbXMUVxO3jQ2 = title
		if '/q/' in url and ('الحلقة' in title or 'الحلقه' in title):
			LqYKJ36CBG = ZXFs0mEPR8qI2zj.findall('(.*?) الحلقة \d+',title,ZXFs0mEPR8qI2zj.DOTALL)
			if LqYKJ36CBG: Wu4CadwRTJfkbXMUVxO3jQ2 = LqYKJ36CBG[0]
		if Wu4CadwRTJfkbXMUVxO3jQ2 not in FF1TYf6O5KENr8R72LUVievClmudxD:
			FF1TYf6O5KENr8R72LUVievClmudxD.append(Wu4CadwRTJfkbXMUVxO3jQ2)
			if '/q/' in url and ('الحلقة' in title or 'الحلقه' in title):
				Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+Wu4CadwRTJfkbXMUVxO3jQ2,RRucmYBaXegTtNOdGHMQ,13,CrGO63LT7j2UxniW)
				CTQlmBkHVz6JioRW = True
			elif 'series' in RRucmYBaXegTtNOdGHMQ:
				Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,11,CrGO63LT7j2UxniW)
				CTQlmBkHVz6JioRW = True
			else:
				Tca7NsYPkIRWtBpFgxLZbSmCi('video',W74fAyGxODoLPs5vMX2l8C93R+title,RRucmYBaXegTtNOdGHMQ,12,CrGO63LT7j2UxniW)
				CTQlmBkHVz6JioRW = True
	if CTQlmBkHVz6JioRW:
		items = ZXFs0mEPR8qI2zj.findall('tsc_3d_button red.*?href="(.*?)" title="(.*?)"',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
		for RRucmYBaXegTtNOdGHMQ,wwNtFTLK2IqAszYBDV9J in items:
			url = JJTrn6SEtYZV31eyR97 + RRucmYBaXegTtNOdGHMQ
			Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+wwNtFTLK2IqAszYBDV9J,url,11)
	return
def pqx0gStI9ojGFP2rWhwRfkVCNX(url):
	QstumvzTIEUMXCcx06aD4y8nSqH = QuWA3hsmIvockZDiy2rLg(Z7uFdWIRv9ybj0,url,'',headers,True,'ALARAB-EPISODES-1st')
	iw2lpIWmKXrEnuayVe0xb = ZXFs0mEPR8qI2zj.findall('href="(/series.*?)"',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	lQHXdV9Nzf6BLqS8D = JJTrn6SEtYZV31eyR97+iw2lpIWmKXrEnuayVe0xb[0]
	HkKfQCS7RIa4xi3houjvl = RxAy5lEFQ1chv0BrdU4p6Pt2(lQHXdV9Nzf6BLqS8D)
	return
def jXYwiO9D056pkrzRh1y8tfWJxQoaI3(url):
	YYmyQXglbEewzL3IA2Sd = []
	QstumvzTIEUMXCcx06aD4y8nSqH = QuWA3hsmIvockZDiy2rLg(dALVaOWB4jKN3Tbt0Cm1ns9k5u,url,'',headers,True,'ALARAB-PLAY-1st')
	lQHXdV9Nzf6BLqS8D = ZXFs0mEPR8qI2zj.findall('class="resp-iframe" src="(.*?)"',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	if lQHXdV9Nzf6BLqS8D:
		lQHXdV9Nzf6BLqS8D = lQHXdV9Nzf6BLqS8D[0]
		R28S4pFmAojEW7CGnx = ZXFs0mEPR8qI2zj.findall('^(http.*?)(http.*?)$',lQHXdV9Nzf6BLqS8D,ZXFs0mEPR8qI2zj.DOTALL)
		if R28S4pFmAojEW7CGnx:
			Fl9VDzobcU = R28S4pFmAojEW7CGnx[0][0]
			z8ALFitr1h9eOxNP3SdTpU,gMXki9QYWHFR0hwsnIPJTz = R28S4pFmAojEW7CGnx[0][1].rsplit('/',1)
			aaIn3XlQKJ6zSfkmjuCyM = z8ALFitr1h9eOxNP3SdTpU+'?named=__watch'
			YYmyQXglbEewzL3IA2Sd.append(aaIn3XlQKJ6zSfkmjuCyM)
			pqrfNVvo8H = Fl9VDzobcU+gMXki9QYWHFR0hwsnIPJTz
		else:
			XgMyLUkfvP4uKVpQsY8RiWZz6N50O = QuWA3hsmIvockZDiy2rLg(JNsoWV1CXc4xy,lQHXdV9Nzf6BLqS8D,'',headers,False,'ALARAB-PLAY-2nd')
			lQHXdV9Nzf6BLqS8D = ZXFs0mEPR8qI2zj.findall('"src": "(.*?)"',XgMyLUkfvP4uKVpQsY8RiWZz6N50O,ZXFs0mEPR8qI2zj.DOTALL)
			if lQHXdV9Nzf6BLqS8D:
				lQHXdV9Nzf6BLqS8D = lQHXdV9Nzf6BLqS8D[0]+'?named=__watch__m3u8'
				YYmyQXglbEewzL3IA2Sd.append(lQHXdV9Nzf6BLqS8D)
	IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('searchBox(.*?)<style>',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	if IZGcQbePXxwAoyYR1n:
		bdq4e6Wr2gslnSiA38 = IZGcQbePXxwAoyYR1n[0]
		lQHXdV9Nzf6BLqS8D = ZXFs0mEPR8qI2zj.findall('href="(.*?)"',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
		if lQHXdV9Nzf6BLqS8D:
			lQHXdV9Nzf6BLqS8D = lQHXdV9Nzf6BLqS8D[0]+'?named=__watch'
			YYmyQXglbEewzL3IA2Sd.append(lQHXdV9Nzf6BLqS8D)
	import fnxsZbk2Fm
	fnxsZbk2Fm.n2h4SBIzxbgJD3K7rtVej01EuGcHPs(YYmyQXglbEewzL3IA2Sd,ll6f2wvU4FdqL3MJyDxORESCK197i,'video',url)
	return
def EoR08gLBFy():
	QstumvzTIEUMXCcx06aD4y8nSqH = QuWA3hsmIvockZDiy2rLg(JNsoWV1CXc4xy,JJTrn6SEtYZV31eyR97,'',headers,True,'ALARAB-RAMADAN-1st')
	IZGcQbePXxwAoyYR1n = ZXFs0mEPR8qI2zj.findall('id="content_sec"(.*?)id="left_content"',QstumvzTIEUMXCcx06aD4y8nSqH,ZXFs0mEPR8qI2zj.DOTALL)
	bdq4e6Wr2gslnSiA38 = IZGcQbePXxwAoyYR1n[0]
	items = ZXFs0mEPR8qI2zj.findall('href="(.*?)".*?>(.*?)<',bdq4e6Wr2gslnSiA38,ZXFs0mEPR8qI2zj.DOTALL)
	nQGOV7qbmNtyfckr4luzA = ZXFs0mEPR8qI2zj.findall('/ramadan([0-9]+)/',str(items),ZXFs0mEPR8qI2zj.DOTALL)
	nQGOV7qbmNtyfckr4luzA = nQGOV7qbmNtyfckr4luzA[0]
	for RRucmYBaXegTtNOdGHMQ,title in items:
		url = JJTrn6SEtYZV31eyR97+RRucmYBaXegTtNOdGHMQ
		title = title.strip(' ')+' '+nQGOV7qbmNtyfckr4luzA
		Tca7NsYPkIRWtBpFgxLZbSmCi('folder',W74fAyGxODoLPs5vMX2l8C93R+title,url,11)
	return
def F6OgHwYPRiX10tJEv8r(search):
	search,Y9RKmgsxBefkFcuIj2GULDHy3,showDialogs = XDzpr8RxgZhT(search)
	if search=='': search = CjyEnpfQ23o0PYwDtLId()
	if search=='': return
	H9IMP4eTVW8dji3EXnS7w = search.replace(' ','+')
	url = JJTrn6SEtYZV31eyR97 + "/q/" + H9IMP4eTVW8dji3EXnS7w
	HkKfQCS7RIa4xi3houjvl = RxAy5lEFQ1chv0BrdU4p6Pt2(url)
	return